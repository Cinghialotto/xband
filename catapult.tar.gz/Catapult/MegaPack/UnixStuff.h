#ifndef __UNIX_TYPES_H__
#define __UNIX_TYPES_H__

#ifndef UNIX		// UNIX systems get these from various header files

#include <stdlib.h>
#include <unix.h>

// From <sys/types.h>
//
typedef unsigned char u_char;
typedef unsigned short u_short;
typedef unsigned int u_int;
typedef unsigned long u_long;


// Prototypes that non-anal compilers don't care about or define themselves.
//
void exit(int retval);
void abort(void);
void *malloc(size_t size);
void free(void *ptr);
int access(char *path, int mode);
int getopt(int argc, char **argv, char *optstring);

// From param.h:
//
#define MAXPATHLEN	1024

// From unistd.h:
//
#define	R_OK		4

#endif	/*UNIX*/
#endif	/*__UNIX_TYPES_H__*/
