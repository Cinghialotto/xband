/* 
 * Generic.c - try different kinds of compression to find what's best
 */
#include <stdio.h>
#ifdef UNIX
# include <sys/types.h>
#else
# include "UnixStuff.h"
#endif

#include "MegaPack.h"
#include "MegaPackPriv.h"


// ===========================================================================
//		Local prototypes
// ===========================================================================

PRIVATE u_long ccitt_updcrc(u_int icrc, const u_char *icp, int icnt);

PRIVATE long CompressNone(const u_char *plain, u_char *enc, long size, u_long flags, BestData *bestBuf);
PRIVATE long ExpandNone(const u_char *enc, u_char *plain, long encSize, long plainSize, u_long flags);


// ===========================================================================
//		Compression methods
// ===========================================================================

#ifdef BOX_ONLY
# define CompressLzb	NULL
#endif

PRIVATE CompressionMethod methods[kMPmaxMethods] = {
#ifdef UNIX
	kMPnone,		"(no compression)",		CompressNone,		ExpandNone,
	kMPquickText,	"Quick text squash",	CompressQuickText,	ExpandQuickText,
	kMPdigram,		"Digram coding",		CompressDigram,		ExpandDigram,
	kMPstaticHuff,	"Static Huffman",		CompressHuff,		ExpandHuff,
	kMPlzss,		"LZSS",					CompressLzss,		ExpandLzss,
	kMPlzb,			"LZB",					CompressLzb,		ExpandLzb,
	kMPjrHuff,		"Japan-RLE-Huffman",	CompressJRHuff,		ExpandJRHuff,
	kMPdebug,		"XOR debug thing",		CompressDebug,		ExpandDebug,
	-1,				"(undefined)",			NULL,				NULL,
#else
	kMPnone,		"(no compression)",		CompressNone,		ExpandNone,
	kMPquickText,	"(not for mac)",		NULL,				NULL,
	kMPdigram,		"Digram coding",		CompressDigram,		ExpandDigram,
	kMPstaticHuff,	"(not for mac)",		NULL,				NULL,
	kMPlzss,		"(not for mac)",		NULL,				NULL,
	kMPlzb,			"LZB",					CompressLzb,		ExpandLzb,
	kMPdebug,		"XOR debug thing",		CompressDebug,		ExpandDebug,
	-1,				"(undefined)",			NULL,				NULL,
#endif
};


// ===========================================================================
//		Main entry points
// ===========================================================================

//
// Compress "size" bytes from "plain" buffer to "enc" buffer.
//
// For our nefarious purposes we assume "enc" buffer is at least 2x "size".
//
// We try each of the compression methods in turn to find out which one
// gives the best compression.  Once we have it, we call that routine again
// to produce the final output.
//
// Returns result (#of byte of enc data) on success, -1 on error.
//
long
Compress(const u_char *plain, u_char *enc, long size, u_long flags)
{
	u_char *data;
	u_short crc = 0;
	long result, bestFlags=flags, bestSize=-1;
	int i, bestMethod=-1;
	u_char cflags;
	BestData bestBuf, tmpBestBuf;

	if (size >= 65536)
		flags |= kMPisBigFile;

	if (flags & kMPincludeCRC)
		crc = ccitt_updcrc(-1, plain, size);


	if (flags & kMPmodeMask) {
		// A "mode" flag was set, so we're only going to be doing the
		// compression once, not probing a set of possible methods.
		//
		// This was something of an afterthought. :-(
		//
		switch (flags & kMPmodeMask) {
		case kMPmodeXMail:
			i = kMPdigram;
			flags |= kMPremapText | kMPuseRLE;
			break;
		case kMPmodeDebug:
			i = kMPdebug;
			flags &= ~(kMPremapText | kMPuseRLE);
			break;
		case kMPmodeText:
			i = kMPlzb;
			flags &= ~kMPremapText;
			break;
		case kMPmodeNews:
			i = kMPlzb;
			flags &= ~kMPremapText;
			break;
		case kMPmodeLZSS:
		case kMPmodeCode:
		case kMPmodeGraphics:
			i = kMPlzb;
			flags &= ~kMPremapText;
			break;
		default:
			fprintf(stderr, "ERROR: Unknown mode 0x%.8lx\n",
				flags & kMPmodeMask);
			return (-1);
		}
		tmpBestBuf.bestFlag = TRUE;		// compressor needs to set this

		// Figure out where the data needs to start.  This needs to match
		// the header creation stuff below.
		//
		data = enc;
		data++;			// one byte for cflags
		data += 2;		// two bytes for size
		if (flags & kMPisBigFile)
			data += 2;	// another two bytes if it's a big file
		if (bestFlags & kMPincludeCRC)
			data += 2;	// and another two if it his a CRC

		if (methods[i].compress == NULL) {
			fprintf(stderr, "ERROR: You moron: you didn't link %d in\n", i);
			return (-1);
		}
		result = (methods[i].compress)(plain, data, size, flags, &tmpBestBuf);
		bestSize = result;
		bestFlags = flags;
		bestBuf = tmpBestBuf;
		bestMethod = i;
	} else {
		// Try each of the compression methods in turn.  Since bestFlag is set
		// to FALSE, the contents of "enc" aren't necessarily valid... the idea
		// is just to get the compressed size and the settings in bestBuf.
		//
		for (i = 0; i < kMPmaxMethods; i++) {
			tmpBestBuf.bestFlag = FALSE;
			if (!(flags & (1 << i)))
				continue;
			if (methods[i].compress == NULL)
				continue;

			if (verbose)
				DBUG(("  Trying '%s'...\n", methods[i].label));
			result = (methods[i].compress)(plain, enc, size, flags, &tmpBestBuf);
			if (result >= 0) {
				if ((bestSize == -1) || (result < bestSize)) {
					bestSize = result;
					bestFlags = flags;
					bestBuf = tmpBestBuf;
					bestMethod = i;
				}
			}

			if (flags & kMPuseRLE) {
				if (verbose)
					DBUG(("  Trying '%s' w/o RLE...\n", methods[i].label));
				result = (methods[i].compress)(plain, enc, size,
					flags & (~kMPuseRLE), &tmpBestBuf);
				if (result >= 0) {
					if ((bestSize == -1) || (result < bestSize)) {
						bestSize = result;
						bestFlags = flags & (~kMPuseRLE);
						bestBuf = tmpBestBuf;
						bestMethod = i;
					}
				}
			}
		}
	}

	if (bestSize < 0 || bestMethod < 0) {
		fprintf(stderr, "ERROR: no compression succeeded\n");
		return (-1);
	}


	// Use whichever one won.  We do the header regardless of whether we
	// produce output or not, so we can see how large the header would be.
	//
	data = enc;

	cflags = bestMethod;
	if (bestFlags & kMPincludeCRC)
		cflags |= kMPcrcIncluded;
	if (bestFlags & kMPremapText)
		cflags |= kMPtextRemapped;
	if (bestFlags & kMPuseRLE)
		cflags |= kMPrleUsed;
	if (bestFlags & kMPisBigFile)
		cflags |= kMPbigFile;
	*data++ = cflags;

	// Write the length bytes, in little-endian order.
	//
	if (flags & kMPisBigFile) {
		*data++ = size & 0xff;
		*data++ = (size >> 8) & 0xff;
		*data++ = (size >> 16) & 0xff;
		*data++ = (size >> 24) & 0xff;
	} else {
		*data++ = size & 0xff;
		*data++ = (size >> 8) & 0xff;
	}

	if (bestFlags & kMPincludeCRC) {
		*data++ = crc & 0xff;
		*data++ = (crc >> 8) & 0xff;
	}


	if (verbose) {
		DBUG(("  Winner is '%s' (%ld + %d bytes)\n",
			methods[bestMethod].label, bestSize, data - enc));
		fflush(stdout);
	}

	// Now compress it into the buffer, beyond the header.
	//
	// If one of the "mode" flags is set, we don't need to do this.
	//
	if (!(flags & kMPmodeMask) && !(flags & kMPnoOutput)) {
		bestBuf.bestFlag = TRUE;	// compressing for real
		result = (methods[bestMethod].compress)(plain, data, size, bestFlags,
			&bestBuf);
		if (result != bestSize) {
			fprintf(stderr, "ERROR: final compression was non-deterministic?\n");
			return (-1);
		}
	} else
		result = bestSize;

	return (result + (data - enc));
}


//
// Expand "size" bytes from "enc" buffer to "plain" buffer.
//
// The size of the uncompressed output is known, and it's up to the caller
// to ensure that "plain" is large enough.  The kind of compression used is
// embedded in the input stream, so no flags are needed.
//
// To simplify things, this interprets the compressed header, and passes
// the broken-out fields to the methods.  The CRC is computed here, if
// necessary.
//
// Returns result (#of byte of plain data) on success, -result on partial
// expand, or 0 on errors that occur before expansion begins.  Kinda weird.
//
long
Expand(const u_char *enc, u_char *plain, long size)
{
	int method, flags;
	long plainSize, result;
	u_long dataFlags;
	u_short crc = 0;
	const u_char *orig=enc, *data;

	// Decode the header.  Length and CRC are in little-endian order.
	//
	method = *enc & 0x0f;
	dataFlags = *enc & 0xf0;
	if (dataFlags & kMPbigFile) {
		plainSize = *++enc;
		plainSize += (*++enc) << 8;
		plainSize += (*++enc) << 16;
		plainSize += (*++enc) << 24;
	} else {
		plainSize = *++enc;
		plainSize += (*++enc) << 8;
	}
	if (dataFlags & kMPcrcIncluded) {
		crc = *++enc;
		crc += (*++enc) << 8;
	}
	data = ++enc;

	if (plainSize > kMaxPlain) {
		fprintf(stderr, "ERROR: plainSize is > kMaxPlain (%ld > %ld)\n",
			plainSize, kMaxPlain);
		return (0);
	}

	// Convert the four flag bits from the ID byte into the flags used
	// as inputs to Compress.
	//
	flags = 0;
	flags |= (dataFlags & kMPbigFile) ? kMPisBigFile : 0;
	flags |= (dataFlags & kMPrleUsed) ? kMPuseRLE : 0;
	flags |= (dataFlags & kMPtextRemapped) ? kMPremapText : 0;
	flags |= (dataFlags & kMPcrcIncluded) ? kMPincludeCRC : 0;

	if (method < 0 || method > kMPmaxMethods) {
		fprintf(stderr, "ERROR: invalid method # (%d)\n", method);
		return (0);
	}
	if (methods[method].expand == NULL) {
		fprintf(stderr, "ERROR: no proc for method #%d\n", method);
		return (0);
	}

	if (plainSize <= 0) {
		fprintf(stderr, "ERROR: plainSize == %ld\n", plainSize);
		return (0);
	}

	if (methods[method].expand == NULL) {
		fprintf(stderr, "ERROR: no expansion routine for method %d\n", method);
	}
	if (verbose)
		DBUG(("  Expanding '%s' from %ld to %ld bytes\n",
			methods[method].label, size - (data - orig), plainSize));

	result = (methods[method].expand)(enc, plain, size - (data - orig),
		plainSize, flags);

	if (result < 0) {
		fprintf(stderr, "ERROR: expand failed\n");
		return (result);
	}
	if (result != plainSize) {
		fprintf(stderr, "ERROR: expanded size (%ld) != plainSize (%ld)\n",
			result, plainSize);
		return (-result);
	}
	if (dataFlags & kMPcrcIncluded) {
		if (crc != ccitt_updcrc(-1, plain, plainSize)) {
			fprintf(stderr, "ERROR: CRC mismatch\n");
			fflush(stdout);
			fflush(stderr);
			return (-result);
		} else {
			DBUG(("  CRCs match\n"));
		}
	} else {
		DBUG(("  (no CRC)\n"));
	}

	return (result);
}


// ===========================================================================
//		The "no compression" routines.
// ===========================================================================

//
// These run through the byte context routines to get RLE and character
// remapping.
//

PRIVATE long
CompressNone(const u_char *plain, u_char *enc, long size, u_long flags, BestData *best)
{
	ByteContext bytxt;
	u_char *orig = enc;
	int ic;

	// If not the final run and we're not doing RLE, we already know the
	// answer and don't need to store any data.  We need to be careful around
	// "remap", because that can cause us to inject an extra 0x7f... we
	// want to silently turn it off, but can't because we've already written
	// the header and the box won't silently ignore it on the remote side.
	// Needs to be turned off before we get here.
	//
	if (!best->bestFlag && !(flags & kMPuseRLE) && !(flags & kMPremapText)) {
		LDBUG(1, ("    (Trivial) size is %ld bytes\n", size));
		return (size);
	}

	InitByte(&bytxt, plain, size, flags);

	while ((ic = GetByte(&bytxt)) != -1)
		*enc++ = ic;

	LDBUG(1, ("    Size is %d bytes\n", enc - orig));
	return (enc - orig);
}

PRIVATE long
ExpandNone(const u_char *enc, u_char *plain, long encSize, long plainSize, u_long flags)
{
	ByteContext bytxt;

	InitByte(&bytxt, plain, plainSize, flags);

	while (1) {
		if (PutByte(&bytxt, *enc++) != 0)
			break;
	}
	return (plainSize);
}


// ===========================================================================
//		16-Bit I/O routines
// ===========================================================================

//
// These are usually used for generating compressed output or reading
// compressed input.
//
// Two sets of routines, one with a 16-bit output buffer and one with a
// 32-bit output buffer.  The 16-bit registers on the lesser processors make
// the 16-bit one more efficient, but sometimes you really want 32 bits
// (the 16-bit routines don't allow you to read or write more than 16 bits).
// [32-bit routines not implemented]
//
// A given context should be read from or written to.  Attempting to mix
// behaviors is undefined, but probably won't do anything you want it to.
//
// These routines make no attempt to halt at the end of the input buffer.
// If you're trying to read past the end, you're fucked anyway.
//
// Basic plan is to always ensure that there are as many full bytes loaded
// as we can cram in, so there's always at least 9 (16-bit) or 25 (32-bit)
// bits available.  If they want more, we shift out what we have and load
// more in.
//

//
// Initialize the bit context.  Pass in a pointer to the buffer things will
// be read from or written to.
//
// Initializes values, preloads the shift "registers".
//
void
InitBits16(BitContext *ctxt, const u_char *buf, int type)
{
	ctxt->buf = (u_char *)buf;
	if (type == kMPinputContext) {
		ctxt->reg16 = (*(ctxt->buf++)) << 8;
		ctxt->reg16 += *(ctxt->buf++);
		ctxt->count = 16;
	} else {
		ctxt->reg16 = 0;
		ctxt->count = 0;
	}
	ctxt->reg32 = 0xdeadbeefL;
}

PRIVATE u_short bitmask16[17] = {
	0x0000,
	0x8000, 0xc000, 0xe000, 0xf000,  0xf800, 0xfc00, 0xfe00, 0xff00,
	0xff80, 0xffc0, 0xffe0, 0xfff0,  0xfff8, 0xfffc, 0xfffe, 0xffff
};

//
// Input the next "count" bits.  Result is aligned with the hi bit.
//
// I'm writing this with a 65816 translation in mind.
//
u_short
InputBits16(register BitContext *ctxt, register int count)
{
	register u_short ret;

	LDBUG(3, ("    --Input16(%d) from 0x%.4x/%ld, next 0x%.2x\n",
		count, ctxt->reg16, ctxt->count, *ctxt->buf));
	if (count <= 0 || count > 16) {
		fprintf(stderr, "ERROR: %d bytes requested in InputBits16\n", count);
		exit(1);	// better than getting 2000 copies of error message
	}

	if (count > ctxt->count) {
		// Need more than we have.  Since we always keep the buffer full,
		// they must want more than 9 bits, and we must have at least 9
		// bits.  We copy the high byte, shift it left 8 bits, then merge
		// in the next byte of input, which is guaranteed to cover the
		// request.
		//
		ret = ctxt->reg16 & 0xff00;
		count -= 8;
		// don't mess with ctxt->count, because we're about to add 8 more
		ctxt->reg16 = (ctxt->reg16 << 8) |
			((unsigned short) *(ctxt->buf++) << (16 - ctxt->count));

		// now we know they want 8 or less, and we have at least 9 more
		ret |= (ctxt->reg16 & bitmask16[count]) >> 8;

		// update context, and reload if necessary
		ctxt->reg16 <<= count;
		ctxt->count -= count;
		// we have 1 to 14 bits loaded in the shift reg; if below 9 fill up
		if (ctxt->count < 9) {
			ctxt->reg16 |=
				((unsigned short) *(ctxt->buf++) << (8 - ctxt->count));
			ctxt->count += 8;
		}
	} else if (count == ctxt->count) {
		// Want exactly what we have (this test follows naturally from the
		// first on an '816).  Copy the whole thing, reload two bytes.
		//
		ret = ctxt->reg16;
		ctxt->reg16 = (*(ctxt->buf++)) << 8;
		ctxt->reg16 += *(ctxt->buf++);
		ctxt->count = 16;
	} else {
		// Want less than we have.  Copy the bits out, slide left, grab
		// another byte or two if we need them.
		//
		ret = ctxt->reg16 & bitmask16[count];
		ctxt->reg16 <<= count;
		ctxt->count -= count;
		// we have 1 to 15 bits loaded
		if (ctxt->count < 9) {
			ctxt->reg16 |= *(ctxt->buf++) << (8 - ctxt->count);
			ctxt->count += 8;
		}
	}

	LDBUG(4, ("      returned 0x%.4x\n", ret));

	// Sanity check.
	//
	if (ctxt->count <= 8) {
		fprintf(stderr, "ERROR: ctxt is not full on exit!\n");
		abort();
	}

	return (ret);
}

//
// Peek at the incoming bit stream without removing bits.
//
u_short
PeekBits16(register BitContext *ctxt, register int count)
{
	if (count < 0 || count > 9) {
		fprintf(stderr, "ERROR: %d bits requested in PeekBits16\n", count);
		exit(1);
	}

	// We're guaranteed to have at least 9 bits in the buffer.
	//
	return (ctxt->reg16 & bitmask16[count]);
}

//
// Output the high "count" bits of "bits".  Expects "bits" to be properly
// masked.
//
// This is a whole bunch easier than input.  Again, I'm writing this with a
// 65816 translation in mind.
//
void
OutputBits16(register BitContext *ctxt, register u_short bits, register int count)
{
	LDBUG(3, ("    --Output16(0x%.4x/%-2d) to 0x%.4x/%-2ld\n",
		bits, count, ctxt->reg16, ctxt->count));
	if (count <= 0 || count > 16) {
		fprintf(stderr, "ERROR: %d bits requested in OutputBits16\n", count);
		exit(1);	// better than getting 2000 copies of error message
	}

	if (count <= 9) {
		// Since we have at most 7 bits in the shift register, we know that
		// the entire output request will fit in with whatever's there.
		//
		ctxt->reg16 |= bits >> ctxt->count;
		ctxt->count += count;
		if (ctxt->count == 16) {
#ifdef BROKEN
			*(ctxt->buf++) = ctxt->reg16 & 0xff;
			//LDBUG(4, ("        1Wrote 0x%2x\n", ctxt->reg16 & 0xff));
			*(ctxt->buf++) = (ctxt->reg16 >> 8) & 0xff;
			//LDBUG(4, ("        +1Wrote 0x%2x\n", (ctxt->reg16 >> 8) & 0xff));
#else
			*(ctxt->buf++) = (ctxt->reg16 >> 8) & 0xff;
			//LDBUG(4, ("        1Wrote 0x%2x\n", (ctxt->reg16 >> 8) & 0xff));
			*(ctxt->buf++) = ctxt->reg16 & 0xff;
			//LDBUG(4, ("        +1Wrote 0x%2x\n", ctxt->reg16 & 0xff));
#endif
			ctxt->count = 0;
			ctxt->reg16 = 0;
		} else if (ctxt->count >= 8) {
			*(ctxt->buf++) = (ctxt->reg16 >> 8) & 0xff;
			//LDBUG(4, ("        2Wrote 0x%2x\n", (ctxt->reg16 >> 8) & 0xff));
			ctxt->count -= 8;
			ctxt->reg16 <<= 8;
		}
	} else {
		// It may or may not fit.  We know it's at least 10 bits, so we
		// will be outputting one or two bytes.  We also know that we have
		// at most 7 bits loaded, so we have to shift in the input as we go.
		//
		ctxt->reg16 |= (bits & 0xff00) >> ctxt->count;
		count -= 8;
		*(ctxt->buf++) = (ctxt->reg16 >> 8) & 0xff;
		//LDBUG(4, ("        3Wrote 0x%2x\n", (ctxt->reg16 >> 8) & 0xff));
		// we added 8, then output 8, so no change to ctxt->count
		ctxt->reg16 <<= 8;

		// 8 down, 2 - 8 more to go.  We just output 8 so we must have room
		// for another 8.
		ctxt->reg16 |= (bits & 0xff) << (8 - ctxt->count);
		ctxt->count += count;
		if (ctxt->count >= 8) {
			*(ctxt->buf++) = (ctxt->reg16 >> 8) & 0xff;
			//LDBUG(4, ("        +3Wrote 0x%2x\n", (ctxt->reg16 >> 8) & 0xff));
			ctxt->count -= 8;
			ctxt->reg16 <<= 8;
		}
	}

	LDBUG(4, ("      Exit with 0x%.4x %-2ld\n", ctxt->reg16, ctxt->count));

	// Sanity check.
	//
	if (ctxt->count >= 8) {
		fprintf(stderr, "ERROR: ctxt is still full on exit!\n");
		abort();
	}
}

//
// Flush any lingering bits out of the pipe.
//
void
FlushBits16(register BitContext *ctxt)
{
	// There are at most 7 bits waiting.  Output enough zeros to force it
	// to emit a byte.
	//
	if (ctxt->count)
		OutputBits16(ctxt, 0, 8 - ctxt->count);

	// Sanity check.
	//
	if (ctxt->count) {
		fprintf(stderr, "ERROR: ctxt still full after flush!\n");
		abort();
	}
}

//
// Get the current pointer.
//
// This could probably be merged with FlushBits16, since the only time we
// care is after we finish producing output and want to know how many bytes
// of data we've generated.
//
u_char *
GetBitPointer(BitContext *ctxt)
{
	return (ctxt->buf);
}


// ===========================================================================
//		32-Bit I/O routines
// ===========================================================================

//
// Initialize the bit context.  Pass in a pointer to the buffer things will
// be read from or written to.
//
// Initializes values, preloads the shift "registers".
//
void
InitBits32(BitContext *ctxt, const u_char *buf, int type)
{
	ctxt->buf = (u_char *)buf;
	if (type == kMPinputContext) {
		ctxt->reg32 = (*(ctxt->buf++)) << 24;
		ctxt->reg32 |= (*(ctxt->buf++)) << 16;
		ctxt->reg32 |= (*(ctxt->buf++)) << 8;
		ctxt->reg32 |= *(ctxt->buf++);
		ctxt->count = 32;
	} else {
		ctxt->reg32 = 0;
		ctxt->count = 0;
	}
	ctxt->reg16 = 0xdead;
}


PRIVATE u_long bitmask32[33] = {
	0x00000000L,
	0x80000000L, 0xc0000000L, 0xe0000000L, 0xf0000000L,
	0xf8000000L, 0xfc000000L, 0xfe000000L, 0xff000000L,
	0xff800000L, 0xffc00000L, 0xffe00000L, 0xfff00000L,
	0xfff80000L, 0xfffc0000L, 0xfffe0000L, 0xffff0000L,
	0xffff8000L, 0xffffc000L, 0xffffe000L, 0xfffff000L,
	0xfffff800L, 0xfffffc00L, 0xfffffe00L, 0xffffff00L,
	0xffffff80L, 0xffffffc0L, 0xffffffe0L, 0xfffffff0L,
	0xfffffff8L, 0xfffffffcL, 0xfffffffeL, 0xffffffffL
};

//
// Input the next "count" bits.  Result is aligned with the hi bit.
//
u_long
InputBits32(register BitContext *ctxt, register int count)
{
	register u_long work;

	LDBUG(3, ("    --Input32(%d) from 0x%.8lx/%ld, next 0x%.2x\n",
		count, ctxt->reg32, ctxt->count, *ctxt->buf));
	if (count <= 0 || count > 32) {
		fprintf(stderr, "ERROR: %d bytes requested in InputBits32\n", count);
		exit(1);	// better than getting 2000 copies of error message
	}

	if (count < ctxt->count) {
		// We have it all in the buffer; send it and reload.
		//
		work = ctxt->reg32 & bitmask32[count];
		ctxt->reg32 <<= count;
		ctxt->count -= count;

	} else {
		// We need to get more to fill the request.  We need to retrieve
		// at most one more byte.
		//
		work = ctxt->reg32 & 0xff000000;
		count -= 8;
		ctxt->reg32 <<= 8;
		// no need to diddle ctxt->count; we removed 8, and will now add 8
		ctxt->reg32 |= (*ctxt->buf++) << (32 - ctxt->count);
		work |= (ctxt->reg32 & bitmask32[count]) >> 8;

		ctxt->reg32 <<= count;
		ctxt->count -= count;
	}
	while (ctxt->count <= 24) {
		ctxt->reg32 |= *(ctxt->buf++) << (24 - ctxt->count);
		ctxt->count += 8;
	}

	return (0);
}

//
// Peek at the incoming bit stream without removing bits.
//
u_long
PeekBits32(register BitContext *ctxt, register int count)
{
	if (count < 0 || count > 25) {
		fprintf(stderr, "ERROR: %d bytes requested in PeekBits32\n", count);
		exit(1);
	}

	// We're guaranteed to have at least 25 bits in the buffer.
	//
	return (ctxt->reg32 & bitmask32[count]);
}

//
// Output the high "count" bits of "bits".  Expects "bits" to be properly
// masked.
//
void
OutputBits32(register BitContext *ctxt, register u_long bits, register int count)
{
	register u_long work;

	LDBUG(3, ("    --Output32(0x%.8lx/%-2d) to 0x%.8lx/%-2ld\n",
		bits, count, ctxt->reg32, ctxt->count));
	if (count <= 0 || count > 32) {
		fprintf(stderr, "ERROR: %d bits requested in OutputBits32\n", count);
		exit(1);	// better than getting 2000 copies of error message
	}

	if (count + ctxt->count > 32) {
		// Merge in enough to finish what we've got buffered, output that
		// byte, then dump the rest.  Since we overflowed 32 bits, after
		// outputting one byte we will have three full bytes and some number
		// of bits.
		//
		work = ctxt->reg32 | (bits >> ctxt->count);
		*(ctxt->buf++) = work >> 24;
		*(ctxt->buf++) = work >> 16;
		*(ctxt->buf++) = work >> 8;
		*(ctxt->buf++) = work;
		ctxt->reg32 = bits << (32 - ctxt->count);
		ctxt->count = (count + ctxt->count) - 32;
	} else {
		// Entire thing fits in the 32-bit output buffer, so merge it in
		// and spit out bytes until all the full bytes are gone.
		//
		ctxt->reg32 |= bits >> ctxt->count;
		ctxt->count += count;
		while (ctxt->count >= 8) {
			*(ctxt->buf++) = ctxt->reg32 >> 24;
			ctxt->reg32 <<= 8;
			ctxt->count -= 8;
		}
	}

	LDBUG(4, ("      Exit with 0x%.8lx %-2ld\n", ctxt->reg32, ctxt->count));

	// Sanity check.
	//
	if (ctxt->count >= 8) {
		fprintf(stderr, "ERROR: ctxt 32 is still full on exit!\n");
		abort();
	}
}

//
// Flush any lingering bits out of the pipe.
//
void
FlushBits32(register BitContext *ctxt)
{
	// There are at most 7 bits waiting.  Output enough zeros to force it
	// to emit a byte.
	//
	if (ctxt->count)
		OutputBits32(ctxt, 0, 8 - ctxt->count);

	// Sanity check.
	//
	if (ctxt->count) {
		fprintf(stderr, "ERROR: ctxt 32 still full after flush!\n");
		abort();
	}
}


// ===========================================================================
//		Byte I/O routines
// ===========================================================================

//
// These will transparently remap the character set from what the box
// knows to a set of values < kRestIsPlain (0x7f), and will transparently
// compress and expand the incoming data with RLE.  They are meant for
// reading data from the *uncompressed* input, and writing data to the
// *uncompressed* output.
//
// A given context should be read from or written to.  Attempting to mix
// behaviors is undefined, but probably won't do anything you want it to.
//
// The RLE encoding is <escape> <char> <count>, where "escape" is kRLEescape
// (0x1f), "char" is the character we found a run of, and "count" is the #of
// occurrences of that character minus 1.  The count value ranges from 0x00
// to 0x7e, so if "remap" is on, all values are still less than 0x7f, and
// for Huffman the RLE counts occupy the same space as remapped characters.
//

//
// Initialize the byte context.  Pass in a pointer to the buffer things will
// be read from or written to.
//
// Initializes values.  "count" is always the uncompressed size.
//
void
InitByte(ByteContext *bytxt, const u_char *buf, const long count, u_long flags)
{
	LDBUG(3, ("    --InitByte  count=%ld flags=0x%.8lx\n", count, flags));
	bytxt->buf = (u_char *)buf;
	bytxt->count = count;
	bytxt->rleFlag = (flags & kMPuseRLE) != 0;
	bytxt->remapFlag = (flags & kMPremapText) != 0;
	bytxt->rleState = 0;
}

//
// Read the next byte from the uncompressed input.
//
// If "remapFlag" is set and an unmappable character is encountered, 0x7f is
// returned, and the remap flag is cleared.  Future data will not be
// mapped, though RLE will continue to function.
//
// If "rleFlag" is set, multiple occurrences of the same character will
// be counted and combined.
//
// When "count" reaches zero, -1 is returned to indicate EOF.
//
int
GetByte(register ByteContext *bytxt)
{
	register int ic;
	register int rlcount, maxcount;
	register u_char raw, *rlePtr;

	if (bytxt->rleFlag && bytxt->rleState) {
		LDBUG(3, ("    --GetByte rleState=%d, char=0x%.2x, count=%d\n",
			bytxt->rleState, bytxt->rleChar, bytxt->rleCount));
		bytxt->rleState--;
		if (bytxt->rleState == 1)
			return (bytxt->rleChar);
		else
			return (bytxt->rleCount);
	}

	if (!bytxt->count)
		return (-1);

	bytxt->count--;
	if (bytxt->remapFlag) {
		ic = BOX2LOWA(*(bytxt->buf++));
		if (ic == -1) {
			// Hit an unmappable char.
			//
			bytxt->buf--;		// whoops, back up
			bytxt->count++;
			bytxt->remapFlag = FALSE;	// don't come back now, y'hear?
			return (kRestIsPlain);
		}
	} else
		ic = *(bytxt->buf++);

	// Since the input is a buffer, we've got the whole thing right in front
	// of us.  Immediately peek at the next few bytes and see what we have.
	//
	// Since the RLE code is 3 bytes, we're not interested in runs shorter
	// than four.  This actually changes quite a bit depending on what
	// compression algorithm is layered on top; it may be cheaper to put
	// in four spaces than to do the corresponding RLE code.
	//
	if (bytxt->rleFlag) {
		rlcount = 0;

		// To make the scan faster, we count up occurrences of the
		// char as it appeared *before* it was mapped.  Since the mapping
		// is reversible this will work.
		//
		// We still want to store the post-mapped results, so that the full
		// RLE sequence is all < kRestIsPlain.  For this same reason, we
		// have to stop counting when the count value is just before
		// kRestIsPlain.
		//
		if (bytxt->remapFlag)
			raw = LOWA2BOX(ic);
		else
			raw = ic;

		if (bytxt->count >= 3) {		// don't bother if not enough bytes
			rlePtr = bytxt->buf;

			// Need to stop either when we reach 0x7e or run off the end
			// of the buffer.
			maxcount = (kRestIsPlain-1 < bytxt->count) ?
				kRestIsPlain-1 : bytxt->count;

			while ((*rlePtr++ == raw) && (rlcount < maxcount))
				rlcount++;
		}
		LDBUG(3, ("    --GetByte found run of %d for 0x%.2x\n", rlcount+1, ic));
		if (rlcount >= 3 || ic == kRLEescape) {
			// Either we found 4 or more in a row, or we encountered a
			// kRLEescape and have to emit RLE output.  Basically we set
			// things up so that the next two requests for data return
			// the RLE character and count.
			//
			// This will confuse anybody who tries to read the pointer
			// directly.
			//
			LDBUG(3, ("      --Emitting RLE codes 0x%.2x %d\n", ic, rlcount));
			bytxt->rleChar = ic;
			bytxt->rleCount = rlcount;
			bytxt->rleState = 2;

			// Adjust the usual suspects.
			//
			bytxt->buf += rlcount;
			bytxt->count -= rlcount;
			return (kRLEescape);
		}
		return (ic);
	} else
		return (ic);
}

//
// Write the next byte to the uncompressed output stream.
//
// If "remapFlag" is set and an unmappable character is encountered, an error
// is returned.  If 0x7f is encountered, "remap" is turned off.
//
// It's safe to assume that the compressor didn't generate any mappings
// that we can't un-map.  If it did, we're hosed anyway, so it doesn't
// matter what we output.
//
// If "rleFlag" is set, occurrences of kRLEescape (0x1f) are caught and
// expanded.
//
// The "count" field in ByteContext isn't used.		[ it isn't?! ]
//
// Returns 0 if everything's fine, 1 if we have fully expanded the input,
// or -1 on error.
//
int
PutByte(register ByteContext *bytxt, register const u_char byte)
{
	register int ic, rlcount;

	LDBUG(3, ("    ---PutByte 0x%.2x\n", byte));
	if (bytxt->count <= 0)
		goto done;

	// Handle RLE runs.
	//
	if (bytxt->rleFlag && bytxt->rleState) {
		LDBUG(3, ("    --PutByte rleState=%d, rleChar=0x%.2x, byte=%d\n",
			bytxt->rleState, bytxt->rleChar, byte));

		bytxt->rleState--;
		if (bytxt->rleState == 1) {
			if (bytxt->remapFlag)
				bytxt->rleChar = LOWA2BOX(byte);
			else
				bytxt->rleChar = byte;
		} else {
			rlcount = byte;
			bytxt->count -= rlcount + 1;
			do {
				*(bytxt->buf++) = bytxt->rleChar;
			} while (rlcount--);
		}
		goto done;
	}

	// Check for start of RLE sequence.
	//
	if (bytxt->rleFlag && (byte == kRLEescape)) {
		// Next two bytes are char and count; wait for them to arrive.
		//
		LDBUG(3, ("    --PutByte got RLE escape 0x%.2x\n", byte));
		bytxt->rleState = 2;
		goto done;
	}

	// Handle single chars, remapping as we go.
	//
	if (bytxt->remapFlag) {
		if (byte == kRestIsPlain) {
			LDBUG(3, ("    PutByte clearing remap flag\n"));
			bytxt->remapFlag = FALSE;
			goto done;
		}
		ic = LOWA2BOX(byte);
		if (ic == -1) {
			fprintf(stderr, "ERROR: illegal value in compressed input (0x%.2x)\n",
				byte);
			return (-1);
		}
	} else {
		ic = byte;
	}

	*(bytxt->buf++) = ic;
	bytxt->count--;

done:
	LDBUG(3, ("    --PutByte count=%ld\n", bytxt->count));
	if (!bytxt->count)
		return (1);
	if (bytxt->count < 0)
		return (-1);
	return (0);
}

//
// This shouldn't really be needed; the only way we can have stuff
// buffered is if we're partway through put()ing an RLE code, in which
// case we have a problem.
//
void
FlushByte(register ByteContext *bytxt)
{
	return;
}

//
// Get the current pointer.
//
u_char *
GetBytePointer(ByteContext *bytxt)
{
	return (bytxt->buf);
}


// ===========================================================================
//		CRC routines
// ===========================================================================

// Stolen from the box comm layer.
//

PRIVATE unsigned short crctab[256] = {
	0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50a5, 0x60c6, 0x70e7,
	0x8108, 0x9129, 0xa14a, 0xb16b, 0xc18c, 0xd1ad, 0xe1ce, 0xf1ef,
	0x1231, 0x0210, 0x3273, 0x2252, 0x52b5, 0x4294, 0x72f7, 0x62d6,
	0x9339, 0x8318, 0xb37b, 0xa35a, 0xd3bd, 0xc39c, 0xf3ff, 0xe3de,
	0x2462, 0x3443, 0x0420, 0x1401, 0x64e6, 0x74c7, 0x44a4, 0x5485,
	0xa56a, 0xb54b, 0x8528, 0x9509, 0xe5ee, 0xf5cf, 0xc5ac, 0xd58d,
	0x3653, 0x2672, 0x1611, 0x0630, 0x76d7, 0x66f6, 0x5695, 0x46b4,
	0xb75b, 0xa77a, 0x9719, 0x8738, 0xf7df, 0xe7fe, 0xd79d, 0xc7bc,
	0x48c4, 0x58e5, 0x6886, 0x78a7, 0x0840, 0x1861, 0x2802, 0x3823,
	0xc9cc, 0xd9ed, 0xe98e, 0xf9af, 0x8948, 0x9969, 0xa90a, 0xb92b,
	0x5af5, 0x4ad4, 0x7ab7, 0x6a96, 0x1a71, 0x0a50, 0x3a33, 0x2a12,
	0xdbfd, 0xcbdc, 0xfbbf, 0xeb9e, 0x9b79, 0x8b58, 0xbb3b, 0xab1a,
	0x6ca6, 0x7c87, 0x4ce4, 0x5cc5, 0x2c22, 0x3c03, 0x0c60, 0x1c41,
	0xedae, 0xfd8f, 0xcdec, 0xddcd, 0xad2a, 0xbd0b, 0x8d68, 0x9d49,
	0x7e97, 0x6eb6, 0x5ed5, 0x4ef4, 0x3e13, 0x2e32, 0x1e51, 0x0e70,
	0xff9f, 0xefbe, 0xdfdd, 0xcffc, 0xbf1b, 0xaf3a, 0x9f59, 0x8f78,
	0x9188, 0x81a9, 0xb1ca, 0xa1eb, 0xd10c, 0xc12d, 0xf14e, 0xe16f,
	0x1080, 0x00a1, 0x30c2, 0x20e3, 0x5004, 0x4025, 0x7046, 0x6067,
	0x83b9, 0x9398, 0xa3fb, 0xb3da, 0xc33d, 0xd31c, 0xe37f, 0xf35e,
	0x02b1, 0x1290, 0x22f3, 0x32d2, 0x4235, 0x5214, 0x6277, 0x7256,
	0xb5ea, 0xa5cb, 0x95a8, 0x8589, 0xf56e, 0xe54f, 0xd52c, 0xc50d,
	0x34e2, 0x24c3, 0x14a0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
	0xa7db, 0xb7fa, 0x8799, 0x97b8, 0xe75f, 0xf77e, 0xc71d, 0xd73c,
	0x26d3, 0x36f2, 0x0691, 0x16b0, 0x6657, 0x7676, 0x4615, 0x5634,
	0xd94c, 0xc96d, 0xf90e, 0xe92f, 0x99c8, 0x89e9, 0xb98a, 0xa9ab,
	0x5844, 0x4865, 0x7806, 0x6827, 0x18c0, 0x08e1, 0x3882, 0x28a3,
	0xcb7d, 0xdb5c, 0xeb3f, 0xfb1e, 0x8bf9, 0x9bd8, 0xabbb, 0xbb9a,
	0x4a75, 0x5a54, 0x6a37, 0x7a16, 0x0af1, 0x1ad0, 0x2ab3, 0x3a92,
	0xfd2e, 0xed0f, 0xdd6c, 0xcd4d, 0xbdaa, 0xad8b, 0x9de8, 0x8dc9,
	0x7c26, 0x6c07, 0x5c64, 0x4c45, 0x3ca2, 0x2c83, 0x1ce0, 0x0cc1,
	0xef1f, 0xff3e, 0xcf5d, 0xdf7c, 0xaf9b, 0xbfba, 0x8fd9, 0x9ff8,
	0x6e17, 0x7e36, 0x4e55, 0x5e74, 0x2e93, 0x3eb2, 0x0ed1, 0x1ef0,
};

PRIVATE u_long
ccitt_updcrc(u_int icrc, const u_char *icp, int icnt)
{
#define M1 0xff
#define M2 0xff00
	register unsigned int crc = icrc;
	register const unsigned char *cp = icp;
	register int cnt = icnt;

	while(cnt--) {
		crc=((crc<<8)&M2)^crctab[((crc>>8)&0xff)^*cp++];
	}

	return(crc);
}

