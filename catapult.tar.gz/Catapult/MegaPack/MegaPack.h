#ifndef __MEGAPACK_H__
#define __MEGAPACK_H__

#ifdef UNIX
# include <sys/types.h>
#else
# include "UnixStuff.h"
#endif

//
// Format of compressed output, arranged for 65816.
//
// +00  (1b) compression_id
//      0-3   compression_kind
//      4     "big file" flag
//      5     "RLE preprocessed" flag
//      6     "text remapped" flag
//      7     "CRC included" flag
//
// +01  (2b) size of uncompressed data (little-endian!)
//
// +03  (2b) CRC if bit 7 set; a 16-bit CRC-CCITT of plain input seeded with -1
//           (little-endian!)
//
// +05  (..) compression-method-specific data
//


// ===========================================================================
//		Constants
// ===========================================================================

#define kMPmaxMethods	16

// Kinds of compression; must be 0-15 (must be 0-7 to fit in kMPtry*).
//
enum {
	kMPnone = 0,
	kMPquickText,
	kMPdigram,
	kMPstaticHuff,
	kMPlzss,
	kMPlzb,
	kMPjrHuff,
	kMPdebug,

	kMPlast		// if this symbol is greater than kMPmaxMethods, bad things
};


// Remaining bits of the first byte.
//
#define kMPbigFile		0x10
#define kMPrleUsed		0x20
#define kMPtextRemapped	0x40
#define kMPcrcIncluded	0x80


// Flag bits for input to Compress.
//
// Low 8 bits are flags for different methods to try.  High 24 bits modify
// how the compression is attempted.
//
#define kMPtryNone			(1L<<kMPnone)
#define kMPtryQuickText		(1L<<kMPquickText)
#define kMPtryDigram		(1L<<kMPdigram)
#define kMPtryStaticHuff	(1L<<kMPstaticHuff)
#define kMPtryLzss			(1L<<kMPlzss)
#define kMPtryLzb			(1L<<kMPlzb)
#define kMPtryDebug			(1L<<kMPdebug)
#define kMPtryJRHuff		(1L<<kMPjrHuff)

#define kMPincludeCRC		(1L<<8)			// include 16-bit CRC at front
#define kMPremapText		(1L<<9)			// remap text to be < 0x7f
#define kMPuseRLE			(1L<<10)		// do an RLE pre-processing step
#define kMPisBigFile		(1L<<11)		// store 4 bytes of length

#define kMPuseStaticDict	(1L<<12)		// LZB: try to use static dict
#define kMPuseAdaptiveDict	(1L<<13)		// LZB: try to be adaptive
#define kMPuseBothDict		(1L<<14)		// LZB: try to use both together
#define kMPvaryStaticBitl	(1L<<15)		// LZB: try different bit lens
#define kMPvaryAdaptiveBitl	(1L<<16)		// LZB: same, but on adaptive
#define kMPtryFlatBits		(1L<<17)		// LZB: flat match len for static

#define kMPnoOutput			(1L<<20)		// don't do final output generation

#define kMPmodeMask			(0xff000000UL)	// high 8 bits
#define kMPmodeDebug		(1L<<25)		// use the debug stuff
#define kMPmodeLZSS			(1L<<26)		// fake mode bit for LZB's LZSS mode
#define kMPmodeCode			(1L<<27)		// use best parms for 65816/68000
#define kMPmodeGraphics		(1L<<28)		// Sega or SNES icons & bitmaps
#define kMPmodeXMail		(1L<<29)		// for X-Mail
#define kMPmodeNews			(1L<<30)		// for XBAND News and BANDWIDTH
#define kMPmodeText			(1L<<31)		// for general ASCII text


// ===========================================================================
//		External interface
// ===========================================================================

long Compress(const u_char *plain, u_char *enc, long size, u_long flags);
long Expand(const u_char *enc, u_char *plain, long size);


#endif /*__MEGAPACK_H__*/
