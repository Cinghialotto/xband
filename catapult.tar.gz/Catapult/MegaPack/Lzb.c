//#ifdef UNIX
/*
 * lzb.c - do LZB compression
 *
 * Use of remapping recommended.
 */
#include <stdio.h>
#include <string.h>
#ifdef UNIX
# include <sys/types.h>
#else
# include "UnixStuff.h"
#endif

#include "MegaPack.h"
#include "MegaPackPriv.h"


//#undef UNIX

//
// Tweak me.
//

//#define LZSS_MODE				// create LZSS-compatible output

#define USE_GAMMA_LEN_TAB		// requires kMaxMatchLength <= 256

//#define BEAN_COUNT			// do some additional checks [now in Makefile]

//#define SIMPLE_MATCHING		// use a simpler string compare algorithm

#define MAX_CHAIN	512			// hack to avoid horrible performance on "pic"



//
// NOTES:
//	- Max match distance should be 15 bits for adaptive-only or static-only,
//	  or 14 bits for a combined mode.  That way the two flag bits and the
//	  match offset fit within a single 16-bit word.  The decoder will
//	  probably choke if this is not the case.
//
//	- Non-variable-width length codes are available with flatBits.  Right
//	  now it's only meaningful for the static dictionary.
//
// BUGS:
//	- I got lazy and didn't adjust the maxLen stuff based on minMatch.  This
//	  needs to be done when generating the string lists.  I don't regard this
//	  as significant, since the only effect is to reduce the max length for
//	  some strings from 257 to 256.
//
//	- Single-byte matches are regarded as insignificant.  This may cost a
//	  byte or two, but it is probably counter-balanced by having two-byte
//	  matches use two fewer bits.
//
//	- Horrible performance on things like "pic" or profiler output, which
//	  have large sections of 00 bytes interspersed with real data.  We
//	  can avoid the horrible performance on long runs of chars with a
//	  trivial hack: after trying N different matches, give up and take
//	  the best one we've found so far.  This results in sub-optimal parsing,
//	  but it's one hell of a lot faster.  Define MAX_CHAIN to get this.
//
//	- The shift from 7-bit to 8-bit literals doesn't take into account that
//	  a match might be found in the static dictionary, which would mean
//	  that the shift could be postponed or eliminated.  Since the primary
//	  targets for this program are X-Mail, news, and game patches, it
//	  doesn't matter.  (This is also why I don't bother trying to output
//	  8-bit data with an escape code... if it can't be remapped, it probably
//	  is a game patch with a high percentage of 8-bit data.)
//

//
// DESCRIPTION
//
// Output is as specified for the LZB algorithm in Bell/Cleary/Witten,
// _Text Compression_, pages 222-223, with the following changes:
//
//	- One or two bytes of header data are output at the start, specifying
//	  the compression parameters.
//	- The minimum match length is always 2, but otherwise varies as
//	  described.
//	- An optional static dictionary can be used in lieu of or in conjunction
//	  with the adaptive dictionary.  This is specified with an additional
//	  flag bit on the matches.
//
// This does optimal parsing on the input file, as described by
// Bell/Cleary/Witten, page 210:
//
//	"Another way to generate an optimal encoding is by working backward
//	through the text.  The approach, which is a kind of dynamic programming,
//	is inductive.  For a string x[1..n], the optimal encoding for x[n] is
//	found, then for x[n-1..n] given the optimal encoding for x[n], then for
//	x[n-2..n], and so on, until the optimal coding is known for the entire
//	text."
//
// The text goes on to caution:
//
//	"As well as suffering from the problem that the encoding delay is not
//	bounded, all these optimal parsing algorithms are slow, and to be sure
//	of working for any input, enough memory must be available to cope with
//	parsing the entire input file in one bite."
//
// You have been warned.
//
/*
Results of Bell's LZB vs pk's optimally-parsed LZB vs GNU Zip.  lzb and pk
use the same encoding scheme, so a direct comparison is relevant.  gzip
uses a completely different encoding scheme, but is still based on LZ77; it
shows what can be gained by combining a huge dictionary (15-bit reach vs
13-bit reach on lzb and pk) with Huffman encoding.

file	size		lzb					pk					gzip
------	------		------				------				------
bib		111261		44135  3.173 60.3%	42389  3.048 61.9%	34896  2.509 68.6%
book1	768771		371048 3.861 51.7%	358011 3.726 53.4%	312275 3.250 59.4%
book2	610856		250628 3.282 59.0%	241911 3.168 60.4%	206152 2.700 66.3%
geo		102400		79017  6.173 22.8%	77073  6.021 24.7%	68410  5.345 33.2%
news	377109		167592 3.555 55.6%	163577 3.470 56.6%	144395 3.063 61.7%
obj1	21504		11467  4.266 46.7%	11118  4.136 48.3%	10315  3.837 52.0%
obj2	246814		96817  3.138 60.8%	92835  3.009 62.4%	81082  2.628 67.2%
paper1	53161		21475  3.232 59.6%	20730  3.120 61.0%	18536  2.789 65.1%
paper2	82199		35285  3.434 57.1%	33974  3.307 58.7%	29660  2.887 63.9%
paper3	46526		20724  3.563 55.5%	20005  3.440 57.0%	18067  3.107 61.2%
paper4	13286		6132   3.692 53.9%	5900   3.553 55.6%	5527   3.328 58.4%
paper5	11954		5523   3.696 53.8%	5341   3.574 55.3%	4988   3.338 58.3%
paper6	38105		15196  3.190 60.1%	14676  3.081 61.5%	13206  2.773 65.3%
pic		513216		66284  1.033 87.1%	62220  0.970 87.9%	52377  0.816 89.8%
progc	39611		15259  3.082 61.5%	14798  2.989 62.6%	13255  2.677 66.5%
progl	71646		18962  2.117 73.5%	18297  2.043 74.5%	16158  1.804 77.5%
progp	49379		12882  2.087 73.9%	12464  2.019 74.8%	11180  1.811 77.3%
trans	93695		24882  2.125 73.4%	24067  2.055 74.3%	18856  1.610 79.9%

Avg	   3251493	   1263308 3.108 61.2% 1219386 3.000 62.5% 1059335 2.606 67.4%

The user times required to compress book1 were reported as:
	lzb		22.88 sec	(lzb.bintree -m 255)
	pk		36.43 sec	(pk -m text -n)
	gzip	14.30 sec	(gzip -9)
	
"pic" took several hours to compress with "pk", because it represents a
worst-case scenario for the parser.  Defining MAX_CHAIN would have reduced
this by a few orders of magnitude at the expense of compressed size.

The compression on book1 with 15-bit pk was 333413 3.470 56.7%.  Experiments
suggest that gzip's Huffman encoding supplies an additional 3-4%; the rest
is due to a fatter dictionary.  This is NOT the case with "geo" or other
binary files, where pk's packing of ASCII characters into 7 bits doesn't
work; gzip's improvement there is typically 6-7%.  (13 bits of reach were
used in the above comparisons because that was the value used by
Bell/Cleary/Witten for the table in the appendix of _Text Compression_.)
*/


//
// Header format:
//
//	+00  a b ccc dd e	[ c & d are zero if "use static" isn't set ]
//
//	  a: 1 bit "use adaptive dictionary?"
//	  b: 1 bit "use static dictionary?"
//	  c: 3 bits offset of start of static dict (0-7 * 4096)
//	  d: 2 bits #of static dictionaries spanned (0-3 means 12/13/14/15 bit span)
//	  e: 1 bit "good stuff in next byte" (if not set, no more header bytes)
//
//	+01  aaa bbb cc	[ only used when adaptiveBits != 12 or flatBits nonzero ]
//
//	  a: 3 bits max pointer distance (0-7 + 8 bits, so 256 to 32768)
//	  b: 3 bits flatBits (0-3 means none/2/3/4 bits for length)
//	  c: 2 bits (unused)
//

#define LZB_E_USE_ADAPTIVE(x)	( (x) ? 0x80 : 0)
#define LZB_E_USE_STATIC(x)		( (x) ? 0x40 : 0)
#define LZB_E_STATIC_START(x)	(( (x) / 4096) << 3)
#define LZB_E_NUM_STATIC(x)		( (x) ? (( (x) - 12) << 1) : 0)
#define LZB_E_MORE_STUFF(x)		( (x) ? 0x01 : 0)
//
#define LZB_E_ADAPTIVE_MAX(x)	(( (x) - 8) << 5)
#define LZB_E_FLAT_BITS(x)		(( (x) ? ( (x) - 1) : 0) << 2)

#define LZB_D_USE_ADAPTIVE(x)	(( (x) & 0x80) != 0)
#define LZB_D_USE_STATIC(x)		(( (x) & 0x40) != 0)
#define LZB_D_STATIC_START(x)	((( (x) & 0x38) >> 3) * 4096)
#define LZB_D_NUM_STATIC(x)		((( (x) & 0x06) >> 1) + 12)
#define LZB_D_MORE_STUFF(x)		(( (x) & 0x01) != 0)
//
#define LZB_D_ADAPTIVE_MAX(x)	((( (x) & 0xe0) >> 5) + 8)
#define LZB_D_FLAT_BITS(x)		((( (x) & 0x1c) >> 2) ? \
	((( (x) & 0x1c) >> 2) + 1) : 0)


#ifdef LIFE_IS_WONDERFUL
# define LZB_Abort()
#else
# define LZB_Abort()	{ fflush(stdout); fflush(stderr); abort(); }
#endif


// Local prototypes.
//
PRIVATE int LZBGetMinMatch(int pointerBits, int literalBits);



// ===========================================================================
//		Compression
// ===========================================================================


//
// Why hash it when you can blow a few hundred K and just index it?
//
// hashTab[x][y] is for a string with the first character 'x' and the
// second character 'y'.  If we're right at the beginning and 1-character
// matches excite us, we can just search down the 'x' axis.  (For adaptive
// matching, this is only used when generating the string lists.)
//
// Each hash table entry is a pointer into a singly-linked list of string
// offsets.  The list is organized from latest to earliest, so that (once
// we skip past everything that appears after the current position) it
// will grab a more recent match with equal length.
//
// The very last character in the file doesn't get hashed, because our
// hash table wants char pairs, and it'd be a worthless place to start
// anyway except in really contrived cases.
//

// One of these for every position in the input.
//
typedef struct StringList {
	long	length;			// optimization for cutoff at end of file
	long	next;			// index of next string in list
} StringList;

// One of these for every position in the input.  (We could combine it
// with StringList, but they serve two fundamentally different purposes.)
//
enum {
	kMatchStatic = 0,
	kMatchAdaptive = 1
};
typedef struct OptimalPath {
	long	matchOffset;	// offset, or -1 if we should use char
	int		matchLength;	// length of best match we found here if match found
	int		matchWhere;		// kMatchStatic or kMatchAdaptive if match found
	long	bitLength;		// total length of output at this juncture, in bits
} OptimalPath;

// One of these for every possible two-character combination.
//
typedef struct HashEnt {
	long	stringListHead;	// index of first string in list
} HashEnt;



//
// Compression parameters.
//

#define kMinMatchLength 2			// absolute min; wastes about a byte
#define kMaxMatchDelta	254			// first 17-bit gamma code is for 256, so
									// we want a max variance of 255 (2 - 256)

#define kStaticDictSect	4096		// each dictionary section is 4K
#define kNumStaticDicts	2			// currently 2 4096 byte chunks
#define kStaticDictSize	(kStaticDictSect * kNumStaticDicts)


#ifndef BOX_ONLY

//
// Local variables.
//
#ifdef UNIX
PRIVATE HashEnt adaptiveHashTab[256][256];
PRIVATE HashEnt staticHashTab[256][256];
#else
PRIVATE HashEnt *adaptiveHashTab = NULL;
PRIVATE HashEnt *staticHashTab = NULL;
#endif

PRIVATE StringList *adaptiveStringList = NULL;
PRIVATE StringList *staticStringList = NULL;

PRIVATE OptimalPath *optimalPath = NULL;


//
// Used to pass compression parameters around.  This gets stuffed into
// bestBuf, so make sure sizeof is less than BestData.
//
typedef struct CompressParms {
	char	useStatic;		// boolean
	char	useAdaptive;	// boolean
	char	staticStart;	// (0-7) which static dictionary to use as base
	char	staticBits;		// (12-14) length of offset into static dict
	char	adaptiveBits;	// (8-15) max size of sliding window
	char	flatBits;		// (0 or 3-5) #of bits in match len; 0 == use gamma
	long	firstHigh;		// offset of first high-ASCII char
} CompressParms;


//
// Used to maintain the current state of the compressor.  Passed to various
// subroutines so we can figure out things like how big a pointer is for a
// given offset and length.
//
typedef struct CompressState {
	// Copies of stuff from CompressParms, so we have it all in one place
	// (besides, it's more efficient to deal with ints).
	//
	int		useStatic;
	int		useAdaptive;
	int		staticStart;
	int		staticBits;
	int		adaptiveBits;

	// Constants.
	//
	int		maxOffset;		// how far back can we look? (based on adaptiveBits)
	int		maxStaticOffset;	// (based on staticBits)
	int		flatBits;		// #of bits in match length if not using gamma
	int		minMatch;		// minimum match length
	//int		maxMatch;		// maximum match length
	long	plainSize;		// size of uncompressed data
	long	firstHigh;		// offset of first high-ASCII character
	const u_char *plain;	// source buffer, so we don't have to pass it
	BitContext *ctxt;		// output bit context

	// State variables.
	//
	int		literalBits;	// #of bits for a literal + flag bit (8 or 9)
	//long	curOffset;		// what offset into the file we are working on
	int		pointerBits;	// how many bits in a ptr; based on current offset
	int		nextDecr;		// at what offset next decr in ptr size occurs
} CompressState;

//
// Prototypes.
//
PRIVATE long LZBCompress(const u_char *plain, u_char *enc, long size, CompressParms *parms);
PRIVATE long LZBBestCompress(const u_char *plain, u_char *enc, long size, CompressParms *parms, long *bestResult, CompressParms *bestParms);
#ifdef UNIX
PRIVATE int LZBGenerateHash(const u_char *dict, const long size, HashEnt hashTab[][256], StringList *stringList);
#else
PRIVATE int LZBGenerateHash(const u_char *dict, const long size, HashEnt *hashTab, StringList *stringList);
#endif
PRIVATE long LZBOutputData(CompressState *state, BitContext *ctxt, const u_char *plain, u_char *enc, long size);
PRIVATE long LZBFindBestMatch(register CompressState *state, register long offset, long *r_bestMatchPosn, long *r_bestMatchLength, int *r_bestMatchWhere);
PRIVATE INLINE int LZBMatchEncodingSize(register CompressState *state, int length, int matchWhere);
PRIVATE int LZBEncodeMatch(register CompressState *state, long curOffset, long matchOffset, long length, int matchWhere);
PRIVATE int LZBEncodeLiteral(register CompressState *state, long literal);
PRIVATE void LZBDumpState(CompressState *state);



//
// Compress the file with LZB, trying different encoding methods to find
// the best one.
//
// Things to try:
//	- adaptive only (3 combos)
//	  - try 9-bit, 12-bit, and 13-bit max window sizes
//	- static only (6 combos)
//	  - try 12-bit "common", 12-bit "special1", and 12-bit "special2"
//	  - try both 13-bit "common+special" arrangements
//	  - try 14-bit "all"
//	- adaptive and static together (6 * 3 = 18 combos)
//	- variable-length match widths vs fixed-length match widths
//
// It's probable that the best of the adaptive results combined with the best
// of the static resuls will yield the best results of the merged runs.  But,
// since we have all the time in the world, there's no reason not to do it
// the right way and be sure.
//
long
CompressLzb(const u_char *plain, u_char *enc, long size, u_long flags, BestData *bestBuf)
{
	CompressParms parms, bestParms;
	long bestResult = -1;
	const u_char *inBuf = NULL;
	register const u_char *scp;
	register u_char *dcp;
	register long i;

	// Sanity check.
	//
	if (sizeof(CompressParms) > kBestBufSize) {
		fprintf(stderr, "ERROR: LZB CompressParms too large (%ld - %d)\n",
			sizeof(CompressParms), kBestBufSize);
		return (-1);
	}

	adaptiveStringList = staticStringList = NULL;
	optimalPath = NULL;
	memset(&parms, 0, sizeof(CompressParms));
	memset(&bestParms, 0, sizeof(CompressParms));

	// We gain nothing by trying to compress 1 or 2 bytes, so just deal with
	// it here.  One less edge case to worry about.  This could be done
	// better, but it's not important for this application.
	//
	if (size < 2) {
		fprintf(stderr, "LZB: get serious\n");
		return (-1);
	}

	// We don't do RLE, so don't try.
	//
	if (flags & kMPuseRLE)
		return (-1);

	// If the caller wants remapping done, create a new buffer for the data
	// and remap it there.  Life gets very strange if we try to do it later.
	// It's also painful to try and emit a "kRestIsPlain", so just fully
	// barf if we can't do the remap.
	//
#ifndef LZSS_MODE
	if (flags & kMPremapText) {
		if ((dcp = (u_char *)malloc(size)) == NULL) {
			fprintf(stderr, "malloc(%ld) failed in CompressLzb\n", size);
			return (-1);
		}
		inBuf = dcp;
		for (i = size, scp = plain; i; i--) {
			if (*scp == kRestIsPlain) {		// urgh
				fprintf(stderr, "ERROR: Remap failed at %ld in LZB compress\n",
					size - i);
				bestResult = -1;
				goto cleanup;
			}
			if ((*dcp++ = BOX2LOWA(*scp++)) == 0xff) {
				fprintf(stderr, "ERROR: remap failed at %ld in LZB compress\n",
					size - i);
				bestResult = -1;
				goto cleanup;
			}
		}
		parms.firstHigh = -1;		// remap guarantees everything < 0x7f

	} else {
		// Since we're not remapping, there is a high probability that the
		// input will contain a high-ASCII character.  Find the first one.
		//
		inBuf = plain;

		parms.firstHigh = -1;
		for (i = size, scp = plain; i; i--)
			if (*scp++ >= 0x7f) {
				parms.firstHigh = size - i;
				break;
			}
	}
#else
	LDBUG(0, ("    ***** Using LZSS mode *****\n"));
	inBuf = plain;
	parms.firstHigh = 0;
#endif	/*LZSS_MODE*/


	// Initialize the hash tables, string lists, and optimal path table.
	// Don't know which of them we'll be needing yet, so just init them
	// all... doesn't take very long.
	//
	adaptiveStringList = (StringList *)malloc(size * sizeof(StringList));
	if (adaptiveStringList == NULL) {
		fprintf(stderr, "LZB malloc adaptiveStringList (%ld) failed\n",
			size * sizeof(StringList));
		bestResult = -1;
		goto cleanup;
	}
#ifndef UNIX
	adaptiveHashTab = (HashEnt *)malloc(sizeof(HashEnt) * 256L * 256L);
	if (adaptiveHashTab == NULL) {
		fprintf(stderr, "LZB malloc adaptiveHashTab (%ld) failed\n",
			sizeof(HashEnt) * 256L * 256L);
		bestResult = -1;
		goto cleanup;
	}
#endif
	LZBGenerateHash(plain, size, adaptiveHashTab, adaptiveStringList);

	staticStringList =
		(StringList *)malloc((long)kStaticDictSize * sizeof(StringList));
	if (staticStringList == NULL) {
		fprintf(stderr, "LZB malloc staticStringList (%ld) failed\n",
			kStaticDictSize * sizeof(StringList));
		bestResult = -1;
		goto cleanup;
	}
	//LZBGenerateHash(staticTextDict, kStaticDictSize, staticHashTab,
	//	staticStringList);
#ifndef UNIX
	staticHashTab = (HashEnt *)malloc(sizeof(HashEnt) * 256L * 256L);
	if (staticHashTab == NULL) {
		fprintf(stderr, "LZB malloc staticHashTab (%ld) failed\n",
			sizeof(HashEnt) * 256L * 256L);
		bestResult = -1;
		goto cleanup;
	}
#endif

	optimalPath = (OptimalPath *)malloc((size+1) * sizeof(OptimalPath));
	if (optimalPath == NULL) {
		fprintf(stderr, "LZB malloc optimalPath (%ld) failed\n",
			size * sizeof(OptimalPath));
		bestResult = -1;
		goto cleanup;
	}


	// If we get a match that encompasses the rest of the input, then the
	// size is the match encoding size plus whatever follows -- in this case,
	// nothing.  So we set the bitLength for the last+1 entry to be zero
	// to avoid having to special-case it later.
	//
	optimalPath[size].matchOffset = -1;
	optimalPath[size].matchLength = 0;
	optimalPath[size].matchWhere = 0;
	optimalPath[size].bitLength = 0;

#ifdef LZSS_MODE
	// This causes the compressor to do things in a particular way.
	//
	flags |= kMPmodeLZSS;
#endif

	// If one of the "mode" flags is set, we want to use that instead of
	// trying one method after another.
	//
	// (Don't forget that "parms" was wiped to zero above.)
	//
	if (flags & kMPmodeMask) {
		if (flags & kMPmodeCode) {
			parms.useAdaptive = 1;
			parms.adaptiveBits = 12;
		} else if (flags & kMPmodeGraphics) {
			parms.useAdaptive = 1;
			parms.adaptiveBits = 12;
		} else if (flags & kMPmodeXMail) {
			LZB_Abort();
		} else if (flags & kMPmodeNews) {
			parms.useAdaptive = 1;
			parms.adaptiveBits = 12;
			parms.useStatic = 1;
			parms.staticBits = 13;
			parms.staticStart = 0;
		} else if (flags & kMPmodeText) {
			parms.useAdaptive = 1;
			parms.adaptiveBits = 15;
		} else if (flags & kMPmodeLZSS) {
			parms.useAdaptive = 1;
			parms.adaptiveBits = 12;
		} else if (flags & kMPmodeDebug) {
			LZB_Abort();		// shouldn't get here!
		} else {
			fprintf(stderr, "LZB: unrecognized mode 0x%.8lx\n", flags);
			return (-1);
		}

		memcpy(bestBuf->bestData, &parms, sizeof(CompressParms));
	}

	if (bestBuf->bestFlag) {
		//
		// Compress it to order.
		//
		memcpy(&parms, bestBuf->bestData, sizeof(CompressParms));
		LZBBestCompress(inBuf, enc, size, &parms, &bestResult, &bestParms);

	} else {
		//
		// Figure out what works.
		//
		// If the "mode" mask is set, we don't have to try other stuff.
		//
		if (flags & kMPmodeMask) {
			LZBBestCompress(inBuf, enc, size, &parms, &bestResult, &bestParms);

		} else {
			// Adaptive modes.
			//
			if (flags & kMPuseAdaptiveDict) {
				parms.useAdaptive = 1;
				parms.useStatic = 0;

				// For files < 256 bytes, all max string offset values are
				// equivalent, because the bit length never reaches 9 bits.  We
				// prefer to store it as "12" because that allows us to avoid
				// storing the max bit length in the output, saving an entire
				// byte (oh goody).
				//
				if ((size > 256) && (flags & kMPvaryAdaptiveBitl)) {
					// try 12
					//
					if (size > 256) {
						parms.adaptiveBits = 12;
						LZBBestCompress(inBuf, enc, size, &parms, &bestResult,
							&bestParms);
					}
					// try 9
					//
					parms.adaptiveBits = 9;
					LZBBestCompress(inBuf, enc, size, &parms, &bestResult,
						&bestParms);
					// try 13
					//
					if (size > 4096) {
						parms.adaptiveBits = 13;
						LZBBestCompress(inBuf, enc, size, &parms, &bestResult,
							&bestParms);
					}
				} else {
					parms.adaptiveBits = 12;
					LZBBestCompress(inBuf, enc, size, &parms, &bestResult,
						&bestParms);
				}
			}

			// Static modes.
			//
			if (flags & kMPuseStaticDict) {
				parms.useStatic = 1;
				parms.useAdaptive = 0;
				parms.flatBits = 0;

				parms.staticBits = 12;
				parms.staticStart = 0;
				LZBBestCompress(inBuf, enc, size, &parms, &bestResult,
					&bestParms);
				if (flags & kMPtryFlatBits) {
					parms.flatBits = 3;
					LZBBestCompress(inBuf, enc, size, &parms, &bestResult,
						&bestParms);
				}
			}

			// Combined modes.
			//
			if (flags & kMPuseBothDict) {
				parms.useStatic = 1;
				parms.useAdaptive = 1;
				parms.adaptiveBits = 12;
				parms.staticBits = 12;
				parms.staticStart = 0;

				parms.flatBits = 0;
				LZBBestCompress(inBuf, enc, size, &parms, &bestResult,
					&bestParms);
				if (flags & kMPtryFlatBits) {
					parms.flatBits = 3;
					LZBBestCompress(inBuf, enc, size, &parms, &bestResult,
						&bestParms);
				}
			}
		}

		// Blabber.
		//
		if (verbose) {
			if (bestResult == -1)
				DBUG(("    *** no winner ***\n"));
			else
				DBUG(("    Winner: static=%s (%d[%d],%d)  adaptive=%s (%d)\n",
					bestParms.useStatic ? "YES" : "no",
					bestParms.staticBits, bestParms.flatBits,
					bestParms.staticStart * kStaticDictSect,
					bestParms.useAdaptive ? "YES" : "no",
					bestParms.adaptiveBits));
		}
		memcpy(bestBuf->bestData, &bestParms, sizeof(CompressParms));
	}

cleanup:
	// Clean up.
	//
	if (inBuf != plain && inBuf != NULL)
		free((void *)inBuf);
	if (adaptiveStringList != NULL)
		free((void *)adaptiveStringList);
	if (staticStringList != NULL)
		free((void *)staticStringList);
	if (optimalPath != NULL)
		free((void *)optimalPath);
#ifndef UNIX
	if (adaptiveHashTab != NULL)
		free((void *)adaptiveHashTab);
	if (staticHashTab != NULL)
		free((void *)staticHashTab);
#endif
	return (bestResult);
}


//
// Calls LZBCompress with the parameters specified, and updates bestResult
// and bestParms if the results from the current run are better than the
// best seen so far.
//
PRIVATE long
LZBBestCompress(const u_char *plain, u_char *enc, long size,
	CompressParms *parms, long *bestResult, CompressParms *bestParms)
{
	long result;

	// Be noisy.
	//
	if (verbose) {
		if (parms->useAdaptive && !parms->useStatic) {
			DBUG(("   ADAPTIVE - %d bit\n", parms->adaptiveBits));
		} else if (!parms->useAdaptive && parms->useStatic) {
			DBUG(("   STATIC - %d bit [%d] @%d\n", parms->staticBits,
				parms->flatBits, parms->staticStart * kStaticDictSect));
		} else if (parms->useAdaptive && parms->useStatic) {
			DBUG(("   COMBINED - %d bit adaptive, %d bit [%d] @%d static\n",
				parms->adaptiveBits, parms->staticBits, parms->flatBits,
				parms->staticStart * kStaticDictSect));
		} else {
			DBUG(("LZB: What the fuck?\n"));
		}
	}

	// Unlike the adaptive dictionary, the static dictionary can change
	// in size and location, so we have to redo the hash table and string
	// list every time.
	//
	if (parms->useStatic) {
		if ((parms->staticStart * kStaticDictSect) + (1 << parms->staticBits)
			> kStaticDictSize)
		{
			fprintf(stderr, "LZB: too many static bits\n");
			return (-1);
		}
		LZBGenerateHash(staticTextDict + parms->staticStart * kStaticDictSect,
			1 << parms->staticBits, staticHashTab, staticStringList);
	}

	// Just do it.
	//
	result = LZBCompress(plain, enc, size, parms);

	if ((result > 0) && ((*bestResult < 0) || (result < *bestResult))) {
		*bestResult = result;
		*bestParms = *parms;
	}

	return (0);
}


//
// Generate the hash and string list tables for a dictionary.
//
// Returns 0 on success, -1 on error.
//
#ifdef UNIX
PRIVATE int
LZBGenerateHash(const u_char *dict, const long size, HashEnt hashTab[][256],
	StringList *stringList)
#else
PRIVATE int
LZBGenerateHash(const u_char *dict, const long size, HashEnt *hashTab,
	StringList *stringList)
#endif
{
	register const u_char *cp;
	register long li;
	register HashEnt *he;

	LDBUG(1, ("    LZB generate dictionary 0x%.8lx %ld\n", (long)dict, size));

	// Empty the hash table.
	//
	memset(hashTab, -1, sizeof(HashEnt) * 256L * 256L);

	// As we walk forward through the dictionary, put the most recently
	// seen string into the hash table, and put the string at the head
	// of the linked list.
	//
	// The computation of max match length ought to be based on the
	// minimum match length at that point and kMaxMatchDelta.  Cheese
	// it by using the absolute minimum.
	//
	for (cp = dict, li = 0 ; li < size-1 ; cp++, li++) {
#ifdef UNIX
		he = &hashTab[*cp][*(cp+1)];
#else
		he = hashTab + (long)(*cp)*256L + (long)(*(cp+1));
#endif
		stringList[li].next = he->stringListHead;
		stringList[li].length =
			(kMinMatchLength + kMaxMatchDelta) <= (size - li) ?
			(kMinMatchLength + kMaxMatchDelta) : (size - li);
		LDBUG(3, ("      %-4ld hashTab[0x%.2x][0x%.2x] = %ld  (len %ld)\n",
			li, *cp, *(cp+1), he->stringListHead, stringList[li].length));
		he->stringListHead = li;
	}

#ifdef BAD_IDEA		// not very useful, matches falsely
	// The very last entry can't be hashed on two chars, so just stuff it
	// in by hand.
	//
	he = &hashTab[*cp][0];
	stringList[li].next = he->stringListHead;
	stringList[li].length = 1;
	LDBUG(0, ("      %-4d hashTab[0x%.2x][0x%.2x] = %ld  (len %d)\n",
		li, *cp, *(cp+1), he->stringListHead, stringList[li].length));
	he->stringListHead = li;
#else
	stringList[li].next = -1;
	stringList[li].length = 1;
#endif

	return (0);
}

//
// Do the actual compression.
//
PRIVATE long
LZBCompress(const u_char *plain, u_char *enc, long size, CompressParms *parms)
{
	CompressState state;
	BitContext ctxt;
	register long li;
	long matchPosn, matchLength;
	long charPath, matchPath;
	int matchWhere, bitLength;
	u_char byte1, byte2;

	if (!parms->useStatic && !parms->useAdaptive) {
		fprintf(stderr, "What're we supposed to do ya moron?\n");
		return (-1);
	}

	// Init output context.
	//
	// Maximum output size is 16 bits of offset and flags + 15 bits of
	// length (gamma encoded), so 31 bits.
	//
	InitBits32(&ctxt, enc, kMPoutputContext);

	// Set up state.
	//
	state.useStatic = parms->useStatic;
	state.useAdaptive = parms->useAdaptive;
	state.staticStart = parms->staticStart;
	state.staticBits = parms->staticBits;
	state.adaptiveBits = parms->adaptiveBits;

	state.maxOffset = 1 << state.adaptiveBits;
	state.maxStaticOffset = 1 << state.staticBits;
	state.flatBits = parms->flatBits;
	state.plain = plain;
	state.plainSize = size;
	state.firstHigh = parms->firstHigh;
	state.ctxt = &ctxt;
	if (state.firstHigh != -1)
		state.literalBits = 9;		// there's one out there, start high
	else
		state.literalBits = 8;		// no high-ASCII anywhere

	// Set the width of the adaptive pointer window.  Start with the adaptive
	// max, then scale it down to fit the amount of data we actually have.
	// The initial offset will be at (size-1), so use that.
	//
	if (state.useAdaptive) {
		state.pointerBits = state.adaptiveBits;
		while (size-1 < (1 << (state.pointerBits - 1)) +1)
			state.pointerBits--;
		state.nextDecr = (1 << (state.pointerBits - 1));
		state.minMatch = LZBGetMinMatch(state.pointerBits, state.literalBits);
		//state.maxMatch = state.minMatch + kMaxMatchDelta;
	} else {
		state.pointerBits = 0;
		state.minMatch = 2;
		state.nextDecr = -1;
		//state.maxMatch = 2 + kMaxMatchDelta;
	}

	if (debug >= 1)
		LZBDumpState(&state);

	// Output the LZB header.
	//
	byte2 = 0;
	byte1 = LZB_E_USE_ADAPTIVE(state.useAdaptive) |
			LZB_E_USE_STATIC(state.useStatic) |
			LZB_E_STATIC_START(state.staticStart) |
			LZB_E_NUM_STATIC(state.staticBits);
	if ((state.useAdaptive && state.adaptiveBits != 12) || state.flatBits) {
		byte1 |= LZB_E_MORE_STUFF(TRUE);
		OutputBits32(&ctxt, ((u_long)byte1) << 24, 8);

		byte2 = LZB_E_ADAPTIVE_MAX(state.adaptiveBits) |
				LZB_E_FLAT_BITS(state.flatBits);
		OutputBits32(&ctxt, ((u_long)byte2) << 24, 8);
	} else {
		OutputBits32(&ctxt, ((u_long)byte1) << 24, 8);
	}
	LDBUG(2, ("    byte1=0x%.2x, byte2=0x%.2x\n", byte1, byte2));

	//
	// Walk backward through the input file.  For each offset:
	//
	//	- Determine if there is a useful match (where "useful" means that
	//	  (#of characters matched) * (bits per character) +1 is longer than
	//	  the #of bits required to represent that match.
	//	- If match found, compute sum of the bits required for the match
	//	  and the bits required for the optimal encoding of everything
	//	  starting from the position past that match.  Compare that to the
	//	  #of bits required to represent the current char and everything
	//	  past the current char.  Use whichever is smallest.  (I don't think
	//	  it matters which we choose in the event of a tie.)
	//	- If no useful match found, just output the character.
	//

	// Do the first one by hand.  It could only be a 1-byte match, so it's
	// highly unlikely that we'd want to do it (or would save anything).
	// FindBestMatch doesn't work on this entry because of the hashing.
	//
	optimalPath[size-1].matchOffset = -1;
	optimalPath[size-1].matchLength = 0;
	optimalPath[size-1].bitLength = state.literalBits;
	if (state.firstHigh == size-1) {
		state.literalBits = 8;
			LDBUG(0, ("    literalBits early-downshifted to 8\n"));
	}

	// Main loop.
	//
	for (li = size-2; li >= 0; li--) {
		// Check for pointer width transition.
		//
		if ((li == state.nextDecr) && (state.pointerBits != 1)) {
			LDBUG(2, ("    Transition from %d to %d pointerBits\n",
				state.pointerBits, state.pointerBits - 1));
			state.pointerBits--;
			state.nextDecr = (1 << (state.pointerBits - 1));

			state.minMatch = LZBGetMinMatch(state.pointerBits, state.literalBits);
			//state.maxMatch = state.minMatch + kMaxMatchDelta;
		}
		LDBUG(2, ("    LOOP %5ld: pointerBits=%d\n", li, state.pointerBits));

		// Look for a match.
		//
		if ((bitLength = LZBFindBestMatch(&state, li, &matchPosn,
			&matchLength, &matchWhere)) < 0)
		{
			// No useful match found, so we just add a character.  Total
			// bit length from here is literalBits plus the #of bits in
			// the next position.
			//
			optimalPath[li].matchOffset = -1;
			optimalPath[li].matchLength = 0;
			optimalPath[li].matchWhere = 0;
			optimalPath[li].bitLength =
				optimalPath[li+1].bitLength + state.literalBits;

			LDBUG(2, ("      %4ld no match-->%d%s\n", li, state.literalBits,
				(li == state.firstHigh) ? " ***" : ""));

		} else {
			// Found a match, determine the shortest path.
			//
			charPath = optimalPath[li+1].bitLength + state.literalBits;
			LDBUG(2, ("      %4ld charPath= %2ld+%2d-->%ld\n", li,
				optimalPath[li+1].bitLength, state.literalBits,
				charPath));

			matchPath = bitLength + optimalPath[li+matchLength].bitLength;
			LDBUG(2, ("      %4ld matchPath=%2ld+%2d-->%ld\n", li,
				optimalPath[li+matchLength].bitLength, bitLength,
				matchPath));

			if (charPath < matchPath) {
				// Happy happy, be a char.
				//
				optimalPath[li].matchOffset = -1;
				optimalPath[li].matchLength = 0;
				optimalPath[li].matchWhere = 0;
				optimalPath[li].bitLength = charPath;
			} else {
				optimalPath[li].matchOffset = matchPosn;
				optimalPath[li].matchLength = matchLength;
				optimalPath[li].matchWhere = matchWhere;
				optimalPath[li].bitLength = matchPath;
			}
		}

		// Check for transition on literal size.
		//
		// We may want to scan the input more carefully, and use a bogus
		// match code as a toggle between 7-bit and 8-bit mode.
		//
		if (li == state.firstHigh) {
			// We've been running in "high ASCII" mode.  The current
			// char is the first offender, so after this one we can ride
			// in low ASCII mode.
			//
			if (state.literalBits != 9) {
				fprintf(stderr, "ERROR: assert wanted 9 bits, found %d\n",
					state.literalBits);
				LZB_Abort();
				return (-1);
			}
			state.literalBits = 8;
			LDBUG(0, ("    literalBits downshifted to 8\n"));
		}
	}
	LDBUG(0, ("    Size in bits is %ld\n", optimalPath[0].bitLength));

	// Generate the output.
	//
	return (LZBOutputData(&state, &ctxt, plain, enc, size));
}

//
// We now know the optimal parsing for the file, given the specified
// dictionaries and length restrictions.  Dump the output into the
// output buffer.
//
// This can be skipped if bestFlag==0 and we are convinced that our
// calculated file size is correct (it had better be!).
//
PRIVATE long
LZBOutputData(CompressState *state, BitContext *ctxt, const u_char *plain,
	u_char *enc, long size)
{
	long numLiterals, numMatches, numMatchedChars, longestMatch;	// stats
	long numStaticMatches, numStaticMatchedChars, longestStaticMatch;
	register long li;
#ifdef BEAN_COUNT
	long bits = 0, lastBits = 0, lastFullBits = optimalPath[0].bitLength;
#endif
	int growing, nextIncr=0;
#ifdef LZSS_MODE
	u_short lzssFlags;
	u_char lzssBuf[16], lzssMask;
	int matchBack, lzssBufCount;
	u_char *orig_enc = enc;
	int i;
#endif

	LDBUG(1, ("      OUTPUT:\n"));
	numLiterals = numMatches = numMatchedChars = longestMatch = 0;
	numStaticMatches = numStaticMatchedChars = longestStaticMatch = 0;

	// For the output, the bits count upward.
	//
	if (state->useAdaptive) {
		state->pointerBits = 1;
		nextIncr = 3;			// when we get here do pointerBits++
		growing = TRUE;
		state->minMatch = LZBGetMinMatch(state->pointerBits, state->literalBits);
		//state->maxMatch = state->minMatch + kMaxMatchDelta;
	} else
		growing = FALSE;

#ifdef LZSS_MODE
	lzssBufCount = 0;
	lzssFlags = 0;
	lzssMask = 1;
#endif

	state->literalBits = 8;
	li = 0;
	while (li < size) {
		// Check for pointer size transition.
		//
		while (growing && li >= nextIncr) {
			state->pointerBits++;
			nextIncr = (1 << state->pointerBits) + 1;
			LDBUG(2, ("    transition from %d to %d pointerBits\n",
				state->pointerBits-1, state->pointerBits));
			state->minMatch = LZBGetMinMatch(state->pointerBits,
				state->literalBits);
			//state->maxMatch = state->minMatch + kMaxMatchDelta;

			if (state->pointerBits == state->adaptiveBits) {
				growing = FALSE;
				break;
			}
		}
		LDBUG(2, ("LOOP %5ld  pointerBits=%d\n", li, state->pointerBits));

		// Check for literal size transition.  We can miss li == firstHigh
		// if it happens in a match (esp with static).
		//
		if ((state->firstHigh >= 0) && (li >= state->firstHigh) &&
			(state->literalBits == 8))
		{
			LZBEncodeLiteral(state, kRestIsPlain);
#ifdef BEAN_COUNT
			//bits += 8;		// not actually counted by "optimal" stuff
#endif
			LDBUG(0, ("    Found hi char at %ld, output kRestIsPlain (0x%.2x)\n",
				li, kRestIsPlain));
			state->literalBits = 9;

			// literalBits changed, update the minMatch setting.
			//
			state->minMatch = LZBGetMinMatch(state->pointerBits,
				state->literalBits);
			//state->maxMatch = state->minMatch + kMaxMatchDelta;
		}

		// Output something.
		//
		if (optimalPath[li].matchOffset == -1) {
			// Output literal.
			//
			LDBUG(2, ("      %4ld->literal 0x%.2x\n", li, plain[li]));
#ifdef LZSS_MODE
			lzssBuf[lzssBufCount++] = plain[li];
			lzssFlags |= lzssMask;
#else
			LZBEncodeLiteral(state, plain[li]);
#endif
			li++;
			numLiterals++;
#ifdef BEAN_COUNT
			bits += state->literalBits;
#endif

		} else {
			LDBUG(2, ("      %4ld->match (%ld,%d) (minMatch=%d)\n", li,
				optimalPath[li].matchOffset, optimalPath[li].matchLength,
				state->minMatch));
#ifdef BEAN_COUNT
			bits += LZBMatchEncodingSize(state,
				optimalPath[li].matchLength, optimalPath[li].matchWhere);
#endif
#ifdef LZSS_MODE
			matchBack = (li - optimalPath[li].matchOffset) -1;
			lzssBuf[lzssBufCount++] = matchBack & 0xff;
			lzssBuf[lzssBufCount++] =
				((matchBack >> 4) & 0xf0) |
				(optimalPath[li].matchLength - 3);
#else
			LZBEncodeMatch(state, li, optimalPath[li].matchOffset,
				optimalPath[li].matchLength, optimalPath[li].matchWhere);
#endif	/*LZSS_MODE*/
			if (!optimalPath[li].matchLength) {
				fprintf(stderr, "      ERROR: matchLength(%ld) == 0\n", li);
				abort();
			}
			if (optimalPath[li].matchWhere == kMatchAdaptive) {
				numMatches++;
				numMatchedChars += optimalPath[li].matchLength;
				if (optimalPath[li].matchLength > longestMatch)
					longestMatch = optimalPath[li].matchLength;
			} else {
				numStaticMatches++;
				numStaticMatchedChars += optimalPath[li].matchLength;
				if (optimalPath[li].matchLength > longestStaticMatch)
					longestStaticMatch = optimalPath[li].matchLength;
			}
			li += optimalPath[li].matchLength;
		}

#ifdef LZSS_MODE
		// If we've got 8 entries, output them.
		//
		if ((lzssMask <<= 1) == 0) {
			*enc++ = lzssFlags;
			for (i = 0; i < lzssBufCount; i++)
				*enc++ = lzssBuf[i];

			lzssBufCount = 0;
			lzssFlags = 0;
			lzssMask = 1;
		}
#endif
#ifdef BEAN_COUNT
		if ((bits - lastBits) != (lastFullBits - optimalPath[li].bitLength)) {
			DBUG(("Bad bits: %5ld %2ld / %2ld\n", li, bits - lastBits,
				lastFullBits - optimalPath[li].bitLength));
		}
		lastBits = bits;
		lastFullBits = optimalPath[li].bitLength;
#endif
	}

#ifdef LZSS_MODE
	*enc++ = lzssFlags;
	for (i = 0; i < lzssBufCount; i++)
		*enc++ = lzssBuf[i];
#else
	FlushBits32(ctxt);
	if (debug >= 0) {
#ifdef BEAN_COUNT
		LDBUG(0, ("    Computed bits at %ld\n", bits));
#endif
		LDBUG(0, ("    Size in bits (rounded & incl header) %ld\n",
			(long)(GetBitPointer(ctxt) - enc) * 8));
	}
#endif

	if (verbose) {
		if (numMatches != 0) {
			DBUG(("      Adaptive stats: literals=%ld, matches=%ld, matchedChars=%ld\n",
				numLiterals, numMatches, numMatchedChars));
			DBUG(("      Adaptive stats: longestMatch=%ld, avg=%.2f\n",
				longestMatch, (double)numMatchedChars / (double)numMatches));
		}
		if (numStaticMatches != 0) {
			DBUG(("      Static stats: matches=%ld, matchedChars=%ld\n",
				numStaticMatches, numStaticMatchedChars));
			DBUG(("      Static stats: longestMatch=%ld, avg=%.2f\n",
				longestStaticMatch,
				(double)numStaticMatchedChars / (double)numStaticMatches));
		}
	}

#ifdef LZSS_MODE
	return (enc - orig_enc);
#else
	return (GetBitPointer(ctxt) - enc);
#endif
}


#ifdef USE_GAMMA_LEN_TAB
// Optimization for LZBMatchEncodingSize.  Not sure this helps much on
// a Sparc 10; cache misses may be more expensive than the short iteration.
//
PRIVATE int gammaLenTab[257] = {
	0x0,0x1,0x3,0x3,0x5,0x5,0x5,0x5,0x7,0x7,0x7,0x7,0x7,0x7,0x7,0x7,
	0x9,0x9,0x9,0x9,0x9,0x9,0x9,0x9,0x9,0x9,0x9,0x9,0x9,0x9,0x9,0x9,
	0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,
	0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,0xb,
	0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,
	0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,
	0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,
	0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,0xd,
	0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,
	0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,
	0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,
	0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,
	0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,
	0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,
	0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,
	0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,0xf,
	0x11,
};
#endif

//
// Determine how many bits are needed to LZB encode a pointer, given
// the current pointer width, match length, and whether we're using
// the adaptive dictionary or the static one.
//
PRIVATE INLINE int
LZBMatchEncodingSize(register CompressState *state, int length,
	int matchWhere)
{
#ifndef USE_GAMMA_LEN_TAB
	register int len2;
#endif
	register int bitLength;


#ifdef LZSS_MODE
	return (1 + 12 + 4);
#endif

	// Compute the bit length of the match count encoding.
	//
	if (state->flatBits && (matchWhere == kMatchStatic)) {
		bitLength = state->flatBits;
	} else {
		// adjust for "p"
		//
		length -= state->minMatch - 1;

#ifdef USE_GAMMA_LEN_TAB
		bitLength = gammaLenTab[length];
#else
		for (bitLength = 1, len2 = length; len2 >>= 1; bitLength++)
			;
		bitLength = (bitLength << 1) - 1;		// gamma size = 2N-1
#endif
	}

	// Now add in the length of the offset and the flag bits.
	//
	if (matchWhere == kMatchAdaptive) {
		if (state->useStatic)	// combined requires 1 extra
			bitLength++;
		bitLength += state->pointerBits + 1;
		LDBUG(2, ("    Length estimate (%d) = %d\n", length, bitLength));
		return (bitLength);
	} else {
		if (state->useAdaptive)	// combined requires 1 extra
			bitLength++;
		bitLength += state->staticBits + 1;
		LDBUG(2, ("    Static estimate (%d) = %d\n", length, bitLength));
		return (bitLength);
	}
	/*NOTREACHED*/
}


//
// Find the best match for the string at the specified offset.  Uses
// the hash table to find the head of the list, then walks through it,
// ignoring entries that are too young or too old.  Don't call this for
// the last byte in the file.
//
// The "best" match is the one that makes the entire output from the
// current point on the shortest.  The actual #of bytes matched isn't
// what matters; the best possible match might force us to use less
// optimal matches down the road.
//
// Searches the adaptive and/or static dictionaries as needed.  matchWhere
// will have either kMatchStatic or kMatchAdaptive depending on where the
// match was found.
//
// If the size of several literals matches the length of a match encoding,
// this chooses the literals, because I think they will be faster to decode.
//
// Returns the match position and length through the parameters.  Return
// value is the length of the match in bits, or -1 if no useful match
// was found.
//
// This routine is THE bottleneck.  We can save some time by not following
// through on matches that are the EXACT same size as one we have already
// seen, because the encoding of the match is the same length, and we will
// end up in the same place when following the optimal path.  However, we
// can NOT ignore all matches that are merely shorter than the best one
// we've found; that would leave us with a more greedy algorithm.
//
PRIVATE long
LZBFindBestMatch(register CompressState *state, register long offset,
	long *r_bestMatchPosn, long *r_bestMatchLength, int *r_bestMatchWhere)
{
	register long earliestMatch, stroff;
	register const u_char *scp, *ccp;
	register int matchLength;
#ifndef SIMPLE_MATCHING
	register const u_char *strend;
	const u_char *strstart;
#endif
#ifdef MAX_CHAIN
	int chainLength;
#endif
	int maxLen, staticHigh, staticBestMatch;
	int bitLength,			// length of bits of encoded <offset,length>
		bestBitLength,		// bit length of best match (return value)
		bitsSaved;			// #of bits saved by this match over literal string
	int bestMatchLength,	// length in bytes of best match (returned)
		lastMatchLength,	// length in bytes of previously found match (opt)
		bestMatchWhere;		// where best match was found (adap/stat) (returned)
	long bestMatchPosn,		// offset of best match (returned)
		totalBitLength,		// size in bits of entire output if we accept match
		bestTotalBitLength;	// best total size seen so far

	*r_bestMatchPosn = *r_bestMatchLength = 0;
	*r_bestMatchWhere = 0;

	bestMatchLength = lastMatchLength = 0;
	bestBitLength = -1;
	bestMatchPosn = -1;
	bestTotalBitLength = 65536L*32767L;	// sloppy; oh well
	bestMatchWhere = kMatchAdaptive;

	// Do the adaptive search, if requested.
	//
	// There's no possible match at offset==0, because the dict is empty.
	//
	if (state->useAdaptive && offset) {
		earliestMatch = offset - state->maxOffset;

		// BRAIN DAMAGE: maxLen should be based on the value of p, but it
		// should be done by the routine that sets up adaptiveStringList.
		//
		// maxLen is the longest possible match we can get at the current
		// offset.  It's limited by either the maximum match length or the
		// proximity of the end of the file.
		//
		maxLen = adaptiveStringList[offset].length;
#ifdef LZSS_MODE
		if (maxLen > 18)
			maxLen = 18;
#endif
#ifdef MAX_CHAIN
		chainLength = 0;
#endif

		// stroff (string offset) is the offset of the match we're
		// investigating.
		//
		stroff = adaptiveStringList[offset].next;
		LDBUG(2, ("          For 0x%.2x0x%.2x, initial at %ld\n",
			*(state->plain+offset), *(state->plain+offset+1), stroff));

		// Search through the list of possible matches.
		//
		// The matches are in a singly-linked list, ordered from back to
		// front.  We automatically ignore anything that appears past the
		// current point, and as soon as we enounter anything too early
		// in the file we can stop looking.
		//
		for ( ; stroff != -1; stroff = adaptiveStringList[stroff].next) {
			if (stroff < earliestMatch) {
				// Everything after this will have already left the sliding
				// window, so no need to consider anything further.
				//
				LDBUG(3, ("          %ld Match at %ld too young/old\n",
					offset, stroff));
				break;
			}

			// Compare the strings.  Since they hashed to the same location,
			// we already know that the first two chars matched.
			//
			// (This prevents us from doing single-byte matches, which probably
			// aren't significant.)
			//

#ifdef SIMPLE_MATCHING
			// This is the straightforward way to do it.
			//
			ccp = state->plain + offset +2;	// string we're currently working on
			scp = state->plain + stroff +2;	// string to try
			matchLength = 2;
			for ( ; matchLength < maxLen; matchLength++) {
				if (*ccp++ != *scp++)
					break;
			}
			if (matchLength > maxLen)	// sanity check
				abort();
#else
			// This fancier and hopefully faster string comparison was
			// pulled out of gzip.  It can cause us to read up to 6 bytes
			// past the end of the input buffer.
			//
			// Experiments show that the effectiveness of this technique
			// vs the previous one varies greatly depending on the kind of
			// input and the compression parameters... and not always in
			// the way you might expect.  This may not be a win.
			//
			strstart = state->plain + offset;
			strend = strstart + maxLen;
			ccp = strstart +1;
			scp = state->plain + stroff +1;
			do {
			} while (
				*++ccp == *++scp && *++ccp == *++scp &&
				*++ccp == *++scp && *++ccp == *++scp &&
				*++ccp == *++scp && *++ccp == *++scp &&
				*++ccp == *++scp && *++ccp == *++scp &&
				ccp < strend);
			matchLength = ccp - strstart;
			if (matchLength > maxLen)
				matchLength = maxLen;
#endif

#ifdef MAX_CHAIN
			if (chainLength++ >= MAX_CHAIN) {
				LDBUG(2, ("    *** Breaking out of long chain ***\n"));
				break;
			}
#endif


			// Check for a run.
			//
			// To kluge around a pathological case, if we get a match at
			// offset-1 that matches on maxLen bytes, we know we've got a
			// single repeated byte.  Once we get in this state, so long as
			// current byte == previous byte, we know we'll have a match on
			// maxLen bytes, and therefore don't have to search further.
			//
			// Sounds like a lot of pain for a simple case, but this thing
			// takes FOREVER on long runs of repeated chars.  25 seconds
			// vs 0.14 seconds for 1000 zeros.
			//
			// Since it's a run of maxLen chars, the only other thing we
			// can hope to find is a run of less than maxLen chars that has
			// a better encoding.  This stuff may cost us a few bits, but it
			// should be worth it.
			//
			if ((matchLength == maxLen) && (stroff == offset-1)) {
				LDBUG(2, ("    Found run of 0x%.2x\n",
					*(state->plain + offset)));

				// Do all the things we normally would upon finding the
				// best match, then break out of the loop.  Sort of annoying
				// having all this stuff in two places, but hey, this is
				// a kluge, remember?
				//
				bitLength = LZBMatchEncodingSize(state, matchLength,
					kMatchAdaptive);
				bitsSaved = (matchLength * state->literalBits) - bitLength;
				if (offset + matchLength > state->plainSize) {
					DBUG(("HEY: offset+mL=%ld, pS=%ld\n",
						offset + matchLength, state->plainSize));
				}
				totalBitLength = bitLength +
					optimalPath[offset + matchLength].bitLength;

				matchLength = maxLen;
				bestBitLength = bitLength;
				bestMatchPosn = stroff;
				bestMatchLength = matchLength;
				bestTotalBitLength = totalBitLength;
				break;
			}

#ifdef LZSS_MODE
			if (matchLength < 3)
				continue;
			if (matchLength > 18)
				matchLength = 18;
#endif
			if (matchLength < state->minMatch)
				continue;

			// As mentioned in the comments at the start of this routine,
			// we can safely ignore matches that are the *exact* same length
			// as one we have already seen, because it will leave us with
			// identical results.
			//
			// We could compare the current match length against a tree of
			// boolean flags, but I suspect updating and scanning secondary
			// data structures will take just as long as comparing the bit
			// lengths again does.  So, I just settle for this simple
			// optimization.
			//
			// Note that we can NOT bail out upon finding a match of length
			// maxLen, because it's possible that a shorter match will
			// actually save us bits in the long run.
			//
			if ((matchLength == bestMatchLength || matchLength == lastMatchLength))
				continue;
			lastMatchLength = matchLength;

			// #of bits saved is the length of the string expressed as
			// literals minus the #of bits needed to express the match.
			// It's possible for this value to be negative if the match
			// is short, in which case we're better off sending literals.
			//
			// This relies on state->pointerBits.
			//
			bitLength = LZBMatchEncodingSize(state, matchLength,
				kMatchAdaptive);
			if (state->literalBits == 8)
				bitsSaved = (matchLength << 3) - bitLength;
			else
				bitsSaved = (matchLength << 3) + matchLength - bitLength;
#ifdef BEAN_COUNT
			// not really bean-counting, just a defensive measure.
			if (bitsSaved != (matchLength * state->literalBits) - bitLength)
				abort();
#endif
			if (bitsSaved > 0) {
				// The match will save bits, but is it the best?
				//
				if (offset + matchLength > state->plainSize) {
					DBUG(("HEY: offset+mL=%ld, pS=%ld\n",
						offset + matchLength, state->plainSize));
				}
				totalBitLength = bitLength +
					optimalPath[offset + matchLength].bitLength;
				LDBUG(2, ("          --%ld matched %2d at %-4ld [%5ld bits]\n",
					offset, matchLength, stroff, totalBitLength));
				if (totalBitLength < bestTotalBitLength) {
					bestBitLength = bitLength;
					bestMatchPosn = stroff;
					bestMatchLength = matchLength;
					bestTotalBitLength = totalBitLength;
				}
			}
		}
	}


	// Search the static dictionaries, if requested.
	//
	// LZSS_MODE shouldn't be here.
	// MAX_CHAIN shouldn't apply if the dictionary is built correctly.
	// Neither should runs in the input.
	//
	// Don't update any of the bestBlahBlah variables unless it really is
	// better than the best adaptive match found.
	//
	if (state->useStatic) {
		lastMatchLength = 0;		// reset
		staticBestMatch = 0;

		// Set the value of maxLen.  There are three things that can make
		// maxLen be less than the largest possible:
		//	- being too close to the end of the input
		//	- being too close to the end of the static dictionary
		//	- being limited by flatBits.
		//
		maxLen = adaptiveStringList[offset].length;		// set by input
		if (state->flatBits) {
			if (maxLen >= (1 << state->flatBits) + state->minMatch)
				maxLen = (1 << state->flatBits) + state->minMatch -1;
		}

		// This is where the end of the static dict is.
		//
		staticHigh = (state->staticStart * kStaticDictSect) +
			state->maxStaticOffset;

		// stroff (string offset) is the offset of the match we're
		// investigating.
		//
#ifdef UNIX
		stroff = staticHashTab[*(state->plain+offset)][*(state->plain+offset+1)].stringListHead;
#else
		stroff = (  staticHashTab + (*(state->plain+offset))*256 +
					(*(state->plain+offset+1))
				 )->stringListHead;
#endif
		LDBUG(2, ("          For 0x%.2x0x%.2x, static at %ld max %d\n",
			*(state->plain+offset), *(state->plain+offset+1), stroff,
			maxLen));

		// Search through the list of possible matches.
		//
		for ( ; stroff != -1; stroff = staticStringList[stroff].next) {
			// Adjust maxLen if we're too close to the end of the static
			// dict.
			//
			if (stroff + maxLen > staticHigh)
				maxLen = staticHigh - stroff;

			// Compare the strings.  Since they hashed to the same location,
			// we already know that the first two chars matched.
			//
			// (This prevents us from doing single-byte matches, which probably
			// aren't significant.)
			//
#ifdef SIMPLE_MATCHING
			// This is the straightforward way to do it.
			//
			ccp = state->plain + offset +2;		// string in input
			scp = staticTextDict + stroff +2;	// string to try in dict
			matchLength = 2;
			for ( ; matchLength < maxLen; matchLength++) {
				if (*ccp++ != *scp++)
					break;
			}
			if (matchLength > maxLen)	// sanity check
				abort();
#else
			// This is the fancy way.
			//
			strstart = state->plain + offset;
			strend = strstart + maxLen;
			ccp = strstart +1;
			scp = staticTextDict + stroff +1;
			do {
			} while (
				*++ccp == *++scp && *++ccp == *++scp &&
				*++ccp == *++scp && *++ccp == *++scp &&
				*++ccp == *++scp && *++ccp == *++scp &&
				*++ccp == *++scp && *++ccp == *++scp &&
				ccp < strend);
			matchLength = ccp - strstart;
			if (matchLength > maxLen)
				matchLength = maxLen;
#endif

			if (matchLength < state->minMatch)
				continue;

			// Don't want to check against bestMatchLength, because that
			// could've been set back in the adaptive stuff.
			//
			if ((matchLength == staticBestMatch) || (matchLength == lastMatchLength))
				continue;
			lastMatchLength = matchLength;

			// #of bits saved is the length of the string expressed as
			// literals minus the #of bits needed to express the match.
			// It's possible for this value to be negative if the match
			// is short, in which case we're better off sending literals.
			//
			bitLength = LZBMatchEncodingSize(state, matchLength,
				kMatchStatic);
			if (state->literalBits == 8)
				bitsSaved = (matchLength << 3) - bitLength;
			else
				bitsSaved = (matchLength << 3) + matchLength - bitLength;
#ifdef BEAN_COUNT
			// not really bean-counting, just a defensive measure.
			if (bitsSaved != (matchLength * state->literalBits) - bitLength)
				abort();
#endif
			if (bitsSaved > 0) {
				// The match will save bits, but is it the best?
				//
				if (offset + matchLength > state->plainSize) {
					DBUG(("HEY: offset+mL=%ld, pS=%ld\n",
						offset + matchLength, state->plainSize));
				}
				totalBitLength = bitLength +
					optimalPath[offset + matchLength].bitLength;
				LDBUG(2, ("          --%ld matched %2d at %-4ld [%5ld bits]\n",
					offset, matchLength, stroff, totalBitLength));
				if (totalBitLength < bestTotalBitLength) {
					bestBitLength = bitLength;
					bestMatchPosn = stroff;
					staticBestMatch = bestMatchLength = matchLength;
					bestTotalBitLength = totalBitLength;
					bestMatchWhere = kMatchStatic;
				}
			}
		}
	}

	// If we found an acceptable match, set stuff up and bail.
	//
	if (bestMatchLength > 0) {
		LDBUG(2, ("          Best match at %ld is %ld/%d\n", offset,
			bestMatchPosn, bestMatchLength));
	} else {
		LDBUG(2, ("          (no useful match found at %ld)\n", offset));
	}

	// Return the length (in bits) of the match we found, for computing
	// the optimal size.  This will be -1 if no useful match was found.
	//
	*r_bestMatchPosn = bestMatchPosn;
	*r_bestMatchLength = bestMatchLength;
	*r_bestMatchWhere = bestMatchWhere;
	return (bestBitLength);
}

//
// Send an <offset,length> pair to the output.  The size of the offset
// depends on whether this was in the adaptive or static dictionaries, and
// (if adaptive) what offset we're currently at; max is 14 bits for the
// 12/16K static dict.  The size of the pointer depends on the match
// length; it can range from 1 to 17 bits.  Overall length is between 2
// and 31 bits.
//
// If we're in a "combined" mode where both adaptive and static matches
// are possible, we output an additional flag bit to discriminate between
// the two.
//
PRIVATE int
LZBEncodeMatch(register CompressState *state, long curOffset, long matchOffset,
	register long length, int matchWhere)
{
	register u_long out = 0L;		// 0 in 1st bit means match
	register long matchBack;
	register int index = sizeof(u_long)*8 -1;
	register int bitLength;

	if (matchWhere == kMatchAdaptive) {
		if (state->useStatic)		// in a "combined" mode?
			index--;				// 0 in 2nd bit means use adaptive

		matchBack = (curOffset - matchOffset) -1;

		index -= state->pointerBits;
		out |= matchBack << index;

		// Adjust for the value of "p".
		//
		length -= state->minMatch - 1;

#ifdef USE_GAMMA_LEN_TAB
		bitLength = gammaLenTab[length];
		index -= bitLength;				// that gives us bitLength-1 0s
#else
		for (bitLength = 1, len2 = length; len2 >>= 1; bitLength++)
			;
		index -= (bitLength << 1) - 1;	// that gives us bitLength-1 0s
#endif
		out |= length << index;			// and bitLength bits of length

		//length += state->minMatch - 1;	// for display only
		//printf("MATCH %d,%d [%d]\n", matchBack, length, 32 - index);
		OutputBits32(state->ctxt, out, sizeof(u_long)*8 - index);

	} else {
		if (state->useAdaptive) {
			out |= 0x40000000L;		// 1 in 2nd bit means use static
			index--;
		}
		index -= state->staticBits;
		out |= matchOffset << index;

		if (state->flatBits) {
#ifdef BEAN_COUNT
			if (length - state->minMatch >= (1 << state->flatBits))
			{
				fprintf(stderr, "LZB: match too large for flat (%ld in %d)\n",
					length, state->flatBits);
				LZB_Abort();
			}
#endif
			index -= state->flatBits;
			out |= (length - state->minMatch) << index;
		} else {
			// Adjust for the value of "p".
			//
			length -= state->minMatch - 1;

#ifdef USE_GAMMA_LEN_TAB
			bitLength = gammaLenTab[length];
			index -= bitLength;				// that gives us bitLength-1 0s
#else
			for (bitLength = 1, len2 = length; len2 >>= 1; bitLength++)
				;
			index -= (bitLength << 1) - 1;	// that gives us bitLength-1 0s
#endif
			out |= length << index;			// and bitLength bits of length
		}

		//length += state->minMatch - 1;	// for display only
		//printf("STATIC %d,%d [%d]\n", matchOffset, length, 32 - index);
		OutputBits32(state->ctxt, out, sizeof(u_long)*8 - index);
	}

	return (0);
}

//
// Send a literal char to the output.  Size will be 8 or 9 bits.
//
PRIVATE int
LZBEncodeLiteral(register CompressState *state, long literal)
{
	register u_long out = 0x80000000L;	// 1 in 1st bit means literal

	// Sanity check.
	//
	if (state->literalBits != 8 && state->literalBits != 9) {
		fprintf(stderr, "ERROR: invalid literalBits (%d)\n",
			state->literalBits);
		LZB_Abort();
	}
	if ((literal & 0x80) && state->literalBits != 9) {
		fprintf(stderr, "ERROR: hi output with literalBits != 9 (0x%.2lx)\n",
			literal);
		LZB_Abort();
	}
	//printf("LITERAL 0x%.2x [%d]\n", literal, state->literalBits);

	if (state->literalBits == 8) {
		// 7 bits of literal, 1 bit of flag
		out |= literal << 24;
		OutputBits32(state->ctxt, out, 8);
	} else {
		// 8 bits of literal, 1 bit of flag
		out |= literal << 23;
		OutputBits32(state->ctxt, out, 9);
	}

	return (0);
}


//
// Dump the contents of the CompressState struct.
//
PRIVATE void
LZBDumpState(CompressState *state)
{
	DBUG(("    --LZB compressor state:\n"));
	DBUG(("      useStatic=%s (%d[%d],%d)  useAdaptive=%s (%d)\n",
		state->useStatic ? "YES" : "no", state->staticBits, state->flatBits,
		state->staticStart * kStaticDictSect,
		state->useAdaptive ? "YES" : "no", state->adaptiveBits));
	DBUG(("      plainSize=%ld  maxOffset=%d  literalBits=%d\n",
		state->plainSize, state->maxOffset, state->literalBits));
	DBUG(("      pointerBits=%d  nextDecr=%d  firstHigh=%ld\n",
		state->pointerBits, state->nextDecr, state->firstHigh));
}
#endif	/*!BOX_ONLY*/


// ===========================================================================
//		Expansion
// ===========================================================================

//
// Decode LZB-encoded data.
//
long
ExpandLzb(const u_char *enc, u_char *plain, long encSize, long plainSize, u_long flags)
{
#ifdef LZSS_MODE
# define THRESHOLD	2
	register int i, j, k;
	u_int lzflags;
	u_char *out_start = plain;

	DBUG(("    ***** Using LZSS mode *****\n"));
	lzflags = 0;
	while (plain - out_start < plainSize) {
		if (((lzflags >>= 1) & 256) == 0) {
			lzflags = (*enc++) | 0xff00;      /* uses higher byte cleverly */
		}                                  /* to count eight */
		if (lzflags & 1) {
			// single character
			*plain++ = *enc++;
		} else {
			// matched a full string
			i = *enc++;
			j = *enc++;
			i |= ((j & 0xf0) << 4);  
			j = (j & 0x0f) + THRESHOLD;
			for (k = 0; k <= j; k++) {
				*plain = *(plain - (i+1));
				plain++;
			}
		}
	}

	if (plain - out_start != plainSize) {
		fprintf(stderr, "ERROR, expected %d, got %d\n", plainSize,
			plain - out_start);
	}

	return (plain - out_start);


#else	/*LZSS_MODE*/
	BitContext ctxt;
	register u_short work;
	register u_char *srcp, *dstp;
	register int i, bitLength;
	int useBoth, useStatic, useAdaptive;
	int literalBits, staticBits, pointerBits, nextIncr, maxAdaptiveBits;
	int staticStart, flatBits;
	int growing, minMatch;

	// Initialize input.
	//
	InitBits16(&ctxt, enc, kMPinputContext);

	// Decode header
	//
	work = InputBits16(&ctxt, 8) >> 8;
	useStatic = LZB_D_USE_STATIC(work);
	useAdaptive = LZB_D_USE_ADAPTIVE(work);
	useBoth = (useStatic && useAdaptive) != 0;
	staticBits = LZB_D_NUM_STATIC(work);
	staticStart = LZB_D_STATIC_START(work);

	if (!useStatic && !useAdaptive) {
		fprintf(stderr, "LZB: !useStatic and !useAdaptive (0x%.4x)\n", work);
		return (-1);
	}

	if (LZB_D_MORE_STUFF(work)) {
		work = InputBits16(&ctxt, 8) >> 8;
		maxAdaptiveBits = LZB_D_ADAPTIVE_MAX(work);
		flatBits = LZB_D_FLAT_BITS(work);
	} else {
		maxAdaptiveBits = 12;
		flatBits = 0;
	}

	if (useBoth && (maxAdaptiveBits >= 15 || staticBits >= 15)) {
		fprintf(stderr, "LZB: choke! gasp! wheeze!\n");
		return (-1);
	}

	LDBUG(0, ("    useStatic=%d (%d[%d]/%d)  useAdaptive=%d (%d)\n",
		useStatic, staticBits, flatBits, staticStart,
		useAdaptive, maxAdaptiveBits));

	literalBits = 7;		// start out in 7-bit ASCII mode
	pointerBits = 1;		// (initial is actually zero with nextIncr=1)
	nextIncr = 3;			// when we get here do pointerBits++
	growing = TRUE;			// true while pointerBits is expanding
	minMatch = LZBGetMinMatch(pointerBits, literalBits+1);

	// Off we go!
	//
	dstp = plain;
	while (dstp < plain + plainSize) {
		while (growing && dstp - plain >= nextIncr) {
			pointerBits++;
			nextIncr = (1 << pointerBits) + 1;
			LDBUG(2, ("    transition from %d to %d pointerBits\n",
				pointerBits-1, pointerBits));
			minMatch = LZBGetMinMatch(pointerBits, literalBits+1);

			if (pointerBits == maxAdaptiveBits) {
				growing = FALSE;
				break;
			}
		}
		LDBUG(2, ("    LOOP %5d: pointerBits=%d nextIncr=%d literalBits=%d\n",
			dstp - plain, pointerBits, nextIncr, literalBits));

		// Max of 2 control bits, and 14 offset bits or 8 literal bits.
		// We're limited to 9 bits from Peek, and someday this'll be running
		// on a 16-bit machine, so just grab the first part.
		//
		work = PeekBits16(&ctxt, 2);
		if (work & 0x8000) {
			// Literal found.
			//
			work = InputBits16(&ctxt, literalBits + 1);
			work = (work & 0x7fff) >> (16 - (literalBits+1));
			LDBUG(2, ("    Literal 0x%.2x\n", work));
			if (literalBits == 7 && work == kRestIsPlain) {
				LDBUG(0, ("    Found kRestIsPlain token (0x%.2x)\n", work));
				literalBits = 8;
				continue;
			}
			*dstp++ = work;
		} else {
			// Match found.  Figure out where the start of the matched string
			// is.
			//
			if (useBoth) {
				if (work & 0x4000) {
					work = InputBits16(&ctxt, staticBits + 2);
					work = (work & 0x3fff) >> (14 - staticBits);
					goto is_static;
				} else {
					work = InputBits16(&ctxt, pointerBits + 2);
					work >>= 14 - pointerBits;
					goto is_adaptive;
				}
			} else if (useAdaptive) {
				work = InputBits16(&ctxt, pointerBits + 1);
				work >>= (15 - pointerBits);
is_adaptive:
				srcp = dstp - (work + 1);
				if (srcp - plain < 0) {
					fprintf(stderr, "ERROR: invalid starting posn %d\n",
						srcp - plain);
					DBUG(("srcp=0x%.8lx, dstp=0x%.8lx, plain=0x%.8lx, work=%d\n",
						(long)srcp, (long)dstp, (long)plain, work));
					LZB_Abort();
				}
				LDBUG(2, ("    AMatch at %ld ", (long)(srcp - plain)));
			} else if (useStatic) {
				work = InputBits16(&ctxt, staticBits + 1);
				work >>= (15 - staticBits);
is_static:
				srcp = staticTextDict + work;
				LDBUG(2, ("    SMatch at %d ", work));
				if (flatBits) {
					work = InputBits16(&ctxt, flatBits);
					work = (work >> (16 - flatBits)) + minMatch;
					goto have_width;
				}
			} else {
				fprintf(stderr, "LZB: say what?\n");
				LZB_Abort();
			}

			// Now we have a pointer to the start of the string.  Pull out
			// the match length by reversing the gamma encoding.
			//
			//work = (InputBits16(&ctxt, 4) >> 12) + 3;
			work = PeekBits16(&ctxt, 8);
			if (!work) {
				fprintf(stderr, "LZB: !work\n");
				LZB_Abort();
			}
			for (bitLength = 1; !(work & 0x8000); bitLength++, work <<= 1)
				if (bitLength > 8) {
					fprintf(stderr, "LZB: bitLength overflow!\n");
					LZB_Abort();
				}

			// Do it like this on an '816 (except the above "for" loop would
			// be integrated in too).
			//
			switch (bitLength) {
			case 1:
				// only one possible case
				(void) InputBits16(&ctxt, 1);
				work = 1;
				break;
			case 2:
				work = InputBits16(&ctxt, 3) >> 13;
				break;
			case 3:
				work = InputBits16(&ctxt, 5) >> 11;
				break;
			case 4:
				work = InputBits16(&ctxt, 7) >> 9;
				break;
			case 5:
				work = InputBits16(&ctxt, 9) >> 7;
				break;
			case 6:
				work = InputBits16(&ctxt, 11) >> 5;
				break;
			case 7:
				work = InputBits16(&ctxt, 13) >> 3;
				break;
			case 8:
				work = InputBits16(&ctxt, 15) >> 1;
				break;
			//case 9:
			//	// only one possible case
			//	(void) InputBits16(&ctxt, 16);
			//	(void) InputBits16(&ctxt, 1);
			//	work = 256;
			//	break;
			}

			work += minMatch - 1;

have_width:
			LDBUG(2, ("of %d (minMatch=%d)\n", work, minMatch));
			while (work--) {
				*dstp++ = *srcp++;
			}
		}
	}
	if (dstp - plain != plainSize) {
		fprintf(stderr, "ERROR, expected %ld, got %ld\n", plainSize,
			(long)(dstp - plain));
		return (dstp - plain);
	}

	// If the remap flag was set, go through and remap it all in place.
	//
	if (flags & kMPremapText) {
		for (i = 0, dstp = plain; i < plainSize; i++, dstp++)
			*dstp = LOWA2BOX(*dstp);
	}

	return (dstp - plain);
#endif	/*LZSS_MODE*/
}


// ===========================================================================
//		General subroutines
// ===========================================================================

//
// Get the minimum match size, based on the current value of the pointer
// width and the number of bits needed to represent a literal.
//
// Uses the  floor( (3+k)/l ) +1  formula from Bell/Cleary/Witten
//
PRIVATE int
LZBGetMinMatch(int pointerBits, int literalBits)
{
	int minMatch;

	minMatch = ((3 + pointerBits) / literalBits) +1;
	if (minMatch < kMinMatchLength)
		minMatch = kMinMatchLength;

	LDBUG(2, ("    minMatch (%d,%d) = %d\n", pointerBits, literalBits,
		minMatch));

	return (minMatch);
}

