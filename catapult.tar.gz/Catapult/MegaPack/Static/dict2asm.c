/*
 * Convert the LZB dictionary to ORCA output.
 */
#include <stdio.h>

#ifdef FUBAR
# define SIZE	(4096*2)
  unsigned char staticTextDict[];
#else
# define SIZE	(256)
  int lowa2box[];
#endif

main()
{
	int i;

#ifdef FUBAR
	for (i = 0; i < SIZE; i++) {
		if (i && !(i%16))
			printf("'\n");
		if (!(i%16))
			printf("           dc    H'");
		printf("%.2x", staticTextDict[i]);
	}
	printf("'\n\n");
#else
	for (i = 0; i < SIZE; i++) {
		if (i && !(i%8))
			printf("'\n");
		if (!(i%8))
			printf("           dc    I2'");
		printf("$%.4x", (unsigned short)lowa2box[i]);
		if ((i+1)%8)
			printf(",");
	}
	printf("'\n\n");
#endif

	exit(0);
	/*NOTREACHED*/
}

