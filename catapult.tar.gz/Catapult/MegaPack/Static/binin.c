#define DEBUG1
//#define DEBUG2
/*
 * bin.c - generate symbol list to feed to dictionary
 *
 * This makes few attempts to be efficient in terms of memory or CPU usage.
 *
 * This is all rather disgusting.
 */
#include <stdio.h>
#include <sys/types.h>

#define kMaxByteCombo	16
#define kMinByteCombo	2
#define kMatchThreshold	1

#ifndef TRUE
# define TRUE	1
# define FALSE	0
#endif

typedef struct Posn {
	u_char	interesting;
	int		startFound;
	long	maxCount;
	long	matchCount[kMaxByteCombo];
} Posn;

//
// Prototypes.
//
long MarkBytesThatFit(u_char *buf, Posn *posnList, int size, int cutoff, int high, int low);


//
// Print usage.
//
void
Usage(char *argv0)
{
	fprintf(stderr, "Usage: %s file\n", argv0);
}

//
// Fast version of memcmp().  We want it inline since it's going to be called
// a lot, and we don't need some fancy stuff (like whole-word comparisons)
// because the ranges are always short.
//
// Doesn't correctly handle n==0.
//
inline int
Memcmp(register char *s1, register char *s2, register int n)
{
	do {
	} while ((*s1++ == *s2++) && n--);

	return (*(s1-1) - *(s2-1));
}

//
// Generate a list of the most frequently appearing phrases found in the
// input buffer.  The input buffer may be mangled.
//
// Returns a pointer to the Posn array, which must be freed by the caller.
//
Posn *
GenerateWordList(u_char *buf, long size /*, int dictSize*/)
{
	long matchCount;
	register Posn *posnList, *srcpp, *trgpp;
	register int i, j, start, nval;

	if ((posnList = (Posn *)malloc(sizeof(Posn) * (size+1))) == NULL) {
		perror("posn malloc");
		return (NULL);
	}
	memset(posnList, 0, sizeof(Posn) * (size+1));
	posnList[size].interesting = 3;		// hack so it'll stop without crashing

	// Analyze the byte patterns.
	//
	for (nval = kMaxByteCombo; nval >= kMinByteCombo; nval--) {
#ifdef DEBUG2
		printf("nval=%d\n", nval);
#else
		fprintf(stderr, "nval=%d\n", nval);
#endif
		srcpp = posnList;
		for (start = 0; start <= size - (nval<<1); start++, srcpp++) {
#ifdef DEBUG2
			printf("  cmpsrc=%d\n", start);
#else
			if (!(start & 0xff))
				fprintf(stderr, "  cmpsrc=%d\r", start);
#endif
			if (srcpp->startFound == nval) {
#ifdef DEBUG2
				printf("    (already done for this N)\n");
#endif
				continue;
			}
			trgpp = posnList + start + nval;
			matchCount = 0;
			for (i = start + nval; i <= size - nval; i++, trgpp++) {
#ifdef DEBUG2
				printf("    cmptrg=%d\n", i);
#endif

				if (trgpp->startFound == nval) {
#ifdef DEBUG2
					printf("      (already done for this N)\n");
#endif
					continue;
				}

				if (Memcmp(buf+start, buf+i, nval) == 0) {
					// Match was found!  Mark the startFound field so we
					// don't use this entry as a starting point or as
					// something to compare against later on.
					//
#ifdef DEBUG2
					printf("      -->match at %d\n", i);
#endif
					trgpp->startFound = nval;

					// Advance past end of match, but back off one so that
					// the loop incr doesn't skip over any.
					//
					i += (nval-1);
					trgpp += (nval-1);
					matchCount++;
				}
			}

			// If we exceeded the threshold of matches needed for this
			// value of N, set the "count" field in every word of the
			// source
			//
			if (matchCount >= kMatchThreshold) {
#ifdef DEBUG2
				printf("    total=%d, keeper\n", matchCount);
#endif
				for (i = 0; i < nval; i++) {
					if (srcpp[i].matchCount[nval-1] < matchCount) {
						srcpp[i].matchCount[nval-1] = matchCount;
						srcpp[i].interesting = 1;
					}
				}
			}
		}
	}

#ifdef DEBUG3
	// Dump the word list, with counts.
	//
	printf("\nCOMPLETE WORD LIST\n");
	for (i = 0; i < wordCount; i++)
		printf("%5d\t(0x%.8lx) \"%s\"\n", i, posnList[i].count, posnList[i].str);
#endif

#ifdef DEBUG1
	// Dump the complete word list for count != 0.
	//
	//printf("\nNONZERO WORD LIST\n");
	printf("PARAM %d %d %d\n", kMaxByteCombo, kMinByteCombo, kMatchThreshold);
	for (i = 0; i < size; i++) {
		if (!posnList[i].interesting)
			continue;
		printf("0x%.2x\t", buf[i]);
		for (j = kMaxByteCombo-1; j >= kMinByteCombo-1; j--)
			printf("%3d ", posnList[i].matchCount[j]);
		printf("\n");
	}
#endif

	return (posnList);
}


//
// Select the best mix of patterns from the posnList and form them into
// a dictionary.
//
int
GenerateDict(u_char *buf, Posn *posnList, int fileSize, int dictSize)
{
	int i;

	if (posnList == NULL) {
		fprintf(stderr, "Say what?\n");
		return (-1);
	}

	if (fileSize < dictSize) {
		for (i = 0; i < fileSize; i++)
			posnList[i].interesting |= 2;
		OutputDict(buf, posnList, fileSize);

		return (0);
	}

	// Okay, get fancy.
	//
	// Want do devote:
	//
	//	- 3% of dictionary to sets of 13-16 bytes
	//	- 5% of dictionary to sets of 9-12 bytes
	//	- 25% of dictionary to sets of 5-8 bytes
	//	- 57% of dictionary to sets of 3 or 4 bytes
	//	- 10% of dictionary to sets of 2 bytes
	//
	{
		int cutoff, high, low;
		int totalcut;
		long res;
		
		totalcut = dictSize;

		cutoff = (int) ((float) dictSize * 0.03);
		high = 16 - kMinByteCombo +1;
		low = 13 - kMinByteCombo +1;
		res = MarkBytesThatFit(buf, posnList, fileSize, cutoff, high, low);
		totalcut -= res;

		cutoff = (int) ((float) dictSize * 0.05);
		high = 12 - kMinByteCombo +1;
		low = 9 - kMinByteCombo +1;
		res = MarkBytesThatFit(buf, posnList, fileSize, cutoff, high, low);
		totalcut -= res;

		cutoff = (int) ((float) dictSize * 0.25);
		high = 8 - kMinByteCombo +1;
		low = 5 - kMinByteCombo +1;
		res = MarkBytesThatFit(buf, posnList, fileSize, cutoff, high, low);
		totalcut -= res;

		cutoff = (int) ((float) dictSize * 0.57);
		high = 4 - kMinByteCombo +1;
		low = 3 - kMinByteCombo +1;
		res = MarkBytesThatFit(buf, posnList, fileSize, cutoff, high, low);
		totalcut -= res;

		//cutoff = (int) ((float) dictSize * 0.10);
		cutoff = totalcut;		// whatever's left
		high = 2 - kMinByteCombo +1;
		low = 2 - kMinByteCombo +1;
		res = MarkBytesThatFit(buf, posnList, fileSize, cutoff, high, low);
	}

	OutputDict(buf, posnList, dictSize);

	return (0);
}


//
// Mark all the bytes that fall between "high" and "low" and fit inside
// "cutoff", based on their frequency in those ranges.  Previously marked
// bytes aren't used.
//
long
MarkBytesThatFit(u_char *buf, Posn *posnList, int size, int cutoff, int high, int low)
{
	int i, j, max, highCount;
	int initialCutoff = cutoff;
	long totalChars;

	highCount = 0;
	totalChars = 0;

	// Make a first pass through to determine the highest count in the
	// specified range.  Also, count up the total #of bytes in the range
	// that haven't already been marked, to see if we really need to be
	// doing anything.
	//
	for (i = 0; i < size; i++) {
		max = 0;
		for (j = low; j <= high; j++) {
			if (posnList[i].matchCount[j] > max)
				max = posnList[i].matchCount[j];
		}
		posnList[i].maxCount = max;
		if (max > highCount)
			highCount = max;
		if (max) {
			if (!(posnList[i].interesting & 2)) {
				totalChars++;
				//printf("added %d (%d) %d\n", i, posnList[i].len, totalChars);
			}
		}
	}

	printf("  For %d/%d (%d), highCount=%d, totalChars=%d\n",
		low, high, cutoff, highCount, totalChars);

	if (totalChars < cutoff) {
		// Don't have enough, so just mark all the words that qualify.
		//
		printf("    (keeping all bytes)\n");
		for (i = 0; i < size; i++) {
			if (!(posnList[i].interesting & 2) && posnList[i].maxCount) {
				posnList[i].interesting |= 2;
				cutoff--;
				//printf("marked %d\n", i);
			}
		}

		printf("   Returning=%d\n", initialCutoff - cutoff);
		return (initialCutoff - cutoff);
	}

	// Starting from highCount, count downward.  Not the fastest way to
	// do it, but we're not in a race.  Mark each entry and then subtract
	// its size from the total we have allocated for this section.
	//
	while (highCount && (cutoff > 0)) {
		for (i = 0; (i < size) && (cutoff > 0); i++) {
			if (!(posnList[i].interesting & 2) && (posnList[i].maxCount >= highCount))
			{
				posnList[i].interesting |= 2;
				cutoff--;
				//printf("Marked %d\n", i);
			}
		}
		highCount--;
	}

	printf("   Returning=%d\n", initialCutoff - cutoff);
	return (initialCutoff - cutoff);
}


//
// Create a dictionary, filling it with byte that are marked with "2" in
// the "interesting" field.
//
// Assumes that there are enough interesting bytes to fill the dictionary.
//
int
OutputDict(u_char *buf, Posn *posnList, int dictSize)
{
	Posn *pp;
	u_char *cp;
	int i, blah;

	printf("\nunsigned char dict[%d] = {", dictSize);

	// Find the first interesting one.
	//
	for (pp = posnList, cp = buf; !(pp->interesting & 2); pp++, cp++)
		;

#ifdef DEBUG1
	//printf("posnList = 0x%.8lx, pp = 0x%.8lx\n", posnList, pp);
#endif

	for (i = 0; i < dictSize; i++) {
		if (!(i % 12)) printf("\n\t");
		printf("0x%.2x,", *cp);

		do {
			pp++;
			cp++;
		} while (!(pp->interesting & 2));
	}
	printf("\n};\n");

	return (0);
}


//
// Do stuff.
//
int
DoStuff(char *filename)
{
	FILE *fp;
	Posn *posnList;
	long size;
	u_char *fileBuf;

	fprintf(stderr, "--- %s\n", filename);

	if ((fp = fopen(filename, "r")) == NULL) {
		perror("fopen");
		return (-1);
	}
	fseek(fp, 0L, 2);
	size = ftell(fp);
	rewind(fp);

	if (size <= 0) {
		fprintf(stderr, "ERROR: file size is %d\n", size);
		fclose(fp);
		return (-1);
	}

	if ((fileBuf = (char *)malloc(size)) == NULL) {
		perror("malloc");
		fclose(fp);
		return (-1);
	}

	if (fread(fileBuf, size, 1, fp) != 1) {
		perror("fread");
		fclose(fp);
		free(fileBuf);
		return (-1);
	}

	fclose(fp);
	posnList = GenerateWordList(fileBuf, size /*, 8192*/);
	if (posnList != NULL)
		GenerateDict(fileBuf, posnList, size, 4096);

	free(fileBuf);

	return (0);
}


//
// Parse args, whatever.
//
int
main(int argc, char *argv[])
{
	extern char *optarg;
	extern int optind;
	int c, errflg, result;

	errflg = 0;
	while ((c = getopt(argc, argv, "b")) != EOF) {
		switch (c) {
		case 'b':
			abort();		// ha ha!
			break;
		default:
			errflg++;
			break;
		}
	}

	if (errflg) {
		Usage(argv[0]);
		exit(2);
	}

	// For each file specified, do stuff
	//
	if (optind >= argc) {
		fprintf(stderr, "Error: no files to thrash\n");
	} else {
		result = 0;
		for (; optind < argc; optind++) {
			DoStuff(argv[optind]);
		}
	}

	exit(0);
	/*NOTREACHED*/
}

