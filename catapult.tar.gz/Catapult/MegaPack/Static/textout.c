/*
 * textout.c - convert word list to binary dictionary
 *
 * This is all rather disgusting.
 */
#include <stdio.h>
#include <sys/types.h>

#ifndef TRUE
# define TRUE	1
# define FALSE	0
#endif

#define kHugeMatchCount	16

typedef struct Word {
	u_char	*str;
	int		len;			// strlen + 1
	u_long	count;
	long	matchCount[16];
	int		mark;
	int		maxCount;
} Word;

#define kCountMax	0x0UL
#define kCountGuess	0x0000000fUL

extern int box2lowa[];


//
// Prototypes
//
Word *LoadWordList(char *filename, long *wordCount_r, long *maxWordCombo_r);
long GetCharCount(Word *wordList, long wordCount, u_long count);
int CreateDict(u_long count, Word *wordList, long wordCount, int dictSize, int binflg);


//
// Print usage.
//
void
Usage(char *argv0)
{
	fprintf(stderr, "Usage: %s word-file\n", argv0);
}

//
// Do stuff.
//
int
DoStuff(char *filename, int dictSize, int binflg)
{
	Word *wordList;
	long wordCount, charCount, maxWordCombo;
	int i, res;

	if ((wordList = LoadWordList(filename, &wordCount, &maxWordCombo)) == NULL)
		return (-1);

	charCount = GetCharCount(wordList, wordCount, kCountMax);
	printf("total charCount = %ld\n", charCount);

	// See if we need to do anything.
	//
	if (charCount < dictSize) {
		for (i = 0; i < wordCount; i++)
			wordList[i].mark = 1;
		CreateDict(kCountMax, wordList, wordCount, charCount, binflg);
		return (0);
	}

	// Okay, get fancy.
	//
	// Want do devote:
	//
	//	- 25% of dictionary to sets of 8/7/6/5 words
	//	- 30% of dictionary to sets of 4/3 words
	//	- 35% of dictionary to sets of 2 words
	//	- 10% of dictionary to sets of 1 words
	//
	{
		int cutoff, high, low;
		int totalcut;
		
		totalcut = dictSize;

#define MODE4
#ifdef MODE1
		cutoff = (int) ((float) dictSize * 0.25);
		high = 7;
		low = 4;
		res = MarkWordsThatFit(wordList, wordCount, cutoff, high, low);
		totalcut -= res;

		cutoff = (int) ((float) dictSize * 0.30);
		high = 6;
		low = 2;
		res = MarkWordsThatFit(wordList, wordCount, cutoff, high, low);
		totalcut -= res;

		cutoff = (int) ((float) dictSize * 0.35);
		high = 1;
		low = 1;
		res = MarkWordsThatFit(wordList, wordCount, cutoff, high, low);
		totalcut -= res;

		//cutoff = (int) ((float) dictSize * 0.10);
		cutoff = totalcut;		// whatever's left
		high = 0;
		low = 0;
		res = MarkWordsThatFit(wordList, wordCount, cutoff, high, low);
#endif
#ifdef MODE2
		//cutoff = (int) ((float) dictSize * 1.0);
		cutoff = totalcut;		// all
		high = 7;
		low = 0;
		res = MarkWordsThatFit(wordList, wordCount, cutoff, high, low);
#endif
#ifdef MODE3
		cutoff = (int) ((float) dictSize * 0.20);
		high = 7;
		low = 4;
		res = MarkWordsThatFit(wordList, wordCount, cutoff, high, low);
		totalcut -= res;

		cutoff = (int) ((float) dictSize * 0.30);
		high = 3;
		low = 2;
		res = MarkWordsThatFit(wordList, wordCount, cutoff, high, low);
		totalcut -= res;

		//cutoff = (int) ((float) dictSize * 0.50);
		cutoff = totalcut;		// whatever's left
		high = 1;
		low = 0;
		res = MarkWordsThatFit(wordList, wordCount, cutoff, high, low);
#endif
#ifdef MODE4
		//cutoff = (int) ((float) dictSize * 1.0);
		cutoff = totalcut;		// all
		high = 1;
		low = 0;
		res = MarkWordsThatFit(wordList, wordCount, cutoff, high, low);
#endif
	}

#if defined(MODE1) || defined(MODE2) || defined(MODE3) || defined(MODE4)
	CreateDict(kCountMax, wordList, wordCount, dictSize, binflg);
#else
	error "Yo hoser"
#endif

	return (0);
}

//
// Sum up the lengths of the words whose count value is greater than or
// equal to "count".
//
long
GetCharCount(Word *wordList, long wordCount, u_long count)
{
	Word *wp;
	long len;

	len = 0;
	for (wp = wordList; wordCount > 0; wordCount--, wp++) {
		if (wp->count >= count)
			len += wp->len;		// add in strlen +1
	}

	return (len);
}


//
// Starting with the most frequently appearing words, mark words in the
// input until we've consumed "cutoff" bytes.
//
// All items in the range are considered equivalent.
//
int
MarkWordsThatFit(Word *wordList, long wordCount, int cutoff, int high, int low)
{
	int i, j, max, highCount;
	int initialCutoff = cutoff;
	long totalChars;

	highCount = 0;
	totalChars = 0;

	// Make a first pass through to determine the highest count in the
	// specified range.  Also, count up the total #of bytes in the range
	// that haven't already been marked, to see if we really need to be
	// doing anything.
	//
	for (i = 0; i < wordCount; i++) {
		max = 0;
		for (j = low; j <= high; j++) {
			if (wordList[i].matchCount[j] > max)
				max = wordList[i].matchCount[j];
		}
		wordList[i].maxCount = max;
		if (max > highCount)
			highCount = max;
		if (max) {
			if (!wordList[i].mark) {
				totalChars += wordList[i].len;
				//printf("added %d (%d) %d\n", i, wordList[i].len, totalChars);
			}
		}
	}

	printf("  For %d/%d (%d), highCount=%d, totalChars=%d\n",
		low, high, cutoff, highCount, totalChars);

	if (totalChars < cutoff) {
		// Don't have enough, so just mark all the words that qualify.
		//
		printf("    (keeping all words)\n");
		for (i = 0; i < wordCount; i++) {
			if (!wordList[i].mark && wordList[i].maxCount) {
				wordList[i].mark = 1;
				cutoff -= wordList[i].len;
			}
		}

		printf("   Returning=%d\n", initialCutoff - cutoff);
		return (initialCutoff - cutoff);
	}

	// Starting from highCount, count downward.  Not the fastest way to
	// do it, but we're not in a race.  Mark each entry and then subtract
	// its size from the total we have allocated for this section.
	//
	while (highCount && (cutoff > 0)) {
		for (i = 0; (i < wordCount) && (cutoff > 0); i++) {
			if (!wordList[i].mark && (wordList[i].maxCount >= highCount)) {
				wordList[i].mark = 1;
				cutoff -= wordList[i].len;
				//printf("Marked %d\n", i);
			}
		}
		highCount--;
	}

	printf("   Returning=%d\n", initialCutoff - cutoff);
	return (initialCutoff - cutoff);
}


//
// Load the word list into a Word array.
//
// Allocates some stuff that won't get freed.  Oh well.
//
Word *
LoadWordList(char *filename, long *wordCount_r, long *maxWordCombo_r)
{
	FILE *fp;
	Word *wordList;
	char *cp, wordBuf[256], buf[512];
	long fileSize, wordCount;
	u_long count;
	int i, matchCount[8], maxWordCombo, foo;

	if ((fp = fopen(filename, "r")) == NULL) {
		perror("fopen");
		return (NULL);
	}
	fseek(fp, 0L, 2);
	fileSize = ftell(fp);
	rewind(fp);

	if (fileSize <= 0) {
		fprintf(stderr, "ERROR: bad file size\n");
		fclose(fp);
		return (NULL);
	}

	// Allocate a monstrous buffer to hold the strings.
	//
	if ((cp = (char *)malloc(fileSize)) == NULL) {
		perror("malloc cp");
		return (NULL);
	}

	// Allocate another monstrous buffer to hold the Words.
	//
	//if ((wordList = (Word *)malloc(sizeof(Word) * (fileSize/2))) == NULL) {
	if ((wordList = (Word *)malloc(sizeof(Word) * (110000))) == NULL) {
		perror("malloc wordList");
		return (NULL);
	}
	//memset(wordList, 0, sizeof(Word) * (fileSize/2));
	memset(wordList, 0, sizeof(Word) * (110000));

	fgets(buf, 512, fp);
	sscanf(buf, "PARAM %d %d", &maxWordCombo, &foo);
	printf("maxWordCombo is %d (%d)\n", maxWordCombo, foo);
	if (maxWordCombo != 8) {
		fprintf(stderr, "AIIIIIEEEEEE!!!\n");
		abort();
	}

	wordCount = 0;
	while (1) {
		//fscanf(fp, "0x%x %s", &count, wordBuf);
		fgets(buf, 512, fp);
		if (feof(fp) || ferror(fp))
			break;
		sscanf(buf, "0x%x %d %d %d %d %d %d %d %d %s", &count,
			&matchCount[7], &matchCount[6], &matchCount[5], &matchCount[4],
			&matchCount[3], &matchCount[2], &matchCount[1], &matchCount[0],
			wordBuf);

		strcpy(cp, wordBuf);
		wordList[wordCount].count = count;
		wordList[wordCount].matchCount[0] = matchCount[0];
		wordList[wordCount].matchCount[1] = matchCount[1];
		wordList[wordCount].matchCount[2] = matchCount[2];
		wordList[wordCount].matchCount[3] = matchCount[3];
		wordList[wordCount].matchCount[4] = matchCount[4];
		wordList[wordCount].matchCount[5] = matchCount[5];
		wordList[wordCount].matchCount[6] = matchCount[6];
		wordList[wordCount].matchCount[7] = matchCount[7];
		wordList[wordCount].str = cp;
		wordList[wordCount].len = strlen(wordBuf) +1;

		cp += wordList[wordCount].len;
		wordCount++;
	}

	fclose(fp);

#ifdef DEBUG2
	for (i = 0; i < wordCount; i++) {
		printf("%5d\t(0x%.8lx) %3d \"%s\"\n", i, wordList[i].count,
			wordList[i].matchCount[0], wordList[i].str);
	}
#endif

	*wordCount_r = wordCount;
	*maxWordCombo_r = maxWordCombo;
	return (wordList);
}


//
// Create a dictionary, filling it with words that are >= "count" and have
// "mark" set.  Stops when the dictionary is filled.
//
// Assumes that there are enough characters in the words to fill the
// dictionary.
//
int
CreateDict(u_long count, Word *wordList, long wordCount, int dictSize, int binflg)
{
	Word *wp;
	u_char *cp;
	int i, len, blah;

#ifdef DEBUG4
	for (i = 0; i < wordCount; i++)
		if (wordList[i].mark) {
			//printf("%5d %s\n", i, wordList[i].str);
		} else {
			printf("%5d %s\n", i, wordList[i].str);
		}

	return (0);
#endif

	printf("\nunsigned char dict[%d] = {", dictSize);
	len = 0;
	wp = wordList -1;
	for (i = 0; i < dictSize; i++) {
		if (!(i % 12)) printf("\n\t");
		if (!len) {
			// Grab the next word.
			//
			do {
				wp++;
				wordCount--;
			} while ((wp->count < count) || (!wp->mark));
			if (wordCount < 0) {
				// can't happen?
				//
				fprintf(stderr, "ERROR: out of words (i=%d), bailing\n", i);
				abort();
			}

			len = wp->len -1;
			cp = wp->str;
			printf("0x%.2x,", ' ');
		} else {
			if (box2lowa[*cp] != -1)
				printf("0x%.2x,", box2lowa[*cp++]);
			else {
				fprintf(stderr, "Found unmappable char 0x%.2x\n", *cp);
				printf("0x%.2x,", *cp++);
			}
			len--;
		}
	}
	printf("\n};\n");

	return (0);
}


//
// Parse args, whatever.
//
int
main(int argc, char *argv[])
{
	extern char *optarg;
	extern int optind;
	int c, errflg, result;
	int binflg = FALSE;

	errflg = 0;
	while ((c = getopt(argc, argv, "b")) != EOF) {
		switch (c) {
		case 'b':
			binflg = TRUE;
			break;
		default:
			errflg++;
			break;
		}
	}

	if (errflg) {
		Usage(argv[0]);
		exit(2);
	}

	// For each file specified, compress
	//
	if (optind >= argc) {
		fprintf(stderr, "Error: no files to thrash\n");
	} else {
		result = 0;
		for (; optind < argc; optind++) {
			DoStuff(argv[optind], 8192, binflg);
		}
	}

	exit(0);
	/*NOTREACHED*/
}

