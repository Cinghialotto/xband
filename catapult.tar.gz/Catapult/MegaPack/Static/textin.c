//#define DEBUG2
/*
 * textin.c - generate word list to feed to dictionary
 *
 * This makes few attempts to be efficient in terms of memory or CPU usage.
 *
 * This is all rather disgusting.
 */
#include <stdio.h>
#include <sys/types.h>

#define kMaxWordCombo	8
#define kMatchThreshold	1

#ifndef TRUE
# define TRUE	1
# define FALSE	0
#endif

typedef struct Word {
	u_char	*str;
	u_long	hash;		// minor optimization
	int		startFound;
	u_long	count;
	long	matchCount[kMaxWordCombo];
} Word;

//
// Print usage.
//
void
Usage(char *argv0)
{
	fprintf(stderr, "Usage: %s file\n", argv0);
}

Word * LexifyBuffer(u_char *buf, long size, long *wordCount_r);

//
// Generate a list of the most frequently appearing phrases found in the
// input buffer.  The input buffer will be mangled.
//
// General plan:
//
//	- For some number N, start with the first N words in the dictionary.
//	 - Scan through the entire dictionary, starting just past the current
//	   word.
//	 - When a copy is found, skip past the entire copy; don't just move
//	   forward one word.  Otherwise "foo foo foo foo foo foo foo" will show
//	   up as 4 occurrences of a 4-word pattern instead of one.  Mark the
//	   startFound field of the first word with N.
//	 - If some frequency threshold is reached (this has to be hand-tweaked),
//	   mark the count field of each of the N words with (1 << N).
//	- Move forward one word, and repeat the search with the next N words.
//	  if the first word's startFound field is marked with N, then we know
//	  we've already found an N-word match starting with this word, so we
//	  don't need to consider it further.
//
// Once we've tagged all the words, we want to keep a few more of them than
// are necessary to bring the total up to dictSize words.  Keep the ones with
// the highest values in the "count" field; the cutoff will have to be
// determined by something like a binary search.  (Alternatively, some kind
// of sort could be done using a parallel data structure.)
//
// When the minimum count is determined, the words are output in the order
// that they appear in the source file, so that groups of words that normally
// appear together will be together in the dictionary.
//
int
GenerateWordList(u_char *buf, long size /*, int dictSize*/)
{
	Word *wordList, *srcwp, *trgwp;
	long wordCount, matchCount;
	int i, j, start, nval;

	if ((wordList = LexifyBuffer(buf, size, &wordCount)) == NULL)
		return (-1);

	// Analyze the word list.
	//
	for (nval = kMaxWordCombo; nval > 0; nval--) {
#ifdef DEBUG2
		printf("nval=%d\n", nval);
#else
		fprintf(stderr, "nval=%d\n", nval);
#endif
		srcwp = wordList;
		for (start = 0; start <= wordCount - nval*2; start++, srcwp++) {
#ifdef DEBUG2
			printf("  cmpsrc=%d\n", start);
#else
			if (!(start & 0xff))
				fprintf(stderr, "  cmpsrc=%d\r", start);
#endif
			if (srcwp->startFound == nval) {
#ifdef DEBUG2
				printf("    (already done for this N)\n");
#endif
				continue;
			}
			trgwp = &wordList[start + nval];
			matchCount = 0;
			for (i = start + nval; i <= wordCount - nval; i++, trgwp++) {
#ifdef DEBUG2
				printf("    cmptrg=%d\n", i);
#endif

				if (trgwp->startFound == nval) {
#ifdef DEBUG2
					printf("      (already done for this N)\n");
#endif
					continue;
				}

				for (j = 0; j < nval; j++) {

#ifdef DEBUG2
					if ( ((*(srcwp+j)).hash != (*(trgwp+j)).hash) &&
						 (strcmp((*(srcwp+j)).str, (*(trgwp+j)).str) == 0) )
					{
						printf("Hash failure 0x%.8lx 0x%.8lx '%s' '%s'\n",
							(*(srcwp+j)).hash, (*(trgwp+j)).hash,
							(*(srcwp+j)).str,  (*(trgwp+j)).str );
						abort();
					}
#endif


					if ( ((*(srcwp+j)).hash == (*(trgwp+j)).hash) &&
						 (strcmp((*(srcwp+j)).str, (*(trgwp+j)).str) == 0) )
					{
						// so far so good
					} else {
#ifdef DEBUG2
						printf("      mismatch at %d\n", j);
#endif
						break;
					}
				}

				if (j == nval) {
					// Match was found!  Mark the startFound field so we
					// don't use this entry as a starting point or as
					// something to compare against later on.
					//
#ifdef DEBUG2
					printf("      -->match at %d\n", i);
#endif
					trgwp->startFound = nval;

					// Advance past end of match, but back off one so that
					// the loop incr doesn't skip over any.
					//
					i += (nval-1);
					trgwp += (nval-1);
					matchCount++;
				}
			}

			// If we exceeded the threshold of matches needed for this
			// value of N, set the "count" field in every word of the
			// source
			//
			if (matchCount >= kMatchThreshold) {
#ifdef DEBUG2
				printf("    total=%d, keeper\n", matchCount);
#endif
				for (i = 0; i < nval; i++) {
					srcwp[i].count |= 1 << (nval-1);
					if (srcwp[i].matchCount[nval-1] < matchCount)
						srcwp[i].matchCount[nval-1] = matchCount;
				}
			}
		}
	}

#ifdef DEBUG2
	// Dump the word list, with counts.
	//
	printf("\nCOMPLETE WORD LIST\n");
	for (i = 0; i < wordCount; i++)
		printf("%5d\t(0x%.8lx) \"%s\"\n", i, wordList[i].count, wordList[i].str);
#endif

	// Dump the complete word list for count != 0.
	//
	//printf("\nNONZERO WORD LIST\n");
	printf("PARAM %d %d\n", kMaxWordCombo, kMatchThreshold);
	for (i = 0; i < wordCount; i++) {
		if (wordList[i].count) {
			printf("0x%.8lx\t", wordList[i].count);
			for (j = kMaxWordCombo-1; j >= 0; j--)
				printf("%4d ", wordList[i].matchCount[j]);
			printf("\t%s\n", wordList[i].str);
		}
	}

	free(wordList);
	return (0);
}


// enum for LexifyBuffer
//
enum { ST_LOOKFORWORD, ST_INWORD };

//
// Break the input buffer down into words.  Mangles its input buffer.
//
// A "word" begins with an alpha char, is composed of alphanumeric
// chars, and ends on almost anything else (whitespace, punctuation).
// Exceptions are single quotes, dashes, ampersands, greater-than,
// underscore, and periods followed by another alphanumeric char.
//
// Returns a pointer to the word list, which has been allocated with malloc()
// and must be freed by the caller.
//
Word *
LexifyBuffer(u_char *buf, long size, long *wordCount_r)
{
	Word *wordList, *wp;
	long wordCount;
	u_char *cp;
	int i, state, len;
	u_long hash;

	// Create a ridiculous number of Words so we don't have to worry about it.
	//
	wordList = (Word *)malloc(sizeof(Word) * (size/2));
	if (wordList == NULL) {
		perror("GenerateWordList malloc");
		return (NULL);
	}
	memset(wordList, 0, sizeof(Word) * (size/2));
	wordCount = 0;

	state = ST_LOOKFORWORD;
	for (cp = buf, wp = wordList; cp < (buf+size); cp++) {
		switch (state) {
		case ST_LOOKFORWORD:
			if (isalpha(*cp)) {
				state = ST_INWORD;
				wp->str = cp;
			}
			break;
		case ST_INWORD:
			if (isalnum(*cp) || (*cp >= 128))
				break;

			switch (*cp) {
			case '\'':
			case '-':
			case '_':
			case '&':
			case '>':
			case '<':
				break;
			case '.':
				if (isalnum(*(cp+1)))
					break;
			default:
				len = cp - wp->str;
				wp->hash = len << 8;
				while (len--) {
					wp->hash <<= 2;
					wp->hash ^= *(wp->str+len);
				}
				wp++;
				wordCount++;
				*cp = '\0';
				state = ST_LOOKFORWORD;
			}

			break;
		default:
			fprintf(stderr, "bad state\n");
			abort();
			break;
		}
	}
	if (state == ST_INWORD) {
		len = cp - wp->str;
		wp->hash = len << 8;
		while (len--) {
			wp->hash <<= 4;
			wp->hash ^= *(cp+len);
		}
		wordCount++;
	}

#ifdef DEBUG2
	for (i = 0; i < wordCount; i++) {
		printf("%5d\t(0x%.8lx) \"%s\"\n", i, wordList[i].hash, wordList[i].str);
	}
#endif

	*wordCount_r = wordCount;
	return (wordList);
}


//
// Do stuff.
//
int
DoStuff(char *filename)
{
	FILE *fp;
	long size;
	u_char *fileBuf;

	fprintf(stderr, "--- %s\n", filename);

	if ((fp = fopen(filename, "r")) == NULL) {
		perror("fopen");
		return (-1);
	}
	fseek(fp, 0L, 2);
	size = ftell(fp);
	rewind(fp);

	if (size <= 0) {
		fprintf(stderr, "ERROR: file size is %d\n", size);
		fclose(fp);
		return (-1);
	}

	if ((fileBuf = (char *)malloc(size)) == NULL) {
		perror("malloc");
		fclose(fp);
		return (-1);
	}

	if (fread(fileBuf, size, 1, fp) != 1) {
		perror("fread");
		fclose(fp);
		free(fileBuf);
		return (-1);
	}

	fclose(fp);
	GenerateWordList(fileBuf, size /*, 8192*/);

	free(fileBuf);

	return (0);
}


//
// Parse args, whatever.
//
int
main(int argc, char *argv[])
{
	extern char *optarg;
	extern int optind;
	int c, errflg, result;

	errflg = 0;
	while ((c = getopt(argc, argv, "b")) != EOF) {
		switch (c) {
		case 'b':
			abort();		// ha ha!
			break;
		default:
			errflg++;
			break;
		}
	}

	if (errflg) {
		Usage(argv[0]);
		exit(2);
	}

	// For each file specified, compress
	//
	if (optind >= argc) {
		fprintf(stderr, "Error: no files to thrash\n");
	} else {
		result = 0;
		for (; optind < argc; optind++) {
			DoStuff(argv[optind]);
		}
	}

	exit(0);
	/*NOTREACHED*/
}

