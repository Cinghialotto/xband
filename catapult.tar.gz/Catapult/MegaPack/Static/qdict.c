/*
 * qdict.c - quick dictionary generation
 *
 * Takes the first 4K of a file and converts it into C source.
 */
#include <stdio.h>
#include <sys/types.h>

#define DICTSIZE	4096

u_char buf1[DICTSIZE];

void
Usage(char *argv0)
{
	fprintf(stderr, "Usage: %s filename\n", argv0);
}

int
LoadFile(FILE *fp, u_char buf[])
{
	if (fread(buf, DICTSIZE, 1, fp) != 1) {
		perror("fread");
		return (-1);
	}
	return (0);
}

int
DumpFile(u_char buf[])
{
	int i;

	printf("\nu_char dict[%d] = {", DICTSIZE);

	for (i = 0; i < DICTSIZE; i++) {
		if (!(i % 12)) printf("\n\t");
		printf("0x%.2x,", buf1[i]);
	}
	printf("\n};\n");

	return (0);
}

int
main(int argc, char *argv[])
{
	FILE *fp;

	if (argc != 2) {
		Usage(argv[0]);
		exit(2);
	}

	if ((fp = fopen(argv[1], "r")) == NULL) {
		perror("fopen");
		exit(1);
	}
	if (LoadFile(fp, buf1) < 0)
		exit(1);
	fclose(fp);

	DumpFile(buf1);

	exit(0);
	/*NOTREACHED*/
}

