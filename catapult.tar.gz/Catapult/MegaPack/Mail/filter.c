/*
 * filter.c - screen out un-mappable chars
 *
 * The player info sometimes has a few garbage characters at the end.
 */
#include <stdio.h>

extern int box2lowa[], lowa2box[];

void
Usage(char *argv0)
{
	fprintf(stderr, "Usage: %s < infile > outfile\n");
}

int
main()
{
	int c;

	while ((c = getc(stdin)) != EOF)
		if (box2lowa[c] != -1)
			putc(c, stdout);

	exit (0);
	/*NOTREACHED*/
}

