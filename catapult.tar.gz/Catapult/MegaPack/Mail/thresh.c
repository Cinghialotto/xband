/*
 * thresh.c
 *
 * Separates the wheat (stuff in mixed-case) from the chaff (stuff only
 * in upper case).
 */
#include <stdio.h>
#include <ctype.h>

#define INFILE	"info+mail.nostuff.mp"

#define WHEAT	"wheat"
#define CHAFF	"chaff"

int
LineIsMostlyUpper(char *buf)
{
	int lower=0, upper=0;

	while (*buf) {
		if (islower(*buf))
			lower++;
		else if (isupper(*buf))
			upper++;
		buf++;
	}

	if (upper >= lower)
		return (1);
	else
		return (0);
}

int
main()
{
	FILE *infp, *wfp, *cfp;
	char linebuf[512];

	if ((infp = fopen(INFILE, "r")) == NULL) {
		perror("fopen INFILE");
		exit(1);
	}
	if ((wfp = fopen(WHEAT, "w")) == NULL) {
		perror("fopen WHEAT");
		exit(1);
	}
	if ((cfp = fopen(CHAFF, "w")) == NULL) {
		perror("fopen CHAFF");
		exit(1);
	}

	while (1) {
		fgets(linebuf, 512, infp);
		if (feof(infp) || ferror(infp))
			break;

		if (LineIsMostlyUpper(linebuf))
			fprintf(cfp, "%s", linebuf);
		else
			fprintf(wfp, "%s", linebuf);
	}

	fclose(infp);
	fclose(wfp);
	fclose(cfp);

	exit(0);
	/*NOTREACHED*/
}

