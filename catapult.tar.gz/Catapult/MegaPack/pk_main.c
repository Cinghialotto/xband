/*
 * pk_main.c - feed stuff into the compressors
 */
#include <stdio.h>
#ifdef UNIX
# include <unistd.h>
# include <sys/param.h>
#else
# include "UnixStuff.h"
#endif
#include <fcntl.h>
#include <string.h>
#include <errno.h>

#include "MegaPack.h"
#include "MegaPackPriv.h"

void Usage(char *argv0);
int CompressFile(char *filename, u_long flags);


// ===========================================================================
//		Globals
// ===========================================================================

int debug = 1;			// debugging on?
int verbose = TRUE;		// verbose output on?


// ===========================================================================
//		Local stuff
// ===========================================================================

// One buffer for plaintext, one for encoded text.
//
#ifdef UNIX
PRIVATE unsigned char plainBuf[kMaxPlain];
PRIVATE unsigned char encBuf[kMaxEnc];
#else
PRIVATE unsigned char *plainBuf;
PRIVATE unsigned char *encBuf;
#endif

long totalPlainSize = 0;
long totalEncSize = 0;
long totalFiles = 0;

int noOutput = FALSE;


// ===========================================================================
//		Useful junk
// ===========================================================================

void
Usage(char *argv0)
{
	fprintf(stderr,
		"Usage: %s [-D] [-v] [-n] [-b] [-m mode] filename ...\n", argv0);
	fprintf(stderr, "\n");
}


// ===========================================================================
//		Controlling routines
// ===========================================================================

//
// Compress the specified file to "file.mp".
//
// Since this isn't meant to replace compress or gzip, we don't try to
// remove the original or retain permissions.
//
// Returns 0 on success, -1 on error.
//
int
CompressFile(char *filename, u_long flags)
{
	FILE *fpin = NULL, *fpout = NULL;
	char outname[MAXPATHLEN];
	long inSize, outSize;

	if (strcmp(filename, "-") == 0) {
		fpin = stdin;
		filename = "stdin";
	} else {
		if (access(filename, R_OK) < 0) {
			perror(filename);
			return (-1);
		}
	}
	if ((fpin = fopen(filename, "r")) == NULL) {
		perror(filename);
		goto fail;
	}

	// Create the new file.
	//
	if (!noOutput) {
		strcpy(outname, filename);
		strcat(outname, ".mp");
		if ((fpout = fopen(outname, "w")) == NULL) {
			perror("fopen");
			goto fail;
		}
		if (verbose)
			printf("----- Compressing '%s' to '%s'\n", filename, outname);
	} else {
		if (verbose)
			printf("----- Compressing '%s'\n", filename);
	}

	// Read the input.
	//
	if (fpin == stdin) {
		if ((inSize = fread(plainBuf, 1, kMaxPlain, fpin)) <= 0) {
			fprintf(stderr, "Unable to read from stdin\n");
			goto fail;
		}
	} else {
		if (fseek(fpin, 0L, 2) != 0) {
			perror("fseek fpin");
			goto fail;
		}
		inSize = ftell(fpin);
		if (inSize > kMaxPlain) {
			fprintf(stderr, "WARNING: truncating from %ld to %ld bytes\n",
				inSize, kMaxPlain);
			inSize = kMaxPlain;
		}
		if (!inSize) {
			fprintf(stderr, "Zero-length input\n");
			goto fail;
		}
		rewind(fpin);
		if (fread(plainBuf, inSize, 1, fpin) != 1) {
			fprintf(stderr, "Read failed, wanted %ld bytes\n", inSize);
			goto fail;
		}
	}
	if (debug >= 1 && verbose)
		printf("  Read %ld bytes\n", inSize);

	// Compress it.
	//
	if ((outSize = Compress(plainBuf, encBuf, inSize, flags)) < 0) {
		fprintf(stderr, "Compression failed\n");
		goto fail;
	}
	if (verbose) {
		long templ;
		printf("\tInput size  : %ld\n", inSize);
		printf("\tOutput size : %ld\n", outSize);

		/* try not to compress anything larger than about 2^30 bytes */
		templ = ((inSize-outSize)*800L)/inSize;

		printf("\tCompression : %.2d%%\n", (int) (templ / 8L));
		printf("\tBits/symbol : %d.%.2d\n", (int) ((800L-templ) / 100L),
			(int) ((800L-templ) % 100L));
	}
	if ((!noOutput) && (fwrite(encBuf, outSize, 1, fpout) != 1)) {
		fprintf(stderr, "Write %ld bytes failed\n", outSize);
		goto fail;
	}

	// Hey, it worked.  Total it all up.
	//
	totalPlainSize += inSize;
	totalEncSize += outSize;
	totalFiles++;

	if (fpin != NULL && fpin != stdin)
		fclose(fpin);
	if (fpout != NULL)
		fclose(fpout);
	return (0);

fail:
	if (fpin != NULL && fpin != stdin)
		fclose(fpin);
	if (fpout != NULL)
		fclose(fpout);
	return (-1);
}

//
// Parse args.
//
// Exits with nonzero status if any of the compress calls failed.
//
int
main(int argc, char *argv[])
{
	extern char *optarg;
	extern int optind;
	int c, errflg, result;
	int binflg = 0;
	u_long flags = 0, modeFlags = 0;
	char *mode = NULL;

	errflg = 0;
	while ((c = getopt(argc, argv, "Dvbnm:")) != EOF) {
		switch (c) {
		case 'D':
			debug++;
			break;
		case 'v':
			verbose = 1 - verbose;
			break;
		case 'b':
			binflg = TRUE;
			break;
		case 'n':
			noOutput = TRUE;
			break;
		case 'm':
			mode = optarg;
			break;
		default:
			errflg++;
			break;
		}
	}

	if (errflg) {
		Usage(argv[0]);
		exit(2);
	}

	if (mode != NULL) {
		// Only one of these should get set.  Dunno why I'm using "|=".
		//
		if (strcmp(mode, "text") == 0)
			modeFlags |= kMPmodeText;
		else if (strcmp(mode, "news") == 0)
			modeFlags |= kMPmodeNews;
		else if (strcmp(mode, "xmail") == 0)
			modeFlags |= kMPmodeXMail;
		else if (strcmp(mode, "lzss") == 0)		// LZB's LZSS mode, not LZSS
			modeFlags |= kMPmodeLZSS;
		else if (strcmp(mode, "code") == 0)
			modeFlags |= kMPmodeCode;
		else if (strcmp(mode, "debug") == 0)
			modeFlags |= kMPmodeDebug;
		else {
			fprintf(stderr, "ERROR: mode '%s' not recognized\n", mode);
			exit(2);
		}
		printf("Using '%s' mode\n", mode);
	}

#ifndef UNIX
	plainBuf = (unsigned char *)malloc(kMaxPlain);
	encBuf = (unsigned char *)malloc(kMaxEnc);
	if (plainBuf == NULL || encBuf == NULL) {
		fprintf(stderr, "buffer alloc failed (%ld/%ld)\n",
			kMaxPlain, kMaxEnc);
		if (plainBuf != NULL)
			free(plainBuf);
		exit(1);
	}
#endif

	// For each file specified, compress
	//
	if (optind >= argc) {
		fprintf(stderr, "Error: no files to compress\n");
		result = 1;
	} else {
		result = 0;
		for (; optind < argc; optind++) {
			flags = 0x00000000
				//| kMPtryNone
				//| kMPtryQuickText
				//| kMPtryDigram
				//| kMPtryStaticHuff
				| kMPtryJRHuff
				//| kMPtryLzss
				//| kMPtryLzb
				//|kMPtryDebug
				| kMPincludeCRC
				//| kMPremapText
				//| kMPuseRLE
				| kMPuseStaticDict
				//| kMPuseAdaptiveDict
				//| kMPuseBothDict
				//| kMPvaryStaticBitl
				| kMPvaryAdaptiveBitl
				//| kMPtryFlatBits
				| modeFlags;
				;
#ifdef BLAH
				| kMPtryNone
				//| kMPtryQuickText
				| kMPtryDigram
				| kMPtryStaticHuff
				| kMPtryLzss
				| kMPtryLzb
				//|kMPtryDebug
				| kMPincludeCRC
				//| kMPremapText
				//| kMPuseRLE
				| kMPuseStaticDict
				| kMPuseAdaptiveDict
				//| kMPuseBothDict
				//| kMPvaryStaticBitl
				| kMPvaryAdaptiveBitl
				//| kMPtryFlatBits
				| modeFlags;
				;
#endif
			if (noOutput) {
				if (verbose)
					printf("(no output will be produced, no CRC generated)\n");
				flags |= kMPnoOutput;
				flags &= ~kMPincludeCRC;
			}
			if (binflg) {
				if (verbose)
					printf("(using binary settings)\n");
				flags &= ~kMPremapText;
			}
			result += CompressFile(argv[optind], flags);
		}
	}

#ifndef UNIX
	if (plainBuf != NULL)
		free(plainBuf);
	if (encBuf != NULL)
		free(encBuf);
#endif

	// Print this even in non-verbose mode.
	//
	printf("\n--- SUMMARY ---\n");
	printf("Total files: %ld\n", totalFiles);
	printf("Input size:  %ld\n", totalPlainSize);
	printf("Output size: %ld\n", totalEncSize);

	if (totalPlainSize) {
		double temp;

		temp = ((double)totalPlainSize - (double)totalEncSize) /
			(double)totalPlainSize;
		/* try not to compress anything larger than about 2^30 bytes */
		printf("\tCompression : %.2f%%\n", temp * 100.0);
		printf("\tBits/symbol : %.3f\n", 8.0 - (temp * 8.0));
	}

	exit(result != 0);
	/*NOTREACHED*/
}

