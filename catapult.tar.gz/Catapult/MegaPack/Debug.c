/*
 * Debug.c - non-compression to test out the interfaces
 *
 * RLE and remapping ignored.
 */
#include <stdio.h>
#ifdef UNIX
# include <sys/types.h>
#else
# include "UnixStuff.h"
#endif

#include "MegaPack.h"
#include "MegaPackPriv.h"


long
CompressDebug(const u_char *plain, u_char *enc, long size, u_long flags, BestData *best)
{
	u_char *orig = enc;

	while (size--)
		*enc++ = *plain++ ^ 0x80;

	return (enc - orig);
}

long
ExpandDebug(const u_char *enc, u_char *plain, long encSize, long plainSize, u_long flags)
{
	if (encSize != plainSize) {
		fprintf(stderr, "ExpandDebug: what the fuck?\n");
		return (0);
	}

	while (encSize--)
		*plain++ = *enc++ ^ 0x80;

	return (plainSize);
}

