/*
 * raw2cplt.c - convert a "raw" file to a "complete" file.
 *
 * What does that mean?  Nothing, just something I made up.  Basically,
 * we want to make sure that every possible interesting character is
 * represented in the Huffman distribution, and if it isn't we need to
 * add one of each on at the end.
 *
 * Assumes the file has been mapped & RLE-ified.
 */
#include <stdio.h>

//
// BoxChars.c includes "int box2lowa[256]", an array with "-1" for every
// character that we aren't interested in.
//
// By changing the ones we are interested in to -2 as we see them, we will
// be left with an array where every positive entry is an interesting
// char that was not found in the "raw" file.
//
// By convention, 0x7f is used as the "I dunno what comes next" escape char.
//
// EEEEK: we're now doing it on the post-mapped text rather than the
// pre-mapped version, so we need to use lowa2box instead of box2lowa.
//
#include "../BoxChars.c"


int
main(int argc, char *argv[])
{
	int i, ic;

	//if (lowa2box[0x7f] == -1) {
	//	fprintf(stderr, "ERROR: 0x7f wasn't reserved!\n");
	//	exit(1);
	//}

	// Need to catch all the RLE codes, so just stuff them all in.
	//
	for (i = 0; i <= 0x7f; i++)
		lowa2box[i] = 1;

	if (argc != 1) {
		fprintf(stderr, "Usage: %s < raw_file > not_so_raw_file\n", argv[0]);
		exit(2);
	}

	//
	// skip past the 7-byte header
	//
	(void) getc(stdin);
	(void) getc(stdin);
	(void) getc(stdin);
	(void) getc(stdin);
	(void) getc(stdin);
	(void) getc(stdin);
	(void) getc(stdin);

	// Figure out what's there.
	//
	while (1) {
		ic = getc(stdin);
		if (feof(stdin) || ferror(stdin))
			break;
		putc(ic, stdout);

		if (ic < 0 || ic > 255) {
			fprintf(stderr, "GLITCH: ic == 0x%.2x\n", ic);
			exit(1);
		}

		if (lowa2box[ic] == -1) {
			fprintf(stderr, "OHDEAR: found unexpected char 0x%.2x\n", ic);
			exit(1);
		} else if (lowa2box[ic] >= 0) {
			lowa2box[ic] = -2;
		}
	}

	// Now figure out what's not.
	//
	for (i = 0; i < 256; i++) {
		if (lowa2box[i] >= 0) {
			fprintf(stderr, " Adding 0x%.2x\n", i);
			putc(i, stdout);
		}
	}

	fprintf(stderr, "Done.\n");
	exit(0);
	/*NOTREACHED*/
}

