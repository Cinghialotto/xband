/*
 * Generate a reasonable distribution for the "table" half of SNES Japanese
 * text.
 *
 * A4 and A5 are the most common (only sets available on the box when
 * writing mail).
 *
 * A1 through FE are the only allowed values.  80 is used as filler when
 * the other stream has ASCII text.  The RLE scheme strips the hi bits
 * when encoding chars.
 */
#include <stdio.h>


main()
{
	int i, j, blah[256];

	for (i = 0; i < 256; i++)
		blah[i] = 1;
	for (i = 0xa1; i <= 0xfe; i++) {
		blah[i] = 2;
		blah[i & 0x7f] = 2;
	}
	blah[0x24] = 128;
	blah[0xa4] = 128;
	blah[0x25] = blah[0xa5] = 64;
	blah[0x80] = blah[0x00] = 32;

	// bias for low RLE counts
	blah[0x01] = blah[0x02] = blah[0x03] = blah[0x04] = blah[0x05] = 8;

	for (i = 0; i < 256; i++) {
		for (j = 0; j < blah[i]; j++)
			putchar(i);
	}

	exit(0);
}

