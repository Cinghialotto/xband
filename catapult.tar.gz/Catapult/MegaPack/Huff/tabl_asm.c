/*
 * From an input file, generate the encoded tree table and the bit patterns.
 */


#include  <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/param.h>

#define	END	256
#define PACKED 017436 /* <US><RS> - Unlikely value */
#define	SUF0	'.'
#define	SUF1	'z'


#define PRESPC "        "
#define COMSPC "              "

struct stat status, ostatus;

/* union for overlaying a long int with a set of four characters */
union FOUR {
	struct { long int lng; } lint;
	struct { char c0, c1, c2, c3; } chars;
};

/* character counters */
long	count [END+1];
union	FOUR insize;
long	outsize;
long	dictsize;
int	diffbytes;

/* i/o stuff */
char	vflag = 0;
int	force = 0;	/* allow forced packing for consistency in directory */
char	filename [MAXPATHLEN];
int	infile;		/* unpacked file */
int	outfile;	/* packed file */
char	inbuff [BUFSIZ];
char	outbuff [BUFSIZ+4];

/* variables associated with the tree */
int	maxlev;
int	levcount [25];
int	lastnode;
int	parent [2*END+1];

/* variables associated with the encoding process */
char	length [END+1];
long	bits [END+1];
union	FOUR mask;
long	inc;
#ifdef vax
char	*maskshuff[4]  = {&(mask.chars.c3), &(mask.chars.c2), &(mask.chars.c1), &(mask.chars.c0)};
#else
#ifdef pdp11
char	*maskshuff[4]  = {&(mask.chars.c1), &(mask.chars.c0), &(mask.chars.c3), &(mask.chars.c2)};
#else	/* u370 or 3b20 or UTS */
char	*maskshuff[4]  = {&(mask.chars.c0), &(mask.chars.c1), &(mask.chars.c2), &(mask.chars.c3)};
#endif
#endif

/* the heap */
int	n;
struct	heap {
	long int count;
	int node;
} heap [END+2];
#define hmove(a,b) {(b).count = (a).count; (b).node = (a).node;}


/* stuff from gzip unpack */
#define LITERALS 256
#define MAX_BITLEN 16
/* max_len == maxlev */
unsigned char literal[LITERALS];
int lit_base[MAX_BITLEN+1];
int leaves[MAX_BITLEN+1];
int parents[MAX_BITLEN+1];


/* gather character frequency statistics */
/* return 1 if successful, 0 otherwise */
input ()
{
	register int i;
	for (i=0; i<END; i++)
		count[i] = 0;
	while ((i = read(infile, inbuff, BUFSIZ)) > 0)
		while (i > 0)
			count[inbuff[--i]&0377] += 2;
	if (i == 0)
		return (1);
	printf (": read error");
	return (0);
}

/* encode the current file */
/* return 1 if successful, 0 otherwise */
output ()
{
	extern off_t lseek();
	int c, i, splat, inleft, base;
	char *inp;
	register char **q, *outp;
	register int bitsleft;
	long temp;

	/* output ``PACKED'' header */
	outbuff[0] = 037; 	/* ascii US */
	outbuff[1] = 036; 	/* ascii RS */

	printf("\n;\n; #of nodes on each level (just FYI)\n;\n");

	/* output the length and the dictionary */
	temp = insize.lint.lng;
	for (i=5; i>=2; i--) {
		outbuff[i] =  (char) (temp & 0377);
		temp >>= 8;
	}
	outp = &outbuff[6];
	*outp++ = maxlev;
	printf("%sDC   I1'%d'%s;max bit len\n", PRESPC, maxlev, COMSPC);
	printf("%sDC   I1'", PRESPC);
	for (i=1; i<maxlev; i++) {
		*outp++ = levcount[i];
		if (i == 17) {
		    printf("'   ;levcount\n%sDC   I1'%d", PRESPC, levcount[i]);
		} else {
		    if (i != 1) printf(",");
		    printf("%d", levcount[i]);
		}
	}
	printf("'   ;levcount\n");
	*outp++ = levcount[maxlev]-2;
	printf("%sDC   I1'%d'   ;levcount[maxlev]-2\n", PRESPC,
		levcount[maxlev]-2);

	printf("\n;\n; literals (for expansion)\n;\n");
	base = 0;
	for (i=1; i<=maxlev; i++) {
		printf("%sDC   H'", PRESPC);
		splat = 0;
		for (c=0; c<END; c++)
			if (length[c] == i) {
				*outp++ = c;
				literal[base++] = c;
				if (++splat == 16) {
				    splat = 0;
				    printf("'   ;level %d\n%sDC   H'%.2x", i,
					PRESPC, c);
				} else {
				    printf("%.2x", c);
				}
			}
		printf("'   ;level %d\n", i);
	}
	dictsize = outp-&outbuff[0];
	printf("\n; dictsize = %d\n\n", dictsize-6);


	/* output the table of bit codes */
	printf(";\n; Bit patterns (for compression)\n;\n");
	for (i = 0; i <= END; i++) {
	    if (!(i % 8)) {
		if (!i) printf("%sDC   I2'", PRESPC);
		else    printf("'   ;$%.2x-$%.2x\n%sDC   I2'", i-8, i-1, PRESPC);
	    } else {
		printf(",");
	    }

	    printf("$%.4x", bits[i] >> 8);
	}
	printf("'   ;%.2x-$%.2x\n", i-1, i-1);

	printf(";\n; Code lengths (for compression and expansion)\n;\n");
	for (i = 0; i <= END; i++) {
	    if (!(i % 8)) {
		if (!i) printf("%sDC   I1'", PRESPC);
		else    printf("'   ;$%.2x-$%.2x\n%sDC   I1'", i-8, i-1, PRESPC);
	    } else {
		printf(",");
	    }

	    printf("%d", length[i]);
	}
	printf("'   ;$%.2x-$%.2x\n", i-1, i-1);

	extra_stuff();
}

int max_len;

/* hacked out of unzip */
extra_stuff()
{
    int i, n, len, nodes;
    int base;

    max_len = maxlev;
    levcount[max_len] -= 2;		/* we didn't do this to internal copy */

    n = 0;
    for (len = 1; len <= max_len; len++) {
	leaves[len] = levcount[len];
	n += leaves[len];
    }
    if (n > LITERALS) {
	printf("too many leaves\n");
	abort();
    }
    leaves[max_len]++;

    base = 0;
    for (len = 1; len <= max_len; len++) {
        /* Remember where the literals of this length start in literal[] : */
        lit_base[len] = base;
        /* And read the literals: */
        for (n = leaves[len]; n > 0; n--) {
	    base++;
            /*literal[base++] = (uch)get_byte();*/
        }
    }
    leaves[max_len]++; /* Now include the EOB code in the Huffman tree */


    /* build the tree */
    nodes = 0;
    for (len = max_len; len >= 1; len--) {
	nodes >>= 1;
	parents[len] = nodes;
	lit_base[len] -= nodes;
	nodes += leaves[len];
    }

    printf("\n;\n; leaves (for table construction)\n;\n");
    printf("%sDC   I2'", PRESPC);
    for (i = 1; i <= max_len; i++) {
	if (i != 1) printf(",");
	printf("%d", leaves[i]);
    }

    printf("'\n");
    printf("\n;\n; parents (for expansion)\n;\n");
    printf("%sDC   I2'", PRESPC);
    for (i = 1; i <= max_len; i++) {
	if (i != 1) printf(",");
	printf("%d", parents[i]);
    }
    printf("'\n");

    printf("\n;\n; adjusted lit_base (for expansion)\n;\n");
    printf("%sDC   I2'", PRESPC);
    for (i = 1; i <= max_len; i++) {
	if (i != 1) printf(",");
	printf("%d", lit_base[i]);
    }
    printf("'\n");
}

/* makes a heap out of heap[i],...,heap[n] */
heapify (i)
{
	register int k;
	int lastparent;
	struct heap heapsubi;
	hmove (heap[i], heapsubi);
	lastparent = n/2;
	while (i <= lastparent) {
		k = 2*i;
		if (heap[k].count > heap[k+1].count && k < n)
			k++;
		if (heapsubi.count < heap[k].count)
			break;
		hmove (heap[k], heap[i]);
		i = k;
	}
	hmove (heapsubi, heap[i]);
}

/* return 1 after successful packing, 0 otherwise */
int packfile ()
{
	register int c, i, p;
	long bitsout;

	/* gather frequency statistics */
	if (input() == 0)
		return (0);

	/* put occurring chars in heap with their counts */
	diffbytes = -1;
	count[END] = 1;
	insize.lint.lng = n = 0;
	for (i=END; i>=0; i--) {
		parent[i] = 0;
		if (count[i] > 0) {
			diffbytes++;
			insize.lint.lng += count[i];
			heap[++n].count = count[i];
			heap[n].node = i;
		}
	}
	if (diffbytes == 1) {
		printf (": trivial file");
		return (0);
	}
	insize.lint.lng >>= 1;
	for (i=n/2; i>=1; i--)
		heapify(i);

	/* build Huffman tree */
	lastnode = END;
	while (n > 1) {
		parent[heap[1].node] = ++lastnode;
		inc = heap[1].count;
		hmove (heap[n], heap[1]);
		n--;
		heapify(1);
		parent[heap[1].node] = lastnode;
		heap[1].node = lastnode;
		heap[1].count += inc;
		heapify(1);
	}
	parent[lastnode] = 0;

	/* assign lengths to encoding for each character */
	bitsout = maxlev = 0;
	for (i=1; i<=24; i++)
		levcount[i] = 0;
	for (i=0; i<=END; i++) {
		c = 0;
		for (p=parent[i]; p!=0; p=parent[p])
			c++;
		levcount[c]++;
		length[i] = c;
		if (c > maxlev)
			maxlev = c;
		bitsout += c*(count[i]>>1);
	}
	if (maxlev > 24) {
		/* can't occur unless insize.lint.lng >= 2**24 */
		printf (": Huffman tree has too many levels");
		return(0);
	}

	/* don't bother if no compression results */
	outsize = ((bitsout+7)>>3)+6+maxlev+diffbytes;
	if ((insize.lint.lng+BUFSIZ-1)/BUFSIZ <= (outsize+BUFSIZ-1)/BUFSIZ
	    && !force) {
		printf (": no saving");
		return(0);
	}

	/* compute bit patterns for each character */
	inc = 1L << 24;
	inc >>= maxlev;
	mask.lint.lng = 0;
	for (i=maxlev; i>0; i--) {
		for (c=0; c<=END; c++)
			if (length[c] == i) {
				bits[c] = mask.lint.lng;
				mask.lint.lng += inc;
			}
		mask.lint.lng &= ~inc;
		inc <<= 1;
	}

	return (output());
}

main(argc, argv)
int argc; char *argv[];
{
	register int i;
	register char *cp;
	int k, sep;
	int fcount =0; /* count failures */
        struct  utimbuf {
        	time_t atime ;
                time_t mtime ;
        } utbuf ;
	int filelen_bound;	/* max file name length */

	for (k=1; k<argc; k++) {
		if (argv[k][0] == '-' && argv[k][1] == '\0') {
			vflag = 1 - vflag;
			continue;
		}
		if (argv[k][0] == '-' && argv[k][1] == 'f') {
			force++;
			continue;
		}
		fcount++; /* increase failure count - expect the worst */
		printf ("%s: %s", argv[0], argv[k]);
                /*
                 * determine the maximum allowable file name
                 * length based on file system type
                 * of argv[k]
                 */
                filelen_bound = 14;

		sep = -1;  cp = filename;
		for (i=0; i < (MAXPATHLEN-3) && (*cp = argv[k][i]); i++)
			if (*cp++ == '/') sep = i;
		if (cp[-1]==SUF1 && cp[-2]==SUF0) {
			printf (": already packed\n");
			continue;
		}
		if (i >= (MAXPATHLEN-3) || (i-sep) > filelen_bound-1) {
			printf (": file name too long\n");
			continue;
		}
		if ((infile = open (filename, 0)) < 0) {
			printf (": cannot open\n");
			continue;
		}
		fstat(infile,&status);
		if (status.st_mode&S_IFDIR) {
			printf (": cannot pack a directory\n");
			goto closein;
		}
		if (status.st_size == 0) {
			printf(": cannot pack a zero length file\n");
			goto closein;
		}
		if( status.st_nlink != 1 ) {
			printf(": has links\n");
			goto closein;
		}
		*cp++ = SUF0;  *cp++ = SUF1;  *cp = '\0';
		if( stat(filename, &ostatus) != -1) {
			printf(".z: already exists\n");
			goto closein;
		}
		outfile = 0;

		packfile();
	        printf (" - file unchanged\n");

      closein:
		close (infile);
	}
	return (fcount);
}

