#include <stdio.h>

main()
{
	int ic, ec=0, nc=0;

	while (1) {
		ic = getchar();
		if (ic == EOF)
			break;
		if (ic == 0x82)
			ec++;
		else
			nc++;
	}

	printf("ec=%d, nc=%d\n", ec, nc);
}

