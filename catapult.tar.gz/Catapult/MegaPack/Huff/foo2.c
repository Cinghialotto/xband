main()
{
	int i;

	for (i = 0; i < 5260; i++) {
		putchar(0x82);
	}
	exit(0);
}

