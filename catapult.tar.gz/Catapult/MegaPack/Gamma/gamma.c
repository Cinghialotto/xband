/*
 * gamma.c - Compute the gamma length table.
 */
#include <stdio.h>

int gammaTab[257];

int
main()
{
	int i, length;
	int len2, bitLength;

	gammaTab[0] = 0;
	for (length = 1; length < 257; length++) {
		for (bitLength = 1, len2 = length; len2 >>= 1; bitLength++)
			;
		gammaTab[length] = bitLength * 2 - 1;
	}

	printf("PRIVATE int gammaLenTab[257] = {");
	for (i = 0; i < 257; i++) {
		if (!(i%16)) printf("\n\t");
		printf("0x%x,", gammaTab[i]);
	}
	printf("\n};\n");

	exit(0);
}

