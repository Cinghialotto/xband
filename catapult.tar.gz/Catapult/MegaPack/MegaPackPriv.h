#ifndef __MEGAPACKPRIV_H__
#define __MEGAPACKPRIV_H__

// ===========================================================================
//		Generic declarations
// ===========================================================================

#ifdef UNIX
# include <sys/types.h>
#else
# include "UnixStuff.h"
#endif
#include "MegaPack.h"

// Pointer to a function returning long.
//
typedef long (*LONG_FUNC_PTR)();


// Random #defines
//
#ifndef TRUE
# define TRUE	1
# define FALSE	0
#endif

#ifndef PRIVATE
# define PRIVATE	static
#endif
#ifndef INLINE
# ifdef UNIX		// stupid Mac don't know what "inline" means
#  define INLINE	inline
# else
#  define INLINE
# endif
#endif

#define DEBUG
#ifdef DEBUG
# define DBUG(x) printf x
# define LDBUG(lv, x) { if (debug >= lv) printf x ; }
#else
# define DBUG(x)
# define LDBUG(lv, x)
#endif

#ifndef NELEM
# define NELEM(x) (sizeof(x) / sizeof(x[0]))
#endif


// ===========================================================================
//		Compression parameters
// ===========================================================================

// It's on the box, so there's nowhere to put more than 64K of output.
//
// I don't expect more than a 2x expansion factor for anything, so allocating
// a huge buffer allows me to be lazy in the compressors.  The expanders
// know exactly how big the source text was, and can allocate a buffer
// accordingly.
//
#define kMaxPlain	65536L		// useful limit
//#define kMaxPlain	180000L		// news.raw
//#define kMaxPlain	800000L		// book1
//#define kMaxPlain	3200000L		// MK II
#define kMaxEnc		(kMaxPlain * 2L)


// ===========================================================================
//		Compression structs and defines
// ===========================================================================

// The "best data" is 16 bytes of whatever the compression method wants to
// keep around.  The idea is that, once we've figured out what the best way
// to pack something is, we don't have to go through again and redo all of
// its internal stuff... it automatically knows which table to use or which
// bit length.  Saves time and keeps the verbose output less so.
//
// The "bestFlag" will be set if the compressor should use the data in the
// bestData buffer, clear if it should try to determine the best method.
//
#define kBestBufSize	16

typedef struct BestData {
	int		bestFlag;
	u_char	bestData[kBestBufSize];
} BestData;


// Table of compression and expansion methods.
//
#define kMPlabelSize	64

typedef struct CompressionMethod {
	int		type;
	char	label[kMPlabelSize];
	long	(*compress)(const u_char *, u_char *, long, u_long, BestData *);
	long	(*expand)(const u_char *, u_char *, long, long, u_long);
} CompressionMethod;


//
// Byte-oriented I/O context.  Useful for transparent RLE and character set
// mapping.
//
typedef struct ByteContext {
	u_char	*buf;
	long	count;
	int		rleFlag;
	int		remapFlag;

	// RLE support
	//
	int		rleState;
	u_char	rleChar;
	int		rleCount;
} ByteContext;


//
// Bit-oriented I/O context.
//
// Really ought to use two different structures, one for 16 and one for 32.
// Otherwise the compiler won't catch it if you try to mix & match them,
// which we don't support.
//
typedef struct BitContext {
	u_char	*buf;
	u_short	reg16;
	u_long	reg32;
	long	count;
} BitContext;

enum {
	kMPinputContext,		// context used for getting bits from input
	kMPoutputContext		// context used for sending bits to output
};



// ===========================================================================
//		Global variables
// ===========================================================================

extern int debug, verbose, ignoreErrors;

extern int box2lowa[], lowa2box[];		// generated into BoxChars.c
extern u_short	qtDigramTab[],
				newsDigramTab[],
				mailLoDigramTab[],
				mailHiDigramTab[];		// generated into DigramTab.c
extern u_char	staticTextDict[];		// generated into LzbDict.c


// ===========================================================================
//		Function prototypes
// ===========================================================================

#define BOX2LOWA(c)	(box2lowa[c])
#define LOWA2BOX(c)	(lowa2box[c])
#define kRestIsPlain	0x7f		// emit when unmappable char detected
#define kRLEescape		0x1f		// RLE escape char, followed by char + count


// Bit I/O routines.
//
void InitBits16(BitContext *ctxt, const u_char *buf, int type);
u_short InputBits16(register BitContext *ctxt, register int count);
u_short PeekBits16(register BitContext *ctxt, register int count);
void OutputBits16(register BitContext *ctxt, register u_short bits, register int count);
void FlushBits16(BitContext *ctxt);
void InitBits32(BitContext *ctxt, const u_char *buf, int type);
u_long InputBits32(register BitContext *ctxt, register int count);
u_long PeekBits32(register BitContext *ctxt, register int count);
void OutputBits32(register BitContext *ctxt, register u_long bits, register int count);
void FlushBits32(BitContext *ctxt);
u_char *GetBitPointer(BitContext *ctxt);

// Byte I/O routines.
//
void InitByte(ByteContext *bytxt, const u_char *buf, const long count, u_long flags);
int GetByte(register ByteContext *bytxt);
int PutByte(register ByteContext *bytxt, const u_char byte);
void FlushByte(register ByteContext *bytxt);
u_char *GetBytePointer(ByteContext *bytxt);

// Compression methods.
//
long CompressQuickText(const u_char *plain, u_char *enc, long size, u_long flags, BestData *bestBuf);
long ExpandQuickText(const u_char *enc, u_char *plain, long encSize, long plainSize, u_long flags);
long CompressDigram(const u_char *plain, u_char *enc, long size, u_long flags, BestData *bestBuf);
long ExpandDigram(const u_char *enc, u_char *plain, long encSize, long plainSize, u_long flags);
long CompressHuff(const u_char *plain, u_char *enc, long size, u_long flags, BestData *bestBuf);
long ExpandHuff(const u_char *enc, u_char *plain, long encSize, long plainSize, u_long flags);
long CompressJRHuff(const u_char *plain, u_char *enc, long size, u_long flags, BestData *bestBuf);
long ExpandJRHuff(const u_char *enc, u_char *plain, long encSize, long plainSize, u_long flags);
long CompressLzss(const u_char *plain, u_char *enc, long size, u_long flags, BestData *bestBuf);
long ExpandLzss(const u_char *enc, u_char *plain, long encSize, long plainSize, u_long flags);
long CompressLzb(const u_char *plain, u_char *enc, long size, u_long flags, BestData *best);
long ExpandLzb(const u_char *enc, u_char *plain, long encSize, long plainSize, u_long flags);
long CompressDebug(const u_char *plain, u_char *enc, long size, u_long flags, BestData *best);
long ExpandDebug(const u_char *enc, u_char *plain, long encSize, long plainSize, u_long flags);




#endif /*__MEGAPACKPRIV_H__*/
