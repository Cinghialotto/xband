/*
 * un_main.c - feed stuff into the expanders
 */
#include <stdio.h>
#ifdef UNIX
# include <unistd.h>
# include <sys/param.h>
#else
# include "UnixStuff.h"
#endif
#include <fcntl.h>
#include <errno.h>

#include "MegaPack.h"
#include "MegaPackPriv.h"

void Usage(char *argv0);
int ExpandFile(char *filename);


// ===========================================================================
//		Globals
// ===========================================================================

int debug = 1;			// debugging on?
int verbose = TRUE;		// verbose output on?


// ===========================================================================
//		Buffers
// ===========================================================================

// One buffer for plaintext, one for encoded text.
//
#ifdef UNIX
PRIVATE unsigned char plainBuf[kMaxPlain];
PRIVATE unsigned char encBuf[kMaxEnc];
#else
PRIVATE unsigned char *plainBuf;
PRIVATE unsigned char *encBuf;
#endif


// ===========================================================================
//		Useful junk
// ===========================================================================

void
Usage(char *argv0)
{
	fprintf(stderr, "Usage: %s [-D] [-v] filename ...\n", argv0);
	fprintf(stderr, "\n");
}


// ===========================================================================
//		Controlling routines
// ===========================================================================

#define kOutname	"mp.out"

//
// Expand the specified file to "mp.out".  Since we aren't going to use
// the output for anything other than debugging, there's no need to save
// the output in different files for multiple inputs.
//
// Returns 0 on success, -1 on error.
//
int
ExpandFile(char *filename)
{
	FILE *fpin = NULL, *fpout = NULL;
	long inSize, outSize;
	int fd;

	if (strcmp(filename, "-") == 0) {
		fpin = stdin;
		filename = "stdin";
	} else {
		if (access(filename, R_OK) < 0) {
			perror(filename);
			return (-1);
		}
	}
	if ((fpin = fopen(filename, "r")) == NULL) {
		perror(filename);
		goto fail;
	}

	// Create the new file.
	//
	if ((fd = open(kOutname, O_WRONLY|O_CREAT|O_TRUNC /*|O_EXCL*/ , 0644)) < 0){
		perror(kOutname);
		goto fail;
	}
	if ((fpout = fdopen(fd, "w")) == NULL) {
		perror("fdopen");
		close(fd);
		goto fail;
	}

	if (verbose) {
		printf("----- Expanding '%s' to '%s'\n", filename, kOutname);
	}

	// Read the input.
	//
	if (fpin == stdin) {
		if ((inSize = fread(encBuf, 1, kMaxEnc, fpin)) <= 0) {
			fprintf(stderr, "Unable to read from stdin\n");
			goto fail;
		}
	} else {
		if (fseek(fpin, 0L, 2) != 0) {
			perror("fseek fpin");
			goto fail;
		}
		inSize = ftell(fpin);
		if (!inSize) {
			fprintf(stderr, "Zero-length input\n");
			goto fail;
		}
		rewind(fpin);
		if (fread(encBuf, inSize, 1, fpin) != 1) {
			fprintf(stderr, "Read failed, wanted %ld bytes\n", inSize);
			goto fail;
		}
	}
	if (debug >= 1 && verbose) {
		printf("  Read %ld bytes\n", inSize);
	}

	// Expand it.
	//
	if ((outSize = Expand(encBuf, plainBuf, inSize)) < 0) {
		fprintf(stderr, "Expansion failed\n");
		outSize = -outSize;		// write it anyway, for debugging
		//goto fail;
	}
	if (fwrite(plainBuf, outSize, 1, fpout) != 1) {
		fprintf(stderr, "Write %ld bytes failed\n", outSize);
		goto fail;
	}

	if (fpin != NULL && fpin != stdin)
		fclose(fpin);
	if (fpout != NULL)
		fclose(fpout);
	return (0);

fail:
	if (fpin != NULL && fpin != stdin)
		fclose(fpin);
	if (fpout != NULL)
		fclose(fpout);
	return (-1);
}

//
// Parse args.
//
// Exits with nonzero status if any of the compress calls failed.
//
int
main(int argc, char *argv[])
{
	//extern char *optarg;
	extern int optind;
	int c, errflg, result;

	errflg = 0;
	while ((c = getopt(argc, argv, "Dv")) != EOF) {
		switch (c) {
		case 'D':
			debug++;
			break;
		case 'v':
			verbose = 1 - verbose;
			break;
		default:
			errflg++;
			break;
		}
	}

	if (errflg) {
		Usage(argv[0]);
		exit(2);
	}

#ifndef UNIX
	plainBuf = (unsigned char *)malloc(kMaxPlain);
	encBuf = (unsigned char *)malloc(kMaxEnc);
	if (plainBuf == NULL || encBuf == NULL) {
		fprintf(stderr, "buffer alloc failed (%ld/%ld)\n",
			kMaxPlain, kMaxEnc);
		if (plainBuf != NULL)
			free(plainBuf);
		exit(1);
	}
#endif

	// For each file specified, expand
	//
	if (optind >= argc) {
		fprintf(stderr, "Error: no files to expand\n");
		result = 1;
	} else {
		result = 0;
		for (; optind < argc; optind++)
			result += ExpandFile(argv[optind]);
	}

#ifndef UNIX
	if (plainBuf != NULL)
		free(plainBuf);
	if (encBuf != NULL)
		free(encBuf);
#endif

	exit(result != 0);
	/*NOTREACHED*/
}

