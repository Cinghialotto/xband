/*
 * See if the BoxChars.c stuff works.
 */
#include <stdio.h>

#include "BoxChars.c"

int
main()
{
	int i;
	int xl;

	while (1) {
		i = getc(stdin);
		if (feof(stdin) || ferror(stdin))
			break;

		xl = box2lowa[i];
		if (xl == -1) {
			fprintf(stderr, "Caught bogus char '%c' (0x%.2x)\n", i, i);
			exit(1);
		}
		putc(lowa2box[xl], stdout);
	}

	exit(0);
}

