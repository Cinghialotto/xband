/*
 * Generate tables to map chars to and from the box.
 *
 * The purpose is to avoid characters with their high bit set.
 *
 * This is a trivial program, because there are enough chars in the 0-31
 * range to cover the values >= 128.  We also remap 0x7f so that we can
 * use it as a flag that an unmappable char has been found.
 *
 * Mostly I'm doing this so I don't have to type out all the #$^! tables.
 *
 * Note that this does NOT map the things that are mapped onto, i.e. finding
 * a 0x01 in the input stream is something that can't be dealt with.  For
 * this reason we manually obstruct mapping on 0x00, 0x0a, and 0x0d.
 *
 * WARNING: the news folks were trying to use 0xca (a bullet on the mac).
 * Would be prudent to make sure it's remapped...
 */
#include <stdio.h>

int box2lowa[256];
int lowa2box[256];

void
dump_array(int ar[])
{
	int i;

	// Yeah it's ugly.  Shut up.
	//
	putchar('\t');
	for (i = 0; i < 256; i++) {
		if (ar[i] < 0)
			printf("%d,  ", ar[i]);
		else
			printf("0x%.2x,", ar[i]);
		if (((i+1) % 8) == 0) {
			putchar('\n');
			if (i != 255)
				putchar('\t');
		} else
			putchar(' ');
	}
}

int
main()
{
	char buf[8];
	int i, val;
	int remap = 1;	// skip over NUL

	for (i = 0; i < 256; i++)
		box2lowa[i] = lowa2box[i] = -1;

	box2lowa[0x00] = lowa2box[0x00] = 0x00;		// NUL
	box2lowa[0x09] = lowa2box[0x09] = 0x09;		// TAB
	box2lowa[0x0a] = lowa2box[0x0a] = 0x0a;		// LF
	box2lowa[0x0d] = lowa2box[0x0d] = 0x0d;		// CR
	//box2lowa[0x1f] = lowa2box[0x1f] = 0x1f;		// RLE escape char

	// map
	//
	while (1) {
		gets(buf);
		if (feof(stdin) || ferror(stdin))
			break;
		val = strtol(buf, NULL, 16);
		if (val < 0x7f) {
			box2lowa[val] = val;
			lowa2box[val] = val;
		} else {
			box2lowa[val] = remap;
			lowa2box[remap] = val;
			do {
				remap++;
			} while (box2lowa[remap] != -1);
		}
	}

	// dump
	//
	printf("int box2lowa[256] = {\n");
	dump_array(box2lowa);
	printf("};\n\n");
	printf("int lowa2box[256] = {\n");
	dump_array(lowa2box);
	printf("};\n\n");

	exit(0);
}

