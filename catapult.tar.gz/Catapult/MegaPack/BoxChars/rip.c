/*
 * Convert a long stream of 4-byte char values into a single column of
 * char values.
 */
#include <stdio.h>

main()
{
	int i;
	char buf[1024];
	char *cp;

	gets(buf);

	cp = buf;
	for (i = 0; i < 112; i++) {
		printf("%.4s\n", cp);
		cp += 4;
	}
	exit(0);
}

