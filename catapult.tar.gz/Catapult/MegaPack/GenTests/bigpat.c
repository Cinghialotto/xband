/*
 * 64K of 0x00-0xff repeated.
 */
#include <stdio.h>

main()
{
	int i;

	for (i = 0; i < 65535; i++)
		putchar(i & 0xff);

	exit(0);
}

