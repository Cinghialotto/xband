/*
 * Cut stdin off at 64K.
 */
#include <stdio.h>

main()
{
	int i, c;

	for (i = 0; i < 65535; i++) {	// 64K -1
	//for (i = 0; i < 57344; i++) {	// 56K
		c = getc(stdin);
		putchar(c);
	}

	exit(0);
}

