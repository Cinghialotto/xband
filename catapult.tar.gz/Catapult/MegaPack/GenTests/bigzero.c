/*
 * 64K of the same char.
 */
#include <stdio.h>

main()
{
	int i;

	for (i = 0; i < 65535; i++)
		putchar('*');

	exit(0);
}

