/*
 * Digram.c - digram-based text compression
 *
 * Use of RLE recommended, use of remapping required.
 */
#include <stdio.h>
#ifdef UNIX
# include <sys/types.h>
#else
# include "UnixStuff.h"
#endif

#include "MegaPack.h"
#include "MegaPackPriv.h"

PRIVATE int DGLookupDigram(int ic1, int ic2, register u_short digramTab[]);
PRIVATE long DGCompress(const u_char *plain, u_char *enc, long size, u_long flags, u_short *digramTab);


// ===========================================================================
//		Compression
// ===========================================================================

long
CompressDigram(const u_char *plain, u_char *enc, long size, u_long flags, BestData *best)
{
	long result, bestResult = 0;
	int bestMode;

	if (flags & kMPmodeMask) {
		// This is probably a mistake... some things work MUCH better
		// with one or the other.  The news one is probably the best
		// overall.
		//
		best->bestData[0] = '0';	// newsDigramTab
	}

	// Try different digram tables until we find the best one.
	//
	if (best->bestFlag) {
		if (best->bestData[0] == '0')
			bestResult = DGCompress(plain, enc, size, flags, newsDigramTab);
		else if (best->bestData[0] == '1')
			bestResult = DGCompress(plain, enc, size, flags, mailLoDigramTab);
		else if (best->bestData[0] == '2')
			bestResult = DGCompress(plain, enc, size, flags, mailHiDigramTab);
		else {
			fprintf(stderr, "Digram: unknown best setting 0x%.2x.\n",
				best->bestData[0]);
			return (-1);
		}
	} else {
		bestMode = -1;
		result = DGCompress(plain, enc, size, flags, newsDigramTab);
		if (result != -1) {
			bestResult = result;
			bestMode = '0';
		}
		result = DGCompress(plain, enc, size, flags, mailLoDigramTab);
		if ((result != -1) && ((bestResult == -1) || (result < bestResult))) {
			bestResult = result;
			bestMode = '1';
		}
		result = DGCompress(plain, enc, size, flags, mailHiDigramTab);
		if ((result != -1) && ((bestResult == -1) || (result < bestResult))) {
			bestResult = result;
			bestMode = '2';
		}

		best->bestData[0] = bestMode;
	}

	return (bestResult);
}


//
// Do the actual compression.
//
PRIVATE long
DGCompress(const u_char *plain, u_char *enc, long size, u_long flags, u_short *digramTab)
{
	ByteContext bytxt;
	u_char *orig = enc;
	int ic1, ic2, digram;

	InitByte(&bytxt, plain, size, flags);

	if (digramTab == newsDigramTab)
		*enc++ = '0';
	else if (digramTab == mailLoDigramTab)
		*enc++ = '1';
	else if (digramTab == mailHiDigramTab)
		*enc++ = '2';
	else {
		fprintf(stderr, "Digram: unknown table!\n");
		return (-1);
	}
	LDBUG(1, ("    Using table '%c'\n", *(enc-1)));

	while (1) {
		if ((ic1 = GetByte(&bytxt)) == -1)
			break;
		if (ic1 == kRestIsPlain)
			goto rest_is_plain;

got_one:
		if ((ic2 = GetByte(&bytxt)) == -1) {
			*enc++ = ic1;
			break;
		}
		if (ic2 == kRestIsPlain) {
			*enc++ = ic1;
			goto rest_is_plain;
		}

		if ((digram = DGLookupDigram(ic1, ic2, digramTab)) != -1) {
			*enc++ = digram | 0x80;
		} else {
			*enc++ = ic1;
			ic1 = ic2;
			goto got_one;
		}
	}

done:
	LDBUG(1, ("    Output is %d bytes\n", enc - orig));
	return (enc - orig);

rest_is_plain:
	LDBUG(1, ("    Encountered unmappable char 0x%.2x at byte %d\n",
		*(GetBytePointer(&bytxt)), GetBytePointer(&bytxt) - plain));
	*enc++ = kRestIsPlain;

	// Now just loop until empty.
	//
	while (1) {
		ic1 = GetByte(&bytxt);
		if (ic1 == -1)
			break;
		*enc++ = ic1;
	}
	goto done;
}

#define kDigramTabSize	128
//
// Look up two chars in the digram table.  Returns the index (0-127) if
// found, -1 if not.
//
// "ic1" is the character appearing first in the input.
//
// Does a binary search on the digram table.
//
PRIVATE int
DGLookupDigram(int ic1, int ic2, register u_short digramTab[])
{
	register int i, upper, lower;
	register u_short lkup, found;

	// Thing to search for.
	//
	lkup = (ic1 << 8) | ic2;

	// Bounds for binary search.
	//
	lower = 0;
	upper = kDigramTabSize-1;

	// Go for it.
	//
	while (1) {
		if (upper <= lower)
			return (-1);

		i = (upper + lower) >> 1;
		found = digramTab[i];
		if (found == lkup) {
			return (i);
		} else if (found < lkup) {
			lower = i;
			if (lower == upper-1)
				if (digramTab[upper] == lkup)
					return (upper);
				else
					return (-1);
		} else {
			upper = i;
			if (lower == upper-1)
				if (digramTab[lower] == lkup)
					return (lower);
				else
					return (-1);
		}
	}
	return (-1);
}


// ===========================================================================
//		Expansion
// ===========================================================================

long
ExpandDigram(const u_char *enc, u_char *plain, long encSize, long plainSize, u_long flags)
{
	ByteContext bytxt;
	register u_short digc;
	register int ic;
	register u_short *digramTab;

	InitByte(&bytxt, plain, plainSize, flags);

	// First byte is which table we're using.  This could be stored more
	// efficiently.
	//
	ic = *enc++;
	if (ic == '0')
		digramTab = newsDigramTab;
	else if (ic == '1')
		digramTab = mailLoDigramTab;
	else
		digramTab = mailHiDigramTab;

	while (1) {
		ic = *enc++;

		if (ic == kRestIsPlain) {
			// Go into stupid mode.
			//
			LDBUG(1, ("    Found 0x%.2x in input at byte %d, switching to guns\n",
				ic, GetBytePointer(&bytxt) - plain));
			if (PutByte(&bytxt, kRestIsPlain) != 0)
				break;
			while (1) {
				if (PutByte(&bytxt, *enc++) != 0)
					break;
			}
			break;
		}

		if (ic & 0x80) {
			digc = digramTab[ic & 0x7f];
			if (PutByte(&bytxt, digc >> 8) != 0) {
				fprintf(stderr, "ERROR: split digram\n");
				break;
			}
			if (PutByte(&bytxt, digc & 0xff) != 0)
				break;
		} else {
			if (PutByte(&bytxt, ic) != 0)
				break;
		}
	}
	return (GetBytePointer(&bytxt) - plain);
}

