/*
 * JRHuff.c - Japanese RLE/Huffman compression with static tables
 *
 * Portions derived from "unzip.c" in gzip-1.2.4.
 *
 * Assumes that the static Huffman tables have a max_len less <= 16 bits.
 * Anything other than that is going to choke on a SNES anyway.
 *
 * RLE setting ignored.  Text remapping should not be used.
 */
#include <stdio.h>
#ifdef UNIX
# include <sys/types.h>
# include <malloc.h>
#else
# include "UnixStuff.h"
#endif

#include "MegaPack.h"
#include "MegaPackPriv.h"
#include "JRHuffTable.h"

//#define BUILD_PEEK_TABLE	// if it's not in ROM
//#define DUMP_PEEK_TABLE	// tabl.c wasn't doing this before
//#define NO_HUFFMAN		// for debugging


//
// Local prototypes.
//
PRIVATE int JRSplitCompress(const u_char *plain, u_char *table, u_char *glyph, long size, long *tableSizep, long *glyphSizep);
PRIVATE long SHCompress(const u_char *plain, u_char *enc, long size, u_long flags, HuffTable *huffTable);
PRIVATE long JRJoinExpand(const u_char *table, const u_char *glyph, u_short tableSize, u_short glyphSize, u_char *plain);
PRIVATE long SHExpand(const u_char *enc, u_char *plain, long encSize, long plainLimit, u_long flags);
#ifdef BUILD_PEEK_TABLE
PRIVATE int BuildPeekTable(HuffTable *huffTable, u_char *ptab, int peekBits);
#endif


// Replace this with whatever is appropriate; the malloc() routine is
// assumed to return NULL on failure.
//
#define InternalMalloc(x)	malloc(x)
#define InternalFree(x)		free(x)


// ===========================================================================
//		Compression
// ===========================================================================

long
CompressJRHuff(const u_char *plain, u_char *enc, long size, u_long flags, BestData *best)
{
	long result, totalResult, bestResult = -1;
	u_char *table = NULL, *glyph = NULL;
	long tableSize, glyphSize;
	int i, bestMode;

	// Turn off MegaPack RLE if it's on.
	//
	flags &= ~kMPuseRLE;

	// Do an initial pass to split the data into halves.  The maximum
	// size of each half is equal to the size of the source (the degenerate
	// case is an entirely English message), so each buffer is as large
	// as the entire input.
	//
	// We do RLE on the "table" half as we go.
	//
	// We need to be careful about overflowing the output buffer.  We are
	// expected to guarantee that the output is no larger than twice the
	// input, but insertion of ASCII pad chars can cause the logical input
	// to be 2x larger than the actual input... since Huffman could then drive
	// the output to be twice as large as the logical input, we run the risk
	// of overflow due to 4x expansion.  The solution is to compress each half
	// into the start of the output buffer until "bestFlag" is set; that way
	// there's no danger unless the caller is an idiot and called with
	// bestFlag set before trying it.
	//
	if ((table = InternalMalloc(size)) == NULL) {
		fprintf(stderr, "JRHuff: table malloc(%ld) failed\n", size);
		return (-1);
	}
	if ((glyph = InternalMalloc(size)) == NULL) {
		fprintf(stderr, "JRHuff: glyph malloc(%ld) failed\n", size);
		InternalFree(table);
		return (-1);
	}

	if (JRSplitCompress(plain, table, glyph, size, &tableSize, &glyphSize) < 0)
	{
		goto free_fail;
	}
	if (tableSize > size || glyphSize > size) {
		// Mr. Scott, I believe you just signed our death warrant.
		fprintf(stderr,
			"JRHuff: split sizes (%ld/%ld) > size (%ld), eeek!\n",
			tableSize, glyphSize, size);
		goto free_fail;
	}

	if (tableSize > 32767 || glyphSize > 32767) {
		fprintf(stderr, "JRHuff: ERROR: split sizes exceed 32767\n");
		return (-1);
	}


	// Do Huffman compression independently on each stream.
	//
	if (best->bestFlag) {
		// Compress with the best method we found.
		//
		u_char *glyphLenGoesHere = enc +2;

		if (best->bestData[0] == '!') {
			// Huffman failed, just copy it over.
			//
			*enc++ = (tableSize >> 8) & 0xff;
			*enc++ = tableSize & 0xff;
			enc += 2;	// leave a hole for glyph len
			memcpy(enc, table, tableSize);
			enc += tableSize;
			totalResult = tableSize + 4;
		} else {
			bestMode = best->bestData[0] - '0';
			if (bestMode < 0 || bestMode > NELEM(huffTab)) {
				fprintf(stderr, "JRHuff: unknown best setting 0x%.2x.\n",
					best->bestData[0]);
				goto free_fail;
			}
			bestResult = SHCompress(table, enc+4, tableSize, flags,
				&huffTab[bestMode]);
			if (bestResult < 0) {
				fprintf(stderr, "JRHuff: best SHCompress failed 0x%.2x.\n",
					best->bestData[0]);
				goto free_fail;
			}
			if (bestResult > 32767) {
				fprintf(stderr, "JRHuff: table side too large (%ld)\n",
					bestResult);
				goto free_fail;
			}
			*enc++ = ((bestResult >> 8) & 0xff) | 0x80;
			*enc++ = bestResult & 0xff;
			enc += 2;	// leave a hole for glyph len
			enc += bestResult;
			LDBUG(2, ("      Best table huff result = %ld -> %ld\n",
				tableSize, bestResult));
			totalResult = bestResult + 4;
		}

		if (best->bestData[1] == '!') {
			// Huffman failed, just copy it over.
			//
			*glyphLenGoesHere++ = (glyphSize >> 8) & 0xff;
			*glyphLenGoesHere++ = glyphSize & 0xff;
			memcpy(enc, glyph, glyphSize);
			enc += glyphSize;
			totalResult += glyphSize;
		} else {
			bestMode = best->bestData[1] - '0';
			if (bestMode < 0 || bestMode > NELEM(huffTab)) {
				fprintf(stderr, "JRHuff: unknown best setting 0x%.2x.\n",
					best->bestData[1]);
				goto free_fail;
			}
			bestResult = SHCompress(glyph, enc, glyphSize, flags,
				&huffTab[bestMode]);
			if (bestResult < 0) {
				fprintf(stderr, "JRHuff: best SHCompress failed 0x%.2x.\n",
					best->bestData[1]);
				goto free_fail;
			}
			if (bestResult > 32767) {
				fprintf(stderr, "JRHuff: glyph side too large (%ld)\n",
					bestResult);
				goto free_fail;
			}
			*glyphLenGoesHere++ = ((bestResult >> 8) & 0xff) | 0x80;
			*glyphLenGoesHere++ = bestResult & 0xff;
			enc += bestResult;
			LDBUG(2, ("      Best glyph huff result = %ld -> %ld\n",
				glyphSize, bestResult));
			totalResult += bestResult;
		}

	} else {
#ifdef NO_HUFFMAN
		totalResult = tableSize + glyphSize +4;
		best->bestData[0] = best->bestData[1] = '!';
#else
		// Try stuff until we find the best one.
		//
		LDBUG(1, ("    Trying tables = %d - %d on table\n",
			kMinTableHuff, kMaxTableHuff));
		bestMode = -1;
		result = bestResult = -1;
		for (i = kMinTableHuff; i <= kMaxTableHuff; i++) {
			result = SHCompress(table, enc, tableSize, flags, &huffTab[i]);
			if ((result != -1) && ((bestResult == -1) || (result < bestResult)))
			{
				bestResult = result;
				bestMode = i + '0';
			}
		}

		if (bestResult < tableSize) {
			best->bestData[0] = bestMode;
			totalResult = bestResult;
		} else {
			best->bestData[0] = '!';
			totalResult = tableSize;
		}
		LDBUG(2, ("      Huff on table: %ld to %ld (table %c)\n",
			tableSize, bestResult, best->bestData[0]));

		LDBUG(1, ("    Trying tables = %d - %d on glyph\n",
			kMinGlyphHuff, kMaxGlyphHuff));
		bestMode = -1;
		result = bestResult = -1;
		for (i = kMinGlyphHuff; i <= kMaxGlyphHuff; i++) {
			result = SHCompress(glyph, enc, glyphSize, flags, &huffTab[i]);
			if ((result != -1) && ((bestResult == -1) || (result < bestResult)))
			{
				bestResult = result;
				bestMode = i + '0';
			}
		}

		if (bestResult < glyphSize) {
			best->bestData[1] = bestMode;
			totalResult += bestResult;
		} else {
			best->bestData[1] = '!';
			totalResult += glyphSize;
		}
		LDBUG(2, ("      Huff on glyph: %ld to %ld (table %c)\n",
			glyphSize, bestResult, best->bestData[1]));

		totalResult += 4;	// include lengths in final output
#endif	/*NO_HUFFMAN*/
	}

	LDBUG(2, ("      TotalResult = %ld\n", totalResult));

	if (totalResult > 2 * size) {
		// If they try to compress with this, they'll overflow enc.  Don't
		// allow that.
		//
		LDBUG(1, ("    JRHuff totalResult (%ld) > 2*size (%ld), bailing\n",
			totalResult, size * 2));
		totalResult = -1;
	}

	InternalFree(table);
	InternalFree(glyph);
	return (totalResult);

free_fail:
	if (table != NULL)
		InternalFree(table);
	if (glyph != NULL)
		InternalFree(glyph);
	return (-1);
}


#define kASCIIPad	0x80	// the pad with wings
#define kKanjiStart	0xa1
#define kKanjiEnd	0xfe

#define ISKANJI(_char) \
	(((unsigned char)(_char) >= kKanjiStart) && \
	((unsigned char)(_char) <= kKanjiEnd))

#define kMinRLE		3		// don't encode 2-byte runs

//
// Do the split/RLE thing (this stuff is Jon Slenk's fault).
//
// Since the data we're RLEing always has the high bit set (it either
// satisfied ISKANJI() or is equal to kASCIIPad), we encode runs as the
// character with the high bit clear followed by the count.  This method
// has the property that it never generates output larger than the input.
//
// Return value is the size of the streams.
//
PRIVATE int
JRSplitCompress(const u_char *plain, u_char *table, u_char *glyph, long size, long *tableSizep, long *glyphSizep)
{
	long rcount, splitsize = 0;
	long origSize = size;	// (for debug only)
	u_char nextChar, prevChar;
	u_char *rleTable, *origTable = table;
	register u_short repCount;

	// First do the split.
	//
	while (size > 0) {
		if (ISKANJI(*plain)) {
			// Output this char to the "table" stream, output the other
			// char to the "glyph" stream.
			//
			LDBUG(4, ("table=0x%.2x\n", *plain));
			*table++ = *plain++;
			LDBUG(4, ("glyph=0x%.2x\n", *plain));
			*glyph++ = *plain++;
			size -= 2;
		} else {
			// Output an ASCII pad to the "table" stream, and put this
			// one into the "glyph" stream.
			//
			LDBUG(4, ("table=0x%.2x\n", kASCIIPad));
			*table++ = kASCIIPad;
			LDBUG(4, ("glyph=0x%.2x\n", *plain));
			*glyph++ = *plain++;
			size--;
		}
		splitsize++;
	}

	if (size < 0) {
		fprintf(stderr, "ERROR: JRHuff: crossed the streams in SplitComp\n");
		return (-1);
	}

	LDBUG(1, ("    SplitCompress on %ld bytes leaves splitsize=%ld\n",
		origSize, splitsize));
	*glyphSizep = splitsize;

	// Now do the RLE in place.  We can't compare current char with char-1,
	// because we might stomp on char-1.  (Actually, if we only run-length
	// encode runs of 3 or more, I don't think we can.  Still, dereferencing
	// a char* with Orca/C sucks the big one...)
	//
	rleTable = origTable;
	table = origTable +1;
	prevChar = *origTable;
	LDBUG(3, ("    Byte=0x%.2x\n", prevChar));
	repCount = 1;
	for (rcount = splitsize-1; rcount > 0; rcount--) {
		LDBUG(3, ("    byte=0x%.2x\n", *table));
		nextChar = *table;
		if ((nextChar == prevChar) && repCount < (255+kMinRLE)) {
			repCount++;
			LDBUG(3, ("      count now=%d\n", repCount));
			table++;
		} else {
			if (repCount > 2) {
				LDBUG(3, ("      RUN 0x%.2x %d\n", prevChar & 0x7f, repCount));
				*rleTable++ = prevChar & 0x7f;
				*rleTable++ = repCount - kMinRLE;
				repCount = 1;
			} else {
				LDBUG(3, ("      output 0x%.2x\n", prevChar));
				*rleTable++ = prevChar;
				if (repCount == 2) {
					LDBUG(3, ("      output 0x%.2x\n", prevChar));
					*rleTable++ = prevChar;
					repCount = 1;
				}
			}
			prevChar = nextChar;
			table++;
		}
	}
	LDBUG(3, ("      Loop done, cleanup\n"));
	if (repCount > 2) {
		LDBUG(3, ("      RUN 0x%.2x %d\n", prevChar & 0x7f, repCount));
		*rleTable++ = prevChar & 0x7f;
		*rleTable++ = repCount - kMinRLE;
	} else {
		LDBUG(3, ("      output 0x%.2x\n", prevChar));
		*rleTable++ = prevChar;
		if (repCount == 2) {
			LDBUG(3, ("      output 0x%.2x\n", prevChar));
			*rleTable++ = prevChar;
		}
	}

	*tableSizep = (long)rleTable - (long)origTable;
	LDBUG(1, ("    source=%ld  tableSize=%ld  glyphSize=%ld\n",
		origSize, *tableSizep, *glyphSizep));
	return (0);
}


//
// Do the static Huffman compression.
//
PRIVATE long
SHCompress(const u_char *plain, u_char *enc, long size, u_long flags, HuffTable *huffTable)
{
	BitContext ctxt;
	ByteContext bytxt;
	u_char *end;
	int ic;

	// Init the output context.
	//
	InitBits16(&ctxt, enc, kMPoutputContext);

	// Init the input context.
	//
	InitByte(&bytxt, plain, size, flags);

	OutputBits16(&ctxt, (unsigned short)huffTable->index << 8, 8);
	LDBUG(1, ("    Using table '%c' on %ld bytes\n", huffTable->index, size));

	while (1) {
		if ((ic = GetByte(&bytxt)) == -1)
			break;
		if (!huffTable->code_lengths[ic]) {
			// Could do a kRestIsPlain here, but if the table is fully
			// populated it can't happen.
			//
			fprintf(stderr, "JRHuff: invalid input byte 0x%.2x\n", ic);
			return (-1);
		}
		LDBUG(3, ("      Output %d:0x%.2x as 0x%.4x/%d (@0x%.4x)\n",
			GetBytePointer(&bytxt) - plain -1, ic, huffTable->bit_pats[ic],
				huffTable->code_lengths[ic], GetBitPointer(&ctxt) - enc));
		OutputBits16(&ctxt, huffTable->bit_pats[ic],
			huffTable->code_lengths[ic]);
	}

	// Output the end marker.
	//
	OutputBits16(&ctxt, huffTable->bit_pats[256], huffTable->code_lengths[256]);
	FlushBits16(&ctxt);
	end = GetBitPointer(&ctxt);

	LDBUG(1, ("    Output is %d bytes\n", end - enc));
	return (end - enc);
}



// ===========================================================================
//		Expansion
// ===========================================================================

long
ExpandJRHuff(const u_char *enc, u_char *plain, long encSize, long plainSize, u_long flags)
{
	u_short tableSize, glyphSize;
	u_char *table = NULL, *glyph = NULL;
	long joinsize, result;

	// Allocate temporary buffers to un-Huff the two streams into.  We
	// don't actually have the uncompressed size of the individual streams,
	// but we know that each can be no larger than plainSize.
	//
	// Japan-SNES note: this'll be used for mail and personal info, so
	// the actual sizes should be small... and besides, Yerga says we have
	// plenty of free memory.
	//
	if ((table = InternalMalloc(plainSize)) == NULL) {
		fprintf(stderr, "JRHuff: table malloc(%ld) failed\n", plainSize * 2);
		return (-1);
	}
	if ((glyph = InternalMalloc(plainSize)) == NULL) {
		fprintf(stderr, "JRHuff: glyph malloc(%ld) failed\n", plainSize * 2);
		InternalFree(table);
		return (-1);
	}

	// Size of data after compression.  If the high bit is set, Huffman
	// was used.
	//
	tableSize = (*enc++) << 8;
	tableSize |= *enc++;
	glyphSize = (*enc++) << 8;
	glyphSize |= *enc++;
	LDBUG(2, ("      tableSize=0x%.4x  glyphSize=0x%.4x\n",
		tableSize, glyphSize));

	// Expand or copy the data into separate table and glyph buffers.  If
	// it was compressed with Huffman, then the actual size of the table
	// and glyph pieces is what Huffman returns, not what we pulled out
	// of the file.
	//
	result = tableSize & 0x7fff;
	if (tableSize & 0x8000)
		result = SHExpand(enc, table, tableSize & 0x7fff, plainSize, flags);
	else
		memcpy(table, enc, tableSize);
	enc += tableSize & 0x7fff;
	tableSize = result;
	LDBUG(2, ("      tableSize actually %d\n", tableSize));

	result = glyphSize & 0x7fff;
	if (glyphSize & 0x8000)
		result = SHExpand(enc, glyph, glyphSize & 0x7fff, plainSize, flags);
	else
		memcpy(glyph, enc, glyphSize);
	glyphSize = result;
	LDBUG(2, ("      glyphSize actually %d\n", glyphSize));

	if (tableSize == (u_short) -1 || glyphSize == (u_short) -1) {
		fprintf(stderr, "ERROR: JRHuff: expansion failed\n");
		InternalFree(table);
		InternalFree(glyph);
		return (-1);
	}

	// Rejoin the streams.
	//
	joinsize = JRJoinExpand(table, glyph, tableSize, glyphSize, plain);

	InternalFree(table);
	InternalFree(glyph);
	return (joinsize);
}

PRIVATE long
JRJoinExpand(const u_char *table, const u_char *glyph, u_short tableSize, u_short glyphSize, u_char *plain)
{
	register u_short repCount;
	u_char *origPlain = plain;
	u_char uch;

	while (tableSize) {
		uch = *table++;
		tableSize--;
		repCount = 1;
		if (!(uch & 0x80)) {
			repCount = *table++ + kMinRLE;
			tableSize--;
			uch |= 0x80;
			LDBUG(3, ("      table=0x%.2x-%d\n", uch, repCount));
		} else {
			LDBUG(3, ("      table=0x%.2x\n", uch));
		}

		// This would be more efficient if the "while" were inside each "if".
		// A clever compiler will optimize out the local invariant, but
		// I doubt Okra/C will.
		//
		glyphSize -= repCount;	// sanity check only
		if (glyphSize >= 65536-256) {
			// If we're here, chances are we rolled it under.
			//
			fprintf(stderr, "ERROR: JRHuff rolled under, glyphSize=%d\n",
				glyphSize);
			return (-1);
		}
		while (repCount--) {
			if (uch == kASCIIPad) {
				*plain++ = *glyph++;
			} else {
				*plain++ = uch;
				*plain++ = *glyph++;
			}
		}
	}

	if (tableSize != 0 || glyphSize != 0) {
		fprintf(stderr, "ERROR: JRHuff JoinExpand failed, glyphSize=%d\n",
			glyphSize);
		return (-1);
	}

	LDBUG(1, ("    JoinExpand: output %ld bytes\n",
		(long)plain - (long)origPlain));
	return ((long)plain - (long)origPlain);
}


//
// Expand the static Huffman.
//
// We don't know the uncompressed size of each stream, but we do know the
// absolute maximum limit (each individual stream cannot exceed the length of
// the source), so we still have a reasonable sanity check.
//
PRIVATE long
SHExpand(const u_char *enc, u_char *plain, long encSize, long plainLimit, u_long flags)
{
	static u_char *peekTable;
	BitContext ctxt;
	ByteContext bytxt;
	u_short eob;
	register HuffTable *huffTable;
	register u_short us;
	register int peekBits, len;

	// Initialize the input context.
	//
	InitBits16(&ctxt, enc, kMPinputContext);

	// Initialize the output context.
	//
	InitByte(&bytxt, plain, plainLimit, flags);

	// First byte is which table we're using.  This could be stored more
	// efficiently.
	//
	us = InputBits16(&ctxt, 8) >> 8;
	LDBUG(1, ("    Using table '%c'\n", us));
	if (us - '0' < 0 || us - '0' > NELEM(huffTab)) {
		fprintf(stderr, "ERROR: JRHuff: bad Huffman table 0x%.2x\n", us);
		return (-1);
	}
	huffTable = &huffTab[us - '0'];

	// Build the hash table.
	//
	peekBits = (huffTable->max_len < kMaxPeekBits) ?
		huffTable->max_len : kMaxPeekBits;
	peekTable = huffTable->peekTable;
#ifdef BUILD_PEEK_TABLE
	BuildPeekTable(huffTable, peekTable, peekBits);
#endif

	/* The eob code is the largest code among all leaves of maximal length: */
	eob = huffTable->leaves[huffTable->max_len] - 1;
	LDBUG(2, ("    eob %d 0x%x\n", huffTable->max_len, eob));

	while (1) {
		us = PeekBits16(&ctxt, peekBits) >> (16 - peekBits);
		len = peekTable[us];
		if (len > 0) {
			// Found it.  Read just those bits, and right-align them
			// (InputBits reads things aligned with the left edge of the word).
			//
			us = InputBits16(&ctxt, len) >> (16 - len);
		} else {
			// It's longer than peekBits, so we need to step down the tree.
			//
			// This formerly straightforward loop got messed up because
			// of a limitation in PeekBits16 (which can look forward at
			// most 9 bits).
			//
			u_short us2 = InputBits16(&ctxt, peekBits) >> (16 - peekBits);

			len = 0;
			do {
				len++;
				us = (us2 << len) |
					PeekBits16(&ctxt, len) >> (16 - len);
			} while (us < (u_short) huffTable->parents[len + peekBits]);
			/* loop as long as peek is a parent node */

			(void) InputBits16(&ctxt, len);		// skip them bits

			len += peekBits;
		}
		LDBUG(3, ("    len=%d, us=0x%.4x\n", len, us));

		if (us == eob && len == huffTable->max_len)
			break;		/* looks like EOF */
		PutByte(&bytxt, huffTable->huff_lits[us + huffTable->lit_base[len]]);
		LDBUG(3, ("      %d: char = 0x%.2x (idx %d)\n",
			GetBytePointer(&bytxt) - plain -1,
			huffTable->huff_lits[us + huffTable->lit_base[len]],
			us + huffTable->lit_base[len]));

		if (GetBytePointer(&bytxt) - plain > plainLimit) {
			fprintf(stderr, "ERROR: JRHuff: too much output\n");
			break;
		}
		if (GetBitPointer(&ctxt) - enc > encSize) {
			fprintf(stderr, "ERROR: JRHuff: too far in input\n");
			break;
		}
	}
	return (GetBytePointer(&bytxt) - plain);
}

#ifdef BUILD_PEEK_TABLE
PRIVATE int
BuildPeekTable(HuffTable *huffTable, u_char *ptab, int peekBits)
{
	register u_char *prefixp;
	int len;

	LDBUG(2, ("      Constructing peek table (%d bits)\n", peekBits));

	prefixp = &ptab[1<<peekBits];
	for (len = 1; len <= peekBits; len++) {
		int prefixes;
		
		prefixes = huffTable->leaves[len] << (peekBits-len); /* may be 0 */
		while (prefixes--)
			*--prefixp = (u_char)len;
	}

	/* The length of all other codes is unknown: */
	while (prefixp > ptab)
		*--prefixp = 0;

# ifdef DUMP_PEEK_TABLE
#  define PRESPC	"\t"
	{
		int i;

		printf("\n//\n// peek table %c (%d bits)\n//\n", huffTable->index,
			peekBits);
		printf("unsigned char peekTable[%d] = {\n", 1<<peekBits);

		for (i = 0; i < 1<<peekBits; i++) {
			if (!(i % 16)) {
				if (!i) printf("%s", PRESPC);
				else    printf(",   //$%.3x-$%.3x\n%s", i-16, i-1, PRESPC);
			} else {
				printf(",");
			}

			printf("%d", ptab[i]);
		}
		printf("    //$%.2x-$%.2x\n", i-16, i-1);
		printf("};\n");
	}
# endif	/*DUMP_PEEK_TABLE*/

	return (0);
}
#endif	/*BUILD_PEEK_TABLE*/

