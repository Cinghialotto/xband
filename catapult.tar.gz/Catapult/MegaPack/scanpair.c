/*
 * Scan a file and output the 128 most common pairs of characters.
 *
 * This was written to be as simple as possible, not as speedy.  The maximum
 * count is 65535; on hitting 64K all counts are cut in half.  Since the
 * compressor only deals with 7-bit data, we can restrict our counts to a
 * 128*128 table.  To make life easier, we use 128*256.
 *
 *
 * Andy McFadden
 * Oct-92
 */
#ifdef __STDC__
# include <stdlib.h>
#endif
#include <stdio.h>

#define READ_BINARY	"r"		/* "r" for UNIX, "rb" for Orca */

extern int errno;

unsigned short counts[256*256];


#ifdef __STDC__
int do_scan(FILE *fp)
#else
int
do_scan(fp)
FILE *fp;
#endif
{
    int i, c, lastc;
    unsigned short idx;

    lastc = getc(fp);
    //if (lastc & 0xff80) {
		//fprintf(stderr, "ERROR: Found data with hi bit set\n");
		//return (-1);
    //}

    while ((c = getc(fp)) != EOF) {
	if (ferror(fp)) {
	    fprintf(stderr, "ERROR: getc failed\n");
	    exit(1);
	}
	//if (c & 0xff80) {
	 //   fprintf(stderr, "ERROR: found data with hi bit set\n");
	  //  return (-1);
	//}
	idx = (unsigned short) c + (((unsigned short) lastc) << 8);

	if (counts[idx] == 65535) {
	    /* cut all counts in half */
	    for (i = 0; i < 65536; i++)
		counts[i] >>= 1;
	} else
	    counts[idx]++;

	lastc = c;
    }

    return (0);
}


/* deal with control characters in a constructive manner */
#ifdef __STDC__
static char *print_val(int val)
#else
static char *
print_val(val)
int val;
#endif
{
    static char result[5];
    int i, c1, c2;

    c1 = (val >> 8) & 0xff;		/* hi byte comes first in stream */
    c2 = val & 0xff;

    if (c1 < 0x20) {
	result[0] = '^';
	result[1] = c1 + 0x40;
	i = 2;
    } else {
	result[0] = c1;
	i = 1;
    }
    if (c2 < 0x20) {
	result[i] = '^';
	result[i+1] = c2 + 0x40;
	i += 2;
    } else {
	result[i] = c2;
	i++;
    }
    result[i] = '\0';

    return (result);
}


/*
 * Print the 128 most common pairs
 *
 * There's no really simple way to do this quickly, so I just construct a
 * list of the 128 most frequent entries and plow through it 32768 times.
 * Since we can ignore zero-frequency entries, this is faster than plowing
 * through the entire array 128 times.
 *
 * A better scheme might be to handle this as the data is coming in, perhaps
 * by organizing the array of frequencies in a heap.  However, I want to keep
 * it simple, and this also has the advantage of working in constant time
 * regardless of the size of the input.  Another idea is to sort the array
 * of 128 entries so that a binary search will cut the number of comparisons
 * down, but reordering the array in an efficient manner while keeping the
 * searches fast requires more code than I want to write just now.
 */
#ifdef __STDC__
void print_results(void)
#else
void
print_results()
#endif
{
    int i, j, rep_idx;
    unsigned short rep_cnt;
    struct {
	int index;		/* index from 0 to 32767; okay for 16 bits */
	unsigned short count;
    } best[128];

    for (j = 0; j < 128; j++) {
	best[j].index = -1;
	best[j].count = 0;
    }

    for (i = 0; i < 65536; i++) {
	if (!counts[i]) continue;
	    /*
	     * If this entry is larger than something in the table, then we
	     * want to replace the smallest entry in the table with it.
	     *
	     * (Note that this won't trigger if the counts are equal; the
	     * choice between two pairs with equal frequency is arbitrarily
	     * made according to numeric value.)
	     */
	rep_idx = -1;
	rep_cnt = 65535;
	for (j = 0; j < 128; j++) {
	    if (counts[i] > best[j].count && rep_cnt > best[j].count) {
		rep_idx = j;
		rep_cnt = best[j].count;
	    }
	}

	if (rep_idx >= 0) {
	    best[rep_idx].index = i;
	    best[rep_idx].count = counts[i];
	}
    }

    /* okay, we now have a table of (up to) 128 entries.  Print them. */
    printf("/*\n * digram frequency table\n */\n\n");
    printf("unsigned short frequent[128] = {");
    for (j = 0; j < 128; j++) {
	if (!(j % 2)) printf("\n    ");
        if (best[j].index < 0) continue;	/* empty slot */

	printf("0x%.4x /*%-4s %-5d*/,    ", best[j].index,
	    print_val(best[j].index), best[j].count);
    }
    printf("\n};\n\n");
}


#ifdef __STDC__
int main(int argc, char *argv[])
#else
int
main(argc, argv)
int argc;
char *argv[];
#endif
{
    FILE *fp;
    int i;

    if (argc != 2) {
	fprintf(stderr, "usage: %s filename\n", argv[0]);
	exit(2);
    }

    /* initialize all counts to zero */
    for (i = 0; i < 65536; i++)
	counts[i] = 0;

    if ((fp = fopen(argv[1], READ_BINARY)) == NULL) {
	fprintf(stderr, "fopen failed, err=%d\n", errno);
	exit(1);
    }

    if (do_scan(fp) < 0) {
	fprintf(stderr, "FAILED\n");
	fclose(fp);
	exit(1);
    }
    fclose(fp);

    print_results();

    exit(0);
}

