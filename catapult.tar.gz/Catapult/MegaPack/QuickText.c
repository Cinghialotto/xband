/*
 * QuickText.c - quick text compression
 *
 * Based on an idea from MacWrite, as described in Bell/Cleary/Witten.
 * Enhanced to strip off the high bit as well.
 *
 * Use of RLE recommended, use of remapping required.
 */
#include <stdio.h>
#ifdef UNIX
# include <sys/types.h>
#else
# include "UnixStuff.h"
#endif
#include <string.h>

#include "MegaPack.h"
#include "MegaPackPriv.h"

PRIVATE long QTCompressDigram(const u_char *plain, u_char *enc, long size, u_long flags, BestData *bestBuf);
PRIVATE long QTCompressNoDigram(const u_char *plain, u_char *enc, long size, u_long flags, BestData *bestBuf);
PRIVATE int QTLookupDigram(int ic1, int ic2);
PRIVATE long QTCountOccurrences(const u_char *data, long size, const char *set, u_long flags);

PRIVATE long QTExpandNoDigram(register BitContext *ctxtp, register ByteContext *bytxtp, u_char *plain, register char *commonChars);
PRIVATE long QTExpandDigram(register BitContext *ctxtp, register ByteContext *bytxtp, u_char *plain, register char *commonChars);



//
// Output format:
//
// First bit is clear if we're using "lo" chars, set if we're using "hi"
// chars (see character frequency discussion below).
//
// Output is a bitstream with 4-bit values.  If the value is 0x0f, then the
// next 7 bits are the low-ASCII character to output.  Otherwise, it's an
// index into the commonChars array.
//
// If the 7-bit value following a 0x0f is kRestIsPlain (0x7f), then we
// encountered an 8-bit value in the input, and the rest of the stream is
// composed of 8-bit values copied from the source.
//

//
// A generated huffman distribution shows:
//	e <space>
//	ainost
//	cdhlr
//
// That's 13 chars, need two more.  The traditional wisdom from printers
// is "etaoin shrdlu", but it turns out 'c' is more common than 'u', and in
// fact MacWrite used " etnroaisdlhcfp".
//
// Because some people tend to express themselves entirely in ALL CAPS, we
// need two sets of common chars depending on which they do.
//
PRIVATE char commonCharsLo[16] = " etaoinshrdlcfp";
PRIVATE char commonCharsHi[16] = " ETAOINSHRDLCFP";


// ===========================================================================
//		Compression
// ===========================================================================

//
// Compression entry point.
//
long
CompressQuickText(const u_char *plain, u_char *enc, long size, u_long flags, BestData *bestBuf)
{
	BestData fakeBestBuf1, fakeBestBuf2;
	long dresult, nodresult;

	if (bestBuf->bestFlag) {
		// Already been here, do the best one.
		//
		if (!bestBuf->bestData[1]) {
			if (verbose)
				DBUG(("    Using digrams\n"));
			return (QTCompressNoDigram(plain, enc, size, flags, bestBuf));
		} else {
			if (verbose)
				DBUG(("    Using digrams\n"));
			return (QTCompressDigram(plain, enc, size, flags, bestBuf));
		}
	} else {
		// Try it both ways.
		//
		fakeBestBuf1.bestFlag = 0;
		nodresult = QTCompressNoDigram(plain, enc, size, flags, &fakeBestBuf1);
		fakeBestBuf2.bestFlag = 0;
		dresult = QTCompressDigram(plain, enc, size, flags, &fakeBestBuf2);

		// Total failure?
		//
		if ((nodresult == -1) && (dresult == -1))
			return (-1);

		if (dresult <= nodresult) {
			if (verbose)
				DBUG(("    Best of QT was 'digram'\n"));
			*bestBuf = fakeBestBuf2;
			return (dresult);
		} else {
			if (verbose)
				DBUG(("    Best of QT was 'no digram'\n"));
			*bestBuf = fakeBestBuf1;
			return (nodresult);
		}
	}
	/*NOTREACHED*/
}


//
// Compress, without digrams.
//
PRIVATE long
QTCompressNoDigram(const u_char *plain, u_char *enc, long size, u_long flags, BestData *bestBuf)
{
	BitContext ctxt;
	ByteContext bytxt;
	int loCount, hiCount;
	u_char *end;
	register int j, ic;
	register char *cc, *commonChars = NULL;

	// Init the output context.
	//
	InitBits16(&ctxt, enc, kMPoutputContext);

	if (bestBuf->bestFlag) {
		// Already been here, grab the info out of bestBuf.
		//
		if (!bestBuf->bestData[0]) {
			commonChars = commonCharsLo;
			OutputBits16(&ctxt, 0, 1);
		} else {
			commonChars = commonCharsHi;
			OutputBits16(&ctxt, 0x8000, 1);
		}
		OutputBits16(&ctxt, 0, 1);
	} else {
		// Step 1: count the #of chars that occur in the "lo" set.
		//
		loCount = QTCountOccurrences(plain, size, commonCharsLo, flags);

		// Step 2: count the #of chars that occur in the "hi" set.
		//
		hiCount = QTCountOccurrences(plain, size, commonCharsHi, flags);

		if (loCount >= hiCount) {
			commonChars = commonCharsLo;
			OutputBits16(&ctxt, 0, 1);
			bestBuf->bestData[0] = 0;
		} else {
			commonChars = commonCharsHi;
			OutputBits16(&ctxt, 0x8000, 1);
			bestBuf->bestData[0] = 1;
		}

		LDBUG(2, ("    loCount = %d, hiCount = %d\n", loCount, hiCount));

		// Indicate that we're not doing digram coding.
		//
		OutputBits16(&ctxt, 0, 1);
		bestBuf->bestData[1] = 0;
	}

	// Init the input context.
	//
	InitByte(&bytxt, plain, size, flags);

	while (1) {
		ic = GetByte(&bytxt);
		if (ic == -1)	// done!
			break;
		if (ic == kRestIsPlain) {
			// Nuts, just pass the rest through.
			//
			LDBUG(1, ("    Encountered unmappable char 0x%.2x at byte %d\n",
				*(GetBytePointer(&bytxt)), GetBytePointer(&bytxt) - plain));
			OutputBits16(&ctxt, 0xf000, 4);
			OutputBits16(&ctxt, kRestIsPlain << 9, 7);

			// Now just loop until empty.
			//
			while (1) {
				ic = GetByte(&bytxt);
				if (ic == -1)
					break;
				OutputBits16(&ctxt, ic << 8, 8);
			}
			break;
		}

		for (j = 0, cc = commonChars; j < 16; j++)
			if (ic == *cc++) {
				OutputBits16(&ctxt, j << 12, 4);
				break;
			}
		if (j >= 16) {
			ic = 0xf000 | (ic << 5);
			OutputBits16(&ctxt, ic, 4+7);
			//OutputBits16(&ctxt, 0xf000, 4);
			//OutputBits16(&ctxt, ic << 9, 7);
		}
	}

	FlushBits16(&ctxt);
	end = GetBitPointer(&ctxt);
	LDBUG(1, ("    Output is %d bytes\n", end - enc));
	return (end - enc);
}

//
// Compress, with digrams.
//
PRIVATE long
QTCompressDigram(const u_char *plain, u_char *enc, long size, u_long flags, BestData *bestBuf)
{
	BitContext ctxt;
	ByteContext bytxt;
	int loCount, hiCount;
	u_char *end;
	char *commonChars = NULL;
	int outs, outl, digram;
	register int j, ic, outc;
	register char *cc;

	// Init the output context.
	//
	InitBits16(&ctxt, enc, kMPoutputContext);

	if (bestBuf->bestFlag) {
		// Already been here, grab the info out of bestBuf.
		//
		if (!bestBuf->bestData[0]) {
			commonChars = commonCharsLo;
			OutputBits16(&ctxt, 0, 1);
		} else {
			commonChars = commonCharsHi;
			OutputBits16(&ctxt, 0x8000, 1);
		}
		OutputBits16(&ctxt, 0x8000, 1);
	} else {
		// Step 1: count the #of chars that occur in the "lo" set.
		//
		loCount = QTCountOccurrences(plain, size, commonCharsLo, flags);

		// Step 2: count the #of chars that occur in the "hi" set.
		//
		hiCount = QTCountOccurrences(plain, size, commonCharsHi, flags);

		if (loCount >= hiCount) {
			commonChars = commonCharsLo;
			OutputBits16(&ctxt, 0, 1);
			bestBuf->bestData[0] = 0;
		} else {
			commonChars = commonCharsHi;
			OutputBits16(&ctxt, 0x8000, 1);
			bestBuf->bestData[0] = 1;
		}

		LDBUG(2, ("    loCount = %d, hiCount = %d\n", loCount, hiCount));

		// Indicate that we are doing digram coding.
		//
		OutputBits16(&ctxt, 0x8000, 1);
		bestBuf->bestData[1] = 1;
	}

	// Init the input context.
	//
	InitByte(&bytxt, plain, size, flags);

	// Several different ways to do this; cleanest uses gotos.  If you
	// have a problem with that, rewrite it yourself ya shmuck.
	//
	outl = outs = -1;
	while (1) {
		ic = GetByte(&bytxt);
		if (ic == -1) break;		// done
		if (ic == kRestIsPlain)		// illegal char
			goto rest_is_plain;

		outl = ic;
		outs = -1;
		for (j = 0, cc = commonChars; j < 16; j++)
			if (ic == *cc++) {
				outs = j;
				break;
			}

got_one:
		// 2nd char
		//
		ic = GetByte(&bytxt);
		if (ic == -1 || ic == kRestIsPlain) {
			// Output the lingering char before moving on.
			if (outs != -1) {
				OutputBits16(&ctxt, outs << 12, 4);
			} else {
				outc = 0xf000 | (outl << 4);
				OutputBits16(&ctxt, outc, 4+8);
			}
		}
		if (ic == -1) break;		// done
		if (ic == kRestIsPlain)		// illegal char
			goto rest_is_plain;

		for (j = 0, cc = commonChars; j < 16; j++)
			if (ic == *cc++) {
				break;
			}
		if (j >= 16) j = -1;

		if ((j != -1) && (outs != -1)) {
			// Both were small, we lose ground with digrams.  Output the
			// first and rotate back.
			//
			OutputBits16(&ctxt, outs << 12, 4);
			outl = ic;
			outs = j;
			goto got_one;
		} else {
			// Look for a digram.  If we don't find one, output the first
			// char and rotate back.  If we do find one, output the digram
			// and go all the way back to the top of the loop.
			//
			if ((digram = QTLookupDigram(outl, ic)) != -1) {
				outc = 0xf800 | (digram << 4);
				OutputBits16(&ctxt, outc, 4+8);
				// fall through
			} else {
				if (outs != -1) {
					OutputBits16(&ctxt, outs << 12, 4);
				} else {
					outc = 0xf000 | (outl << 4);
					OutputBits16(&ctxt, outc, 4+8);
				}
				outl = ic;
				outs = j;
				goto got_one;
			}
		}
	}

done:
	FlushBits16(&ctxt);
	end = GetBitPointer(&ctxt);
	LDBUG(1, ("    Output is %d bytes\n", end - enc));
	return (end - enc);

rest_is_plain:
	// This used to be part of the loop, but the loop got rearranged.
	//
	LDBUG(1, ("    Encountered unmappable char 0x%.2x at byte %d\n",
		*(GetBytePointer(&bytxt)), GetBytePointer(&bytxt) - plain));
	OutputBits16(&ctxt, 0xf000, 4);
	OutputBits16(&ctxt, kRestIsPlain << 8, 8);

	// Now just loop until empty.
	//
	while (1) {
		ic = GetByte(&bytxt);
		if (ic == -1)
			break;
		OutputBits16(&ctxt, ic << 8, 8);
	}
	goto done;
}


//
// Count the #of occurrences of characters from "set" in "data".
//
// Stops when it hits a character >= kRestIsPlain.
// Remaps if the remap flag is set.
//
PRIVATE long
QTCountOccurrences(const u_char *data, long size, const char *set, u_long flags)
{
	ByteContext bytxt;
	register int remap = flags & kMPremapText;
	register int ic;
	register long count = 0;

	// Init the input context.
	//
	InitByte(&bytxt, data, size, flags);

	// Read until EOF.
	//
	while (1) {
		if (remap) {
			ic = GetByte(&bytxt);
			if (ic == kRestIsPlain) {
				ic = GetByte(&bytxt);
				LDBUG(1, ("    Scan encountered unmappable char (0x%.2x)\n",
					ic));
				return (count);
			}
		} else
			ic = GetByte(&bytxt);

		if (ic == -1)			// EOF reached
			return (count);

		if (ic >= kRestIsPlain) {
			LDBUG(1, ("    Scan encountered char >= 0x%.2x (0x%.2x)\n",
				kRestIsPlain, ic));
			break;
		}

		if (strchr(set, (char)ic) != NULL)
			count++;
		data++;
	}

	return (count);
}

#define kDigramTabSize	128
//
// Look up two chars in the digram table.  Returns the index (0-127) if
// found, -1 if not.
//
// "ic1" is the character appearing first in the input.
//
PRIVATE int
QTLookupDigram(int ic1, int ic2)
{
	register int i;
	register u_short lkup;

	lkup = (ic1 << 8) | ic2;

	for (i = 0; i < kDigramTabSize; i++)
		if (qtDigramTab[i] == lkup)
			return (i);
	return (-1);
}


// ===========================================================================
//		Expansion
// ===========================================================================

//
// Expansion entry point.
//
long
ExpandQuickText(const u_char *enc, u_char *plain, long encSize, long plainSize, u_long flags)
{
	char *commonChars;
	BitContext ctxt;
	ByteContext bytxt;

	// Init the input context.
	//
	InitBits16(&ctxt, enc, kMPinputContext);

	// Init the output context.
	//
	InitByte(&bytxt, plain, plainSize, flags);

	if (InputBits16(&ctxt, 1))
		commonChars = commonCharsHi;
	else
		commonChars = commonCharsLo;

	if (!InputBits16(&ctxt, 1))
		return (QTExpandNoDigram(&ctxt, &bytxt, plain, commonChars));
	else
		return (QTExpandDigram(&ctxt, &bytxt, plain, commonChars));
}

//
// Do the QuickText expansion, using 7-bit characters instead of digrams.
//
PRIVATE long
QTExpandNoDigram(register BitContext *ctxtp, register ByteContext *bytxtp,
	u_char *plain, register char *commonChars)
{
	register u_short val;

	// We output one character through each iteration of this loop.
	//
	while (1) {
		val = InputBits16(ctxtp, 4);
		if (val == 0xf000) {
			// Next 7 bits are the character.
			//
			val = InputBits16(ctxtp, 7) >> 9;
			if (val == kRestIsPlain) {
				// Go into stupid mode.
				//
				LDBUG(1, ("    Found 0x%.2x in input at byte %d, switching to guns\n",
					val, GetBytePointer(bytxtp) - plain));
				if (PutByte(bytxtp, kRestIsPlain) != 0)
					break;
				while (1) {
					val = InputBits16(ctxtp, 8) >> 8;
					if (PutByte(bytxtp, val) != 0)
						break;
				}
				break;

			} else
				if (PutByte(bytxtp, val) != 0)
					break;

		} else {
			if (PutByte(bytxtp, *(commonChars + (val >> 12))) != 0)
				break;
		}
	}

	return (GetBytePointer(bytxtp) - plain);
}

//
// Do the QuickText expansion, using digrams.
//
PRIVATE long
QTExpandDigram(register BitContext *ctxtp, register ByteContext *bytxtp,
	u_char *plain, register char *commonChars)
{
	register u_short val, digram;

	// We output one character through each iteration of this loop.
	//
	while (1) {
		val = InputBits16(ctxtp, 4);
		if (val == 0xf000) {
			// Next 8 bits are the character or the digram.
			//
			val = InputBits16(ctxtp, 8) >> 8;
			if (val == kRestIsPlain) {
				// Go into stupid mode.
				//
				LDBUG(1, ("    Found 0x%.2x in input at byte %d, switching to guns\n",
					val, GetBytePointer(bytxtp) - plain));
				if (PutByte(bytxtp, kRestIsPlain) != 0)
					break;
				while (1) {
					val = InputBits16(ctxtp, 8) >> 8;
					if (PutByte(bytxtp, val) != 0)
						break;
				}
				break;

			} else {
				if (val & 0x0080) {
					// Found a digram.
					//
					digram = qtDigramTab[val & 0x7f];
					if (PutByte(bytxtp, digram >> 8) != 0) {
						fprintf(stderr, "ERROR: split digram\n");
						return (-1);
						break;
					}
					if (PutByte(bytxtp, digram & 0x7f) != 0)
						break;
				} else {
					// Found a char.
					//
					if (PutByte(bytxtp, val) != 0)
						break;
				}
			}

		} else {
			if (PutByte(bytxtp, *(commonChars + (val >> 12))) != 0)
				break;
		}
	}

	return (GetBytePointer(bytxtp) - plain);
}

