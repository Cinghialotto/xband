/*
 * Huff.c - Huffman compression with static tables
 *
 * Portions derived from "unzip.c" in gzip-1.2.4.
 *
 * Assumes that the static Huffman tables have a max_len less <= 16 bits.
 * Anything other than that is going to choke on a SNES anyway.
 *
 * RLE optional (probably won't hurt), remapping depends on Huffman table
 */
#include <stdio.h>
#ifdef UNIX
# include <sys/types.h>
#else
# include "UnixStuff.h"
#endif

#include "MegaPack.h"
#include "MegaPackPriv.h"
#include "HuffTable.h"

PRIVATE long SHCompress(const u_char *plain, u_char *enc, long size, u_long flags, HuffTable *huffTable);
PRIVATE int BuildPeekTable(HuffTable *huffTable, u_char *ptab, int peekBits);



// ===========================================================================
//		Compression
// ===========================================================================

long
CompressHuff(const u_char *plain, u_char *enc, long size, u_long flags, BestData *best)
{
	long result, bestResult = -1;
	int i, bestMode;

	// Try different Huffman tables until we find the best one.
	//
	if (best->bestFlag) {
		bestMode = best->bestData[0] - '0';
		if (bestMode < 0 || bestMode > NELEM(huffTab)) {
			fprintf(stderr, "Huff: unknown best setting 0x%.2x.\n",
				best->bestData[0]);
			return (-1);
		}
		bestResult = SHCompress(plain, enc, size, flags, &huffTab[bestMode]);

	} else {
		bestMode = -1;
		for (i = 0 ; i < NELEM(huffTab); i++) {
			result = SHCompress(plain, enc, size, flags, &huffTab[i]);
			if ((result != -1) && ((bestResult == -1) || (result < bestResult)))
			{
				bestResult = result;
				bestMode = i + '0';
			}
		}

		best->bestData[0] = bestMode;
	}

	return (bestResult);
}


//
// Do the actual compression.
//
PRIVATE long
SHCompress(const u_char *plain, u_char *enc, long size, u_long flags, HuffTable *huffTable)
{
	BitContext ctxt;
	ByteContext bytxt;
	u_char *end;
	int ic;

	// Init the output context.
	//
	InitBits16(&ctxt, enc, kMPoutputContext);

	// Init the input context.
	//
	InitByte(&bytxt, plain, size, flags);

	OutputBits16(&ctxt, (unsigned short)huffTable->index << 8, 8);
	LDBUG(1, ("    Using table '%c'\n", huffTable->index));

	while (1) {
		if ((ic = GetByte(&bytxt)) == -1)
			break;
		if (!huffTable->code_lengths[ic]) {
			// Could do a kRestIsPlain here, but if the table is fully
			// populated it can't happen.
			//
			fprintf(stderr, "Huff: invalid input byte 0x%.2x\n", ic);
			return (-1);
		}
		LDBUG(2, ("      Output %d:0x%.2x as 0x%.4x/%d (@0x%.4x)\n",
			GetBytePointer(&bytxt) - plain -1, ic, huffTable->bit_pats[ic],
				huffTable->code_lengths[ic], GetBitPointer(&ctxt) - enc));
		OutputBits16(&ctxt, huffTable->bit_pats[ic],
			huffTable->code_lengths[ic]);
	}

	// Output the end marker.
	//
	OutputBits16(&ctxt, huffTable->bit_pats[256], huffTable->code_lengths[256]);
	FlushBits16(&ctxt);
	end = GetBitPointer(&ctxt);

	LDBUG(1, ("    Output is %d bytes\n", end - enc));
	return (end - enc);
}



// ===========================================================================
//		Expansion
// ===========================================================================

// This defines how large our hash table is.  Space required is
// (2^kMaxPeekBits) * sizeof(unsigned short).  If we can't use RAM on the
// box we can precompute the tables and put them in ROM, or just do without
// them entirely, though that will make things run more slowly.
//
// Due to a limitation in PeekBits16, this can be no more than 9.
//
#define kMaxPeekBits	8


long
ExpandHuff(const u_char *enc, u_char *plain, long encSize, long plainSize, u_long flags)
{
	static u_char peekTable[1 << kMaxPeekBits];
	BitContext ctxt;
	ByteContext bytxt;
	u_short eob;
	register HuffTable *huffTable;
	register u_short us;
	register int peekBits, len;

	// Initialize the input context.
	//
	InitBits16(&ctxt, enc, kMPinputContext);

	// Initialize the output context.
	//
	InitByte(&bytxt, plain, plainSize, flags);

	// First byte is which table we're using.  This could be stored more
	// efficiently.
	//
	us = InputBits16(&ctxt, 8) >> 8;
	LDBUG(1, ("    Using table '%c'\n", us));
	huffTable = &huffTab[us - '0'];

	// Build the hash table.
	//
	peekBits = (huffTable->max_len < kMaxPeekBits) ?
		huffTable->max_len : kMaxPeekBits;
	BuildPeekTable(huffTable, peekTable, peekBits);

	/* The eob code is the largest code among all leaves of maximal length: */
	eob = huffTable->leaves[huffTable->max_len] - 1;
	LDBUG(2, ("    eob %d 0x%x\n", huffTable->max_len, eob));

	while (1) {
		us = PeekBits16(&ctxt, peekBits) >> (16 - peekBits);
		len = peekTable[us];
		if (len > 0) {
			// Found it.  Read just those bits, and right-align them
			// (InputBits reads things aligned with the left edge of the word).
			//
			us = InputBits16(&ctxt, len) >> (16 - len);
		} else {
			// It's longer than peekBits, so we need to step down the tree.
			//
			// This formerly straightforward loop got messed up because
			// of a limitation in PeekBits16 (which can look forward at
			// most 9 bits).
			//
			u_short us2 = InputBits16(&ctxt, peekBits) >> (16 - peekBits);

			len = 0;
			do {
				len++;
				us = (us2 << len) |
					PeekBits16(&ctxt, len) >> (16 - len);
			} while (us < (u_short) huffTable->parents[len + peekBits]);
			/* loop as long as peek is a parent node */

			(void) InputBits16(&ctxt, len);		// skip them bits

			len += peekBits;
		}
		LDBUG(2, ("    len=%d, us=0x%.4x\n", len, us));

		if (us == eob && len == huffTable->max_len)
			break;		/* looks like EOF */
		PutByte(&bytxt, huffTable->huff_lits[us + huffTable->lit_base[len]]);
		LDBUG(2, ("      %d: char = 0x%.2x (idx %d)\n",
			GetBytePointer(&bytxt) - plain -1,
			huffTable->huff_lits[us + huffTable->lit_base[len]],
			us + huffTable->lit_base[len]));

		if (GetBytePointer(&bytxt) - plain > plainSize) {
			fprintf(stderr, "ERROR: Huff: too much output\n");
			break;
		}
		if (GetBitPointer(&ctxt) - enc > encSize) {
			fprintf(stderr, "ERROR: Huff: too far in input\n");
			break;
		}
	}
	return (GetBytePointer(&bytxt) - plain);
}


PRIVATE int
BuildPeekTable(HuffTable *huffTable, u_char *ptab, int peekBits)
{
	register u_char *prefixp;
	int len;

	LDBUG(2, ("      Constructing peek table (%d bits)\n", peekBits));

	prefixp = &ptab[1<<peekBits];
	for (len = 1; len <= peekBits; len++) {
		int prefixes;
		
		prefixes = huffTable->leaves[len] << (peekBits-len); /* may be 0 */
		while (prefixes--)
			*--prefixp = (u_char)len;
	}

	/* The length of all other codes is unknown: */
	while (prefixp > ptab)
		*--prefixp = 0;

	return (0);
}

