#define TEST
/*
 * @(#) sega_lzss.c 1.1@(#)
 */

/*
	File:		sega_lzss.c

	Contains:	xxx put contents here xxx

	Written by:	Andy McFadden

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	10/31/94	ATM		first checked in

	To Do:
*/

/**************************************************************
    LZSS.C -- A Data Compression Program
    (tab = 4 spaces)
***************************************************************
    4/6/1989 Haruhiko Okumura
    Use, distribute, and modify this program freely.
    Please send me your improved versions.
         PC-VAN         SCIENCE
         NIFTY-Serve    PAF01022
         CompuServe     74050,1022
**************************************************************/

//
// CRC routines, stolen from comm layer
//

unsigned long _ccitt_updcrc(unsigned int icrc, unsigned char *icp, int icnt);


unsigned long ccitt_crcinit = 65535;

static unsigned short crctab[256] = {
	0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50a5, 0x60c6, 0x70e7,
	0x8108, 0x9129, 0xa14a, 0xb16b, 0xc18c, 0xd1ad, 0xe1ce, 0xf1ef,
	0x1231, 0x0210, 0x3273, 0x2252, 0x52b5, 0x4294, 0x72f7, 0x62d6,
	0x9339, 0x8318, 0xb37b, 0xa35a, 0xd3bd, 0xc39c, 0xf3ff, 0xe3de,
	0x2462, 0x3443, 0x0420, 0x1401, 0x64e6, 0x74c7, 0x44a4, 0x5485,
	0xa56a, 0xb54b, 0x8528, 0x9509, 0xe5ee, 0xf5cf, 0xc5ac, 0xd58d,
	0x3653, 0x2672, 0x1611, 0x0630, 0x76d7, 0x66f6, 0x5695, 0x46b4,
	0xb75b, 0xa77a, 0x9719, 0x8738, 0xf7df, 0xe7fe, 0xd79d, 0xc7bc,
	0x48c4, 0x58e5, 0x6886, 0x78a7, 0x0840, 0x1861, 0x2802, 0x3823,
	0xc9cc, 0xd9ed, 0xe98e, 0xf9af, 0x8948, 0x9969, 0xa90a, 0xb92b,
	0x5af5, 0x4ad4, 0x7ab7, 0x6a96, 0x1a71, 0x0a50, 0x3a33, 0x2a12,
	0xdbfd, 0xcbdc, 0xfbbf, 0xeb9e, 0x9b79, 0x8b58, 0xbb3b, 0xab1a,
	0x6ca6, 0x7c87, 0x4ce4, 0x5cc5, 0x2c22, 0x3c03, 0x0c60, 0x1c41,
	0xedae, 0xfd8f, 0xcdec, 0xddcd, 0xad2a, 0xbd0b, 0x8d68, 0x9d49,
	0x7e97, 0x6eb6, 0x5ed5, 0x4ef4, 0x3e13, 0x2e32, 0x1e51, 0x0e70,
	0xff9f, 0xefbe, 0xdfdd, 0xcffc, 0xbf1b, 0xaf3a, 0x9f59, 0x8f78,
	0x9188, 0x81a9, 0xb1ca, 0xa1eb, 0xd10c, 0xc12d, 0xf14e, 0xe16f,
	0x1080, 0x00a1, 0x30c2, 0x20e3, 0x5004, 0x4025, 0x7046, 0x6067,
	0x83b9, 0x9398, 0xa3fb, 0xb3da, 0xc33d, 0xd31c, 0xe37f, 0xf35e,
	0x02b1, 0x1290, 0x22f3, 0x32d2, 0x4235, 0x5214, 0x6277, 0x7256,
	0xb5ea, 0xa5cb, 0x95a8, 0x8589, 0xf56e, 0xe54f, 0xd52c, 0xc50d,
	0x34e2, 0x24c3, 0x14a0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
	0xa7db, 0xb7fa, 0x8799, 0x97b8, 0xe75f, 0xf77e, 0xc71d, 0xd73c,
	0x26d3, 0x36f2, 0x0691, 0x16b0, 0x6657, 0x7676, 0x4615, 0x5634,
	0xd94c, 0xc96d, 0xf90e, 0xe92f, 0x99c8, 0x89e9, 0xb98a, 0xa9ab,
	0x5844, 0x4865, 0x7806, 0x6827, 0x18c0, 0x08e1, 0x3882, 0x28a3,
	0xcb7d, 0xdb5c, 0xeb3f, 0xfb1e, 0x8bf9, 0x9bd8, 0xabbb, 0xbb9a,
	0x4a75, 0x5a54, 0x6a37, 0x7a16, 0x0af1, 0x1ad0, 0x2ab3, 0x3a92,
	0xfd2e, 0xed0f, 0xdd6c, 0xcd4d, 0xbdaa, 0xad8b, 0x9de8, 0x8dc9,
	0x7c26, 0x6c07, 0x5c64, 0x4c45, 0x3ca2, 0x2c83, 0x1ce0, 0x0cc1,
	0xef1f, 0xff3e, 0xcf5d, 0xdf7c, 0xaf9b, 0xbfba, 0x8fd9, 0x9ff8,
	0x6e17, 0x7e36, 0x4e55, 0x5e74, 0x2e93, 0x3eb2, 0x0ed1, 0x1ef0,
};

unsigned long _ccitt_updcrc(unsigned int icrc, unsigned char *icp, int icnt)
{
#define M1 0xff
#define M2 0xff00
	register unsigned int crc = icrc;
	register unsigned char *cp = icp;
	register int cnt = icnt;

	while(cnt--) {
		crc=((crc<<8)&M2)^crctab[((crc>>8)&0xff)^*cp++];
	}

	return(crc);
}


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define EXIT_FAILURE 1
#define EXIT_SUCCESS 0

#define N           4096     /* size of ring buffer */
#define F             18     /* upper limit for match_length */
#define THRESHOLD  2   /* encode string into position and length
if match_length is greater than this */
#define NIL             N    /* index for root of binary search trees */

unsigned long int
textsize = 0,  /* text size counter */
codesize = 0,  /* code size counter */
printcount = 0;     /* counter for reporting progress every 1K bytes */
unsigned char
text_buf[N + F - 1];     /* ring buffer of size N,
              with extra F-1 bytes to facilitate string comparison */
int      match_position, match_length,  /* of longest match.  These are
              set by the InsertNode() procedure. */
lson[N + 1], rson[N + 257], dad[N + 1];  /* left & right children &
              parents -- These constitute binary search trees. */

#define SEGA_BUF_SIZE	32768

void InitTree(void)  /* initialize trees */
{
	int  i;

	/* For i = 0 to N - 1, rson[i] and lson[i] will be the right and
       left children of node i.  These nodes need not be initialized.
       Also, dad[i] is the parent of node i.  These are initialized to
       NIL (= N), which stands for 'not used.'
       For i = 0 to 255, rson[N + i + 1] is the root of the tree
       for strings that begin with character i.  These are initialized
       to NIL.  Note there are 256 trees. */

	for (i = N + 1; i <= N + 256; i++) rson[i] = NIL;
	for (i = 0; i < N; i++) dad[i] = NIL;
}

void InsertNode(int r)
/* Inserts string of length F, text_buf[r..r+F-1], into one of the
       trees (text_buf[r]'th tree) and returns the longest-match position
       and length via the global variables match_position and match_length.
       If match_length = F, then removes the old node in favor of the new
       one, because the old one will be deleted sooner.
       Note r plays double role, as tree node and position in buffer. */
{
	register int  i, p, cmp;
	register unsigned char  *key;

	cmp = 1;  
	key = &text_buf[r];  
	p = N + 1 + key[0];
	rson[r] = lson[r] = NIL;  
	match_length = 0;
	for ( ; ; ) {
		if (cmp >= 0) {
			if (rson[p] != NIL) p = rson[p];
			else {  
				rson[p] = r;  
				dad[r] = p;  
				return;  
			}
		} else {
			if (lson[p] != NIL) p = lson[p];
			else {  
				lson[p] = r;  
				dad[r] = p;  
				return;  
			}
		}
		for (i = 1; i < F; i++)
			if ((cmp = key[i] - text_buf[p + i]) != 0)  break;
		if (i > match_length) {
			match_position = p;
			if ((match_length = i) >= F)  break;
		}
	}
	dad[r] = dad[p];  
	lson[r] = lson[p];  
	rson[r] = rson[p];
	dad[lson[p]] = r;  
	dad[rson[p]] = r;
	if (rson[dad[p]] == p) rson[dad[p]] = r;
	else lson[dad[p]] = r;
	dad[p] = NIL;  /* remove p */
}

void DeleteNode(int p)  /* deletes node p from tree */
{
	register int  q;

	if (dad[p] == NIL) return;  /* not in tree */
	if (rson[p] == NIL) q = lson[p];
	else if (lson[p] == NIL) q = rson[p];
	else {
		q = lson[p];
		if (rson[q] != NIL) {
			do {  
				q = rson[q];  
			} while (rson[q] != NIL);
			rson[dad[q]] = lson[q];  
			dad[lson[q]] = dad[q];
			lson[q] = lson[p];  
			dad[lson[p]] = q;
		}
		rson[q] = rson[p];  
		dad[rson[p]] = q;
	}
	dad[q] = dad[p];
	if (rson[dad[p]] == p) rson[dad[p]] = q;  
	else lson[dad[p]] = q;
	dad[p] = NIL;
}

//
// Compressed from in_buf to out_buf.
//
// Returns the compressed length.
//
short Encode(unsigned char *in_buf, short uncr_length, unsigned char *out_buf)
{
	register int i, len;
	int  c, r, s, last_match_length, code_buf_ptr;
	unsigned char  code_buf[17], mask;
	unsigned short sega_crc = ccitt_crcinit;
	long write_offset = 0;
	unsigned char *in_start = in_buf;
	unsigned char *out_start = out_buf;

	// SEGA: write a two-byte length word at the start, and leave space
	// for the CRC
	sega_crc = _ccitt_updcrc(ccitt_crcinit, in_buf, uncr_length);
	*(short *)out_buf = sega_crc;
	out_buf += 2;
	*(short *)out_buf = uncr_length;
	out_buf += 2;

	InitTree();  /* initialize trees */
	code_buf[0] = 0;  /* code_buf[1..16] saves eight units of code, and
         code_buf[0] works as eight flags, "1" representing that the unit
         is an unencoded letter (1 byte), "0" a position-and-length pair
	         (2 bytes).  Thus, eight units require at most 16 bytes of code. */
	code_buf_ptr = mask = 1;
	s = 0;  
	r = N - F;
	for (i = s; i < r; i++) text_buf[i] = ' ';  /* Clear the buffer with
	         any character that will appear often. */
	for (len = 0; len < F && (in_buf - in_start < uncr_length); len++) {
		c = *in_buf++;
		text_buf[r + len] = c;  /* Read F bytes into the last F bytes of
	              the buffer */
	}
	if ((textsize = len) == 0) return;  /* text of size zero */
	// SEGA: we don't have a circular buffer, so don't do this
	//for (i = 1; i <= F; i++) InsertNode(r - i);  /* Insert the F strings,
    //     each of which begins with one or more 'space' characters.  Note
    //     the order in which these strings are inserted.  This way,
	//     degenerate trees will be less likely to occur. */
	InsertNode(r);  /* Finally, insert the whole string just read.  The
	         global variables match_length and match_position are set. */
	do {
		if (match_length > len) match_length = len;  /* match_length
		              may be spuriously long near the end of text. */
		if (match_length <= THRESHOLD) {
			match_length = 1;  /* Not long enough match.  Send one byte. */
			code_buf[0] |= mask;  /* 'send one byte' flag */
			code_buf[code_buf_ptr++] = text_buf[r];  /* Send uncoded. */
		} else {
			// SEGA: store distance back rather than offset into circ buf
			int match_back = r - match_position;
			if (match_back < 0) match_back += N;

			//printf("match_position = %d, r/s = %d/%d, match_back = %d\n",
			//	match_position, r, s, match_back);

			code_buf[code_buf_ptr++] = (unsigned char) match_back /*match_position*/;
			code_buf[code_buf_ptr++] = (unsigned char)
			    (((match_back /*match_position*/ >> 4) & 0xf0)
			    | (match_length - (THRESHOLD + 1)));  /* Send position and
			                        length pair. Note match_length > THRESHOLD. */
		}
		if ((mask <<= 1) == 0) {  /* Shift mask left one bit. */
			for (i = 0; i < code_buf_ptr; i++)  /* Send at most 8 units of */
				*out_buf++ = code_buf[i];     /* code together */
			codesize += code_buf_ptr;
			code_buf[0] = 0;  
			code_buf_ptr = mask = 1;
		}
		last_match_length = match_length;
		for (i = 0; i < last_match_length &&
		    (in_buf - in_start < uncr_length); i++) {
			c = *in_buf++;
			DeleteNode(s);      /* Delete old strings and */
			text_buf[s] = c;    /* read new bytes */
			if (s < F - 1) text_buf[s + N] = c;  /* If the position is
                   near the end of buffer, extend the buffer to make
			                   string comparison easier. */
			s = (s + 1) & (N - 1);  
			r = (r + 1) & (N - 1);
			/* Since this is a ring buffer, increment the position
                      modulo N. */
			InsertNode(r); /* Register the string in text_buf[r..r+F-1] */
		}
		if ((textsize += i) > printcount) {
			printf("%12ld\r", textsize);  
			printcount += 1024;
			/* Reports progress each time the textsize exceeds
                      multiples of 1024. */
		}
		while (i++ < last_match_length) {  /* After the end of text, */
			DeleteNode(s);                     /* no need to read, but */
			s = (s + 1) & (N - 1);  
			r = (r + 1) & (N - 1);
			if (--len) InsertNode(r);          /* buffer may not be empty. */
		}
	} while (len > 0);  /* until length of string to be processed is zero */
	if (code_buf_ptr > 1) {       /* Send remaining code. */
		for (i = 0; i < code_buf_ptr; i++)
			*out_buf++ = code_buf[i];
		codesize += code_buf_ptr;
	}
	printf("In : %ld bytes\n", textsize);   /* Encoding is done. */
	printf("Out: %ld bytes\n", codesize);
	printf("Out/In: %.3f\n", (double)codesize / textsize);
	printf("sega_crc = 0x%.4lx\n", sega_crc);

	return (out_buf - out_start);
}



//
// Decodes from in_buf to out_buf.
//
// Returns the uncompressed size.
//
short Decode(unsigned char *in_buf, short length, unsigned char *out_buf)
{
	register int  i, j, k;
	unsigned int  flags;
	unsigned short uncr_length, uncr_crc;
	unsigned char *out_start = out_buf;

	uncr_crc = *(short *)in_buf;
	in_buf += 2;
	uncr_length = *(short *)in_buf;
	in_buf += 2;

	flags = 0;
	while (out_buf - out_start < uncr_length) {
		if (((flags >>= 1) & 256) == 0) {
			flags = (*in_buf++) | 0xff00;      /* uses higher byte cleverly */
		}                                  /* to count eight */
		if (flags & 1) {
			// single character
			*out_buf++ = *in_buf++;
		} else {
			// matched a full string
			i = *in_buf++;
			j = *in_buf++;
			i |= ((j & 0xf0) << 4);  
			j = (j & 0x0f) + THRESHOLD;
			for (k = 0; k <= j; k++) {
				*out_buf = *(out_buf - i);
				out_buf++;
			}
		}
	}

	if (_ccitt_updcrc(ccitt_crcinit, out_start, uncr_length) != uncr_crc) {
		fprintf(stderr, "CRC mismatch, calc 0x%.4x vs file 0x%.4x\n",
		    _ccitt_updcrc(ccitt_crcinit, out_start, uncr_length), uncr_crc);
	}
	if (out_buf - out_start != uncr_length) {
		fprintf(stderr, "ERROR, expected %d, got %d\n", uncr_length,
			out_buf - out_start);
	}

	return (out_buf - out_start);
}

#ifdef TEST
int main(int argc, char *argv[])
{
	FILE     *infile, *outfile;  /* input & output files */
	static char in_buf[SEGA_BUF_SIZE], out_buf[SEGA_BUF_SIZE];
	char  *s;
	long length, result_length;

	if (argc != 4) {
		printf("'lzss e file1 file2' encodes file1 into file2.\n");
		printf("'lzss d file2 file1' decodes file2 into file1.\n");
		return EXIT_FAILURE;
	}
#ifdef APW
	if ((s = argv[1], s[1] || strpbrk(s, "DEde") == NULL)
	    || (s = argv[2], (infile  = fopen(s, "rb")) == NULL)
	    || (s = argv[3], (outfile = fopen(s, "wb")) == NULL)) {
		printf("??? %s\n", s);  
		return EXIT_FAILURE;
	}
#else
	if ((s = argv[1], s[1] || strpbrk(s, "DEde") == NULL)
	    || (s = argv[2], (infile  = fopen(s, "r")) == NULL)
	    || (s = argv[3], (outfile = fopen(s, "w+")) == NULL)) {
		printf("??? %s\n", s);  
		return EXIT_FAILURE;
	}
#endif

#define HEADER_LEN	17
	fseek(infile, 0L, 2);
	length = ftell(infile);
	printf("INPUT LENGTH = %ld\n", length);
	length -= HEADER_LEN;
	//rewind(infile);
	fseek(infile, (long)HEADER_LEN, 0);
	fread(in_buf, length, 1, infile);
	if (toupper(*argv[1]) == 'E')
		result_length = Encode(in_buf, length, out_buf);
	else
		result_length = Decode(in_buf, length, out_buf);
	printf("RESULT LENGTH = %ld\n", result_length);
	fwrite(out_buf, 1, result_length, outfile);
	fclose(infile);  
	fclose(outfile);
	return EXIT_SUCCESS;
}
#endif

