/*
 *	$Id: AddressEntry.h,v 1.2 1995/05/11 23:10:14 jhsia Exp $
 *	
 *	$Log: AddressEntry.h,v $
 * Revision 1.2  1995/05/11  23:10:14  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		AddressEntry.h

	Contains:	xxx put contents here xxx

	Written by:	KON

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <2>	 6/20/94	KON		Update for CES look.
		 <1>	  6/9/94	KON		first checked in

	To Do:
*/


#ifndef __AddressEntry__
#define __AddressEntry__

#ifndef __PlayerDB__
#include "PlayerDB.h"
#endif __PlayerDB__

// ==BRAIN DAMAGE==
// Positions in read address dialog - this is shit: read from DB
//

#define kAddressReadNamePos			20
#define kAddressReadNameLength		90
#define kDateLastPlayedReadPos		120
#define kDateLastPlayedReadLength	80
#define kAddressReadStatsPos		210
#define kAddressReadStatsLength		80


#endif __AddressEntry__
