/*
 *	$Id: SoundTestPriv.h,v 1.2 1995/05/11 23:11:02 jhsia Exp $
 *	
 *	$Log: SoundTestPriv.h,v $
 * Revision 1.2  1995/05/11  23:11:02  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		SoundTestPriv.h

	Contains:	xxx put contents here xxx

	Written by:	Joe Britt

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <2>	 8/22/94	JOE		now u can play with the fx freqs
		 <1>	 8/20/94	JOE		first checked in

	To Do:
*/



#define	kBGMItem			4
#define	kMusicDisableItem	3
#define	kSoundFXItem		2
#define	kSoundFXMapItem		1
#define	kSoundFXFreq		0

#define	kFXNamePixelWidth	112

#define	kSoundTestClutCycleRate		10


typedef struct 
{

segaCharRect	fxIDRect;	
segaCharRect	fxFreqRect;
segaCharRect	bgmIDRect;
segaCharRect	fxRect;
segaCharRect	bgmRect;
segaCharRect	musicSetRect;

long			musicPromptPats;
long			musicSetPats;
long			fxIDPats;
long			bgmIDPats;
long			fxPats;
long			bgmPats;
long			titlePats;
long			bgmPromptPats;
long			fxFreqPats;

short			oldFont;
short			blink;
short			color;
short			c11;
unsigned char	patchSelect;
unsigned char	bgmSelect;

long			theta;
long			sx;
long			sy;
SpriteRef		s1;

short			itemSelected;
Boolean			musicDisable;
unsigned char	fxFreq;

TextBoxReference myTextBoxMems;

FXID			patchID;
BMID			bgmID;

VBLProcRef		myvbl;

} SoundTestRefCon;
