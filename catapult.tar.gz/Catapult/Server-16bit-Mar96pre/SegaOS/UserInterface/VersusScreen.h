/*
 *	$Id: VersusScreen.h,v 1.2 1995/05/11 23:11:10 jhsia Exp $
 *	
 *	$Log: VersusScreen.h,v $
 * Revision 1.2  1995/05/11  23:11:10  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		VersusScreen.h

	Contains:	xxx put contents here xxx

	Written by:	Joe Britt

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	 7/19/94	JOE		first checked in
	To Do:
*/



#ifndef __VersusScreen__
#define __VersusScreen__



#endif


