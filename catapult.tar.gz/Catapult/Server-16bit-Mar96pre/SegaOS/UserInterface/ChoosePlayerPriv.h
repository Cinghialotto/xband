/*
 *	$Id: ChoosePlayerPriv.h,v 1.2 1995/05/11 23:10:16 jhsia Exp $
 *	
 *	$Log: ChoosePlayerPriv.h,v $
 * Revision 1.2  1995/05/11  23:10:16  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		ChoosePlayerPriv.h

	Contains:	xxx put contents here xxx

	Written by:	KON

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	 6/10/94	KON		first checked in

	To Do:
*/


typedef struct ChoosePlayerRefCon
{
	DITLItemList 	*theDitlList;
	ControlTable 	*myControlTable;
} ChoosePlayerRefCon;

