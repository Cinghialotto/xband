/*
 *	$Id: MailEdit.h,v 1.2 1995/05/11 23:10:34 jhsia Exp $
 *	
 *	$Log: MailEdit.h,v $
 * Revision 1.2  1995/05/11  23:10:34  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		MailEdit.h

	Contains:	xxx put contents here xxx

	Written by:	Chris Yerga

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <2>	  7/1/94	CMY		second checked in.
		 <1>	  6/2/94	CMY		first checked in

	To Do:
*/


