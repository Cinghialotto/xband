/*
 *	$Id: HistView.h,v 1.2 1995/05/11 23:10:27 jhsia Exp $
 *	
 *	$Log: HistView.h,v $
 * Revision 1.2  1995/05/11  23:10:27  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		HistView.h

	Contains:	xxx put contents here xxx

	Written by:	KON

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <7>	  7/7/94	JOE		use ranking manager
		 <6>	  7/3/94	JOE		tweak list of items in History screen's DITL again
		 <5>	  7/1/94	JOE		tweak list of items in History screen's DITL
		 <4>	 6/30/94	JOE		add list of items in History screen's DITL
		 <3>	 6/28/94	SAH		Killed Results.h
		 <2>	 6/10/94	KON		Update to use new dispatcher.

	To Do:
*/

#ifndef __HistView__
#define __HistView__


#endif __HistView__
