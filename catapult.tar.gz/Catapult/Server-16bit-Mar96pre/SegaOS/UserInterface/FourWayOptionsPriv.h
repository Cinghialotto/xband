/*
 *	$Id: FourWayOptionsPriv.h,v 1.2 1995/05/11 23:10:26 jhsia Exp $
 *	
 *	$Log: FourWayOptionsPriv.h,v $
 * Revision 1.2  1995/05/11  23:10:26  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		FourWayOptionsPriv.h

	Contains:	xxx put contents here xxx

	Written by:	KON

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	 6/11/94	KON		first checked in

	To Do:
*/



typedef struct 
{
	DITLItemList 	*theDitlList;
	ControlTable 	*theControlTable;
} FourWayOptionsRefCon;


