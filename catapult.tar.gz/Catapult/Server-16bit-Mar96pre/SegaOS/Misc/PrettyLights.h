/*
 *	$Id: PrettyLights.h,v 1.2 1995/05/11 22:53:44 jhsia Exp $
 *	
 *	$Log: PrettyLights.h,v $
 * Revision 1.2  1995/05/11  22:53:44  jhsia
 * removed CodeToData, switch the others with rcs keywords
 *
 */

/*
	File:		PrettyLights.h

	Contains:	animation command defines

	Written by:	Rosko

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <6>	 8/13/94	JOE		more Joggler stuff
		 <5>	  8/8/94	JOE		added joggler protos
		 <4>	 7/17/94	SGR		added looping
		 <3>	 6/20/94	SGR		managerized
		 <2>	 6/20/94	SGR		added database stuff
		 <1>	 6/15/94	SGR		this stuff really works
		 <1>	6/15/94	SGR		first checked in

	To Do:
*/

#ifndef __DataBase__
#include "DataBase.h"
#endif
#ifndef __Animation__
#include "Animation.h"
#endif

#define kLEDSkip		0
#define	kLEDSmallDelay	1<<4
#define kLEDBigDelay	2<<4
#define	kLEDJoggler		3<<4	/* not a normal animation; this is a Joggler */
#define	kLEDLowJump1	4<<4
#define kLEDLowJump2	5<<4
#define	kLEDHiJump1		6<<4
#define kLEDHiJump2		7<<4

void	_SetLEDs ( unsigned char data );

AnimationRef _SetLEDScreenAnimation ( DBID screenID, AnimationRef animation ) ;

typedef
struct LEDState
{
	short			loopCnt ;
	unsigned char *	command ;
	Boolean			jogglerActive;
} LEDState ;
	

#ifdef SIMULATOR
extern unsigned char gLEDState ;
#endif

void SetLEDs ( unsigned char data ) = 
	CallDispatchedFunction( kSetLEDs );
	
void InitJoggler( void ) = 
	CallDispatchedFunction( kInitJoggler );
	
void DisplayJoggler( unsigned char *data ) = 
	CallDispatchedFunction( kDisplayJoggler );
	
void StopJoggler( void ) =
	CallDispatchedFunction( kStopJoggler );
	
AnimationRef SetLEDScreenAnimation ( DBID screenID, AnimationRef animation ) =
	CallDispatchedFunction( kSetLEDScreenAnimation );

