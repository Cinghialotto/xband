/*
 *	$Id: NetRegister.h,v 1.2 1995/05/11 22:53:43 jhsia Exp $
 *	
 *	$Log: NetRegister.h,v $
 * Revision 1.2  1995/05/11  22:53:43  jhsia
 * removed CodeToData, switch the others with rcs keywords
 *
 */

/*
	File:		NetRegister.h

	Contains:	xxx put contents here xxx

	Written by:	KON

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <9>	 7/27/94	KON		Make the address book connect dialogs work again. Removed
									parameter from CheckNetRegister.
		 <8>	 7/21/94	BET		add #ifdef __SERVER__
		 <7>	 7/13/94	KON		Add IsBoxNetRegistered call.
		 <6>	  7/6/94	KON		Add calls to get network time out value and network wait so far.
		 <5>	  7/5/94	KON		Use correct selector for check net register.
		 <4>	  7/5/94	KON		Change NetRegister to CheckNetRegister and add a new NetRegister
									proc that does nothing but mark player as registered.
		 <3>	  7/1/94	ADS		Added missing #include
		 <2>	 6/17/94	KON		Add SetNetTimeoutValue.
		 <1>	 6/17/94	KON		first checked in

	To Do:
*/



#ifndef __NetRegister__
#define __NetRegister__

#ifndef __PlayerDB__
#include "PlayerDB.h"
#endif

#define	kGoAheadAndConnect		0
#define kDontDoTheConnection	1

#ifdef __SERVER__
// do something so the server can use the file

#else

short CheckNetRegister( void ) =
	CallDispatchedFunction( kCheckNetRegister );

void NetRegister( void ) =
	CallDispatchedFunction( kNetRegister );

void NetRegisterDone( void ) =
	CallDispatchedFunction( kNetRegisterDone );

void SetNetTimeoutValue( long timeOutValue ) =
	CallDispatchedFunction( kSetNetTimeoutValue );

long GetNetTimeoutValue( void ) =
	CallDispatchedFunction( kGetNetTimeoutValue );

long GetNetWaitSoFar( void ) =
	CallDispatchedFunction( kGetNetWaitSoFar );

Boolean IsBoxNetRegistered( void ) =
	CallDispatchedFunction( kIsBoxNetRegistered );
#endif

#endif __NetRegister__
