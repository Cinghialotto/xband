/*
 * @(#) ScreenStateTables.r 1.1@(#)
 */

/*
	File:		ScreenStateTables.r

	Contains:	xxx put contents here xxx

	Written by:	KON

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<32>	 7/22/94	CMY		Remapped the 4-way options screen
		<31>	 7/21/94	KON		Fix for four button address entry and new in address entry
									screen.
		<30>	 7/21/94	CMY		FIx for the 4-button mail view
		<29>	 7/20/94	KON		Rearrange the top level mail screen.
		<28>	 7/19/94	JOE		wire XFile back to the Rankings screen
		<27>	 7/19/94	JOE		temporarily wire XFILE to versus screen for testing
		<26>	 7/17/94	JOE		update account info (cleverly named Options) screen
		<25>	 7/15/94	ADS		Added password entry
		<24>	 7/14/94	CMY		Fixed a fuqup
		<23>	 7/14/94	CMY		Added XBand setup screen
		<22>	 7/12/94	CMY		Added check mail button to mail screens
		<21>	 7/11/94	KON		Updated connect in address book and address entry screens to
									point to find opponent screen.
		<20>	 7/11/94	CMY		Added choose icon screen.
		<19>	 7/11/94	CMY		Added taunt and info text screens.
		<18>	 7/10/94	CMY		Added Choose Handle screen
		<17>	  7/9/94	CMY		Made "New" work in the "about this address" screen in addr. book
		<16>	  7/6/94	ADS		Added player info options screen
		<15>	  7/5/94	ADS		Add table for new aboutbox screen
		<14>	  7/3/94	KON		Change routine in Mail entry screen to do delete properly and to
									get us to mail edit correctly.
		<13>	  7/2/94	CMY		Added New Address Edit screen.
		<12>	  7/2/94	CMY		Add MailEdit screen.
		<11>	 6/30/94	KON		Add NewsScreen.
		<10>	 6/20/94	KON		Update for CES.
		 <9>	 6/17/94	KON		Futsted around some more.
		 <8>	 6/17/94	KON		Made most undefined entries point to the same screen rather than
									return.
		 <7>	 6/15/94	KON		Make delete key stay on the address book screen.
		 <6>	 6/11/94	KON		Add four way options screen.
		 <5>	 6/11/94	KON		Use magic return value for stack based navigation.
		 <4>	 6/11/94	KON		Add four way mail screen.
		 <3>	 6/11/94	KON		Fix delete in mail screen.
		 <2>	 6/10/94	KON		Minor tweaks to some of the screen branching logic.
		 <1>	 6/10/94	KON		first checked in

	To Do:
*/


/*
**
** This is total shit, but I don't know how to use res. It would be really
** nice to use the constants from Screens.h and types from DataBase.h here,
** but, hell, it's better than nothing.
**
**
** Resource format is a DBID size count of possible options coming out of the
** screen with DBID of the resource number, along with the ID's of the screens
** that each option leads to.
*/


data 'SSTT' (1, "Choose Player") 
{
	$"04 02 02 02 02"			/* all roads point to kMainScreen */
};

data 'SSTT' (2, "Main Screen") 
{
	$"06 03 04 0A 06 0B ff"		/* FindOpponent, Player List, Mailbox, Stats, Options, Return */
};		


data 'SSTT' (3, "kFindOpponent") 
{
	$"01 ff"					/* Eventually comes back to main screen */
};

data 'SSTT' (4, "Player List") 
{
	$"05 05 04 03 0E ff"		/* Player Info, Delete, Connect, New, Return */
};

data 'SSTT' (5, "Player Info") 
{
	$"04 ff 03 0E ff"		/*  delete, connect, new, xit */
};

data 'SSTT' (6, "Stats Screen") 
{
	$"05 ff ff ff ff ff"		/* bump back to main screen */
};

data 'SSTT' (7, "kDisplayMailScreen") 
{
	$"05 08 07 0D 03 ff"			/* kMailEntryScreen, bump back to main screen */
};

data 'SSTT' (8, "kMailEntryScreen") 
{
	$"05 0D ff 0D 03 ff"			/* Back to display mail screen */
};

data 'SSTT' (9, "kOptionsScreen") 
{
	$"0F ff ff ff ff ff ff ff ff ff ff ff ff ff ff ff"			/* Back to main screen */
};

data 'SSTT' (10, "k4WayMailScreen") 
{
	$"04 07 0C 0C ff"			/* mail, news, news, return */
};

data 'SSTT' (11, "k4WayOptionsScreen") 
{
	$"04 09 10 16 ff"			/* opts, opts, XBand Setup, return */
};

data 'SSTT' (12, "kNewsScreen") 
{
	$"01 ff"			/* return */
};

data 'SSTT' (13, "kMailEditScreen") 
{
	$"01 ff"			/* return */
};

data 'SSTT' (14, "kAddressBookNewScreen") 
{
	$"01 ff"			/* return */
};

data 'SSTT' (15, "kAboutBoxScreen") 
{
	$"01 ff"			/* return */
};

data 'SSTT' (16, "kPlayerInfoOptsScreen") 
{
	$"06 11 12 13 14 15 ff"			/* Handle, Icon, Taunt, Info, Password, xZit */
};

data 'SSTT' (17, "ChooseHandleScreen")
{
	$"01 FF"
};

data 'SSTT' (18, "ChooseIconScreen")
{
	$"01 FF"
};

data 'SSTT' (19, "ChooseTauntScreen")
{
	$"01 FF"
};

data 'SSTT' (20, "ChooseInfoTextScreen")
{
	$"01 FF"
};

data 'SSTT' (21, "ChoosePasswordScreen")
{
	$"01 FF"
};

data 'SSTT' (22, "XBand Setup")
{
	$"01 FF"
};

data 'SSTT' (24, "Versus Screen")
{
	$"01 FF FF FF FF FF FF FF FF FF"
};


