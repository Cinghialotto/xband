/*
 *	$Id: Utils.h,v 1.3 1995/10/04 19:34:46 steveb Exp $
 *	
 *	$Log: Utils.h,v $
 * Revision 1.3  1995/10/04  19:34:46  steveb
 * Changed ByteCopy to use memcpy instead of bcopy.
 *
 * Revision 1.2  1995/05/11  22:53:47  jhsia
 * removed CodeToData, switch the others with rcs keywords
 *
 */

/*
	File:		Utils.h

	Contains:	xxx put contents here xxx

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <7>	  8/4/94	JBH		Made RandomShort use a global seed.
		 <6>	  8/2/94	CMY		Managerized RandomShort
		 <5>	 7/18/94	CMY		UnpackBytes
		 <4>	 7/16/94	BET		Add UNIX def for ByteCopy.
		 <3>	 6/21/94	CMY		Added RandomShort.
		 <2>	 6/14/94	SAH		Made ByteCopy dispatched through the memory manager.

	To Do:
*/


#ifndef UTILS_H
#define UTILS_H

void _ByteCopy(
	Ptr		dest,
	Ptr		source,
	long	length);

#ifdef __SERVER__

#ifdef	unix
#define	ByteCopy( d, s, l )		memcpy( d, s, l )
#else
#define	ByteCopy( d, s, l )		_ByteCopy( d, s, l )
#endif	/* unix */

short RandomShort( void );

#else

#ifndef __SegaOS__
#include "SegaOS.h"
#endif


void ByteCopy( Ptr dest, Ptr source, long length) = 
	CallDispatchedFunction( kByteCopy );

void UnpackBytes(char *source, char *dest, short sourceLength) =
	CallDispatchedFunction( kUnpackBytes );

short RandomShort( void ) =
	CallDispatchedFunction( kRandomShort );
	
#endif

#endif


