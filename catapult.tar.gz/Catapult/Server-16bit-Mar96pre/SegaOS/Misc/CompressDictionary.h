/*
 *	$Id: CompressDictionary.h,v 1.2 1995/05/11 22:53:39 jhsia Exp $
 *	
 *	$Log: CompressDictionary.h,v $
 * Revision 1.2  1995/05/11  22:53:39  jhsia
 * removed CodeToData, switch the others with rcs keywords
 *
 */

/*
	File:		CompressDictionary.h

	Contains:	xxx put contents here xxx

	Written by:	KON

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<10>	 8/14/94	JBH		Added third bitstream (nibbles) to the infamous JoshCompression
		 <9>	 7/24/94	JBH		Added new form of compression (aka JoshCompress).
		 <8>	 7/24/94	KON		Add bitmap cacheing.
		 <7>	 7/21/94	KON		Added support for name table compressor. If defed out until
									decompressor is written.
		 <6>	 7/17/94	KON		Tag graphics with their dictionary.
		 <5>	 7/17/94	KON		Update prototypes so the dictionary takes a DBID to support
									multiple dictionaries. Move the clut dictionary to clut DBID
									254.
		 <4>	 7/17/94	KON		Add color table dictionaries and constant defines for our DBIDs.
		 <3>	 7/16/94	KON		Add run length compression of zero entries in the name table.
		 <2>	 7/16/94	KON		add uniqueCells field to DictionaryBitMap.
		 <1>	 7/16/94	KON		first checked in

	To Do:
*/


#ifndef __CompressDictionary__
#define __CompressDictionary__

#ifndef __SegaGraphics__
#include "SegaGraphics.h"
#endif __SegaGraphics__

#ifndef __DataBase__
#include "DataBase.h"
#endif __DataBase__

#define colorTableDictionaryDBID		254


#define kZeroBitLoner			0
#define kZeroBitRun				1
#define kIncrementPrediction	2
#define kBackPointer			3

typedef struct DictionaryBitMap
{
	SegaBitMap		bitMap;
	unsigned char	clutRef;
	DBID			patternDictionaryRef;
	short			uniqueCells;
#if 0
	short			predictorStart;
	unsigned short	backTableOffset;
	unsigned short	zeroTableOffset;
#endif
	short			nameTable[1];	//references master dictionary
} DictionaryBitMap;

typedef struct JoshCompressHeader {
	unsigned short	offsetToData;
	unsigned short	offsetToNibbles;
	unsigned char	favoriteXX;
	unsigned char	favoriteXY;
	long			totalUncompressedSize;
	unsigned char	data[2];
} JoshCompressHeader;

short AddPatternToDictionary( long *patternPtr );
void AddMasterDictionaryToDB( DBID dictionaryID );
DictionaryBitMap * RunLengthCompressZeroNameTableEntries( DictionaryBitMap *bitMapPtr );
unsigned char AddColorTableToDictionary( long *colorTablePtr );
void AddColorTableDictionaryToDB( void );
DictionaryBitMap * CompressNameTableEntriesToBits( DictionaryBitMap *bitMapPtr, short beginPrediction );
void MoveResourceToMasterDictionary( Handle myResource );


#endif __CompressDictionary__

