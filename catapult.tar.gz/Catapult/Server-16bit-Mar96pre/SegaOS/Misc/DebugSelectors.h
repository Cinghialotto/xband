/*
 *	$Id: DebugSelectors.h,v 1.2 1995/05/11 22:53:40 jhsia Exp $
 *	
 *	$Log: DebugSelectors.h,v $
 * Revision 1.2  1995/05/11  22:53:40  jhsia
 * removed CodeToData, switch the others with rcs keywords
 *
 */

/*
	File:		DebugSelectors.h

	Contains:	Flags to enable / disable debugging code

	Written by:	Josh Horwich

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<10>	 8/25/94	HEC		Added SHOW_POPEN_ERRS
		 <9>	 8/24/94	JBH		Disable STRESS_DBCOMPRESS for true final build.
		 <8>	 8/22/94	ADS		Added FORCE_HARD_HERE
		 <7>	 8/19/94	JBH		Added STRESS_DBCOMPRESS
		 <6>	 8/18/94	ADS		Moved SmallRAM switch here
		 <5>	 8/16/94	JBH		Disable TESTNASTYDIALOG to please the testers
		 <4>	 8/12/94	KON		Add USEDISK selector.
		 <3>	 8/12/94	HEC		Disable SHOW_SEGA_ERROR_DIALOG until it actually works.
		 <2>	 8/11/94	HEC		Added SHOW_SEGA_ERROR_DIALOG
		 <1>	 8/10/94	JBH		first checked in

	To Do:
*/
#ifndef __DebugSelectors__
#define __DebugSelectors__

/* OK, here's the story. We want a central repository for switches to enable or disable */
/* debugging code throughout the project. Hopefully when we ship, we have them all turned */
/* off, so we don't have some embarrassing "secret key", as opposed to the not-so-embarassing */
/* secret stuff. */

#define TESTNASTYDIALOG		0			/* allows a deferred dialog to appear at next main eventloop */
//#define SHOW_SEGA_ERROR_DIALOG	1		/* pop up deferred dialog for ReportError() on Sega build */

#if defined(SIMULATOR) && !defined(ROMDB)
//  #define USEDISK		1	/* uses disk transport rather than network */
#endif

/* turn this on to allow the user to "scramble" their database on boot. This will also require */
/* the user to hold the B and C buttons down during boot. */
#define	STRESS_DBCOMPRESS	0

/* turn this on to shrink the os SRAM heap usage down for debugging purposes */
//#define SMALLRAM		1


/*  Turn this on to force "hard-here" mode (we normally would like to use
	"soft-here" mode but there are some problems)
*/
#ifndef SIMULATOR
	#define FORCE_HARD_HERE	1
#endif

/*	Turn this on to display POpen errors during server connect in FindOpponent.c */
//#define SHOW_POPEN_ERRS 1




#endif __DebugSelectors__
