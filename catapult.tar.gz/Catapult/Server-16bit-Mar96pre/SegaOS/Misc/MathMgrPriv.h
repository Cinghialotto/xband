/*
 *	$Id: MathMgrPriv.h,v 1.2 1995/05/11 22:53:42 jhsia Exp $
 *	
 *	$Log: MathMgrPriv.h,v $
 * Revision 1.2  1995/05/11  22:53:42  jhsia
 * removed CodeToData, switch the others with rcs keywords
 *
 */

/*
	File:		MathMgrPriv.h

	Contains:	xxx put contents here xxx

	Written by:	Josh Horwich

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <2>	  8/4/94	JOE		added sinetable global
		 <1>	  8/4/94	JBH		first checked in. Added a global random seed.
	To Do:
*/

typedef struct MathMgrGlobals
{
	long		randomSeed;
	char		*sineTable;
} MathMgrGlobals;

#ifdef SIMULATOR
	#define MANAGERGLOBALTYPE MathMgrGlobals
#else
	extern MathMgrGlobals mathMgr;
#endif

