/*
 *	$Id: QuickSortPriv.h,v 1.2 1995/05/11 22:53:46 jhsia Exp $
 *	
 *	$Log: QuickSortPriv.h,v $
 * Revision 1.2  1995/05/11  22:53:46  jhsia
 * removed CodeToData, switch the others with rcs keywords
 *
 */

/*
	File:		QuickSortPriv.h

	Contains:	xxx put contents here xxx

	Written by:	KON

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	  7/2/94	KON		first checked in

	To Do:
*/



typedef struct SortGlobals
{
	void			*base;
	CompareFunction	compareFunc;
	SwapFunction	swapFunc;
} SortGlobals;


#ifdef SIMULATOR
#define	MANAGERGLOBALTYPE	SortGlobals
#else
extern SortGlobals qsort;
#endif

