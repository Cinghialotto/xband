/*
 *	$Id: QuickSort.h,v 1.2 1995/05/11 22:53:45 jhsia Exp $
 *	
 *	$Log: QuickSort.h,v $
 * Revision 1.2  1995/05/11  22:53:45  jhsia
 * removed CodeToData, switch the others with rcs keywords
 *
 */

/*
	File:		QuickSort.h

	Contains:	xxx put contents here xxx

	Written by:	KON

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <2>	  7/4/94	KON		The compare function should return a short.
		 <1>	  7/2/94	KON		first checked in

	To Do:
*/


#ifndef __QuickSort__
#define __QuickSort__

#ifndef __SegaOS__
#include "SegaOS.h"
#endif __SegaOS__

typedef short (*CompareFunction)( void * base, short index1, short index2 );	
typedef void (*SwapFunction)( void * base, short index1, short index2 );	


void QSort( short n, void *base, CompareFunction compare, SwapFunction swap ) =
	CallDispatchedFunction( kQSort );


#endif __QuickSort__
