/*
 *	$Id: NetRegisterPriv.h,v 1.2 1995/05/11 22:53:44 jhsia Exp $
 *	
 *	$Log: NetRegisterPriv.h,v $
 * Revision 1.2  1995/05/11  22:53:44  jhsia
 * removed CodeToData, switch the others with rcs keywords
 *
 */

/*
	File:		NetRegisterPriv.h

	Contains:	xxx put contents here xxx

	Written by:	KON

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <6>	  8/9/94	KON		Add dontExpireTimeoutProc global.
		 <5>	 7/27/94	KON		Make address registration warning dialogs work again. Changed
									globals to use a userIdentification instead of a playerInfo.
		 <4>	  7/7/94	KON		Add timeout proc for slave.
		 <3>	  7/6/94	KON		Remove kNetRegisterTimeOutInit and make it a db constant.
		 <2>	 6/17/94	KON		Add SetNetTimeoutValue.
		 <1>	 6/17/94	KON		first checked in

	To Do:
*/

#ifndef __Time__
#include "time.h"
#endif __Time__

#define kNotRegistered	0
#define kRegistered		1

typedef struct NetRegisterGlobals
{
	userIdentification	addressBookPlayer;
	short	 	registered;
	short		reregisterCount;
	long		registrationTime;
	long		timeOutValue;
//
// These are used by the timeout proc
//
	char		firstTime;
	char		dontExpireTimeoutProc;	//set when the timeout proc should not post a dialog
	TimeProcRef	timeProcRef;
} NetRegisterGlobals;



#ifdef SIMULATOR
#define	MANAGERGLOBALTYPE		NetRegisterGlobals
#else
extern NetRegisterGlobals netRegister;
#endif

long NetRegisterTimeOutTimeProc( void ) =
	CallDispatchedFunction( kNetRegisterTimeOutTimeProc );

