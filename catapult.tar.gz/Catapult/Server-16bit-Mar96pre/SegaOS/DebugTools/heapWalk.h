/*
 *	$Id
 *
 *	$Log: heapWalk.h,v $
 * Revision 1.2  1995/05/11  21:53:08  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		heapWalk.h

	Contains:	xxx put contents here xxx

	Written by:	Chris Yerga

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <3>	  6/1/94	SAH		Made ReserveAddressRange take an address rather than an offset.
		 <2>	 5/28/94	CMY		Added ReserveMemoryRange
		 <1>	 5/25/94	SAH		first checked in

	To Do:
*/

/*
 * HeapWalk.h
 *
 */

#define kFreeBlockType 1
#define kBlockType 2
#define kNoMoreBlocks 3

/*
 * HeapWalkProc
 *
 * Pass one of these procPtrs to WalkHeap. It will call out to your proc for every block in
 * the heap. The args are as follows:
 *
 *		void	*block		The current block address
 *		long	size		The size of the block
 *		long	type		kFreeBlockType,kBlockType, or kNoMoreBlocks (at end of heap)
 *		long	data		The data you passed to WalkHeap (store your state data here)
 *
 * Your proc can return a non-zero value if it wishes to terminate the heap walk. The value
 * will in turn be returned from WalkHeap(). If you return zero always, you'll get called
 * for all blocks and WalkHeap will return zero to the caller at the end
 */
typedef long (*HeapWalkProc)(void *block, long size, long type, long data);

long WalkHeap(Heap *heap, HeapWalkProc callout, long data);


/* Returns the size of the heap */
long HeapSize(Heap *heap);

/* Find out what block a given address is in */
long FindBlock(PubHeap heap, long address, long *blockAddress, long *size);

/* Allocate a block at a specific address within the heap to reserve memory */
void ReserveAddressRange(PubHeap heap, long address, long length);

