/*
 *	$Id
 *
 *	$Log: simDebugger.h,v $
 * Revision 1.2  1995/05/11  21:53:09  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		simDebugger.h

	Contains:	simulator/debugger windows

	Written by:	Chris Yerga

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):
	
		<16>	 8/16/94	KON		Add kROMHeap to do one-shot for ROM display in heap update
									window.
		<15>	 8/13/94	JOE		try to bring the LEDs back to life
		<14>	 8/28/56	SAH		Update the box id through a time mgr task.
		<13>	  7/3/94	SAH		Added the Box Identification window.
		<12>	  7/1/94	ADS		add database type/id info to DB heap view
		<11>	 6/28/94	CMY		Added clut window.
		<10>	 6/28/94	SAH		Updated to new globals.
		 <9>	 6/15/94	SGR		added led stuff
		 <8>	 6/12/94	SAH		Update to new database heap global.
		 <7>	 6/11/94	CMY		Add support for stack crawls.
		 <6>	 6/10/94	CMY		Added ResetDebugger
		 <5>	  6/3/94	CMY		Mouse coordinates window.
		 <4>	 5/29/94	CMY		Add view of Pattern memory.
		 <3>	 5/26/94	HEC		Added ROM heap.
		 <2>	 5/26/94	SAH		Added TempHeap and DataHeap.
		 <1>	 5/25/94	SAH		first checked in

	To Do:
*/


#ifdef DEBUG

#ifndef __Heaps__
	#include "heaps.h"
#endif
#ifndef __Time__
	#include "time.h"
#endif

#include <StdIO.h>

/* --- Menu Constants --- */
#define kHeapStatsItem			801
#define	kPatternMemoryItem		802
#define	kMouseCoordinatesItem	803
#define	kLEDItem				804
#define kClutItem				805
#define kBoxIDItem				806

/*
 * Debugger Globals
 *
 */
#define OSCodeHeap	(PubHeap) gOSCodeHeap
#define GameHeap	(PubHeap) gGameRuntimeHeap
#define TempHeap	(PubHeap) gTempHeap
#define DataHeap	(PubHeap) gDatabaseHeap
#define ROMHeap		(PubHeap) gRomHeap

#define kROMHeap		4

/*
 * Debugging Globals
 *
 * We store these in a struct so we can get them through a pointer whenever necessary.
 * Some of our debugging code is called from the Sega thread through a TimeRequest callout,
 * and it's possible at some time in the future that our A5 world isn't available
 */
 
#define kMaxHeapViews	8

typedef void (*BlockInfoRef) ( Ptr theBlock, long blockSize, char* description );


typedef struct {
	SegaLowMem		*segaLoMem;				/* A way to get at shit in lomems */
	
		// Heap Stats
	WindowPtr		heapStatsWindow;		/* The "heap stats" window, if open (or nil) */
	short			heapStatsLineHeight;	/* Height of a line of text in it */
	short			heapStatsHeapHeight;	/* Height of a heap's info in it */
	short			heapStatsHeapCount;		/* Number of heaps being displayed */
	PubHeap			heapStatsHeapList[kMaxHeapViews];	/* The heaps being displayed */
	unsigned char	*heapStatsHeapNames[kMaxHeapViews];	/* ...and their names */
	TimeProcRef		heapStatsTimeProc;		/* The timeProc that updates the window */
	
		// Heap View
	WindowPtr		heapViewWindow;			/* The detailed "heap view" window, if open (or nil) */
	short			heapViewHeapIndex;		/* What heap are we viewing in it? */
	Rect			heapViewGrowParams;		/* The min/max width & height for growWindow */
	Rect			heapViewRect;			/* The bounds of the heap image */
	short			cellHeight;
	Fixed			pixelsPerByte;
	BlockInfoRef	heapStatsInfoStr[kMaxHeapViews];	/* procs to analyze and describe blocks */
	
		// Pattern View
	WindowPtr		patternViewWindow;		/* The view of pattern memory usage */
	TimeProcRef		patternViewTimeProc;	/* The timeProc that updates the window */
	
		// Mouse Coordinates
	WindowPtr		mouseCoordinatesWindow;	/* Shows the mouse coordinates */
	
		// LED Window
	WindowPtr		LEDWindow;				/* Shows the LEDs */
	TimeProcRef		LEDTimeProc;			/* The guy that updates the window */
	
		// Clut Window
	WindowPtr		clutWindow;				/* Shows the SEGA cluts */
	TimeProcRef		clutTimeProc;			/* The guy that updates the window */
	
		// BoxID Window
	WindowPtr		boxIDWindow;			/* Shows the Box ID globals */
	TimeProcRef		boxIDTimeProc;			/* The guy that updates the window */
} DebugGlobals;

/*
 * DrawHeapPicture state
 *
 * This is used when we draw the single-ling color image of a heap. We call the 
 * WalkHeap proc to iterate through every block in the heap and call us with this state.
 * It basically just contains the screen coordinates of the current block.
 */
typedef struct {
	Fixed	bytesPerPixel;			/* Number of bytes each screen pixel represents */
	short	heapStartX;				/* x coordinate of heap start */
	long	heapStartAddress;		/* Addr of heap start */
	Rect	lastBlockRect;			/* The rectangle drawn for the last block */
} DrawHeapPictureState;

/*
 * DrawHeapView state
 *
 * This is used when we draw the 2D color image of a heap. It's just like the guy above.
 */
typedef struct {
	Fixed	bytesPerPixel;			/* Number of bytes each horizontal screen pixel represents */
	short	pixelsPerRow;			/* Number of pixels in each full horizontal row */
	short	cellHeight;				/* The height of the rectangles for each block */
	Rect	heapViewRect;			/* The bounds of the view rectangle */
	long	heapStartAddress;		/* Addr of heap start */
	Rect	lastBlockRect;			/* The rectangle drawn for the last block */
} DrawHeapViewState;


/*
 * A6-Frame
 *
 * The stack crawl routine uses this
 */
typedef struct A6Frame {
	struct A6Frame	*next;
	short			*callerPC;
} A6Frame;


/*
 * External Routines
 *
 */
void InitDebugger(void);
void ResetDebugger(void);
void PrintStackCrawl(FILE *destination);


#endif DEBUG
