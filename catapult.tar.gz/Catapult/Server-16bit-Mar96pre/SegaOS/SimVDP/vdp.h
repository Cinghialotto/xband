/*
 *	$Id: vdp.h,v 1.2 1995/05/11 23:04:35 jhsia Exp $
 *	
 *	$Log: vdp.h,v $
 * Revision 1.2  1995/05/11  23:04:35  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		vdp.h

	Contains:	Headers for Sega Video Display Processor.

	Written by:	Sean Callahan

	Copyright:	� 1993 by Rocket Science Games, Inc., all rights reserved.

	Change History (most recent first):

		 <3>	  7/6/94	CMY		Added support for VRAM reads.
		 <2>	 5/26/94	SAH		Put a sean in front of sean's stuff.
		 <2>	 5/24/94	SAH		Ifdefed some SIMUALTOR crap.
		 <1>	  4/4/94	SMC		Project thrash.
		 <8>	 3/29/94	SMC		Add VWrite/Addr prototypes.
		 <7>	 3/16/94	SMC		Change PostVRegister macro and add fill prototypes.
		 <6>	  3/3/94	MHK		use unsigned shorts for copy to vram call lengths so we can do
									more than 0x7fff bytes
		 <5>	 2/15/94	MHK		more type casting problems
		 <4>	 2/11/94	MHK		type casting for think c
		 <3>	  2/1/94	SMC		PostCopyToVRAM changes.
		 <2>	 1/31/94	SMC		Change for use with VDP simulator.
		 <1>	 11/4/93	SMC		Initial version.
*/


#ifndef __VDP__
#define __VDP__


#define	WIDTH_MASK		0x0C00
#define	HEIGHT_MASK		0x0300
#define	LINK_MASK		0x007F
#define	WIDTH_SHIFT		10
#define	HEIGHT_SHIFT	8
#define	LINK_SHIFT		0

#define	PRIORITY_MASK	0x8000
#define	CLUT_MASK		0x6000
#define	VFLIP_MASK		0x1000
#define	HFLIP_MASK		0x0800
#define	PATTERN_MASK	0x07FF
#define	PRIORITY_SHIFT	15
#define	CLUT_SHIFT		13
#define VFLIP_SHIFT		12
#define	HFLIP_SHIFT		11
#define	PATTERN_SHIFT	0


typedef struct {
	short y;
	short link;			// and width,height
	short pattern;		// and priority,clut,vflip,hflip
	short x;
} SegaSprite;

typedef struct {
	short pattern;		// and priority,clut,vflip,hflip
} SegaMap;


typedef unsigned char SegaCell[32];


typedef struct {
	short colors[16];
} SegaClut;

#define	RED_MASK		0x000E
#define	RED_SHIFT		1
#define	GREEN_MASK		0x00E0
#define	GREEN_SHIFT		5
#define	BLUE_MASK		0x0E00
#define	BLUE_SHIFT		9


// SetScrollMode constants

#define	FULL_VSCROLL	0
#define	CELL_VSCROLL	4
#define	FULL_HSCROLL	0
#define	CELL_HSCROLL	2
#define	LINE_HSCROLL	3

// SetHCellMode constants

#define	HCELLMODE_32	0x0000
#define	HCELLMODE_40	0x0081

// SetScrollSize constants

#define	SCROLLSIZE_32	0
#define	SCROLLSIZE_64	1
#define	SCROLLSIZE_128	3

#ifdef SIMULATOR
WindowPtr InitVDP(CGrafPtr port,GDHandle device);
#endif

void SeanSetScrollA(unsigned short addr);
void SeanSetWindow(unsigned short addr);
void SeanSetScrollB(unsigned short addr);
void SeanSetSpriteBase(unsigned short addr);
void SeanSetBackColor(short clut,short index);
void SeanSetScrollMode(short hmode,short vmode,short xintFlag);
void SeanSetHCellMode(short mode,short hiliteFlag,short interlace);
void SeanSetHScroll(unsigned short addr);
void SeanSetAutoIncrement(short increment);
void SeanSetScrollSize(short hsize,short vsize);
void SeanSetWindowH(short h,short rightFlag);
void SeanSetWindowV(short v,short downFlag);

void SeanSetYScrollA(short y);
void SeanSetYScrollB(short y);

#ifdef SIMULATOR
void VDPIdle( void );
#else
#define	VDPIdle()
#endif

void SetColorTable(short clutIndex,SegaClut *clut);

#define	VReg(_reg,_val)				(0x8000 + ((_reg) << 8) + (_val))

void VAddress(long value);
void VWriteByte(unsigned char value);
void VWriteWord(short value);
void VWriteLong(long value);
void VRegWrite(short value);

unsigned short VReadWord(void);

void SeanDMAToVRAM(void *src,void *dst,unsigned short wcount);
void SeanCopyToVRAM(void *src,void *dst,unsigned short wcount);
void SeanCopyToCRAM(void *src,void *dst,short wcount);
void SeanCopyToVSRAM(void *src,void *dst,short wcount);
void SeanCopyToVMap(void *src,void *dst,short x,short y,short width,short height,short bump);
void SeanFillVRAM(long value,void *dst,long lcount);
void SeanFillCRAM(long value,void *dst,long lcount);
void SeanFillVSRAM(long value,void *dst,long lcount);

#endif // __VDP__



