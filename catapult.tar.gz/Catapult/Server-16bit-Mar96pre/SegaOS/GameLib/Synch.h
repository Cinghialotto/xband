/*
 *	$Id
 *
 *	$Log: Synch.h,v $
 * Revision 1.2  1995/05/11  22:12:20  jhsia
 * switch to cvs keywords
 *
 */






short	SynchModems ( void ) =
	CallDispatchedFunction( kSynchModems );

short	SynchVbls ( void ) =
	CallDispatchedFunction( kSynchVbls );

