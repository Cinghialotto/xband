/*
 *	$Id
 *
 *	$Log: CommPriv.h,v $
 * Revision 1.2  1995/05/11  22:12:18  jhsia
 * switch to cvs keywords
 *
 */




#define	MANAGERGLOBALTYPE		CommGlobals


typedef
struct CommGlobals
{
	short status;
	short lastError;
} CommGlobals;


/* connection status */
enum
{
	kNoConnection,
	kWaitingForConnection,
	kOpenConnection
};

