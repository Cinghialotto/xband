/*
 *	$Id
 *
 *	$Log: SynchPriv.h,v $
 * Revision 1.2  1995/05/11  22:12:21  jhsia
 * switch to cvs keywords
 *
 */


typedef
struct SynchGlobals
{
	short dummy;
} SynchGlobals;


#ifdef SIMULATOR
#define MANAGERGLOBALTYPE SynchGlobals
#else

extern SynchGlobals synch;

#endif

