/*
 * @(#) SegaSound.h 1.1@(#)
 */

/*
	File:		SegaSound.h

	Contains:	Header for Arena's Sega Sound Manager

	Written by:	Joe Britt

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<32>	 8/28/94	JOE		Changed the old intro sounds to the new flippin A sounds
		<31>	 8/27/94	SAH		Added a stinky sound.
		<30>	 8/22/94	HEC		added kOpponentFoundSnd
		<29>	 8/21/94	JOE		added kDialogChooseSnd
		<28>	 8/20/94	JOE		added GetBGMDisable()
		<27>	 8/16/94	JOE		added about box sound
		<26>	 8/16/94	JOE		added icon flip snd
		<25>	 8/14/94	JOE		added phone ring snd, Josh's XBand Letter snd, and note
									constants
		<24>	 8/13/94	JOE		added SetBGMDisable
		<23>	 8/11/94	JBH		Added constants for maze sounds.
		<22>	  8/7/94	JOE		renamed pad to altFreq in FXID struct
		<21>	  8/6/94	JOE		Added FXID/BMID structs
		<20>	  8/5/94	JOE		Added kJizzlationDisableSnd
		<19>	  8/1/94	JOE		added kSecretStatRevealedSnd
		<18>	 7/28/94	JOE		Added ShutDownSoundMgr() call to halt the z80 & deallocate the
									sound buffer.
		<17>	 7/27/94	JOE		Give the FX voices a priority of 100.
		<16>	 7/25/94	HEC		Added kSmartCardInsertedSnd and kSmartCardRemovedSnd
		<15>	 7/25/94	KON		Added kServerConnectDoneSnd.
		<14>	 7/21/94	JOE		more FX IDsa
		<13>	 7/21/94	JOE		kKeyboardMoveSnd
		<12>	 7/20/94	JOE		update system FX IDs
		<11>	 7/18/94	JOE		swapped freq & duration position for new SSND structure
		<10>	 7/16/94	JOE		updates
		 <9>	 7/15/94	JOE		updating to Sega Sound Driver.
		 <8>	 7/10/94	JOE		yanked InitDefaultSounds()
		 <7>	 7/10/94	JOE		update for indirect sound FX & BGM selection
		 <6>	  7/1/94	ADS		Added missing #include
		 <5>	 6/21/94	CMY		(Joe) Added HellHiss and Outland.
		 <4>	  6/5/94	SAH		(Joe) Changes.
		 <3>	  6/4/94	SAH		(Joe) Changes.
		 <2>	 5/30/94	SAH		Projector sucks.
		 <1>	 5/30/94	SAH		first checked in
	To Do:
*/

#ifndef __SegaSound__
#define __SegaSound__

#ifndef __Errors__
#include "Errors.h"
#endif

#ifndef __DataBase__
#include "DataBase.h"
#endif


// -------------------------------------------------------
// Constants

// Standard System Sound FX

#define	kConnectSpritesSnd		0		// electric jizzlers
#define	kConnectTextSnd			1

#define	kTextInputSnd			2		// general text keyboard sounds
#define	kTextReturnSnd			3
#define	kTextDeleteSnd			4

#define	kChoosePlayerMoveSnd	5		// Choose Player Sounds
#define	kChoosePlayerSelSnd		6

#define	kPasswordEntrySnd		7

#define	kButtonArrivalSnd		8		// Main Screen buttons slide in
#define	kButtonRollUpDownSnd	9		// Main Screen buttons tilt up/down
#define	kButtonMoveSnd			10		// general move sound
#define	kButtonSelectSnd		11		// general select sound

#define	kPlayerListSelSnd		12		// Player List
#define	kFunctionButtonSelSnd	13		// ???
	
#define	kBandwidthArrivalSnd	14		// Newspaper sounds
#define	kBandwidthNextPageSnd	15
#define	kBandwidthPageFlipSnd	16
#define	kBandwidthGraphicSnd	17

#define	kXBandPageFlipSnd		18		// XBand News

#define	kXMailSwitchButtonSnd	19
#define	kStatsScreenFlipSnd		20		// Stats page

#define	kTauntTextAppearSnd		21

#define	kFlippinASnd			22		// for intro animation
#define	kXBandNewsFlippinASnd	23		// for XBand news

#define	kDialogExplodeSnd		24		// Dialog Transition Sounds
#define	kDialogWarpUpSnd		25
#define	kDialogBounceUpSnd		26
#define	kDialogBounceDownSnd	27
#define kDialogFlyTogetherSnd	28
#define	kDialogFlyApartSnd		29
#define	kDialogZoomInSnd		30
#define	kDialogZoomOutSnd		31

#define	kKeyboardMoveSnd		32
#define	kTauntTextDoneSnd		33
#define	kPasswordDoneSnd		34

#define kServerConnectDoneSnd	35

#define kSmartCardInsertedSnd	36
#define kSmartCardRemovedSnd	37

#define	kSecretStatRevealedSnd	38

#define	kJizzlationDisableSnd	39

#define	kMazeMoveSnd			40
#define	kMazeBadMoveSnd			41
#define	kMazeCompleteSnd		42

#define	kXBandNewsLetterSnd		43

#define	kPhoneRingSnd			44

#define	kIconFlipSnd			45

#define	kAbout1Snd				46

#define	kDialogChooseSnd		47

#define	kOpponentFoundSnd		48

#define	kSinkoSinkedSnd			49

#define	kLastSnd				kSinkoSinkedSnd


#define	kMazeBackgroundMusic	128

// Gems control constants

#define	kFXPriority			100

// BGM & Voice Errors

#define	kBadVoice			1
#define	kBGMNotFound		2
#define	kFXNotFound			3


// Note Freq Values

#define	nC0		0

#define	nCs0	nC0 	+ 1
#define	nD0		nCs0 	+ 1
#define	nDs0	nD0 	+ 1
#define	nE0		nDs0	+ 1
#define	nF0		nE0		+ 1
#define	nFs0	nF0		+ 1
#define	nG0		nFs0	+ 1
#define	nGs0	nG0		+ 1
#define	nA0		nGs0	+ 1
#define	nAs0	nA0		+ 1
#define	nB0		nAs0	+ 1


#define	nC1		nB0		+ 1
#define	nCs1	nC1 	+ 1
#define	nD1		nCs1 	+ 1
#define	nDs1	nD1 	+ 1
#define	nE1		nDs1	+ 1
#define	nF1		nE1		+ 1
#define	nFs1	nF1		+ 1
#define	nG1		nFs1	+ 1
#define	nGs1	nG1		+ 1
#define	nA1		nGs1	+ 1
#define	nAs1	nA1		+ 1
#define	nB1		nAs1	+ 1


#define	nC2		nB1		+ 1
#define	nCs2	nC2 	+ 1
#define	nD2		nCs2 	+ 1
#define	nDs2	nD2 	+ 1
#define	nE2		nDs2	+ 1
#define	nF2		nE2		+ 1
#define	nFs2	nF2		+ 1
#define	nG2		nFs2	+ 1
#define	nGs2	nG2		+ 1
#define	nA2		nGs2	+ 1
#define	nAs2	nA2		+ 1
#define	nB2		nAs2	+ 1


#define	nC3		nB2		+ 1
#define	nCs3	nC3 	+ 1
#define	nD3		nCs3 	+ 1
#define	nDs3	nD3 	+ 1
#define	nE3		nDs3	+ 1
#define	nF3		nE3		+ 1
#define	nFs3	nF3		+ 1
#define	nG3		nFs3	+ 1
#define	nGs3	nG3		+ 1
#define	nA3		nGs3	+ 1
#define	nAs3	nA3		+ 1
#define	nB3		nAs3	+ 1

#define	nC4		nB3		+ 1
#define	nCs4	nC4 	+ 1
#define	nD4		nCs4 	+ 1
#define	nDs4	nD4 	+ 1
#define	nE4		nDs4	+ 1
#define	nF4		nE4		+ 1
#define	nFs4	nF4		+ 1
#define	nG4		nFs4	+ 1
#define	nGs4	nG4		+ 1
#define	nA4		nGs4	+ 1
#define	nAs4	nA4		+ 1
#define	nB4		nAs4	+ 1

#define	nC5		nB4		+ 1
#define	nCs5	nC5 	+ 1
#define	nD5		nCs5 	+ 1
#define	nDs5	nD5 	+ 1
#define	nE5		nDs5	+ 1
#define	nF5		nE5		+ 1
#define	nFs5	nF5		+ 1
#define	nG5		nFs5	+ 1
#define	nGs5	nG5		+ 1
#define	nA5		nGs5	+ 1
#define	nAs5	nA5		+ 1
#define	nB5		nAs5	+ 1




// -------------------------------------------------------
// Data Structures

// Low-level structs

typedef struct BGM {
	unsigned short	noteDataOffset;		// offset to note data from trackData[0]
	char			trackData[];		// arbitrarily long hunk of track data
	} BGM, *BGMPtr;
	

typedef struct Voice {
	short	frequency;					// default frequency
	short	duration;					// default duration
	
	char	voiceData[];				// arbitrarily long hunk of data (FM or samples)
	} Voice, *VoicePtr;


// High-level (DataBase) structs (wrappers around low-level structs)

typedef struct DBBGM {

	BGM		theBGM;
	} DBBGM, *DBBGMPtr;
	
	
typedef struct DBFX {

	Voice	theVoice;
	} DBFX, *DBFXPtr;


// kBackgroundMusicRef & kSoundEffectRef structs

typedef struct FXID {
	DBID	theFX;
	char	altFreq;
	} FXID;

typedef struct BMID {
	DBID	theBGM;
	char	pad;
	} BMID;


// -------------------------------------------------------
// Prototypes


// High-Level routines

void 	SetBGMDisable( Boolean disable ) =
	CallDispatchedFunction( kSetBGMDisable );	

Boolean GetBGMDisable( void ) =
	CallDispatchedFunction( kGetBGMDisable );	

Err		StartDBBGM(DBID bgmID) = 
	CallDispatchedFunction( kStartDBBGM );	

Err		PlayDBFX(DBID fxID, short theDuration, short theFreq) =
	CallDispatchedFunction( kPlayDBFX );



// Low-Level routines

void	InitSoundMgr(void) =
	CallDispatchedFunction( kInitSoundMgr );
					
void	ShutDownSoundMgr(void) =
	CallDispatchedFunction( kShutDownSoundMgr );
					
Err 	StopBGM(void) = 
	CallDispatchedFunction( kStopBGM );

long	FX1NoteOff(void) =
	CallDispatchedFunction( kFX1NoteOff );

long	FX2NoteOff(void) =
	CallDispatchedFunction( kFX2NoteOff );
	


// GEMs Funcs in SegaSound.a.o

		/* start up the Gems system, including loading the Z80, starting it, and 				*/
		/*  passing pointers into the 68000 ROM for patches, envelopes, sequences and samples 	*/

void 	gemsinit( long patchbankptr, long envbankptr, long seqbankptr, long sampbankptr );

void 	gemsstartsong( long seqno );					/* start a sequence */
void 	gemsstopsong( long seqno );						/* stop a sequence */
void 	gemsstopall();									/* stop all sequences */
void 	gemspauseall();									/* pause all active sequences */
void 	gemsresumeall();								/* resume all paused sequences */


void 	gemssettempo( long newtempo );					/* set the global tempo value in beats per minute */

void 	gemslockchannel( long channel );				/* lock a channel for use with sound effects */

void 	gemssetprio( long channel, long priority );		/* set the note on priority for a channel */

void 	gemsunlockchannel( long channel );				/* unlock a channel when done with making sound effects on it */

void 	gemsnoteon( long channel, long notenum );		/* turn on notenum() on channel */

void 	gemsnoteoff( long channel, long notenum );		/* turn off notenum on channel */

void 	gemsprogchange( long channel, long newprog );	/* change the patch to newprog on channel */

void 	gemspitchbend( long channel, long bendamt );	/* bend the note on channel by bendamt(signed 8-bit frac # semi-tones) */

void 	gemssetenv( long channel, long envnum );		/* change the pitch modulator to envnum on channel */
														/*  trigger the envelope if not in note-on retrigger mode */

void 	gemsretrigenv( long channel, long val );		/* turn on/off the note-on retrigger mode on channel */
														/*  val = 80h is on, val = 0 is off(explicit envelope trigger) */

void 	gemssustain( long channel, long val );			/* turn on/off the sustain mode on channel */
														/*  val = 80h is on, val = 0 is off */

void 	gemssamprate( long channel, long rate );		/* set the digital playback rate on channel */
														/*  rate = 4 means dont override rate in sample bank */
														/*  rate = 5 means play samples back at 10.4 kHz; see docs for more */

void 	gemsmute( long song, long channel, long val );	/* mute a channel of a song */
															/*  val = 1 is mute, val = 0 is enabled */

void 	gemsstorembox( long mbox, long val );			/* store a value in a mailbox */
														/*  legal mailbox #s are 0..29, values are 0..127 */

short 	gemsreadmbox( long mbox );						/* read a value from a mailbox */
														/*  legal mailbox #s are 0..29, values are 0..127 */


/* the following are low-level support routines */	

void 	gemsdmastart( void );				/* tell the z80 we want to do dma */																	
void 	gemsdmaend( void );					/* tell the z80 we're done with dma */


void 	gemsholdz80( void );				/* hold the Z80 - ### use this before accessing the control paddle ports */
void 	gemsreleasez80( void );				/* resume the Z80 - ### use this after accessing the control paddle ports */


void 	gemsloadz80( void );				/* load the Z80 - called by initgems - DON'T USE */
void 	gemsstartz80( void );				/* start the Z80 - called by initgems - DON'T USE */


void 	gemsputcbyte( long b );				/* put a command byte on the Z80 command queue */
void 	gemsputptr( long p );				/* put a ptr on the Z80 command queue */


#endif __SegaSound__

