/*
 * @(#) SegaSoundPriv.h 1.1@(#)
 */

/*
	File:		SegaSoundPriv.h

	Contains:	

	Written by:	Joe Britt

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <7>	 8/17/94	JOE		Moved z80ResetCtl reg addr here
		 <6>	 8/13/94	JOE		Global for SetBGMDisable
		 <5>	 7/16/94	JOE		updates
		 <4>	 7/15/94	JOE		updating to Sega Sound Driver.
		 <3>	 7/10/94	JOE		moved private sound IDs here
		 <2>	 6/20/94	SAH		Added the buffer global.
		 <1>	 5/30/94	SAH		first checked in
	To Do:
*/

#ifndef __Time__
#include "time.h"
#endif


#ifdef SIMULATOR
#define	SIMPRINT(x)			printf x;
#else
#define	SIMPRINT(x)
#endif


#define	z80ResetCtl		0xA11200		// 0x0000 = ASSERT reset, 0x0100 = RELEASE reset


#define	kSoundBufferSize	4096

// FX Voice Allocation

#define	kFXVoice1Channel	15			// zero-based
#define	kFXVoice2Channel	14

#define	kFXVoice1Patch		16			// zero-based
#define	kFXVoice2Patch		15

#define	kFMSoundSize		39			// each sound in a patch table is 39 bytes long

#define	kNumPatchesInBank	17			// all sequences should have 17 patches, 
										//  emptys for any unused slots
										
#define	kPatchBankSize		(kFMSoundSize * kNumPatchesInBank) + (2 * kNumPatchesInBank)		
											// patch data + offsets
								
#define	kFXVoice1PatchOffset	kPatchBankSize - kFMSoundSize
#define	kFXVoice2PatchOffset	kFXVoice1PatchOffset - kFMSoundSize


typedef struct noteOffRec {

	long			duration;
	long			freq;
	TimeProcRef		timeRef;
	Boolean			firstCall;
	
	} noteOffRec;


typedef struct SoundGlobals {
	
	noteOffRec		FX1NoteOffRec;
	noteOffRec		FX2NoteOffRec;
	Ptr				soundBuffer;
	DBID			curBGMPlaying;
	Boolean			useFXVoice1;
	Boolean			BGMDisabled;
	
	} SoundGlobals;
	

#ifdef SIMULATOR
#define MANAGERGLOBALTYPE SoundGlobals
#else
extern SoundGlobals soundglobs;
#endif





// Private FX IDs

#define kKeyClick1			0
#define kKeyClick2			1
#define kHellHiss			2 
#define kOutland 			3

#define	kStandardBGM		1


