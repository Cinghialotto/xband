/*
 *	$Id: BoxProfile.h,v 1.2 1995/05/11 22:57:09 jhsia Exp $
 *	
 *	$Log: BoxProfile.h,v $
 * Revision 1.2  1995/05/11  22:57:09  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		BoxProfile.h

	Contains:	Def's & structures for performance tool

	Written by:	Andy Stadler

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <4>	 8/14/94	ADS		Lotsa new stuff.  Default is off.
		 <3>	 8/11/94	JBH		Turn it off for the simulator as well, until Andy moves some
									profile data out of SRAM (it's full!)
		 <2>	 8/10/94	SAH		Don't profile for the ROMDB either.
		 <1>	  8/9/94	ADS		first checked in

	To Do:
*/



#ifndef __BOXPROFILE_H_
#define __BOXPROFILE_H_


//
//-----Set the following flag to turn on dispatcher code profiling
//

//	#define DISPATCHER_PROFILING





//  Everything else in this file only exists when we have profiling compiled in

#ifdef DISPATCHER_PROFILING


/*---------------------------
 * profiler magic numbers
 *---------------------------*/


#define gMasterPrevTick		SegaLowMem.debugReserve1
#define gMasterTickCounter	SegaLowMem.debugReserve2
#define gProfDispatch		SegaLowMem.reserved11	// and 12!

#define kTickVBLCount		0x5c43+4		// approx value @ vbl entry
#define kTickMaxCount		0x61BF			// approx highest value

#define kTimerBytesMask 	0x00C000FF;		// that's 00LL00HH, but masked
#define kTimerAddr			kDefaultInternal+kReadMVSyncLow
#define kTimerShiftLSB		6				// # of unused LSB after mask


/*---------------------------
 * dispatcher profiling control calls
 *---------------------------*/


#ifdef SIMULATOR

#define ResetProfiles	xResetProfiles
#define ProfileControl	xProfileControl
#define ReportProfiles	xReportProfiles

#else

#define kProfDispatch	0xF8

						// move.w  #sel	  jsr.w	  dispatcher
#define ProfDisp(sel)	{ 0x303c, (sel), 0x4EB8, kProfDispatch }

enum	{
	kResetProfiles	= 1,
	kProfileControl,
	kReportProfiles
};

void ResetProfiles(void) =
	ProfDisp( kResetProfiles );
void ProfileControl(Boolean on) =
	ProfDisp( kProfileControl );
void ReportProfiles(Boolean disposeAfter) =
	ProfDisp( kReportProfiles );

#endif


void SwapProfiles(Boolean inVBL);		// ONLY called by vbl task
void xResetProfiles(void);
void xProfileControl(Boolean on);
void xReportProfiles(Boolean disposeAfter);



/*---------------------------
 * dispatcher profiling data structures
 *---------------------------*/


//#define PROFILE_IN_OS_MEM
#define PROFILE_IN_HEAPS

typedef
struct ProfileEntry
{
	long	pureTime;			// time spent IN this routine
	long	totalTime;			// time spent in this routine AND its descendants
} ProfileEntry;


typedef
struct ProfileTable
{
	short			numEntries;
	unsigned long	startRun;		// start time of current run
	unsigned long	totalRun;		// total time of all runs
	
	ProfileEntry table[];
} ProfileTable;


typedef
struct	ProfileGlobalStack
{
	long	childTime;
	long	callNum;
	long	startTime;
	long	oldGlobals;
	long	returnAddr;
} ProfileGlobalStack;




#endif		// DISPATCHER_PROFILING

#endif		// __BOXPROFILE_H_


