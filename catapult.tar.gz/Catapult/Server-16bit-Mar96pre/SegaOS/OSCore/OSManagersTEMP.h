/*
 *	$Id: OSManagersTEMP.h,v 1.2 1995/05/11 22:57:27 jhsia Exp $
 *	
 *	$Log: OSManagersTEMP.h,v $
 * Revision 1.2  1995/05/11  22:57:27  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		OSManagersTEMP.h

	Contains:	xxx put contents here xxx

	Written by:	Andy Stadler

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <8>	 8/14/94	ADS		Obsolete again, nobody should be using it
		 <7>	 7/20/94	ADS		Cleared out again
		 <6>	 7/19/94	ADS		Vector Mania
		 <5>	 7/18/94	ADS		Dispatcher cleanup
		 <4>	 7/17/94	ADS		added fifo manager
		 <3>	 7/14/94	ADS		Empty for this round
		 <2>	 7/14/94	ADS		Added NetMiscManager
		 <1>	 7/13/94	ADS		first checked in

	To Do:
*/



	* * * 	I AM OBSOLETE	* * * 


