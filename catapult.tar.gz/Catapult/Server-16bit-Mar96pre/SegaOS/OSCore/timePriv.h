/*
 *	$Id: timePriv.h,v 1.2 1995/05/11 22:57:44 jhsia Exp $
 *	
 *	$Log: timePriv.h,v $
 * Revision 1.2  1995/05/11  22:57:44  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		timePriv.h

	Contains:	xxx put contents here xxx

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <7>	 8/11/94	HEC		Added delayThresh global.
		 <6>	 7/31/94	HEC		Added inOSIdle to globals to solve reentrancy problem.
		 <5>	 7/22/94	SAH		Moved current time to gTicks lowmem
		 <4>	 7/10/94	SAH		Added the inIdle global.
		 <3>	  7/2/94	SAH		Jesus is here!
		 <2>	 5/30/94	SAH		Add osidle proc.
		 <1>	 5/12/94	SAH		first checked in

	To Do:
*/



typedef
struct TimeRequest
{
	struct TimeRequest *	next;
	long					fireTime;
	long					flags;
	TimeRequestProc			proc;
	long					data;
} TimeRequest;


typedef
struct TimeGlobals
{
	TimeRequest *	tasks;
	SegaOSIdlePtr	gOSIdle;
	long			jesusTime;
	long			jesusDate;
	Boolean			inIdle;
	Boolean			inOSIdle;
	short			delayThresh;
} TimeGlobals;


#ifdef SIMULATOR
#define MANAGERGLOBALTYPE TimeGlobals
#else

extern TimeGlobals time;

#endif

/*
* flags
*/
enum
{
	kTaskDisposed = 1,			// the task was disposed of re-entrantly, kill it when safe
	kTaskActive = 2				// the task is currently active (being executed)
};


