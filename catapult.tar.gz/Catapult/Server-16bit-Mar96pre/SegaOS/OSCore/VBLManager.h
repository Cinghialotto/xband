/*
 *	$Id: VBLManager.h,v 1.2 1995/05/11 22:57:39 jhsia Exp $
 *	
 *	$Log: VBLManager.h,v $
 * Revision 1.2  1995/05/11  22:57:39  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		VBLManager.h

	Contains:	xxx put contents here xxx

	Written by:	Joe Britt (mucho ripped off from Shannon Holland)

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <2>	 7/28/94	JOE		don't have something hilited when u check in...it can get zapped
		 <1>	 7/28/94	JOE		first checked in
	To Do:
*/

#ifndef __VBLMgr__
#define __VBLMgr__

#ifndef __SegaOS__
#include "SegaOs.h"
#endif


#ifndef __SERVER__

typedef long * VBLProcRef;

typedef long (*VBLRequestProc) ( long data );


VBLProcRef	AddVBLRequest ( VBLRequestProc proc, long data, long firstFire ) =
	CallDispatchedFunction( kAddVBLRequest );

short	RemoveVBLRequest ( VBLProcRef ref ) =
	CallDispatchedFunction( kRemoveVBLRequest );

short	VBLIdle ( void ) =
	CallDispatchedFunction( kVBLIdle );


#endif __SERVER__

#endif __VBLMgr__
