/*
 *	$Id: MessDisp.h,v 1.2 1995/05/11 22:57:19 jhsia Exp $
 *	
 *	$Log: MessDisp.h,v $
 * Revision 1.2  1995/05/11  22:57:19  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		MessDisp.h

	Contains:	xxx put contents here xxx

	Written by:	Konstantin Othmer

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <7>	 8/22/94	ADS		Add hidden box serial # calls
		 <6>	  8/9/94	HEC		Move errors to errors.h.
		 <5>	 7/18/94	DJ		added kOpponentVerificationFailed for peer verification
		 <4>	  6/4/94	DJ		added some poop that is irrelevant now
		 <3>	  6/4/94	DJ		fixed ifndefs for SERVER
		 <2>	  6/4/94	KON		Added individual sizes to send, receive, and peer opcode tables.
		 <3>	 5/18/94	BET		Add #include "OSManagers.h"
		 <2>	 5/12/94	KON		Make SendMessage take a void* instead of a long.

	To Do:
*/

#ifndef __MessDisp__
#define __MessDisp__

typedef long MessErr;

#ifndef __SERVER__

#include "OSManagers.h"
#include "Dispatcher.h"


typedef MessErr (*opCodeProcPtr)(void);			//opcodes take a void and return a short
typedef void (*sendOpCodeProcPtr)(void *);		//messages take a void * and return a short


MessErr InitMessages( void ) =
	CallDispatchedFunction( kInitMessages );

MessErr ProcessServerData ( void ) = 
	CallDispatchedFunction( kProcessServerData );

MessErr ProcessPeerData ( void ) =
	CallDispatchedFunction( kProcessPeerData );
	
MessErr SendMessage ( long opCode, void * theParameter ) = 
	CallDispatchedFunction( kSendMessage );
	
void SetClearLoginMisc ( long setBits, long clearBits ) =
	CallDispatchedFunction ( kSetClearLoginMisc );
	
long GetLoginMisc ( void ) =
	CallDispatchedFunction ( kGetLoginMisc );

#endif __SERVER__

#endif __MessDisp__
