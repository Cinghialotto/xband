/*
 *	$Id: List.h,v 1.2 1995/05/11 22:57:18 jhsia Exp $
 *	
 *	$Log: List.h,v $
 * Revision 1.2  1995/05/11  22:57:18  jhsia
 * switch to rcs keywords
 *
 */


/************************************************************************/
/*	 Tub-o-cheese list package	 										*/
/************************************************************************/

#ifndef LIST_H
#define LIST_H


typedef struct ListNode {
	Ptr				data;
	struct ListNode *prev, *next;
	struct ListHead	*head;
} ListNode;

typedef struct ListHead {
	ListNode 		*list;
} ListHead;

/************************************************************************/
/*	 List manipulators 													*/
/************************************************************************/

ListHead *NewList(
	void);
	
Err AddListNodeToList(
	ListHead 	*head,
	ListNode	*node);

ListNode *GetFirstListNode(
	ListHead	*head);

long NumListNodesInList(
	ListHead	*head);

Err EmptyList(
	ListHead	*head);

Err DisposeList(
	ListHead	*head);

/************************************************************************/
/* Node manipulators 													*/
/************************************************************************/

ListNode *NewListNode(
	Ptr			data);

Err RemoveListNodeFromList(
	ListNode	*node);

ListNode *GetNextListNode(
	ListNode 	*node);

ListNode *GetPrevListNode(
	ListNode	*node);

Err DisposeListNode(
	ListNode	*node);

Ptr GetListNodeData(
	ListNode	*node);

Err SetListNodeData(
	ListNode	*node,
	Ptr			data);

#endif

