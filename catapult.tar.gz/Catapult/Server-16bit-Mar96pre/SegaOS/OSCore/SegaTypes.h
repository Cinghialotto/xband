/*
 *	$Id: SegaTypes.h,v 1.5 1995/05/11 22:57:37 jhsia Exp $
 *	
 *	$Log: SegaTypes.h,v $
 * Revision 1.5  1995/05/11  22:57:37  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		SegaTypes.h

	Contains:	xxx put contents here xxx

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<32>	 8/27/94	HEC		Added cardPrefix to the XBANDCard structure.
		<31>	 8/25/94	SAH		Kill NEWERRORS.
		<30>	 8/25/94	HEC		Added kPeerToPeerConnectCardProb and kSlaveTimedOutCardProb
		<29>	 8/24/94	BET		Add new netErrorStruct under conditional compile NEWERRORS until
									we can flush the old boxes.
		<28>	 8/20/94	KON		Moved serverUniqueID to PlayerInfo and put ColorTableID in its
									place in userIdentification.
		<28>	 8/20/94	KON		Moved serverUniqueID to PlayerInfo and put ColorTableID in its
									place in userIdentification.
		<27>	 8/18/94	HEC		Added XBANDCard typedef.
		<26>	 8/18/94	ADS		Hide gBoxID globals
		<25>	 8/13/94	BET		Move server connects to top of NetErrorStruct, add script error
									field.
		<24>	 8/12/94	JOE		nuke IconRef struct, update userIdentification struct
		<23>	 8/11/94	JOE		made userValid info a bunch of flags
		<22>	 8/10/94	BET		Added scriptID brokering vi phoneNumber structure.
		<21>	  8/9/94	ATM		phoneNumbers are now 24 digits (when will the madness end?!)
		<20>	  8/5/94	DJ		phonenumbers are now 16 digits
		<19>	  8/4/94	ADS		Changed old padByte to serverUniqueID
		<18>	  8/4/94	ATM		Made NetTypes.h UNIX-only to keep the Mac build from breaking.
									Need a UNIX #include file with all of the Mac "Types.h"
									definitions.
		<17>	  8/4/94	ATM		Added NetTypes.h include; UNIX server build was broken by
									Boolean.
		<16>	  8/3/94	JOE		don't need taunt/info string DBIDs
		<15>	  8/3/94	JOE		Added some more user info to the BoxIdentification struct
		<14>	  8/1/94	HEC		Added validationToken to BoxIdentification
		<13>	  8/1/94	HEC		Added lastCard and problemToken to BoxIdentification struct.
		<12>	 7/25/94	SAH		Added gameError to the GameResult structure.
		<11>	 7/21/94	BET		Add some padding to match Stun structure packing
		<10>	 7/19/94	DJ		BoxIdentification now has boxhometown and user icons
		 <9>	 7/18/94	KON		Made hometown part of useridentification.
		 <8>	 7/18/94	KON		Added IconRefStruct and made it part of userIdentification and
									moved DBID here from DataBase.h.
		 <7>	 7/16/94	HEC		Added call waiting errors.
		 <6>	 7/15/94	SAH		New GameResult.
		 <5>	 7/10/94	SAH		Brought NetErrorRecord in from NetStructs.h
		 <4>	  7/5/94	JOE		decided that userIdentification wasn't the best place to put the
									Town & BDay.
		 <3>	 8/28/56	SAH		Changed the base phone number to the localAccessNumber.
		 <2>	  7/5/94	JOE		expanded userIdentification struct to include Town and Birthday,
									as well as bait preference.
		 <1>	 6/28/94	SAH		first checked in

	To Do:
*/




#ifndef __SegaTypes__
#define	__SegaTypes__

#ifdef unix
#include "NetTypes.h"		// need definition of Boolean for UNIX
#endif

#define kPhoneNumberSize	24					// must be even to keep Stink C
#define kUserNameSize		34					// from screwing up sizeof() calculation!!
#define kUserTownSize		34					
#define kMaxLocalUsers 		4

// phoneNumber type item ID's
enum {
	kBoxPhoneNumID = 0,
	kChallengePhoneNumID,
	k800PhoneNumID
	};
	
// History data base uses this data base to store opponents names
// stale names (no longer referred to by the history data base)
// are flushed here by walking the results and making sure each active
// opponent has some result associated with him. If not, he's outta here!
//

// Problem cases for using Problem Token

enum {
	kNoDialtoneInServerConnectCardProb = 1,
	kSomeErrorInServerConnectCardProb,
	kLineBusyInServerConnectCardProb,
	kServerConnectRetryDoneCardProb,
	kServerCommErrorCardProb,
	kGameFreeTimeOverCardProb,
	kPeerToPeerConnectCardProb,
	kSlaveTimedOutCardProb
};

typedef struct {
	long	token;			// a magic token may travel with this card
	short	type;			// kCardGPM896 or kCardGPM103
	short	rechargesLeft;	// times card can be recharged (if GPM896)
	short	creditsLeft;	// credits remaining on card after debit
	unsigned char problem;	// if problem token used, identifies "why" it was used.
	char	pad[1];			// pad out Mac to same size as Sparc unix.	
	long	serialNumber;	// every card has unique serial number for tracking
	long	cardPrefix;		// Any card's first four bytes
	long	reserved;		// for the future!
} XBANDCard;

typedef unsigned char DBID;

typedef struct
{
	DBID	scriptID;
	char	length;			// length of phoneNumber (only for Server_SendOpponentPhoneNumber)
	char	phoneNumber[kPhoneNumberSize];	//extra character to buffer for C-string
} phoneNumber;

typedef
struct BoxSerialNumber
{
	long	region;				// the region id for the box
	long	box;				// the identifier for this box within the region
} BoxSerialNumber;


typedef	char			UserName[kUserNameSize];
typedef	char			Hometown[kUserTownSize];

#define	kPWLen	8

typedef unsigned char	Password[kPWLen];


typedef
struct userIdentification
{
	BoxSerialNumber	box;			//unique per box
	unsigned char	userID;			//0-3 for local, > kOpponentRangeStart for others
	unsigned char	colorTableID;	// allows server to assign tracking numbers
	DBID			ROMIconID;		// RAM icon, if there is one, comes from box & userID
	Hometown		userTown;
	UserName		userName;		//extra character to buffer for C-string
} userIdentification;



//
// NetErrorRecord for SNES (sn03+); since it's a superset of the segb one,
// it's used to store things internally.
//
typedef struct NetErrorRecord {
	unsigned char			serverConnects;				// may be redundant if cleared each server contact
	unsigned char			peerConnects;				// may be redundant if cleared each server contact
	unsigned short			framingError;
	unsigned short			overrunError;
	unsigned short			packetError;
	unsigned char			callWaitingInterrupt;
	unsigned char			noDialtoneError;
	unsigned char			serverBusyError;
	unsigned char			peerBusyError;
	unsigned char			serverDisconnectError;
	unsigned char			peerDisconnectError;
	unsigned char			serverAbortError;			// if we were connected to the server and asked for abort
	unsigned char			peerAbortError;				
	unsigned char			serverNoAnswerError;		// Originate timed out
	unsigned char			peerNoAnswerError;			// Originate timed out
	unsigned char			serverHandshakeError;		// Connection started but failed.
	unsigned char			peerHandshakeError;			// Connection started but failed.
	unsigned char			serverX25NoServiceError;	// if there are no circuits available
	unsigned char			callWaitingError;			// we got call waiting during connection
	unsigned char			remoteCallWaitingError;		// remote modem got call waiting
	unsigned char			scriptLoginError;			// selected script flaked out
	unsigned char			packetRetransError;			// count of times we had to retransmit
	unsigned char			usedAltPOPNumber;			// was alternate POP used?
	unsigned char			ctsTimeouts;				// #of CTS timeouts
	unsigned char			spinloopTimeouts;			// #of "oh fuck..."
	unsigned char			reserved[8];				// unused
} NetErrorRecord; 

//
// segb and pre-sn03 don't have the extra reserved fields at the end
//
typedef struct segb_NetErrorRecord {
	unsigned char			serverConnects;				// may be redundant if cleared each server contact
	unsigned char			peerConnects;				// may be redundant if cleared each server contact
	unsigned short			framingError;
	unsigned short			overrunError;
	unsigned short			packetError;
	unsigned char			callWaitingInterrupt;
	unsigned char			noDialtoneError;
	unsigned char			serverBusyError;
	unsigned char			peerBusyError;
	unsigned char			serverDisconnectError;
	unsigned char			peerDisconnectError;
	unsigned char			serverAbortError;			// if we were connected to the server and asked for abort
	unsigned char			peerAbortError;				
	unsigned char			serverNoAnswerError;		// Originate timed out
	unsigned char			peerNoAnswerError;			// Originate timed out
	unsigned char			serverHandshakeError;		// Connection started but failed.
	unsigned char			peerHandshakeError;			// Connection started but failed.
	unsigned char			serverX25NoServiceError;	// if there are no circuits available
	unsigned char			callWaitingError;			// we got call waiting during connection
	unsigned char			remoteCallWaitingError;		// remote modem got call waiting
	unsigned char			scriptLoginError;			// selected script flaked out
	unsigned char			packetRetransError;			// count of times we had to retransmit
	unsigned char			usedAltPOPNumber;			// was alternate POP used?
	unsigned char			ctsTimeouts;				// #of CTS timeouts
	unsigned char			spinloopTimeouts;			// #of "oh fuck..."
} segb_NetErrorRecord; 

/*
* This struct is used to communicate between the game patch
*/

typedef
struct GameResult
{
	long			size;					// the size of the game results structure
	long			gameID;
	long			gameError;
	unsigned long	localPlayer1Result;
	unsigned long	localPlayer2Result;
	unsigned long	remotePlayer1Result;
	unsigned long	remotePlayer2Result;
	long			playTime;
	long			dbIDDataPtr;
	long			dbIDDataSize;
	long			gameReserved[ 10 ];
	short			numLocalPlayers;
	char			pad[2];
} GameResult;

#endif

