/*
 *	$Id: OSManagers.h,v 1.2 1995/05/11 22:57:26 jhsia Exp $
 *	
 *	$Log: OSManagers.h,v $
 * Revision 1.2  1995/05/11  22:57:26  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		OSManagers.h

	Contains:	Selectors for managers and functions.

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

	   <299>	 8/27/94	ADS		Needed to be below the patch range, not above (sorry2)
	   <298>	 8/27/94	CMY		Added kPreflightNewAddressEntry...sorry!
	   <297>	 8/27/94	SAH		Changed sinko selectors. Created some unused lametalk selectors.
	   <296>	 8/26/94	JBH		Added memory manager routines to help the database compact with
									the minimum of DB unstable time.
	   <295>	 8/25/94	JOE		more hardware keyboard stuff
	   <294>	 8/24/94	SAH		More lametalk formats/stinkotron functions.
	   <293>	 8/24/94	JOE		Add some hardware keyboard stuff
	   <292>	 8/23/94	BET		Add kClearNetErrors.
	   <291>	 8/23/94	HEC		Added PeerConnect VBL routines.
	   <290>	 8/22/94	SAH		Filled two reserved entries with GT controller 16 stuff.
	   <289>	 8/22/94	SAH		Stink.
	   <288>	 8/22/94	ADS		Killed old peerconnect, added new hiddenserialnumber & login
									flags calls
	   <287>	 8/21/94	JOE		Add kGetGamePatchFlags
	   <286>	 8/21/94	KON		Add kHueShift.
	   <285>	 8/20/94	JOE		Add kGetLocalUserCustomROMClutID & kSetLocalUserCustomROMClutID
	   <284>	 8/20/94	JBH		Added kIncrementClutReferences.
	   <283>	 8/20/94	SAH		Added kGTSyncotron.
	   <282>	 8/20/94	BET		Add kPGetDebugChatScript.
	   <281>	 8/20/94	CMY		Added Get/Set AcceptChallengeOption.
	   <280>	 8/20/94	JOE		added kGetBGMDisable
	   <279>	 8/19/94	JBH		Moved DBpurge manager into db manager
	   <278>	 8/19/94	ADS		Changed OS patch stuff, removed a couple obsolete
	   <277>	 8/19/94	JBH		Added DBPurge manager
	   <276>	 8/18/94	ADS		Move all boxID stuff to BoxSer.  Kill PhoneManager
	   <275>	 8/18/94	JBH		Added kDisposeOldestGamePatch, kMarkGamePatchUsed.
	   <274>	 8/18/94	HEC		Adding kUserWantsToDebitCard.
	   <273>	 8/17/94	JBH		Adding kGetScreensEnteredCount.
	   <272>	 8/17/94	JOE		new game value funcs
	   <271>	 8/17/94	JBH		Added kAddItemToDB, kDBAddItemHighPtrSize, kCompactPermDatabase,
									kNewMemoryHigh (instead of kNewTempHigh)
	   <270>	 8/16/94	CMY		Added SetKeyLayoutMeasureProc
	   <269>	 8/15/94	JOE		Add kDisposeGamePatch
	   <268>	 8/15/94	JBH		Added kDisableDefDialogs, kEnableDefDialogs
	   <267>	 8/14/94	SAH		Added kCorrelateAddressBookEntry.
	   <266>	 8/13/94	BET		Add kGetNetErrors.
	   <265>	 8/13/94	HEC		Add kCheckWipeCard
	   <264>	 8/13/94	KON		Add kSyncOTron.
	   <263>	 8/13/94	BET		Add kFifoPeekEnd.
	   <262>	 8/13/94	JOE		added kSetBGMDisable
	   <261>	 8/12/94	JOE		put back in Kon's GetIconBitMap() call
	   <260>	 8/12/94	JOE		Custom icon changes to PersonficationMgr, BoxSer, UsrConfg, and
									Icon stuff
	   <259>	 8/27/56	JBH		Added kDrawXBandNews, kDisposeXBandNews.
	   <258>	 8/12/94	HEC		Added DebitCardForConnect. Removed UsingSmartCard.
	   <257>	 8/11/94	JBH		Added kSetNewsCountdownTimeConst
	   <256>	 8/11/94	JBH		Added kDrawXBandLogo, kDisposeXBandLogoRef,
									kDisposeXBandLogoSparks. Removed kPeerSetupSparks,
									kPeerTrashSparks.
	   <255>	 8/10/94	KON		Remove dismissal animation since it tears the screen.
	   <254>	 8/10/94	KON		Add kGetIconBitMap.
	   <253>	 8/10/94	KON		Added getIconBitMap call.
	   <252>	  8/9/94	CMY		Added FillNameTable
	   <251>	  8/9/94	KON		Added countDefDialogs.
	   <250>	  8/9/94	KON		Remove dispose aux background graphic.
	   <249>	  8/9/94	SAH		Added opponent personification dbid calls.
	   <248>	  8/9/94	JOE		Nuke kClearGameNames
	   <247>	  8/8/94	JOE		Added Joggler support
	   <246>	  8/8/94	JBH		Added kCreateShiners, kDisposeShiners.
	   <245>	  8/8/94	KON		Add AuxBackground graphic support.
	   <244>	  8/7/94	JOE		added kSetGameValue
	   <243>	  8/7/94	JOE		added kGetGameValue
	   <242>	  8/6/94	HEC		added kDoPeerDialog and kPUCheckRing.
	   <241>	  8/6/94	JOE		added kGetCurScreenIdentifier
	   <240>	  8/5/94	JBH		Added kGetGraphicReferenceClut
	   <239>	  8/5/94	ADS		Removed "db unstable type" stuff completely
	   <238>	  8/5/94	JOE		Added kSetJizzlerBehavior & kGetJizzlerBehavior
	   <237>	  8/4/94	JOE		Added sine & cosine to math mgr
	   <236>	  8/4/94	HEC		Removed some old peerconnect routines.
	   <235>	  8/4/94	HEC		added personifuckation routine
	   <234>	  8/4/94	SAH		New game error stuff.
	   <233>	  8/3/94	JOE		new icon routines
	   <232>	  8/3/94	JOE		Personification mgr update, new UsrConfg stuff,
									DrawDBIconWithoutIREF
	   <231>	  8/3/94	HEC		Added accessors to XBAND options in BoxSer.
	   <230>	  8/3/94	SAH		Added gametalk loose session poo.
	   <229>	  8/2/94	SAH		Added get and set os version.
	   <228>	  8/2/94	HEC		New personification stuff.
	   <227>	  8/2/94	CMY		Managerized RandomShort
	   <226>	  8/2/94	JOE		added kGetRankingSize
	   <225>	  8/2/94	SAH		Added some more gametalk calls.
	   <224>	  8/1/94	JOE		added kTestThisSequence
	   <223>	  8/1/94	CMY		Added NewTempMemHigh.
	   <222>	  8/1/94	MWF		added initControllers
	   <221>	  8/1/94	KON		Remove capture and playback managers.
	   <220>	  8/1/94	CMY		Added blinky sprites and sprite palette control routines.
	   <219>	  8/1/94	HEC		Removed a ton of unused/undefined selectors.
	   <218>	  8/1/94	HEC		Added [Get][Set]ValidationToken to BoxSer manager.
	   <217>	  8/1/94	HEC		New BoxSer routines, smartcard changes, peerconnect routines.
	   <216>	  8/1/94	JOE		added selector for hidden shit ranking mgr call
	   <215>	 7/31/94	CMY		Added selectors for private keyboard caching calls.
	   <214>	 7/31/94	KON		Added kGetUniqueWriteableStringID.
	   <213>	 7/31/94	KON		Added delete writeable string and changed server strings to
									writeable strings.
	   <212>	 7/31/94	KON		Added get and set server string.
	   <211>	 7/31/94	HEC		Removed kSendAndWaitForMagicToken, kDoPeerDataExchange.  Added
									new PeerConnect routines.
	   <210>	 7/30/94	CMY		Added GetDecompressorCache for controlling caching of
									dictionaries.
	   <209>	 7/29/94	CMY		Fixed selector for BoxScreenLayoutString.
	   <208>	 7/29/94	CMY		Added screen layout utils.
	   <207>	 7/29/94	HEC		Added kPUCheckCarrier.  Renamed kPUCheckLineNoise to
									kPUCheckLine.
	   <206>	 7/28/94	JOE		added VBL manager
	   <205>	 7/28/94	JOE		added kShutDownSoundMgr
	   <204>	 7/27/94	KON		Add calls to set and check network dial again flag.
	   <203>	 7/27/94	HEC		Removed kGetCreditToken, kSetCreditToken.
	   <202>	 7/26/94	CMY		Added sprite and pattern routines to use high pattern mems.
	   <201>	 7/26/94	JOE		Ranking Mgr changes
	   <200>	 7/26/94	SAH		Added kGTSCloseSessionSynch.
	   <199>	 7/26/94	JBH		Added maze to secrets
	   <198>	 7/26/94	HEC		Added kHandleCallWaiting and kFlushUserEvents.
	   <197>	 7/25/94	DJ		Add kTGetTransportHoldSession, kTSetTransportHoldSession.
	   <196>	 7/25/94	BET		Add kTGetTransportHold, kTSetTransportHold.
	   <195>	 7/25/94	KON		Add draw news return icon.
	   <194>	 7/25/94	KON		Remove show news next page control.
	   <193>	 7/25/94	CMY		Added GetAnimationSuspendLevel.
	   <192>	 7/24/94	JBH		Added Sparks to sprite manager (for waiting for server /
									opponent screen).
	   <191>	 7/24/94	JBH		Added that crazy JoshDecompress (named after a different Josh,
									no doubt...)
	   <190>	 7/22/94	SAH		More GameTalk/modem stuff.
	   <189>	 7/22/94	SAH		New gametalk fuckers.
	   <188>	 7/22/94	BET		Add kPUMatchString
	   <187>	 7/21/94	ADS		Replaced to controller read entries
	   <186>	 7/21/94	BET		Add kPUDoSelectorLogin.
	   <185>	 7/21/94	KON		Added GetCurFontLineHeight.
	   <184>	 7/21/94	CMY		Your mother sucks cocks in hell and you have to rebuild your
									project.
	   <183>	 7/21/94	HEC		Checked in lots of fun new smart card routines.
	   <182>	 7/20/94	ADS		final merge from Vector Mania
	   <181>	 7/20/94	DJ		added kGetCompetitionResults
	   <180>	 7/19/94	DJ		added set/get user icons, get/set boxhometown
	   <179>	 7/19/94	CMY		SetDecompressorImage, SetSpriteImage, and GetDBButtonGraphic to
									support golden animating buttons.
	   <178>	 7/19/94	JOE		update GameDB selectors
	   <177>	 7/18/94	CMY		Jizzling boxes
	   <176>	 7/18/94	KON		Add routines to draw and dispose of icons by reference.
	   <175>	 7/18/94	ADS		Dispatcher cleanup
	   <174>	 7/17/94	KON		Add routines for marking address book as updated and finding out
									if a players book is changed.
	   <173>	 7/17/94	DJ		added opponentVerificationTag
	   <172>	 7/17/94	CMY		Added routines for managing dictionary caches for the
									decompressors.
	   <171>	 7/17/94	JBH		Added kDontPlayAgain, so error-cases out of games don't ask for
									a rematch.
	   <170>	 7/17/94	HEC		Added kGetCreditToken and kSetCreditToken.
	   <169>	 7/17/94	CMY		Added GetImageClut, bumped size of selector table.
	   <168>	 7/17/94	HEC		Added kPUAsyncReadDispatch for Andy...
	   <167>	 7/17/94	JBH		Added DoPlayAgainDialog.
	   <166>	 7/16/94	HEC		Added tons of managerized PModem calls. Added more SmartCard
									calls.
	   <165>	 7/16/94	JOE		new sound mgr shit
	   <164>	 7/16/94	JBH		Added thank-you routine to EndGame
	   <163>	 7/15/94	JBH		Aded kGetClut, kGetColorLuminance.
	   <162>	 7/15/94	SAH		Some new BoxServices calls for game results.
	   <161>	 7/15/94	CMY		Added kDeleteAllOutBoxMail to fuck up Joe.
	   <160>	 7/15/94	JBH		Add more clut calls (RequestUniqueClut, RequestSpecificClut,
									SetupClut).
	   <159>	 7/14/94	ADS		Merged lotsa new stuff
	   <158>	 7/14/94	CMY		Add RadioButtonManager
	   <157>	 7/14/94	CMY		Add GetIndexInBoxMail.
	   <156>	 7/13/94	CMY		Added CountOutBoxEntries and GetKeyLayoutFieldCount.
	   <155>	 7/12/94	KON		Add kIsBoxRegistered flag.
	   <154>	 7/12/94	SAH		Added kCreateGameDispatcher.
	   <153>	 7/12/94	HEC		Added kPUReceiveBufferAvail
	   <152>	 7/12/94	JOE		Perfornication Mgr changes
	   <151>	 7/11/94	JBH		Add kSendCommandToChatKeyboard, kTextEditPreflightAppend,
									kTextEditGetLineLength.
	   <150>	 7/11/94	CMY		Added DrawSegaCursor
	   <149>	 7/11/94	CMY		SelectKeyboardField.
	   <148>	 7/10/94	KON		Added get news graphics ID.
	   <147>	 7/10/94	SAH		Added kDBPreflight.
	   <146>	 7/10/94	HEC		SmartCard routine changes.
	   <145>	 7/10/94	ADS		Add growth ranges (please don't touch these)
	   <144>	 7/10/94	HEC		Added kDBSetConstants
	   <143>	 7/10/94	SAH		Added kDrawPaddedClippedSegaText and kRenderSegaText.
	   <142>	  7/9/94	HEC		Added kPIsNumberBusy.
	   <141>	  7/9/94	JBH		Added New / Save / Restore / Dispose text state calls.
	   <140>	  7/8/94	JBH		Added progress mgr.
	   <139>	  7/8/94	CMY		Added StuffCurrentKeyboardField.
	   <138>	  7/8/94	DJ		added GameTalk routines ReadBytes and FlushInput
	   <137>	  7/8/94	HEC		Moved DBGetConstant and DBAddConstant to BoxSex Manager.
	   <136>	  7/7/94	JOE		added Rankings manager
	   <135>	  7/7/94	CMY		Added MinimizeUserHandle.
	   <134>	  7/7/94	CMY		Add SetTextEditLineHeight
	   <133>	  7/7/94	KON		Add net register time out time proc selector.
	   <132>	  7/6/94	SAH		Added math manager.
	   <131>	  7/6/94	KON		Add get and set of network wait times.
	   <130>	  7/6/94	HEC		Added new database routines: DBAddItemPtrSize, DBAddConstant,
									and DBGetConstant.
	   <129>	  7/6/94	ADS		Added password, new dialog calls
	   <128>	  7/6/94	ADS		Added password calls
	   <127>	  7/5/94	SAH		Upped the size of the function table.
	   <126>	  7/5/94	CMY		FinishKeyboard and RefreshKeyboard to support error dialogs
									during keyboard entry.
	   <125>	  7/5/94	SAH		Added ClearOldOpponent and kSaveInterimResults.
	   <124>	 8/28/56	SAH		Killed Get/Seg BasePhonenumber.
	   <123>	  7/5/94	JOE		perfornication mgr update, add NukeRAMDBIcon()
	   <122>	  7/5/94	CMY		SendServerAddressesToVerify for new address book entries.
	   <121>	  7/5/94	BET		Add kPGetError.
	   <120>	  7/5/94	KON		Add kCheckNetRegister.
	   <119>	  7/4/94	KON		Add compare strings.
	   <118>	  7/4/94	ADS		Adding secret keys manager
	   <117>	  7/4/94	ADS		Adding secret keys manager
	   <116>	  7/4/94	BET		kPCheckError was already there.
	   <115>	  7/4/94	BET		Add kPUSetError and kPCheckError
	   <114>	  7/4/94	DJ		kTUGetError
	   <113>	  7/4/94	SAH		kGetNextCommand
	   <112>	  7/3/94	BET		Add kTUSetError.
	   <111>	  7/3/94	JBH		Added kGetBackdropID, kSetBackgroundColor, kGetBackgroundColor,
									and kDeallocateTopBuffer, in order to allow dialogs to trash
									backdrop patterns temporarily.
	   <110>	  7/3/94	SAH		Added kSpawnDBAnimation.
	   <109>	  7/3/94	KON		Add selector for marking mail as read.
	   <108>	  7/3/94	SAH		Added kDBTypeChanged.
	   <107>	  7/2/94	KON		Add sort manager.
	   <106>	  7/2/94	CMY		Added activate/deactivate of TextEdit fields.
	   <105>	  7/2/94	SAH		Added some box id globals.
	   <104>	  7/2/94	JBH		Added kSetSpriteTilePosition.
	   <103>	  7/2/94	DJ		removed set/get gameresultflags
	   <102>	  7/2/94	SAH		Added kSetDBUnstable.
	   <101>	  7/2/94	JOE		add kDrawIcon, kDisposeIconReference
	   <100>	  7/1/94	SAH		I fuckin' win. Now, who's gonna be 1000?
		<99>	  7/1/94	HEC		Oh, I'm sooo close!  Added kSetBoxMaster, SmartCard manager,
									preliminary calls and associated goo.
		<98>	 6/30/94	SAH		Who's gonna be lucky 100? Added kDBGet/SetTypeFlags.
		<97>	 6/30/94	CMY		Added screen-driven keyboard calls.
		<96>	 6/30/94	SAH		Added PurgePermHeaps. Killed some unused mail out box calls.
		<95>	 6/30/94	KON		Add killcurnewspage.
		<94>	 6/29/94	CMY		Grayscale sprite drawing and keyboard entry manager
		<93>	 6/29/94	KON		Update news.
		<92>	 6/28/94	CMY		Palette manager and sprite calls.
		<91>	 6/28/94	SAH		Killed Results Manager. Killed LowLevel globals. Updated
									UsrConfig and Opponents api.
		<90>	 6/28/94	BET		Add kTCheckErrorSess
		<89>	 6/27/94	KON		Added get and set gameID SRAM functions.
		<88>	 6/27/94	KON		Add validate and invalidate news.
		<87>	 6/21/94	HEC		Added kFadeInScreen to SegaScrn
		<86>	 6/21/94	KON		Add SetDialogTimeOut Delay.
		<85>	 6/21/94	BET		Add GameTalk Manager
		<84>	 6/21/94	CMY		Added ExplodeSprite.
		<83>	 6/20/94	SGR		added kSetLEDScreenAnimation
		<82>	 6/20/94	BET		Add kSetupServerTalk and kTearDownServerTalk.
		<81>	 6/20/94	KON		Added IsBoxMaster for CES.
		<80>	 6/20/94	KON		Added DeferredDialogManager and bumped number of selectors up to
									500.
		<79>	 6/20/94	CMY		Animation priorities, animated dialogs, decompressor options...
		<78>	 6/19/94	KON		Remove clear opponents.
		<77>	 6/19/94	BET		Add API for sticky errors on net interfaces
		<76>	 6/19/94	BET		Add API for sticky errors on net interfaces
		<75>	 6/18/94	CMY		SuspendAnimations and ResumeAnimations.
		<74>	 6/18/94	CMY		Add ClearOpponent for Kon.
		<73>	 6/18/94	HEC		Added DBGetUniqueIDInRange
		<72>	 6/18/94	KON		Add NewAddressManager.
		<71>	 6/18/94	KON		Change kResetScreen to kResetCurrentScreen to prevent name
									conflict.
		<70>	 6/18/94	KON		Add new NGP calls.
		<69>	 6/18/94	BET		Add Async open and listen for phys
		<68>	 6/17/94	KON		Add SetNetTimeoutValue.
		<67>	 6/17/94	KON		Added EqualCString.
		<66>	 6/17/94	SAH		Added some more patch db calls.
		<65>	 6/17/94	CMY		Added SetTextPatternAddress.
		<64>	 6/17/94	KON		Add support for NetRegister Manager.
		<63>	 6/17/94	SAH		Added some game patch cheese.
		<62>	 6/16/94	KON		Add selectors for game results to BoxSerial manager.
		<61>	 6/16/94	CMY		Added an event queue for controller reads. Removed
									AllowUserEvent.
		<60>	 6/15/94	KON		Add low-level delete entry to the address book.
		<59>	 6/15/94	CMY		Add paramText for dialogs
		<58>	 6/15/94	BET		Add kTUCheckTimers selector
		<57>	 6/15/94	SGR		Add LED stuff.
		<56>	 6/15/94	KON		More address book shit.
		<55>	 6/15/94	SAH		Added the rosko manager.
		<54>	 6/15/94	KON		Added misc. stuff to support address book.
		<53>	 6/14/94	KON		Added String length, clear opponents, and AddToAddressBook
									stuff.
		<52>	 6/14/94	CMY		Remove the distinction between Inform and Confirm dialogs.
		<51>	 6/14/94	KON		Add last box state calls.
		<50>	 6/14/94	DJ		added 	kTCheckError,
		<49>	 6/14/94	CMY		Added DialogMgr.
		<48>	 6/14/94	KON		Added boxState calls.
		<47>	 6/14/94	BET		Add some more net API
		<46>	 6/14/94	SAH		More managers. Made the function table bigger.
		<45>	 6/14/94	KON		Add new call: AddAddressBookEntry.
		<44>	 6/13/94	SAH		Added a bunch more managers.
		<43>	 6/13/94	KON		Add BoxSerial Manager.
		<42>	 6/13/94	CMY		Added EraseTextGDevice
		<41>	 6/13/94	BET		Add net API
		<40>	 6/13/94	CMY		Added Sprite layers.
		<39>	 6/13/94	SAH		Added StringDB and DitlItemSetup functions.
		<38>	 6/13/94	CMY		Added TextSprites.
		<37>	 6/12/94	SAH		Added backdrop mgr.
		<36>	 6/11/94	SAH		Added kWaitVBlank.
		<35>	 6/11/94	SAH		Added kCheckDBUnstable.
		<34>	 6/11/94	KON		Added phone number manager.
		<33>	 6/10/94	KON		Add DITLReset and screen preflight and restart.
		<32>	 6/10/94	SAH		Added the VerifySegaHeap call. Moved the endgame selectors to
									the beginning so they don't change when new stuff is added and
									hose the game patches.
		<31>	 6/10/94	BET		Add a couple more
		<30>	  6/9/94	HEC		Added DBVerifyDatabase function
		<29>	  6/9/94	BET		Add a couple of funks
		<28>	  6/9/94	KON		Added ModemMisc and Screens managers.
		<27>	  6/5/94	CMY		Add clut fading calls.
		<26>	  6/5/94	SAH		Extended manager.
		<25>	  6/5/94	HEC		Added EndGame Manager.
		<24>	  6/4/94	SAH		Added cart manager.
		<23>	  6/4/94	KON		Add Challenge manager.
		<22>	  6/4/94	SAH		Added GetData Mgr.
		<21>	  6/2/94	KON		Added SegaAppendText.
		<20>	  6/1/94	BET		Add new physical layer calls
		<19>	 5/31/94	SAH		Brought SegaMisc stuff into SegaScrn and SegaText.
		<18>	 5/31/94	HEC		Revised patch manager selectors, etc.
		<17>	 5/30/94	SAH		Added sound manager.
		<16>	 5/30/94	SAH		Add Events Mgr and SetOSIdle and SegaOSIdle.
		<15>	 5/30/94	SAH		Added kInitPermDatabase.
		<14>	 5/28/94	SAH		Always add the DBRomSwitch selector.
		<13>	 5/28/94	KON		Add DITLMgr.
		<12>	 5/26/94	BET		Update for managerized Disk Transport.
		<11>	 5/26/94	BET		Get ready for DiskTransport Manager
		<10>	 5/26/94	SAH		Added User Config and Opponent Managers.
		 <9>	 5/26/94	BET		Add a teeny ted forgot that mwerks hates
		 <8>	 5/26/94	BET		Add transport changes
		 <7>	 5/26/94	HEC		Added kDBROMSwitch selector
		 <6>	 5/26/94	SAH		Added vdp manager.
		 <5>	 5/26/94	SAH		Added the screen manager.
		 <4>	 5/25/94	DJ		fix case sensitive: Database not DataBase
		 <3>	 5/25/94	DJ		Integrated into new Sega project....  integration of Kon's stuff
									and Shannon's (physical and transport layers).
		<17>	 5/25/94	KON		Added Playback manager.
		<16>	 5/25/94	KON		Database, not DataBase.
		<15>	 5/25/94	KON		Added Capture manager.
		<14>	 5/25/94	HEC		Added database manager selectors
		<13>	 5/25/94	HEC		Added WhichMemory to heaps and Database Manager.
		<12>	 5/24/94	SAH		Added the text manager.
		<11>	 5/21/94	SAH		Added kInitAnimateProcs and kDrawAnimationFrame.
		<10>	 5/20/94	HEC		Adding kDelayMS and kDelayTicks.
		 <9>	 5/19/94	SAH		Added kDisposeImagePatterns.
		 <8>	 5/18/94	HEC		Changed pattern manager func names
		 <7>	 5/18/94	SAH		Added kLoadCursorFromVRAM and kCreateCursorData.
		 <6>	 5/17/94	HEC		Rename kInitPattern to kInitPatternManager
		 <5>	 5/17/94	SAH		Added the cursor manager.
		 <4>	 5/17/94	HEC		Adding pattern manager!
		 <3>	 5/16/94	SAH		Added path manager.
		 <2>	 5/12/94	SAH		Added animation manager, sprite manager and time manager.

	To Do:
*/


#ifndef __OSManagers__
#define __OSManagers__


/*
* this file defines all the managers, their main entry point and their dispatched routine id's
*/


#define	kNumSelectors 		(950 + 50)					// this many total selectors
#define	kNumManagers 		64							// this many managers



/* manager id's */
enum
{
	kDispatcherManager,
	kMemoryManager,
	kReliableManager,
	kControlManager,
	kGlobalManager,
	kPatchDBManager,
	kMessageManager,
	kSpriteManager,
	kDecompressManager,
	kTimeManager,
	kAnimationManager,
	kPathManager,
	kPatternManager,
	kCursorManager,
	kTextManager,
	kDatabaseManager,
	kPhysicalLayerManager,
	kTransportLayerManager,
	kScreenManager,
	kVDPManager,
	kOpponentManager,
	kUsrConfgManager,
	kDITLManager,
	kEventsManager,
	kSoundManager,
	kGetDataManager,
	kChallengeManager,
	kCartManager,
	kEndGameManager,
	kModemMiscManager,
	kScreensManager,
	kBackdropManager,
	kBoxSerialManager,
	kPlayerDBManager,
	kMiscDBItemsManager,
	kTextUtilsManager,
	kNewsManager,
	kGameDBManager,
	kPerfornicationManager,
	kMailManager,
	kSendQManager,
	kDialogManager,
	kRoskoManager,
	kNetRegisterManager,
	kNewAddressManager,
	kDefDialogManager,
	kGameTalkManager,
	kKeyboardEntryManager,
	kSmartCardManager,
	kSortManager,
	kSecretManager,
	kMathManager,
	kRankingManager,
	kProgressManager,
	kRadioButtonManager,
	kNetMiscManager,
	kPeerConnectManager,
	kFifoManager,
	kVBLManager,
		
	/* keep this one as last */
	kLastManager
};

#if kLastManager >= kNumManagers
fuck you think c
#error "Too many managers, bump size of manager table"
#endif 


/* routine id's */
enum
{
	/* End Game manager -- these are at the beginning so they never change! */
	kRestoreSegaOS,
	kAskForReplay,
	kThankYouScreen,

	/* dispatcher */
	kInstallDispatchedManager,
	kCallManagerControl,
	kSoftInitOS,
	kGetDispatchedFunction,
	kSetDispatchedFunction,
	kSetDispatchedGroup,
	kGetManagerGlobals,
	kSetManagerGlobals,
	kAllocateGlobalSpace,
	kFreeGlobalSpace,
	kDisposePatch,
	kCompactOSCodeHeap,
	kGetPatchVersion,
	kSetPatchVersion,
	
	/* Memory manager */
	kInitHeap,
	kNewMemory,
	kNewMemoryHigh,
	kNewMemoryClear,
	kDisposeMemory,
	kGetMemorySize,
	kMaxFreeMemory,
	kTotalFreeMemory,
	kSwitchPermHeap,
	kSwtichTempHeap,
	kCreateTempHeap,
	kCreateHeapFromPtr,
	kCreateTempSubHeap,
	kAllocPermHeapZone,
	kDisposePermHeapZone,
	kCompactHeap,
	kMoveHeap,
	kPrepareHeapForMove,
	kComputeHeapPtrDelta,
	kResizeHeap,
	kBlockMove,
	kWhichMemory,
	kGetHeapSize,
	kVerifySegaHeap,
	kPurgePermHeaps,
	kByteCopy,
	kUnpackBytes,
	
	kFillMemory,
	kGetCurrentHeap,
	kFindLastAllocatedBlock,
	
	/* reliability manager */
	kSetOSUnstable,
	kSetDBUnstable,
	kSetAddressUnstable,
	kInstallReliableAddress,
	kCheckOSReliable,
	
	/* controller manager */
	kInitControllers,
	kReadHardwareController,
	kControllerVBL,
	kReadAllControllers,
	kFlushHardwareKeyboardBuffer,
	kGetNextHardwareKeyboardChar,
	kGetHardwareKeyboardFlags,
	kSetHardwareKeyboardFlags,
	kGetNextESKeyboardRawcode,
	kGetNextESKeyboardStatus,
	kGetNextESKeyboardChar,
	kSendCmdToESKeyboard,
	
	/* globals manager */
	kGetGlobal,
	kSetGlobal,
	
	/* game patch manager */
	kAddGamePatch,
	kLoadGamePatch,
	kDisposeGamePatch,
	kGetGamePatchVersion,
	kGetGamePatchFlags,
	kFindGamePatch,
	kCreateGameDispatcher,
	kInitGamePatch,
	kStartGame,
	kGameOver,
	kResumeGame,
	kGameDoDialog,
	kUpdateGameResultsAfterError,
	kHandleGameError,
	kPlayCurrentGame,
	kInstallGameFunction,
	kDisposeOldestGamePatch,
	kMarkGamePatchUsed,
	
	/* message manager */
	kInitMessages,
	kProcessServerData,
	kProcessPeerData,
	kSendMessage,
	kGetSendMessageHandler,
	kGetPeerMessageHandler,
	kGetSerialOpCode,
	kGetServerMessageHandler,
	kInstallPeerHandler,
	kInstallReceiveServerHandler,
	kInstallSendMessageHandler,
	kReceivePeerMessageDispatch,
	kReceiveServerMessageDispatch,
	kGobbleMessage,
	kSetClearLoginMisc,
	kGetLoginMisc,
	
	/* sprite manager */
	kCreateSprite,
	kCreateSpriteInFront,
	kCreateSpriteHigh,
	kDisposeSprite,
	kMoveSprite,
	kDrawSprite,
	kIncrementSpriteFrame,
	kSetSpriteFrame,
	kGetSpriteFrame,
	kFlipSprite,
	kCreateSpriteData,
	kCreateTextSprite,
	kCreateTextSpriteFromBitmap,
	kExplodeSprite,
	kSetSpriteGrayFlag,
	kSetSpriteTilePosition,
	kSetSpriteImage,
	kSetSpritePalette,
	
	kWriteSpriteToVDP,
	kFigureTileSize,
	kAllocateSprite,
	kFreeSprite,
	kGetSpriteLastTile,
	kGetSpriteFirstTile,
	
	kNewSpark,
	kDisposeSpark,
	kGetSparkSprite,
	kStartSpark,
	kStopSpark,

	kDrawXBandLogo,
	kDisposeXBandLogoRef,
	kDisposeXBandLogoSparks,
	kSyncOTron,

	/* decompression manager */
	kInitDecompression,
	kCreateDecompressor,
	kDisposeDecompressor,
	kSetDstPattern,
	kSetImageTiling,
	kSetImageOrigin,
	kGetImageClut,
	kDisposeImagePatterns,
	kDecompressFrame,
	kSetDecompressorOptionsSelector,
	kSetDecompressorPixelMappingSelector,
	kSetDecompressorPaletteSelector,
	kGetDictionaryCache,
	kReleaseDictionaryCache,
	kSetDecompressorImage,
	kExpandPatternDictionary,
	kGetDecompressorCache,
	kReleaseDecompressorCache,
	kJoshDecompress,
	
	/* time manager */
	kAddTimeRequest,
	kRemoveTimeRequest,
	kTimeIdle,
	kIncCurrentTime,
	kDelayMS,
	kDelayTicks,
	kSetOSIdle,
	kSegaOSIdle,
	kGetJesusTime,
	kSetJesusTime,
	kGetJesusDate,
	kSetJesusDate,
	
	/* animation manager */
	kInitAnimateProcs,
	kSpawnAnimation,
	kSpawnDBAnimation,
	kCreateAnimation,
	kDisposeAnimation,
	kDrawAnimationFrame,
	kStartAnimation,
	kStopAnimation,
	kSuspendAnimations,
	kSetAnimationPriority,
	kSetAnimationGrayFlag,
	kGetAnimationSuspendLevel,
	
	/* path manager */
	kInitPathManager,
	kCreatePath,
	kDisposePath,
	kSetPathPoints,
	kSetPathFrames,
	kSetPathVelocity,
	kGetPathPoint,
	kDistBetweenPoints,
	
	/* pattern manager */
	kInitPatternManager,
	kNewPatternBlock,
	kNewPatternBlockHigh,
	kFreePatternBlock,
	kDeallocateTopPatternBlock,
	kNewFirstPatternBlock,
	kSetRange,
	kClearRange,
	kRangeIsFree,
	kFindFreeRange,
	kGetLeftOnesTable,
	kGetRightOnesTable,

	/* cursor manager */
	kCreateSegaCursor,
	kDisposeSegaCursor,
	kMoveSegaCursor,
	kHideSegaCursor,
	kShowSegaCursor,
	kGetSegaCursorPos,
	kSetSegaCursorImage,
	kLoadCursorFromVRAM,
	kDrawSegaCursor,
	kLoadCursorPattern,
	
	/* text manager */
	kInitSegaFonts,
	kSetCurFont,
	kGetCurFont,
	kGetCurFontHeight,
	kGetCurFontLineHeight,
	kSetFontColors,
	kGetFontColors,
	kSetupTextGDevice,
	kGetTextPatternAddress,
	kGetTextGDeviceOrigin,
	kDrawSegaString,
	kRenderSegaString,
	kMeasureSegaText,
	kCenterSegaText,
	kDrawClippedSegaText,
	kDrawCenteredClippedSegaText,
	kDrawPaddedClippedSegaText,
	kGetCharWidth,
	kSegaNumToString,
	kSegaNumToDate,
	kSegaAppendText,
	kCompareDates,
	kCompareStrings,
	kSetupTextSpriteGDevice,
	kEraseTextGDevice,
	kGetStringLength,
	kDrawDBXYString,
	kGetDBXYString,
	kGetSegaString,
	kGetWriteableString,
	kSetWriteableString,
	kDeleteWriteableString,
	kGetUniqueWriteableStringID,
	kCopyCString,
	kSetTextPatternStart,
	kEqualCStrings,
	kGetTextStateReference,
	kSaveTextState,
	kRestoreTextState,
	kDisposeTextStateReference,

	kVDPCopyBlitDirect,
	kVDPCopyBlitDirectBGColor,
	kVDPCopyBlitTiled,
	kVDPCopyBlitTiledBGColor,
	kOrBlit2to4,
	kOrBlit1to4,

	/* ServerTalk physical layer */
	kPInit,
	kPOpen,
	kPListen,
	kPOpenAsync,
	kPListenAsync,
	kPClose,
	kPNetIdle,
	kPCheckError,
	kPWritePacketSync,
	kPWritePacketASync,
	kPGetError,
	kPUOpenPort,
	kPUClosePort,
	kPUProcessIdle,
	kPUProcessSTIdle,
	kPUReadSerialByte,
	kPUWriteSerialByte,
	kPUTransmitBufferFree,
	kPUReceiveBufferAvail,
	kPUTestForConnection,
	kPUReadTimeCallback,
	kPUWriteTimeCallback,
	kPUSetupServerTalk,
	kPUTearDownServerTalk,
	kPUSetError,
	kPUIsNumberBusy,
	kPUOriginateAsync,
	kPUAnstondet,
	kPUWaitForRLSD,
	kPUInitCallProgress,
	kPUCallProgress,
	kPUDialNumber,
	kPUWaitDialTone,
	kPUAnswerAsync,
	kPUCheckAnswer,
	kPUCheckRing,
	kPUResetModem,
	kPUSetTimerTicks,
	kPUSetTimerSecs,
	kPUTimerExpired,
	kPUHangUp,
	kPUPickUp,
	kPUWriteXRAM,
	kPUWriteYRAM,
	kPUReadXRAM,
	kPUReadYRAM,
	kPUIdleMode,
	kPUDataMode,
	kPUDialMode,
	kPUToneMode,
	kPUCheckLine,
	kPUCheckCarrier,
	kPUDetectLineNoise,
	kPUListenToLine,
	kPUDisableCallWaiting,
	kPUAsyncReadDispatch,
	kPUDoSelectorLogin,
	kPUMatchString,
	kPGetDebugChatScript,

	/* ServerTalk transport layer */
	kTInit,
	kTOpen,
	kTListen,
	kTOpenAsync,
	kTListenAsync,
	kTClose,
	kTCloseAsync,
	kTUnthread,
	kTNetIdle,
	kTUCheckTimers,
	kTReadDataSync,
	kTReadDataASync,
	kTWriteDataSync,
	kTWriteDataASync,
	kTAsyncWriteFifoData,
	kTReadData,
	kTWriteData,
	kTReadAByte,
	kTWriteAByte,
	kTQueueAByte,
	kTReadBytesReady,
	kTDataReady,
	kTDataReadySess,
	kTIndication,
	kTForwardReset,
	kTNetError,
	kTCheckError,
	kTUInitSessRec,
	kTUSendCtl,
	kTUDoSendCtl,
	kTUDoSendOpenCtl,
	kTUUpdateSessionInfo,
	kTUSendOpen,
	kTUSendOpenAck,
	kTUSendCloseAdv,
	kTUSendFwdReset,
	kTUSendFwdResetAck,
	kTUSendFwdResetPacket,
	kTUSendRetransAdv,
	kTUOpenDialogPacket,
	kTUFwdResetPacket,
	kTUCloseConnPacket,
	kTURetransAdvPacket,
	kTUAllowConnection,
	kTUDenyConnection,
	kTUSetError,
	kTUGetError,
	kTGetUserRef,
	kTSetUserRef,
	kTGetTransportHold,
	kTGetTransportHoldSession,
	kTSetTransportHold,
	kTSetTransportHoldSession,

	/* database manager */
	kInitPermDatabase,
	kCompactPermDatabase,
	kDBGetItem,
	kDBAddItem,
	kDBDeleteItem,
	kDBGetUniqueID,
	kDBGetUniqueIDInRange,
	kDBGetItemSize,
	kDBCountItems,
	kDBGetFirstItemID,
	kDBGetNextItemID,
	kDBNewItemType,
	kDBGetTypeFlags,
	kDBSetTypeFlags,
	kDBDeleteItemType,
	kDBPurge,
	kDBTypeChanged,
	kComputeTypeCheckSum,
	kDBVerifyDatabase,
	kDBROMSwitch,
	kDBAddItemPtrSize,
	kDBAddItemHighPtrSize,
	kDBPreflight,

	kGetItemSize,
	kDBGetTypeNode,
	kDBGetPrevTypeNode,
	kDBTNGetItem,
	kDBTNGetPrevItem,
	kDBTNDisposeList,
	kDeleteItem,
	kAddItemToDB,
	kAllowDBItemPurge,

	/* screen manager */
	kLinearizeScreenArea,
	kGetSegaScreenBaseAddr,
	kInitSegaGDevices,
	kSetCurrentDevice,
	kGetCurrentDevice,
	kRequestClut,
	kReleaseClut,
	kIncrementClutReferences,
	kSetupClutDB,
	kGetSegaScreenOrigin,
	kGetSegaGDevice,
	kEraseGDevice,
	kSetupVDP,
	kBlankClut,
	kFadeInClut,
	kFadeInScreen,
	kGenerateGrayMap,
	kWaitVBlank,
	kSetBackgroundColor,
	kGetBackgroundColor,
	kRequestUniqueClut,
	kRequestSpecificClut,
	kSetupClut,
	kGetClut,
	kGetColorLuminance,
	kFillNameTable,
	
	/* vdp manager */
	kDMAToVRAM,
	kCopyToVRAM,
	kCopyToCRAM,
	kCopyToVSRAM,
	kCopyToVMap,
	kFillVRAM,
	kFillCRAM,
	kFillVSRAM,
	
	/* opponent manager */
	kGetOpponentPhoneNumber,
	kSetOpponentPhoneNumber,
	kGetCurOpponentIdentification,
	kSetCurOpponentIdentification,
	kGetCurOpponentTaunt,
	kGetCurOpponentInfo,
	kClearOldOpponent,
	kGetOpponentVerificationTag,
	kSetOpponentVerificationTag,
	
	/* user configuration manager */
	kGetCurrentLocalUser,
	kFillInUserIdentification,
	kGetLocalUserTaunt,
	kSetLocalUserTaunt,
	kGetLocalUserInfo,
	kSetLocalUserInfo,
	kIsUserValidated,
	kSetCurUserID,
	kGetCurUserID,
	kVerifyPlayerPassword,
	kIsEmptyPassword,
	kComparePassword,
	kGetPlayerPassword,
	
	/* DITL manager */
	kNewDITL,
	kGiveDITLTime,
	kDisposeDITL,
	kGetDITLItem,
	kInitDITLMgr,
	kClearDITLDone,
	kProcessDITLScreen,
	kSetupDITLItemList,
	kSetupDITLObjectData,
	kDisposeDITLItemList,
	kSetupControlTable,
	kDisposeControlTable,
	kGetDITLObjectData,
	
	/* events manager */
	kInitUserEvents,
	kFlushUserEvents,
	kWaitForUserButtonPress,
	kCheckUserButtonPress,
	kGetNextControllerEvent,
	kGetNextCommand,
	kQueueGet,
	kQueueInsert,
	
	/* sound manager */
	kSetBGMDisable,
	kGetBGMDisable,
	kInitSoundMgr,
	kShutDownSoundMgr,
	kStartDBBGM,
	kStopBGM,
	kPlayDBFX,
	kFX1NoteOff,
	kFX2NoteOff,
	kShutUpFXVoice1,
	kShutUpFXVoice2,
	
	/* GetData manager */
	kGetDataSync,
	kGetDataBytesReady,
	kGetDataError,

	/* Challenge manager */
	kGetChallengePhoneNumber,
	kSetChallengePhoneNumber,
	kGetChallengeIdentification,
	kSetChallengeIdentification,
	
	/* cartridge manager */
	kGetGameID,

	/* Modem Misc manager */
	kIsRemoteModemTryingToConnect,
	kSetRemoteModemTryingToConnectState,
	
	/* Screens Manager */
	kInitScreen,
	kPreflightScreen,
	kSetupScreen,
	kSendCommandToScreen,
	kKillScreen,
	kGetNewScreenIdentifier,
	kGetCurScreenIdentifier,
	kGetScreenStateTable,
	kResetCurrentScreen,
	kGetScreenLayoutRectangleCount,
	kGetScreenLayoutRect,
	kGetScreenLayoutCharRect,
	kGetScreenLayoutPointCount,
	kGetScreenLayoutPoint,
	kGetScreenLayoutStringCount,
	kGetScreenLayoutString,
	kDrawScreenLayoutString,
	kBoxScreenLayoutString,
	kGetScreensEnteredCount,
		
	/* backdrop manager */
	kSetBackdropID,
	kSetBackdropBitmap,
	kClearBackdrop,
	kHideBackdrop,
	kSetAuxBackgroundGraphic,
	kShowBackdrop,
	kGetBlinkySprite,
	
	/* box serial number manager */
	kGetBoxSerialNumber,
	kSetBoxSerialNumber,
	kGetHiddenBoxSerialNumbers,
	kGetBoxHometown,
	kSetBoxHometown,
	kSetBoxState,
	kResetBoxState,
	kGetBoxState,
	kSetLastBoxState,
	kResetLastBoxState,
	kGetLastBoxState,
	kGetGameWinsLosses,
	kSetCompetitionResults,
	kGetCompetitionResults,
	kSetGameErrorResults,
	kGetGameErrorResults,
	kUpdateGameResults,
	kClearGameResults,
	kClearNetErrors,
	kGetLocalGameValue,
	kSetLocalGameValue,
	kGetOppGameValue,
	kSetOppGameValue,
	kIsBoxMaster,
	kSetBoxMaster,
	kSetCurGameID,
	kGetCurGameID,
	kCheckBoxIDGlobals,
	kInitBoxIDGlobals,
	kChangedBoxIDGlobals,
	kDBAddConstant,
	kDBGetConstant,
	kDBSetConstants,
	kSetDialNetworkAgainFlag,
	kCheckDialNetworkAgainFlag,
	kSetBoxXBandCard,
	kGetBoxXBandCard,
	kGetBoxLastCard,
	kSetBoxMagicToken,
	kSetBoxProblemToken,
	kGetBoxProblemToken,
	kUseBoxProblemToken,
	kSetBoxValidationToken,
	kGetBoxValidationToken,
	kSetIMovedOption,
	kSetQwertyKeyboardOption,
	kSetCallWaitingOption,
	kSetAcceptChallengesOption,
	kGetAcceptChallengesOption,
	kGetIMovedOption,
	kGetQwertyKeyboardOption,
	kGetCallWaitingOption,
	kGetNetErrors,
	kGetBoxPhoneNumber,
	kSetBoxPhoneNumber,
	kGetLocalAccessPhoneNumber,
	kSetLocalAccessPhoneNumber,
	kGet800PhoneNumber,
	kGetLocalUserName,
	kSetLocalUserName,
	kGetLocalUserROMIconID,
	kSetLocalUserROMIconID,
	kGetLocalUserCustomROMClutID,
	kSetLocalUserCustomROMClutID,
	kGetLocalUserPassword,
	kSetLocalUserPassword,
	kValidateUserPersonification,
	kInvalidateUserPersonification,
	
	/* address book manager */
	kGetAddressBookTypeForCurrentUser,
	kGetAddressBookIDFromIndex,
	kCountAddressBookEntries,
	kRemoveAddressBookEntry,
	kGetIndexAddressBookEntry,
	kAddAddressBookEntry,
	kGetUserAddressBookIndex,
	kDeleteAddressBookEntry,
	kSendNewAddressesToServer,
	kMarkAddressBookUnchanged,
	kAddressBookHasChanged,
	kCorrelateAddressBookEntry,
	
	/* new address manager */
	kAddPlayerToAddressBook,
	kUpdateAddressBookStuff,
	kAddOnDeckAddressBookEntry,
	kMinimizeUserHandle,
	
	/* misc db items manager */
	kGetDBGraphics,
	kDrawDBGraphic,
	kDrawDBGraphicAt,
	kDrawGraphic,
	kDisposeGraphicReference,
	kGetGraphicReferenceClut,
	kDrawPlayerIcon,
	kNukePlayerRAMIcon,
	kGetPlayerRAMIconBitMap,
	kGetPlayerIconBitMap,
	kGetIconBitMap,
	kPlayerRAMIconExists,
	kDisposeIconReference,
	kGetDBButtonFrame,
	kDrawGraphicGray,
	kHueShift,
	
	/* text utils manager */
	kFindLineBreak,
	kSegaBoxText,
	kDrawSegaStringLength,
	kMeasureSegaTextLength,
	kInitTextEdit,
	kSetTextEditLineHeight,
	kTextEditAppend,
	kTextEditDelete,
	kDisposeTextEdit,
	kTextEditActivate,
	kTextEditDeactivate,
	kTextEditPreflightAppend,
	kTextEditGetLineLength,
	kDrawTextBox,
	kSetJizzleBehavior,
	kGetJizzleBehavior,
	kStartTextBoxAnimation,
	kStopTextBoxAnimation,
	kDisposeTextBoxReference,
	
	kDrawSegaTextPlusSpaces,
	kUpdateTECaret,
	kEraseTextEditLine,
	kGetCompressedJizzlers,
	
	/* news manager */
	kFindNextNewsString,
	kAddPageToNewsBox,
	kGetPageFromNewsBox,
	kGetNewsForm,
	kGetNumNewsPages,
	kEmptyNewsBox,
	kDrawNewsPage,
	kValidateNews,
	kInvalidateNews,
	kSetupNewsForServerConnect,
	kServerConnectNewsDone,
	kDoNewsControlIdle,
	kKillCurNewsPage,
	kGetNewsGraphicsID,
	kShowLeftRightPageControls,
	kDrawNewsReturnIcon,
	kSetNewsCountdownTimeConst,
	kDrawXBandNews,
	kDisposeXBandNews,
	
	/* game db manager */
	kGetNGPListGamePatchInfo,
	kGetNGPListGamePatchVersion,
	kGetNGPVersion,
	kUpdateNGPList,
	kUpdateNameList,
	kGetGameName,
	
	/* Perfornication manager */
	kChangeUserPersonificationPart,	
	kInstallOpponentPersonification,
	kGetPersonificationPart,

	kPutPersonificationOnWire,
	kGetPersonificationFromWire,
	kDisposePersonificationSetup,
	
	kReceivePersonficationBundle,
	kParsePersonificationBundle,
	kCreatePersonificationBundle,

	/* mail manager */
	kCountInBoxEntries,
	kCountOutBoxEntries,
	kAddMailToOutBox,
	kAddMailToInBox,
	kRemoveMailFromInBox,
	kGetIndexInBoxMail,
	kGetIndexOutBoxMail,
	kGetInBoxGraphicID,
	kMarkMailItemRead,
	kDeleteAllOutBoxMail,
	kGetInBoxTypeForCurrentUser,
	kGetOutBoxTypeForCurrentUser,
	kGetOutBoxIDFromIndex,
	kGetInBoxIDFromIndex,
	kGetBoxIDFromIndex,
	
	/* SendQ Manager */
	kAddItemToSendQ,
	kAddItemSizeToSendQ,
	kDeleteSendQ,
	kKillSendQItem,
	kGetFirstSendQElementID,
	kGetNextSendQElementID,
	kCountSendQElements,
	kGetSendQElement,
	kRemoveItemFromSendQ,
	
	/* Dialog Manager */
	kSetDialogColors,
	kDoDialog,
	kDialogParameterText,
	kDoDialogItem,
	kDoDialogParam,
	kDoPlayAgainDialog,
	
	kCopyString,
	kDoAnyResponse,
	kDoDataDrivenDismissal,
	kDoPassword,
	kDrawDialogFrame,
	kFillTextRectangle,
	kHorizontalLine,
	kKillProgressTimer,
	kReplaceParameters,
	kSetupProgressTimer,
	kVerticalLine,
	kCreateShiners,
	kDisposeShiners,
	
	/* rosko manager */
	kSetVector,
	kSetVectorTblAddr,
	kSetSafeRamSrc,
	kSetSafeRomSrc,
	kSetLEDs,
	kSetLEDScreenAnimation,
	kInitJoggler,
	kDisplayJoggler,
	kStopJoggler,
	
	/* Def Dialog Manager */
	kQDefDialog,
	kShowDefDialogs,
	kCountDefDialogs,
	kDisableDefDialogs,
	kEnableDefDialogs,

	/* Net Register Manager */
	kCheckNetRegister,
	kNetRegister,
	kNetRegisterDone,
	kSetNetTimeoutValue,
	kGetNetTimeoutValue,
	kGetNetWaitSoFar,
	kNetRegisterTimeOutTimeProc,
	kIsBoxNetRegistered,
	kGetNetRegisterCase,
	
	/* GameTalk Manager */
	kGTSInit,
	kGTSShutdown,
	kGTSFlushInput,
	kGTSessionPrefillFifo,
	kGTSessionEstablishSynch,
	kGTSessionExchangeCommands,
	kGTSessionValidateControl,
	kGTSErrorRecover,
	kGTSCloseSessionSynch,
	kGTSDoCommand,
	kGTSDoResend,
	kGTSResendFromFrame,
	kGTSSetPacketFormat,
	kGTSSetRamRomOffset,
	kGTSessionSetLatency,
	kGTSessionSendController8,
	kGTSessionReadController8,
	kGTSessionSendController12,
	kGTSessionReadController12,
	kGTSessionSendController16,
	kGTSessionReadController16,
	kGTSessionSendController18,
	kGTSessionReadController18,
	kGTSessionSendController24,
	kGTSessionReadController24,
	kGTSessionSendController27,
	kGTSessionReadController27,
	kGTModemInit,
	kGTModemGetModemError,
	kGTModemClearFifo,
	kGTModemClockInByte,
	kGTModemClockOutByte,
	kGTModemAbleToSend,
	kGTModemSendBytes,
	kGTModemCheckLine,
	kGTModemReadModem,
	kGTSendReceiveBytes,
	kGTCloseSessionSafe,
	kGTCreateLooseSession,
	kGTLooseSessionIdle,
	kGTCloseLooseSession,
	
	/* stinkotron */
	kGTSyncotron,
	kGTMasterCalculateLatency,
	kGTSlaveCalculateLatency,
	kGTSyncoReadModemVBL,
	kGTSyncronizeVBLs,
	kGTSyncronizeMasterLeave,
	kGTSyncronizeSlaveLeave,
	kGTSyncoTronVBLHandler,
	kGTUnused1,
	kGTUnused2,
	kGTUnused3,
	kGTUnused4,
	kGTUnused5,
	kGTUnused6,
	
	
	
	/* Keyboard Entry Manager */
	kSetupKeyboardEntryLayout,
	kDisposeKeyboardEntryLayout,
	kDoKeyboardEntry,
	kInitKeyboardEntry,
	kSendCommandToKeyboard,
	kFinishKeyboardEntry,
	kRefreshKeyboard,
	kStuffCurrentKeyboardField,
	kSelectKeyboardField,
	kSendCommandToChatKeyboard,
	kGetKeyLayoutFieldCount,
	kGetKeyLayoutFieldSize,
	kSetKeyboardEntryMeasureProc,
	
	kSetFocusField,
	kDrawKeyboard,
	kComputeCursorLineNumber,
	kCacheKeyboardGraphics,
	kReleaseKeyboardGraphicsCache,
	
	/* SmartCard Manager */
	kGetCardType,
	kCardInstalled,
	kReadCardBytes,
	kWriteCardBit,
	kGotoCardAddress,
	kIncrementCardAddress,
	kReadCardBit,
	kResetCard,
	kPresentSecretCode,
	kGetRemainingCredits,
	kFindFirstOne,
	kCountCardBits,
	kDebitCardForConnect,
	kDebitSmartCard,
	kCheckValidDebitCard,
	kIsGPM896,
	kIsGPM103,
	kIsGPM256,
	kDebit896Card,
	kDebit103Card,
	kGet896Credits,
	kGet103Credits,
	kCheckWipeCard,
	kUserWantsToDebitCard,

	/* QuickSort Manager */
	kQSort,
	
	/* Secret Keys Manager */
	kTrySecretCommand,
	kTestThisSequence,
	kExecCommands,
	kGetSecretList,
	kGetSecretSequence,
	kResetSecretCommand,
	kTestSequence,
	kPlayMaze,
	kEndPlayMaze,
	
	/* math manager */
	kLongDivide,
	kLongMultiply,
	kSqrt,
	kRandomShort,
	kSine,
	kCosine,
	
	/* Ranking Manager */
	kGetFirstRanking,
	kGetNextRanking,
	kGetPrevRanking,
	kGetHiddenStat,
	kNextRankingExists,
	kPrevRankingExists,
	kCountRankings,
	kGetFirstRankingID,
	kGetNextRankingID,
	kGetUniqueRankingID,
	kGetRankingSize,
	kDeleteRanking,
	kAddRanking,
	kGetRanking,
	
	/* progress manager */
	kInitProgressProcs,
	kSpawnProgressProc,
	kDisposeProgressProc,
	kSetProgressPosition,
	kProgressIdle,
	
	/* Radio Button Manager */
	kSetupRadioButton,
	kDrawRadioButton,
	kActivateRadioButton,
	kDeactivateRadioButton,
	kRadioButtonSelectNext,
	kRadioButtonSelectPrevious,
	kRadioButtonGetSelection,
	kRadioButtonSetSelection,
	kRadioButtonIdle,
	kDisposeRadioButtonRef,
	kDrawRadioSelection,

	/* NetMisc manager */
	kNetIdleFunc,
	kCheckError,
	kccitt_updcrc,
	
	/* Peer Connect Manager */
	kDoPeerConnection,
	kConnectToPeer,
	kDisplayPeerInfo,
	kDoSlavePeerConnect,
	kDoMasterPeerConnect,
	kPeerConnectionDropped,
	kDoPeerRestoreOS,
	kDoExchangePeerData,
	kDoPeerDialog,
	kChat,
	kPeerStartVBL,
	kPeerStopVBL,
	kPeerVBLHandler,

	/* Fifo Manager */

	kFifoInit,
	kFifoActive,
	kFifoWrite,
	kFifoRead,
	kFifoPeek,
	kFifoPeekEnd,
	kFifoAvailable,
	kFifoRemaining,
	kFifoSkip,
	kFifoCopy,
	kFifoChkSum,
	kGetFifoIn,
	kFifoLastCharIn,
	kFifoUnwrite,
	kFifoSize,
	kFifoFlush,
	kFifoUnread,
	kFifoResetConsumption,
	kFifoAdjustConsumption,

	/* VBL Manager */
	kAddVBLRequest,
	kRemoveVBLRequest,
	kVBLIdle,

#if 0
	/* connection manager */
	kInitConnection,
	kReadSerialByte,
	kWriteSerialByte,
	kTransmitBufferFree,
	kWaitForConnection,
	kTestForConnection,
	kAcknowledgeConnection,
	kDialNumber,
	kDisconnect,
#endif

	/* Last minute additions - we don't want to renumber anything above */
	kPreflightNewAddressEntry,


	
	/* reserved ranges */	
	kPatchRangeStart,
	kPatchRangeEnd = kPatchRangeStart + 50,
	
	/* keep this one as last */
	kLastFunction
};

#if ( kLastFunction >= kNumSelectors )
#error "Too many selectors, bump size of function table"
#endif 


/* manager commands */
enum
{
	kHardInitialize,									// new install init
	kSoftInialize,										// reset init
	kHardClose,											// go away for ever
	kSoftClose,											// soft power down?
	kCodeBlockMoved,									// block in os code heap moved
	kGlobalsMoved,										// globals blocked moved
	kRemovePatch										// remove an os patch
};


/* manager versions */
#define	kDispatcherVersion		0x1
#define	kMemMgrVersion			0x1
#define	kReliableMgrVersion		0x1
#define	kControlMgrVersion		0x1
#define	kGlobalMgrVersion		0x1
#define	kPatchDBVersion			0x1
#define	kMessageVersion			0x1
#define	kSpriteMgrVersion		0x1
#define	kDecompressMgrVersion	0x1
#define	kTimeMgrVersion			0x1
#define	kAnimationMgrVersion	0x1
#define	kPathMgrVersion			0x1
#define	kPatternMgrVersion		0x1
#define	kCursorMgrVersion		0x1
#define	kDatabaseMgrVersion		0x1
#define	kTextMgrVersion			0x1
#define	kPhysicalMgrVersion		0x1
#define	kTransportMgrVersion	0x1
#define	kScreenMgrVersion		0x1
#define	kVDPMgrVersion			0x1
#define	kOpponentMgrVersion		0x1
#define	kUsrConfgMgrVersion		0x1
#define kDITLMgrVersion			0x1
#define kEventsMgrVersion		0x1
#define	kSoundMgrVersion		0x1
#define	kGetDataMgrVersion		0x1
#define	kChallengeMgrVersion	0x1
#define	kCartMgrVersion			0x1
#define	kEndGameMgrVersion		0x1
#define	kModemMiscMgrVersion	0x1
#define	kScreensMgrVersion		0x1
#define	kBackdropMgrVersion		0x1
#define	kBoxSerialMgrVersion	0x1
#define	kPlayerDBMgrVersion		0x1
#define	kMiscDBItemsVersion		0x1
#define	kTextUtilsVersion		0x1
#define	kNewsVersion			0x1
#define	kGameDBVersion			0x1
#define	kPerfornicationVersion	0x1
#define	kMailVersion			0x1
#define	kSendQMgrVersion		0x1
#define	kDialogMgrVersion		0x1
#define	kRoskoMgrVersion		0x1
#define	kNetRegisterMgrVersion	0x1
#define	kNewAddressMgrVersion	0x1
#define	kDefDialogMgrVersion	0x1
#define	kGameTalkMgrVersion		0x1
#define kKeyboardEntryVersion	0x1
#define kSmartCardMgrVersion	0x1
#define kSortManagerVersion		0x1
#define kSecretManagerVersion	0x1
#define kMathManagerVersion		0x1
#define kRankingManagerVersion	0x1
#define kProgressManagerVersion	0x1
#define kRadioButtonMgrVersion	0x1
#define	kNetMiscMgrVersion		0x1
#define	kPeerConnectMgrVersion	0x1
#define	kFifoManagerVersion		0x1
#define	kVBLManagerVersion		0x1

/* manager entry points */

long	_DispatcherControl( short command, long data );
long	_MemoryMgrControl( short command, long data );
long	_ReliabilityControl ( short command, long data );
long	_ControllerControl ( short command, long data );
long	_GlobalControl ( short command, long data );
long	_PatchDBControl ( short command, long data );
long	_MessageDispatchControl ( short command, long data );
long	_SpriteControl ( short command, long data );
long	_DecompressControl ( short command, long data );
long	_TimeControl ( short command, long data );
long	_AnimationControl ( short command, long data );
long	_PathControl ( short command, long data );
long	_PatternControl ( short command, long data );
long	_CursorControl ( short command, long data );
long	_TextControl ( short command, long data );
long	_DatabaseControl ( short command, long data );
long	_PhysicalLayerControl ( short command, long data );
long	_TransportLayerControl ( short command, long data );
long	_DiskTransportControl ( short command, long data );
long	_ScreenControl ( short command, long data );
long	_VDPControl ( short command, long data );
long	_OpponentControl ( short command, long data );
long	_UsrConfgControl ( short command, long data );
long	_DITLControl ( short command, long data );
long	_EventsControl ( short command, long data );
long	_SoundControl ( short command, long data );
long	_GetDataControl ( short command, long data );
long	_ChallengeControl ( short command, long data );
long	_CartridgeControl ( short command, long data );
long	_EndGameControl ( short command, long data );
long	_ModemMiscControl ( short command, long data );
long	_ScreensControl ( short command, long data );
long	_BackdropControl ( short command, long data );
long	_BoxSerialControl ( short command, long data );
long	_PlayerDBControl ( short command, long data );
long	_MiscDBItemsControl ( short command, long data );
long	_TextUtilsControl ( short command, long data );
long	_NewsControl ( short command, long data );
long	_GameDBControl ( short command, long data );
long	_PerfornicationControl ( short command, long data );
long	_MailControl ( short command, long data );
long	_SendQControl ( short command, long data );
long	_DialogControl ( short command, long data );
long	_RoskoControl ( short command, long data );
long	_NetRegisterControl ( short command, long data );
long	_NewAddressControl( short command, long data );
long	_DefDialogControl( short command, long data );
long	_GameTalkControl( short command, long data );
long	_KeyboardEntryControl( short command, long data );
long	_SmartCardControl( short command, long data );
long	_SortControl( short command, long data );
long	_SecretControl( short command, long data );
long	_MathControl( short command, long data );
long	_RankingControl( short command, long data );
long	_ProgressControl( short command, long data );
long	_RadioButtonControl( short command, long data );
long	_NetMiscControl( short command, long data );
long	_PeerConnectControl( short command, long data );
long	_FifoControl( short command, long data );
long	_VBLControl( short command, long data );

#endif

