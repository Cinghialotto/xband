/*
 *	$Id: SmartCard.h,v 1.2 1995/05/11 22:57:38 jhsia Exp $
 *	
 *	$Log: SmartCard.h,v $
 * Revision 1.2  1995/05/11  22:57:38  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		SmartCard.h

	Contains:	xxx put contents here xxx

	Written by:	Ted

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):
									
		<19>	 8/19/94	HEC		Include SegaTypes.h
		<18>	 8/18/94	HEC		Moved XBANDCard typedef to SegaTypes.h
		<17>	 8/18/94	HEC		Added UserWantsToDebitCard.
		<16>	 8/16/94	HEC		api change to DebitSmartCard.
		<15>	 8/15/94	DJ		padded xbandcard to work on unix
		<14>	 8/13/94	HEC		Add CheckWipeCard().
		<13>	 8/12/94	HEC		Slightly different API. Added DebitCardForConnect().
		<12>	  8/9/94	HEC		Move smartcard errors to errors.h
		<11>	  8/1/94	HEC		Define XBANDCard type.
		<10>	 7/27/94	HEC		Removed CreditToken typedef, and Set/GetCreditToken protos.
		 <9>	 7/22/94	SAH		Fixed a conflict with OSManagers - renamed the card types.
		 <8>	 7/22/94	HEC		PresentSecretCode took the wrong size parameter!
		 <7>	 7/21/94	HEC		Changes to make GPM103 debit.
		 <6>	 7/17/94	DJ		added kUsingDebitCard, kUsingCreditToken, etc for server msg
		 <5>	 7/17/94	HEC		Added Get and SetCreditToken.
		 <4>	 7/17/94	HEC		Added CheckValidDebitCard.
		 <3>	 7/16/94	HEC		New errors, new routines.
		 <2>	 7/10/94	HEC		New sendQ message type, routine prototypes.
		 <1>	  7/1/94	HEC		first checked in

	To Do:
*/


#ifndef __SmartCard__
#define __SmartCard__

#ifndef __SegaTypes__
#include "SegaTypes.h"
#endif

//
// This enum is sent to the server in DoSendDebitCardOpCode to tell it how we're paying.
//
enum {
	kUsingDebitCard,
	kUsingCreditToken,
	kUsingCreditCard
};

// SmartCard Types (These values are burned into each card in a prespecified location)

#define kCardGPM896		0x01			/* Rechargeable Debit Card */
#define kCardGPM103		0x02			/* One-time credit Card */
#define kCardGPM256		0x03			/* 160-bit ROM for XPANDSION Card */

#ifndef __SERVER__

#ifndef __OSManagers__
#include "OSManagers.h"
#endif

#ifndef __Dispatcher__
#include "Dispatcher.h"
#endif


OSErr GetCardType ( long *type ) =
	CallDispatchedFunction( kGetCardType );

OSErr CardInstalled( void ) =
	CallDispatchedFunction( kCardInstalled );

OSErr ReadCardBytes( long address, void *data, long bytes )  =
	CallDispatchedFunction( kReadCardBytes );

OSErr WriteCardBit( long address ) =
	CallDispatchedFunction( kWriteCardBit );

void GotoCardAddress( short address ) =
	CallDispatchedFunction( kGotoCardAddress );

void IncrementCardAddress( short count ) =
	CallDispatchedFunction( kIncrementCardAddress );

short ReadCardBit( void ) =
	CallDispatchedFunction( kReadCardBit );

void ResetCard( void ) =
	CallDispatchedFunction( kResetCard );

short GetRemainingCredits( Boolean actual ) =
	CallDispatchedFunction( kGetRemainingCredits );

OSErr PresentSecretCode( short code ) =
	CallDispatchedFunction( kPresentSecretCode );

OSErr DebitSmartCard( XBANDCard *card, long debits, long *actualDebited ) =
	CallDispatchedFunction( kDebitSmartCard );

short FindFirstOne( long address, long size ) =
	CallDispatchedFunction( kFindFirstOne );

short CountCardBits( long address, long size ) =
	CallDispatchedFunction( kCountCardBits );

OSErr DebitCardForConnect( void ) =
	CallDispatchedFunction( kDebitCardForConnect );

OSErr CheckValidDebitCard( void ) =
	CallDispatchedFunction( kCheckValidDebitCard );

OSErr IsGPM896( void ) =
	CallDispatchedFunction( kIsGPM896 );

OSErr IsGPM103( void ) =
	CallDispatchedFunction( kIsGPM103 );

OSErr IsGPM256( void ) =
	CallDispatchedFunction( kIsGPM256 );

OSErr Debit896Card( XBANDCard *card ) =
	CallDispatchedFunction( kDebit896Card );

OSErr Debit103Card( XBANDCard *card ) =
	CallDispatchedFunction( kDebit103Card );

short Get896Credits( void ) =
	CallDispatchedFunction( kGet896Credits );

short Get103Credits( void ) =
	CallDispatchedFunction( kGet103Credits );

short CheckWipeCard( void ) =
	CallDispatchedFunction( kCheckWipeCard );

Boolean UserWantsToDebitCard( void ) =
	CallDispatchedFunction( kUserWantsToDebitCard );


#endif __SERVER__
#endif __SmartCard__

