/*
 *	$Id: RoskoSega.h,v 1.2 1995/05/11 22:57:31 jhsia Exp $
 *	
 *	$Log: RoskoSega.h,v $
 * Revision 1.2  1995/05/11  22:57:31  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		RoskoSega.h

	Contains:	xxx put contents here xxx

	Written by:	xxx put writers here xxx

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <4>	 6/15/94	SGR		added SetLEDs
		 <3>	 6/15/94	SAH		Managerized and new functions for new hardware.
		 <2>	 6/14/94	SAH		Added DetermineCardVersion.
		 <1>	  6/4/94	HEC		first checked in

	To Do:
*/



#ifndef __RoskoSega__
#define __RoskoSega__


#ifndef __SegaOS__
#include "SegaOS.h"
#endif


void SetSafeRomSrc ( Ptr start, Ptr end ) = 
	CallDispatchedFunction( kSetSafeRomSrc );

void SetSafeRamSrc ( Ptr start, Ptr end ) = 
	CallDispatchedFunction( kSetSafeRamSrc );

void SetVectorTblAddr ( Ptr address ) = 
	CallDispatchedFunction( kSetVectorTblAddr );

void SetVector ( long vector, Ptr address ) = 
	CallDispatchedFunction( kSetVector );



#endif __RoskoSega__

