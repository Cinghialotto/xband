/*
 *	$Id: Dispatcher.h,v 1.2 1995/05/11 22:57:10 jhsia Exp $
 *	
 *	$Log: Dispatcher.h,v $
 * Revision 1.2  1995/05/11  22:57:10  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Dispatcher.h

	Contains:	Public interface to system dispatcher

	Written by:	Konstantin Othmer

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<15>	 8/14/94	ADS		New dispatch.  Also moved non-common calls to
									DispatcherControl.h
		<14>	  8/9/94	ADS		Preshifted dispatch codes for more speed
		<13>	  8/2/94	SAH		Added get and set os version.
		<12>	 7/29/94	SAH		Made the dispatcher macro smaller.
		<11>	 7/24/94	ADS		new dispatcher tracing stuff
		<10>	 7/15/94	dwh		unix-ise.
		 <9>	 7/11/94	SAH		Added soft init flagss.
		 <8>	  7/1/94	SAH		Added BuildDispatcherTable,
		 <7>	 6/29/94	ADS		Adding patch messageflags
		 <6>	 6/28/94	SAH		Added SoftInitOS.
		 <5>	 5/27/94	BET		Changed the dispatcher vector for the both boxes.
		 <4>	 5/27/94	SAH		Changed the disppatcher vector for the sega.
		 <4>	 5/25/94	HEC		Changed moveq#,d0 to move.w #,d0 in selector glue
		 <3>	 5/18/94	HEC		#include "OSManagers.h"
		 <2>	 5/17/94	KON		Added #ifndef __Dispatcher__

	To Do:
*/

#ifndef __Dispatcher__
#define __Dispatcher__

#include "OSManagers.h"


/*
* global accessor macro. these are accessed through the global ptr gGlobalPtr when using the
* simulator. we don't care about the name of the global structure in that case. when running
* live we reference through the structure name off of a5.
*/

#ifdef SIMULATOR
#define REFGLOBAL(a,b) ((MANAGERGLOBALTYPE *) gGlobalPtr)->b
#else
#define	REFGLOBAL(a,b) (a).b
#endif



//  -------------------------------------------
//	---	macro to dispatch to our dispatcher ---
//  -------------------------------------------


//  On a real box it's:		MOVE.W #disp<<2,D0  JSR kDispVector
//
//  But you can't step the debugger through that, so
//
//	the simulator way is :   MOVE.W #disp<<2,D0  MOVE.L kDispVector,A0   JSR (A0)

//  We have to use the non-thinkC-friendly dispatcher on ROMDB runs,
//  because it's building code that will run on the final product.
//
//  This means ROMDB runs will be somewhat hard to debug....


#if defined (SIMULATOR) && !defined (ROMDB)
	#define SLOW_DISPATCH
#else
	#define FAST_DISPATCH
#endif



#ifdef SLOW_DISPATCH
	#define	kDispatcherVector	0x40
	#define	CallDispatchedFunction( sel )	\
						{ 0x303c, (sel)<<2, 0x2078, kDispatcherVector, 0x4E90 }
#else
	#define	kDispatcherVector	0x40
	#define	CallDispatchedFunction( sel )	\
						{ 0x303c, (sel)<<2, 0x4EB8, kDispatcherVector }
#endif




//  Just a few calls here, which really belong in DispatcherControl.h,
//  but since every single manager uses them, we'll put 'em here.

#ifndef	unix

short	AllocateGlobalSpace( short id, short offset, long size, Ptr * globals ) =
	CallDispatchedFunction( kAllocateGlobalSpace );

void	SetDispatchedFunction ( short selector, short manager, ProcPtr proc ) = 
	CallDispatchedFunction( kSetDispatchedFunction );

short	GetManagerGlobals ( short id, Ptr * globals, short * offset ) = 
	CallDispatchedFunction( kGetManagerGlobals );
	
#endif


#endif __Dispatcher__

