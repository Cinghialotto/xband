/*
 *	$Id: MessDispPriv.h,v 1.2 1995/05/11 22:57:20 jhsia Exp $
 *	
 *	$Log: MessDispPriv.h,v $
 * Revision 1.2  1995/05/11  22:57:20  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		MessDispPriv.h

	Contains:	xxx put contents here xxx

	Written by:	xxx put writers here xxx

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <7>	 8/22/94	ADS		Add hidden box serial # calls
		 <6>	 7/21/94	BET		add #ifdef __SERVER__
		 <5>	 7/14/94	ADS		Remove placeholder
		 <4>	 7/13/94	ADS		Vectorize EVERYTHING
		 <3>	  6/4/94	DJ		some minor tweak that I can't remember
		 <2>	  6/4/94	KON		Make send, receive server, and receive peer opcode tables
									individually sizable.

	To Do:
*/

#ifndef __Messages_Priv__
#define __Messages_Priv__


#ifndef	__Messages__
#include "Messages.h"
#endif __Messages__



typedef struct
{
	opCodeProcPtr	opCodeProc[kNumReceiveOpCodeItems];
	unsigned char	version[kNumReceiveOpCodeItems];
} opCodeReceiveTable;

typedef struct
{
	opCodeProcPtr	opCodeProc[kNumPeerOpCodeItems];
	unsigned char	version[kNumPeerOpCodeItems];
} opCodePeerTable;

typedef struct
{
	sendOpCodeProcPtr	opCodeProc[kNumSendOpCodeItems];
	unsigned char		version[kNumSendOpCodeItems];
} sendMessageTable;


//
// Private
//
typedef struct MessageDispatchGlobals
{
	opCodeReceiveTable	*receiveServerTable;
	sendMessageTable	*sendMessageTable;
	opCodePeerTable 	*receivePeerTable;
	long				miscLoginBits;
}MessageDispatchGlobals;



#ifdef SIMULATOR
#undef MANAGERGLOBALTYPE
#define	MANAGERGLOBALTYPE		MessageDispatchGlobals
#endif








#ifdef __SERVER__
// do something so the server can use the file

#else

// internal functions, vectorized for patching



void GetSendMessageHandler( short opCode, unsigned char *version, sendOpCodeProcPtr *opCodeProc ) =
	CallDispatchedFunction( kGetSendMessageHandler );
	
void GetPeerMessageHandler( short opCode, unsigned char *version, opCodeProcPtr *opCodeProc ) =
	CallDispatchedFunction( kGetPeerMessageHandler );

short GetSerialOpCode( short *data ) =
	CallDispatchedFunction( kGetSerialOpCode );

void GetServerMessageHandler( short opCode, unsigned char *version, opCodeProcPtr *opCodeProc ) =
	CallDispatchedFunction( kGetServerMessageHandler );

void InstallPeerHandler( unsigned char version, short opCode, opCodeProcPtr opCodeProc ) =
	CallDispatchedFunction( kInstallPeerHandler );

void InstallReceiveServerHandler( unsigned char version, short opCode, opCodeProcPtr opCodeProc ) =
	CallDispatchedFunction( kInstallReceiveServerHandler );

void InstallSendMessageHandler( unsigned char version, short opCode, sendOpCodeProcPtr opCodeProc ) =
	CallDispatchedFunction( kInstallSendMessageHandler );

MessErr ReceivePeerMessageDispatch( short opCode ) =
	CallDispatchedFunction( kReceivePeerMessageDispatch );

MessErr ReceiveServerMessageDispatch( short opCode ) =
	CallDispatchedFunction( kReceiveServerMessageDispatch );

MessErr GobbleMessage(long size) =
	CallDispatchedFunction( kGobbleMessage );

#endif //__SERVER__

#endif __Messages_Priv__ 

