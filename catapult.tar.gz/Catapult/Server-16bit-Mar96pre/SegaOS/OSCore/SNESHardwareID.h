/*
 *	Copyright: � 1995 Catapult Entertainment Inc., all rights reserved
 *
 *	$Id: SNESHardwareID.h,v 1.5 1995/06/01 15:02:25 fadden Exp $
 *	
 *	$Log: SNESHardwareID.h,v $
 * Revision 1.5  1995/06/01  15:02:25  fadden
 * Merge in from newbr.
 * -> Moved definition of hwid to DataBase_HardwareID.h.
 *
 * Revision 1.4  1995/05/11  22:57:32  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		SNESHardwareID.h

	Contains:	xxx put contents here xxx

	Written by:	Josh

	Copyright:	� 1995 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	 2/23/95	JBH		first checked in

	To Do:
*/


#ifndef __SNESHardwareID__
#define	__SNESHardwareID__

#ifdef DEFINED_ELSEWHERE		// now in DataBase_HardwareID.h
// Hardware ID types.  This way if we have different families of hardware ID
// (ie some parts from Dallas Semiconductor, and some other product which
// has a secure microcontroller), we can append this number to their
// serial #'s // to guarantee uniqueness across ALL products.
//
// (These probably don't belong in "SNES" HardwareID.h.)
#define kHWID_NoHWID			0
#define kHWID_DallasTouch		1
#define kHWID_SCSecureMicro		2
#endif

typedef
struct SnesHardwareID
{
	unsigned char	familyCode;
	unsigned char	serialNumber[6];
	unsigned char	crc;
} SnesHardwareID;

// Error codes, returned by GetHardwareID (0 is noError)
#define		kHWIDNoPullupResistorError		1		/* the line never went back up after reset */
#define		kHWIDNoPresencePulseError		2		/* the ID part never responded after reset */
#define		kHWIDNoPullupAfterPresenceError	3		/* the line never went back up after presence */
#define		kHWIDBadCRCError				4		/* the CRC check on the part failed */

#ifndef __SERVER__
void	ReadHardwareID( void )
	CallDispatchedFunction( kReadHardwareID );

short	GetHardwareID( HardwareID *idBuffer )
	CallDispatchedFunction( kGetHardwareID );

unsigned char	HardwareIDCRC( unsigned char *buffer )
	CallDispatchedFunction( kHardwareIDCRC );
#endif

#endif
