/*
 *	$Id: ROMMain.h,v 1.2 1995/05/11 22:57:28 jhsia Exp $
 *	
 *	$Log: ROMMain.h,v $
 * Revision 1.2  1995/05/11  22:57:28  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		ROMMain.h

	Contains:	xxx put contents here xxx

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	 7/11/94	SAH		first checked in

	To Do:
*/



void	BootStrap ( void );
void	BootOS ( Boolean gameRestart );
void	BootOSVector ( Boolean gameRestart );

