/*
 *	$Id: ScreensPriv.h,v 1.2 1995/05/11 22:57:34 jhsia Exp $
 *	
 *	$Log: ScreensPriv.h,v $
 * Revision 1.2  1995/05/11  22:57:34  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		ScreensPriv.h

	Contains:	xxx put contents here xxx

	Written by:	KON

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <4>	 8/18/94	JBH		Added screensEntered, used to seed RandomShort at softInit time
		 <3>	  8/6/94	JOE		added global for _GetCurScreenIdentifier
		 <2>	 6/13/94	KON		Fix up name typos from copy and paste.
		 <1>	 6/10/94	KON		first checked in

	To Do:
*/



typedef
struct ScreensGlobals
{
	ScreenDispatch	gCurScreenHandler;
	DBID			curScreen;
	long			screensEntered;			/* used as a random seed at softInit time */
} ScreensGlobals;


#ifdef SIMULATOR
#define MANAGERGLOBALTYPE ScreensGlobals
#else

extern ScreensGlobals screens;

#endif


