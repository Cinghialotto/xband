/*
 *	$Id: ModemMiscPriv.h,v 1.2 1995/05/11 22:57:23 jhsia Exp $
 *	
 *	$Log: ModemMiscPriv.h,v $
 * Revision 1.2  1995/05/11  22:57:23  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		ModemMiscPriv.h

	Contains:	xxx put contents here xxx

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	  7/2/94	SAH		first checked in

	To Do:
*/



typedef
struct ModemMiscGlobals
{
	Boolean	modemState;
} ModemMiscGlobals;

#ifdef SIMULATOR
#define	MANAGERGLOBALTYPE	ModemMiscGlobals
#else
extern ModemMiscGlobals modMisc;
#endif

