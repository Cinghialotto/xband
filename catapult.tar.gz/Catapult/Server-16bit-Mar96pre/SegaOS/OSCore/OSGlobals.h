/*
 *	$Id: OSGlobals.h,v 1.2 1995/05/11 22:57:25 jhsia Exp $
 *	
 *	$Log: OSGlobals.h,v $
 * Revision 1.2  1995/05/11  22:57:25  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		OSGlobals.h

	Contains:	Position dependent OS globals.

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<44>	 8/29/94	SAH		Andy is a fucker.
		<43>	 8/29/94	ADS		Move the heaps bar (added 2k to database)
		<42>	 8/28/94	SAH		Shrink the ROMDB to allow room for some code, dammit!
		<41>	 8/28/94	KON		Moved sim ROM extra to 15K (up 10K).
		<40>	 8/28/94	ADS		Add global GameTalk checksum table at 0x400
		<39>	 8/27/94	ADS		Rom DB high
		<38>	 8/27/94	SAH		Bumped os and database heap. Shrunk game heap.
		<37>	 8/25/94	SAH		Shrunk the ROM DB heap for the sega build.
		<36>	 8/25/94	SAH		New boot vector and ROMDB location.
		<35>	 8/25/94	ADS		Romdb ++1k
		<34>	 8/25/94	ADS		Get rid of grungy ROM globals, made romdb 1k smaller
		<33>	 8/24/94	SAH		Reduced ROM DB by 3K (too much code!).
		<32>	 8/19/94	JBH		Bumped ROM DB size by 8K.
		<31>	 8/14/94	ADS		Profiling eats less RAM now
		<30>	 8/11/94	SAH		Added SMALLRAM #ifdef for smalker SRAM heap debugging.
		<29>	 8/10/94	SAH		New heap sizes for 64K sram.
		<28>	  8/9/94	ADS		Bigger globals stack when code profiler is running
		<27>	 7/27/94	SAH		Shrunk the ROM db some to fuck everyone up. Made the SRAM dbase
									heap a little bigger.
		<26>	 7/17/94	HEC		Lowered ROM DB size.
		<25>	 7/16/94	KON		Crank ROM up to 380K.
		<24>	 7/16/94	CMY		Bumped ROM DB size to make room for intro animation.
		<23>	 7/16/94	KON		Bumped ROM DB size to make room for new mail screen and two more
									two bit fonts.
		<22>	 7/11/94	SAH		Added ROM debug globals and gBoxNumber.
		<21>	 7/11/94	KON		Bumped the ROM DB size to make room for another two bit font.
		<20>	  7/8/94	HEC		Fucked around with hack.
		<19>	  7/8/94	SAH		HACK for steve.
		<18>	  7/2/94	SAH		Added kMinMappedRom.
		<17>	  7/1/94	SAH		Added VALIDSRAMADDRESS macro and kMinTableSize.
		<16>	 6/30/94	SAH		Made the ROM a more real thing for the stimulator.
		<15>	 6/30/94	CMY		Bumped ROM size to hold keyboard screens.
		<14>	 6/30/94	SAH		Added AddressInRom macro.
		<13>	 6/28/94	SAH		New globals.
		<12>	 6/21/94	KON		Bump ROM size for Joey's latest graphics.
		<11>	 6/20/94	SAH		Ate some more rom.
		<10>	 6/20/94	SAH		Set the sram heap to it's real size.
		 <9>	 6/20/94	KON		Bump the ROM DB heap to 148k.
		 <8>	 6/20/94	KON		Rename kRomSize to kRomDBSize.
		 <7>	 6/16/94	SAH		Some new register globals.
		 <6>	 6/15/94	SAH		Updated rom database for new hardware. Added gRegisterBase and
									killed gMagicRts and gNewRosko.
		 <5>	 6/14/94	SAH		Made the ROM database a more realistic size (it really has to be
									smaller than 512K kon!). Changed some other crap while I was
									here.
		 <4>	  6/9/94	KON		Made the ROM bigger so the new screen stuff will fit.
		 <3>	  6/5/94	SAH		New heap sizes.
		 <2>	  6/3/94	SAH		Brought in the remaining heap size constants and shrunk the sram
									heap.
		 <1>	 5/28/94	SAH		first checked in

	To Do:
*/



#ifndef	__OSGLOBALS__
#define	__OSGLOBALS__

#ifndef __BOXPROFILE_H_
#include "BoxProfile.h"
#endif		// __BOXPROFILE_H_





//=== WARNING ===
//
//  If you change kRomDBSize, you MUST change the ROMDB location,
//	in ROM Map.  These values are NOT connected by any automatic means.
//

#if (defined (ROMDB) || !defined(SIMULATOR))
	#define kSIMRomExtra	0
#else
	#define	kSIMRomExtra	(12 * 1024L)					// change SIM slop here
#endif

#define kRomDBSize 			((318 * 1024L) + kSIMRomExtra)	// change base size here


#define	kRomSize			(512 * 1024L)
#define	kRomBase			0x00200000
#define kRomEntryPoint		0x100							// Matches ROM Map value
#define kRomGTCksumOffset	0x400							// GT checksum table
#define	kRomDBOffset		(kRomSize-kRomDBSize)			// ROMDB is always "the top"

#define	kDRAMSize			0x10000L						// 64K of DRAM
#define	kStackSize			0x1000L							// 4K stack space
#define	kTempHeapSize		(kDRAMSize - kStackSize)		// size of temp heap


#ifdef DISPATCHER_PROFILING
	#define kGlobalsCallStackSize	( 64 * sizeof(ProfileGlobalStack) )
//	#define kExtraMinTableSize		( 1024 * 16L )
	#define kExtraMinTableSize		0					// we'll be putting profiling in the heaps for now
#else
	#define	kGlobalsCallStackSize	( 64 * 8 )				/* 64 nested function calls */
	#define kExtraMinTableSize		0
#endif



/*
 * Following Perm heaps must fit within 64K!
 * We assume that the upper low level os heap will eat about 4K
 */
#ifdef SMALLRAM
#define	kOSCodeHeapSize			( 1024 * 8L )
#define	kMinTableSize			( 1024 * 5L + kExtraMinTableSize)
#define	kDataBaseHeapSize		( 1024 * 20L )
#define	kGameRuntimeHeapSize	( 1024 * 10L )			// this is a minimum size
#else

#define	kOSCodeHeapSize			( 1024 * 19L )
#define	kMinTableSize			( 5500L + kExtraMinTableSize)
#define	kDataBaseHeapSize		( 1024 * 27L )
#define	kGameRuntimeHeapSize	( 1024 * 12L )			// this is a minimum size

#endif

#if ( ( kOSCodeHeapSize + kDataBaseHeapSize + kGameRuntimeHeapSize + kMinTableSize ) > kSRAMSize )
#error "SRAM is too small"
#endif


#define gRomDatabase		(gRomBottom + kRomDBOffset)
#define gRomGTChecksum		(gRomBottom + kRomGTCksumOffset)
#define gRomTop				(gRomBottom + kRomSize)


/*
*	Some general useful macros
*/

#define	ADDRESSINROM(x)		( ((unsigned long) (x)) >= gRomBottom && ((unsigned long) (x)) < gRomTop )
#define	VALIDSRAMADDRESS(x)	( !((long) (x) & 0x1) && ((unsigned long) (x)) >= gBottomPermRam && ((unsigned long) (x)) < gTopPermRam )
#endif

