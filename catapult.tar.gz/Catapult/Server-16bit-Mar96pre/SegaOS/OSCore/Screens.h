/*
 *	$Id: Screens.h,v 1.2 1995/05/11 22:57:33 jhsia Exp $
 *	
 *	$Log: Screens.h,v $
 * Revision 1.2  1995/05/11  22:57:33  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Screens.h

	Contains:	xxx put contents here xxx

	Written by:	KON

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<21>	 8/18/94	JBH		Added GetScreensEnteredCount.
		<20>	  8/6/94	JOE		added _GetCurScreenIdentifier
		<19>	 7/29/94	CMY		Fixed selector for BoxScreenLayoutString.
		<18>	 7/29/94	CMY		Added BoxScreenLayoutString
		<17>	  7/6/94	ADS		moved per-screen info to ScreenLists.h
		<16>	  7/6/94	ADS		Added player info options screen
		<15>	  7/5/94	ADS		added aboutbox screen
		<14>	  7/4/94	ADS		New interface for screen control
		<13>	  7/2/94	CMY		Added address edit screen.
		<12>	  7/1/94	CMY		Added mail edit screen.
		<11>	 6/30/94	KON		Add GetNewsScreenDispatchPtr.
		<10>	 6/18/94	KON		Change kResetScreen to kResetCurrentScreen to prevent name
									conflict.
		 <9>	 6/17/94	KON		Add screen reset constant.
		 <8>	 6/13/94	KON		Make selection parameter to screens a long.
		 <7>	 6/11/94	KON		Add four way options screen.
		 <6>	 6/11/94	KON		Define pop screen magic return value for stack based screen
									navigation.
		 <5>	 6/11/94	KON		Add four way mail screen.
		 <4>	 6/10/94	KON		Add screen reset and preflight functions.
		 <3>	 6/10/94	KON		Add FindOpponent screen.
		 <2>	 6/10/94	KON		Added support for more screens...still some to go.
		 <1>	  6/9/94	KON		first checked in

	To Do:
*/


#ifndef __Screens__
#define __Screens__

#ifndef __DataBase__
#include "DataBase.h"
#endif __DataBase__

#ifndef _SCREENLISTS_H_
#include "ScreenLists.h"
#endif

#ifndef __SegaGraphics__
#include "SegaGraphics.h"
#endif


//
// Screen commands
//
enum
{
	kDoScreenPreflight = 0,
	kDoScreenReset,
	kDoScreenSetupCommand,
	kDoScreenCommand,
	kDoScreenKill
};

// this structure contains data communicated from screen to screen

typedef struct {
	long	selection;		// where we can remember it
	long	initValue;		// used to control deeper screens we invoke
} ScreenParams;

typedef long (*ScreenDispatch)(short action, long command, long *refCon, ScreenParams *params);	


// result codes.  0 means do nothing, pos. numbers are table-goto commands

#define kScreenNotHandled	0
#define kPopScreen			0xFF
#define kResetScreen 		0xFE
#define kForceGotoScreen	0xFD


void InitScreens( void ) = 
	CallDispatchedFunction( kInitScreen );

long PreflightScreen( DBID screenID, long* initValue ) =
	CallDispatchedFunction( kPreflightScreen );

void ResetScreen( long *refCon ) =
	CallDispatchedFunction( kResetCurrentScreen );

void SetupScreen( DBID screenID, long *refCon, ScreenParams* params ) =
	CallDispatchedFunction( kSetupScreen );

long SendCommandToScreen( long command, long *refCon, ScreenParams* params ) =
	CallDispatchedFunction( kSendCommandToScreen );
	
void KillScreen( long *refCon ) =
	CallDispatchedFunction( kKillScreen );
	
DBID GetNewScreenIdentifier( DBID oldScreenID, short result ) =
	CallDispatchedFunction( kGetNewScreenIdentifier );
	
DBID GetCurScreenIdentifier( void ) =
	CallDispatchedFunction( kGetCurScreenIdentifier );
	
DBID *GetScreenStateTable( DBID oldScreenID ) =
	CallDispatchedFunction( kGetScreenStateTable );


/* ScreenLayout utilities
 *
 * These guys provide an interface to a ScreenLayoutType database entry. A ScreenLayout
 * is just a list of Rectangles, Points, and String IDs -- three data types that are
 * very helpful for laying out screens. If you need a place to store such info and the
 * DITL manager isn't appropriate, this is a cheezy way to do it.
 */
 
short GetScreenLayoutRectangleCount( DBID layoutID ) = 
	CallDispatchedFunction( kGetScreenLayoutRectangleCount );

void GetScreenLayoutRect( DBID layoutID, short rectangleIndex, Rect *data ) =
	CallDispatchedFunction( kGetScreenLayoutRect );

void GetScreenLayoutCharRect( DBID layoutID, short rectangleIndex, segaCharRect *data ) =
	CallDispatchedFunction( kGetScreenLayoutCharRect );
	
short GetScreenLayoutPointCount( DBID layoutID ) = 
	CallDispatchedFunction( kGetScreenLayoutPointCount );

void GetScreenLayoutPoint( DBID layoutID, short pointIndex, Point *data ) =
	CallDispatchedFunction( kGetScreenLayoutPoint );

short GetScreenLayoutStringCount( DBID layoutID ) = 
	CallDispatchedFunction( kGetScreenLayoutStringCount );
	
char *GetScreenLayoutString( DBID layoutID, short stringIndex ) =
	CallDispatchedFunction( kGetScreenLayoutString );

long DrawScreenLayoutString( DBID layoutID, short stringIndex ) =
	CallDispatchedFunction( kDrawScreenLayoutString );

long BoxScreenLayoutString( DBID layoutID, short stringIndex, short rectIndex, short justify ) =
	CallDispatchedFunction( kBoxScreenLayoutString );

//
// Utility functions
//

long GetScreensEnteredCount( void ) =
	CallDispatchedFunction( kGetScreensEnteredCount );

#endif __Screens__
