/*
 *	$Id: ModemMisc.h,v 1.2 1995/05/11 22:57:22 jhsia Exp $
 *	
 *	$Log: ModemMisc.h,v $
 * Revision 1.2  1995/05/11  22:57:22  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		ModemMisc.h

	Contains:	xxx put contents here xxx

	Written by:	KON

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <4>	  7/7/94	KON		Remove unused constants.
		 <3>	  7/5/94	KON		Added kPeerToPeerGiveUpTicks which sets the amount of time the
									master tries to connect to the peer.
		 <2>	 6/20/94	BET		Add kRedialDelayTicks.
		 <1>	  6/9/94	KON		first checked in

	To Do:
*/


#ifndef __ModemMisc__
#define __ModemMisc__


Boolean IsRemoteModemTryingToConnect( void ) =
	CallDispatchedFunction( kIsRemoteModemTryingToConnect );
void SetRemoteModemTryingToConnectState( Boolean state ) =
	CallDispatchedFunction( kSetRemoteModemTryingToConnectState );


#endif __ModemMisc__
