/*
 *	$Id: SegaOs.h,v 1.2 1995/05/11 22:57:35 jhsia Exp $
 *	
 *	$Log: SegaOs.h,v $
 * Revision 1.2  1995/05/11  22:57:35  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		SegaOs.h

	Contains:	xxx put contents here xxx

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<14>	 8/19/94	ADS		Got rid of unused kOSVersion
		<13>	 8/13/94	HEC		Add WipeOSAndReset
		<12>	  8/7/94	ADS		Moved all the state reporting stuff to Exceptions.h
		<11>	  8/2/94	SAH		New gOSState flags when for when we wipe the os, database and
									Box ID globals.
		<10>	 7/15/94	dwh		unix-ise.
		 <9>	 6/28/94	SAH		Added os state flags.
		 <8>	 6/20/94	SAH		Added gameRestart flag to StartupSega.
		 <7>	 6/12/94	CMY		Make StartupSega return a flag indicating if the OS Heaps were
									rebuilt.
		 <6>	  6/3/94	SAH		Moved the remaining heap size stuff to OSGlobals.h
		 <5>	 5/30/94	SAH		Bump up kGlobalsCallStackSize to make sure we're ok.
		 <4>	 5/27/94	SAH		Changed the database heap size to free up some rooom.
		 <3>	 5/26/94	SAH		Changed allocations a little. Made them longs to fix sign
									extension problems.
		 <2>	 5/26/94	HEC		Changing heap allocations
		 <3>	 5/25/94	HEC		expanded data heap size temporarily
		 <2>	 5/17/94	SAH		Added #ifndef include crap.

	To Do:
*/


#ifndef __SegaOS__
#define __SegaOS__


#ifndef __Globals__
#include "Globals.h"
#endif

#ifndef __Debug__
#include "Debug.h"
#endif

#ifndef __OSManagers__
#include "OSManagers.h"
#endif

#ifndef __Dispatcher__
#include "Dispatcher.h"
#endif

#ifndef __SegaTypes__
#include "SegaTypes.h"
#endif

#ifndef __SegaErrors__
#include "SegaErrors.h"
#endif



/*
* os routines
*/

#ifndef	unix
Boolean	StartupSega( Boolean gameRestart );
void	RestartSega ( void );
Ptr		OSAllocMemTop( short size );
void	WipeOSAndReset( void );
#endif

#endif



