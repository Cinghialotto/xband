/*
 *	$Id: RoskoSegaPriv.h,v 1.2 1995/05/11 22:57:31 jhsia Exp $
 *	
 *	$Log: RoskoSegaPriv.h,v $
 * Revision 1.2  1995/05/11  22:57:31  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		RoskoSegaPriv.h

	Contains:	xxx put contents here xxx

	Written by:	

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	 8/13/94	JOE		first checked in
	To Do:
*/



#ifndef __RoskoSegaPriv__
#define __RoskoSegaPriv__

typedef struct RoskoSegaGlobals
{
	char			*theHBLHandler;
	unsigned long	oldLevel4Vector;
} RoskoSegaGlobals;



#ifdef SIMULATOR
#define	MANAGERGLOBALTYPE	RoskoSegaGlobals
#else
extern RoskoSegaGlobals RSglobs;
#endif


#endif

