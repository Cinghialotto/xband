/*
 *	$Id: heaps.h,v 1.2 1995/05/11 22:57:42 jhsia Exp $
 *	
 *	$Log: heaps.h,v $
 * Revision 1.2  1995/05/11  22:57:42  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		heaps.h

	Contains:	Memory Manager stuff

	Written by:	Shannon Holland

	Copyright:	� 1994 by Apple Computer, Inc., all rights reserved.

	Change History (most recent first):

		 <8>	 8/26/94	JBH		Added routines to facilitate fast heap relocation, so the
									database can be unstable for a minimum of time.
		 <7>	 8/16/94	JBH		Converted NewTempMemHigh to NewMemoryHigh, so we can allocate
									things high in perm heaps too.
		 <6>	  8/1/94	CMY		Added NewTempMemHigh -- allocates memory from the top of the
									temp heap.
		 <5>	 6/30/94	SAH		Added PurgePermHeaps.
		 <4>	 6/10/94	SAH		Added VerifySegaHeap.
		 <3>	 5/26/94	SAH		Added GetHeapSize.
		 <2>	 5/25/94	DJ		#ifdef for __SERVER__ (different stubs than game has)
		 <6>	 5/25/94	HEC		fixing bug
		 <5>	 5/25/94	HEC		Adding WhichMemory call
		 <4>	 5/24/94	SAH		Added kTemp and kPerm for Constantine.
		 <3>	 5/18/94	KON		Put #ifndefs around all includes.
		 <2>	 5/18/94	BET		Add #include "MessDisp.h"

	To Do:
*/


#ifndef __Heaps__
#define __Heaps__


#ifdef __SERVER__

#define DisposeMemory(p) DisposePtr((Ptr)p)
#define NewMemory(perm,size) ((Ptr)NewPtr(size))
#define NewMemoryClear(perm,size) ((Ptr)NewPtrClear(size))

#else




#ifndef __SegaOS__
#include "SegaOS.h"
#endif __SegaOS__

#ifndef __MessDisp__
#include "MessDisp.h"
#endif __MessDisp__

/*
* our public interfaces
*/


typedef	long * PubHeap;
typedef short (*CompactProcPtr) ( Ptr oldBlockPtr, Ptr newBlockPtr, long blockSize );


/*
* Some equates
*/
enum
{
	kTemp,			/* allocate memory in temporary heap */
	kPerm			/* allocate memory in permanent heap */
};

/*
* WhichMemory return codes
*/
enum
{
	kROMAddress = -1,		/* Address in ROM */
	kUnknownAddress = 0,	/* Don't know where pointer points */
	kTempAddress = 1,		/* Address in temp memory (64K DRAM) */
	kPermAddress = 2		/* Address in perm memory (64K SRAM) */
};

/*
* Dispose a block in any heap
*/
void	DisposeMemory ( void *p ) =
	CallDispatchedFunction( kDisposeMemory );

/* 
* Allocate a block out of the current permanent or temp heap
*/
void *	NewMemory ( short perm, long size ) =
	CallDispatchedFunction( kNewMemory );

/* 
* Allocate a block out of temp heap at the high end of memory
*/
void *	NewMemoryHigh ( short perm, long size ) =
	CallDispatchedFunction( kNewMemoryHigh );

/* 
* Get the size of a block
*/
long	GetMemorySize ( void *p ) =
	CallDispatchedFunction( kGetMemorySize );

/*
* Allocate memory and then clear it
*/
void *	NewMemoryClear ( short perm, long size ) =
	CallDispatchedFunction( kNewMemoryClear );

/*
* Return the maximum block size that can currently be allocated
*/
long	MaxFreeMemory (  short perm ) =
	CallDispatchedFunction( kMaxFreeMemory );

/*
* Return the maximum block size if the heap were to be compacted
*/
long	TotalFreeMemory ( short perm ) =
	CallDispatchedFunction( kTotalFreeMemory );

/*
* Return the internal size of a heap (ie allocatable area)
*/
long	GetHeapSize ( short perm ) =
	CallDispatchedFunction( kGetHeapSize );

/*
* Return the maximum block size if the heap were to be compacted
*/
long	WhichMemory ( void *p ) =
	CallDispatchedFunction( kWhichMemory );

/*
* Create a heap at a given address. "heap" must be a full heap header. this is
* designed to be used with heap headers created by AllocPermHeapZone.
*/
void	InitHeap( PubHeap heap, void *start, long length ) =
	CallDispatchedFunction( kInitHeap );

/*
* Compact a heap. compactProc is called for every allocated block moved
*/
short	CompactHeap ( PubHeap heap, CompactProcPtr compactProc ) = 
	CallDispatchedFunction( kCompactHeap );
	
/*
* Move a heap. compactProc is called for every allocated block moved. Be
* careful about moving it over allocated memory - it doesn't check.
*/
short	MoveHeap ( PubHeap heap, Ptr newBase, CompactProcPtr compactProc ) =
	CallDispatchedFunction( kMoveHeap );

long	PrepareHeapForMove ( PubHeap sourceHeap, PubHeap destHeap, Ptr *sourcePtr, Ptr *destPtr ) =
	CallDispatchedFunction( kPrepareHeapForMove );

long	ComputeHeapPtrDelta( PubHeap sourceHeap, PubHeap destHeap ) = 
	CallDispatchedFunction( kComputeHeapPtrDelta );

/*
* Resize a heap. compactProc is called for every allocated block moved. It calls
* CompactHeap first. It will return an error if there is not enough free space to
* shrink a heap.
*/
short	ResizeHeap ( PubHeap heap, long newSize, CompactProcPtr compactProc ) =
	CallDispatchedFunction( kResizeHeap );

/*
* Switch the permanent heap to newPerm. Returns the old perm heap so it can be
* restored.
*/
PubHeap	SwitchPermHeap ( PubHeap newPerm ) =
	CallDispatchedFunction( kSwitchPermHeap );

/*
* Switch the temp heap to newPerm. Returns the old temp heap so it can be
* restored.
*/
PubHeap	SwitchTempHeap ( PubHeap newTemp ) =
	CallDispatchedFunction( kSwtichTempHeap );

/*
* takes dram and turns it into a heap.
*/
PubHeap	CreateTempHeap ( void *start, long length ) =
	CallDispatchedFunction( kCreateTempHeap );

/*
* takes a pointer to a chunk of memory, allocates a heap header at the top and a heap
* after. if you move the heap later make sure to not move it over the header.
*/
PubHeap	CreateHeapFromPtr ( Ptr start, long length ) =
	CallDispatchedFunction( kCreateHeapFromPtr );

/*
* Allocate a block in the current temporary heap that will hold another heap of length
* bytes. This new heap will be suitable for SwitchTempHeap.
*/
PubHeap CreateTempSubHeap ( long length ) =
	CallDispatchedFunction( kCreateTempSubHeap );

/*
* Allocates one of the eight permanent memory heap headers. be careful. It calls
* SetOSUnstable ( true ). You are responsible for calling SetOSUnstable ( false ) at
* the right time.
*/
PubHeap	AllocPermHeapZone ( void ) =
	CallDispatchedFunction( kAllocPermHeapZone );

/*
* Dispose of a previously allocated permament heap header. you should probably do the
* SetOSUnstable thing around this one.
*/
short	DisposePermHeapZone ( PubHeap heap ) =
	CallDispatchedFunction( kDisposePermHeapZone );

/*
* the old standard
*/
void	SegaBlockMove ( Ptr src, Ptr dst, long length ) =
	CallDispatchedFunction( kBlockMove );

/*
* Memory allocation in a heap failed, purge whatever we can to save the world!
*/
void *	PurgePermHeaps ( short perm, long size ) =
	CallDispatchedFunction( kPurgePermHeaps );

/*
* Verify a heap is at least structurally valid. Returns false if bad.
*/
Boolean	VerifySegaHeap ( PubHeap heap ) =
	CallDispatchedFunction( kVerifySegaHeap );


#endif __SERVER__

#endif __Heaps__

