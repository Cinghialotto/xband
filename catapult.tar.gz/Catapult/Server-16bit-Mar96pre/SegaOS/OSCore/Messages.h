/*
 * Copyright: � 1995 Catapult Entertainment Inc., all rights reserved
 *
 * $Id: Messages.h,v 1.8 1995/11/08 18:33:46 jhsia Exp $
 *	
 * $Log: Messages.h,v $
 * Revision 1.8  1995/11/08  18:33:46  jhsia
 * Added safe smartcard debit message (sj01). (fadden)
 *
 * Revision 1.7  1995/05/11  22:57:21  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Messages.h

	Contains:	xxx put contents here xxx

	Written by:	Konstantin Othmer

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<67>	12/14/94	HEC		Added Andy1's misclogin flags. Made #defines.
		<66>	11/19/94	HEC		Added kFAXMachineDetected login bit.
		<65>	 8/27/94	KON		Bump to segB for new outgoing mail format.
		<64>	 8/27/94	HEC		Bumped rom version from 8 to 9.
		<63>	 8/25/94	BET		Add multiple NetErrorRecords for X25 and 800.
		<62>	 8/25/94	KON		Add message for deleting DBTypes and message for calling misc
									box functions.
		<61>	 8/25/94	ATM		Updated to seg7 for f2 ROMs.
		<60>	 8/22/94	ADS		Add hidden box serial # calls
		<59>	 8/21/94	DJ		added "password" protect to boxwipemind
		<58>	 8/21/94	DJ		messages for box restoring (setcurrentusernumber and
									boxwipemind)
		<57>	 8/21/94	KON		Add names for login flags.
		<56>	 8/20/94	ADS		More patch downloading cleanup
		<55>	 8/19/94	DJ		new version to support addr book update for current user only
		<54>	 8/19/94	ADS		msSystemVersion really means msOSPatchVersion
		<53>	 8/16/94	JBH		Even newer ROM version (seg4), which uses an extra longword in
									msLogin message
		<52>	 8/15/94	DJ		new rom version (seg3)
		<51>	 8/15/94	JBH		Added constants to describe the first longword after msLogin
		<50>	 8/15/94	KON		Add message to set date and time.
		<49>	 8/13/94	DJ		made it easier to maintain that number
		<48>	 8/13/94	BET		added to numsendmsgs to 40
		<47>	 8/13/94	BET		Update kSegaIdentification.
		<46>	 8/13/94	BET		Try that again
		<45>	 8/13/94	BET		Add msSendNetErrors
		<44>	 8/12/94	DJ		Updated kSegaIdentification to indicate new ROM version
									(8/12/94)
		<43>	 8/12/94	BET		Added dial script updaters
		<42>	 8/12/94	HEC		added DoLiveSmartCardDebit.
		<41>	 8/11/94	JOE		Update for box<->server personification exchanges (only send
									stuff that's changed)
		<40>	  8/5/94	DJ		address book: msDeleteUncorrelatedAddressBookEntries,
									msCorrelateAddressBookEntry
		<39>	  8/4/94	JOE		Added DoReceivePersValidation message, nuked old Peer-Peer
									Personification exchange messages
		<38>	  8/4/94	SAH		New game error messages.
		<37>	  8/1/94	KON		Remove a bunch of stale messages.
		<36>	 7/31/94	KON		Removed deleting writeable strings.
		<35>	 7/27/94	HEC		Added DoReceiveProblemToken and DoReceiveValidationToken.
		<34>	 7/21/94	JBH		Added GetConstant messages.
		<33>	 7/20/94	ADS		Kill LoadCPE/msInstall for good.  Dead.
		<32>	 7/19/94	DJ		added msSendGameResults
		<31>	 7/19/94	DJ		added msSetCurrentUserName and msSetBoxHometown
		<30>	 7/17/94	DJ		added msSendCreditDebitInfo and msSendBoxType
		<29>	 7/17/94	HEC		Added msSendCreditToken and msReceiveCreditTokenOpcode.
		<28>	 7/17/94	HEC		Added  DoSendDebitCardOpCode proto.
		<27>	 7/17/94	JOE		Added receivers for Credit and Restrictions server messages.
		<26>	 7/17/94	KON		Added msDebitCard something or other for Ted.
		<25>	 7/17/94	JBH		Moved thank-you strings into writeable strings.
		<24>	 7/16/94	JBH		Fixed memory crasher - didn't allocate enough table entries.
									Ugh!
		<23>	 7/16/94	JBH		Added thank-you string messages.
		<22>	 7/15/94	DJ		added kSegaIdentification (a long to id that this is a sega)
		<21>	 7/14/94	CMY		Add message to send outgoing mail
		<20>	 7/12/94	JOE		add server personification msgs
		<19>	 7/11/94	KON		Remove competative message (we always use challenge now) and add
									NetRegister message.
		<18>	 7/10/94	HEC		Added msSetConstants
		<17>	  7/8/94	DJ		added DoSetBoxPhoneNumber and DoSetLocalAccessPhoneNumber
		<16>	  7/8/94	JOE		added Rankings messages
		<15>	  7/5/94	DJ		moved addr book validation into a single message,
									DoSendAddressesToVerifyOpCode
		<14>	  7/5/94	CMY		Messages to handle address book entries.
		<13>	  7/2/94	DJ		removed msUnsupportedGame
		<12>	  7/2/94	DJ		added msQDefDialog
		<11>	 6/12/94	DJ		added DoReceivePeerEndOfStream
		<10>	 6/10/94	DJ		added msUnsupportedGame so the server can notify box if game is
									unsupported.
		 <9>	  6/4/94	DJ		added msEndStream handler (changed intro.c to deal with it)
		 <8>	  6/4/94	DJ		fixes for #ifndef SERVER
		 <7>	  6/4/94	KON		Renumbered peer-to-peer messages to be in the 1 to 10 range.
									This changed all outgoing messages to be 10 higher than before.
									Sorry, Dave!
		 <6>	  6/2/94	BET		News
		 <5>	 5/31/94	DJ		added DoReceiveMail and msReceiveMail
		 <4>	 5/27/94	DJ		added opponent handling routines (wait and receive phone number)
		 <3>	 5/26/94	DJ		added LoopBack for network debugging
		 <2>	 5/25/94	DJ		moved messOut around SERVER #ifdef cuz server needs that defn
		 <6>	 5/25/94	KON		Turn session model into a single page version, very similar to
									PICT. Can now receive and playback streams under server control
									during connect, and viewing under user control other times.
		 <5>	 5/25/94	KON		Added capture session and capture stream opcodes. We may want to
									back these out. They are not added to MessDisp.c yet, and they
									haven't been tested.
		 <4>	 5/23/94	DJ		ifdefed out routines and includes if the server is using this .h
									file.  Note that server and sega share Messages.h
		 <3>	 5/12/94	KON		Removed send and flush results messages since those are handled
									by the send Q now.
		 <2>	 5/12/94	KON		Added remote control over database. Added support for send Q.

	To Do:
*/

#ifndef __Messages__
#define __Messages__

#ifndef __SERVER__		// Server doesn't include any function protos.

#ifndef __DataBase__
#include "DataBase.h"
#endif

#endif __SERVER


#ifndef __MessDisp__
#include "MessDisp.h"
#endif

//
// bit flags for login message flags long
//
#define kCurUserAcceptsChallenges		0x01
#define kCurUserMoved					0x02
#define kOSHeapTrashed					0x04
#define kDBHeapTrashed					0x08
#define kBoxIDTrashed					0x10
#define kQwertyKeyboard					0x20		/* NOT USED IN SEGA ROM 1.0 */
#define kCallWaitingEnabled				0x40		/* NOT USED IN SEGA ROM 1.0 */
#define kPatchWasSplit					0x80		/* SEGA ROM 1.1 */
#define kFAXMachineDetected				0x100		/* SEGA ROM 1.1 */

//
// bit flags for the serverMiscControl message long
//
#define kClearNetErrorsFlag				0x01
#define kDeleteSendQFlag				0x02
#define kDeleteAllAoutBoxMailFlag		0x04
#define kMarkAddressBookUnchangedFlag	0x08
#define kClearGameResultsFlag			0x10
#define kClearBANDWIDTHControlsFlag		0x20		/* new for SNES */
#define kClearXBANDNewsControlsFlag		0x40		/* new for SNES */
#define kClearPeerLogFlag				0x80		/* new for SNES */

//
// bit flags for the DoBoxWipeMide message long
//
#define kSetOSUnstableFlag				0x01
#define kSetOSStableFlag				0x02
#define kSetDBUnstableFlag				0x04
#define kSetDBStableFlag				0x08

typedef	unsigned char	messOut;
#define msOutgoingOpCodeSize	sizeof( messOut )


// This is sent to the server to identify the box as a sega msBoxType.  this will be useful
// when we support snes or newer versions of our sega box.
//
// Here is the list of old ROM versions:
//
//  #define kSegaIdentification	((long)'sega')		/* 8/11/94	*/
//

//#define kSegaIdentification	((long)'seg1')		/* 8/12/94.  added personification send/recv */
//#define kSegaIdentification	((long)'seg2')		/* 8/13/94.  added NetError returns */
//#define kSegaIdentification	((long)'seg3')		/* 8/15/94.  added setDateAndTime */
//#define kSegaIdentification	((long)'seg4')		/* 8/16/94.  added long of memory info to msLogin */
//#define kSegaIdentification	((long)'seg5')		/* 8/19/94.  update addr book only for current user */
//#define kSegaIdentification	((long)'seg6')		/* 8/20/94.  long flags in login, fallback access phone number */
//#define kSegaIdentification	((long)'seg7')		/* 8/25/94.  update for F2 build */
//#define kSegaIdentification	((long)'seg8')			/* 8/25/94.  F2 is done, long live F2 */
//#define kSegaIdentification	((long)'seg9')			/* 8/27/94.  F6! bigger smartcard struct */
//#define kSegaIdentification	((long)'segb')			/* 8/27/94.  outgoing mail is now sent with local box user ID */

//
// outgoing messages - peer: reserve messages from 1 to kNumPeerOpCodeItems
// incoming peer messages are symetrical and use the same numbers, of course
//
// NEVER want to allow code to be sent peer-to-peer, so the receive dispatch uses
// a separate table from server messages!!
//
#define kNumPeerOpCodeItems			10	/* MessDisp.c needs this to allocate dispatch tables */

// Don't have more than kNumPeerOpCodeItems (you can make kNumPeerOpCodeItems bigger if you want).
//
#define msPeerEndOfStream			2	/* shared with msEndOfStream (see below) */


//
// outgoing messages - sent to server
//

#define msLogin						kNumPeerOpCodeItems+1
#define msGameIDAndPatchVersion		kNumPeerOpCodeItems+2
#define msDoSendNewsControls		kNumPeerOpCodeItems+3
#define msChallengeRequest			kNumPeerOpCodeItems+4
#define msSystemVersion				kNumPeerOpCodeItems+5		/* this is for the rom patch version	*/
#define msSendNGPVersion			kNumPeerOpCodeItems+6

#define	msDBIDInfo					kNumPeerOpCodeItems+7
#define	msSendItemFromDB			kNumPeerOpCodeItems+8
#define	msSendFirstItemID			kNumPeerOpCodeItems+9
#define	msSendNextItemID			kNumPeerOpCodeItems+10

#define	msSendSendQElements			kNumPeerOpCodeItems+11
#define	msSendAddressesToVerify		kNumPeerOpCodeItems+12

#define	msSendNumRankings			kNumPeerOpCodeItems+13
#define	msSendFirstRankingID		kNumPeerOpCodeItems+14
#define	msSendNextRankingID			kNumPeerOpCodeItems+15
#define msSendRankingData			kNumPeerOpCodeItems+16

#define	msSendInvalidPers			kNumPeerOpCodeItems+17
#define msSendInterestingDBConstants	kNumPeerOpCodeItems+18
#define msSendOutgoingMail			kNumPeerOpCodeItems+19
#define msSendCreditDebitInfo		kNumPeerOpCodeItems+20

#define msBoxType					kNumPeerOpCodeItems+21
#define msSendGameResults			kNumPeerOpCodeItems+22	/* DoSendGameResults handles both these sendmsg types */
#define msSendNoGameResults			kNumPeerOpCodeItems+23	/* DoSendGameResults handles both these sendmsg types */

#define	msSendConstant				kNumPeerOpCodeItems+24

#define msSendGameErrorResults		kNumPeerOpCodeItems+25	/* DoSendGameErrorResults handles both these sendmsg types */
#define msSendNoGameErrorResults	kNumPeerOpCodeItems+26	/* DoSendGameErrorResults handles both these sendmsg types */

#define msSendNetErrors				kNumPeerOpCodeItems+27	/* DoSendNetErrors handles both these sendmsg types */
#define msNoNetErrors				kNumPeerOpCodeItems+28	/* DoSendNetErrors handles both these sendmsg types */

#define msSendHiddenSerials			kNumPeerOpCodeItems+29

// New Sega stuff (also present on SNES).
//
#define msSendBoxMemStats			kNumPeerOpCodeItems+30

#define msSendBoxLogs				kNumPeerOpCodeItems+31

// *
// * You MUST update this if you add more outgoing messages to the server.
// *
#define kNumSendOpCodeItems			kNumPeerOpCodeItems+35	/* MessDisp.c needs this to allocate dispatch tables */




//
// incoming server messages
//

#define kNumReceiveOpCodeItems			255		/* MessDisp.c needs this to allocate dispatch tables */

#define	msNewMessageHandler 			1
#define msEndOfStream					msPeerEndOfStream	/* == 2 */
#define	msGamePatch 					3
#define	msSetDateAndTime 				4
#define	msServerMiscControl 			5


#define msExecuteCode					9
#define msPatchOSCode					10

#define msRemoveDBTypeOpCode			12
#define	msRemoveMessageHandler			13
#define msRegisterPlayer				14
#define	msNewNGPList					15
#define	msSetBoxSerialNumber			16
#define	msGetTypeIDsFromDB				17
#define	msAddItemToDB					18
#define	msDeleteItemFromDB				19
#define	msGetItemFromDB					20
#define	msGetFirstItemIDFromDB			21
#define	msGetNextItemIDFromDB			22
#define	msClearSendQ					23

#define msLoopBack						27		/* debug the network */
#define msWaitForOpponent				28
#define msOpponentPhoneNumber			29
#define msReceiveMail					30
#define msNewsHeader					31
#define msNewsPage						32
#define msUNUSED1						33		/* was msInstaller */
#define msQDefDialog					34
#define msAddAddressBookEntry			35
#define msDeleteAddressBookEntry		36

#define msReceiveRanking				37
#define	msDeleteRanking					38
#define	msGetNumRankings				39
#define	msGetFirstRankingID				40
#define	msGetNextRankingID				41
#define	msGetRankingData				42

#define	msSetBoxPhoneNumber				43
#define	msSetLocalAccessPhoneNumber		44
#define msSetConstants					45

#define	msReceiveValidPers				46
#define	msGetInvalidPers				47

#define msDeleteUncorrelatedAddressBookEntries	48
#define msCorrelateAddressBookEntry		49

#define	msReceiveWriteableString		50

#define	msReceiveCredit					51
#define	msReceiveRestrictions			52
#define msReceiveCreditToken			53

#define msSetCurrentUserName			54
#define msSetBoxHometown				56

#define	msGetConstant					57
#define	msReceiveProblemToken			58
#define	msReceiveValidationToken		59

#define	msLiveDebitSmartCard			60
#define msSendDialScript				61

#define msSetCurrentUserNumber			62
#define msBoxWipeMind					63
#define msGetHiddenSerials				64

// New Sega messages, also present on SNES
#define msGetLoadedGameInfo				66
#define msClearNetOpponent				67
#define msGetBoxMemStats				68
#define msReceiveRentalSerialNumber		69
#define msReceiveNewsIndex				70
#define msReceieveBoxNastyLong			71

#define msSomethingOrOtherOnSj01		72
#define msSafeSmartCardDebit			73



//
// There are no handlers for these messages.
//
#define kOneByteOpCodeRangeEnd 			250	/* used in GetSerialOpCode() in case we ever goto 2-byte opcodes */

#define kOneByteEscapeOpCode1			250	/* these are unused (i think) -dj */
#define kOneByteEscapeOpCode2			251
#define kOneByteEscapeOpCode3 			252
#define kOneByteEscapeOpCode4 			253
#define kOneByteEscapeOpCode5 			254
#define kOneByteEscapeOpCode6 			255


// These are read by DoBoxWipeMind before wiping just to be extra
// paranoidly sure that the message isn't accidentally getting triggered.
//
#define kBoxWipeMindPassword1	0x12345678L
#define kBoxWipeMindPassword2	0x9abcdef0L
#define kBoxWipeMindPassword3	0x1234567aL
#define kBoxWipeMindPassword4	0xbcdef012L



#ifndef __SERVER__		// Server doesn't include any function protos.


typedef void (*messageCodeProcPtr)(void);					//opcodes take a void and return a short

//  this is the "installer" which is the first half of a downloaded patch
typedef MessErr (*installerCodeProcPtr)(long dataLength, Ptr OSPatchData );


//
// Eats bytes from the connection.  Used in error situations.
//	eg. if a message handler couldn't malloc space for the message (eg. DoReceiveNewsPage).
//
MessErr GobbleMessage(long size);

//
// Received Server Messages
//
MessErr	DoReceiveEndOfStream(void);	// returns kStreamDone when activated.

MessErr DoNewMessageOpCode( void );
MessErr DoGamePatchMessageOpCode( void );
MessErr DoSetDateAndTimeOpCode( void );

MessErr DoExecuteCodeMessageOpCode( void );
MessErr DoPatchOSMessageOpCode( void );

MessErr DoRemoveDBTypeMessageOpCode( void );
MessErr DoRemoveMessageHandlerOpCode( void );
MessErr	DoRegisterPlayerMessageOpCode( void );
MessErr DoNewNGPListOpCode( void );
MessErr DoSetBoxSerialNumber( void );
MessErr DoGetTypeIDsFromDB( void );
MessErr DoAddItemToDB( void );
MessErr DoDeleteItemFromDB( void );
MessErr DoGetItemFromDB( void );
MessErr DoGetFirstItemIDFromDB( void );
MessErr DoGetNextItemIDFromDB( void );
MessErr DoClearSendQOpCode( void );

MessErr DoLoopBack(void);

MessErr DoWaitForOpponentOpCode(void);
MessErr DoReceiveOpponentPhoneNumber(void);
MessErr	DoReceiveMail(void);
MessErr DoReceiveNewsPage(void);
MessErr	DoReceiveNewsHeader(void);
MessErr	DoReceiveUnsupportedGame(void);
MessErr DoReceiveQDefDialog(void);
MessErr DoReceiveAddressBookEntry(void);
MessErr DoReceiveAddressBookEntryToDelete(void);
MessErr DoDeleteUncorrelatedAddressBookEntries(void);
MessErr DoCorrelateAddressBookEntry(void);

MessErr DoReceiveRanking(void);
MessErr DoDeleteRanking(void);
MessErr DoGetNumRankings(void);
MessErr DoGetFirstRankingID(void);
MessErr DoGetNextRankingID(void);
MessErr DoGetRankingData(void);

MessErr DoSetBoxPhoneNumber(void);
MessErr DoSetLocalAccessPhoneNumber(void);
MessErr DoReceiveConstants(void);

MessErr DoReceiveValidatedPersonification(void);
MessErr DoGetInvalidatedPersonification(void);

MessErr	DoReceiveWriteableString(void);

MessErr	DoReceiveCredit(void);
MessErr	DoReceiveCreditToken(void);
MessErr	DoReceiveProblemToken(void);
MessErr	DoReceiveValidationToken(void);
MessErr	DoReceiveRestrictions(void);
MessErr DoServerMiscControl(void);

MessErr DoSetCurrentUserName( void );
MessErr DoSetBoxHometown( void );

MessErr	DoGetConstant( void );
MessErr DoLiveSmartCardDebit( void );
MessErr DoRecieveDialScript(void);

// These are for restoring the box state after a crash
//
MessErr	DoSetCurrentUserNumber( void );	// 0 thru 3
MessErr DoBoxWipeMind( void );
MessErr DoGetHiddenSerials( void );


//
// Send and matching Received Peer Messages
//
MessErr DoReceivePeerEndOfStream(void);

//
// Send Messages
// MessErr is always returned as zero for send messages!
//
void DoSendEndOfStream( void *notUsed );
void DoSendBoxTypeOpCode( void * notUsed );
void DoSendLoginMessageOpCode( void * notUsed );
void DoGameIDAndPatchVersionOpCode( void * notUsed );
void DoSendChallengeOpCode( void * notUsed );
void DoSendPatchVersionOpCode( void * notUsed );		// msSystemVersion

void DoSendNGPVersionOpCode( void * notUsed );
void DoSendDBIDsOpCode( void * type );
void DoGetItemFromDBOpCode( void * typeIDPair );
void DoGetFirstItemIDFromDBOpCode( void * type );
void DoGetNextItemIDFromDBOpCode( void * typeIDPair );
void DoSendSendQElementsOpCode( void * notUsed );
void DoSendAddressesToVerifyOpCode( void * notUsed );

void DoSendNumRankingsOpCode( void * notUsed );
void DoSendFirstRankingIDOpCode( void * notUsed );
void DoSendNextRankingIDOpCode( void * prevID );
void DoSendRankingDataOpCode( void * theID );

void DoSendInvalidatedPersonificationOpCode( void * unused );

void DoSendOutgoingMail( void * notUsed );
void DoSendCreditDebitInfoOpCode( void *card );
void DoSendGameResults( void *notUsed );
void DoSendGameErrorResults( void *notUsed );
void DoSendConstant( void * constantID );
void DoSendNetErrors( void *notUsed );
void DoSendHiddenSerials( void *notUsed );

#endif __SERVER__
#endif __Messages__

