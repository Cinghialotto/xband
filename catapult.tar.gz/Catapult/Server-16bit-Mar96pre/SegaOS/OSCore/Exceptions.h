/*
 *	$Id: Exceptions.h,v 1.2 1995/05/11 22:57:15 jhsia Exp $
 *	
 *	$Log: Exceptions.h,v $
 * Revision 1.2  1995/05/11  22:57:15  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Exceptions.h

	Contains:	Stuff for the 68000 exception vectors

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<16>	 8/29/94	ADS		More OSState flags, save the boxstate too
		<15>	 8/24/94	ADS		Added two more, for the interrupts
		<14>	 8/24/94	ADS		Lots more restart info
		<13>	 8/22/94	ADS		Stack sniffer
		<12>	 8/18/94	ADS		Added bit for invalid box globals
		<11>	 8/17/94	ADS		Need dispatchercontrol to get necessary #defines
		<10>	 8/14/94	ADS		Added new "long" stack frames for addr err vector
		 <9>	  8/9/94	ADS		Dispatcher tracing lives here now
		 <8>	  8/7/94	ADS		All new box restart reporting stuff
		 <7>	  8/5/94	SAH		Added the game talk vbl.
		 <6>	 7/31/94	SAH		Added VBLTimer.
		 <5>	 7/27/94	SAH		Flashy.
		 <4>	 7/26/94	SAH		New restart semaphore.
		 <3>	 7/26/94	CMY		Stop making my compiles so damn slow!
		 <2>	 7/24/94	HEC		Define VBLRec and associate routines to control vbl task.
		 <1>	 5/12/94	SAH		first checked in

	To Do:
*/

#ifndef _EXCEPTIONS_H
#define _EXCEPTIONS_H

#ifndef __SegaTypes__
#include "SegaTypes.h"
#endif

#ifndef __DISPATCHERCONTROL__
#include "DispatcherControl.h"
#endif


void	SetExceptionVectors ( void );
void	VBLTimer ( void );
void	GameTalkVBL ( void );



//---------------------------------
//	Box restart shit
//---------------------------------

#ifdef DISP_CALL_LOG
	#define	kHistorySize	(8)			// MUST be 2^n
#endif


typedef struct	{					// there's room for 48 longs, change globals.h if longer!
	unsigned long	registers[16];	// these values are filled up by an exception handler
	
	unsigned short	excMode;		// the first 3 fields are only on Addr/Bus errors
	unsigned long	excAddr;
	unsigned short	excInstrReg;
	unsigned short	excSR;			// SR and PC are saved for all exceptions
	unsigned long	excPC;
	unsigned short	excCode;		// set at crash time
	
			 long	unstablePC;		// last PC who set OSUnstable
	unsigned long	startupFlags;	// set by the startup code
	
#ifdef DISP_CALL_LOG	
	short	histCallNums[kHistorySize];
	long	histCallers[kHistorySize];
	short	prevEntry;
#endif
	short	osState;				// set by various routines

	BoxSerialNumber	setBoxID;		// the one set by _SetBoxSerialNumber
	BoxSerialNumber	coldBoxID;		// boxID at cold boot time
	BoxSerialNumber	warmBoxID;		// boxID at end of StartupSega
	
	unsigned long	stackLowWater;	// deepest stack depth
	
	long			boxState;		// copies of same from BoxSer
	long			lastBoxState;

	
} BoxRestartInfo;

enum	{
	kMachineDead		=   0x001,		// bit fields for "restartFlags"
	kDataDead			=   0x002,
	kGameHeapDead		=   0x004,
	kResetting			=   0x008,
	kResetWhileUnstable =   0x010,
	kGameRestart		=   0x020,
	kOSUnstable			=   0x040,
	kDataBaseUnstable	=   0x080,
	kMadeOSUnstable		=   0x100,
	kBadBoxID			=   0x200,
	kBadEarlyRamTest	=   0x400,
	kBadLowVectors		=   0x800,
	kOSUnstableAtHpCk	=  0x1000,
	kOSUnreliableAtHpCk	=  0x2000,
	kOSHeapNonVerify	=  0x4000,
	kDBDBNonVerify		=  0x8000,
	kDBHeapCollide		= 0x10000,
	kDBHeapUnstable		= 0x20000,
	kDBHeapNonVerify	= 0x40000

};

										// which conditions cause upload of restart block
#define kUploadRestartConditions						\
	(kMachineDead + kDataDead + kResetWhileUnstable		\
	+ kOSUnstable + kDataBaseUnstable + kMadeOSUnstable + kBadBoxID)
	

enum	{						// exception codes from restarts
	kBusError			=	1,					// handling a bus error
	kIllegal			=	2,					// an illegal instruction was hit
	kZeroDivide			=	3,					// zero divide
	kChkException		=	4,				// any other exception handler
	kTrapVException		=	5,
	kPrivException		=	6,
	kTraceException		=	7,
	kLineFException		=	8,
	kBadIRQException	=	9,
	kExtIRQException	=  10,
	kHorIRQException	=  11,
	kOddIRQException	=  12,
	kOtherException		=  13
};


enum	{						// bit fields for "osstate"
	kAllocMemory		=    0x1,					// system is allocating memory
	kHeapError			=    0x2,					// a heap was bad
	kMemFull			=    0x4,					// a heap was full
	kForceReset			=    0x8,					// user forced a system reset
	kOSBooting			=   0x10,					// the os was booting
	kWipedBoxID			=   0x20,				// wiped the box id globals
	kPurgeRestart		=   0x40,
	kStackUnderflow		=   0x80,				// stack got too small!
	kEarlyRamCk			=  0x100,
	kTooManyBoots		=  0x200,
	kBadBootVector		=  0x400
};

#define	SETOSSTATE(x)			( gBoxRestart->osState |= (x) )






//---------------------------------
//	simulator-only  shit
//---------------------------------

#if defined(SIMULATOR) || defined(__SERVER__)
#include <OSUtils.h>
#include <Retrace.h>

typedef struct {
	VBLTask task;
	long vbla5;
	Boolean installed;
} VBLRec;
extern VBLRec vblTask;

extern	short	gRestartSemaphore;

enum
{
	kGameTalkTask,
	kPUReadTimeTask,
	kPUWriteTimeTask
};

void	StopVBLTask ( void );	// only for SIMULATOR or SERVER
void	StartVBLTask(void);		// only for SIMULATOR or SERVER
void	FlagTimeTask ( short task );
#endif




#endif		// _EXCEPTIONS_H

