/*
 *	$Id: Globals.h,v 1.2 1995/05/11 22:57:16 jhsia Exp $
 *	
 *	$Log: Globals.h,v $
 * Revision 1.2  1995/05/11  22:57:16  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Globals.h

	Contains:	Low memory layout

	Written by:	Shannon Holland & Andy Stadler

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<62>	 8/27/94	JBH		Changed gBootSuccessful to gBootAttempts, to allow a boot to be
									interrupted by a reset without mind loss.
		<61>	 8/25/94	BET		Add multiple NetErrorRecords for X25 and 800.
		<60>	 8/25/94	HEC		Remove dependency on debugselectors.h
		<59>	 8/22/94	ATM		Removed DebugSelectors.h from includes on server.
		<58>	 8/22/94	ADS		Restructured to allow all-page-zero operation
		<57>	 8/22/94	SAH		Added stinko params.
		<56>	 8/22/94	ADS		Add hidden box serial #
		<55>	 8/21/94	BET		Take over location 54 as modemDebug.
		<54>	 8/21/94	ADS		New lomem layout
		<53>	 8/19/94	ADS		Add new os patch stuff
		<52>	 8/18/94	HEC		Made this fucker compile. #including dispatcher and osmanagers.
		<51>	 8/18/94	ADS		Hide gBoxID globals
		<50>	 8/18/94	SAH		Turn off SMALLRAM for everyone else.
		<49>	 8/16/94	SGP		Reconciled with Harddefines.a.
		<48>	 8/14/94	ADS		Shuffled so dispatcher can have 2 longs
		<47>	 8/11/94	SAH		Added SMALLRAM #define for shrinking SRAM.
		<46>	 8/10/94	SAH		SRAM is 64K again.
		<45>	  8/9/94	HEC		Removed obsolete highmem globals (problemToken, etc.)
		<44>	  8/8/94	DJ		if serverized
		<43>	  8/7/94	ADS		New himem restart stuff
		<42>	  8/5/94	ADS		Removed db unstable type stuff completely
		<41>	  8/5/94	SAH		Added a game talk session global.
		<40>	  8/2/94	SAH		Added os version.
		<39>	 7/31/94	HEC		Added osEnabled bit flag in lowmem to tell if game or os is up.
		<38>	 7/31/94	SAH		Added the soundEnabled global.
		<37>	 7/29/94	JOE		made gVDPBusy unsigned
		<36>	 7/29/94	JOE		Added gVDPBusy
		<35>	 7/27/94	HEC		Added gSmartCardToken, gProblemToken, and gValidationToken to
									SegaHighMem.
		<34>	 7/22/94	DJ		cheesyness needed cuz it is hard to get MWerks to have a global
									#define
		<33>	 7/22/94	dwh		Think C unavailable on Sun platform - too bad.
		<32>	 7/22/94	SAH		New ticks.
		<31>	 7/15/94	dwh		unix-ise.
		<30>	 7/10/94	SAH		Don't include NetStructs.h anymore.
		<29>	  7/8/94	SAH		HACK for steve.
		<28>	  7/7/94	BET		Add net stats field to high mem.
		<27>	  7/5/94	SAH		Made some of the game patch vectors (game dispatcher and rom
									offset) real on the stimulator.
		<26>	  7/2/94	SAH		Killed a bunch of globals.
		<25>	  7/1/94	SAH		Added gBootSuccessful and some more debug vars.
		<24>	  7/1/94	SAH		Added more heap boundary pointers. Added an os boot vector.
		<23>	  7/1/94	ADS		Reshuffled lowmem, globalsStack in "real" lowmem
		<22>	 6/29/94	ADS		Fixing broken cast in gRamTest1
		<21>	 6/28/94	SAH		Killed LowLevel globals. Moved many globals up high. Created a
									protected high memory area for box serial number.
		<20>	 6/19/94	HEC		Added gRegisterBase low-level global
		<19>	 6/17/94	SAH		Added some nasty game patch lowmems.
		<18>	 6/17/94	KON		Lots of game score stuff.
		<17>	 6/16/94	SAH		New hardware register globals.
		<16>	 6/15/94	SAH		Added ram and rom offset globals for the new hardware. Also
									added a global that points at the hardware registers.
		<15>	 6/15/94	KON		Added Jesus time and date.
		<14>	 6/14/94	KON		Add last box state global.
		<13>	 6/14/94	KON		Added global for boxState.
		<12>	 6/14/94	SAH		Added a flag for new/old rosko cards.
		<11>	 6/12/94	SAH		Made the database globals real low mems and filled out the low
									mem structure.
		<10>	  6/9/94	KON		Added remote modem connect state.
		 <9>	  6/4/94	KON		Add box serial number global.
		 <8>	 5/28/94	SAH		Moved all the ROM/RAM/SRAM position globals to OSGlobals.h to
									save compile time.
		 <7>	 5/28/94	KON		Fixed the gRamTest2 variable for Mac.
		 <6>	 5/27/94	SAH		Fixed the gRamTest2 variable for sega.
		 <5>	 5/27/94	SAH		Added constants for dram size, temp heap size and stack size.
		 <4>	 5/27/94	SAH		Added kRomDatabase.
		 <3>	 5/26/94	HEC		Added kSRAMSize
		 <2>	 5/26/94	SAH		Added globals for database and temp heaps.
		 <4>	 5/25/94	SAH		Redefed gRomTop and gRomBottom for simulator build. Fixed
									gRomTop macro for sega build.
		 <3>	 5/25/94	HEC		Adding ROM addresses
		 <2>	 5/24/94	SAH		Made the low mems use a structure.

	To Do:
*/

#ifndef __Globals__
#define __Globals__


#ifndef __SegaTypes__
#include "SegaTypes.h"
#endif	//	__SegaTypes__

#ifndef	__SERVER__
#ifndef __Dispatcher__
#include "Dispatcher.h"
#endif
#ifndef __OSManagers__
#include "OSManagers.h"
#endif
#ifndef SIMULATOR
	#define FORCE_HARD_HERE	1
#endif
#endif /*!__SERVER__*/


// cheesyness needed cuz it is hard to get MWerks to have a global #define
#if !defined(__SERVER__) && defined(__MWERKS__)
#define __SERVER__
#endif


// these are the himem blocks.  We hide their actual structures from most
// of the world, so the only thing that matters is that we've reserved
// a big enough chunk for them.

typedef struct	{
	unsigned long	fake[48];
//	BoxRestartInfo	real;
} BoxRestartInfoReserved;

typedef struct	{
	unsigned long		fake[88];
//	BoxIdentification	real;
	BoxSerialNumber		hiddenSerial1;		// stored where nobody should touch it
} BoxIDReserved;



/*
* A bunch of nasty low mems for the os. make sure you need to be here before you use this space!
*
*/


#ifdef	SIMULATOR
#define	GETMGRGLOBALSOFFSET(name,offsetVar)	(offsetVar = 0)
#else
#define	GETMGRGLOBALSOFFSET(name,offsetVar)	{ \
											asm	{	lea			name,a0			} \
											asm	{	move.l		a5,d0			} \
											asm	{	sub.l		a0,d0			} \
											asm	{	move.l		d0,offset		} \
											}
#endif


/*
* general os constants
*/

#define	kRamTest1		0xDEADBEEF
#define	kRamTest2		0xBEEFFACE

//#define	SMALLRAM	1

#ifdef SMALLRAM
#define kSRAMSize		(56*1024L)
#else
#define kSRAMSize		(64*1024L)
#endif

/*
* General OS Low mems
*/

/*
	OS EXPAND GLOBALS
	
	These are for low level system globals that need to be in a fixed place in case the system
	goes down. they are for things like permanent memory heap ptrs. really important things have
	their own low-mem. the next level of important things goes here and then just general
	crap goes in the global table stuff below.
*/

/*  Be very careful when you manipulate these globals.  There are quite a number of
	restrictions and requirements, which are a nasty intersection of 68000, 68040,
	PowerPC, SegaOS, MacOS, and game runtime requirements.  I've tried to mark things
	as closely as possible, to give you some clues if you need to move them further.
	Each entry may be marked by one or more of the following codes:
	
		040		must be in this area so it can REALLY be in lomem on 040 machines
		PPC		reserved by PPC/emulator (so we can run simulator)
		LOW		must be anywhere in lomem
		FIX		must be at THAT address (cpu architecture)
		
	Please add more codes in any way which helps explain layout restrictions
*/


/*  The following block represents all of the functions which are required
	at GAME PLAY time.  This is because they MUST be mapped in the 0x100-0x180
	space, due to the the behavior of Fred's "soft here" mode.
	
	On the mac/simulator, they are mapped into the trap exception space,
	which is unused (we hope) except for trap E which is for the debugger.
*/

typedef struct GameTimeLowMem
{
	long			registerBase;
	long			controlRegisters;
	long			ticks;
	long			gameDispatcher0;
	long			gameDispatcher1;
	long			gameGlobalsStack;
	long			gameDispatchTable;
	long			gameParams;
	long			gtReadController;
	long			gtSendController;
	long			gtReadModem;
	long			ramOffset;
	long			romOffset;
	long			syncoParams;
	long			reservedTrapMacDebug;
	long			reservedTrapF;
} GameTimeLowMem;




/* Sega Low memory $0 - $200 */
typedef
struct SegaLowMem
{
#ifdef FORCE_HARD_HERE
	long			hiddenSerial2a;			// 0x00
	long			hiddenSerial2b;			// 0x04
#else
	long			resetSp;				// 0x00		FIX
	long			reset;					// 0x04		FIX
#endif

	long			accessFault;			// 0x08		FIX
	long			addressError;			// 0x0C		FIX
	long			illegal;				// 0x10		FIX
	long			zeroDivide;				// 0x14		FIX
	long			chk;					// 0x18		FIX
	long			fTrap;					// 0x1c		FIX
	long			privilege;				// 0x20		FIX
	long			trace;					// 0x24		FIX
	long			lineA;					// 0x28		FIX
	long			lineF;					// 0x2C		FIX
	long			reserved30;				// 0x30
	long			coprocessor;			// 0x34		FIX			// not used on 040
	long			formatErr;				// 0x38		FIX
	long			uninitInterrupt;		// 0x3C		FIX
	
	long			dispatcher0;			// 0x40			040		// 6 bytes here: jmp.l disp
	long			dispatcher1;			// 0x44			040
	long			globalsStack;			// 0x48			040		// must == kGlobalsStack
	long			dispatchTable;			// 0x4C
	long			ramTest1;				// 0x50
	long			modemDebug;				// 0x54
	unsigned char	VDPBusy;				// 0x58		// I really wish this was a simple flags long!
	unsigned char	soundEnabled : 1;		// 0x59
	unsigned char	osEnabled : 1;			// 0x59
	unsigned char	padBits : 6;			// 0x59
	char			pad2;					// 0x5A
	char			pad3;					// 0x5B
	long			reservedPPC;			// 0x5C		PPC
	
	long			spurious;				// 0x60		FIX
	long			level1;					// 0x64		FIX
	long			external;				// 0x68		FIX
	long			level3;					// 0x6C		FIX
	long			horizontal;				// 0x70		FIX
	long			level5;					// 0x74		FIX
	long			vertical;				// 0x78		FIX
	long			level7;					// 0x7C		FIX
	
#ifdef SIMULATOR
	GameTimeLowMem	gameVectors;			// 0x80-BC	FIX
#else
	long			trap[ 16 ];				// 0x80-BC	FIX
#endif

#ifdef FORCE_HARD_HERE
	GameTimeLowMem	gameVectors;			// 0xC0-FC	FIX
#else
	long			fpBranch;				// 0xC0			LOW		// these COULD be used on Sega
	long			fpInexact;				// 0xC4			LOW
	long			fpDiv0;					// 0xC8			LOW
	long			fpUnderflow;			// 0xCC			LOW
	long			fpOperand;				// 0xD0			LOW
	long			fpOverflow;				// 0xD4			LOW
	long			fpNAN;					// 0xD8			LOW
	long			fpUnimplType;			// 0xDC			LOW
	
	long			reservedE0;				// 0xE0
	long			reservedE4;				// 0xE4			LOW
	long			reservedE8;				// 0xE8			LOW
	long			reservedEC;				// 0xEC
	
	long			reservedF0;				// 0xF0	
	long			reservedF4;				// 0xF0	
	long			hiddenSerial2a;			// 0xF8
	long			hiddenSerial2b;			// 0xFC
#endif
	
/* up here above $100 things get tricker.  On the mac, it's entirely
   off-limits.  On the Sega, 100-180 is a special game-time globals
   area, and 180-1FF are Fred registers.
*/
	
#if defined(SIMULATOR) || defined(FORCE_HARD_HERE)
	long			reservedMac[64];		// 0x100-0x1FC
#else
	GameTimeLowMem	gameVectors;			// 0x100
	long			reserved140[ 16 ];		// 0x140
	long			rosko[ 32 ];			// 0x180
#endif

} SegaLowMem;




/*
*	Certain of our lomem globals will ALWAYS be at 0, so we can get to them
*	directly from any loaded code.
*/

#define	gGameDispatcher		(((SegaLowMem *) 0)->gameVectors.gameDispatcher0)			/* real low mem on both */
#define	gGTSendController	(((SegaLowMem *) 0)->gameVectors.gtSendController)			/* gametalk send controller vector */
#define	gGTReadController	(((SegaLowMem *) 0)->gameVectors.gtReadController)			/* gametalk read controller vector */
#define	gGTReadModem		(((SegaLowMem *) 0)->gameVectors.gtReadModem)				/* gametalk read controller vector */
#define	gGamePatchParams	(((SegaLowMem *) 0)->gameVectors.gameParams)

/*
*	Others are faked when on the simulator, to try to reduce lomem wierdness.
*
*	Note some of these are in GameVectors.  That's OK.  The previous list is for
*	"published" things anyway.  Things here are internal to the OS so they can
*	move and nobody needs to know....
*/

#define	gControlRegisters	(((SegaLowMem *) gBottomPermRam)->gameVectors.controlRegisters)	/* offset to control registers in current mode */
#define	gGameDispatchTable	(((SegaLowMem *) gBottomPermRam)->gameVectors.gameDispatchTable)
#define	gGameGlobalsStack	(((SegaLowMem *) gBottomPermRam)->gameVectors.gameGlobalsStack)
#define	gGameEntryPoint		(((SegaLowMem *) gBottomPermRam)->gameVectors.gameEntryPoint)
#define	gDispatcherTable	(((SegaLowMem *) gBottomPermRam)->dispatchTable)	/* ptr to dispatcher table */
#define	gRamTest1			(((SegaLowMem *) gBottomPermRam)->ramTest1)			/* RAM location 1 for first boot testing */
#define	gRegisterBase		(((SegaLowMem *) gBottomPermRam)->gameVectors.registerBase)		/* offset to register base */
#define	gRamOffset			(((SegaLowMem *) gBottomPermRam)->gameVectors.ramOffset)		/* offset to mapped sram */
#define	gRomOffset			(((SegaLowMem *) gBottomPermRam)->gameVectors.romOffset)					/* offset to mapped rom */
#define	gVDPBusy	 		(((SegaLowMem *) gBottomPermRam)->VDPBusy)
#define	gSoundEnabled	 	(((SegaLowMem *) gBottomPermRam)->soundEnabled)
#define	gOSEnabled	 		(((SegaLowMem *) gBottomPermRam)->osEnabled)
#define gHiddenSerial2		(((SegaLowMem *) gBottomPermRam)->hiddenSerial2a)

/* some other hardware vectors */
#define	gVBLHandler	 		(((SegaLowMem *) gBottomPermRam)->vertical)
#define	gHorzHandler	 	(((SegaLowMem *) gBottomPermRam)->horizontal)


#ifndef	__SERVER__
#ifdef SIMULATOR
// stimulator uses mac ticks
#define	gTicks				(Ticks)
#else
	// get stink c to generate the right code
	volatile long (gTicks) : (OFFSET(SegaLowMem,gameVectors.ticks));
#endif
#endif

/*
*	SegaHighMem
*	This is a global structure that sits at the top of sram. The purpose of being here is to free up
*	space down low for things that still want to be at a fixed location but DON'T need to be accessed
*	during game time (ie are only accessed when ram is mapped normally).
*/

typedef
struct SegaHighMem
{
	short			osUnstable;
	short			dbUnstable;
	unsigned short	bootAttempts;
	short			patchVersion;
	long			patchData;
	long			dataHeapTop;
	long			dataHeapBottom;
	long			dataBaseHeap;
	long			osBootVector;
	long			memTop;
	long			memBase;
	struct DBTypeNode *	typeList;
	long			globalsStackBase;
	long			ramTest2;
	long			lowLevelHeap;
	long			osCodeHeap;
	long			osCodeTop;
	long			osCodeBottom;
	long			gameRuntimeHeap;
	long			tempHeap;
	long			romHeap;
	long			smartcardSerial;
	long			smartcardToken;
	long			problemToken;
	long			validationToken;
	long			vblGTSession;
	NetErrorRecord	*currentNetStats;
	NetErrorRecord	netStats800;
	NetErrorRecord	netStatsX25;
} SegaHighMem;

/* macro to point us at the base of our high memory globals */
#define	gHighGlobalsBase		( gTopPermRam - kHiMemReserved )

/* accessor macros */
#define	gOSUnstable			(((SegaHighMem *) gHighGlobalsBase)->osUnstable)		/* os stable count */
#define	gDataBaseUnstable	(((SegaHighMem *) gHighGlobalsBase)->dbUnstable)		/* db stable count */
#define	gBootAttempts		(((SegaHighMem *) gHighGlobalsBase)->bootAttempts)		/* how many boot attempts since last successful */
#define	gPatchVersion		(((SegaHighMem *) gHighGlobalsBase)->patchVersion)		/* version of the currently installed os */
#define	gPatchData			(((SegaHighMem *) gHighGlobalsBase)->patchData)			/* OS Heap block containing patch */
#define	gDataHeapTop		(((SegaHighMem *) gHighGlobalsBase)->dataHeapTop)		/* the top of the database heap */
#define	gDataHeapBottom		(((SegaHighMem *) gHighGlobalsBase)->dataHeapBottom)	/* the bottom of the database heap */
#define	gDatabaseHeap		(((SegaHighMem *) gHighGlobalsBase)->dataBaseHeap)		/* ptr to perm database heap */
#define	gOSBootVector		(((SegaHighMem *) gHighGlobalsBase)->osBootVector)		/* os boot vector */
#define	gMemTop				(((SegaHighMem *) gHighGlobalsBase)->memTop)			/* ptr to top of unallocated SRAM */
#define	gMemBase			(((SegaHighMem *) gHighGlobalsBase)->memBase)			/* ptr to bottom of SRAM */
#define	gDatabaseTypeList	(((SegaHighMem *) gHighGlobalsBase)->typeList)			/* ptr to head of db type list */
#define	gGlobalStackBase	(((SegaHighMem *) gHighGlobalsBase)->globalsStackBase)	/* base stack ptr for globals */
#define	gRamTest2			(((SegaHighMem *) gHighGlobalsBase)->ramTest2)			/* RAM location 2 for first boot testing */
#define	gOSLowLevelHeap		(((SegaHighMem *) gHighGlobalsBase)->lowLevelHeap)		/* ptr to base of low level os heap */
#define	gOSCodeHeap			(((SegaHighMem *) gHighGlobalsBase)->osCodeHeap)
#define	gOSCodeTop			(((SegaHighMem *) gHighGlobalsBase)->osCodeTop)
#define	gOSCodeBottom		(((SegaHighMem *) gHighGlobalsBase)->osCodeBottom)
#define	gGameRuntimeHeap	(((SegaHighMem *) gHighGlobalsBase)->gameRuntimeHeap)
#define	gTempHeap			(((SegaHighMem *) gHighGlobalsBase)->tempHeap)
#define	gRomHeap			(((SegaHighMem *) gHighGlobalsBase)->romHeap)
#define	gNetStats			(((SegaHighMem *) gHighGlobalsBase)->currentNetStats)
#define	gNetStats800		(((SegaHighMem *) gHighGlobalsBase)->netStats800)
#define	gNetStatsX25		(((SegaHighMem *) gHighGlobalsBase)->netStatsX25)
#define	gVBLGTSession		(((SegaHighMem *) gHighGlobalsBase)->vblGTSession)		/* a temp gt session for vbls to get at */



/*
*	SegaROMGlobals
*	These are a bunch of globals that are stored at a fixed address in ROM.
*	The accessor functions for these are in OSGlobals.h (I figure most people
*	don't need these and moving them there allows their position in ROM to be
*	changed without forcing a recompile of the entire project...).
*/

typedef
struct SegaRomGlobals
{
	phoneNumber		the800Number;
} SegaRomGlobals;




#ifdef SIMULATOR
/* our fake a5 */
extern long glGlobalPtr;
#define gGlobalPtr			glGlobalPtr

#else
#define gGlobalPtr			a5					/* use a register here */
#endif



#ifdef SIMULATOR
/* for the simulator we use globals for top and bottom of sram */
extern long glBottomPermRam;
extern long glRomBottom;
extern long glRomDatabase;
extern long glGlobalPtr;

#define	gBottomPermRam		glBottomPermRam
#define gRomBottom			glRomBottom
#define gGlobalPtr			glGlobalPtr

#else

/* the real box uses actual hard coded addresses */
#define	gBottomPermRam		0x0								/* the bottom of physical SRAM */
#define gRomBottom			kRomBase						/* base of physical ROM */
#define gGlobalPtr			a5								/* use a register here */

#endif

#define	gTopPermRam			(gBottomPermRam+kSRAMSize)		/* the top of physical SRAM */




/*
*	Next to last is the BoxID structure.  However, this is totally hidden
*	inside BoxSer.c, so the only thing you'll see here globally is the space
*	which was reserved for it - sizeof(BoxIDReserved) a bit lower in this file.
*/

// BRAIN DAMAGE - BoxIDReserved must be >= the size of the real BoxID structure.


/*
*	BoxRestartInfo
*	This is a set of globals which is ALWAYS considered "live" - they are never 
*	checksummed or otherwise tagged.  We store debugging info in this space, and
*	upload it after crashes.
*/

#define	gBoxRestartAddress		( gTopPermRam - sizeof(BoxRestartInfoReserved) )
#define	gBoxRestart				((BoxRestartInfo *) gBoxRestartAddress)



//
// --- High Mem Reserved
//
//  The total amount of reserved himem areas is expressed here.  Anything
//  below this is available to the various allocators (see SegaOS.c)

#define kHiMemReserved	(sizeof(BoxRestartInfoReserved)+sizeof(BoxIDReserved)+sizeof(SegaHighMem) )



/*
*	ACCESSORS FOR REAL LOW-MEM
*
*	Define accessors here for anything which will ALWAYS be in low-mem
*	(even on the simulator).
*/

#define kGlobalsStack	0x48	/* where should this really have been defined? */

#define	gDispatchProcPtr	(*(long *) kDispatcherVector )			/* ptr to dispatch proc (fixed for mac and sega) */
#define	gGlobalStack		(*(long *) kGlobalsStack)				/* stack ptr for globals */



/*
* Globals manager
* We have a manager that keeps track of a general list of globals. Each global is one
* longword. Be very careful about using these. They are meant for shared system globals
* that we don't want to have to use low mems for.
*/

/* this is the list of the general globals we know about */
/* they are accessed through Get and SetGlobal */

enum
{

	/* keep this one last */
	kLastGlobal
};


#define	GameGlobal(field)	OFFSET(SegaLowMem,gameVectors)+OFFSET(GameTimeLowMem,field)


#ifndef	__SERVER__
short	GetGlobal ( short globalID, long * global ) =
	CallDispatchedFunction( kGetGlobal );

short	SetGlobal ( short globalID, long global ) =
	CallDispatchedFunction( kSetGlobal );
#endif

#endif __Globals__

