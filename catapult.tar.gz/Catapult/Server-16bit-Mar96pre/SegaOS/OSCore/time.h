/*
 *	$Id: time.h,v 1.2 1995/05/11 22:57:43 jhsia Exp $
 *	
 *	$Log: time.h,v $
 * Revision 1.2  1995/05/11  22:57:43  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		time.h

	Contains:	xxx put contents here xxx

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<13>	 8/14/94	ADS		GetCurrentTicks is now a macro
		<12>	 7/25/94	BET		unix-ise include capitalization.
		<11>	 7/12/94	HEC		Added kDontCallSegaOSIdle
		<10>	  7/7/94	DJ		added #ifndef __SERVER__
		 <9>	  7/7/94	HEC		DelayMS and DelayTicks now take caller for SegaOSIdle
		 <8>	  7/6/94	BET		Add caller parameter to SegaOSIdle.
		 <7>	  7/1/94	HEC		Added kWaitForMasterCallTimeout and kWaitForSlaveAnswerTimeout.
		 <6>	 6/21/94	KON		Add kInfiniteTime.
		 <5>	 6/16/94	BET		Revert Ted's changes.
		 <4>	 6/15/94	HEC		Fixed stupid bug
		 <3>	 6/15/94	KON		Add Get and Set Jesus Date and Time.
		 <2>	 5/30/94	SAH		Add SetOSIdle and SegaOSIdle.
		 <4>	 5/20/94	HEC		Added DelayMS and DelayTicks
		 <3>	 5/17/94	SAH		Changed #ifndef includes so I could get my initials in here
									last.
		 <2>	 5/17/94	KON		added #ifndef includes
		 <2>	 5/17/94	KON		Added some #ifndef includes.
		 <1>	 5/12/94	SAH		first checked in

	To Do:
*/

#ifndef __Time__
#define __Time__

#ifndef __SegaOS__
#include "SegaOs.h"
#endif

/*
** Timeouts
*/

#define kWaitForMasterCallTimeout			(60*60)		/* wait one minute for master to call us */
#define kWaitForSlaveAnswerTimeout			(60*60)		/* wait one minute for slave to answer */

/*
* Some magic time values
*/
enum
{
	kNever = -1,
	kInfiniteTime = 0x7FFFFFFF
};

// SegaOSIdle client identifier values
enum
{
	kNonSpecificCode	= 0,
	kNetworkCode,
	kDontCallSegaOSIdle = -1
};


#ifndef __SERVER__

typedef long * TimeProcRef;

typedef long (*TimeRequestProc) ( long time, long data );

typedef void (*SegaOSIdlePtr)( short caller );

#define GetCurrentTime()	(gTicks)


TimeProcRef	AddTimeRequest ( TimeRequestProc proc, long data ) =
	CallDispatchedFunction( kAddTimeRequest );

short	RemoveTimeRequest ( TimeProcRef ref ) =
	CallDispatchedFunction( kRemoveTimeRequest );

short	TimeIdle ( void ) =
	CallDispatchedFunction( kTimeIdle );

void	IncCurrentTime( void ) =
	CallDispatchedFunction( kIncCurrentTime );

void	DelayMS( long ms, short caller ) =
	CallDispatchedFunction( kDelayMS );

void	DelayTicks( long ticks, short caller) =
	CallDispatchedFunction( kDelayTicks );

void SegaOSIdle( short caller ) =
	CallDispatchedFunction( kSegaOSIdle );

void SetOSIdle( SegaOSIdlePtr newOSIdle ) =
	CallDispatchedFunction( kSetOSIdle );

long GetJesusTime( void ) =
	CallDispatchedFunction( kGetJesusTime );
	
void SetJesusTime( long currentTime ) =
	CallDispatchedFunction( kSetJesusTime );

long GetJesusDate( void ) =
	CallDispatchedFunction( kGetJesusDate );

void SetJesusDate( long currentDate ) =
	CallDispatchedFunction( kSetJesusDate );

#endif __SERVER__

#endif __Time__
