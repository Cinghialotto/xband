/*
 *	$Id: EndGamePriv.h,v 1.2 1995/05/11 22:57:14 jhsia Exp $
 *	
 *	$Log: EndGamePriv.h,v $
 * Revision 1.2  1995/05/11  22:57:14  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		EndGamePriv.h

	Contains:	xxx put contents here xxx

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <2>	 7/15/94	SAH		No more globals.
		 <1>	  7/5/94	SAH		first checked in

	To Do:
*/

#ifndef __GamePatch__
#include "GamePatch.h"
#endif

typedef
struct EndGameGlobals
{
	short dummy;
} EndGameGlobals;



#ifdef SIMULATOR
#define	MANAGERGLOBALTYPE		EndGameGlobals
#else
extern EndGameGlobals endgame;
#endif


