/*
 *	$Id: SegaTraps.h,v 1.2 1995/05/11 22:57:36 jhsia Exp $
 *	
 *	$Log: SegaTraps.h,v $
 * Revision 1.2  1995/05/11  22:57:36  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		SegaTraps.h

	Contains:	Sega debugging traps

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <2>	 5/30/94	SAH		Added debug flag.
		 <1>	 5/30/94	SAH		first checked in

	To Do:
*/

#ifndef DEBUG
#define DEBUG
#endif


#ifdef SIMULATOR

#define	PsyqHalt() 
#define	PsyqPoll() 

#else

#ifdef DEBUG
void	PsyqHalt ( void ) = 0xa003;
void	PsyqPoll ( void ) = 0xa000;
#else
#define	PsyqHalt() 
#define	PsyqPoll() 
#endif

#endif

