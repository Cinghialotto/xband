/*
 *	$Id: GlobalsPriv.h,v 1.2 1995/05/11 22:57:17 jhsia Exp $
 *	
 *	$Log: GlobalsPriv.h,v $
 * Revision 1.2  1995/05/11  22:57:17  jhsia
 * switch to rcs keywords
 *
 */



#define	kNumGlobals		32


typedef
struct GlobalTable
{
	short entries;
	long table [ kNumGlobals ];
} GlobalTable;


#ifdef SIMULATOR

#define MANAGERGLOBALTYPE GlobalTable
#else
GlobalTable globals;

#endif


