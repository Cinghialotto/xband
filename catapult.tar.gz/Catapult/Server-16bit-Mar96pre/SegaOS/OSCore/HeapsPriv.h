/*
 *	$Id: HeapsPriv.h,v 1.2 1995/05/11 22:57:17 jhsia Exp $
 *	
 *	$Log: HeapsPriv.h,v $
 * Revision 1.2  1995/05/11  22:57:17  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		HeapsPriv.h

	Contains:	xxx put contents here xxx

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <5>	 7/21/94	JBH		Added logicalBlockSize to block header, so GetMemorySize doesn't
									lie.
		 <4>	 7/14/94	ADS		Vectorize EVERYTHING
		 <3>	  7/1/94	SAH		Don't turn on Verify when building the ROMDB.
		 <2>	 6/30/94	SAH		Added insidePurge to private globals.

	To Do:
*/


#ifdef SIMULATOR
#ifndef ROMDB
#define HEAP_VERIFY
#endif
#endif

#define	kMaxHeapZones		8


typedef
struct Block
{
	struct Block *	next;
	struct Block *	prev;
	unsigned short	logicalBlockSize;
#ifdef HEAP_VERIFY
	long			signature;
#endif
} Block;


typedef
struct Heap
{
	Block *	head;
	Block *	tail;
} Heap;

typedef
struct HeapListEntry
{
	short	used;
	Heap	heap;
} HeapListEntry;

typedef
struct HeapTable
{
	short numEntries;
	HeapListEntry heaps[ kMaxHeapZones ];
} HeapTable;

typedef
struct HeapGlobals
{
	Heap *	tempHeap;
	Heap *	permHeap;
	HeapTable permHeaps;
	Boolean	insidePurge;
} HeapGlobals;


#ifdef SIMULATOR
#define MANAGERGLOBALTYPE HeapGlobals
#else

extern HeapGlobals heaps;

#endif



// internal functions, vectorized for patching


static	void	FillMemory ( Ptr base, short size, long val )  =
	CallDispatchedFunction( kFillMemory );

static	Heap *	GetCurrentHeap ( short perm )  =
	CallDispatchedFunction( kGetCurrentHeap );

static	Block *	FindLastAllocatedBlock ( Heap * heap )  =
	CallDispatchedFunction( kFindLastAllocatedBlock );



