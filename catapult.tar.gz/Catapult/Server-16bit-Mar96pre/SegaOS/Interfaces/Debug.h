/*
 *	$Id: Debug.h,v 1.2 1995/05/11 22:49:42 jhsia Exp $
 *	
 *	$Log: Debug.h,v $
 * Revision 1.2  1995/05/11  22:49:42  jhsia
 * switch to rcs keywords
 *
 */



/*
* this file defines a bunch of debugging stuff
*/


#ifndef NDEBUG

#ifdef SIMULATOR
#define	FLAGANALYZER()		DebugStr("\pFlagging the analyzer here...")

#else
#define	FLAGANALYZER()		*((long *) 0x2c) = *((long *) 0x2c)
#endif

#else
#define	FLAGANALYZER()		

#endif
