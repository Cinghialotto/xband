/*
 *	$Id: DebugMacro.h,v 1.2 1995/05/11 22:49:43 jhsia Exp $
 *	
 *	$Log: DebugMacro.h,v $
 * Revision 1.2  1995/05/11  22:49:43  jhsia
 * switch to rcs keywords
 *
 */

// ===========================================================================
//	DebugMacro.h					�1994 Brian Topping All rights reserved.
// ===========================================================================

#define DEBUG 1

#ifdef DEBUG
	#define IfDEBUGStr(a,b) { if (a) DebugStr(b); }
#else
	#define IfDEBUGStr(a,b)
#endif

