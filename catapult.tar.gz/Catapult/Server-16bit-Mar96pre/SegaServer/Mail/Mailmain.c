/*
 * Catapult Entertainment, Inc.
 *
 * $Id: Mailmain.c,v 1.34 1996/02/02 15:43:00 chs Exp $
 *
 * $Log: Mailmain.c,v $
 * Revision 1.34  1996/02/02  15:43:00  chs
 * use gConfig.catapultTown everywhere.
 *
 * Revision 1.33  1995/11/08  18:35:29  jhsia
 * Pull Catapult town out of gConfig.catapultTown. (fadden)
 *
 * Revision 1.32  1995/10/26  03:36:28  jhsia
 * Added -D flag to cause error messages to go to screen instead of syslog.
 * Put JAPAN_TESTING #ifdef around restrictions on U282:19:A style addresses.
 *
 * Revision 1.31  1995/10/22  16:09:18  roxon
 * Oops. A missing '!' in front of strcmp(). And a few comment lines.
 *
 * Revision 1.30  1995/10/22  15:30:08  roxon
 * Check "Content-Transfer-Encoding: quoted-printable" for emails in MIME.
 *
 * Revision 1.29  1995/10/17  18:25:59  chs
 * relax u-colon mail restriction from "xband-*@catapent.com" to "xband*".
 *
 * Revision 1.28  1995/10/16  15:00:43  chs
 * allow both *@catapent.com and xband* to send to U: addrs.
 * requeue mail from *@catapent.com and xband* when box is full.
 *   (this shouldn't happen anymore anyway, but what the heck)
 * add support for sending to the first valid player on the box.
 *
 * Revision 1.27  1995/10/15  17:03:22  roxon
 * Add jis2euc() convertor and decode_mime() fom Xmails from internet.
 * Add Japanese character handling in line formating (screen display).
 *
 * Revision 1.26  1995/09/24  14:53:47  roxon
 * Remove the restriction of enforcing a full path config file name with -f.
 *
 * Revision 1.25  1995/09/13  14:09:19  ted
 * Fixed warnings.
 *
 * Revision 1.24  1995/08/21  21:30:11  roxon
 * Check full file name for -f option. And, reading locale server.conf is
 * done in Common_ReadConf() instead.
 *
 * Revision 1.23  1995/08/14  22:28:23  roxon
 * Read locale specific server.conf, and setlocale() accordingly.
 *
 * Revision 1.22  1995/07/19  16:23:39  chs
 * Allow [0123] as playerID's as well as [ABCD].
 *
 * Revision 1.21  1995/06/28  18:12:09  chs
 * Break one internet mail into at most 10 Xmails (used to be 5).
 * Support -r switch that newer sendmail passes us.
 * Fix the code that makes sure the date is non-zero.
 * Make sure the title fits in its field.
 * If the mail would go to an account that's closed,
 *   if the sender is support, drop the mail,
 *   otherwise bounce with NOUSER.
 *
 * Revision 1.20  1995/06/12  13:23:11  chs
 * Handle U_ and U: addresses better.
 * Remove SNES-server hack.
 * Improve from-address and subject detection.
 * Set the from (box,region) to (-1,0) instead of (-1,-1)
 *   to work around a SNES "feature".
 * Improve some error messages.
 *
 * Revision 1.19  1995/05/31  11:02:53  chs
 * Correct a debugging message.
 *
 * Revision 1.18  1995/05/26  16:14:03  chs
 * Undo a stupid change I made that broken the handling of bounced mail.
 *
 * Revision 1.17  1995/05/18  16:50:45  chs
 * Only allow *@catapent.com to send mail to "U:" addresses.
 *
 * Revision 1.16  1995/05/17  06:33:11  chs
 * made -v be more verbose.
 * deal with magic Uxxxx:xx:x and U_xxxxxxxx:xx:x addresses here now.
 * added a big hack for snes:  if the name lookup fails on the default
 * server, try again on the snes server.
 *
 */

/*
	File:		Mailmain.c

	Contains:	xxx put contents here xxx
	
	Guilty:		Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <7>	12/13/94	BET		Take the number off messages that fit into a single message.
		 <6>	11/28/94	BET		Fix the bitch
		 <5>	11/16/94	ATM		Limit the total size to 2*kMaxSingleMessage.
		 <4>	11/11/94	ATM		Increased kMaxSingleMessage from 100 to 512.  (350 is the
									experimentally determined max.)
		 <3>	10/24/94	BET		Fix long messages being repeated.
		 <2>	 10/6/94	BET		Damn projector
		 <1>	 10/4/94	BET		first checked in

	To Do:
*/


/* return values from sendmails sysexits.c */
enum {
	USAGE = 64,
	DATAERR = 65,
	NOINPUT = 66,
	NOUSER = 67,
	NOHOST = 68,
	UNAVAILABLE = 69,
	SOFTWARE = 70,
	OSERR = 71,
	OSFILE = 72,
	CANTCREAT = 73,
	IOERR = 74,
	TEMPFAIL = 75,
	PROTOCOL = 76,
	NOPERM = 77,
	CONFIG = 78
};

#include <stdio.h>
#include <memory.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
#include <string.h>
#include <strings.h>
#include <syslog.h>
#include <ctype.h>
#include <time.h>
#include <locale.h>

extern int getopt(int, char * const *, const char *);
extern char *optarg;
extern int opterr;
extern int optind;

#include "SegaTypes.h"
#include "ServerDataBase.h"
#include "Common_ReadConf.h"
#include "Common_PlatformID.h"
#include "Dates.h"
#include "Common_Missing.h"
#include "errorlog.h"

#define kMaxSingleMessage	512
#define kMaxNumMessages		10
#define BUFLEN			32768
#define kMailMessageLines	5
#define kXbandPrefix		"xband"
#define kMAILERNAME		"MAILER-DAEMON"
#define kMAILERRETURN		"This X-Mail you sent was NOT delivered because of an error in the address (the TO: box).  Please check the mailing address for spelling and unnecessary spaces and try again."


static int FormatLineBuf(u_char *, u_char *, int);
static long convertDate(char *);
static int MonthNum(char *);
static Boolean StripInternalXbandAlias(char *);

static  void jis2euc(u_char *, u_char *);
static  void decode_mime(u_char *, u_char *);

/*
 * Character Widths for Sega XBAND Light 9
 */
static u_char sega_xBandLight9Widths[256] = {
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		3, 3, 4, 9, 6, 9, 8, 2,
		4, 4, 6, 6, 3, 4, 3, 5,
		7, 7, 7, 7, 7, 7, 7, 7,
		7, 7, 3, 3, 6, 7, 6, 5,
		9, 8, 6, 7, 7, 6, 6, 7,
		7, 3, 5, 6, 6,10, 7, 8,
		6, 8, 6, 6, 6, 7, 8,10,
		7, 7, 7, 3, 5, 3, 6, 6,
		3, 6, 6, 5, 6, 6, 4, 6,
		6, 4, 4, 5, 4,10, 6, 6,
		6, 6, 4, 5, 5, 6, 6, 10,
		6, 6, 5, 4, 4, 4, 7, 255,

		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
	};

/*
 * Same thing but for SNES.
 */
static u_char snes_xBandLight9Widths[256] = {
		255, 1,   2,   3,   4,   5,   6,   7,
		8,   9,  10,  11,  12,  13,  14,  15,
		16, 17,  18,  19,  20,  21,  22,  23,
		24, 25,  26,  27,  28,  29,  30,  31,
		3,   3,   4,   9,   6,   9,   8,   2,
		4,   4,   6,   6,   3,   5,   3,   5,
		7,   7,   7,   7,   7,   7,   7,   7,
		7,   7,   3,   3,   6,   6,   6,   5,
		9,   6,   5,   6,   6,   5,   5,   6,
		6,   3,   4,   5,   5,   8,   6,   8,
		5,   7,   5,   5,   6,   6,   6,   10,
		6,   7,   7,   3,   5,   3,   6,   5,
		3,   5,   5,   4,   5,   5,   4,   5,
		5,   3,   4,   5,   3,   8,   5,   5,
		5,   5,   4,   5,   5,   5,   6,   10,
		6,   6,   5,   4,   4,   4,   7,   255,

		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 5,   255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 5,   255, 255, 6,   255, 255,
		8,   8,   10,  255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		5,   3,   255, 255, 255, 255, 255, 255,
		255, 9,   255, 255, 255, 255, 255, 255,
		7,   8,   5,   5,   3,   3,   255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		6,   255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255
	};


static char *config_file = DEFAULT_CONFIG_FILE;

char MailBuf[BUFLEN];
int debug = 0;
ServerState *boxState = NULL;

void ReportError(char *file, long line, char *message) {}

static long Common_TimeToSegaDate(time_t);
static long
Common_TimeToSegaDate(time_t now)
{
    struct tm *tm;

    tm = localtime(&now);

    return(Date(tm->tm_year + 1900, tm->tm_mon, tm->tm_mday));
}


void
main(int argc, char *argv[])
{
    int		messageLen, c, delete, verbose,
		lineSize, numLines, numMessages,
		mailerMsg, seenAMsg, err, from_catapult;
    char	*cp, *user, *message, *body, *rangeStart, *fromaddr;
    char	lineBuf[kMaxSingleMessage], subject[kTitleSize + 5];
    userIdentification	uID;
    Account 	*account;
    Mail	*mail;
    FILE	*tempfile;
    int		mime_1_0_qp = 0;

    u_char *font_metrics;
    int title_width, body_width, iconid;
    int box, region, ucolon;
    char playerchar, fromname[1024];

    fromaddr = NULL;
    from_catapult = false;
    ucolon = false;
    delete = false;
    verbose = false;
    seenAMsg = false;
    box = 0;

    opterr = 0;
    while ((c = getopt(argc, argv, "b:c:df:i:r:vxD")) != EOF) {
	switch (c) {
	  case 'b':
	    box = atoi(optarg);
	    continue;
	  case 'c':
	    gConfig.databaseSvc.hostName = optarg;
	    continue;
	  case 'd':
	    /* ignored, for binmail compatibility */
	    continue;
	  case 'f':
	    config_file = optarg;
	    continue;
	  case 'i':
	    gConfig.databaseSvc.svc = atol(optarg);
	    continue;
	  case 'r':
	    fromaddr = optarg;
	    continue;
	  case 'v':
	    verbose = true;
	    continue;
	  case 'x':
	    delete = true;
	    continue;
	  case 'D':
	    debug = 1;
	    continue;
	  usage:
	  default:
	    (void) fprintf(stderr, "%s: Unknown option %s\n",
			   argv[0], argv[optind-1]);
	    (void) fprintf(stderr, "usage:\t%s [-d] [-c host]"
			   " [-i rpc service number] username\n",
			   argv[0]);
	    exit(USAGE);
	}
    }

    /* if we are out of args, bail, otherwise its the username */
    if (optind == argc)
	goto usage;
    user = argv[optind];

    chdir("/opt/catapult/conf");
    if (Common_ReadConfigFile("Xmail", config_file) < 0) {
	fprintf(stderr, "config file %s busted\n", config_file);
	exit(SOFTWARE);
    }

    setlocale(LC_ALL, gConfig.locale_phone);

    chdir("/tmp");
    log_open("Xmail", LOG_PID, LOG_USER);

    bzero(&uID, sizeof uID);
    uID.box.box = uID.box.region = -1;
    strncpy(uID.userName, user, kUserNameSize);

    /*
     * a user specified with -b gets the first valid player on the box
     */
    if (box) {
	int i;

	uID.box.box = box;
	uID.box.region = gConfig.happyRegion;

	for (i = 0; i < 4; i++) {
	    userIdentification foundUserID;
	    err = WrapperDB_FindUserIdentification(&uID, &foundUserID);
	    if (err == kNoError) {
		uID = foundUserID;
		break;
	    }
	}
    }

    /*
     * next look for Uxxxx:yy:z and U_xxxxxxxx_yy_z addresses
     */
    if (uID.box.box == -1 &&
	toupper(*user) == 'U' &&
	(sscanf(user+1, "%d:%d:%c", &box, &region, &playerchar) == 3
	 || sscanf(user+1, "_%d_%d_%c", &box, &region, &playerchar) == 3)) {

	int player = toupper(playerchar) - 'A';

	if (player < 0 || player > 3)
	    player = playerchar - '0';

	if (player >= 0 && player <= 3) {
	    if (user[1] == '_') {
		box = DataBaseUtil_ScrambleBoxID(box, 1);
	    }
	    else {
		ucolon = true;
	    }
	    uID.box.box = box;
	    uID.box.region = region;
	    uID.userID = player;
	    if (verbose) {
		log_msg("converted %s to (%d,%d,%d)",
			user, box, region, player);
	    }
	}
    }

    /*
     * finally just try the name as-is
     */
    if (uID.box.box == -1) {
	userIdentification foundUserID;
	err = WrapperDB_FindUserIdentification(&uID, &foundUserID);
	if (err != kNoError) {
	    log_msg("FindUserIdentification for %s -> %d\n", user, err);
	    exit(NOUSER);
	}
	uID = foundUserID;
    }

    err = WrapperDB_FindAccount(&uID, &account);
    if (err != kNoError) {
	log_msg("FindAccount (%d,%d,%d) -> %d\n",
		uID.box.box, uID.box.region, uID.userID, err);
	exit(NOUSER);
    }

    if (delete) {
	numMessages = WrapperDB_GetNumIncomingMail(&uID);
	for (c = 0; c < numMessages; c++)
	    WrapperDB_MarkMailAsSent(&uID, c);
	WrapperDB_RemoveSentMail(&uID);
	printf("removed %d messages from %s\n",
	       numMessages, uID.userName);
	exit(0);
    }

    if (account->boxAccount.csUpdatedFlags
	& kCSUpdatedFlags_DisableInternetMail) {
	log_msg("mail to %s (%d,%d,%d) disabled, bouncing message",
		user, uID.box.box, uID.box.region, uID.userID);
	exit(NOUSER);
    }

    /*
     * Deal with different platforms
     */
    switch (account->boxAccount.platformID) {
      case kPlatformGenesis:
      default:
	font_metrics = sega_xBandLight9Widths;
	title_width = 150;
	body_width = 240;
	iconid = 0;
	break;

      case kPlatformSNES:
      case kPlatformSJNES:
	font_metrics = snes_xBandLight9Widths;
	title_width = 177;
	body_width = 205;
	iconid = 202;
	break;
    }

    mail = (Mail *)malloc(sizeof(Mail)+kMaxSingleMessage);
    if (!mail) {
	log_msg("malloc failed");
	exit(OSERR);
    }
    memset(mail, 0, sizeof(Mail)+kMaxSingleMessage);

    /* copy the entire message to the temp file */
    tempfile = tmpfile();
    c = fread(MailBuf, 1, BUFLEN, stdin);
    while (c == BUFLEN) {
	fwrite(MailBuf, 1, c, tempfile);
	c = fread(MailBuf, 1, BUFLEN, stdin);
    }
    fwrite(MailBuf, 1, c, tempfile);

    messageLen = ftell(tempfile);
    fseek(tempfile, 0, 0);

    message = (char *)malloc(messageLen + 1);
    if (!message) {
	log_msg("malloc failed");
	exit(OSERR);
    }
    fread(message, 1, messageLen, tempfile);
    fclose(tempfile);
    message[messageLen] = 0;

    /* if locale is ja, convert incoming message (mime or jis) to EUC */
    if ( LOCALE_PHONE_JA() ) {
	u_char  *euc_msg = (u_char *)malloc(messageLen + 1);

	/* find the start of the body (ie. end of the headers) */
	body = strstr(message, "\n\n");
	if (!body) {
	    log_msg("no message body");
	    exit(PROTOCOL);
	}

	// check header lines first
	strncpy(euc_msg, message, body - message);
	if ( strstr(euc_msg, "MIME-Version: 1.0") ) {
		char	*qp_ptr = strstr(euc_msg, "Content-Transfer-Encoding:");

		qp_ptr += 26;
		while ( *qp_ptr == ' ') qp_ptr++;

	    if (!strncasecmp(qp_ptr, "quoted-printable", 16) )
		    mime_1_0_qp = 1;
	}

	memset(euc_msg, 0, messageLen + 1);

	// OK. do encoding conversion accordingly
	if ( mime_1_0_qp ) {
	    decode_mime(euc_msg, (u_char *)message);
	} else {
	    jis2euc(euc_msg, (u_char *)message);
	}

	free(message);
	message = (char *)euc_msg;

	/* messageLen is used below */
	c = messageLen = strlen(message);
    }		// done with Japanese message conversion

    /* find the start of the body (ie. end of the headers) */
    body = strstr(message, "\n\n");
    if (!body) {
	log_msg("no message body");
	exit(PROTOCOL);
    }

    fromname[0] = 0;

    /* if the from address was specified with -r, use that */
    if (fromaddr) {
	strcpy(fromname, fromaddr);
    }

    /*
     * if no -r, use the "From" header 
     */
    if (!fromname[0]) {
	/* find the "From" header */
	rangeStart = strstr(message, "From: ");
	if (!rangeStart || rangeStart > body) {
	    log_msg("no from address");
	    exit(PROTOCOL);
	}

	/*
	 * search for "From" headers like
	 * "From: Chuck Silvers <chs@catapent.com>"
	 */
	cp = strpbrk(rangeStart, "<\n");
	if (cp && *cp == '<' ) {
	    char *cp2 = strpbrk(cp, ">\n");
	    
	    if (cp2 && *cp2 == '>') {
		cp++;	/* skip the '<' */
		strncpy(fromname, cp, cp2 - cp);
	    }
	}

	/* when all else fails just grab the first word after the "From:" */
	if (!fromname[0] && sscanf(rangeStart, "From: %s", fromname) != 1) {
	    log_msg("from address malformed");
	    exit(PROTOCOL);
	}
    }

    for (cp = fromname;
	 isalnum(*cp) || *cp == '-' || *cp == '.' || *cp == '_';
	 cp++) ;

    if (!strcasecmp(cp, "@catapent.com") || !strncasecmp(fromname, "xband", 5)) {
	from_catapult = true;
    }

    /* is this from mailer daemon? */
    mailerMsg = !strncasecmp(fromname, kMAILERNAME, strlen(kMAILERNAME));
    if (mailerMsg) {
	strcpy(fromname, "support@catapent.com");
    }

#ifndef JAPAN_TESTING
    /*
     * allow only Catapult users to send to "U:" addresses
     */
    if (ucolon && !from_catapult) {
	log_msg("mail to U: address from %s", fromname);
	exit(NOUSER);
    }
#endif	/*JAPAN_TESTING*/

    /*
     * if this mail is being sent from an address of 
     * the form: kXbandPrefix<string>@catapent.com, this
     * message is from an internal Catapult alias
     * managed through procmail. Strip the 
     * "@catapent.com" part and insert the xband
     * town and iconID.
     */
    if (StripInternalXbandAlias(fromname)) {
		strcpy(mail->from.userTown, gConfig.catapultTown);
		mail->from.ROMIconID = kXBANDPlayerIcon;
    } else {
		strcpy(mail->from.userTown, "Internet");
		mail->from.ROMIconID    = iconid;
    }
    strncpy(mail->from.userName, fromname, sizeof(mail->from.userName));
    mail->from.box.box      = -1;
    /*
     * The region used to be set to -1 as well.
     * However, on the SNES, having the from
     * (box, region) = (-1, -1) tells the box
     * that the "to" and "title" fields shouldn't
     * be filled in automatically when the user
     * does "reply".  Therefore we set it to 0 now.
     * Yay.
     */
    mail->from.box.region   = 0;
    mail->from.userID       = 0;
    mail->from.colorTableID = 0;
    
    /* set up the 'to' address */
    mail->to = uID;
    
    /* set up other fields */
    mail->serialNumber = 0;
    mail->hasThisMailBeenRead = 0;

    cp = strstr(mailerMsg ? body: message, "Subject:");
    if (!mailerMsg && cp > body) {
	cp = NULL;
    }
    if (cp) {
	cp += 8; /* length of "Subject:" */
	if (mailerMsg && !strncmp(cp, " Re:", 4)) {
	    cp += 4;
	}
	while (*cp == ' ' || *cp == '\t') {
	    cp++;
	}

	subject[0] = 0;
	if (mailerMsg) {
	    strcpy(subject, "Re: ");
	}
	strncat(subject, cp, kTitleSize - 1);
	subject[kTitleSize - 1] = 0;
	cp = strchr(subject, '\n');
	if (cp) {
	    *cp = 0;
	}
    }
    else {
	strcpy(subject, "(No Subject)");
    }

    FormatLineBuf(subject, font_metrics, title_width);

    rangeStart = strstr(message, "Date: ");
    if (rangeStart && rangeStart < body) {
	mail->date = convertDate(&rangeStart[6]);
    }

    /* make sure the date is non-zero */
    if (mail->date == 0) {
	mail->date = Common_TimeToSegaDate(time(0));
    }
    
    if (mailerMsg) {
	rangeStart = kMAILERRETURN;
	c = strlen(rangeStart);
    }
    else {
	rangeStart = body + 2;
	c = messageLen - (rangeStart - message);
    }

    numMessages = 1;
    while (c && (numMessages <= kMaxNumMessages)) {
	/* clear accumulated message */
	mail->message[0] = 0;
	/* skip returns at beginning of message */
	while (*rangeStart == '\n') {
	    rangeStart++;
	    c--;
	}
	if (!c)
	    break;

	/* now process the mail */
	for (numLines = 0; numLines < kMailMessageLines; numLines++) {
	    if ((numMessages == kMaxNumMessages)
		&& (numLines == kMailMessageLines-1)) {
		if (mail->message[strlen(mail->message)-1] != '\n')
		    strcat(mail->message, "\n");
		strcpy(lineBuf,
		       "[Mail truncated for length by XBAND]");
		strncat(mail->message,
			lineBuf, kMaxSingleMessage);
		c = 0;
		break;
	    }

	    strncpy(lineBuf, rangeStart, kMaxSingleMessage);
	    lineSize = FormatLineBuf(lineBuf, font_metrics,
				     body_width);
	    if (!lineSize)
		break;
	    if (lineSize == -1) { 
		log_msg("FormatLineBuf failed");
		exit(SOFTWARE);
	    }
	    c -= lineSize;
	    rangeStart += lineSize;
	    strncat(mail->message, lineBuf, kMaxSingleMessage);
	}

	if (c || seenAMsg) {
	    sprintf(mail->title, "%.29s (%d)", subject, numMessages);
	}
	else {
	    strncpy(mail->title, subject, kTitleSize);
	}

	numMessages++;
	seenAMsg = true;
	
	err = WrapperDB_AddMailToIncoming(mail);
	if (err == kMailNotDelivered_TooManyMails && from_catapult) {
	    /*
	     * If support is sending mail to someone with a full queue,
	     * leave it in the sendmail queue.
	     */
	    log_msg("requeuing mail from Catapult user %s", fromname);
	    exit(TEMPFAIL);
	}

	/* deal with closed accounts */
	if (err == kMailNotDelivered_AccountClosed) {
	    if (!strcmp(fromname, "support@catapent.com")) {
		/*
		 * if support is sending mail to a closed account,
		 * just drop the message.
		 */
		log_msg("dropping support mail to closed account %s", user);
		exit(0);
	    }
	    else {
		/*
		 * if anyone else sends mail to a closed account,
		 * give back "User Unknown".
		 */
		log_msg("bouncing mail from %s to closed account %s",
			fromname, user);
		exit(NOUSER);
	    }
	}

	if (err != kNoError) {
	    log_msg("AddMailToIncoming from %s to %s -> %d",
		    fromname, user, err);
	    exit(CANTCREAT);
	}
    }
    
    exit(0);
}

/*
 * FormatLineBuf -- take more than a line full of info in lineBuf
 * and trim it down to a single box screen line of info.
 * Return the number of characters eaten.
 * This routine uses two newlines in a row as a line terminator
 */
static int FormatLineBuf(u_char *lineBuf, u_char *fontMetrics, int lineWidth)
{
u_char		*maxMessage, *findex, *lastIndex;
int		width, skew, lastSkew, count;
int		charlen = 0;
	
	lastSkew = skew = 0;
	
	// short circuit the process if the max
	// that can be in this line already fits
	maxMessage = strstr(lineBuf, "\n\n");

	// if the newlines start the line, return it as a line of its own.
	if (maxMessage == lineBuf) {
		// count the leading newlines,
		// condense multiple newlines into one blank line
		count = strspn(lineBuf, "\n");
		lineBuf[1] = 0;
		return count;
	}

	if (maxMessage)
		maxMessage[1] = 0;
	else
		maxMessage = lineBuf + strlen(lineBuf);

	width = 0;

	lastIndex = findex = lineBuf;
	while (findex < maxMessage) {
		if (*findex == ' ') {
			lastIndex = findex+1;
			lastSkew = skew;
		}
		else if (*findex == '\n') {
			// found a newline, know we wouldn't see it
			// if it were two because of strstr above
			// if both previous and next chars are non-space,
			// just make it a space
			if ((findex[-1] != ' ') && (findex[1] != ' '))
				*findex = ' ';
			else {
				memcpy(findex, findex+1,
				       lineBuf+kMaxSingleMessage-findex);
				lastIndex = findex+1;
				lastSkew = skew;
				skew += 1;
				// make sure we didn't polish off the buffer
				if (!*findex) {
					return findex-lineBuf+skew;
				}
			}
		}

		// check for end-of-message.
		// not sure why this is necessary.
		if (*findex == 0) {
		    return findex-lineBuf+skew;
		}

		// check for bad characters
		// used to return -1, now just change bad char to a space
		// This check is OK only if the locale is not ja (ko & zh, too).
		if ( !LOCALE_PHONE_JA() && fontMetrics[*findex] == 255) {
			*findex = ' ';
		}

		// accumulate width
		if ( LOCALE_PHONE_JA() ) {
			charlen = mblen(findex, MB_CUR_MAX);
			if ( charlen > 1 ) {
				/*
				 * In fact, 2 should be a safe bet
				 * for Japanese EUC on Sun.  The magic 14 is
				 * the Japanese character width on SJNES
				 * This is very bad coding. Other platforms
				 * may have different width for Japanese characters.
				 */
				width += 14;
			} else if ( charlen == 1 ) {
				width += fontMetrics[*findex];
			} else {
				/*
				 * should not happen at all,
				 * something is screwed up.
				 */
				charlen = 1;
				*findex = ' ';
				width += fontMetrics[*findex];
			}
		} else {
			width += fontMetrics[*findex];
		}

		if (width > lineWidth) {
			if (lastIndex != lineBuf) {
				findex = lastIndex;
				skew = lastSkew;
			}
			*findex = 0;
			return findex-lineBuf+skew;
		}

		if ( charlen == 0 )
			findex++;
		else
			findex += charlen;
	}
	return findex-lineBuf+skew;
}

/************************************************************************
 * BeautifyDate - make a date look better
 * assumes the date is in smtp date format
 ************************************************************************/
static long convertDate(char *dateStr)
{
    char *cp;
    union {
	long date;
	struct {
	    unsigned		year:16;
	    unsigned		month:4;
	    unsigned		day:5;
	    unsigned		misc:7;
	} s;
    } u;

    if (strlen(dateStr) < 10) return(0);  /* ignore really short dates */
    u.date = 0;

    /*
     * skip day of the week
     */
    cp = strpbrk(dateStr, ",\n");
    if (cp == NULL || *cp == '\n')
	return 0;

    cp++;
    while (isspace(*cp))
	cp++;

    /* eat day */
    u.s.day = strtol(cp, &cp, 10);
    if (cp == NULL)
	return 0;

    /* skip spaces */
    while (isspace(*cp))
	cp++;

    /* eat month */
    u.s.month = MonthNum(cp);

    /* skip spaces */
    while (*cp && !isspace(*cp))
	cp++;
    while (isspace(*cp))
	cp++;
	
    /* eat year */
    if (*cp && isdigit(*cp)) {
	u.s.year = strtol(cp, &cp, 10);
	if (u.s.year < 20) {
	    u.s.year += 2000;
	}
	else {
	    if (u.s.year < 1900) {
		u.s.year += 1900;
	    }
	}
    }
    return u.date;
}

/************************************************************************
 * MonthNum - get the month number from a month name
 ************************************************************************/
static int MonthNum(char *cp)
{
	char monthStr[4];
	short month=0;
	
	/*
	 * copy and lowercase
	 */
	bcopy(cp,monthStr,3);
	monthStr[3] = 0;
	for (cp=monthStr;*cp;cp++) if (isupper(*cp)) *cp = tolower(*cp);
	cp = monthStr;
	
	switch(cp[0])
	{
		case 'j': month = cp[1]=='a' ? 1 : (cp[2]=='n' ? 6 : 7); break;
		case 'f': month = 2; break;
		case 'm': month = cp[2]=='r' ? 3 : 5; break;
		case 'a': month = cp[1]=='p' ? 4 : 8; break;
		case 's': month = 9; break;
		case 'o': month = 10; break;
		case 'n': month = 11; break;
		case 'd': month = 12; break;
	}
	return(month - 1);
}


/************************************************************************
 * StripInternalXbandAlias: 
 * strip the email-address of domain name if the address is of the form 
 * kXbandPrefix<string>@catapent.com eg. xband-<string>@catapent.com
 ************************************************************************/

static Boolean StripInternalXbandAlias(char *address)
{
    char 	*str;
    Boolean	flag = false;

    if (!strncasecmp(kXbandPrefix, address, strlen(kXbandPrefix))) {
	flag = true;

	str = strrchr(address, '@');
	if (str && !strcmp(str+1, "catapent.com")) {
  	    *str = (char)NULL;
	}
    }

    return(flag);
}

static void
jis2euc(s1, s2)
u_char	*s1, *s2;
{
	int	state = 0;
	u_char	*ss1 = s1, *ss2 = s2;

	while ( *ss2 != '\0' ) {
		if ( *ss2 == 0x1b && *(ss2 + 1) == 0x26 && *(ss2 + 2) == 0x40 &&
			 *(ss2 + 3) == 0x1b && *(ss2 + 4) == 0x24 && *(ss2 + 5) == 0x42 ) {
			state = 1;
			ss2 += 6;
			continue;
		}

		if ( *ss2 == 0x1b && *(ss2 + 1) == 0x24 ) {
			ss2 +=2;
			switch ( *ss2 ) {
			case 0x40:
			case 0x42:
				state = 1;
				ss2++;
				break;
			default:
				break;
			}
			continue;
		}

		if ( *ss2 == 0x1b && *(ss2 + 1) == 0x28 ) {
			ss2 +=2;
			switch ( *ss2 ) {
			case 0x42:
			case 0x4a:
			case 0x48:
				state = 0;
				ss2++;
				break;
			default:
				break;
			}
			continue;
		}

		if ( state == 1 ) {
			*ss1 = *ss2 | 0x80;
			ss1++; ss2++;
			*ss1 = *ss2 | 0x80;
			ss1++; ss2++;
		} else {
			*ss1 = *ss2;
			ss1++; ss2++;
		}
	}

	*ss1 = '\0';

}

static void
decode_mime(str2, str1)
u_char	*str1, *str2;
{
	unsigned char	*ptr1 = str1;
	unsigned char	*ptr2 = str2;
	unsigned char	hexvalue[3];

	hexvalue[0] = hexvalue[1] = hexvalue[2] = 0;

	while ( *ptr1 != 0x0 ) {
		if ( *ptr1 != '=' ) {
			*ptr2 = *ptr1;
			ptr1++;
			ptr2++;
			continue;
		}

		if ( *ptr1 == '=' && *(ptr1 + 1) == 0x0a ) {
			ptr1 += 2;
			continue;
		}

		ptr1++;
		hexvalue[0] = *ptr1;
		ptr1++;
		hexvalue[1] = *ptr1;
		ptr1++;

		if ( !isxdigit(hexvalue[0]) || !isxdigit(hexvalue[1]) ) {
			*ptr2 = '=';
			ptr2++;
			*ptr2 = hexvalue[0];
			ptr2++;
			*ptr2 = hexvalue[1];
			ptr2++;
			continue;
		}

		*ptr2 = (char)strtol(hexvalue, (char **)NULL, 16);
		ptr2++;
	}
}
