/*
 * Copyright: @ 1994 Catapult Entertainment Inc., all rights reserved
 *
 * $Id: mailscan.c,v 1.5 1995/06/28 22:33:55 chs Exp $
 *
 * $Log: mailscan.c,v $
 * Revision 1.5  1995/06/28  22:33:55  chs
 * Be better about recognizing bogus lines in the maillog.
 *
 * Revision 1.4  1995/05/26  23:15:24  jhsia
 * switch to rcs keywords
 *
 *
 * Search for mail in the maillog files.
 *
 * Bugs --> fadden
 */
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>

#ifndef TRUE
# define TRUE	1
# define FALSE	0
#endif

// ===========================================================================
//		Search-related stuff
// ===========================================================================

#define MAX_LINE 512

// Assume most chars will be upper case.
#define MY_TOUPPER(x) ( ((x) >= 'a' && (x) <= 'z') ? (x)-0x20 : (x) )

typedef struct MangledMail {
	char *from_name;
	char *to_name;
	int  from_box;

	char *date;
	char *subject;
	char *message;
} MangledMail;

//
// This should be faster than the original (without using -O, the code
// for this routine is twice as fast using gcc).
//
// Note that this returns, 0, positive, or negative, NOT 0,1,-1.
//
int
Database_CompareStrings(register const char *str1, register const char *str2)
{
	register int c1, c2;

	str1--, str2--;		// you didn't see that
	do {
		// Assume runs of spaces will be short.
		//
		while ((c1 = *++str1) == ' ')
			;
		while ((c2 = *++str2) == ' ')
			;

		if (MY_TOUPPER(c1) != MY_TOUPPER(c2))
			break;
	} while (c1);

	return (MY_TOUPPER(c1) - MY_TOUPPER(c2));
}


//
// Break a mail line down into pieces.  This is really painful.
//
// Returns a pointer to a static MangledMail struct.
//
MangledMail *
MangleMailLine(char *line)
{
	static MangledMail mm;
	char *cp, *comma19;

#ifdef DEBUG2
	printf("MangleMail... '%s'", line);
#endif

	if (! (isdigit(line[0]) && isdigit(line[1]) && line[2] == ':' &&
	       isdigit(line[3]) && isdigit(line[4]) && line[5] == ':' &&
	       isdigit(line[6]) && isdigit(line[7])))
	    return NULL;

	cp = line;
	mm.date = line;

	cp += 9;

	if (*cp == ':') {
	    // new format

	    int title_len;
	    char *cp2;

	    // skip past remaining date stuff
	    cp++;
	    while (*cp != ':')
		cp++;
	    *cp++ = 0;

	    mm.from_name = cp;
	    while (*cp != ':')
		cp++;
	    *cp++ = 0;

	    cp2 = strrchr(mm.from_name, '(');
	    if (cp2) {
		*cp2++ = 0;
		mm.from_box = atoi(cp2);
	    }
	    else {
		mm.from_box = -1;
	    }

	    mm.to_name = cp;
	    while (*cp != ':')
		cp++;
	    *cp++ = 0;

	    title_len = atoi(cp);
	    if (title_len == 0) {
//		fprintf(stderr, "GLITCH: atoi failure '%s'\n", cp);
		return (NULL);
	    }
	    while (*cp != ':')
		cp++;
	    cp++;

	    mm.subject = cp + 1;
	    cp += title_len;
	    *cp++ = 0;

	    mm.message = cp;
	}
	else {

	while (*cp != ':')
		cp++;

	*cp++ = '\0';
	mm.from_name = cp;

	// Can't scan forward.  Scan up to the ",19," (which hopefully nobody
	// will be using in their user name), then scan around from there.
	cp = comma19 = strstr(cp, ",19,");
	if (comma19 == NULL) {
		fprintf(stderr, "GLITCH: strstr failure '%s'\n", line);
		return (NULL);
	}
	while (*cp != '(')
		cp--;

	*cp++ = '\0';
	*comma19 = '\0';
	mm.from_box = atoi(cp);
	if (!mm.from_box) {
		fprintf(stderr, "GLITCH: atoi failure '%s'\n", cp);
		return (NULL);
	}

	cp = comma19 + 1;
	while (*cp != '>')
		cp++;
	*cp++ = '\0';
	mm.to_name = cp;

	while (*cp != ':')
		cp++;
	*(cp - 1) = '\0';
	cp += 2;
	mm.subject = cp;

	while (*cp != ':')
		cp++;
	*(cp - 1) = '\0';
	cp += 2;
	mm.message = cp;

	if (mm.message[strlen(mm.message)-1] == '\n')
		mm.message[strlen(mm.message)-1] = '\0';

	}

#ifdef DEBUGxx
	printf("FOUND:\n");
	printf("\tDATE      '%s'\n", mm.date);
	printf("\tFROM_NAME '%s'\n", mm.from_name);
	printf("\tFROM_BOX  '%d'\n", mm.from_box);
	printf("\tTO_NAME   '%s'\n", mm.to_name);
	printf("\tSUBJECT   '%s'\n", mm.subject);
	printf("\tMESSAGE   '%s'\n", mm.message);
#endif
	return (&mm);
}


//
// Do the actual parsing of mail and figure out if it's worth displaying.
//
void
ScanMail(FILE *fp, char *from_name, int from_box, char *to_name)
{
	MangledMail *mail;
	char linebuf[512];
	int show, show_needed = 0;
	int num_found = 0;

	if (from_box != -1 || from_name != NULL)
		show_needed = 1;
	if (to_name != NULL)
		show_needed |= 2;

	while (1) {
		fgets(linebuf, 512, fp);
		if (feof(fp) || ferror(fp))
			break;

		if ((mail = MangleMailLine(linebuf)) == NULL)
			continue;

		show = 0;
		if (from_name != NULL &&
			Database_CompareStrings(from_name, mail->from_name) == 0)
		{
			show = 1;
		} else if (from_box != -1 && from_box == mail->from_box)
		{
			show = 1;
		}

		if (to_name != NULL &&
			Database_CompareStrings(to_name, mail->to_name) == 0)
		{
			show |= 2;
		}

		if (show == show_needed) {
			printf("%s  %s[%d] --> %s\n    %s : %s\n",
				mail->date, mail->from_name, mail->from_box,
				mail->to_name, mail->subject, mail->message);
			num_found++;
		}
	}

	if (ferror(fp))
		perror("fgets");

	if (!num_found)
		printf("No matches found.\n");

	return;
}


#define ZCAT			"/usr/local/bin/zcat"
#define ROOT_FILE_NAME	"/home/binky/catapult/OLD_LOGS/maillog"
//
// Entry point for the search.  Format of "date" is YYMMDD.
//
// The maillogs are compressed with gzip, so we have to read it through
// a gunzip pipe.
//
// Returns 0 on success, -1 on some sort of error.
//
int
ShowMail(char *date, char *from_name, int from_box, char *to_name)
{
	FILE *fp;
	char cmdline[64];

	sprintf(cmdline, "%s.%s.gz", ROOT_FILE_NAME, date);
	if (access(cmdline, R_OK) < 0) {
		switch (errno) {
		case ENOENT:
			printf("\nFAILED: Mail for that date is not available\n");
			break;
		default:
			printf("failed (err=%d)\n", errno);
			break;
		}
		return (-1);
	}

	sprintf(cmdline, "%s %s.%s.gz", ZCAT, ROOT_FILE_NAME, date);
	if ((fp = popen(cmdline, "r")) == NULL) {
		perror("popen");
		return (-1);
	}

	ScanMail(fp, from_name, from_box, to_name);

	pclose(fp);
	return (0);
}



// ===========================================================================
//		Interface-related garbage
// ===========================================================================

//
// Print something helpful.
//
void
PrintHelp(void)
{
	printf("\tSet up the search criteria, then enter the date you want to\n");
	printf("\tsearch in YYMMDD format (e.g. 950207 for Feb 7 1995).  You\n");
	printf("\tcan search by who the mail is from (specific name or all\n");
	printf("\tusers on that box), who it is to, or both.\n\n");

	printf("\tAt the prompt, either enter a date, or one of the following\n");
	printf("\tcommands.  You only need to type the first letter, and hit\n");
	printf("\treturn.  You will be asked for further information.\n\n");

	printf("\t\tH)elp - this info\n");
	printf("\t\tT)o - set the \"To:\" criteria.\n");
	printf("\t\tF)rom - set the \"From:\" criteria for a user name.\n");
	printf("\t\tB)ox - set the \"From:\" criteria for an entire box.\n");
	printf("\t\tQ)uit - bail.\n");
}


#define MAX_NAME	33
//
// Slightly silly routine.
//
// Returns a pointer to a static string buffer.
//
char *
QuoteName(char *name)
{
	static char qname[MAX_NAME+3];

	sprintf(qname, "'%s'", name);
	return (qname);
}

//
// Slightly silly routine.
//
// Returns a pointer to a static string buffer.
//
char *
BoxName(int box)
{
	static char bname[32];

	sprintf(bname, "Box %d:19:*", box);
	return (bname);
}

//
// Get a string from stdin.
//
// Return value is a pointer to a static string buffer.  Returns NULL if
// only return alone was hit.
//
char *
GetString(char *prompt)
{
	static char strbuf[100];

	printf("%s", prompt);  fflush(stdout);
	fgets(strbuf, 100, stdin);
	if (strbuf[strlen(strbuf)-1] == '\n')
		strbuf[strlen(strbuf)-1] = '\0';
	if (!strlen(strbuf))
		return (NULL);
	else
		return (strbuf);
}


//
// Loop forever, taking commands.
//
void
MainLoop(void)
{
	char *to_name = NULL;
	char *from_name = NULL;
	int from_box = -1;
	char cmdbuf[100];
	int show_help = TRUE, done = FALSE;
	char *cp;

	while (!done) {
		if (show_help) {
			show_help = FALSE;
			PrintHelp();
		}

		printf("\n\nCurrent criteria:  From:%s",
			(from_name == NULL && from_box == -1) ? "<anyone>" :
				(from_name != NULL) ? QuoteName(from_name) : BoxName(from_box));
		printf("  To:%s\n",
			(to_name == NULL) ? "<anyone>" : QuoteName(to_name));

		printf("\n--- Enter command or date (YYMMDD): ");  fflush(stdout);
		fgets(cmdbuf, 100, stdin);
		if (cmdbuf[strlen(cmdbuf)-1] == '\n')
			cmdbuf[strlen(cmdbuf)-1] = '\0';
		if (strlen(cmdbuf) != 6 || !isdigit(cmdbuf[0])) {
			// Must be a command.
			//
			switch (toupper(cmdbuf[0])) {
			case 'Q':
				done = TRUE;
				break;
			case 'H':
			case '?':
				show_help = TRUE;
				break;
			case 'T':
				if (to_name != NULL) {
					free(to_name);
					to_name = NULL;
				}
				cp = GetString("See mail TO what handle (just hit return for none)? ");
				if (cp != NULL)
					to_name = strdup(cp);
				break;
			case 'F':
				if (from_name != NULL) {
					free(from_name);
					from_name = NULL;
				}
				cp = GetString("See mail FROM what handle (just hit return for none)? ");
				if (cp != NULL) {
					from_name = strdup(cp);
					from_box = -1;
				}
				break;
			case 'B':
				cp = GetString("See mail FROM what box # (just hit return for none)? ");
				// gee this got ugly
				if (cp != NULL) {
					from_box = atoi(cp);
					if (!from_box)			// was it garbage?
						from_box = -1;		// yup, nuke from_box
					else {
						if (from_name != NULL)
							free(from_name);
						from_name = NULL;	// nope, keep it, nuke from_name
					}
				} else {
					from_box = -1;
					if (from_name != NULL)
						free(from_name);
					from_name = NULL;
				}
				break;
			default:
				printf("\nUnknown command '%s'; type 'h' for help.\n", cmdbuf);
				break;
			}
		} else {
			// Looks like a date.
			//
			if (from_box == -1 && from_name == NULL && to_name == NULL) {
				printf("You have to specify something to search for.\n");
			} else {
				printf("Searching for mail in maillog.%s...\n\n", cmdbuf);
				ShowMail(cmdbuf, from_name, from_box, to_name);
			}
		}
	}
}


//
// Get args?
//
int
main(int argc, char *argv[])
{
	signal(SIGPIPE, SIG_IGN);
	MainLoop();

	exit(0);
	/*NOTREACHED*/
}

