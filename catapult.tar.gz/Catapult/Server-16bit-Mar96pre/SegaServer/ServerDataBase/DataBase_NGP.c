/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: DataBase_NGP.c,v 1.3 1995/05/28 20:41:11 jhsia Exp $
 *
 * $Log: DataBase_NGP.c,v $
 * Revision 1.3  1995/05/28  20:41:11  jhsia
 * switch to rcs keywords
 *
 */
#ifdef OBSOLETE

/*
	File:		DataBase_NGP.c

	Contains:	xxx put contents here xxx

	Written by:	David Jevans


	Change History (most recent first):

		 <1>	 5/31/94	DJ		first checked in

	To Do:
*/



#include <stdlib.h>

#include "ServerDataBase_priv.h"
#include "Errors.h"

SDBNGP *SDBNGP_New(void)
{
SDBNGP *ngp;
	
	ngp = (SDBNGP *)malloc(sizeof(SDBNGP));
	ASSERT(ngp);
	if(!ngp)
	{
		ERROR_MESG("out of mems");
		return(NULL);
	}

	ngp->ngp = NULL;

	return(ngp);
}

#endif	/*OBSOLETE*/
