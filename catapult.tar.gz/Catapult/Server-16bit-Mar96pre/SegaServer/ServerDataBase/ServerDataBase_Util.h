/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: ServerDataBase_Util.h,v 1.10 1995/11/13 16:10:54 davej Exp $
 *
 * $Log: ServerDataBase_Util.h,v $
 * Revision 1.10  1995/11/13  16:10:54  davej
 * New function prototype for DataBaseUtil_FreeUCA.
 *
 * Revision 1.9  1995/10/03  16:56:47  ted
 * Export snes_MeasureTextBold9Width().
 *
 * Revision 1.8  1995/09/27  18:40:12  hufft
 * added Common_Phone support for Japan Server
 *
 * Revision 1.7  1995/08/02  17:28:37  jhsia
 * altered prototype for DataBaseUtil_CompareStrings() and
 * DataBaseUtil_CompareStrings()
 *
 * Revision 1.6  1995/05/28  20:41:30  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		ServerDataBase_Util.h

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		 <3>	11/30/94	DJ		Added replacementModem param to
									DataBaseUtil_FindAllPlayerAccountsByGamePhone.
		 <2>	11/13/94	ATM		Added proto for MakePhoneNumberUgly.
		 <1>	 11/9/94	DJ		Renamed these routines to be DataBaseUtil_....

	To Do:
*/


#ifndef __ServerDataBase_Util__
#define __ServerDataBase_Util__

#include <sys/types.h>
#include "ServerDataBase.h"


//
// Server calls this to release any message data that is returned by DB queries.
//
void DataBaseUtil_ReleasePreformedMessage(PreformedMessage *msg);
void DataBaseUtil_ReleaseServerNewsPage(ServerNewsPage *page);



//
// These two are currently living in Server_RestoreBox.c
// (so why are they here?)
//
Err DataBaseUtil_FindAllPlayerAccounts(userIdentification *userID, Account **accounts);
Err DataBaseUtil_FindAllPlayerAccountsByGamePhone(phoneNumber *newBoxPhoneNumber, Account **accounts, Boolean replacementModem, long platformID);


Boolean DataBaseUtil_CompareUserIdentifications(userIdentification *challengeUserID, userIdentification *userID);
int DataBaseUtil_CompareStrings(register const u_char *str1, register const u_char *str2);
// In proper fucked-up C style, this returns true if they match, false if different.
Boolean DataBaseUtil_CompareBoxSerialNumbers(BoxSerialNumber *box1, BoxSerialNumber *box2);


void DataBaseUtil_ReleaseServerPlayerInfo(ServerPlayerInfo *splayerInfo);

Err DataBaseUtil_FreeAccount(Account *account);

Err DataBaseUtil_FreeUCA(UCAAccount *ucaAccount);

Err DataBaseUtil_UpdateUserPhoneNumber(Account *account, const phoneNumber *boxPhoneNumber);

long DataBaseUtil_SizeofMail(const Mail *mail);

void DataBaseUtil_FilterName(u_char *in, u_char *out);
u_long DataBaseUtil_ScrambleBoxID(u_long num, Boolean descramble);
short snes_MeasureTextBold9Width( u_char *cString );
int Reconfigure(void);

#endif __ServerDataBase_Util__

