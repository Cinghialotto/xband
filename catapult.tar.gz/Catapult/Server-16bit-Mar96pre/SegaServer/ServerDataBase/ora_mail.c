/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[12];
};
static struct sqlcxp sqlfpn =
{
    11,
    "ora_mail.pc"
};


static unsigned long sqlctx = 0;


static struct sqlexd {
   unsigned int   sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   unused;
            short *cud;
   unsigned char  *sqlest;
            char  *stmt;
   unsigned char  **sqphsv;
   unsigned int   *sqphsl;
            short **sqpind;
   unsigned int   *sqparm;
   unsigned int   **sqparc;
   unsigned char  *sqhstv[14];
   unsigned int   sqhstl[14];
            short *sqindv[14];
   unsigned int   sqharm[14];
   unsigned int   *sqharc[14];
} sqlstm = {8,14};

/* Prototypes */
extern sqlcex(/*_ unsigned long *, struct sqlexd *, struct sqlcxp * _*/);
extern sqlcx2(/*_ unsigned long *, struct sqlexd *, struct sqlcxp * _*/);
extern sqlcte(/*_ unsigned long *, struct sqlexd *, struct sqlcxp * _*/);
extern sqlbuf(/*_ char * _*/);
extern sqlgs2(/*_ char * _*/);
extern sqlora(/*_ unsigned long *, void * _*/);

/* Forms Interface */
static int IAPSUCC = 0;
static int IAPFAIL = 1403;
static int IAPFTL  = 535;
extern sqliem(/*_ char *, int * _*/);

 static char *sq0004 = 
"select mail.from_box ,mail.from_region ,mail.from_player ,mail.from_address \
,mailq.from_icon ,mail.from_color ,mail.from_town ,((mail.date_sent-to_date('0\
1-01-1970','MM-DD-YYYY'))* 86400) ,mail.title ,mail.message  from mail ,mailq \
where (((mailq.box=:b0 and mailq.region=:b1) and mailq.player=:b2) and mailq.m\
ailid=mail.mailid) order by mailq.mailid           ";
 static char *sq0013 = 
"select mailid  from mailq where ((box=:b0 and region=:b1) and player=:b2) or\
der by mailid           ";
typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static short sqlcud0[] =
{8,34,
2,0,0,1,0,0,27,230,0,3,3,0,1,0,1,9,0,0,1,9,0,0,1,10,0,0,
28,0,0,2,12,0,29,242,0,0,0,0,1,0,
42,0,0,3,85,0,4,263,0,4,3,0,1,0,2,3,0,0,1,3,0,0,1,3,0,0,1,3,0,0,
72,0,0,4,361,0,9,345,0,3,3,0,1,0,1,3,0,0,1,3,0,0,1,3,0,0,
98,0,0,4,0,0,13,349,0,10,0,0,1,0,2,3,0,0,2,3,0,0,2,3,0,0,2,9,0,0,2,3,0,0,2,3,0,
0,2,9,0,0,2,3,0,0,2,9,0,0,2,9,0,0,
152,0,0,4,0,0,15,356,0,0,0,0,1,0,
166,0,0,5,85,0,4,491,0,4,3,0,1,0,2,3,0,0,1,3,0,0,1,3,0,0,1,3,0,0,
196,0,0,6,45,0,4,536,0,1,0,0,1,0,2,3,0,0,
214,0,0,7,252,0,3,541,0,14,14,0,1,0,1,3,0,0,1,3,0,0,1,3,0,0,1,3,0,0,1,3,0,0,1,
9,0,0,1,3,0,0,1,3,0,0,1,3,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,1,9,0,0,
284,0,0,8,12,0,29,561,0,0,0,0,1,0,
298,0,0,9,90,0,3,568,0,5,5,0,1,0,1,3,0,0,1,3,0,0,1,3,0,0,1,3,0,0,1,3,0,0,
332,0,0,10,12,0,29,571,0,0,0,0,1,0,
346,0,0,11,14,0,31,576,0,0,0,0,1,0,
360,0,0,12,14,0,31,581,0,0,0,0,1,0,
374,0,0,13,100,0,9,610,0,3,3,0,1,0,1,3,0,0,1,3,0,0,1,3,0,0,
400,0,0,13,0,0,13,613,0,1,0,0,1,0,2,3,0,0,
418,0,0,13,0,0,15,616,0,0,0,0,1,0,
432,0,0,14,42,0,5,618,0,1,1,0,1,0,1,3,0,0,
450,0,0,15,12,0,29,619,0,0,0,0,1,0,
464,0,0,16,98,0,4,646,0,4,3,0,1,0,2,3,0,0,1,3,0,0,1,3,0,0,1,3,0,0,
494,0,0,17,83,0,2,658,0,4,4,0,1,0,1,3,0,0,1,3,0,0,1,3,0,0,1,3,0,0,
524,0,0,18,12,0,29,663,0,0,0,0,1,0,
538,0,0,19,80,0,2,692,0,3,3,0,1,0,1,3,0,0,1,3,0,0,1,3,0,0,
564,0,0,20,12,0,29,698,0,0,0,0,1,0,
};


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include <sqlca.h>

#define	WE_CAN_USE_THE_REAL_HEADERS 0

#if	WE_CAN_USE_THE_REAL_HEADERS
/*
   We can't include any of the actual server header files,
   since ProC doesn't understand C++-style comments.
   kill me.
 */

#include "Server.h"
#include "ServerDataBase.h"
#include "ServerDataBase_priv.h"
#include "Mail.h"
#include "Dates.h"

#else

typedef short Err;
typedef unsigned char DBID;

typedef
struct BoxSerialNumber
{
	long	region;
	long	box;
} BoxSerialNumber;

#define kUserNameSize		34
#define kUserTownSize		34
#define kTitleSize		34

typedef	char			UserName[kUserNameSize];
typedef	char			Hometown[kUserTownSize];

typedef
struct userIdentification
{
	BoxSerialNumber	box;
	unsigned char	userID;
	unsigned char	colorTableID;
	DBID			ROMIconID;
	Hometown		userTown;
	UserName		userName;
} userIdentification;


typedef struct
{
	userIdentification	from;
	userIdentification	to;
	short				serialNumber;
	long				date;
	char				hasThisMailBeenRead;
	char				title[kTitleSize];
	char				message[1];
} Mail;



/*
 * Stuff from ServerDataBase.h
 */

#define kBoxFlag_DisableIncomingMail (1<<2)
#define kBoxFlag_DisableOutgoingMail (1<<3)

enum DatabaseErrors {
	kInvalidUserID 			= -2000,
	kNoSuchUserAccount,
	kNoSuchGameID,
	kDuplicateGameID,
	kPatchVersionNotHigher,
	kAccountInvalid,
	kAddingSystemPatchIsFucked,
	kAccountAlreadyExists,
	kChallengeeWaitingForDifferentGame,
	kChallengeeWaitingForDifferentUser,
	kChallengeeNotAvailable,  		/* -1990 */
	kChallengeeWaitingForAutoMatch,
	kChallengeeTooFar,
	kDifferentRomVersion,
	kOpponentNotRegistered,
	kNoSuchBoxAccount,
	kInvalidArguments,
	kInvalidPhoneNumber,
	kLeaveOnQueue,
	kOpponentIsDialing,
	kOpponentIsDialingForWrongGame,	/* -1980 */
	
	kUnexpectedEOF,
	kUnexpectedCode,
	
	kPOPFileIsUpToDate,
	kNoPOPAvailable,
	kLongDistancePOP,
	kInvalidAreaCode,
	kInvalidPrefix,
	kInvalidExchange,

	kResetDefinite,
	kResetMaybe,					/* -1970 */
	kResetUnknown,

	kCallWaitingFucker,

	kOpponentNotFound,
	kWaitingForAnother,
	kCallingRestricted,
	kDoesNotAcceptChallenges,
	kSpecificToAuto,
	
	kNoPrecreatedBoxAccount,		/* UCA hasn't created you an account.  You cannot log in! */

	kMailNotDelivered_AccountClosed,
	kMailNotDelivered_IncomingMailDisabled,
	kMailNotDelivered_OutgoingMailDisabled,
	kMailNotDelivered_TooManyMails,
	kMailNotDelivered_IncomingMailBlocked,
	kMailNotDelivered_OutgoingMailBlocked,
	kChallengeeBlocksYou,
	kRPCLinkFailed
};

#define kNoError 0
#define kFucked -1
#define kMaxMailsInBox		25

/*
 * from SegaOS/Graphics/SegaIcons.h
 */
enum {
        kFirstReservedIcon = 200,
        kNewPlayerIcon = kFirstReservedIcon,
        kXBANDPlayerIcon
};


/*
 * from pcp_share_defs.h
 */
typedef enum pcp_fld_acct_status {
	PCP_ACCT_STATUS_BETA = 0,
	PCP_ACCT_STATUS_GUEST = 10010,
	/* fully functional, login subject to credit limit check */
	PCP_ACCT_STATUS_ACTIVE =	10100,
		/* still being set up, no logins */
	PCP_ACCT_STATUS_PENDING =	10101,
		/* in arrears, no logins, no longer being charged fees */
	PCP_ACCT_STATUS_SUSPENDED =	10102,
		/* permanently closed */
	PCP_ACCT_STATUS_CLOSED =	10103
} pcp_fld_acct_status_t;


#define LOGP_FLAW 60

/*
 * from SegaOS/Graphics/Dates.h
 */
#define kSpecialDateEscapeMask	0x7FFFFFFF
#define kYearMask				0x7FFF0000
#define kYearShift				16
#define kMonthMask				0x0000F000
#define kMonthShift				12
#define kDayMask				0x00000F80
#define kDayShift				7

#define DateYear(year)		(((year) << kYearShift) & kYearMask )
#define DateMonth(month)	(((month) << kMonthShift) & kMonthMask)
#define DateDay(day)		(((day) << kDayShift) & kDayMask)
#define Date(year, month, day)	(DateYear(year) | DateMonth(month) | DateDay(day))

#define YearOfDate(date)	(((date) & kYearMask) >> kYearShift )
#define MonthOfDate(date)	(((date) & kMonthMask) >> kMonthShift)
#define DayOfDate(date)		(((date) & kDayMask) >> kDayShift)

#endif

#define SETUP_VARCHAR(var, val) { strcpy(var.arr, val); \
				      var.len = strlen(var.arr);}

#define kMaxMessageSize		512

char *sql_error(void);
void ora_init(void);
Err ora_AddMailToIncoming(const Mail *mail);
long ora_GetNumIncomingMail(const userIdentification *userID);
Mail *ora_GetIncomingMail(const userIdentification *userID, long mailIndex);
void ora_MarkMailAsSent(const userIdentification *userID, long mailIndex);
void ora_RemoveSentMail(const userIdentification *userID);
void ora_RemoveMail(const userIdentification *, long);

#define SQL_ERROR	(sqlca.sqlcode < 0)
#define SQL_NOTFOUND	(sqlca.sqlcode == 1403)

/* EXEC SQL whenever notfound goto sql_notfound; */ 
/* EXEC SQL whenever sqlerror goto sql_sqlerror; */ 

char *sql_error(void)
{
    static char buf[1024];
    int buf_len, msg_len;

    buf_len = sizeof buf;
    sqlglm(buf, &buf_len, &msg_len);
    buf[msg_len-1] = 0;

    return buf;
}

void ora_init(void)
{
    /* varchar username[20], password[20]; */ 
struct { unsigned short len; unsigned char arr[20]; } username;
struct { unsigned short len; unsigned char arr[20]; } password;
    static int inited;

    if (inited)
	return;
    inited = 1;

    SETUP_VARCHAR(username, "chs");
    SETUP_VARCHAR(password, "chs2");
    /* EXEC SQL connect :username identified by :password; */ 
{
    sqlstm.iters = (unsigned int  )10;
    sqlstm.offset = (unsigned int  )2;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlstm.sqhstv[0] = (unsigned char  *)&username;
    sqlstm.sqhstl[0] = (unsigned int  )22;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqharm[0] = (unsigned int  )0;
    sqlstm.sqhstv[1] = (unsigned char  *)&password;
    sqlstm.sqhstl[1] = (unsigned int  )22;
    sqlstm.sqindv[1] = (         short *)0;
    sqlstm.sqharm[1] = (unsigned int  )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}

    Logmsg("connected to database \"%s\"\n", getenv("TWO_TASK"));
    return;

  sql_notfound:
  sql_sqlerror:
    Logmsg("connect to oracle failed, %s\n", sql_error());
}


void ora_commit(void)
{
    /* EXEC SQL commit work; */ 
{
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )28;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}

    
  sql_notfound:
  sql_sqlerror:;
}


long ora_GetNumIncomingMail(const userIdentification *user)
{
    int box = user->box.box;
    int region = user->box.region;
    int player = user->userID;
    int nmails = 0;

/*
Logmsg("selecting nmails for user %d,%d,%d\n",
       user->box.box, user->box.region, user->userID);
*/

    ora_init();

    /* EXEC SQL select count(*) into :nmails from mailq
	where box = :box and
	      region = :region and
	      player = :player; */ 
{
    sqlstm.stmt = "select count(*)  into :b0  from mailq where ((box=:b1 and\
 region=:b2) and player=:b3)";
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )42;
    sqlstm.selerr = (unsigned short)1;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlstm.sqhstv[0] = (unsigned char  *)&nmails;
    sqlstm.sqhstl[0] = (unsigned int  )4;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqharm[0] = (unsigned int  )0;
    sqlstm.sqhstv[1] = (unsigned char  *)&box;
    sqlstm.sqhstl[1] = (unsigned int  )4;
    sqlstm.sqindv[1] = (         short *)0;
    sqlstm.sqharm[1] = (unsigned int  )0;
    sqlstm.sqhstv[2] = (unsigned char  *)&region;
    sqlstm.sqhstl[2] = (unsigned int  )4;
    sqlstm.sqindv[2] = (         short *)0;
    sqlstm.sqharm[2] = (unsigned int  )0;
    sqlstm.sqhstv[3] = (unsigned char  *)&player;
    sqlstm.sqhstl[3] = (unsigned int  )4;
    sqlstm.sqindv[3] = (         short *)0;
    sqlstm.sqharm[3] = (unsigned int  )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode == 1403) goto sql_notfound;
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}

    return nmails;

  sql_notfound:
    PLogmsg(LOGP_FLAW, "ORA: getnumincomingnmail NOTFOUND\n");
    return 0;

  sql_sqlerror:
    PLogmsg(LOGP_FLAW, "ORA: getnumincomingnmail SQLERROR %s\n", sql_error());
    return 0;
}

static long Common_TimeToSegaDate(time_t);
static long
Common_TimeToSegaDate(time_t now)
{
    struct tm *tm;

    tm = localtime(&now);

    return(Date(tm->tm_year + 1900, tm->tm_mon, tm->tm_mday));
}

Mail *ora_GetIncomingMail(const userIdentification *user, long whichmail)
{
    Mail *mail;
    int i, sqlop;

    int box = user->box.box;
    int region = user->box.region;
    int player = user->userID;

    int from_box, from_region, from_player, from_icon, from_color;
    time_t date;
    /* varchar
	from_address[kUserNameSize],
	from_town[kUserTownSize],
	title[kTitleSize],
	message[kMaxMessageSize]; */ 
struct { unsigned short len; unsigned char arr[34]; } from_address;
struct { unsigned short len; unsigned char arr[34]; } from_town;
struct { unsigned short len; unsigned char arr[34]; } title;
struct { unsigned short len; unsigned char arr[512]; } message;

    ora_init();

    if (box == -1) {
	/* shouldn't happen.. */
	Logmsg("ORA: getincomingmail requested box == -1 ??\n");
	return NULL;
    }

    if (whichmail < 0) {
	Logmsg("ORA: getincomingmail requested mail %d ??\n", whichmail);
	return NULL;
    }	


    /*
     * GRRN!
     * don't look now, this is a huge hack!
     */
    sqlop = 0;
    /* EXEC SQL declare getincomingmail_cursor cursor for
	select
	    mail.from_box, mail.from_region, mail.from_player,
	    mail.from_address, mailq.from_icon,
	    mail.from_color, mail.from_town,
	    (mail.date_sent - to_date('01-01-1970','MM-DD-YYYY'))*86400,
	    mail.title, mail.message
	    /o
	    into :from_box, :from_region, :from_player,
	    :from_address, :from_icon, :from_color, :from_town,
	    :date, :title, :message;
	    o/
        from mail, mailq
	where mailq.box = :box and
	      mailq.region = :region and
	      mailq.player = :player and
	      mailq.mailid = mail.mailid
	order by mailq.mailid; */ 

    sqlop++;
    /* EXEC SQL open getincomingmail_cursor; */ 
{
    sqlstm.stmt = sq0004;
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )72;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlstm.sqhstv[0] = (unsigned char  *)&box;
    sqlstm.sqhstl[0] = (unsigned int  )4;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqharm[0] = (unsigned int  )0;
    sqlstm.sqhstv[1] = (unsigned char  *)&region;
    sqlstm.sqhstl[1] = (unsigned int  )4;
    sqlstm.sqindv[1] = (         short *)0;
    sqlstm.sqharm[1] = (unsigned int  )0;
    sqlstm.sqhstv[2] = (unsigned char  *)&player;
    sqlstm.sqhstl[2] = (unsigned int  )4;
    sqlstm.sqindv[2] = (         short *)0;
    sqlstm.sqharm[2] = (unsigned int  )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}


    for (i = -1; i < whichmail; i++) {
	sqlop++;
	/* EXEC SQL fetch getincomingmail_cursor
	    into :from_box, :from_region, :from_player,
	    :from_address, :from_icon, :from_color, :from_town,
	    :date, :title, :message; */ 
{
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )98;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)0;
 sqlstm.sqhstv[0] = (unsigned char  *)&from_box;
 sqlstm.sqhstl[0] = (unsigned int  )4;
 sqlstm.sqindv[0] = (         short *)0;
 sqlstm.sqharm[0] = (unsigned int  )0;
 sqlstm.sqhstv[1] = (unsigned char  *)&from_region;
 sqlstm.sqhstl[1] = (unsigned int  )4;
 sqlstm.sqindv[1] = (         short *)0;
 sqlstm.sqharm[1] = (unsigned int  )0;
 sqlstm.sqhstv[2] = (unsigned char  *)&from_player;
 sqlstm.sqhstl[2] = (unsigned int  )4;
 sqlstm.sqindv[2] = (         short *)0;
 sqlstm.sqharm[2] = (unsigned int  )0;
 sqlstm.sqhstv[3] = (unsigned char  *)&from_address;
 sqlstm.sqhstl[3] = (unsigned int  )36;
 sqlstm.sqindv[3] = (         short *)0;
 sqlstm.sqharm[3] = (unsigned int  )0;
 sqlstm.sqhstv[4] = (unsigned char  *)&from_icon;
 sqlstm.sqhstl[4] = (unsigned int  )4;
 sqlstm.sqindv[4] = (         short *)0;
 sqlstm.sqharm[4] = (unsigned int  )0;
 sqlstm.sqhstv[5] = (unsigned char  *)&from_color;
 sqlstm.sqhstl[5] = (unsigned int  )4;
 sqlstm.sqindv[5] = (         short *)0;
 sqlstm.sqharm[5] = (unsigned int  )0;
 sqlstm.sqhstv[6] = (unsigned char  *)&from_town;
 sqlstm.sqhstl[6] = (unsigned int  )36;
 sqlstm.sqindv[6] = (         short *)0;
 sqlstm.sqharm[6] = (unsigned int  )0;
 sqlstm.sqhstv[7] = (unsigned char  *)&date;
 sqlstm.sqhstl[7] = (unsigned int  )4;
 sqlstm.sqindv[7] = (         short *)0;
 sqlstm.sqharm[7] = (unsigned int  )0;
 sqlstm.sqhstv[8] = (unsigned char  *)&title;
 sqlstm.sqhstl[8] = (unsigned int  )36;
 sqlstm.sqindv[8] = (         short *)0;
 sqlstm.sqharm[8] = (unsigned int  )0;
 sqlstm.sqhstv[9] = (unsigned char  *)&message;
 sqlstm.sqhstl[9] = (unsigned int  )514;
 sqlstm.sqindv[9] = (         short *)0;
 sqlstm.sqharm[9] = (unsigned int  )0;
 sqlstm.sqphsv = sqlstm.sqhstv;
 sqlstm.sqphsl = sqlstm.sqhstl;
 sqlstm.sqpind = sqlstm.sqindv;
 sqlstm.sqparm = sqlstm.sqharm;
 sqlstm.sqparc = sqlstm.sqharc;
 sqlcex(&sqlctx, &sqlstm, &sqlfpn);
 if (sqlca.sqlcode == 1403) goto sql_notfound;
 if (sqlca.sqlcode < 0) goto sql_sqlerror;
}

    }

    sqlop++;
    /* EXEC SQL close getincomingmail_cursor; */ 
{
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )152;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}


    mail = malloc(sizeof(Mail) + message.len);
    bzero(mail, sizeof(Mail) + message.len);

    mail->from.box.box = from_box;
    mail->from.box.region = from_region;
    mail->from.userID = from_player;
    mail->from.ROMIconID = from_icon;
    mail->from.colorTableID = from_color;

    mail->to = *user;

  /* XXX deal with SNs */
    mail->serialNumber = 0;
    mail->date = Common_TimeToSegaDate(date);

    strncpy(mail->from.userName, from_address.arr,
	    from_address.len);
    strncpy(mail->from.userTown, from_town.arr, from_town.len);
    strncpy(mail->title, title.arr, title.len);
    strncpy(mail->message, message.arr, message.len);

  /* XXX mark it as read, assign serial number */

    return mail;

  sql_notfound:
    Logmsg("ORA: getincomingmail NOTFOUND on op %d\n", sqlop);
    return NULL;

  sql_sqlerror:
    Logmsg("ORA: getincomingmail SQLERROR on op %d: %s\n", sqlop, sql_error());
    return NULL;
}


#define kDateSize 100

Err ora_StoreMail(const Mail *mail, int dochecks)
{
    int nmails, mailid, err, to_inet, from_inet, from_platform, to_platform;
    int dummy, boxflags, accountstatus;
    /* varchar
	from_name[kUserNameSize],
	from_town[kUserTownSize],
	to_name[kUserNameSize],
	date_sent[kDateSize],
	title[kTitleSize],
	message[kMaxMessageSize]; */ 
struct { unsigned short len; unsigned char arr[34]; } from_name;
struct { unsigned short len; unsigned char arr[34]; } from_town;
struct { unsigned short len; unsigned char arr[34]; } to_name;
struct { unsigned short len; unsigned char arr[100]; } date_sent;
struct { unsigned short len; unsigned char arr[34]; } title;
struct { unsigned short len; unsigned char arr[512]; } message;
    short from_name_ind, to_name_ind;
    userIdentification full_to;
    char datebuf[kDateSize];

    /* Pro*C sux */
    int from_box, from_region, from_player, from_icon, from_color,
	to_box, to_region, to_player;

    /*
     * if sender not internet, get sender's account
     * if sender's outgoing mail disabled, return error
     * get recipient's account
     * if recipient DNE, return error
     * if recipient's incoming mail disabled, return error
     * if recipient's account is closed, return error
     * get recipient's mailq len
     * if recipient's mailq is full, return error
     * convert icon
     * convert "support" mail to "XBAND"
     * add to mail table
     * if to internet, we're done
     * add entry to mailq
     */

    ora_init();

    from_inet = (strchr(mail->from.userName, '@') != NULL);
    to_inet = (strchr(mail->to.userName, '@') != NULL);

    /*
     * uh, hack?
     * we want to store the "to" user's boxid in Oracle,
     * not just the string.  but if the user just types the name in
     * (as opposed to replying to a previous mail),
     * all we get is the string.
     */
    if (mail->to.box.box == -1 && !to_inet) {
	err = DataBase_FindUserIdentification(&mail->to, &full_to);
	if (err != kNoError) {
	    return err;
	}
	((Mail *)mail)->to = full_to;
    }

    from_box = mail->from.box.box;
    from_region = mail->from.box.region;
    from_player = mail->from.userID;
    from_icon = mail->from.ROMIconID;
    from_color = mail->from.colorTableID;
    to_box = mail->to.box.box;
    to_region = mail->to.box.region;
    to_player = mail->to.userID;

#if 1
    /* for now, always store the name */
    from_name_ind = to_name_ind = 0;
#else
    from_name_ind = from_inet ? 0 : -1;
    to_name_ind = to_inet ? 0 : -1;
#endif

    if (! from_inet && dochecks) {
	err = oramail_GetInfo(&mail->from, &from_platform,
			     &boxflags, &dummy);
	if (err)
	    return err;

	if (boxflags & kBoxFlag_DisableOutgoingMail) {
	    return kMailNotDelivered_OutgoingMailDisabled;
	}
    }
    if (! to_inet && dochecks) {
	err = oramail_GetInfo(&mail->to, &to_platform,
			     &boxflags, &accountstatus);
	if (err)
	    return err;

	if (boxflags & kBoxFlag_DisableIncomingMail) {
	    return kMailNotDelivered_IncomingMailDisabled;
	}

	if (accountstatus == PCP_ACCT_STATUS_CLOSED) {
	    return kMailNotDelivered_AccountClosed;
	}

	/* EXEC SQL select count(*) into :nmails from mailq
	    where box = :to_box and
		  region = :to_region and
		  player = :to_player; */ 
{
 sqlstm.stmt = "select count(*)  into :b0  from mailq where ((box=:b1 and re\
gion=:b2) and player=:b3)";
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )166;
 sqlstm.selerr = (unsigned short)1;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)0;
 sqlstm.sqhstv[0] = (unsigned char  *)&nmails;
 sqlstm.sqhstl[0] = (unsigned int  )4;
 sqlstm.sqindv[0] = (         short *)0;
 sqlstm.sqharm[0] = (unsigned int  )0;
 sqlstm.sqhstv[1] = (unsigned char  *)&to_box;
 sqlstm.sqhstl[1] = (unsigned int  )4;
 sqlstm.sqindv[1] = (         short *)0;
 sqlstm.sqharm[1] = (unsigned int  )0;
 sqlstm.sqhstv[2] = (unsigned char  *)&to_region;
 sqlstm.sqhstl[2] = (unsigned int  )4;
 sqlstm.sqindv[2] = (         short *)0;
 sqlstm.sqharm[2] = (unsigned int  )0;
 sqlstm.sqhstv[3] = (unsigned char  *)&to_player;
 sqlstm.sqhstl[3] = (unsigned int  )4;
 sqlstm.sqindv[3] = (         short *)0;
 sqlstm.sqharm[3] = (unsigned int  )0;
 sqlstm.sqphsv = sqlstm.sqhstv;
 sqlstm.sqphsl = sqlstm.sqhstl;
 sqlstm.sqpind = sqlstm.sqindv;
 sqlstm.sqparm = sqlstm.sqharm;
 sqlstm.sqparc = sqlstm.sqharc;
 sqlcex(&sqlctx, &sqlstm, &sqlfpn);
 if (sqlca.sqlcode == 1403) goto sql_notfound;
 if (sqlca.sqlcode < 0) goto sql_sqlerror;
}


	if (nmails > kMaxMailsInBox) {
	    return kMailNotDelivered_TooManyMails;
	}
    }

    if ((strcmp(mail->from.userName, "support@catapent.com") == 0) ||
	(strcmp(mail->from.userName, "beta@catapent.com") == 0))
    {
	strcpy((char *)mail->from.userName, "XBAND");
	strcpy((char *)mail->from.userTown, "Cupertino, CA");
	from_icon = kXBANDPlayerIcon;
    }

/*
Logmsg("from platform = %x, to_platform = %x, from_icon = %d\n",
       from_platform, to_platform, from_icon);
*/
    if (!to_inet && !from_inet && dochecks) {
	from_icon = Common_ConvertROMIconID(from_platform, to_platform,
					    from_icon);
    }

    sprintf(datebuf, "%02d-%02d-%04d",
	    MonthOfDate(mail->date) + 1,
	    DayOfDate(mail->date),
	    YearOfDate(mail->date));

    SETUP_VARCHAR(from_name, mail->from.userName);
    SETUP_VARCHAR(from_town, mail->from.userTown);
    SETUP_VARCHAR(to_name, mail->to.userName);
    SETUP_VARCHAR(title, mail->title);
    SETUP_VARCHAR(message, mail->message);
    SETUP_VARCHAR(date_sent, datebuf);

/*
Logmsg("from_name = %s, and will %sbe stored\n",
       from_name.arr, from_name_ind == -1 ? "not " : "");
Logmsg("sql: getting new mailid\n");
*/

    /* EXEC SQL select mail_seq.nextval into :mailid from dual; */ 
{
    sqlstm.stmt = "select mail_seq.nextval  into :b0  from dual ";
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )196;
    sqlstm.selerr = (unsigned short)1;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlstm.sqhstv[0] = (unsigned char  *)&mailid;
    sqlstm.sqhstl[0] = (unsigned int  )4;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqharm[0] = (unsigned int  )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode == 1403) goto sql_notfound;
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}


/*
Logmsg("sql: inserting mail id %d\n", mailid);
*/
    /* EXEC SQL insert into mail
	(mailid, from_box, from_region, from_player, from_color, from_town,
	 to_box, to_region, to_player, date_sent,
	 title, from_address, to_address, message)
	values (:mailid,
		:from_box,
		:from_region,
		:from_player,
		:from_color,
		:from_town,
		:to_box,
		:to_region,
		:to_player,
		to_date(:date_sent,'MM-DD-YYYY'),
		:title,
		:from_name:from_name_ind,
		:to_name:to_name_ind,
		:message ); */ 
{
    sqlstm.stmt = "insert into mail(mailid,from_box,from_region,from_player,\
from_color,from_town,to_box,to_region,to_player,date_sent,title,from_address,t\
o_address,message) values (:b0,:b1,:b2,:b3,:b4,:b5,:b6,:b7,:b8,to_date(:b9,'MM\
-DD-YYYY'),:b10,:b11:b12,:b13:b14,:b15)";
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )214;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlstm.sqhstv[0] = (unsigned char  *)&mailid;
    sqlstm.sqhstl[0] = (unsigned int  )4;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqharm[0] = (unsigned int  )0;
    sqlstm.sqhstv[1] = (unsigned char  *)&from_box;
    sqlstm.sqhstl[1] = (unsigned int  )4;
    sqlstm.sqindv[1] = (         short *)0;
    sqlstm.sqharm[1] = (unsigned int  )0;
    sqlstm.sqhstv[2] = (unsigned char  *)&from_region;
    sqlstm.sqhstl[2] = (unsigned int  )4;
    sqlstm.sqindv[2] = (         short *)0;
    sqlstm.sqharm[2] = (unsigned int  )0;
    sqlstm.sqhstv[3] = (unsigned char  *)&from_player;
    sqlstm.sqhstl[3] = (unsigned int  )4;
    sqlstm.sqindv[3] = (         short *)0;
    sqlstm.sqharm[3] = (unsigned int  )0;
    sqlstm.sqhstv[4] = (unsigned char  *)&from_color;
    sqlstm.sqhstl[4] = (unsigned int  )4;
    sqlstm.sqindv[4] = (         short *)0;
    sqlstm.sqharm[4] = (unsigned int  )0;
    sqlstm.sqhstv[5] = (unsigned char  *)&from_town;
    sqlstm.sqhstl[5] = (unsigned int  )36;
    sqlstm.sqindv[5] = (         short *)0;
    sqlstm.sqharm[5] = (unsigned int  )0;
    sqlstm.sqhstv[6] = (unsigned char  *)&to_box;
    sqlstm.sqhstl[6] = (unsigned int  )4;
    sqlstm.sqindv[6] = (         short *)0;
    sqlstm.sqharm[6] = (unsigned int  )0;
    sqlstm.sqhstv[7] = (unsigned char  *)&to_region;
    sqlstm.sqhstl[7] = (unsigned int  )4;
    sqlstm.sqindv[7] = (         short *)0;
    sqlstm.sqharm[7] = (unsigned int  )0;
    sqlstm.sqhstv[8] = (unsigned char  *)&to_player;
    sqlstm.sqhstl[8] = (unsigned int  )4;
    sqlstm.sqindv[8] = (         short *)0;
    sqlstm.sqharm[8] = (unsigned int  )0;
    sqlstm.sqhstv[9] = (unsigned char  *)&date_sent;
    sqlstm.sqhstl[9] = (unsigned int  )102;
    sqlstm.sqindv[9] = (         short *)0;
    sqlstm.sqharm[9] = (unsigned int  )0;
    sqlstm.sqhstv[10] = (unsigned char  *)&title;
    sqlstm.sqhstl[10] = (unsigned int  )36;
    sqlstm.sqindv[10] = (         short *)0;
    sqlstm.sqharm[10] = (unsigned int  )0;
    sqlstm.sqhstv[11] = (unsigned char  *)&from_name;
    sqlstm.sqhstl[11] = (unsigned int  )36;
    sqlstm.sqindv[11] = (         short *)&from_name_ind;
    sqlstm.sqharm[11] = (unsigned int  )0;
    sqlstm.sqhstv[12] = (unsigned char  *)&to_name;
    sqlstm.sqhstl[12] = (unsigned int  )36;
    sqlstm.sqindv[12] = (         short *)&to_name_ind;
    sqlstm.sqharm[12] = (unsigned int  )0;
    sqlstm.sqhstv[13] = (unsigned char  *)&message;
    sqlstm.sqhstl[13] = (unsigned int  )514;
    sqlstm.sqindv[13] = (         short *)0;
    sqlstm.sqharm[13] = (unsigned int  )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}


    if (to_inet) {
	/* EXEC SQL commit work; */ 
{
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )284;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)0;
 sqlcex(&sqlctx, &sqlstm, &sqlfpn);
 if (sqlca.sqlcode < 0) goto sql_sqlerror;
}

	return kNoError;
    }

/*
Logmsg("sql: inserting mailq\n");
*/
    /* EXEC SQL insert into mailq (box, region, player, from_icon, mailid, flags)
	values (:to_box, :to_region, :to_player, :from_icon, :mailid, 0); */ 
{
    sqlstm.stmt = "insert into mailq(box,region,player,from_icon,mailid,flag\
s) values (:b0,:b1,:b2,:b3,:b4,0)";
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )298;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlstm.sqhstv[0] = (unsigned char  *)&to_box;
    sqlstm.sqhstl[0] = (unsigned int  )4;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqharm[0] = (unsigned int  )0;
    sqlstm.sqhstv[1] = (unsigned char  *)&to_region;
    sqlstm.sqhstl[1] = (unsigned int  )4;
    sqlstm.sqindv[1] = (         short *)0;
    sqlstm.sqharm[1] = (unsigned int  )0;
    sqlstm.sqhstv[2] = (unsigned char  *)&to_player;
    sqlstm.sqhstl[2] = (unsigned int  )4;
    sqlstm.sqindv[2] = (         short *)0;
    sqlstm.sqharm[2] = (unsigned int  )0;
    sqlstm.sqhstv[3] = (unsigned char  *)&from_icon;
    sqlstm.sqhstl[3] = (unsigned int  )4;
    sqlstm.sqindv[3] = (         short *)0;
    sqlstm.sqharm[3] = (unsigned int  )0;
    sqlstm.sqhstv[4] = (unsigned char  *)&mailid;
    sqlstm.sqhstl[4] = (unsigned int  )4;
    sqlstm.sqindv[4] = (         short *)0;
    sqlstm.sqharm[4] = (unsigned int  )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}


    /* EXEC SQL commit work; */ 
{
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )332;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}

    return kNoError;

  sql_notfound:
    Logmsg("ORA: addmailtoincoming NOTFOUND\n");
    /* EXEC SQL rollback work; */ 
{
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )346;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}

    return kFucked;
    
  sql_sqlerror:
    Logmsg("ORA: addmailtoincoming SQLERROR: %s\n", sql_error());
    /* EXEC SQL rollback work; */ 
{
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )360;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}

    return kFucked;
}

void ora_MarkMailAsSent(const userIdentification *user, long whichmail)
{
    int i, mailid;
    int box = user->box.box;
    int region = user->box.region;
    int player = user->userID;

    ora_init();

    /*
     * don't look now, it's another BIG HACK
     */

/*
Logmsg("markmailassent: selecting for mailids for %d,%d,%d\n",
       box, region, player);
*/

    /* EXEC SQL declare markmailassent_cursor cursor for
	select mailid from mailq
	    where box = :box and
	       region = :region and
	       player = :player
	    order by mailid; */ 

    /* EXEC SQL open markmailassent_cursor; */ 
{
    sqlstm.stmt = sq0013;
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )374;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlstm.sqhstv[0] = (unsigned char  *)&box;
    sqlstm.sqhstl[0] = (unsigned int  )4;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqharm[0] = (unsigned int  )0;
    sqlstm.sqhstv[1] = (unsigned char  *)&region;
    sqlstm.sqhstl[1] = (unsigned int  )4;
    sqlstm.sqindv[1] = (         short *)0;
    sqlstm.sqharm[1] = (unsigned int  )0;
    sqlstm.sqhstv[2] = (unsigned char  *)&player;
    sqlstm.sqhstl[2] = (unsigned int  )4;
    sqlstm.sqindv[2] = (         short *)0;
    sqlstm.sqharm[2] = (unsigned int  )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}


    for (i = -1; i < whichmail; i++) {
	/* EXEC SQL fetch markmailassent_cursor into :mailid; */ 
{
 sqlstm.iters = (unsigned int  )1;
 sqlstm.offset = (unsigned int  )400;
 sqlstm.cud = sqlcud0;
 sqlstm.sqlest = (unsigned char  *)&sqlca;
 sqlstm.sqlety = (unsigned short)0;
 sqlstm.sqhstv[0] = (unsigned char  *)&mailid;
 sqlstm.sqhstl[0] = (unsigned int  )4;
 sqlstm.sqindv[0] = (         short *)0;
 sqlstm.sqharm[0] = (unsigned int  )0;
 sqlstm.sqphsv = sqlstm.sqhstv;
 sqlstm.sqphsl = sqlstm.sqhstl;
 sqlstm.sqpind = sqlstm.sqindv;
 sqlstm.sqparm = sqlstm.sqharm;
 sqlstm.sqparc = sqlstm.sqharc;
 sqlcex(&sqlctx, &sqlstm, &sqlfpn);
 if (sqlca.sqlcode == 1403) goto sql_notfound;
 if (sqlca.sqlcode < 0) goto sql_sqlerror;
}

    }
    
    /* EXEC SQL close markmailassent_cursor; */ 
{
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )418;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}


    /* EXEC SQL update mailq set flags = 1 where mailid = :mailid; */ 
{
    sqlstm.stmt = "update mailq  set flags=1 where mailid=:b0";
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )432;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlstm.sqhstv[0] = (unsigned char  *)&mailid;
    sqlstm.sqhstl[0] = (unsigned int  )4;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqharm[0] = (unsigned int  )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode == 1403) goto sql_notfound;
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}

    /* EXEC SQL commit work; */ 
{
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )450;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}

    return;

  sql_notfound:
    Logmsg("ORA: markmailassent NOTFOUND\n");
    return;
  sql_sqlerror:
    Logmsg("ORA: markmailassent SQLERROR: %s\n", sql_error());
    return;
}


void
ora_RemoveMail(const userIdentification *user, long whichmail)
{
    int mailids[kMaxMailsInBox], nmails;
    int box = user->box.box;
    int region = user->box.region;
    int player = user->userID;

    ora_init();

    /*
     * get num mails in queue for user
     * if whichmail > num in queue, error
     */

    /* EXEC SQL select mailid into :mailids from mailq
	where box = :box and
	      region = :region and
	      player = :player
	order by mailid; */ 
{
    sqlstm.stmt = "select mailid into :b0  from mailq where ((box=:b1 and re\
gion=:b2) and player=:b3) order by mailid";
    sqlstm.iters = (unsigned int  )25;
    sqlstm.offset = (unsigned int  )464;
    sqlstm.selerr = (unsigned short)1;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlstm.sqhstv[0] = (unsigned char  *)mailids;
    sqlstm.sqhstl[0] = (unsigned int  )4;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqharm[0] = (unsigned int  )25;
    sqlstm.sqharc[0] = (unsigned int   *)0;
    sqlstm.sqhstv[1] = (unsigned char  *)&box;
    sqlstm.sqhstl[1] = (unsigned int  )4;
    sqlstm.sqindv[1] = (         short *)0;
    sqlstm.sqharm[1] = (unsigned int  )0;
    sqlstm.sqhstv[2] = (unsigned char  *)&region;
    sqlstm.sqhstl[2] = (unsigned int  )4;
    sqlstm.sqindv[2] = (         short *)0;
    sqlstm.sqharm[2] = (unsigned int  )0;
    sqlstm.sqhstv[3] = (unsigned char  *)&player;
    sqlstm.sqhstl[3] = (unsigned int  )4;
    sqlstm.sqindv[3] = (         short *)0;
    sqlstm.sqharm[3] = (unsigned int  )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode == 1403) goto sql_notfound;
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}


    nmails = sqlca.sqlerrd[2];

    if (whichmail > nmails) {
	return;
    }

    /* EXEC SQL delete mailq
	where mailid = :mailids[whichmail] and
	      box = :box and
	      region = :region and
	      player = :player; */ 
{
    sqlstm.stmt = "delete from mailq  where (((mailid=:b0 and box=:b1) and r\
egion=:b2) and player=:b3)";
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )494;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlstm.sqhstv[0] = (unsigned char  *)&mailids[whichmail];
    sqlstm.sqhstl[0] = (unsigned int  )4;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqharm[0] = (unsigned int  )0;
    sqlstm.sqhstv[1] = (unsigned char  *)&box;
    sqlstm.sqhstl[1] = (unsigned int  )4;
    sqlstm.sqindv[1] = (         short *)0;
    sqlstm.sqharm[1] = (unsigned int  )0;
    sqlstm.sqhstv[2] = (unsigned char  *)&region;
    sqlstm.sqhstl[2] = (unsigned int  )4;
    sqlstm.sqindv[2] = (         short *)0;
    sqlstm.sqharm[2] = (unsigned int  )0;
    sqlstm.sqhstv[3] = (unsigned char  *)&player;
    sqlstm.sqhstl[3] = (unsigned int  )4;
    sqlstm.sqindv[3] = (         short *)0;
    sqlstm.sqharm[3] = (unsigned int  )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode == 1403) goto sql_notfound;
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}

    /* EXEC SQL commit work; */ 
{
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )524;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}

    return;

  sql_notfound:
    Logmsg("ORA: removemail NOTFOUND\n");
    return;
  sql_sqlerror:
    Logmsg("ORA: removemail SQLERROR: %s\n", sql_error());
    return;
}


void
ora_RemoveSentMail(const userIdentification *user)
{
    int mailids[kMaxMailsInBox], nmails;
    int box = user->box.box;
    int region = user->box.region;
    int player = user->userID;

    ora_init();

    /*
     * XXX
     * delete all mailq entries with the "sent" bit on.
     * currently this is the only bit that can be set, so
     * just check for (flags == 1).
     */

    /* EXEC SQL delete mailq
	where box = :box and
	      region = :region and
	      player = :player and
	      flags = 1; */ 
{
    sqlstm.stmt = "delete from mailq  where (((box=:b0 and region=:b1) and p\
layer=:b2) and flags=1)";
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )538;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlstm.sqhstv[0] = (unsigned char  *)&box;
    sqlstm.sqhstl[0] = (unsigned int  )4;
    sqlstm.sqindv[0] = (         short *)0;
    sqlstm.sqharm[0] = (unsigned int  )0;
    sqlstm.sqhstv[1] = (unsigned char  *)&region;
    sqlstm.sqhstl[1] = (unsigned int  )4;
    sqlstm.sqindv[1] = (         short *)0;
    sqlstm.sqharm[1] = (unsigned int  )0;
    sqlstm.sqhstv[2] = (unsigned char  *)&player;
    sqlstm.sqhstl[2] = (unsigned int  )4;
    sqlstm.sqindv[2] = (         short *)0;
    sqlstm.sqharm[2] = (unsigned int  )0;
    sqlstm.sqphsv = sqlstm.sqhstv;
    sqlstm.sqphsl = sqlstm.sqhstl;
    sqlstm.sqpind = sqlstm.sqindv;
    sqlstm.sqparm = sqlstm.sqharm;
    sqlstm.sqparc = sqlstm.sqharc;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode == 1403) goto sql_notfound;
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}


    /* EXEC SQL commit work; */ 
{
    sqlstm.iters = (unsigned int  )1;
    sqlstm.offset = (unsigned int  )564;
    sqlstm.cud = sqlcud0;
    sqlstm.sqlest = (unsigned char  *)&sqlca;
    sqlstm.sqlety = (unsigned short)0;
    sqlcex(&sqlctx, &sqlstm, &sqlfpn);
    if (sqlca.sqlcode < 0) goto sql_sqlerror;
}

    return;

  sql_notfound:
/*
    this happens normally when the user connected but has no mail.
    Logmsg("ORA: removesentmail NOTFOUND\n");
*/
    return;
  sql_sqlerror:
    Logmsg("ORA: removesentmail SQLERROR: %s\n", sql_error());
    return;
}


#if	TESTMAIN
extern double drand48();
#define USERS 10000
#define RANDOM_BOX(x) ((int)(drand48() * (double)(x)))

void create_bogus_mail(int from, int to);
void read_bogus_mail(int whichuser);
int main(int argc, char **argv);

void create_bogus_mail(int from, int to)
{
    Mail *mail;
    mail = malloc(sizeof(Mail) + 100);
    bzero(mail, sizeof(Mail) + 100);

    mail->from.box.box = from;
    mail->from.box.region = 19;
    mail->from.userID = 0;

    mail->to.box.box = to;
    mail->to.box.region = 19;
    mail->to.userID = 0;

#if	DEBUG
printf("from %d to %d\n", mail->from.box.box, mail->to.box.box);
#endif

    strcpy(mail->title, "my title");
    strcpy(mail->message, "this is the body");

    AddMailToIncoming(mail);
    free(mail);
}

void read_bogus_mail(int whichuser)
{
    userIdentification user;
    int i, nmails;

    user.box.box = whichuser;
    user.box.region = 19;
    user.userID = 0;

    nmails = GetNumIncomingMail(&user);
printf("user %d has %d mails\n", whichuser, nmails);
    for (i = 0; i < nmails; i++) {
	Mail *mail;

	mail = GetIncomingMail(&user, i);
	if (!mail) {
	    printf("couldn't get mail %d for user %d\n", i, whichuser);
	}
/*
	printf("from (%d,%d,%d) to (%d,%d,%d): %s : %s\n",
	       mail->from.box.box,
	       mail->from.box.region,
	       mail->from.userID,
	       mail->to.box.box,
	       mail->to.box.region,
	       mail->to.userID,
	       mail->title,
	       mail->message);
*/

	free(mail);
    }
}

main(int argc, char **argv)
{
    int i;

    ora_init();

#if	DEBUG
    printf("\nConnected to ORACLE as user: %s\n", username.arr);
#endif
    srand48(time(0));

    if (argc != 2) {
	printf("usage: %s [send | read]\n", argv[0]);
	exit(1);
    }

    if (!strcmp(argv[1], "send")) {
	for (i = 0; i < 1000; i++) {
	    create_bogus_mail(RANDOM_BOX(USERS),RANDOM_BOX(USERS));
	}
    }

    if (!strcmp(argv[1], "read")) {
	for (i = 0; i < USERS; i++) {
	    read_bogus_mail(i);
	}
    }

    EXEC SQL commit work release;
    exit(0);
}
#endif
