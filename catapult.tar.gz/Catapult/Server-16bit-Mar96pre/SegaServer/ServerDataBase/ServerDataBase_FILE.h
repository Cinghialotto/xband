/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: ServerDataBase_FILE.h,v 1.6 1995/09/13 14:15:39 ted Exp $
 *
 * $Log: ServerDataBase_FILE.h,v $
 * Revision 1.6  1995/09/13  14:15:39  ted
 * Fixed warnings.
 *
 * Revision 1.5  1995/05/28  20:41:29  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		ServerDataBase_FILE.h

	Contains:	xxx put contents here xxx

	Written by:	David Jevans


	Change History (most recent first):

		 <7>	 9/28/94	ATM		Added kSDBNewSaveFormat and kSDBStartOfBox.
		 <6>	 8/16/94	ATM		Added kSDB_GamePatchFile.
		 <5>	  8/8/94	ATM		Added kSDB_NewsFile.
		 <4>	  8/5/94	DJ		make work on mac
		 <3>	  8/3/94	ATM		Added kSDB_BMail.
		 <2>	 6/30/94	DJ		system patch file prefix
		 <1>	 5/31/94	DJ		save and restore database to file

	To Do:
*/


#ifndef __ServerDataBase_FILE__
#define __ServerDataBase_FILE__

#define kSDBFILE	"ServerDB.save"

typedef long	SDBCode;

#define kSDBCode_Server		0x73766462	// 'svdb' obsolete
#define kSDBCode_System		1

#define	kSDBNewerSaveFormat	0x7a736462	// 'zsdb' newer save format
#define kSDBNewSaveFormat	0x6e736462	// 'nsdb' new save format
#define kSDBStartOfBox		0x61626f78	// 'abox' sync token
#define kSDBEndOfData		0x64656e64	// 'dend' sync token


#define kSDB_BMail		"BroadcastMail"
#define kSDB_NewsFile	"NewsPages"
#define kSDB_GamePatchFile	"Patches.smsgs"
#define kSDB_CookieFile "CookieFile"


#define kSDB_SystemPatchFilenameLength	1000
#define kSDB_SystemPatchFilePrefix		"SystemPatch"



#endif __ServerDataBase_FILE__

