/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: ServerDataBase_priv.h,v 1.27 1996/01/10 14:51:54 hufft Exp $
 *
 * $Log: ServerDataBase_priv.h,v $
 * Revision 1.27  1996/01/10  14:51:54  hufft
 * use libphonedb
 *
 * Revision 1.26  1996/01/04  22:56:12  hufft
 * added pop mail
 *
 * Revision 1.25  1995/11/14  20:29:00  hufft
 * rename DataBase_LoadCompuServePops to PhoneDB_Load
 *
 * Revision 1.24  1995/09/13  14:15:40  ted
 * Fixed warnings.
 *
 * Revision 1.23  1995/08/21  13:19:59  steveb
 * Caching rpc.segad re-checkin.
 *
 * Revision 1.22  1995/08/15  19:01:15  steveb
 * Revert to Revision 1.20
 *
 * Revision 1.21  1995/08/11  17:39:59  steveb
 * Caching rpc.segad checkin.  Changes too numerous to mention.
 *
 * Revision 1.20  1995/08/02  17:24:43  jhsia
 * altered prototype for Database_FindUserByHandle(), IsHandleWidthLegal(), and
 * Database_FindUserByName()
 *
 * Revision 1.19  1995/07/17  12:24:39  ted
 * Make PhoneDB_Reload return long.
 *
 * Revision 1.18  1995/06/19  20:59:07  fadden
 * Prototypes for HWID searches.
 *
 * Revision 1.17  1995/06/01  15:14:50  fadden
 * Merge in from newbr.
 * -> Prototype for new phone search routine.
 *
 * Revision 1.16  1995/05/28  20:41:30  jhsia
 * switch to rcs keywords
 *
 */

#ifndef __ServerDataBase_priv__
#define __ServerDataBase_priv__

#include <stdio.h>
#include "ServerDataBase.h"
#include "GameDB.h"
#include "Common_List.h"
#include "ServerDataBase_FILE.h"

//
// DB mail header.
//

typedef struct SDBMail {
	Mail	*mail;
	Boolean	sentToBox;
} SDBMail;

//
// DB news header.
//
typedef struct SDBNewsPaper {
	DBType		pageType;
	ListHead	*pageList;		// list of ServerNewsPage;
} SDBNewsPaper;

//
// DB news header.
//
typedef struct SDBNews {
	ListHead	*paperList;		// list of SDBNewsPaper;
	ListHead        *animList;  // list of animations (DbItem)
} SDBNews;

//
// User database
//

typedef struct SDBUser {
	short				mailSerialNumber;
	ListHead			*incomingMail;
	long				lastBroadcastMailSent;
	PlayerAccount		playerAccount;
} SDBUser;

typedef struct SDBBox {
	SDBUser		*users[4];
	BoxAccount	boxAccount;
	UserAccount	userAccount;
	UCAInfo		ucaInfo;
} SDBBox;

// Opacity is for punks
//
// (struct SDBBoxListPrivate only exists inside DataBase_UserAccess.c)
//
typedef struct SDBBoxListPrivate *SDBBoxList;

typedef struct SDBUsers {
	long		timeStamp;
	long		uniqueBoxSerialNumber;
	long 		numUsers;
#ifdef OLD_LINKED_LIST_SHIT
	ListHead	*list;
#else
#  ifndef __DUMPSAVE__
	SDBBoxList	list;
#  else
	/*#error "DUMPSAVE is now busted";*/
	ListHead	*list;		// no it isn't
#  endif
#endif
} SDBUsers;

//
// Game patches.
//
typedef struct SDBGameNode {
	long				platformID;		// should be boxType?
	long				gameID;
	long				version;
	char				gameName[kGameNameSize];
	PreformedMessage	*patch;
	//ListHead			*rankings;
} SDBGameNode;

typedef struct SDBGames {
	ListHead	*list;
	//long		opponentMagicCookie;
} SDBGames;


#ifdef NOT_USED
//
// Network Game Patch list
//
typedef struct SDBNGP {
	NGPData	*ngp;
} SDBNGP;

SDBNGP *SDBNGP_New(void);
#endif

//
// list of system updates
// some are keyframes, some are incremental updates
//
typedef struct SDBSystemNode {
	long 				version;
	Boolean				keyframe;
	long				numPatches;
	PreformedMessage	**patches;
} SDBSystemNode;

typedef struct SDBSystem {
	ListHead	*list;
} SDBSystem;

//
// the Server DataBase
//
typedef struct SDB {
	SDBSystem	*system;
	//SDBNGP		*ngp;
	SDBGames	*games;
	SDBUsers	*users;
	SDBNews		*news;
	ListHead	*broadcastMail;
} SDB;

// Main database creation and get routines
//
SDB *SDB_New(void);
Err SDB_Dispose(SDB *sdb);
Err SDB_Save(FILE *fp);
Err SDBBox_Write(SDBBox *box, void *foo);
Err SDB_Restore(FILE *fp, int backup);
void SDBBox_Free(SDBBox *box);
SDBBox *SDBBox_Read(FILE *fp, long file_version);

SDBSystem *SDB_GetSystem(SDB *sdb);
SDBUsers *SDB_GetUsers(SDB *sdb);
//SDBNGP *SDB_GetNGP(SDB *sdb);
SDBGames *SDB_GetGames(SDB *sdb);
SDBNews *SDB_GetNews(SDB *sdb);

// System creation and assorted routines
//
SDBSystem *SDBSystem_New(void);
Err SDBSystem_Save(FILE *fp);
Err SDBSystem_Restore(FILE *fp);
Err SDBSystem_Print(void);
Err SDBSystem_LoadSystemPatches(void);

// Uniquifier
//
Boolean DataBase_UniquifyHandle(userIdentification *userID, long platformID);
Boolean IsHandleWidthLegal(u_char *cString, long platformID);
#define kMaxNameUnique 8192

// PlayerAccount and BoxAccount internal routines
//
Err DataBase_InitBoxAccount(SDBBox *box);
Err DataBase_InitUserAccount(SDBBox *box);
Err DataBase_InitPlayerAccount(SDBUser *user);

// Users (a holder for the list of user accounts).
//
SDBUsers *SDBUsers_New(void);

// Game routines
//
SDBGames *SDBGames_New(void);
SDBGameNode *Database_FindGame(long platformID, long gameID);
//long Database_NewOpponentMagicCookie(void);

// Handy treats
//
Mail *Database_DuplicateMail(const Mail *mail);

// Mail routines
//
Err DataBase_LoadBroadcastMail(void);
Err DataBase_AddStampedMailToBroadcast(const Mail *, unsigned long);

// News routines
SDBNews *SDBNews_New(void);
Err DataBase_LoadNewsPages(void);
Boolean DataBase_ParseNewsDataLine(char *line, FontID *fontid,
	char *color0, char *color1, char *color2, char *color3);
void DataBase_ReplaceEscapedChars(char *str);
Boolean DataBase_TranslateConstant(char *line, long *value);

//
// Add a new game to the database.  Update to a new game patch version.
//
Err DataBase_NewGame(long, long, long, char *, PreformedMessage *);
Err DataBase_NukeGamePatches(void);

Err PhoneDB_Load(void);	/* load the phone database */
Err PhoneDB_NamedLoad(char *name);
short PhoneDB_GetNumPOPs(void);
int PhoneDB_IsLocal(const phoneNumber *, const phoneNumber *);
//long DataBase_TransmogrifyGameID(long GameID);

void DataBase_LoadGamePatches(void);

//
// Vicious reload routines
//
long PhoneDB_Reload(void);
void DataBase_ReloadNewsPages(void);
void DataBase_ReloadBroadcastMail(void);
void DataBase_ReloadGamePatches(void);

ServerDbItem *DataBase_NewDbItem(char *);
void DataBase_ReleaseObject(ServerDbItem *);

void Database_GenerateUniqueBoxSerialNumber(BoxSerialNumber *boxSerialNumber);

Account *DataBase_NewGetAccount(const userIdentification *userID);

SDBBoxList Database_NewBoxList(void);
unsigned long Database_CountBoxes(SDB *sdb);

//
// Security crud.
//
int GetCurrentConnectInfo(char **hostp, short *portp, int *msgp);

//
// GLOBALS
//
#ifndef __DataBase_Core__
extern SDB *gSDB;
#endif

#endif __ServerDataBase_priv__

