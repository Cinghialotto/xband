/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: DataBase_List.h,v 1.2 1995/05/28 20:41:08 jhsia Exp $
 *
 * $Log: DataBase_List.h,v $
 * Revision 1.2  1995/05/28  20:41:08  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		DataBase_List.h

	Contains:	xxx put contents here xxx

	Written by:	David Jevans


	Change History (most recent first):

		 <5>	 9/18/94	ATM		THIS FILE IS OBSOLETE.  Moved to Common_List.h.
		 <4>	 9/17/94	ATM		Added nelem field to list header.  Also prepended INLINE to all
									functions that don't alloc or free memory.
		 <3>	  8/9/94	DJ		error codes
		 <2>	 6/30/94	DJ		added GetSortedListNodeKey
		 <1>	 5/31/94	DJ		augmented List.h (this has sorted lists)

	To Do:
*/

// All gone!


