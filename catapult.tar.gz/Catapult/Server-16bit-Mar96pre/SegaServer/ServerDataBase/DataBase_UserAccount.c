/*
 * Copyright:	 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: DataBase_UserAccount.c,v 1.70 1996/01/15 16:47:35 davej Exp $
 *
 * $Log: DataBase_UserAccount.c,v $
 * Revision 1.70  1996/01/15  16:47:35  davej
 * Two changes for Instant Access policy: (1) start all new accounts at
 * "ACTIVE" status; (2) start 250-credit accounts with usedCredits=0, so that
 * when their free month expires, they can't log in unless Customer Service
 * has updated their credit counters after receiving a check.
 *
 * Revision 1.69  1996/01/04  22:56:08  hufft
 * added pop mail
 *
 * Revision 1.68  1995/11/30  16:00:19  ansell
 * Tookover gamePlatform for failed800PopConnects.
 *
 * Revision 1.67  1995/11/13  16:04:00  davej
 * Support for ECP.  New fields checkingAccount, bankNumber, datePreNoteSent.
 * Billing type CAT_ACCT_BILL_ECP.  Initial accountStatus & account Flags now
 * depends only on billingType; credits set only by prodstr.  New function
 * DataBase_CopyUCAInfo replaces memcpy in Database_CreateNewAccount and
 * DataBase_FindUCAByCSID to fix old bug in managing UCAInfo's string ptrs.
 *
 * Revision 1.66  1995/11/07  16:33:49  steveb
 * Renamed boxAccount->eid to boxAccount->prevSmartCardSerialNumber.  File
 * version is now 41.
 *
 * Revision 1.65  1995/10/27  18:27:08  steveb
 * Just did some long needed housecleaning.  No new code.
 *
 * Revision 1.64  1995/10/24  16:59:02  ted
 * Added code for CAT_ACCT_BILL_SMARTC and added promo string "/xband/smartcard/ja".
 *
 * Revision 1.63  1995/10/23  17:46:43  davej
 * Backed out previous changes for ECP DB fields.
 *
 * Revision 1.62  1995/10/23  16:54:46  davej
 * Added support code in create and update for three new DB fields
 * (checkingAccount, bankNumber, datePreNoteSent).  Also, new ECP enum value
 * for billing type check in create.
 *
 * Revision 1.61  1995/09/24  14:05:21  steveb
 * Added XBNUsage struct to BoxAccount.
 *
 * Revision 1.60  1995/09/17  20:44:30  steveb
 * Added support for "smart" stitcher updates.
 *
 * Revision 1.59  1995/09/13  14:15:34  ted
 * Fixed warnings.
 *
 * Revision 1.58  1995/09/06  23:27:34  ted
 * Removed #ifdeffedout WATCH_ACCT code since it could never have worked anyway.
 *
 * Revision 1.57  1995/08/21  13:13:09  steveb
 * Caching rpc.segad re-checkin.
 *
 * Revision 1.56  1995/08/15  18:55:37  steveb
 * Revert to Revision 1.54
 *
 * Revision 1.55  1995/08/11  17:39:52  steveb
 * Caching rpc.segad checkin.  Changes too numerous to mention.
 *
 * Revision 1.54  1995/08/07  21:50:33  fadden
 * Changed ngpVersion to cordPullData.
 *
 * Revision 1.53  1995/08/02  16:25:31  jhsia
 * use mblen to figure out the byte count of the last char
 *
 * Revision 1.52  1995/07/26  23:03:10  fadden
 * Added WATCH_ACCT stuff to UpdateAccount (currently #ifdefed-out).
 *
 * Revision 1.51  1995/07/26  13:57:45  ansell
 * Added Database_FindPlayerInfoChanges() which takes a list of userID
 * structs and looks them up in the database to see if their personal
 * info has changed since a specified time.
 * Renamed failedServerConnects to totalServerConnects.
 *
 * Revision 1.50  1995/07/21  18:19:54  ted
 * Changed hasMailFlags account field to modemVersion.
 *
 * Revision 1.49  1995/07/18  16:30:00  ansell
 * (steveb) Fixed more instances of setting mciPhoneList stuff.
 *
 * Revision 1.48  1995/07/18  15:24:39  ansell
 * (steveb) Fixed a nasty free memory bug.
 *
 * Revision 1.47  1995/07/17  21:47:10  steveb
 * Added new database fields:
 * 	char *BoxAccount.mciPhoneList
 * 	unsigned long BoxAccount.eid - this used to be osVersion
 * 	unsigned long PlayerAccount.lastPersonInfoChange
 * 	unsigned long PlayerAccount.lastAddrBookCheck
 * File version is now 38
 *
 * Revision 1.46  1995/07/10  21:22:15  rich
 * Added Japanese SNES platform (kPlatformSJNES).
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.45  1995/07/07  14:31:28  davej
 * Modified fixes 1.44 and 1.41 to correct compiler warnings and be generally
 * better.
 *
 * Revision 1.44  1995/07/05  17:58:28  davej
 * Modified DataBase_UpdatedAccount to force kCSUpdatedFlag_UpdatedRestrictions
 * on if restrictions are updated (kBA_restrictInfo set).
 *
 * Revision 1.43  1995/07/04  22:57:51  fadden
 * Added Begin/EndUpdateHWID calls around hardwareID changes.
 *
 * Revision 1.42  1995/06/30  19:00:55  chs
 * In Database_FindAccountBySerial(),
 * make some noise if the playerNum is negative.
 *
 * Revision 1.41  1995/06/29  17:42:56  davej
 * Added code to DataBase_UpdateAccount to set closedDate when account status
 * is changed to CAT_ACCT_STATUS_CLOSED.
 *
 * Revision 1.40  1995/06/19  20:57:45  fadden
 * Changed FindAccountBySerial to return just the boxAccount if that's all
 * that is available (a la NewFindAccount).  Implemented FindSerialByHWID.
 *
 * Revision 1.39  1995/06/19  19:22:07  davej
 * Tweak misspelled call to PLogmsg in previous rev.
 *
 * Revision 1.38  1995/06/19  19:16:35  davej
 * Additional log messages (tag CREDITSDEBUG) for prodstr and billingType.
 *
 * Revision 1.37  1995/06/19  16:48:16  davej
 * Bad credits HACK: force maxCredits = -1 only on first credit-update call
 * following an account create.  Also, if activationDate < created or == 0,
 * set activationDate to created.
 *
 * Revision 1.36  1995/06/19  11:25:17  davej
 * Trivial tweak to previous checkin: use kUnlimitedXBandCredits rather than
 * a hard-coded value of -1.
 *
 * Revision 1.35  1995/06/16  19:32:55  davej
 * Fixed bug in previous check-in and made test for error case more general.
 *
 * Revision 1.34  1995/06/15  21:54:06  davej
 * Added stuff for credits (0,0,0) problem.  If the problem is detected, fix
 * it by setting maxCredits to -1.  Also added various PLogmsg calls to help
 * in debugging the cause.
 *
 * Revision 1.33  1995/06/12  11:34:02  davej
 * Change to DataBase_UpdateUCA() to allow ucaInfo.balance to be updated from
 * the UCA API.
 *
 * Revision 1.32  1995/06/07  11:28:05  fadden
 * Removed the "bogus" prodstr stuff, which was, well, bogus.
 *
 * Revision 1.31  1995/06/05  19:12:39  davej
 * One last change (?) to the HACK of r1.25 & r1.27 (maxFreeCredits): on
 * create (Database_CreateNewAccount) and first-update (DataBase_UpdateUCA),
 * set maxFreeCredits equal to maxCredits so that CatAdmin's display of
 * maxFreeCredits appears consistent to the operator.
 *
 * Revision 1.30  1995/06/05  12:09:14  davej
 * Hack to protect boxFlags from incorrect use by the UCA applications.  Mask
 * their new value for boxFlags for only the kBoxFlag_FilterMail bit and
 * combine that with the old boxFlags, just before calling 
 * DataBase_UpdateAccount.
 * Same fix applied to uca.c, but won't be installed by UCA until 6/9/95 or so.
 *
 * Revision 1.29  1995/06/02  21:00:14  fadden
 * Added several different fields to database (notably hardwareID and other
 * restore-related stuff).  Finally got sick of dbunny's 2-space tabs and
 * reformatted DataBase_UpdateAccount.
 *
 * Revision 1.28  1995/06/01  15:13:40  fadden
 * Merge in from newbr.
 * -> Significant changes to the way lookups by phone number and (non-UCA)
 * new account creation works.
 *
 * Revision 1.27  1995/05/31  16:28:31  davej
 * Modified maxCredits HACK of 5/26/95 to allow first update following create
 * (normally uca_init_restrict) to directly modify maxCredits rather than
 * redirecting the new value into maxFreeCredits.  Also corrected small
 * (1-byte) memory leak in Database_CreateNewAccount by freeing initial
 * prodstr value before assigning caller's.
 *
 * Revision 1.26  1995/05/28  20:41:20  jhsia
 * switch to rcs keywords
 *
 * Revision 1.25  1995/05/26  15:57:20  davej
 * Last-minute emergency HACK for 6/1/95 billing support.  Squirrel away the
 * UCA caller's new value for maxCredits into the unused maxFreeCredits field,
 * and recover the original unchanged maxCredits value from the SDBBox. Argh!!
 *
 * Revision 1.24  1995/05/26  10:33:24  davej
 * Added new prodstr values for new billing plans (eff. 6/1/95) and
 * validation of billing type vs. prodstr, since only certain combinations of
 * these are valid.
 *
 * Revision 1.23.2.3  1995/05/26  18:08:03  fadden
 * Changed a logmsg.
 *
 * Revision 1.23.2.2  1995/05/24  01:21:53  fadden
 * Rewrote Database_CreateBoxAndPlayerAccount.  Added Database_FindSerialByHWID.
 *
 * Revision 1.23.2.1  1995/05/22  03:35:52  fadden
 * Shuffled code around so I can find things.  Added Database_FindSerialByPhone
 * and Database_FindAccountBySerial.  ifdefed out:
 * Database_FindAccountByGamePhoneAndPlayerNum
 * Database_FindReplacementAccountByGamePhoneAndPlayerNum
 *
 * Revision 1.23  1995/05/17  23:26:10  fadden
 * Changed memcpy(&buf, ...) to memcpy(buf, ...).  Emergency fix for crashing
 * rpc.segad.
 *
 * Revision 1.22  1995/05/17  21:31:15  chs
 * Remove Uxxxx:xx:x and U_xxxxxxxx_xx_x magic name translations.
 * These are done in Xmail now.
 *
 * Revision 1.21  1995/05/13  01:38:58  fadden
 * Call GetCurrentConnectInfo to figure out who's repeatedly calling FindInfo
 * with U282:19:A format addresses.
 *
 * Revision 1.20  1995/05/12  06:33:52  fadden
 * Change Database_FindPlayerInfo to use ServerPlayerInfo instead of PlayerInfo.
 * Return the box's platformID in the iconPlatformID field.
 *
 * Revision 1.19  1995/05/12  00:43:10  chs
 * Actually maintain mailInBox field of PlayerAccount.
 *
 */

#include <stdio.h>
#include <memory.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

#include "Server.h"
#include "ServerDataBase.h"
#include "ServerDataBase_priv.h"

#include "Common_PlatformID.h"

#include "Errors.h"
#include "Utils.h"
#include "StringDB.h"
#include "Common.h"
#include "Common_Missing.h"

#include "DataBase_Cache.h"

//
// Local prototypes
//

PRIVATE void
DataBase_CopyUCAInfo(
	UCAInfo *,
	const UCAInfo *);

PRIVATE SDBBoxPtr Database_CreateBoxAccount(
	SDBUsers *, 
	const userIdentification *, 
	phoneNumber *, 
	long);

PRIVATE void DataBase_GenUidFromSDBUser(
	SDBUser *, 
	userIdentification *,
	SDBBoxCachePtr);

PRIVATE void DataBase_SetSDBUserFromUserID(
	const userIdentification *, 
	SDBUser *,
	SDBBoxCachePtr);

PRIVATE Err Database_InternalPlayerCreate(
	SDBBoxCachePtr, 
	const userIdentification *, 
	Account **);

PRIVATE SDBUser *Database_CreateBoxUserAccount(
	const userIdentification *,
	SDBBoxCachePtr);

void plat2locale(char *locale, long platformID);


// ===========================================================================
//		Creates & Updates
// ===========================================================================

PRIVATE SDBBoxPtr
Database_CreateBoxAccount(
	SDBUsers *users, 
	const userIdentification *userID, 
	phoneNumber *boxPhone, 
	long platformID)
{
	SDBBoxPtr	   box;

	// create a new account for this virgin box. yum!  ;-)
	box = (SDBBox *) calloc(1, sizeof(SDBBox));
	ASSERT(box);
	if(!box)
	{
		ERROR_MESG("out of mems");
		return(NULL);
	}
	
	//box->boxSerialNumber = userID->box;
	//box->boxPhoneNumber = *boxPhoneNumber;
	box->users[0] = box->users[1] = box->users[2] = box->users[3] = NULL;

	DataBase_InitBoxAccount(box);

	// Do this after InitBoxAccount, since DataBase_InitBoxAccount memsets
	// the whole thing to 0 (actually, it memsets the boxAccount, userAccount,
	// and ucaInfo to 0).
	//
	box->boxAccount.platformID = platformID;
	box->boxAccount.box = userID->box;
	box->boxAccount.gamePhone = *boxPhone;
	box->boxAccount.originalGamePhone = *boxPhone;
	box->ucaInfo.cc_num = calloc(1, sizeof(char));
	box->ucaInfo.cc_expr = calloc(1, sizeof(char));
	box->ucaInfo.checkingAccount = calloc(1, sizeof(char));
	box->ucaInfo.bankNumber = calloc(1, sizeof(char));
	box->ucaInfo.prodstr = calloc(1, sizeof(char));
	box->ucaInfo.home_phone = calloc(1, sizeof(char));
	box->ucaInfo.cc_name = calloc(1, sizeof(char));
	box->ucaInfo.address = calloc(1, sizeof(char));
	box->ucaInfo.city = calloc(1, sizeof(char));
	box->ucaInfo.state = calloc(1, sizeof(char));
	box->ucaInfo.zip = calloc(1, sizeof(char));
	box->ucaInfo.country = calloc(1, sizeof(char));
	box->ucaInfo.access_code = calloc(1, sizeof(char));
	box->ucaInfo.comment = calloc(1, sizeof(char));

	ASSERT(users == gSDB->users);

	return(box);
}


/*
 * Create a new account (called from uca)
 */
Err 
Database_CreateNewAccount(
	unsigned int csid, 
	phoneNumber *boxPhone, 
	long platformID, 
	char *prodstr, 
	long billingType, 
	Account **account, 
	UCAAccount **ucaaccount)
{
	userIdentification	userID;
	SDBUsers 			*users;
	SDBBoxCachePtr 		entry;
	SDBBoxPtr 			box;
	int 				i;

	*account = NULL;
	*ucaaccount = NULL;

	//
	// Validate the caller's prodstr vs. billingType.  This should
	// probably be done in the UCA library, but we are not in a
	// position to change libuca.a right now (frozen at UCA pending
	// tight testing deadline).  Move this later?
	//
	PLogmsg(LOGP_NOTICE,
		"Checking billingType %d vs. prodstr %s.\n",
		billingType, prodstr);
	switch (billingType) {
	case CAT_ACCT_BILL_VISA:
	case CAT_ACCT_BILL_MCARD:
	case CAT_ACCT_BILL_ECP:
		if (strcmp(prodstr, "/xband/50credits/monthly") &&
		    strcmp(prodstr, "/xband/unlimitedcredits/monthly"))
			return(kInvalidArguments);
		break;
	case CAT_ACCT_BILL_PREPAID:
		if (strcmp(prodstr, "/xband/250credits/unlimitedmonths") &&
		    strcmp(prodstr, "/xband/unlimitedcredits/5months"))
			return(kInvalidArguments);
		break;
	case CAT_ACCT_BILL_BETA:
	case CAT_ACCT_BILL_GUEST:
	case CAT_ACCT_BILL_INTERNAL:
	case CAT_ACCT_BILL_PROMO:
		if (strcmp(prodstr, "/xband/unlimitedcredits/monthly"))
			return(kInvalidArguments);
		break;
	case CAT_ACCT_BILL_SMARTC:
		if (strcmp(prodstr, "/xband/smartcard/ja"))
			return(kInvalidArguments);
		break;
	default:
		return(kInvalidArguments);
	} // end switch (billingType)

	users = SDB_GetUsers(gSDB);
	ASSERT(users);

	userID.userID = 0;
	Database_GenerateUniqueBoxSerialNumber(&userID.box);

	PLogmsg(LOGP_NOTICE,
		"CREATING BOX ACCOUNT: (%ld,%ld) (%.4s)\n",
		userID.box.box, userID.box.region,
		(char *) &platformID);

	box = Database_CreateBoxAccount(users, &userID, boxPhone, platformID);
	ASSERT(box);
	if ( box == NULL )
		return(kOutOfMemoryErr);

	/*
	 * Initialize some additional stuff in the SDBBox
	 */
	box->userAccount.customerServiceID = csid;
	box->userAccount.billingType = billingType;

	// HACK ALERT * HACK ALERT * HACK ALERT * HACK ALERT
	//
	// We need to set a flag indicating that the account has just been
	// created.  DataBase_UpdateUCA relies on this bit being set so it
	// can tell the first update call from subsequent ones.
	//
	box->boxAccount.csUpdatedFlags |= kCSUpdatedFlag_AwaitingMaxCredits;

	// END HACK * END HACK * END HACK * END HACK

	// Free initial prodstr malloc'd in Database_CreateBoxAccount
	if (box->ucaInfo.prodstr)
		free(box->ucaInfo.prodstr);
	box->ucaInfo.prodstr = (char *) malloc(strlen(prodstr)+1);
	strcpy(box->ucaInfo.prodstr, prodstr);

	box->ucaInfo.created = (long) time(NULL);
	box->ucaInfo.player_cnt = 0;

	//
	// Init account status & flags based upon billingType
	//
	switch (billingType) {
	case CAT_ACCT_BILL_PREPAID:
	case CAT_ACCT_BILL_ECP:
		//
		// Initial "PENDING" status obsolete with "Instant Access" policy
		// Jan 15 '96.  Everybody plays from day 1.  Fall thru to "ACTIVE".
		//
	case CAT_ACCT_BILL_VISA:
	case CAT_ACCT_BILL_MCARD:
	case CAT_ACCT_BILL_SMARTC:
	case CAT_ACCT_BILL_BETA:
	case CAT_ACCT_BILL_INTERNAL:
	case CAT_ACCT_BILL_GUEST:
	case CAT_ACCT_BILL_PROMO:
		box->userAccount.accountStatus = CAT_ACCT_STATUS_ACTIVE;
		box->userAccount.accountFlags = 0L;
		break;
	default:
		//
		// And what do we do with an invalid billing type?  We shouldn't get here, but
		// perhaps it's better to set status to pending and let CS sort it out.
		//
		PLogmsg(LOGP_NOTICE,
			"Unknown billing type: %ld -- setting status to pending.\n",
			billingType);
		box->userAccount.accountStatus = CAT_ACCT_STATUS_PENDING;
		box->userAccount.accountFlags = 0L;
		break;
	} // end switch (billingType)

	//
	// Init account credit counters based upon product string
	//
	if (!strcmp(prodstr, "/xband/50credits/monthly")) {
		box->boxAccount.startCredits = -50;
		box->boxAccount.usedCredits = -50;
		box->boxAccount.maxCredits = 0;
	}
	else if (!strcmp(prodstr, "/xband/250credits/unlimitedmonths")) {
		box->boxAccount.startCredits = -250;
		//
		// Set usedCredits to 0, not -250, so that the account will stop
		// working at the end of the free first month if they haven't sent
		// us a check.  Part of Instant Access policy change, Jan 15, '96.
		//
		box->boxAccount.usedCredits = 0;
		box->boxAccount.maxCredits = 0;
	}
	else if (!strcmp(prodstr, "/xband/unlimitedcredits/monthly")) {
		box->boxAccount.startCredits = 0;
		box->boxAccount.usedCredits = 0;
		box->boxAccount.maxCredits = kUnlimitedXBandCredits;
	}
	else if (!strcmp(prodstr, "/xband/unlimitedcredits/5months")) {
		box->boxAccount.startCredits = 0;
		box->boxAccount.usedCredits = 0;
		box->boxAccount.maxCredits = kUnlimitedXBandCredits;
	}
	else if (!strcmp(prodstr, "/xband/smartcard/ja")) {
		box->boxAccount.startCredits = 0;
		box->boxAccount.usedCredits = 0;
		box->boxAccount.maxCredits = kUnlimitedXBandCredits;
	}
//
//	And what do we do with an invalid product string?  We shouldn't get here, but
//	perhaps it's better to clear credit counters and let CS sort it out.
//
	else {
		PLogmsg(LOGP_NOTICE,
			"Unknown product string: %s -- setting credits to 0.\n",
			prodstr);
		box->boxAccount.startCredits = 0;
		box->boxAccount.usedCredits = 0;
		box->boxAccount.maxCredits = 0;
	}

	// Set maxFreeCredits to maxCredits, so the CatAdmin display makes sense.
	//
	box->boxAccount.maxFreeCredits = box->boxAccount.maxCredits;	// Init for delayed update of maxCredits HACK

	/*
	 * Create account
	 */
	*account = (Account *) calloc(1, sizeof(Account));
	ASSERT(*account);

	(*account)->stitcherUpdate = 0;
	(*account)->boxModified = 0;
	(*account)->playerModified = 0;
	(*account)->playerAccountValid = false;

	/* copy the BoxAccount */
	memcpy(&(*account)->boxAccount, &box->boxAccount, sizeof(BoxAccount));

	/* initialize some more shit in the BoxAccount */
	(*account)->boxAccount.opaqueStore.numBytes = 0;
	(*account)->boxAccount.opaqueStore.buf = (char *) NULL;

	/*
	 * We need to do this so that when the rpc stuff frees the account
	 * struct, it does not free the real pointer in the box struct.
	 */
	(*account)->boxAccount.mciPhoneList = strdup(box->boxAccount.mciPhoneList);

	/* copy the UserAccount */
	memcpy(&(*account)->userAccount, &box->userAccount, sizeof(UserAccount));

	/* initialize some shit in the PlayerAccount */
	(*account)->playerAccount.numRankingInfo = 4;
	(*account)->playerAccount.openTaunt = calloc(1, sizeof(char));
	(*account)->playerAccount.personInfo = calloc(1, sizeof(char));
	for (i=0; i<kMaxAddressBookEntries; i++)
		(*account)->playerAccount.addressBook[i].serverUniqueID = kUncorrelatedEntry;
	(*account)->playerAccount.opaqueStore.numBytes = 0;
	(*account)->playerAccount.opaqueStore.buf = (char *) NULL;
	(*account)->playerAccount.magicID = 0L;
	
	/*
	 * Create ucaaccount
	 */
	*ucaaccount = (UCAAccount *) calloc(1, sizeof(UCAAccount));
	ASSERT(*ucaaccount);

	(*ucaaccount)->ucaModified = 0;

	//
	// Copy the database's UCAInfo structure
	//
	DataBase_CopyUCAInfo(&(*ucaaccount)->ucaInfo, &box->ucaInfo);

    /*
	 * Create the cache entry, and add the box to the search trees.
	 */
    entry = Cache_NewEntry(box);
	if ( entry ) {
		/*
		 * Set the account magicID to be the box cache pointer instead
		 * of the box.  This will work because the box cache pointer
		 * is valid as long as rpc.segad is running.
		 */
		(*account)->boxAccount.magicID = (long) entry;

		Database_AddBox(gSDB, entry);

		/* Save the box to disk */
		gWRinfo.type = kBoxWrite | kForceWrite | kInformStitcher;
		gWRinfo.data = NULL;
		gWRinfo.cache = gCache;
		Cache_WriteBox(entry, &gWRinfo);

		ServerDataBase_SaveToDiskTmp();

		/*
		 * Now free up the mems used by the new box account.  We only want
		 * to keep it in memory when it is actually accessed.
		 */
		SDBBox_Free(box);
		Cache_InvalidateEntry(entry);

		return(kNoError);
	}
	else {
		/* What a waste.  Free the box mems and return */
		 SDBBox_Free(box);

		 return(kOutOfMemoryErr);
	}
}


//
// Create a new account as if we're UCA, only we're not.
//
// This needs to be a separate RPC call because the UCA stuff translates
// Account differently from the way SunSega does.
//
// Doesn't try to pass the UCAAccount back (not needed + don't want to worry
// about translating it).
//
Err
Database_NonUCACreateNewAccount(unsigned int csid, phoneNumber *boxPhone, long platformID, char *prodstr, long billingType, Account **accountp)
{
	UCAAccount *holder = NULL;
	Err err;

	err = Database_CreateNewAccount(csid, boxPhone, platformID, prodstr,
		billingType, accountp, &holder);

	if (holder != NULL)
		free(holder);

	return (err);
}


//
// Copy a UCAInfo struct, duplicating (char *) pointers
//
PRIVATE void
DataBase_CopyUCAInfo(UCAInfo *out, const UCAInfo *in)
{
	out->cs_id = in->cs_id;
	out->cc_num = strdup(in->cc_num);
	out->cc_expr = strdup(in->cc_expr);
	out->checkingAccount = strdup(in->checkingAccount);
	out->bankNumber = strdup(in->bankNumber);
	out->datePreNoteSent = in->datePreNoteSent;
	out->prodstr = strdup(in->prodstr);
	out->prod_activate = in->prod_activate;
	out->prod_terminate = in->prod_terminate;
	out->prod_cycle_start = in->prod_cycle_start;
	out->prod_terminate = in->prod_terminate;
	out->home_phone = strdup(in->home_phone);
	out->cc_name = strdup(in->cc_name);
	out->address = strdup(in->address);
	out->city = strdup(in->city);
	out->state = strdup(in->state);
	out->zip = strdup(in->zip);
	out->country = strdup(in->country);
	out->access_code = strdup(in->access_code);
	out->terminate = in->terminate;
	out->created = in->created;
	out->comment = strdup(in->comment);
	out->player_cnt = in->player_cnt;
	out->balance = in->balance;
	out->credits = in->credits;
}


//
// Create a new user account for this virgin box. yum!  ;-)
//
PRIVATE SDBUser *
Database_CreateBoxUserAccount(
	const userIdentification *userID,
	SDBBoxCachePtr entry)
{
	SDBUser		*user;

	// create the user
	user = (SDBUser *)malloc(sizeof(SDBUser));
	ASSERT(user);
	if(!user)
	{
		ERROR_MESG("out of mems");
		return(NULL);
	}

	user->incomingMail = NewSortedList();
	user->mailSerialNumber = 0;
	user->lastBroadcastMailSent = 0;

	//user->userID = *userID;
	DataBase_InitPlayerAccount(user);		// set defaults
	// do this after InitPlayerAccount, since IPA memsets everything to 0
	DataBase_SetSDBUserFromUserID(userID, user, entry);

	return(user);
}

//
// Called from CreatePlayerAccount and CreateBoxAndPlayerAccount.
//
PRIVATE Err
Database_InternalPlayerCreate(
	SDBBoxCachePtr entry, 
	const userIdentification *userID, 
	Account **account)
{
	SDBBoxPtr	box;
	SDBUser		*user;
	Err			err;

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	ASSERT(box);
	if ( box == NULL )
		return (kFucked);

	user = box->users[userID->userID];

	if(!user) {
		user = Database_CreateBoxUserAccount(userID, entry);
		box->users[userID->userID] = user;
#ifndef OLD_LINKED_LIST_SHIT
		err = Database_EndUpdateName(gSDB, entry, userID->userID);
		ASSERT(err == kNoError);
#endif
	} else {
		ERROR_MESG("You cannot recreate an existing account!");
		return(kAccountAlreadyExists);
	}

	if ((long)userID->userID != (long)user->playerAccount.player) {
		PLogmsg(LOGP_FLAW, "ERROR: player nums don't match on create (%d/%d)\n",
			userID->userID, user->playerAccount.player);
	}
	
	// store a log of when logged in perhaps?

	// also, if the box did send phone number all the time,
	// then we could ensure that it was the same and if not
	// we could reprogram ourselves...  we should also reprogram
	// the box with its new local POP if that's the case.
	//
	// Right now we ignore the phone number  5/31/94

	*account = DataBase_GetAccount(userID);
	if (*account == NULL) {
		PLogmsg(LOGP_FLAW, "CreateAccount: found box, but not Account?!?\n");
		return(kNoSuchUserAccount);
	}

	return(kNoError);
}

//
// Prepare a new account on the first customer login.
//
// As of today, a stub account will already have been created by UCA.  We
// just need to finish setting up the box account and create the player
// account.
//
// NOTE: the boxPhoneNumber and platformID arguments are no longer used.
//
Err
Database_CreateBoxAndPlayerAccount(
	userIdentification *userID, 
	phoneNumber *boxPhoneNumber, 
	long platformID, 
	long *result, 
	Account **account)
{
	SDBBoxCachePtr 	entry;
	SDBBox 			*box;
	Err				rval;

	// Validate arguments.
	//
	ASSERT_MESG(userID->userID < 4, "userID->userID is not between 0 and 3");
	if (userID->userID > 3)
		return (kInvalidUserID);
	if (userID->box.box <= 0 || userID->box.region <= 0) {
		PLogmsg(LOGP_FLAW, "ERROR: CreateBoxAndPlayerAccount (%ld,%ld)\n",
			userID->box.box, userID->box.region);
		return (kInvalidUserID);
	}

	*result = 0;
	*account = NULL;

	// Look up the UCA pre-created account.
	//
	box = Database_FindBoxByBSN(gSDB, &userID->box, &entry);
	if (!box)
		return (kNoSuchBoxAccount);

	// Sanity-check the platformID.  Could sanity-check the boxPhoneNumber
	// too, I suppose.
	//
	if (platformID != 0 && box->boxAccount.platformID != 0 &&
		platformID != box->boxAccount.platformID)
	{
		PLogmsg(LOGP_FLAW, "ERROR: CBAPA platformID doesn't match acct\n");
		// do nothing, I guess
	}

	// Tell the world.  This logmsg must be different from the UCA-creation
	// message and the player-account-only-creation message.  The platformID
	// should already be set in the account, and should match.
	//
	PLogmsg(LOGP_NOTICE,
		"CREATING ACCOUNT: (%ld,%ld)[%ld] (%.4s)\n",
		userID->box.box, userID->box.region,
		userID->userID, (char *)&platformID);

	// Uniquify the userName.
	//
	if (DataBase_UniquifyHandle(userID, platformID))
		*result |= kUserNameUniquified;

	// Mark the box as being non-New.
	//
	box->userAccount.dateFirstConnect = box->userAccount.dateLastConnect =
		time(0);

	// Copy some crud.
	//
	strncpy(userID->userTown, box->boxAccount.homeTown, kUserTownSize);

	// Create a player account.
	//
	if ((rval = Database_InternalPlayerCreate(entry, userID, account)) 
		== kNoError)
	{
		/* Save the box to disk */
		gWRinfo.type = kBoxWrite | kForceWrite | kInformStitcher;
		gWRinfo.data = NULL;
		gWRinfo.cache = gCache;
		Cache_WriteBox(entry, &gWRinfo);
	}

	return (rval);
}

//
// Updates the userID in place if it needed to be uniquified
// Need to remove users variable because DB_CreateBoxAccount shouldn't need to
// take "users" should take gSDB.
//
// Need platformID to do the handle uniquification.
//
Err 
Database_CreatePlayerAccount(
	userIdentification *userID, 
	long platformID, 
	long *result, 
	Account **account)
{
    SDBBoxCachePtr	entry;
	SDBUsers		*users;
	SDBBox			*box;
	Err				rval;

	*result = 0;
	*account = NULL;

	PLogmsg(LOGP_NOTICE,
		"CREATING: (%ld,%ld)[%ld]\n", userID->box.box, userID->box.region,
		userID->userID);

	ASSERT_MESG(userID->userID < 4, "userID->userID is not between 0 and 3");
	if (userID->userID > 3) 
		return (kInvalidUserID);

	users = SDB_GetUsers(gSDB);
	ASSERT(users);

	// copy the userID, and uniquify the userName
	if (DataBase_UniquifyHandle(userID, platformID))
		*result |= kUserNameUniquified;

	box = Database_FindBoxByBSN(gSDB, &userID->box, &entry);
	
	ASSERT_MESG(box, 
		"Database_CreatePlayerAccount should only be called if the box exists!\n");

	if(!box)
		return(kNoSuchBoxAccount);

	if ((rval = Database_InternalPlayerCreate(entry, userID, account)) 
		== kNoError) 
	{
		/* Save the box to disk */
		gWRinfo.type = kBoxWrite | kForceWrite | kInformStitcher;
		gWRinfo.data = NULL;
		gWRinfo.cache = gCache;
		Cache_WriteBox(entry, &gWRinfo);
	}

	return(rval);
}

// Updates the userID in place.
//
// Need platformID to do the handle uniquification.
//
Err 
Database_UpdateUserHandle(
	userIdentification *userID, 
	long platformID, 
	long *result)
{
	SDBBoxCachePtr	entry;
	SDBBox     		*box;
	SDBUser    		*user;
	Err        		err;

	*result = 0;
  
	ASSERT_MESG(userID->userID < 4, "userID->userID is not between 0 and 3");
	if (userID->userID > 3) 
		return (kInvalidUserID);
  
	/* copy the userID, and uniquify the userName */

	if (DataBase_UniquifyHandle(userID, platformID))
	*result |= kUserNameUniquified;
  
	box = Database_FindBoxByBSN(gSDB, &userID->box, &entry);
	if(!box)
	return(kNoSuchBoxAccount);

	user = box->users[userID->userID];
	if(!user)
		return(kNoSuchUserAccount);
  
	/* check that handles match and replace if not. */

	if (DataBaseUtil_CompareStrings(user->playerAccount.userName, 
		userID->userName)) {
#ifndef OLD_LINKED_LIST_SHIT
		err = Database_BeginUpdateName(gSDB, entry, userID->userID);
		ASSERT(err == kNoError);
#endif
		ByteCopy((Ptr)user->playerAccount.userName, 
			(Ptr)userID->userName, kUserNameSize);

		/* Save the box to disk */
		gWRinfo.type = kBoxWrite | kForceWrite | kInformStitcher;
		gWRinfo.data = NULL;
		gWRinfo.cache = gCache;
		Cache_WriteBox(entry, &gWRinfo);

#ifndef OLD_LINKED_LIST_SHIT
		err = Database_EndUpdateName(gSDB, entry, userID->userID);
		ASSERT(err == kNoError);
#endif
	}
  
	return(kNoError);
}



// ===========================================================================
//		Searches
// ===========================================================================

//
// == BRAIN DAMAGE ==
// receive login gets the boxid and phone number and then userIdentification.
// only userIdentification is needed (cuz boxid is redundant and there is
// no need to send phone number across, and that may even pose a security risk).
//
// For username (the handle) KON should send server a message when it changes....
// otherwise I would have to compare it to what the DB has to see if it changed.
//
// 5/30/94  dj
//

Err 
DataBase_FindUserIdentification(
	const userIdentification *userID, 
	userIdentification *updatedUserID)
{
    SDBBoxCachePtr	entry;
	SDBUser 		*user;

	ASSERT(userID); 
	if (!userID) 
		return(kNoSuchUserAccount);
	
	user = Database_FindUser(userID, &entry);
	
	if (user) {
		DataBase_GenUidFromSDBUser(user, updatedUserID, entry);
		return(kNoError);
	}
	else
		return(kNoSuchUserAccount);
}

//
// Given a pointer to the SDBUser struct, fill out the fields of a
// userIdentification struct.  (SDBBox would be better, but most of these
// routines only have the SDBUser... so we need the back pointer to the
// box for this to work.)
//
PRIVATE void
DataBase_GenUidFromSDBUser(
	SDBUser *user, 
	userIdentification *userID,
	SDBBoxCachePtr entry)
{
	SDBBoxPtr box;

	ASSERT(user);
	ASSERT(userID);
	ASSERT(entry);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	ASSERT(box);
	if ( box == NULL )
		return;

	userID->box = box->boxAccount.box;
	userID->userID = user->playerAccount.player;
	userID->colorTableID = user->playerAccount.colorTableID;
	userID->ROMIconID = user->playerAccount.iconID;
	strcpy(userID->userTown, box->boxAccount.homeTown);
	strcpy(userID->userName, user->playerAccount.userName);
}

//
// Does the opposite.  Given a userID, fill out the appropriate fields in
// PlayerAccount and BoxAccount.
//
PRIVATE void
DataBase_SetSDBUserFromUserID(
	const userIdentification *userID, 
	SDBUser *user,
	SDBBoxCachePtr entry)
{
	SDBBoxPtr box;

	ASSERT(user);
	ASSERT(userID);
	ASSERT(entry);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	ASSERT(box);
	if ( box == NULL )
		return;

	box->boxAccount.box = userID->box;
	user->playerAccount.player = userID->userID;
	user->playerAccount.colorTableID = userID->colorTableID;
	user->playerAccount.iconID = userID->ROMIconID;
	strcpy(box->boxAccount.homeTown, userID->userTown);
	strcpy(user->playerAccount.userName, userID->userName);
}

//
// This is used by mail to find a user account.
// If the box serial number is -1 then we should search by handle.  sigh.
// ATM: should we search by phone number instead of handle...?
// 
SDBUser *
Database_FindUser(
	const userIdentification *userID,
	SDBBoxCachePtr *entry_ptr)
{
	SDBBox	*box;
	SDBUser	*user;

	ASSERT(userID);

	if (userID->box.box == -1 || userID->box.region == -1) {
		return(Database_FindUserByHandle(userID->userName, entry_ptr));
	}

	ASSERT_MESG(userID->userID < 4, "userID is not between 0 and 3");
	if (userID->userID > 3) return(NULL);

	box = Database_FindBoxByBSN(gSDB, (const BSNPtr) &userID->box, entry_ptr);
	if(!box)
		return(NULL);

	user = box->users[userID->userID];
	return(user);
}

//
// Look up a user by handle.
//
SDBUser *
Database_FindUserByHandle(
	const u_char *userName,
	SDBBoxCachePtr *entry_ptr)
{
	ASSERT(userName);
	return Database_FindUserByName(gSDB, userName, entry_ptr);
}

//
// look up the boxid.
// if none, create an account and create this user.
//
// find this user.
//
// BRAIN DAMAGE: this needs to check for region as well
//
// OK.  It does it because now SDBUsers->users is a list of lists.  This is indexed first by region.
// The child list is all boxids for that region.  Total cheese!  10/25/94  dj
//

SDBBox *
Database_FindBoxAccount(
	SDBUsers *users, 
	BoxSerialNumber *boxSerialNumber,
	SDBBoxCachePtr *entry_ptr)
{
	ASSERT(users == gSDB->users);
	return Database_FindBoxByBSN(gSDB, boxSerialNumber, entry_ptr);
}


#ifdef OLD_RESTORE_STUFF
//
// This trys to find the Most Recently Used account.  If they don't have the dateLastConnect set,
// then it settles for the Most Recently Created.  If the csUpdatedFlags & kCSUpdatedFlag_BindLostModem
// then we will choose that account preferentially.  This is used by the Customer Service organization (U.C.A.)
// to force a crashed modem to bind to a specific account if there are multiple accounts at a single phone number.
//
Err Database_FindAccountByGamePhoneAndPlayerNum(
	phoneNumber *boxPhoneNumber,
	unsigned char playerNum,
	long platformID,
	Account **account)
{
SDBBox				*box;
userIdentification	userID;

	*account = NULL;

	ASSERT_MESG(playerNum < 4, "playerNum is not between 0 and 3");
	if (playerNum > 3) return (kInvalidUserID);

	box = Database_FindBoxByPhone(gSDB, boxPhoneNumber, platformID);
	
	if (box == NULL)
		return kNoSuchBoxAccount;
	
	userID.box		= box->boxAccount.box;
	userID.userID	= playerNum;
		
	*account = DataBase_GetAccount(&userID);
	
	if (*account == NULL) 
	{
		Logmsg("Database_FindAccountByGamePhoneAndPlayerNum: found box, but no player\n");
		return (kNoSuchUserAccount);
	}
	return (kNoError);
}
#endif	/*OLD_RESTORE_STUFF*/


#ifdef OLD_RESTORE_STUFF
//
// Same as above, but returns only an account that has the csUpdatedFlags
// set with the kCSUpdatedFlag_ReplacementModem bit set.  This happens
// when a customer replaces their modem and UCA sets the bit so that
// their new modem gets the old account info.
//
Err Database_FindReplacementAccountByGamePhoneAndPlayerNum(
	phoneNumber *boxPhoneNumber,
	unsigned char playerNum,
	long platformID,
	Account **account)
{
SDBBox				*box;
userIdentification	userID;

	*account = NULL;

	ASSERT_MESG(playerNum < 4, "playerNum is not between 0 and 3");
	if (playerNum > 3) return (kInvalidUserID);

	box = Database_FindReplacementBoxByPhone(gSDB, boxPhoneNumber, platformID);
	
	if (box == NULL)
		return kNoSuchBoxAccount;
	
	userID.box		= box->boxAccount.box;
	userID.userID	= playerNum;
		
	*account = DataBase_GetAccount(&userID);
	
	if (*account == NULL) 
	{
		Logmsg("Database_FindReplacementAccountByGamePhoneAndPlayerNum: found box, but no player\n");
		return (kNoSuchUserAccount);
	}
	return (kNoError);
}
#endif	/*OLD_RESTORE_STUFF*/



//
// Searches only on BoxID, Region, and PlayerNum, not on handle.
//
Err 
Database_FindAccount(
	const userIdentification *userID, 
	Account **account)
{
	SDBBoxCachePtr 	entry;
	SDBBoxPtr		box;
	SDBUser			*user;

	*account = NULL;

	ASSERT_MESG(userID->userID < 4, "userID->userID is not between 0 and 3");
	if (userID->userID > 3) return (kInvalidUserID);

	box = Database_FindBoxByBSN(gSDB, &userID->box, &entry);
	if(!box)
		return(kNoSuchBoxAccount);

	user = box->users[userID->userID];

	if(!user)
		return(kNoSuchUserAccount);

	*account = DataBase_GetAccount(userID);
	if (*account == NULL) {
		PLogmsg(LOGP_FLAW, "FindAccount: found box, but not Account?!?\n");
		return(kNoSuchUserAccount);
	}
	return(kNoError);
}

//
// Searches only on BoxID, Region, and PlayerNum, not on handle.
// Will return a box even if the specified player isn't there.
//
Err 
Database_NewFindAccount(
	const userIdentification *userID, 
	Account **account)
{
	SDBBoxCachePtr 	entry;
	SDBBoxPtr		box;
	SDBUser			*user;

	*account = NULL;

	ASSERT_MESG(userID->userID < 4, "userID->userID is not between 0 and 3");
	if (userID->userID > 3) return (kInvalidUserID);

	box = Database_FindBoxByBSN(gSDB, &userID->box, &entry);
	if(!box)
		return(kNoSuchBoxAccount);

	user = box->users[userID->userID];

	if(!user)
		*account = DataBase_NewGetAccount(userID);
	else
		*account = DataBase_GetAccount(userID);

	if (*account == NULL) {
		PLogmsg(LOGP_FLAW, "FindAccount: found box, but not Account?!?\n");
		return(kNoSuchUserAccount);
	}
	return(kNoError);
}


//
// Find an account by phone number, returning the box serial numbers of the
// account found.
//
// Returns kNoError on success.
//
Err
Database_FindSerialByPhone(
	const phoneNumber *phoneNum, 
	long mode,
	long platformID, 
	BoxSerialNumber *boxp)
{
	SDBBoxCachePtr 	entry;
	SDBBoxPtr		box;

	PLogmsg(LOGP_PROGRESS, "Database_FindSerialByPhone (%s - '%.4s' - %s)\n",
		(mode == kPhoneLookupReplacement) ? "repl" :
		(mode == kPhoneLookupNew) ? "new " :
		(mode == kPhoneLookupAnyOpenUsed) ? "anop" :
		(mode == kPhoneLookupAnyUsed) ? "used" : "???",
		(char *)&platformID, phoneNum->phoneNumber);

	boxp->box = -1;
	boxp->region = -1;

	switch (mode) {
	case kPhoneLookupReplacement:
		box = Database_FindReplacementBoxByPhone(gSDB,
			phoneNum, platformID, &entry);
		break;
	case kPhoneLookupNew:
		box = Database_FindNewBoxByPhone(gSDB, phoneNum, platformID, &entry);
		break;
	case kPhoneLookupAnyOpenUsed:
		box = Database_FindOpenBoxByPhone(gSDB, phoneNum, platformID, &entry);
		break;
	case kPhoneLookupAnyUsed:
		box = Database_FindBoxByPhone(gSDB, phoneNum, platformID, &entry);
		break;
	default:
		PLogmsg(LOGP_FLAW, 
			"ERROR: FindSerialByPhone with unknown mode %d\n", mode);
		return (kInvalidArguments);
	}

	if (box == NULL) {
		if (mode == kPhoneLookupAnyUsed)
			Logmsg("No accounts found at '%s' on '%.4s'\n",
				phoneNum->phoneNumber, (char *)&platformID);
		else
			PLogmsg(LOGP_PROGRESS, "No accounts found at '%s' on '%.4s'\n",
				phoneNum->phoneNumber, (char *)&platformID);
		return (kNoSuchBoxAccount);
	}

	*boxp = box->boxAccount.box;
	PLogmsg(LOGP_PROGRESS, "  Found (%ld,%ld) at '%s' on '%.4s'\n", boxp->box,
		boxp->region, phoneNum->phoneNumber, (char *)&platformID);

	return (kNoError);
}

//
// Look up an account by hardwareID.
//
// No guarantee that hardwareID will be unique across platforms, so include
// the platformID in the lookup.  (950608: according to Josh, we'll either
// be using parts from the same family, or switch to a different family...
// so as long as the "family" number is included in the comparison, we can
// be assured that they will be unique across platforms.)
//
// Returns kNoError if the account is found, with the serials in "boxp".
//
Err
Database_FindSerialByHWID(
	const HardwareID *hwid, 
	long platformID,
	BoxSerialNumber *boxp)
{
	SDBBoxCachePtr 	entry;
	SDBBoxPtr		box;

	PLogmsg(LOGP_PROGRESS, "Database_FindSerialByHWID (type %d on '%.4s')\n",
		hwid->hardwareIDtype, (char *)&platformID);

	boxp->box = -1;
	boxp->region = -1;
	
	if (hwid->hardwareIDtype == kHWID_NoHWID) {
		PLogmsg(LOGP_FLAW,
			"Some idiot called Database_FindSerialByHWID w/o hwid\n");
		return (kInvalidArguments);
	}

	box = Database_FindBoxByHWID(gSDB, hwid, platformID, &entry);
	if (box == NULL) {
		// Nobody by that name.
		return (kNoSuchBoxAccount);
	}

	*boxp = box->boxAccount.box;
	PLogmsg(LOGP_PROGRESS, 
		"  Found (%ld,%ld) by HWID\n", boxp->box, boxp->region);

	return (kNoError);
}

//
// Retrieve an account based on the box serial numbers.
//
// Works a lot like FindAccount, but takes box serials instead of userIdent
// (9 bytes vs 80 over RPC), and sets statusFlagp.
//
// The statusFlags are needed so the caller can tell the difference between
// an account lookup that failed because it was a new account and an account
// lookup that failed because that playerNum didn't exist.  (This could also
// be accomplished by trying to look up all 4 players and drawing your own
// conclusions, or getting just the box account and looking at the date.)
//
// Returns kNoError if both boxAccount and playerAccount returned.
// Returns kNoSuchUserAccount if the playerAccount for "playerNum" didn't
//	exist.  If this was able to return just the boxAccount by itself,
//	statusFlags will have "kFindAccountStatusBoxOnly" set.
// Returns kNoSuchBoxAccount if the box just doesn't exist.
//
Err
Database_FindAccountBySerial(
	BoxSerialNumber *boxp, 
	int playerNum,
	long *statusFlagp, 
	Account **accountp)
{
	userIdentification 	userID;
	SDBBoxCachePtr 		entry;
	SDBBoxPtr			box;
	SDBUser				*user;

	PLogmsg(LOGP_PROGRESS, "Database_FindAccountBySerial (%ld,%ld)[%d]\n",
		boxp->box, boxp->region, playerNum);

	*accountp = NULL;
	*statusFlagp = 0L;

	ASSERT_MESG(playerNum < 4, "userID->userID is not between 0 and 3");
	if (playerNum > 3 || playerNum < 0) {
	    PLogmsg(LOGP_FLAW, "Ack! BOX LOGGED IN WITH BOGUS PLAYER %d\n",
		    playerNum);
	    return (kInvalidUserID);
	}

	box = Database_FindBoxByBSN(gSDB, boxp, &entry);
	if ( !box )
		return (kNoSuchBoxAccount);

	// See if it's never been used before (dateLastConnect==0).
	//
	if (!box->userAccount.dateLastConnect)
		*statusFlagp |= kFindAccountStatusNew;

	// See if it's closed.  (Don't need this??)
	//
	if (box->userAccount.accountStatus == CAT_ACCT_STATUS_CLOSED)
		*statusFlagp |= kFindAccountStatusClosed;

	// See if the player account exists.
	//
	userID.box = *boxp;
	userID.userID = playerNum;
	user = box->users[playerNum];

	if (!user) {
		// Get just the boxAccount.  The playerAccount will have some
		// garbage filled in to make XDR happy.
		//
		*accountp = DataBase_NewGetAccount(&userID);
		if (*accountp == NULL) {
			PLogmsg(LOGP_FLAW,
				"FindAccountBySerial: found data, but NewGetAccount failed\n");
		} else {
			*statusFlagp |= kFindAccountStatusBoxOnly;
		}

		return (kNoSuchUserAccount);

	} else {
		// Get both box and player.
		//
		*accountp = DataBase_GetAccount(&userID);
		if (*accountp == NULL) {
			PLogmsg(LOGP_FLAW,
				"FindAccountBySerial: found data, but GetAccount failed\n");
			// (should we do something to statusFlags? does it matter?)
			return (kNoSuchUserAccount);
		}

		return (kNoError);
	}

	/*NOTREACHED*/
}



ServerPlayerInfo **
Database_FindPlayerInfoChanges(const userIdentification *userIDList,
	const userIdentification *userID, const long lastChecked)
{
ServerPlayerInfo	**splayerInfoList;
Account				*account;
PlayerAccount		*playerAccount;
userIdentification	tmpUserID;
long				length, i, j=0;

	splayerInfoList = (ServerPlayerInfo **)
		malloc(sizeof(ServerPlayerInfo *)*kMaxAddressBookEntries+1);

	for (i=0; i < kMaxAddressBookEntries; i++)
	{
		if (userIDList[i].box.box != -1)
		{
			if (DataBase_FindUserIdentification(&userIDList[i], &tmpUserID) !=
				kNoError)
			{
				splayerInfoList[j] = 
					(ServerPlayerInfo *)malloc(sizeof(ServerPlayerInfo));
				splayerInfoList[j]->iconPlatformID = -1; // Delete me!
			}
			else
			{
				account = DataBase_GetAccount(&tmpUserID);
				playerAccount = &account->playerAccount;
				ASSERT_MESG(playerAccount, "We should never get this message, cuz we just called Database_FindUser and it returned OK.");
				if(!playerAccount)
				{
					// We're fucked!!!
					// DataBase_FindUserIdentification returned OK, but 
					// DataBase_GetAccount didn't?  What the hell?
					// Should probably clean some shit up before we...
					return(NULL);
				}

				if (playerAccount->lastPersonInfoChange > lastChecked)
				{
					length = strlen(playerAccount->personInfo)+1;
					splayerInfoList[j] = (ServerPlayerInfo *)
						malloc(sizeof(ServerPlayerInfo) + length);
					splayerInfoList[j]->iconPlatformID = 
						account->boxAccount.platformID;
					splayerInfoList[j]->playerInfo.userId = tmpUserID;

					// for this info you want to scan through the address book
					// of userID looking for playerID.  
					splayerInfoList[j]->playerInfo.wins = 0;
					splayerInfoList[j]->playerInfo.losses = 0;
					splayerInfoList[j]->playerInfo.dateLastPlayed = 1;

					strcpy(splayerInfoList[j]->playerInfo.info, 
						playerAccount->personInfo);

					DataBaseUtil_FreeAccount(account);
				}
				else
				{
					DataBaseUtil_FreeAccount(account);
					continue;
				}
			}
			splayerInfoList[j]->playerInfo.serverUniqueID = i;
			j++;
		}
	}
	splayerInfoList[j] = NULL;
	return(splayerInfoList);
}

//
// userID is the id of the caller.  this is used because you need to
// cross-index the last time you played against that user for the
// dateLastPlayed field.  Shit.
//
// This routine assumes that playerID is valid (ie. came from
// DataBase_FindUserIdentification)
//
ServerPlayerInfo *
Database_FindPlayerInfo(
	const userIdentification *playerID, 
	const userIdentification *userID)
{
ServerPlayerInfo	*splayerInfo;
Account				*account;
PlayerAccount		*playerAccount;
long				length;

	ASSERT(playerID->box.box != -1);

	account = DataBase_GetAccount(playerID);
	playerAccount = &account->playerAccount;
	ASSERT_MESG(playerAccount, "We should never get this message, cuz we just called Database_FindUser and it returned OK.");
	if(!playerAccount)
		return(NULL);

	length = strlen(playerAccount->personInfo)+1;
	splayerInfo = (ServerPlayerInfo *)malloc(sizeof(ServerPlayerInfo) + length);
	splayerInfo->iconPlatformID = account->boxAccount.platformID;
	splayerInfo->playerInfo.userId = *playerID;

	// for this info you want to scan through the address book of userID
	// looking for playerID.  
	splayerInfo->playerInfo.wins = 0;
	splayerInfo->playerInfo.losses = 0;
	splayerInfo->playerInfo.dateLastPlayed = 1; /* kNeverDate; */	// BRAIN DAMAGE.  should check if we matched them up and set date to then.

	strcpy(splayerInfo->playerInfo.info, playerAccount->personInfo);

	DataBaseUtil_FreeAccount(account);		// ++ATM
	return (splayerInfo);
}

/*
 * Lookup account by customer service ID.  Return both Account and UCAAccount 
 * structures.
 */
Err 
DataBase_FindUCAByCSID(
	unsigned int csid, 
	Account **account, 
	UCAAccount **ucaaccount)
{
	userIdentification 	userID;
	SDBBoxCachePtr		entry;
	SDBBoxPtr			box;
	int 				i, count;

	*account = NULL;
	*ucaaccount = NULL;

	box = Database_FindBoxByCSID(gSDB, csid, &entry);
	if (box == NULL)
		return kNoSuchBoxAccount;

	userID.box = box->boxAccount.box;
	userID.userID = 0;

	/*
	 * Create account
	 */
	*account = (Account *) calloc(1, sizeof(Account));
	ASSERT(*account);

	(*account)->stitcherUpdate = 0;
	(*account)->boxModified = 0;
	(*account)->playerModified = 0;
	(*account)->playerAccountValid = false;

	/* copy the BoxAccount */
	memcpy(&(*account)->boxAccount, &box->boxAccount, sizeof(BoxAccount));
	if (box->boxAccount.opaqueStore.numBytes > 0) {
		(*account)->boxAccount.opaqueStore.buf = (char *) malloc(box->boxAccount.opaqueStore.numBytes);
		(*account)->boxAccount.opaqueStore.numBytes = box->boxAccount.opaqueStore.numBytes;
		memcpy((*account)->boxAccount.opaqueStore.buf, box->boxAccount.opaqueStore.buf, box->boxAccount.opaqueStore.numBytes);
	}
	else {
		(*account)->boxAccount.opaqueStore.numBytes = 0;
		(*account)->boxAccount.opaqueStore.buf = (char *) 0;
	}
	(*account)->boxAccount.magicID = (long) entry;

	/*
	 * We need to do this so that when the rpc stuff frees the account
	 * struct, it does not free the real pointer in the box struct.
	 */
	(*account)->boxAccount.mciPhoneList = strdup(box->boxAccount.mciPhoneList);

	/* copy the UserAccount */
	memcpy(&(*account)->userAccount, &box->userAccount, sizeof(UserAccount));
	
	/* initialize some shit in the PlayerAccount */
	(*account)->playerAccount.numRankingInfo = 4;
	(*account)->playerAccount.openTaunt = calloc(1, sizeof(char));
	(*account)->playerAccount.personInfo = calloc(1, sizeof(char));
	for (i=0; i<kMaxAddressBookEntries; i++)
		(*account)->playerAccount.addressBook[i].serverUniqueID = kUncorrelatedEntry;
	(*account)->playerAccount.opaqueStore.numBytes = 0;
	(*account)->playerAccount.opaqueStore.buf = (char *) NULL;
	(*account)->playerAccount.magicID = 0L;

	/*
	 * Create ucaaccount
	 */
	*ucaaccount = (UCAAccount *) calloc(1, sizeof(UCAAccount));
	ASSERT(*ucaaccount);

	(*ucaaccount)->ucaModified = 0;

	//
	// Copy the database's UCAInfo structure
	//
	DataBase_CopyUCAInfo(&(*ucaaccount)->ucaInfo, &box->ucaInfo);

	/* fill in the PInfo structure */
	count = 0;
	for (i=0; i<4; i++) {
		if (box->users[i]) {
			(*ucaaccount)->pInfo.players[count] = i;
			memcpy(&(*ucaaccount)->pInfo.names[count], &box->users[i]->playerAccount.userName, sizeof(UserName));
			memcpy(&(*ucaaccount)->pInfo.eraseCodes[count], &box->users[i]->playerAccount.passwordEraseCode, sizeof(Password));
			count++;
		}
	}
	(*ucaaccount)->ucaInfo.player_cnt = count;

	return kNoError;
}


#ifdef NOT_USED
/*
 * Lookup account by game phone.  Return both Account and UCAAccount structures.
 */
Err DataBase_FindUCAByGamePhone(phoneNumber *gamePhone, long platformID, Account **account, UCAAccount **ucaaccount)
{
	SDBBox *box;
	userIdentification userID;

	*account = NULL;

	//
	// Nasty!  Evil!  Broken!
	//
	platformID = 0;
	//
	// Wildcard the platformID until UCA actually sends it.
	//

	box = Database_FindBoxByPhone(gSDB, gamePhone, platformID);

	if (box == NULL)
		return kNoSuchBoxAccount;

	userID.box = box->boxAccount.box;
	userID.userID = 0;

	*account = DataBase_GetAccount(&userID);

	if (*account == NULL) {
		Logmsg("DataBase_FindUCAByGamePhone: found box, but no player\n");
		return kNoSuchUserAccount;
	}

	return kNoError;
}
#endif



// ===========================================================================
//		BoxAccount/UserAccount routines
// ===========================================================================

//
// Set the values in a brand new SDBBox to defaults.  Handles BoxAccount
// and UserAccount.
//
// Called from Database_CreateBoxAccount().
//
Err DataBase_InitBoxAccount(SDBBox *box)
{
	BoxAccount *newbox;
	UserAccount *newuser;
	UCAInfo *newuca;

	ASSERT(box);
	newbox = &(box->boxAccount);
	newuser = &(box->userAccount);
	newuca = &(box->ucaInfo);

	// zap the whole thing
	memset(newbox, 0, sizeof(BoxAccount));
	memset(newuser, 0, sizeof(UserAccount));
	memset(newuser, 0, sizeof(UCAInfo));

	box->boxAccount.mciPhoneList = calloc(1, sizeof(char));

	return (kNoError);
}


// ===========================================================================
//		PlayerAccount routines
// ===========================================================================

//
// Set the values in a brand new SDBUser to defaults.
//
// Called from Database_CreateBoxUserAccount().
//
Err DataBase_InitPlayerAccount(SDBUser *user)
{
	PlayerAccount *newpa;
	long			a;


	ASSERT(user);
	newpa = &(user->playerAccount);

	// zap the whole thing
	memset(newpa, 0, sizeof(PlayerAccount));

	newpa->numRankingInfo = 4;		// BRAIN DAMAGE, probably not needed anymore

	newpa->openTaunt = (char *) malloc(1);	// if we just make the pointer NULL
	*(newpa->openTaunt) = '\0';				// then xdr_string() will crash
/* -----
	newpa->closeTaunt = (char *) malloc(1);
	*(newpa->closeTaunt) = '\0';
----- */
	newpa->personInfo = (char *) malloc(1);
	*(newpa->personInfo) = '\0';

	for(a = 0; a < kMaxAddressBookEntries; a++)
		newpa->addressBook[a].serverUniqueID = kUncorrelatedEntry;
	
	return (kNoError);
}


// ===========================================================================
//		Account routines
// ===========================================================================


//
// Retrieves the specified Account info.  Allocates a new Account structure
// and returns it.  It is up to the caller to free it.
//
// Returns NULL if the specified userID can't be found.
//
// SEARCHES ONLY BY BOXID, not handle.
//
Account *
DataBase_GetAccount(
	const userIdentification *userID)
{
	SDBBoxCachePtr	entry;
	SDBUser 		*user;
	SDBBox 			*box;
	Account 		*newa;
	BoxAccount 		*dbba, *newba;
	UserAccount 	*dbua, *newua;
	PlayerAccount 	*dbpa, *newpa;

	if ((box = Database_FindBoxByBSN(gSDB, &userID->box, &entry)) == NULL)
		return (NULL);		// couldn't find that box
	
	user = box->users[userID->userID];
	if(!user)
		return (NULL);		// couldn't find that player

	newa = (Account *)calloc(1, sizeof(Account));
	ASSERT(newa);

	newa->stitcherUpdate = 0;
	newa->boxModified = newa->playerModified = 0;
	newa->playerAccountValid = true;

	// Copy the database's BoxAccount
	//
	dbba = &(box->boxAccount);
	newba = &(newa->boxAccount);
	memcpy(newba, dbba, sizeof(BoxAccount));
	if (dbba->opaqueStore.numBytes > 0) {
	    newba->opaqueStore.buf = (char *)malloc(dbba->opaqueStore.numBytes);
	    newba->opaqueStore.numBytes = dbba->opaqueStore.numBytes;
	    memcpy(newba->opaqueStore.buf, dbba->opaqueStore.buf, 
		newba->opaqueStore.numBytes);
	} else {
	    newba->opaqueStore.buf = (char *)NULL;
	    newba->opaqueStore.numBytes = 0;
	}

	if (dbba->mciPhoneList != NULL) {
		newba->mciPhoneList = (char *)malloc(strlen(dbba->mciPhoneList)+1);
		strcpy(newba->mciPhoneList, dbba->mciPhoneList);
	}

	// don't need to do anything fancy... yet

	// Kluge: need to refer back to the box
	newba->magicID = (long) entry;

	// Copy the database's UserAccount
	//
	dbua = &(box->userAccount);
	newua = &(newa->userAccount);
	memcpy(newua, dbua, sizeof(UserAccount));


	// Copy the database's PlayerAccount
	//
	// We copy the bulk of the structure in one shot, but then we have
	// to malloc() storage and strcpy() the variable-length strings:
	//	  openTaunt
	//	  closeTaunt
	//	  personInfo
	//
	dbpa = &(user->playerAccount);
	newpa = &(newa->playerAccount);
	memcpy(newpa, dbpa, sizeof(PlayerAccount));

	if (dbpa->openTaunt != NULL) {
		newpa->openTaunt = (char *)malloc(strlen(dbpa->openTaunt)+1);
		strcpy(newpa->openTaunt, dbpa->openTaunt);
	} else
		newpa->openTaunt = NULL;
/* -----
	if (dbpa->closeTaunt != NULL) {
		newpa->closeTaunt = (char *)malloc(strlen(dbpa->closeTaunt)+1);
		strcpy(newpa->closeTaunt, dbpa->closeTaunt);
	} else
		newpa->closeTaunt = NULL;
----- */
	if (dbpa->personInfo != NULL) {
		newpa->personInfo = (char *)malloc(strlen(dbpa->personInfo)+1);
		strcpy(newpa->personInfo, dbpa->personInfo);
	} else
		newpa->personInfo = NULL;
	if (dbpa->customIconSize != 0) {
		newpa->customIcon = (unsigned char *)malloc(dbpa->customIconSize);
		memcpy(newpa->customIcon, dbpa->customIcon, dbpa->customIconSize);
	} else
		newpa->customIcon = NULL;

	if (dbpa->opaqueStore.numBytes > 0) {
	    newpa->opaqueStore.buf = (char *)malloc(dbpa->opaqueStore.numBytes);
	    newpa->opaqueStore.numBytes = dbpa->opaqueStore.numBytes;
	    memcpy(newpa->opaqueStore.buf, dbpa->opaqueStore.buf, 
		newpa->opaqueStore.numBytes);
	} else {
	    newpa->opaqueStore.buf = (char *)NULL;
	    newpa->opaqueStore.numBytes = 0;
	}

	// Now for something completely ugly: stuff a pointer back to the SDBUser
	// into the magicID field.  (A temporary measure!)  The client should
	// treat that magicID as a magic cookie that is Not To Be Fucked With.
	//
	newpa->magicID = (long) user->playerAccount.player;

	return (newa);
}

//
// Retrieves the specified Account info.  Allocates a new Account structure
// and returns it.  It is up to the caller to free it.
//
// Returns a valid boxAccount even if the player specified doesn't exist.
//
// SEARCHES ONLY BY BOXID, not handle.
//
Account *
DataBase_NewGetAccount(
	const userIdentification *userID)
{
	SDBBoxCachePtr	entry;
	SDBUser 		*user;
	SDBBox 			*box;
	Account 		*newa;
	BoxAccount 		*dbba, *newba;
	UserAccount 	*dbua, *newua;
	PlayerAccount 	*dbpa, *newpa;

	if ((box = Database_FindBoxByBSN(gSDB, &userID->box, &entry)) == NULL)
		return (NULL);		// couldn't find that box
	
	newa = (Account *)calloc(1, sizeof(Account));
	ASSERT(newa);

	newa->stitcherUpdate = 0;
	newa->boxModified = newa->playerModified = 0;

	// Copy the database's BoxAccount
	//
	dbba = &(box->boxAccount);
	newba = &(newa->boxAccount);
	memcpy(newba, dbba, sizeof(BoxAccount));
	if (dbba->opaqueStore.numBytes > 0) {
	    newba->opaqueStore.buf = (char *)malloc(dbba->opaqueStore.numBytes);
	    newba->opaqueStore.numBytes = dbba->opaqueStore.numBytes;
	    memcpy(newba->opaqueStore.buf, dbba->opaqueStore.buf, 
		newba->opaqueStore.numBytes);
	} else {
	    newba->opaqueStore.buf = (char *)NULL;
	    newba->opaqueStore.numBytes = 0;
	}

	if (dbba->mciPhoneList != NULL) {
		newba->mciPhoneList = (char *)malloc(strlen(dbba->mciPhoneList)+1);
		strcpy(newba->mciPhoneList, dbba->mciPhoneList);
	}

	// Same kluge as for PlayerAccounts: need to refer back to the box
	newba->magicID = (long) entry;


	// Copy the database's UserAccount
	//
	dbua = &(box->userAccount);
	newua = &(newa->userAccount);
	memcpy(newua, dbua, sizeof(UserAccount));


	newpa = &(newa->playerAccount);
	user = box->users[userID->userID];
	if(!user)
	{
	long i;

		newa->playerAccountValid = false;

	        /* initialize some shit in the PlayerAccount */
	        newpa->numRankingInfo = 4;
	        newpa->openTaunt = calloc(1, sizeof(char));
	        newpa->personInfo = calloc(1, sizeof(char));
	        for (i=0; i<kMaxAddressBookEntries; i++)
	                newpa->addressBook[i].serverUniqueID = kUncorrelatedEntry;
	        newpa->opaqueStore.numBytes = 0;
	        newpa->opaqueStore.buf = (char *) NULL;
	        newpa->magicID = 0L;
	}
	else
	{
		newa->playerAccountValid = true;

		// Copy the database's PlayerAccount
		//
		// We copy the bulk of the structure in one shot, but then we have
		// to malloc() storage and strcpy() the variable-length strings:
		//	  openTaunt
		//	  closeTaunt
		//	  personInfo
		//
		dbpa = &(user->playerAccount);
		memcpy(newpa, dbpa, sizeof(PlayerAccount));
	
		if (dbpa->openTaunt != NULL) {
			newpa->openTaunt = (char *)malloc(strlen(dbpa->openTaunt)+1);
			strcpy(newpa->openTaunt, dbpa->openTaunt);
		} else
			newpa->openTaunt = NULL;
	/* -----
		if (dbpa->closeTaunt != NULL) {
			newpa->closeTaunt = (char *)malloc(strlen(dbpa->closeTaunt)+1);
			strcpy(newpa->closeTaunt, dbpa->closeTaunt);
		} else
			newpa->closeTaunt = NULL;
	----- */
		if (dbpa->personInfo != NULL) {
			newpa->personInfo = (char *)malloc(strlen(dbpa->personInfo)+1);
			strcpy(newpa->personInfo, dbpa->personInfo);
		} else
			newpa->personInfo = NULL;
		if (dbpa->customIconSize != 0) {
			newpa->customIcon = (unsigned char *)malloc(dbpa->customIconSize);
			memcpy(newpa->customIcon, dbpa->customIcon, dbpa->customIconSize);
		} else
			newpa->customIcon = NULL;
	
		if (dbpa->opaqueStore.numBytes > 0) {
		    newpa->opaqueStore.buf = (char *)malloc(dbpa->opaqueStore.numBytes);
		    newpa->opaqueStore.numBytes = dbpa->opaqueStore.numBytes;
		    memcpy(newpa->opaqueStore.buf, dbpa->opaqueStore.buf, 
			newpa->opaqueStore.numBytes);
		} else {
		    newpa->opaqueStore.buf = (char *)NULL;
		    newpa->opaqueStore.numBytes = 0;
		}


		// Now for something completely ugly: stuff a pointer back to the 
		// SDBUser into the magicID field.  (A temporary measure!)  
		// The client should treat that magicID as a magic cookie that is 
		// Not To Be Fucked With.
		//
		newpa->magicID = (long) user->playerAccount.player;
	}

	return (newa);
}


//
// Update an existing Account
//
Err 
DataBase_UpdateAccount(
	const Account *account)
{
	SDBBoxCachePtr 		entry;
	SDBBoxPtr 			box;
	SDBUser 			*user;
	UserAccount 		*dbua;
	const UserAccount 	*userAccount;
	BoxAccount 			*dbba;
	const BoxAccount	*boxAccount;
	PlayerAccount 		*dbpa;
	const PlayerAccount	*playerAccount;
	int i;

	PLogmsg(LOGP_PROGRESS, "DataBase_UpdateAccount\n");

	/* Update the BoxAccount */

	boxAccount = &(account->boxAccount);

	entry = (SDBBoxCachePtr) boxAccount->magicID;

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	ASSERT(box);
	if ( box == NULL )
		return (kFucked);

	dbba = &(box->boxAccount);		/* database's copy of boxAccount */
	ASSERT(dbba);

	if (account->boxModified & kBA_box) {
#ifndef OLD_LINKED_LIST_SHIT
		Database_BeginUpdateBoxID(gSDB, entry);
#endif
		dbba->box = boxAccount->box;
#ifndef OLD_LINKED_LIST_SHIT
		Database_EndUpdateBoxID(gSDB, entry);
#endif
	}
	if (account->boxModified & kBA_platformID)
		dbba->platformID = boxAccount->platformID;
	if (account->boxModified & kBA_homeTown) {
		strncpy(dbba->homeTown, boxAccount->homeTown, kUserTownSize);
		strncpy(dbba->originalHomeTown, boxAccount->originalHomeTown, kUserTownSize);
		dbba->homeTown[kUserTownSize-1] = '\0';
		dbba->originalHomeTown[kUserTownSize-1] = '\0';
	}
	if (account->boxModified & kBA_hardwareID) {
		Database_BeginUpdateHWID(gSDB, entry);
		memcpy(&dbba->hardwareID, &boxAccount->hardwareID,
			sizeof(dbba->hardwareID));
		memcpy(&dbba->prevHardwareID, &boxAccount->prevHardwareID,
			sizeof(dbba->prevHardwareID));
		Database_EndUpdateHWID(gSDB, entry);
	}
	if (account->boxModified & kBA_rentalInfo)
		dbba->rentalInfo = boxAccount->rentalInfo;
	if (account->boxModified & kBA_validationToken)
		dbba->validationToken = boxAccount->validationToken;
	if (account->boxModified & kBA_gamePhone) {
#ifndef OLD_LINKED_LIST_SHIT
		Database_BeginUpdatePhone(gSDB, entry);
#endif
		
		dbba->gamePhone = boxAccount->gamePhone;
		dbba->originalGamePhone = boxAccount->originalGamePhone;
		dbba->lastGamePhone = boxAccount->lastGamePhone;
		dbba->dateLastChangedGamePhone = boxAccount->dateLastChangedGamePhone;
		
#ifndef OLD_LINKED_LIST_SHIT
		Database_EndUpdatePhone(gSDB, entry);
#endif
	}
	if (account->boxModified & kBA_overridePhone) {
		dbba->overrideANI1 = boxAccount->overrideANI1;
		dbba->overridePOP1 = boxAccount->overridePOP1;
		dbba->overrideANI2 = boxAccount->overrideANI2;
		dbba->overridePOP2 = boxAccount->overridePOP2;
	}
	if (account->boxModified & kBA_popPhone) {
		dbba->popPhone = boxAccount->popPhone;
		dbba->altPopPhone = boxAccount->altPopPhone;
	}

	if (account->boxModified & kBA_mciPhoneList) {
		if (dbba->mciPhoneList != NULL)
			free(dbba->mciPhoneList);
		dbba->mciPhoneList = (char *)malloc(strlen(boxAccount->mciPhoneList)+1);
		strcpy(dbba->mciPhoneList, boxAccount->mciPhoneList);
	}

	if (account->boxModified & kBA_xbnUsage)
		dbba->xbnUsage = boxAccount->xbnUsage;

	if (account->boxModified & kBA_failed800PopConnects)
		dbba->failed800PopConnects = boxAccount->failed800PopConnects;
	if (account->boxModified & kBA_totalServerConnects)
		dbba->totalServerConnects = boxAccount->totalServerConnects;
	if (account->boxModified & kBA_failedClientConnects)
		dbba->failedClientConnects = boxAccount->failedClientConnects;
	if (account->boxModified & kBA_credits) {
		dbba->usedCredits = boxAccount->usedCredits;
		dbba->maxCredits = boxAccount->maxCredits;
		dbba->startCredits = boxAccount->startCredits;
		dbba->usedFreeCredits = boxAccount->usedFreeCredits;
		dbba->maxFreeCredits = boxAccount->maxFreeCredits;
		dbba->startFreeCredits = boxAccount->startFreeCredits;
	}

	if (account->boxModified & kBA_boxFlags)
		dbba->boxFlags = boxAccount->boxFlags;

	if (account->boxModified & kBA_prevSmartCardSerialNumber)
		dbba->prevSmartCardSerialNumber = 
			boxAccount->prevSmartCardSerialNumber;

	if (account->boxModified & kBA_cordPullData)
		dbba->cordPullData = boxAccount->cordPullData;
	if (account->boxModified & kBA_lastMatchup)
		dbba->lastMatchup = boxAccount->lastMatchup;
	if (account->boxModified & kBA_lastSlaveInfo)
		dbba->lastSlaveInfo = boxAccount->lastSlaveInfo;
	if (account->boxModified & kBA_password)
		strcpy(dbba->password, boxAccount->password);
	if (account->boxModified & kBA_crashes) {
		dbba->numberOfBoxCrashes = boxAccount->numberOfBoxCrashes;
		dbba->dateOfLastBoxCrash = boxAccount->dateOfLastBoxCrash;
	}
	if (account->boxModified & kBA_newsChannels) {
		dbba->numNewsChannels = boxAccount->numNewsChannels;
		for (i = 0; i < dbba->numNewsChannels; i++)
			dbba->newsChannels[i] = boxAccount->newsChannels[i];
	}
	if (account->boxModified & kBA_csUpdatedFlags) {
		dbba->csUpdatedFlags = boxAccount->csUpdatedFlags;
	}
	if (account->boxModified & kBA_restrictInfo) {
		memcpy(dbba->restrictInfo, boxAccount->restrictInfo,
			sizeof(dbba->restrictInfo));
		dbba->restrictArea = boxAccount->restrictArea;
		// Force UpdatedRestrictions bit on in case UCA didn't
		// Note this code must follow assignment of csUpdatedFlags above.
		dbba->csUpdatedFlags |= kCSUpdatedFlag_UpdatedRestrictions;
	}
	if (account->boxModified & kBA_debug) {
		memcpy(dbba->debug, boxAccount->debug,
			kNumDebugFields * sizeof(boxAccount->debug[0]));
	}
	if (account->boxModified & kBA_modemVersion) {
		memcpy(dbba->modemVersion, boxAccount->modemVersion,
			sizeof(boxAccount->modemVersion));
	}
	if (account->boxModified & kBA_miscPreferences)
		dbba->miscPreferences = boxAccount->miscPreferences;

	if (account->boxModified & kBA_opaqueStore) {
		if (dbba->opaqueStore.buf != NULL) {
			free(dbba->opaqueStore.buf);
			dbba->opaqueStore.buf = NULL;
			dbba->opaqueStore.numBytes = 0;
		}
		dbba->opaqueStore.numBytes = boxAccount->opaqueStore.numBytes;
		if (dbba->opaqueStore.numBytes > 0) {
			dbba->opaqueStore.buf = (char *)malloc(dbba->opaqueStore.numBytes);
			ASSERT(dbba->opaqueStore.buf);
			memcpy(dbba->opaqueStore.buf, boxAccount->opaqueStore.buf, 
				dbba->opaqueStore.numBytes);
		}
	}

	/* always update netErrorTotals */
	dbba->netErrorTotals = boxAccount->netErrorTotals;

	/*
	 *	Update the UserAccount
	 *	Uses the "box" ptr recovered from the boxAccount magicID.
	 */
	userAccount = &(account->userAccount);
	dbua = &(box->userAccount);
	ASSERT(dbua);
	
	if (account->userModified & kUA_accountStatus) {
		dbua->accountStatus = userAccount->accountStatus;
		if (userAccount->accountStatus == CAT_ACCT_STATUS_CLOSED)
			dbua->closedDate = time(NULL);
	}
	if (account->userModified & kUA_activationDate)
		dbua->activationDate = userAccount->activationDate;

	if (account->userModified & kUA_customerServiceID) {
#ifndef OLD_LINKED_LIST_SHIT
		Database_BeginUpdateCSID(gSDB, entry);
#endif
		dbua->customerServiceID = userAccount->customerServiceID;
#ifndef OLD_LINKED_LIST_SHIT
		Database_EndUpdateCSID(gSDB, entry);
#endif
	}

	if (account->userModified & kUA_lastConnect) {
		dbua->dateLastConnect = userAccount->dateLastConnect;
		dbua->typeLastConnect = userAccount->typeLastConnect;
	}
	if (account->userModified & kUA_accountFlags)
		dbua->accountFlags = userAccount->accountFlags;
	if (account->userModified & kUA_zipCode)
		strcpy(dbua->zipCode, userAccount->zipCode);
	if (account->userModified & kUA_dateFirstConnect)
		dbua->dateFirstConnect = userAccount->dateFirstConnect;
	if (account->userModified & kUA_billingType) {
		//
		// DEBUG aid: display old and new billingType values
		//
		PLogmsg(LOGP_NOTICE,
			"CREDITSDEBUG: box (%ld,%ld) old billingType is %ld.\n",
			account->boxAccount.box.box,
			account->boxAccount.box.region,
			dbua->billingType);
		PLogmsg(LOGP_NOTICE,
			"CREDITSDEBUG: box (%ld,%ld) new billingType is %ld.\n",
			account->boxAccount.box.box,
			account->boxAccount.box.region,
			userAccount->billingType);
		dbua->billingType = userAccount->billingType;
	}
	if (account->userModified & kUA_acquisitionType)
		dbua->acqusitionType = userAccount->acqusitionType;
	if (account->userModified & kUA_closedDate)
		dbua->closedDate = userAccount->closedDate;
	if (account->userModified & kUA_promoString) {
		if (strlen(userAccount->promoString) > kPromoStringSize-1) {
			PLogmsg(LOGP_FLAW, "ERROR: promoString '%s' too long\n",
				userAccount->promoString);
			strncpy(dbua->promoString, userAccount->promoString,
				kPromoStringSize-1);
			dbua->promoString[kPromoStringSize-1] = '\0';
		} else {
			strcpy(dbua->promoString, userAccount->promoString);
		}
	}
	
	/* Update the PlayerAccount if it is valid */
	if (account->playerAccountValid) {
		unsigned char player;

		playerAccount = &(account->playerAccount);

		/* Kluge: recover the player number */
		player = (unsigned char) playerAccount->magicID;
		user = box->users[player];
		ASSERT(user);

		dbpa = &(user->playerAccount);	/* database's copy of playerAccount */
		ASSERT(dbpa);

#ifdef WHAT_THE_FUCK
		if (account->playerModified & kPA_magicID)
			dbpa->magicID = playerAccount->magicID;
#endif

		if (account->playerModified & kPA_userName) {
#ifndef OLD_LINKED_LIST_SHIT
			Database_BeginUpdateName(gSDB, entry, playerAccount->player);
#endif
			strcpy(dbpa->userName, playerAccount->userName);
			strcpy(dbpa->filteredUserName, playerAccount->filteredUserName);
			dbpa->filteredNameSuffix = playerAccount->filteredNameSuffix;
#ifndef OLD_LINKED_LIST_SHIT
			Database_EndUpdateName(gSDB, entry, playerAccount->player);
#endif
		}
		if (account->playerModified & kPA_iconID)
			dbpa->iconID = playerAccount->iconID;
		if (account->playerModified & kPA_colorTableID)
			dbpa->colorTableID = playerAccount->colorTableID;
		if (account->playerModified & kPA_openTaunt) {
			if (dbpa->openTaunt != NULL)
				free(dbpa->openTaunt);
			dbpa->openTaunt = (char *)malloc(strlen(playerAccount->openTaunt)+1);
			strcpy(dbpa->openTaunt, playerAccount->openTaunt);
		}
		if (account->playerModified & kPA_personInfo) {
			if (dbpa->personInfo != NULL)
				free(dbpa->personInfo);
			dbpa->personInfo = (char *)malloc(strlen(playerAccount->personInfo)+1);
			strcpy(dbpa->personInfo, playerAccount->personInfo);
		}
		if (account->playerModified & kPA_password)
			strcpy(dbpa->password, playerAccount->password);
		if (account->playerModified & kPA_birthday)
			dbpa->birthday = playerAccount->birthday;
		if (account->playerModified & kPA_playerFlags)
			dbpa->playerFlags = playerAccount->playerFlags;

		if (account->playerModified & kPA_lastPersonInfoChange)
			dbpa->lastPersonInfoChange = playerAccount->lastPersonInfoChange;
		if (account->playerModified & kPA_lastAddrBookCheck)
			dbpa->lastAddrBookCheck = playerAccount->lastAddrBookCheck;

		if (account->playerModified & kPA_customIcon) {
			dbpa->customIconSize = playerAccount->customIconSize;
			if (dbpa->customIcon != NULL)
				free(dbpa->customIcon);
			dbpa->customIcon = (char *)malloc(dbpa->customIconSize);
			memcpy(dbpa->customIcon, playerAccount->customIcon,
				dbpa->customIconSize);
		}

		if (account->playerModified & kPA_opaqueStore) {
			if (dbpa->opaqueStore.buf != NULL) {
				free(dbpa->opaqueStore.buf);
				dbpa->opaqueStore.buf = NULL;
				dbpa->opaqueStore.numBytes = 0;
			}
			dbpa->opaqueStore.numBytes = playerAccount->opaqueStore.numBytes;
			if (dbpa->opaqueStore.numBytes > 0) {
				dbpa->opaqueStore.buf = (char *)malloc(dbpa->opaqueStore.numBytes);
				ASSERT(dbpa->opaqueStore.buf);
				memcpy(dbpa->opaqueStore.buf, playerAccount->opaqueStore.buf, 
				dbpa->opaqueStore.numBytes);
			}
		}

		if (account->playerModified & kPA_mailInBox)
			memcpy(dbpa->mailInBox, playerAccount->mailInBox, sizeof(playerAccount->mailInBox));

		if (account->playerModified & kPA_lastPersonInfoChange)
			dbpa->lastPersonInfoChange = playerAccount->lastPersonInfoChange;
		if (account->playerModified & kPA_lastAddrBookCheck)
			dbpa->lastAddrBookCheck = playerAccount->lastAddrBookCheck;

		if (account->playerModified & kPA_autoMatchConnects)
			dbpa->autoMatchConnects = playerAccount->autoMatchConnects;
		if (account->playerModified & kPA_challengeConnects)
			dbpa->challengeConnects = playerAccount->challengeConnects;
		if (account->playerModified & kPA_msgCheckConnects)
			dbpa->msgCheckConnects = playerAccount->msgCheckConnects;
		if (account->playerModified & kPA_numResets) {
			dbpa->numEvilResets = playerAccount->numEvilResets;
			dbpa->numIffyResets = playerAccount->numIffyResets;
		}
		if (account->playerModified & kPA_ranking) {
			dbpa->numRankingInfo = playerAccount->numRankingInfo;
			for (i = 0; i < dbpa->numRankingInfo; i++)
				dbpa->rankingInfo[i] = playerAccount->rankingInfo[i];
		}
		if (account->playerModified & kPA_prevOpponent) {
			dbpa->nextPrevOpponent = playerAccount->nextPrevOpponent;
			for (i = 0; i < kMaxPreviousOpponent; i++)
				dbpa->prevOpponent[i] = playerAccount->prevOpponent[i];
		}
		if (account->playerModified & kPA_addressBook)
			memcpy(dbpa->addressBook, playerAccount->addressBook,
				sizeof(dbpa->addressBook));
		if (account->playerModified & kPA_erasePassword)
			strcpy(dbpa->passwordEraseCode, playerAccount->passwordEraseCode);
		if (account->playerModified & kPA_newsChannels) {
			dbpa->numNewsChannels = playerAccount->numNewsChannels;
			for (i = 0; i < dbpa->numNewsChannels; i++)
				dbpa->newsChannels[i] = playerAccount->newsChannels[i];
		}
		if (account->playerModified & kPA_csUpdatedFlags) {
			dbpa->csUpdatedFlags = playerAccount->csUpdatedFlags;
		}
		
		if (account->playerModified & kPA_debug) {
			memcpy(dbpa->debug, playerAccount->debug,
				kNumDebugFields * sizeof(playerAccount->debug[0]));
		}
	}

	/* Save the box to disk */
	gWRinfo.type = kBoxWrite;
	if ( account->stitcherUpdate == 0 )
		gWRinfo.type |= kInformStitcher;

	gWRinfo.data = NULL;
	gWRinfo.cache = gCache;
	Cache_WriteBox(entry, &gWRinfo);

	return (kNoError);
}

/*
 * Update an existing Account
 */
Err 
DataBase_UpdateUCA(
	Account *account, 
	UCAAccount *ucaaccount)
{
	SDBBoxCachePtr 	entry;
	SDBBoxPtr 		box;
	UCAInfo 		*ucaInfo;
	UCAInfo 		*db_ucaInfo;

	/*
	 * First, update the stuff in the UCA structure, then call
	 * DataBase_UpdateAccount() to update the account structure
	 * and update the box on disk.
	 */

	/* Update the UCAInfo structure */
	ucaInfo = &(ucaaccount->ucaInfo);

	/* recover the SDBBox pointer */
	entry = (SDBBoxCachePtr) account->boxAccount.magicID;

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	ASSERT(box);
	if ( box == NULL )
		return (kFucked);

	/* Get the DB copy of the UCAInfo structure */
	db_ucaInfo = &(box->ucaInfo);
	ASSERT(db_ucaInfo);

	if (ucaaccount->ucaModified & kUCA_cc_num) {
		if (db_ucaInfo->cc_num)
			free(db_ucaInfo->cc_num);
		db_ucaInfo->cc_num = (char *)malloc(strlen(ucaInfo->cc_num)+1);
		strcpy(db_ucaInfo->cc_num, ucaInfo->cc_num);
	}
	if (ucaaccount->ucaModified & kUCA_cc_expr) {
		if (db_ucaInfo->cc_expr)
			free(db_ucaInfo->cc_expr);
		db_ucaInfo->cc_expr = (char *)malloc(strlen(ucaInfo->cc_expr)+1);
		strcpy(db_ucaInfo->cc_expr, ucaInfo->cc_expr);
	}
	if (ucaaccount->ucaModified & kUCA_checkingAccount) {
		if (db_ucaInfo->checkingAccount)
			free(db_ucaInfo->checkingAccount);
		db_ucaInfo->checkingAccount = (char *)malloc(strlen(ucaInfo->checkingAccount)+1);
		strcpy(db_ucaInfo->checkingAccount, ucaInfo->checkingAccount);
	}
	if (ucaaccount->ucaModified & kUCA_bankNumber) {
		if (db_ucaInfo->bankNumber)
			free(db_ucaInfo->bankNumber);
		db_ucaInfo->bankNumber = (char *)malloc(strlen(ucaInfo->bankNumber)+1);
		strcpy(db_ucaInfo->bankNumber, ucaInfo->bankNumber);
	}
	if (ucaaccount->ucaModified & kUCA_datePreNoteSent) {
		db_ucaInfo->datePreNoteSent = ucaInfo->datePreNoteSent;
	}
	if (ucaaccount->ucaModified & kUCA_prodstr) {
		//
		// DEBUG aid -- if prodstr changes, log it.
		//
		PLogmsg(LOGP_NOTICE,
			"CREDITSDEBUG: box (%ld,%ld) old prodstr is %s.\n",
			account->boxAccount.box.box,
			account->boxAccount.box.region,
			db_ucaInfo->prodstr ? db_ucaInfo->prodstr : "NULL");
		PLogmsg(LOGP_NOTICE,
			"CREDITSDEBUG: box (%ld,%ld) new prodstr is %s.\n",
			account->boxAccount.box.box,
			account->boxAccount.box.region,
			ucaInfo->prodstr ? ucaInfo->prodstr : "NULL");
		if (db_ucaInfo->prodstr)
			free(db_ucaInfo->prodstr);
		db_ucaInfo->prodstr = (char *)malloc(strlen(ucaInfo->prodstr)+1);
		strcpy(db_ucaInfo->prodstr, ucaInfo->prodstr);
				
	}
	if (ucaaccount->ucaModified & kUCA_prod_activate) {
		db_ucaInfo->prod_activate = ucaInfo->prod_activate;
	}
	if (ucaaccount->ucaModified & kUCA_prod_cycle_start) {
		db_ucaInfo->prod_cycle_start = ucaInfo->prod_cycle_start;
	}
	if (ucaaccount->ucaModified & kUCA_prod_terminate) {
		db_ucaInfo->prod_terminate = ucaInfo->prod_terminate;
	}
	if (ucaaccount->ucaModified & kUCA_home_phone) {
		if (db_ucaInfo->home_phone)
			free(db_ucaInfo->home_phone);
		db_ucaInfo->home_phone = (char *)malloc(strlen(ucaInfo->home_phone)+1);
		strcpy(db_ucaInfo->home_phone, ucaInfo->home_phone);
	}
	if (ucaaccount->ucaModified & kUCA_cc_name) {
		if (db_ucaInfo->cc_name)
			free(db_ucaInfo->cc_name);
		db_ucaInfo->cc_name = (char *)malloc(strlen(ucaInfo->cc_name)+1);
		strcpy(db_ucaInfo->cc_name, ucaInfo->cc_name);
	}
	if (ucaaccount->ucaModified & kUCA_address) {
		if (db_ucaInfo->address)
			free(db_ucaInfo->address);
		db_ucaInfo->address = (char *)malloc(strlen(ucaInfo->address)+1);
		strcpy(db_ucaInfo->address, ucaInfo->address);
	}
	if (ucaaccount->ucaModified & kUCA_city) {
		if (db_ucaInfo->city)
			free(db_ucaInfo->city);
		db_ucaInfo->city = (char *)malloc(strlen(ucaInfo->city)+1);
		strcpy(db_ucaInfo->city, ucaInfo->city);
	}
	if (ucaaccount->ucaModified & kUCA_state) {
		if (db_ucaInfo->state)
			free(db_ucaInfo->state);
		db_ucaInfo->state = (char *)malloc(strlen(ucaInfo->state)+1);
		strcpy(db_ucaInfo->state, ucaInfo->state);
	}
	if (ucaaccount->ucaModified & kUCA_zip) {
		if (db_ucaInfo->zip)
			free(db_ucaInfo->zip);
		db_ucaInfo->zip = (char *)malloc(strlen(ucaInfo->zip)+1);
		strcpy(db_ucaInfo->zip, ucaInfo->zip);
	}
	if (ucaaccount->ucaModified & kUCA_country) {
		if (db_ucaInfo->country)
			free(db_ucaInfo->country);
		db_ucaInfo->country = (char *)malloc(strlen(ucaInfo->country)+1);
		strcpy(db_ucaInfo->country, ucaInfo->country);
	}
	if (ucaaccount->ucaModified & kUCA_access_code) {
		if (db_ucaInfo->access_code)
			free(db_ucaInfo->access_code);
		db_ucaInfo->access_code = (char *)malloc(strlen(ucaInfo->access_code)+1);
		strcpy(db_ucaInfo->access_code, ucaInfo->access_code);
	}
	if (ucaaccount->ucaModified & kUCA_terminate) {
		db_ucaInfo->terminate = ucaInfo->terminate;
	}
	/* beginning of "READ ONLY" fields */
	if (ucaaccount->ucaModified & kUCA_created) {
		db_ucaInfo->created = ucaInfo->created;
	}
	if (ucaaccount->ucaModified & kUCA_comment) {
		if (db_ucaInfo->comment)
			free(db_ucaInfo->comment);
		db_ucaInfo->comment = (char *)malloc(strlen(ucaInfo->comment)+1);
		strcpy(db_ucaInfo->comment, ucaInfo->comment);
	}
	if (ucaaccount->ucaModified & kUCA_player_cnt) {
		/* DO NOTHING */
	}
	if (ucaaccount->ucaModified & kUCA_balance) {
		//
		// Although a "read only" field, the Oracle stitcher needs to
		// be able to set the balance so UCA can read it.
		//
		db_ucaInfo->balance = ucaInfo->balance;
	}
	if (ucaaccount->ucaModified & kUCA_credits) {
		/* DO NOTHING */
	}

	//
	// Force a valid activationDate if it is zero, or if it is less than
	// created date.  The latter condition can occur because created is
	// set in rpc.segad and activationDate is set in libuca, on a remote
	// machine.  So we'll just set activationDate to created if they're
	// out of sync or if activationDate is not given.
	//
	// This would be more appropriately done in DataBase_UpdateAccount, but
	// created date is in the UCAAccount, which is not passed in to
	// DataBase_UpdateAccount().  So here it is...
	//
	if ((account->userAccount.activationDate == 0) ||
	    (account->userAccount.activationDate < ucaaccount->ucaInfo.created)) {
		account->userAccount.activationDate = ucaaccount->ucaInfo.created;
		account->userModified |= kUA_activationDate;
	};

	//
	// HACK ALERT * HACK ALERT * HACK ALERT * HACK ALERT * 5/26/95 davej
	//					       Revised 5/31/95 davej
	//
	// To meet last-minute policy changes in billing effective 6/1/95,
	// and without the ability to update the UCA library until well
	// after that, we need to accomplish the following.
	//
	// When maxCredits is set for the first time following account create,
	// we set it directly as the customer's initial spending cap.
	//
	// But when UCA changes maxCredits (a.k.a. cred_lim) on subsequent
	// account updates, we don't want it to actually take effect until some
	// magic SQL process runs at a later time.  So we squirrel away the new
	// value for maxCredits into the currently unused maxFreeCredits field,
	// and recover the original unchanged maxCredits value from the SDBBox.
	//
	if (box->boxAccount.csUpdatedFlags & kCSUpdatedFlag_AwaitingMaxCredits) {
		// The maxCredits value hasn't been updated since the account was created.
		//
		PLogmsg(LOGP_NOTICE,
			"DataBase_UpdateUCA: box (%ld,%ld) kCSUpdatedFlag_AwaitingMaxCredits is set.\n",
			account->boxAccount.box.box,
			account->boxAccount.box.region);
		if (account->boxModified & kBA_credits) {
			// They want to change *Credits fields
			//
			PLogmsg(LOGP_NOTICE,
				"DataBase_UpdateUCA: box (%ld,%ld) kBA_credits is set; maxCredits=%ld (was %ld).\n",
				account->boxAccount.box.box,
				account->boxAccount.box.region,
				account->boxAccount.maxCredits,
				box->boxAccount.maxCredits);
			//
			// Check for evil credits case -- moved 6/19/95 davej
			//
			if ((!strcmp(ucaInfo->prodstr, "/xband/unlimitedcredits/monthly") ||
			     !strcmp(ucaInfo->prodstr, "/xband/unlimitedcredits/5months")) &&
			    (account->boxAccount.maxCredits != kUnlimitedXBandCredits)) {
				//
				// They're on an unlimited plan, yet maxCredits != kUnlimitedXBandCredits.
				// This should never happen.  Complain and fix it.
				//
				PLogmsg(LOGP_NOTICE,
					"DataBase_UpdateUCA: box (%ld,%ld): FORCING maxCredits = -1.\n",
					account->boxAccount.box.box,
					account->boxAccount.box.region);
				account->boxAccount.maxCredits = kUnlimitedXBandCredits;
				// account->boxModified |= kBA_credits; // already set; see enclosing 'if'.
			}
			
			// Copy maxCredits into maxFreeCredits.
			// This is so CatAdmin displays consistent information to CS people.
			//
			account->boxAccount.maxFreeCredits = account->boxAccount.maxCredits;

			// Clear the first-update bit
			account->boxAccount.csUpdatedFlags &= ~kCSUpdatedFlag_AwaitingMaxCredits;
			account->boxModified |= kBA_csUpdatedFlags;
		}
	}
	else {
		// Not the first update following account create
		//
		// Roll maxCredits into maxFreeCredits in input account struct
		account->boxAccount.maxFreeCredits = account->boxAccount.maxCredits;

		// Restore the maxCredits value from DB into input account struct
		account->boxAccount.maxCredits = box->boxAccount.maxCredits;
	}

	// END HACK * END HACK * END HACK * END HACK * 5/31/95 davej

	// HACK ALERT * HACK ALERT * HACK ALERT * HACK ALERT * 6/2/95 davej
	//
	// Note: the following hack was also worked into the UCA library
	// (uca.c, where it probably belongs), but won't be linked with their
	// application before 6/9/95.  Some time after that, the following
	// can most likely go away. -- davej
	//
	// The UCA application seems to be ignoring the previous state of the
	// boxFlags when changing the profanity filter: it just assigns 0 or 1
	// (kBoxFlag_FilterMail) to boxFlags, ignoring its previous contents,
	// and passes it into the UCA API.  We need to correct for that,
	// allowing them to affect only the kBoxFlag_FilterMail bit.
	// DataBase_UpdateAccount simply takes account->boxAccount.boxFlags as
	// the new value for the DB, so before calling it, we combine the old
	// boxFlags with UCA's value for the kBoxFlag_FilterMail bit.
	// 
	if (account->boxModified & kBA_boxFlags)
		account->boxAccount.boxFlags =
			(box->boxAccount.boxFlags & ~kBoxFlag_FilterMail)
			| (account->boxAccount.boxFlags & kBoxFlag_FilterMail);

	// END HACK * END HACK * END HACK * END HACK * 6/2/95 davej

	return DataBase_UpdateAccount(account);
}

#ifdef NOT_USED
// If a user tries to get a name on this list, it will be rejected without
// consulting the database.
//
// All special mail targets (other than those used for pre-release debugging)
// need to be in this list.
//
// (NOTE: this stuff is probably obsoleted by DJ's obscenity stuff.)
//
// 950420: Actually, it *is* obsoleted.  Get rid of it.  ++ATM
//
static char *reservedHandle[] = {
//	"xband",		this gets handled differently
	"phone",
};
#endif

// determine the byte count of the last character in a string
static int
get_last_charlen(u_char *s, int slen)
{
	int	char_len = 0;
	int	parse_len = 0;

	while ( parse_len + char_len < slen ) {
		parse_len += char_len;
		char_len = mblen(s + parse_len, MB_CUR_MAX);
		if (char_len <= 0 || parse_len + char_len > slen ) {
			// something must be wrong
			char_len = 0;
			break;
		}
	}

	return (char_len);
}

void plat2locale(char *locale, long platformID)
{
	// Any new platform must be added in
	switch (platformID) {
	case kPlatformGenesis:
	case kPlatformSNES:
		strcpy(locale, "C");
		break;
	case kPlatformSJNES:
		strcpy(locale, "ja");
		break;
	default:
		break;
	}
}

//
// Make a userName (a/k/a "handle") unique if it isn't already.
//
// This has to respect the maximum #of characters allowed as well as
// the maximum field width in pixels.
//
// Returns TRUE if the userID was modified, FALSE if userID->useName was
// already unique.
//
Boolean DataBase_UniquifyHandle(userIdentification *userID, long platformID)
{
	userIdentification testID, dummy;
	/* where's the magic 16 come from? Should be bigger for Japanese? */
	char numstr[16];
	long i, unlen, numlen, last_char_len;
	int wasBogus = 0;

	// Make sure they're not trying to be cute.  Handle "XBAND" specially,
	// since we want *NO* confusion over it... no ".XBAND" or "XBAND."
	// should be allowed.  We could send a dialog and yell, too...
	//
	// Also disallow the "U_" names we use for internet "from" addresses

	if ((strncasecmp(userID->userName, "xband", 5) == 0) ||
		(strncasecmp(userID->userName+1, "xband", 5) == 0) ||
		(strncasecmp(userID->userName, "U_", 2) == 0))
	{
			strcpy(userID->userName, gettext("Illegal Name"));
			wasBogus++;
	}

#ifdef NOT_USED
	for (i = 0; i < NELEM(reservedHandle); i++) {
		if (DataBaseUtil_CompareStrings(userID->userName, reservedHandle[i]) == 0) {
			strcpy(userID->userName, gettext("Bogus Name"));
			wasBogus++;
			break;
		}
	}
#endif

	testID.box.box = -1;
	testID.box.region = -1;
	strcpy(testID.userName, userID->userName);

	if (DataBase_FindUserIdentification(&testID, &dummy) != kNoSuchUserAccount) {
		if (DataBaseUtil_CompareUserIdentifications(userID, &dummy)) {
			// Guess what, he owned it.  No need to uniquify.  The guy
			// probably just capitalized it or added some spaces.
			return (wasBogus);
		}

		{	char p_locale[16];

			memset(p_locale, 0, 16);
			plat2locale(p_locale, platformID);
			setlocale(LC_CTYPE, p_locale);
		}

		// name was taken, generate a new one
		// (this could be much faster; should try to avoid string calls)
		unlen = strlen(testID.userName);
		i = 1;
		while (i < kMaxNameUnique) {
			sprintf(numstr, "%ld", i);
			numlen = strlen(numstr);
			while (numlen >= (kUserNameSize - unlen)) {
				// shorten name until number fits; don't forget kUserNameSize includes null!
				last_char_len = get_last_charlen(testID.userName, unlen);
				if ( last_char_len == 0 )
					return(false);
				else
					unlen -= last_char_len;
			}
			strcpy(testID.userName + unlen, numstr);	// append numbers
			*(testID.userName + unlen + numlen) = '\0';
			// see if it fits in the field; if not, shorten it further
			while (!IsHandleWidthLegal(testID.userName, platformID)) {
				last_char_len = get_last_charlen(testID.userName, unlen);
				if ( last_char_len == 0 )
					return(false);
				else
					unlen -= last_char_len;

				ASSERT(unlen > 2);		// should NEVER get this small
				strcpy(testID.userName + unlen, numstr);
				*(testID.userName + unlen + numlen) = '\0';
			}
			ASSERT(strlen(testID.userName) < kUserNameSize);

			// okay, we've got a new candidate; try it
			if (DataBase_FindUserIdentification(&testID, &dummy) == kNoSuchUserAccount)
				break;
			if (DataBaseUtil_CompareUserIdentifications(userID, &dummy)) {
				// He owns it, he can replace it.  He probably tried to
				// change "fubar2" back to "fubar", but "fubar" and "fubar1"
				// were still taken.  Return "true" since we did have to
				// uniqify his requested name.
				strcpy(userID->userName, testID.userName);
				return (true);
			}
			i++;
		}
		if (i == kMaxNameUnique)
			goto failure;

		strcpy(userID->userName, testID.userName);
		return (true);
	} else {
		return (wasBogus);
	}

failure:
	// BRAIN DAMAGE
	//
	// Do something appropriate; reject the request entirely or just make
	// up an arbitrary unique name.  This should be very rare unless
	// kMaxNameUnique is too small.
	PLogmsg(LOGP_FLAW, "Uniquify: AIIIIIIIIIGH\n");
	return (false);
}

