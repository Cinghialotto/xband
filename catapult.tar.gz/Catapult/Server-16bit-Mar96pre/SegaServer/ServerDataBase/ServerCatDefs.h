/*
 * Copyright:	� 1995 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: ServerCatDefs.h,v 1.1 1995/11/06 17:35:01 davej Exp $
 *
 * $Log: ServerCatDefs.h,v $
 * Revision 1.1  1995/11/06  17:35:01  davej
 * More housecleaning (moved CAT_* and cat_* back out of ServerDataBase.h and
 * into their own new file, ServerCatDefs.h, and #include'd ServerCatDefs.h
 * in ServerDataBase.h).  For compilation problems at UCA&L.
 *
 *
 */

#ifndef __ServerCatDefs__
#define __ServerCatDefs__

/*
 * CAT_FLD_ACCT_STATUS
 *
 * These values are embedded in the database, so they *cannot* change!
 */
typedef enum cat_fld_acct_status {
	CAT_ACCT_STATUS_BETA = 0,
	CAT_ACCT_STATUS_GUEST = 10010,
	/* fully functional, login subject to credit limit check */
	CAT_ACCT_STATUS_ACTIVE = 10100,
	/* still being set up, no logins */
	CAT_ACCT_STATUS_PENDING = 10101,
	/* in arrears, no logins, no longer being charged fees */
	CAT_ACCT_STATUS_SUSPENDED = 10102,
	/* permanently closed */
	CAT_ACCT_STATUS_CLOSED = 10103
} cat_fld_acct_status_t;

/*
 * CAT_FLD_ACCT_STATUS_FLAGS
 *
 * These values are embedded in the database, so they *cannot* change!
 */

/* waiting for activate date */
#define	CAT_ACCT_STATFLAG_PENDING_ACTIVATE	0x01
/* waiting for $$ */
#define	CAT_ACCT_STATFLAG_PENDING_CREDIT	0x02
/* overdue charges */
#define	CAT_ACCT_STATFLAG_SUSPEND_CREDIT	0x04
/* bad behavior */
#define CAT_ACCT_STATFLAG_SUSPEND_BEHAVIOR	0x08
/* vacation request */
#define	CAT_ACCT_STATFLAG_SUSPEND_REQUEST	0x10
/* rebill request from uca */
#define CAT_ACCT_STATFLAG_REBILL_REQUEST	0x20
/* hasn't agreed to the legal terms yet */
#define CAT_ACCT_STATFLAG_TERMS_NOT_SIGNED	0x40
/* user agreed to the legal terms with a person over the phone */
#define CAT_ACCT_STATFLAG_AGREED_TO_TERMS	0x80

/*
 * Rec-ids for CAT_FLD_ACCT_BALANCES
 *
 * These values are embedded in the database, so they *cannot* change!
 */
#define CAT_ACCT_BALANCE_INVALID	0	/* avoid unitialized ones */
#define	CAT_ACCT_BALANCE_DOLLARS	1	/* main balance */

/* Catapult balances */
#define	CAT_ACCT_BALANCE_CAT_CREDITS	500	/* main credits */
#define	CAT_ACCT_BALANCE_CAT_FREECREDS	501	/* free credits */

/*
 * CAT_FLD_ACCT_BILL_TYPE
 *
 * These values are embedded in the database, so they *cannot* change!
 */
typedef enum cat_fld_bill_type {
	CAT_ACCT_BILL_UNDEFINED =   0,	/* invalid - used during acct create */
	CAT_ACCT_BILL_PREPAID = 10000,	/* prepaid to keep positive balance */
	CAT_ACCT_BILL_INVOICE = 10001,	/* invoiced monthly */
	CAT_ACCT_BILL_DEBIT =	10002,	/* checking account debit */
	CAT_ACCT_BILL_VISA =	10003,	/* Visa */
	CAT_ACCT_BILL_MCARD =	10004,	/* Mastercard */
	CAT_ACCT_BILL_AMEX =	10005,	/* American Express */
	CAT_ACCT_BILL_SMARTC =	10006,	/* Smartcard */
	CAT_ACCT_BILL_SUBORD =	10007,	/* roll up to parent account */
	CAT_ACCT_BILL_BETA =	10008,	/* beta testers - ignored by billing */
	CAT_ACCT_BILL_INTERNAL = 10009,	/* internal employee, same as guest */
	CAT_ACCT_BILL_GUEST =	10010,	/* no charge, but credit limits apply */
	CAT_ACCT_BILL_PROMO =	10011,	/* promotional account for mktg */
	CAT_ACCT_BILL_ECP =	10012	/* electronic check processing */
} cat_fld_bill_type_t;

/*
 * CAT_FLD_ANA_CONTACTS
 *
 * The main contact always exists first. If necessary, other contacts
 * are added to the name_address array.
 *
 * These values are embedded in the database, so they *cannot* change!
 */
typedef enum cat_fld_ana_contacts {
	CAT_ACCT_CONTACT_PRIMARY =		1,	/* main contact */
	CAT_ACCT_CONTACT_BILLADDR =		2,	/* separate billing address */
	CAT_ACCT_CONTACT_BILLQUEST =	3,	/* separate billing rep */
	CAT_ACCT_CONTACT_SUPPORTQUEST =	4,	/* separate support rep */
	CAT_ACCT_CONTACT_MISC =			5	/* miscellaneous contact */
} cat_fld_ana_contacts_t;
	
/*
 * CAT_FLD_ACCT_USER_PROFILE
 */
#define	CAT_USERP_INDIV		0x01000000
#define	CAT_USERP_CORP		0x02000000
#define	CAT_USERP_REGULAR	0x00000001
#define	CAT_USERP_PRESS		0x00000002
#define	CAT_USERP_PARTNER	0x00000004
#define	CAT_USERP_FRIEND	0x00000008
#define	CAT_USERP_MODERATOR	0x00000010
#define	CAT_USERP_NONPROFIT	0x00000020

/************************************************************************
 * Account_log Object Fields						*
 ************************************************************************/

/*
 * CAT_FLD_ALTOT_BAL_OPERATOR
 */
typedef enum cat_fld_alog_balop {
	CAT_ALOG_BALOP_INC = 1,
	CAT_ALOG_BALOP_SET
} cat_fld_alog_balop_t;

/*
 * CAT_FLD_ACAT_BOXFLAGS
 *
 * These values are stored in the database so they *cannot* change!
 */
#define CAT_ACAT_BFLAGS_FILTERPROFANITY	0x01	/* filtering on */

/*
 * CAT_FLD_ACAT_EVENT_FLAGS
 */

/* crash victim designator */
#define CAT_ACAT_EFLAGS_BINDLOSTMODEM		(0x01)	
/* disable sending of mail if he is a foul-mouth sunofabitch */
#define CAT_ACAT_EFLAGS_DISABLEOUTGOINGMAIL	(0x02)	
/* force box to do a 1-800 restore */
#define CAT_ACAT_EFLAGS_FORCE800RESTORE		(0x04)	
/* restrictions were updated */
#define CAT_ACAT_EFLAGS_UPDATEDRESTRICTIONS	(0x08)	
/* clear the box password */
#define CAT_ACAT_EFLAGS_CLEARBOXPASSWORD	(16)	
/* resend the personification (maybe we edited it for obscenity..) */
#define CAT_ACAT_EFLAGS_SENDPERSONIFICATION	(32)	
/* resend all info  */
#define CAT_ACAT_EFLAGS_SENDALLBOXINFO		(64)	
/* resend all info (set if a customer replaces their modem due to defect) */
#define CAT_ACAT_EFLAGS_REPLACEMENTMODEM	(128)	
/* resend hometown to box */
#define CAT_ACAT_EFLAGS_HOMETOWNUPDATED		(256)	

/*
 * CAT_FLD_ACAT_PLATFORM
 *
 * These values are stored in the database so they *cannot* change!
 */
#define CAT_ACAT_PLATFORM_SEGAGENESIS	0x01	/* Sega Genesis */
#define CAT_ACAT_PLATFORM_SNES			0x02	/* Super Nintendo */

/*
 * CAT_FLD_ACAT_RESTRICT_AREA
 *
 * These values are stored in the database so they *cannot* change!
 */
typedef enum cat_fld_acat_restrict_area {
	/* Local calls only */
	CAT_ACAT_RESTRICT_AREA_LOCAL					= 0,	
	/* Long distance enabled */
	CAT_ACAT_RESTRICT_AREA_LDISTANCE 				= 1,
	/* player list long distance */
	CAT_ACAT_RESTRICT_AREA_PLLDISTANCE 				= 2, 
	/* Long distance enabled until market matures */
	CAT_ACAT_RESTRICT_AREA_TEMPORARYLONGDISTANCE 	= 4,	
	/* XBN long distance */
	CAT_ACAT_RESTRICT_AREA_LDISTANCE_XBN		 	= 5,	
	/* XBN player-list long distance */
	CAT_ACAT_RESTRICT_AREA_PLLDISTANCE_XBN		 	= 6	
} cat_fld_acat_restrict_area_t;

/*
 * CAT_FLD_ACAT_RESTRICT_* (start & end times)
 *
 * These values are stored in the database so they *cannot* change!
 */
#define CAT_ACAT_RESTRICT_PLAYANY	0x00000000	/* play anytime */
#define	CAT_ACAT_RESTRICT_PLAYNEVER	0xffffffff	/* play never */

/************************************************************************
 * Catapult connection object fields					*
 ************************************************************************/

/*
 * CAT_FLD_SCCONN_TYPE
 *
 * These values are stored in the database so they *cannot* change!
 */
typedef enum cat_fld_scconn_type {
	CAT_SCCONN_TYPE_MAILONLY = 1,		/* mail only connect */
	CAT_SCCONN_TYPE_CHALLENGE = 2,		/* challenge connect */
	CAT_SCCONN_TYPE_PLAYERLIST = 3		/* playerlist connect */
} cat_fld_scconn_type_t;

/*
 * CAT_FLD_SCAT_GAME_STATUS
 * (actually stores status of previous game played)
 *
 * These values are stored in the database so they *cannot* change!
 */
typedef enum cat_fld_scat_game_status {
	CAT_SCAT_GSTAT_SUCCESS,			/* normal game */
	CAT_SCAT_GSTAT_NO_OPP_FOUND,	/* XBand couldn't find an opponent */
	CAT_SCAT_GSTAT_CHALLENGE_FAIL,	/* playerlist challenge failed */
	CAT_SCAT_GSTAT_OPP_NOANSWER,	/* opponent's modem didn't answer */
	CAT_SCAT_GSTAT_OPP_RESET,		/* opponent reset during game */
	CAT_SCAT_GSTAT_PLYR_RESET,		/* you reset during game */
	CAT_SCAT_GSTAT_COMM_ERROR		/* Some kind of communication error */
} cat_fld_scat_game_status_t;


#endif __ServerCatDefs__
