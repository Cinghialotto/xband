/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: DataBase_Match.h,v 1.20 1996/01/22 16:10:34 ted Exp $
 *
 * $Log: DataBase_Match.h,v $
 * Revision 1.20  1996/01/22  16:10:34  ted
 * Changes to support new vector-based matching algorithm.
 *
 * Revision 1.19  1995/10/30  17:48:22  ted
 * Updated proto for Match_AddBoxHistory.
 *
 * Revision 1.18  1995/10/25  16:16:19  chs
 * Add definitions for retrieving the opponent history for a box.
 *
 * Revision 1.17  1995/10/19  22:29:45  hufft
 * Japan Database Changes
 *
 * Revision 1.16  1995/10/16  19:14:54  ted
 * Added MatchControl_ForgetBoxOpponentHistory struct and
 * kMatchCtl_ForgetBoxOpponentHistory, message and new function protos.
 *
 * Revision 1.15  1995/10/10  10:23:50  ted
 * Added tournament functionality for Sriram. Added previously played boxes to
 * growning list per box in history.gdbm file in conf/historydir directory. File can be
 * deleted with the kMatchCtl_KillPlayHistory message.
 *
 * Revision 1.14  1995/10/03  12:13:23  ted
 * Added kLookLongFirst contestant flag.
 *
 * Revision 1.13  1995/07/17  12:28:12  ted
 * Create ContestantInput structure and RPC_FindMatch now takes gameID.
 *
 * Revision 1.12  1995/05/28  20:41:11  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		DataBase_Match.h

	Contains:	Matcher stuff

	Written by:	Ted


	Change History (most recent first):

		<13>	12/14/94	HEC		Added kForceAcceptChallengeFlag
		<12>	 12/6/94	HEC		Modified several prototypes.
		<11>	11/29/94	HEC		Added kREALPlayerFlag
		<10>	11/23/94	HEC		Added FindRealLongMatch
		 <9>	11/23/94	HEC		Removed kForceMaster flag since it's impossible.
		 <8>	11/22/94	HEC		Enums for how match was made.
		 <7>	11/19/94	HEC		New Player stuff.
		 <6>	11/18/94	HEC		3 min. minimum, 10 min. maximum wait.
		 <5>	11/16/94	HEC		Tweaked wait times.
		 <4>	11/14/94	HEC		Added VIP wait time and tweaked other times.
		 <3>	11/13/94	HEC		Wait estimation routines and constants.
		 <2>	 11/8/94	HEC		Changed Match_Control_DequeueContestant struct.
		 <1>	 11/7/94	HEC		first checked in
*/

#ifndef __DataBase_Match__
#define __DataBase_Match__

#include <sys/types.h>
#include "Server.h"
#include "ServerDataBase.h"
#include "Common_List.h"
#include "Common_Types.h"
#include "BINTree.h"

//============================================================================
//		Defines
//============================================================================

// SCORES

#define kBestScore				1000
#define kWorstScore				0
#define kNoScore				-1

// NORMALIZING SCORE VALUES

#define kMaxSkillDelta			4000
#define kSkillScale				4
#define kWaitScale				2
#define kMaxAgo					(60*60)

// TIMING

#define kExpireInterval			(60*5)			// Check deadwood this often
#define kEstWaitScale			(60*5)			// Wait time estimate calculation

//============================================================================
//		Macros
//============================================================================

#define MAX(_a,_b)				(((_a) > (_b)) ? (_a) : (_b))
#define MIN(_a,_b)				(((_a) < (_b)) ? (_a) : (_b))

#define Matching_Abort()	abort()

// Find Contestant pointer from BINTreePtr
#define FINDSTART(_ptr,_field) \
	((ContestantPtr)((char *)(_ptr) - \
	((char *)&((ContestantPtr)(_ptr))->_field - (char *)(_ptr))))

#define GLOBAL_TO_CONTESTANT(_ptr)	FINDSTART((_ptr),globalTreeNode)
#define SPEC_TO_CONTESTANT(_ptr) 	FINDSTART((_ptr),specTreeNode)

// Get tree nodes from contestant ptr
#define GLOBAL_NODE(_c) &(_c)->globalTreeNode
#define SPEC_NODE(_c) &(_c)->specTreeNode

//============================================================================
//		Matching enumerations
//============================================================================

// Which node we're interested in during dumps, etc.
enum {
	kNextLocalNode = 1,
	kNextGlobalNode,
	kNextSpecNode
};

// Contestant.challengeFlags should be one of:
enum {
	kIgnoreChallenges = 0,
	kAcceptChallenges,
	kSpecificChallenge
};

// Matchup.warning should be one of:
enum {
	kMWarnNone = 0,
	kMWarnSpecificToAuto,
	kMWarnSpecificToSpecific,
	kMWarnAutoChangedGame,
	kMWarnAutoChangedPlayer,
	kMWarnAutoToSpecific,
	kMWarnAutoToAuto,
};

// This is what we send back.
//
// Note that, if the person is enqueued, we don't send back the userName.
// This means that it won't be available for the "wait for %s to show up"
// dialog that you get when you challenge someone.  This is fine, since
// the caller should already have it.
//
enum {
	// two possible ways to return successfully
	//
	kMatchWait = 0,						// player is on a queue
	kMatchDial							// player needs to dial opponent

	// also uses DatabaseErrors enum from ServerDataBase.h
};

enum {
	kWaitShort = 0,
	kWaitAverage,
	kWaitLong
};

//============================================================================
//		Matching types
//============================================================================

typedef struct
{
	double			ppm;			// players per minute
	long			new;			// internal - total player in last minute
	double			lastppm;		// internal - ppm for last minute
	time_t			lasttime;		// internal - last time traffic bumped
} Traffic;

typedef struct _qnode
{
	struct _qnode *next;
	struct _qnode *prev;
	struct _contestant *contestant;
} QNode, *QNodePtr;

typedef struct
{
	QNodePtr		head;
	long			count;
	Traffic			traffic;
	long			threshold;
} Queue, *QueuePtr;

typedef struct
{
	BINTree			tree;			// head of tree
	Traffic			traffic;		// traffic for tree
} Tree, *TreePtr;


//
// Contestant "inputFlags"
//
#define kNewPlayerFlag				(1<<0)	/* REAL player that's logged in less than 10 times */
#define kShortWaitFlag				(1<<1)	/* Special player waits short period of time */
#define kForceSlave					(1<<2)	/* Force the player to wait instead of dial */
#define kForceMaster				(1<<3)	/* Make contestant master at all costs, or return error */
#define kForceAcceptChallengeFlag	(1<<4)	/* Match regardless of slave's challenge flags (For Josh!) */
#define kTournamentFlag				(1<<5)	/* Tournament player */
#define kLookLongFirst				(1<<6)	/* Check long distance match before local */

// Contestant Queue indices

#define kLocalQueue					0
#define kLongQueue					1
#define kXBNQueue					2
#define kGlobalQueue				3
#define kMaxQueues					(kGlobalQueue+1)

// To reduce the amount of data sent to the matchers, I've broken the input and internal
// contestant state into two structs.

typedef struct _contestantInput
{
	// contestant info; passed in
	//
	unsigned		xbn:1;				// player subscribes to xbn
	unsigned		xbndial:1;			// can dial out on xbn
	unsigned		xbncallable:1;		// can receive xbn calls
	unsigned		billme:1;			// billed for XBN matches
	unsigned		callLongDistance:1;	// can we make long distance calls
	unsigned		waitTime:2;			// enum
	unsigned		challengeFlags:2;	// enum
	unsigned		player:4;			// (0-3) player # on box
	unsigned		oppPlayer:4;		// (0-3) player # of desired specific opponent
	long			flags;				// SunSega tells us nifty stuff
	long			contestantID;		// unique connection cookie passed in from SunSega
	long			gamePatchVersion;	// don't match different versions!
	BoxSerialNumber	boxSerialNumber;
	BoxSerialNumber	oppBoxSerialNumber;	// serial # of desired specific opponent
	UserName		userName;
	phoneNumber		boxPhoneNumber;
	RankingInfo		ranking;			// full rankingInfo
	PreviousOpponent prevOpponent[kMaxPreviousOpponent];	// prevOpp list
} ContestantInput, *ContestantInputPtr;

typedef struct _contestant
{
	ContestantInput	in;					// input to matcher
	BINNode			globalTreeNode;		// member of global wait tree 
	BINNode			specTreeNode;		// member of specific waiting tree
	QNode			qnode[kMaxQueues];	// Link for each linear queue
	long			randomVal;			// random, goes along with magic cookie
	time_t			queuedWhen;			// when enqueued
	time_t			expireWhen;			// when to expire the slave (box wait time)
	time_t			stopWhen;			// when to stop matching internally
	eid_t			eid;				// local exchange id
	long			lca_idx;			// index to list of local exchanges for contestant
	unsigned		ht:1;				// dial pattern for toll call inside home npa
	unsigned		fl:2;				// dial pattern for local call outside home npa
	unsigned		flags:1;			// general purpose
} Contestant, *ContestantPtr;

typedef struct {
	long items;
	long boxes[1];
} BoxList;

typedef struct Matchup
{
	// everybody gets these
	//
	Err				result;				// enum
	Err				specificShunt;		// reason why moved from spec to auto
	Err				warning;			// stuff like "don't call in twice"
	long			magicCookie;		// the enchanted Oreo (for waiting)
	long			randomVal;			// nice random number
	long			matchOrExpWhen;		//

	// if result is kMatchDial, these are set:
	//
	long			oppMagicCookie;		// the other guy's cookie (for dialing)
	BoxSerialNumber	oppBoxSerialNumber;	// The Enemy
	char			oppPlayer;			// (0-3) The Enemy's player number
	unsigned		oppSpecific		:1;	// boolean; did he challenge me?
	unsigned		oppTollCall		:1;	// is call toll?
	unsigned		sprint			:1;	// Sprint used for toll call
	unsigned		mci				:1; // MCI used for toll call
	unsigned		billslave		:1; // bill slave for MCI charges
	unsigned		billmaster		:1; // bill master for MCI charges
	unsigned		xbnslave		:1; // slave subscribes to XBAND Nationwide
	unsigned		xbnmaster		:1; // master subscribes to XBAND Nationwide
	unsigned		xbndial			:1; // master can dial out on XBAND Nationwide
	phoneNumber		oppPhoneNumber;		// exact dial string for master
	phoneNumber		oppOrigPhoneNumber;	// opponent's normalized 10-digit phone number
	UserName		oppUserName;		// name to display while dialing
	RankingInfo		oppRankingInfo;		// slave's ranking info
	long			oppInputFlags;		// verbatim from slave's contestant struct
} Matchup;

// Global values for an entire region.
typedef struct RegionGlobals
{
	// useful stuff
	long			regionID;			// what region am I

	// statistics
	time_t			startTime;			// when these stats were initialized
	long			numConnections;		// #of RPC connects (incl control stuff)
	long			numRequests;		// #of matching requests (either kind)
	long			numFailedReq;		// #of failed matching requests
	long			numLongDistance;	// #of long-distance matches
	long			numMatches;			// #of overall matches
	long			numSpecWait;		// #of specific challenge requests told to wait
	long			numAutoWait;		// #of auto-match told to wait
	long			numSpecificReq;		// #of specific challenge requests
	long			numSpecificSuc;		// #of specific challenge pairs
	long			numAutoReq;			// #of auto-match requests
	long			numAutoSuc;			// #of auto-match successes
	long			numAutoSpecificSuc;	// #of auto-matches reqs-->specific
	long			numEnqueued;		// #of people put on a queue
	long			numDequeued;		// #of people removed from a queue
	long			numTimeouts;		// #of people booted by timer
	long			numRequeued;		// #of people who re-reg while on queue
	long			numReborn;			// #of people restored from purgatory
	long			timeEnqueued;		// total time spent on queue for all
	long			predictorError;		// total time predictor is off by (seconds)
} RegionGlobals;

//
// Global (to Matching) variables
//
extern RegionGlobals gRegion;


//============================================================================
//		Matching_Control stuff
//============================================================================

//
// Input to the Control routine.
//
// The MatchControl type is a union of every possible control message.  All
// of the control messages *must* start with "long type"; that's how we
// tell them apart.  Try to keep the messages brief.
//
// The MatchControlResult is a variable-sized structure like those used
// elsewhere in the server.  The content of the "data" element depends
// entirely on what MatchControl was called with.
//
typedef struct MatchControl_Ping
{
	long type;
	// Just see if matcher is alive.
} MatchControl_Ping;

typedef struct MatchControl_Shutdown
{
	long type;

	// Shut down and exit.  Use a validation flag to ensure a mis-set type
	// doesn't nuke the whole thing.  For obvious reasons, this doesn't
	// return anything.
	//
	long validate;		// must == kMatchShutdownValidate
} MatchControl_Shutdown;
#define kMatchShutdownValidate	0xD5AAD5AA

typedef struct MatchControl_Reload
{
	long type;
	// Reload database files, notably the LATA stuff.
} MatchControl_Reload;

typedef struct MatchControl_DoExpire
{
	long type;

	// Causes Matching_ExpireContestants to be called.  If "when" is nonzero,
	// it will be used as the current time (so by passing time + 2 minutes,
	// you can cause everything to expire two minutes fast).
	//
	long when;
} MatchControl_DoExpire;

typedef struct MatchControl_GetContestant
{
	long type;

	// Get the Contestant struct for a given ContestantID.  This should
	// NOT be used as a prelude to SetContestant.
	//
	long contestantID;
} MatchControl_GetContestant;

typedef struct MatchControl_DequeueContestant
{
	long type;

	// Remove a Contestant from the queue.
	//
	BoxSerialNumber boxSerialNumber;
} MatchControl_DequeueContestant;

typedef struct MatchControl_ForgetBoxOpponentHistory
{
	long type;

	// Remove boxes from each other's play history
	//
	BoxSerialNumber box1;
	BoxSerialNumber box2;
} MatchControl_ForgetBoxOpponentHistory;

typedef struct MatchControl_GetOpponentHistory
{
	long type;

	// retrieve a box's play history
	//
	BoxSerialNumber box;
} MatchControl_GetOpponentHistory;

typedef struct MatchControl_GrabContestant
{
	long type;

	// Grab a Contestant off of the queue.  Contestant remains in limbo
	// until a SetContestant puts him back.  Failure to do a SetContestant
	// causes a memory leak.
	//
	// The Contestant structure is returned.
	//
	Contestant contestant;
} MatchControl_GrabContestant;

typedef struct MatchControl_SetContestant
{
	long type;

	// Set the values of a previously Grabbed Contestant.  Bad idea unless
	// you know what you're doing.
	//
	Contestant contestant;
} MatchControl_SetContestant;

typedef struct MatchControl_CreateContestant
{
	long type;

	// Create a contestant.  This is intended to be used for debugging
	// and stress-testing.
	//
	Contestant contestant;
} MatchControl_CreateContestant;

typedef struct MatchControl_GetQueues
{
	long type;

	// Boolean values for which queues to get.  We *must* get them all
	// in one RPC, or run the risk of inconsistent data.  Of course,
	// UDP RPCs may choke if the data size exceeds 8K...
	//
	// Current plan: either you get the global+purgatory queues,
	// or you get the queue for a specific game.  A gameID of 0 corresponds
	// to the specific queue.  This will probably change.
	//
	short getGeneral;		// boolean
	long gameID;
} MatchControl_GetQueues;

// union of all of the above
//
typedef union MatchControl
{
	long type;
	MatchControl_Ping ping;
	MatchControl_Shutdown shutdown;
	MatchControl_Reload reload;
	MatchControl_DoExpire doExpire;
	MatchControl_GetContestant getContestant;
	MatchControl_DequeueContestant dequeueContestant;
	MatchControl_GrabContestant grabContestant;
	MatchControl_SetContestant setContestant;
	MatchControl_CreateContestant createContestant;
	MatchControl_GetQueues getQueues;
	MatchControl_ForgetBoxOpponentHistory forget;
} MatchControl;

//
// Return values from the Control routine.  All MatchControl calls cause
// a result to be returned, usually MatchControlResult_Status.
//
// As above, the result structure is a union of all possible result
// structures.  In a few cases, a large chunk of data is returned... in
// that case we use the "dangling data" structure seen in various other
// places in the server.
//
// Once again, the first element in each type MUST be "type".  Also, the
// second element in each msut be "size" so that the RPC routines can deal
// with dynamically allocated structures.  (For convenience, size == 0 is
// equivalent to size == sizeof(MatchControlResult).)
//
// To be robust, these probably ought to include the request type, so
// we can be sure that the server is responding to what we wanted.
//
typedef struct MatchControlResult_Status
{
	long type;
	long size;

	// Used for simple calls.  This just returns whether or not the call
	// succeeded (kNoError on success, something else on error).
	//
	Err  result;
} MatchControlResult_Status;

typedef struct MatchControlResult_Contestant
{
	long type;
	long size;

	// Return from GetContestant and GrabContestant.
	//
	Err  result;
	Contestant contestant;
} MatchControlResult_Contestant;

typedef struct MatchControlResult_QueueContents
{
	long type;
	long size;

	// Here follow "size" bytes of data, where "size" is from 0 to 8K.
	// Exact format TBD.
	//
	// Return from GetQueues.
	//
	Err  result;
	long count;
	unsigned char data[1];
} MatchControlResult_QueueContents;

#define kMatchControlResult_GetOpponentHistoryMaxBoxes 100
typedef struct MatchControlResult_GetOpponentHistory
{
	long type;
	long size;

	// Return from GetOpponentHistory
	//
	Err  result;
	long count;
	long boxes[kMatchControlResult_GetOpponentHistoryMaxBoxes];
} MatchControlResult_GetOpponentHistory;

// union of all of the above
//
typedef union MatchControlResult
{
	struct {
		long type;
		long size;
	} generic;
	MatchControlResult_Status status;
	//MatchControlResult_Contestant contestant; // not yet needed
	MatchControlResult_QueueContents queueContents;
	MatchControlResult_GetOpponentHistory getHistory;
} MatchControlResult;


// Enumerated types for the "type" field.
//
enum {
	kMatchCtl_Ping,
	kMatchCtl_Shutdown,
	kMatchCtl_Reload,
	kMatchCtl_GetContestant,
	kMatchCtl_DequeueContestant,
	kMatchCtl_GrabContestant,
	kMatchCtl_SetContestant,
	kMatchCtl_CreateContestant,
	kMatchCtl_DoExpire,
	kMatchCtl_GetQueues,
	kMatchCtl_KillPlayHistory,
	kMatchCtl_ForgetBoxOpponentHistory,
	kMatchCtl_GetOpponentHistory,

	kMatchCtlRes_NoResult,			// NULL pointer
	kMatchCtlRes_Status,
	kMatchCtlRes_Contestant,
	kMatchCtlRes_QueueContents,
};


//============================================================================
//		Support for non-RPC communications
//============================================================================
#ifndef USE_RPC_FOR_MATCHER

#define MANGLE_SVC(svc)	( ((svc%10000)<1280) ? (svc%10000)+2048 : svc%10000 )

enum { MATCH_PACKET_FINDMATCH=0, MATCH_PACKET_CONTROL };
typedef struct {
	short size;
	short type;
	union {
		MatchControl matchControl;
		ContestantInput contestantInput;
	} data;
} MatchRequestPacket;

typedef struct
{
	short size;
	short type;
	union
	{
		Matchup matchup;
		MatchControlResult matchControlResult;
	} data;
} MatchReplyPacket;

// Ugly kluge to make my life simpler.  This is the size of the request
// and reply packets without the "data" union.  The horror, the horror.
//
#define REQ_SIZE_WITHOUT_DATA	4
#define REPLY_SIZE_WITHOUT_DATA	4
#define UDP_PORT_ADJ	(-128)

#endif /*USE_RPC_FOR_MATCHER*/


// ===========================================================================
//		External Function Prototypes
// ===========================================================================

enum { MDC_BRIEF, MDC_VERBOSE };

// DataBase_Match.c

MatchControlResult *
Match_Control(MatchControl *matchControl);

Matchup *
Match_FindMatch(ContestantPtr caller);

void
Match_Shutdown(void);

Err
Match_Startup(long platformID, long gameID);

// RPC calls

Matchup *RPC_FindMatch(ContestantInput *contestant, long platformID, long gameID);
MatchControlResult *RPC_MatchingControl(const MatchControl *matchControl, long platformID, long gameID);


#endif __DataBase_Match__

