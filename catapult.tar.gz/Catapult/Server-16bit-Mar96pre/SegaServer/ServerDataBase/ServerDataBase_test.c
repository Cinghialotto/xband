/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 *	$Id
 *
 *	$Log: ServerDataBase_test.c,v $
 * Revision 1.2  1995/05/28  20:41:31  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		ServerDataBase_test.c

	Contains:	xxx put contents here xxx

	Written by:	David Jevans


	Change History (most recent first):

		 <1>	 5/31/94	DJ		Test program for the database

	To Do:
*/


#include "Server.h"
#include "ServerDataBase.h"
#include "ServerDataBase_priv.h"
#include "Mail.h"

#include <string.h>
#include <stdlib.h>

// #define RUN1

static void Test_System(void)
{

#ifdef RUN1
PreformedMessage	msg1, msg2[2];
#endif RUN1

long	latestSystemVersion, latestKeyframeSystemVersion;
long 	i, numPatches;

#ifdef RUN1
	msg1.message = "system version 1 patch: you suck";
	msg1.length = strlen(msg1.message) + 1;
	SDBSystem_AddSystemVersion(1, true, 1, &msg1);

	msg2[0].message = "system version 2 patch1: eat my shorts";
	msg2[0].length = strlen(msg2[0].message) + 1;
	msg2[1].message = "system version 2 patch2: you big wiggler";
	msg2[1].length = strlen(msg2[1].message) + 1;
	SDBSystem_AddSystemVersion(2, false, 2, msg2);
#endif RUN1

	latestSystemVersion = DataBase_GetLatestSystemVersion();
	printf("Latest system version = %ld\n", latestSystemVersion);
	
	latestKeyframeSystemVersion = DataBase_GetLatestSystemKeyframeVersion();
	printf("Latest keyframe system version = %ld\n", latestKeyframeSystemVersion);

	for(i = latestKeyframeSystemVersion; i <= latestSystemVersion; i++){
		numPatches = DataBase_GetSystemNumPatches(i);
		printf("Num Patches for system version %ld = %ld\n", i, numPatches);
	}
}

static void Test_UserAccount(void)
{
userIdentification 	user1 = {13, 0, {"psycho jevans"}},
					user2 = {23, 0, {"Krazy Kon"}};

Mail	*from1, *from2;
long	numMails, i, mailSize;
Mail	*mail;

//	user1.boxSerialNumber = Database_GenerateUniqueBoxSerialNumber();
	Database_CheckAccount(&user1);
	Database_CheckAccount(&user2);

	from1 = (Mail *)malloc(sizeof(Mail) + 200);
	from2 = (Mail *)malloc(sizeof(Mail) + 200);
	
	from1->to = user2;
	from1->from = user1;
	from1->serialNumber = 0;
	from1->date = 0;
	from1->iconRef = 0;
	strcpy(from1->title, "special message");
	strcpy(from1->message, "Kon, you suck");

	from2->to = user1;
	from2->from = user2;
	from2->serialNumber = 0;
	from2->date = 0;
	from2->iconRef = 0;
	strcpy(from2->title, "re: special message");
	strcpy(from2->message, "Jevans, you're right!");

	DataBase_AddMailToIncoming(from1);
	DataBase_AddMailToIncoming(from2);

	//
	// Now see if it really got in there.
	//
	numMails = DataBase_GetNumIncomingMail(&user2);
	if(numMails > 0)
	{		
		for(i = 0; i < numMails; i++)
		{
			mail = DataBase_GetIncomingMail(&user2, i);
			mailSize = DataBase_SizeofMail(mail);
			
			DataBase_PrintMail(mail);
		}
	}

	numMails = DataBase_GetNumIncomingMail(&user1);
	if(numMails > 0)
	{		
		for(i = 0; i < numMails; i++)
		{
			mail = DataBase_GetIncomingMail(&user1, i);
			mailSize = DataBase_SizeofMail(mail);
			
			DataBase_PrintMail(mail);
		}
	}

	free(from1);
	free(from2);
}

void main()
{

	ServerDataBase_Initialize();

	Test_System();
	
	Test_UserAccount();	
	
	SDBSystem_Print();
	
	ServerDataBase_Shutdown();
}

