/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.  
 *
 *	$Id
 *
 *	$Log: DataBase_Rankings.c,v $
 * Revision 1.2  1995/05/28  20:41:16  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		DataBase_Rankings.c

	Contains:	KON's rating stuff

	Written by:	KON


	Change History (most recent first):

		<14>	10/17/94	ATM		THIS FILE IS NOW OBSOLETE.  It has been moved to
									Server_Rankings.c.
		<13>	10/16/94	ATM		Replaced provisional stuff.  Now we just do the normal ratings
									stuff, but don't count win/loss against the other guy.
		<12>	10/15/94	ATM		Mumble.
		<11>	10/14/94	ATM		Now it sucks less.
		<10>	10/14/94	ATM		It sucks.  Whatever.
		 <9>	10/14/94	ATM		Added a return, twiddled provisional stuff.
		 <8>	10/14/94	ATM		Major changes to the way provisional stuff works.
		 <7>	10/14/94	ATM		Added a logmsg to indicate that the rating computed is based on
									one or both players being in the Provisional Zone.
		 <6>	10/14/94	ATM		Twiddled logmsgs.
		 <5>	10/10/94	ATM		Made InitializePlayerRankings init the rest of the fields in
									RankingInfo.
		 <4>	 10/4/94	ATM		Need to adjust stuff in GetMatchPointValueForP1, or new players
									never get any xpoints.
		 <3>	 10/4/94	ATM		Make first transition at 2.
		 <2>	 10/1/94	ATM		Added some log messages.
		 <1>	 10/1/94	ATM		Checked into server source tree.
		 <6>	 9/27/94	KON		Added GetNextLevelPoints function.
		 <5>	 9/27/94	KON		Added function to return game point values.
		 <4>	 9/25/94	KON		Pin ratings at zero.
		 <3>	 9/24/94	KON		wins are now 2, ties 1, and losses 0. Made normal function array
									a const.
		 <2>	 9/24/94	KON		First checked in.

	To Do:
*/

// OBSOLETE!


