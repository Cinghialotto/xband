/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: ServerDataBase.h,v 1.100 1996/03/09 18:33:30 fadden Exp $
 *
 * $Log: ServerDataBase.h,v $
 * Revision 1.100  1996/03/09 18:33:30  fadden
 * Added kBoxFlag_MindWipe.
 *
 * Revision 1.99  1996/01/10  14:51:52  hufft
 * use libphonedb
 *
 * Revision 1.98  1996/01/04  22:56:11  hufft
 * added pop mail
 *
 * Revision 1.97  1995/12/20  19:09:38  ansell
 * Changed kMaxRankingInfo to 32 since we have more than 16 SNES games.
 *
 * Revision 1.96  1995/11/30  15:59:37  ansell
 * Took over gamePlatform for failed800PopConnects.
 * Added bits to CSUpdatedFlags for "SendXBAccessMail" and "PopOverRide".
 * Added bits to boxFlags for "BoxPopOverRide"
 *
 * Revision 1.95  1995/11/15  11:06:49  raja
 * Added a bit  kCSUpdatedFlag_collectSetupFee to mark accounts that owe us
 * the setup fee.
 *
 * Revision 1.94  1995/11/13  19:47:16  hufft
 * pop lookup itf changes, rpc returns a list of numbers, and dial patterns
 *
 * Revision 1.93  1995/11/13  16:09:57  davej
 * New fields to support ECP: checkingAccount, bankNumber, datePreNoteSent.
 *
 * Revision 1.92  1995/11/09  14:26:15  davej
 * Added #define kAcqTypeEAMadden96 for userAccount.acqusitionType [sic].
 *
 * Revision 1.91  1995/11/07  16:33:52  steveb
 * Renamed boxAccount->eid to boxAccount->prevSmartCardSerialNumber.  File
 * version is now 41.
 *
 * Revision 1.90  1995/11/06  17:35:03  davej
 * More housecleaning (moved CAT_* and cat_* back out of ServerDataBase.h and
 * into their own new file, ServerCatDefs.h, and #include'd ServerCatDefs.h
 * in ServerDataBase.h).  For compilation problems at UCA&L.
 *
 * Revision 1.89  1995/11/01  16:48:29  chs
 * Added new flag for lastMatchup.flags to indicate that
 * the lastMatchup info is valid.
 *
 * Revision 1.88  1995/11/01  16:19:02  davej
 * Added kBoxFlag_NoSetupFee for EA promotional accounts.  Also added ECP
 * boxFlags bits as placeholders for impending ECP checkin.
 *
 * Revision 1.87  1995/10/27  18:27:13  steveb
 * Just did some long needed housecleaning.  No new code.
 *
 * Revision 1.86  1995/10/23  17:51:59  davej
 * Backed out changes for ECP DB fields.
 *
 * Revision 1.85  1995/10/23  16:42:01  davej
 * For ECP: added three new DB fields to UCAInfo, kUCA_xxx change bits, and
 * two new boxFlags.
 *
 * Revision 1.84  1995/10/19  22:31:18  hufft
 * Japan Database Changes
 *
 * Revision 1.83  1995/10/03  16:57:14  ted
 * Modified lastMatchup struct for XBN estimated usage.
 *
 * Revision 1.82  1995/09/28  20:15:25  hufft
 * Moved the #define PhoneDB_ValidateNumber to the right portion of file
 *
 * Revision 1.81  1995/09/28  14:42:56  hufft
 * Changed to use catapult RPC convention
 *
 * Revision 1.80  1995/09/27  18:40:05  hufft
 * added Common_Phone support for Japan Server
 *
 * Revision 1.79  1995/09/27  15:50:51  chs
 * Changed FindAccessCode to FindUCAInfo.
 *
 * Revision 1.78  1995/09/24  14:05:23  steveb
 * Added XBNUsage struct to BoxAccount.
 *
 * Revision 1.77  1995/09/19  23:58:37  fadden
 * Added kCallWaitingHoser.
 *
 * Revision 1.76  1995/09/17  20:44:32  steveb
 * Added support for "smart" stitcher updates.
 *
 * Revision 1.75  1995/09/13  14:15:38  ted
 * Fixed warnings.
 *
 * Revision 1.74  1995/09/10  22:35:12  fadden
 * Added CompleteEnough constants.
 *
 * Revision 1.73  1995/08/29  16:38:54  ansell
 * Added kBoxFlag_OSTester so we can mark user's to receive early
 * system patches (RattlePatches)(.
 *
 * Revision 1.72  1995/08/27  18:54:18  fadden
 * Fixed a comment (boxFlags is *not* unused).
 *
 * Revision 1.71  1995/08/24  18:45:36  ansell
 * Added kBoxFlag_GameTester to BoxFlags so we can have (you guessed it) 
 * game testers!!!
 *
 * Revision 1.70  1995/08/24  10:03:03  ted
 * Added kBoxFlag_DisableXBN to prevent a box from playing on Nationwide
 * (requested by Customer Service).
 *
 * Revision 1.69  1995/08/21  13:17:30  steveb
 * Caching rpc.segad re-checkin.
 *
 * Revision 1.68  1995/08/15  18:59:33  steveb
 * Revert to Revision 1.66
 *
 * Revision 1.67  1995/08/11  17:39:57  steveb
 * Caching rpc.segad checkin.  Changes too numerous to mention.
 *
 * Revision 1.66  1995/08/11  15:13:23  fadden
 * Renamed some of the reserved fields in CordPullData.
 *
 * Revision 1.65  1995/08/08  16:36:08  steveb
 * Added some new fields to the DB to support cord pull stats.  File version
 * is now 39.
 *
 * Revision 1.64  1995/08/07  21:51:10  fadden
 * Renamed ngpVersion to cordPullData.
 *
 * Revision 1.63  1995/07/26  13:58:15  ansell
 * Added prototype for Database_FindPlayerInfoChanges().
 * Renamed failedServerConnects to totalServerConnects.
 *
 * Revision 1.62  1995/07/25  22:57:43  ted
 * Changed mdoemVersion to char array.
 *
 * Revision 1.61  1995/07/21  18:21:37  ted
 * Changed hasMailFlags account field to modemVersion. Defined Rockwell modem
 * version constants.
 *
 * Revision 1.60  1995/07/17  21:47:13  steveb
 * Added new database fields:
 * 	char *BoxAccount.mciPhoneList
 * 	unsigned long BoxAccount.eid - this used to be osVersion
 * 	unsigned long PlayerAccount.lastPersonInfoChange
 * 	unsigned long PlayerAccount.lastAddrBookCheck
 * File version is now 38
 *
 * Revision 1.59  1995/07/11  14:20:48  fadden
 * Added kMiscPrefsSNESBasicValid, removed boxGlobalCallingAreaOptions.
 *
 * Revision 1.58  1995/07/07  20:58:08  fadden
 * Added kMiscPrefs enum.
 *
 * Revision 1.57  1995/06/19  20:58:48  fadden
 * Changed proto for FindAccountBySerial, and added kFindAccountStatus* for it.
 *
 * Revision 1.56  1995/06/16  19:30:28  davej
 * Defined kBoxFlag_CreditsBroken bit for credits=(0,0,0) fix.  See code in
 * Server_CheckAccountCredits.
 *
 * Revision 1.55  1995/06/13  01:20:43  raja
 * Added kcsUpdatedFlags_ccChanged - this bit will be used to mark accounts
 * whose cc number or expiration has changed.
 *
 * Revision 1.54  1995/06/08  11:16:14  ted
 * Added DataBase_GetExchangeInfo.
 *
 * Revision 1.53  1995/06/02  21:01:47  fadden
 * Changes to support version 37 of the rpc.segad db format, notably addition
 * of hardwareID and other restore-related stuff.
 *
 * Revision 1.52  1995/06/01  15:14:24  fadden
 * Merge in from newbr.
 * -> Changes for new restore stuff, especially to lookups by phone.
 *
 * Revision 1.51  1995/05/31  15:55:36  davej
 * Added kCSUpdatedFlag_AwaitingMaxCredits bit for 6/1/95 billing policy HACK;
 * see also DataBase_UserAccount.c for implementation.
 *
 * Revision 1.50  1995/05/28  20:41:28  jhsia
 * switch to rcs keywords
 *
 * Revision 1.49  1995/05/26  19:03:01  davej
 * Using the currently unused field usedFreeCredits to keep track of how many
 * credits a customer burns during the free-first-month period.  See
 * Server_CheckAccountCredits.c.
 *
 * Revision 1.48  1995/05/25  22:49:21  davej
 * Added kUA_promoDescr bit for PROMO account description string promoDescr.
 *
 * Revision 1.47  1995/05/24  14:18:03  chs
 * Rearranged prototypes for mail.
 *
 * Revision 1.46  1995/05/23  22:09:33  ted
 * Moved XBNSubscribed flag back to restrict area flags.
 *
 * Revision 1.45  1995/05/23  16:31:23  ted
 * Flag movement for XBAND Nationwide.
 *
 * Revision 1.44.2.1  1995/05/22  03:39:01  fadden
 * Shuffled restore-related prototypes around.  Added some new enums.
 *
 * Revision 1.44  1995/05/17  18:12:55  fadden
 * Mark lastGamePhone and gamePlatform as being totally unused.
 *
 * Revision 1.43  1995/05/12  06:04:02  fadden
 * Defined struct ServerPlayerInfo.  Changed FindPlayerInfo to return that
 * instead.
 *
 */

#ifndef __ServerDataBase__
#define __ServerDataBase__

/*
 * Note to the unwary: many of the other server include files include this
 * one.  Not a problem - they're all guarded with #ifndefs at the top - but
 * this needs to have the box includes FIRST; otherwise the other headers
 * that expect the box types to come out of this file will fail.
 */
#include "UsrConfg.h"
#include "BoxSer.h"
#include "Mail.h"
#include "News.h"
#include "GameDB.h"
#include "Errors.h"
#include "PlayerDB.h"
#include "AddressBook.h"
#include "PreformedMessage.h"

#include "Server.h"
#include "ServerCatDefs.h"
#include "DataBase_HardwareID.h"

#include "Common.h"
#include "Common_OpaqueStore.h"

#define kNoLocalPOPDialogString \
"Sorry, we can't find you a local access number in your area for dialing XBAND. "\
"The number we've assigned you may incur additional phone charges."

enum DatabaseErrors {
	kInvalidUserID 					= -2000,
	kNoSuchUserAccount,
	kNoSuchGameID,
	kDuplicateGameID,
	kPatchVersionNotHigher,
	kAccountInvalid,
	kAddingSystemPatchIsFucked,
	kAccountAlreadyExists,
	kChallengeeWaitingForDifferentGame,
	kChallengeeWaitingForDifferentUser,
	kChallengeeNotAvailable,  		/* -1990 */
	kChallengeeWaitingForAutoMatch,
	kChallengeeTooFar,
	kDifferentRomVersion,
	kOpponentNotRegistered,
	kNoSuchBoxAccount,
	kInvalidArguments,
	kInvalidPhoneNumber,
	kLeaveOnQueue,
	kOpponentIsDialing,
	kOpponentIsDialingForWrongGame,	/* -1980 */
	
	kUnexpectedEOF,
	kUnexpectedCode,
	
	kPOPFileIsUpToDate,
	kNoPOPAvailable,
	kLongDistancePOP,
	kInvalidAreaCode,
	kInvalidPrefix,
	kInvalidExchange,

	kResetDefinite,
	kResetMaybe,					/* -1970 */
	kResetUnknown,

	kCallWaitingFucker,

	kOpponentNotFound,
	kWaitingForAnother,
	kCallingRestricted,
	kDoesNotAcceptChallenges,
	kSpecificToAuto,
	
	/* UCA hasn't created you an account.  You cannot log in! */
	kNoPrecreatedBoxAccount,

	kMailNotDelivered_AccountClosed,
	kMailNotDelivered_IncomingMailDisabled,		/* -1960 */
	kMailNotDelivered_OutgoingMailDisabled,
	kMailNotDelivered_TooManyMails,
	kMailNotDelivered_IncomingMailBlocked,
	kMailNotDelivered_OutgoingMailBlocked,
	kChallengeeBlocksYou,
	kRPCLinkFailed,
	
	/* Matcher: cannot make contestant a master */
	kCannotForceMaster,				

	kSlaveUnReachableXBN,
	kSlaveDoesntHaveXBN,

	kReplacementAccount,		// used by restore	/* -1950 */
	kNewAccount,				// used by restore

	kCordPullFucker,

	kNotEnoughCompletedTie,		// completeEnough stuff from Josh
	kEnoughCompletedTie,
	kEnoughCompletedLocalWinner,
	kEnoughCompletedRemoteWinner,

	kCallWaitingHoser,
};

/*
 * You can only have 25 mails waiting to be delivered to you.
 *
 * ("InBox" is probably the wrong label)
 */
#define kMaxMailsInBox	25

/* 
 * How many seconds of drift are acceptable between the Front End and 
 * Server machines.  Used by DataBase_POPLookup() 
 */
#define kServerTimeDriftFudgeFactor	(180)  

/*
 * When building the client side RPC calls, we overload the definitions
 * and change the names.  The following disgusting hack achieves this
 * without the use of prototypes.  clientstubs.c also includes this
 * file and hence we don't even have to change the names of the functions
 * which overload the real routines present only in the server.
 * Only those functions that are overload are to be listed here.  Be
 * careful, not all of them are done this way.
 */
#ifdef	CLIENTRPC

#ifdef REAL_CLIENT_RPC
/*
 * These should *never* be called directly except by Server_WrapperDB.c 
 * and clientstubs.c.  Only those two files define REAL_CLIENT_RPC.  
 * This NonExistant_ assures that!
 * dj 11/9/94.
 */

#define	ServerDataBase_Initialize			RPC_Initialize
#define	ServerDataBase_Shutdown				RPC_Shutdown
#define	ServerDataBase_SaveToDisk			RPC_SaveToDisk
#define DataBase_FindUCAInfoByCSID			RPC_FindUCAInfoByCSID
#define	Database_FindAccount				RPC_FindAccount
#define Database_FindSerialByPhone			RPC_FindSerialByPhone
#define Database_FindSerialByHWID			RPC_FindSerialByHWID
#define Database_FindAccountBySerial		RPC_FindAccountBySerial
#define	Database_CreatePlayerAccount		RPC_CreatePlayerAccount
#define	Database_CreateBoxAndPlayerAccount	RPC_CreateBoxAndPlayerAccount
#define	Database_UpdateUserHandle			RPC_UpdateUserHandle
#define	DataBase_FindUserIdentification		RPC_FindUserIdentification
#define	Database_FindPlayerInfoChanges		RPC_FindPlayerInfoChanges
#define	Database_FindPlayerInfo				RPC_FindPlayerInfo
#define DataBase_GetAccount					RPC_GetAccount
#define DataBase_UpdateAccount				RPC_UpdateAccount
#define	DataBase_AddMailToIncoming			RPC_AddMailToIncoming
#define	DataBase_GetNumIncomingMail			RPC_GetNumIncomingMail
#define	DataBase_GetIncomingMail			RPC_GetIncomingMail
#define	DataBase_MarkMailAsSent				RPC_MarkMailAsSent
#define	DataBase_RemoveSentMail				RPC_RemoveSentMail
#define DataBase_FindUCAByCSID				RPC_FindUCAByCSID
#define DataBase_UpdateUCA					RPC_UpdateUCA
#define Database_CreateNewAccount			RPC_CreateNewAccount
#define Database_NonUCACreateNewAccount		RPC_NonUCACreateNewAccount
#define	Database_NewFindAccount				RPC_NewFindAccount

/* 
 * Delete this when rpc stub is deleted.  this is not a public routine 
 * anymore 
 */
#define	Database_GenerateUniqueBoxSerialNumber RPC_GenerateUniqueBoxSerialNumber	
#else

#define	ServerDataBase_Initialize			NonExistent_RPC_Initialize
#define	ServerDataBase_Shutdown				NonExistent_RPC_Shutdown
#define	ServerDataBase_SaveToDisk			NonExistent_RPC_SaveToDisk

#define DataBase_FindUCAInfoByCSID			NonExistent_RPC_FindUCAInfoByCSID
#define	Database_FindAccount				NonExistent_RPC_FindAccount
#define Database_FindSerialByPhone			NonExistent_FindSerialByPhone
#define Database_FindSerialByHWID			NonExistent_FindSerialByHWID
#define Database_FindAccountBySerial		NonExistent_FindAccountBySerial
#define	Database_CreatePlayerAccount		NonExistent_RPC_CreatePlayerAccount
#define	Database_CreateBoxAndPlayerAccount	NonExistent_RPC_CreateBoxAndPlayerAccount
#define	Database_UpdateUserHandle			NonExistent_RPC_UpdateUserHandle
#define	DataBase_FindUserIdentification		NonExistent_RPC_FindUserIdentification
#define	Database_FindPlayerInfoChanges		NonExistent_RPC_FindPlayerInfoChanges
#define	Database_FindPlayerInfo				NonExistent_RPC_FindPlayerInfo
#define DataBase_GetAccount					NonExistent_RPC_GetAccount
#define DataBase_UpdateAccount				NonExistent_RPC_UpdateAccount
#define	DataBase_AddMailToIncoming			NonExistent_RPC_AddMailToIncoming
#define	DataBase_GetNumIncomingMail			NonExistent_RPC_GetNumIncomingMail
#define	DataBase_GetIncomingMail			NonExistent_RPC_GetIncomingMail
#define	DataBase_MarkMailAsSent				NonExistent_RPC_MarkMailAsSent
#define	DataBase_RemoveSentMail				NonExistent_RPC_RemoveSentMail
#define DataBase_FindUCAByCSID				NonExistent_RPC_FindUCAByCSID
#define DataBase_UpdateUCA					NonExistent_RPC_UpdateUCA
#define Database_CreateNewAccount			NonExistent_RPC_CreateNewAccount
#define Database_NonUCACreateNewAccount		NonExistent_RPC_NonUCACreateNewAccount
#define	Database_NewFindAccount				NonExistent_RPC_NewFindAccount

/* 
 * Delete this when rpc stub is deleted.  this is not a public routine 
 * anymore 
 */
#define	Database_GenerateUniqueBoxSerialNumber NonExistent_RPC_GenerateUniqueBoxSerialNumber

#endif

#define	DataBase_GetLatestSystemVersion RPC_GetLatestSystemVersion
#define	DataBase_GetLatestSystemKeyframeVersion RPC_GetLatestSystemKeyframeVersion
#define	DataBase_GetSystemNumPatches RPC_GetSystemNumPatches
#define	DataBase_GetSystemPatch RPC_GetSystemPatch
#define	DataBase_AddSystemPatch RPC_AddSystemPatch
#define	DataBase_GetKoolStuff RPC_GetKoolStuff
#define	DataBase_GetNewsPage RPC_GetNewsPage
#define	DataBase_GetNumNewsPages RPC_GetNumNewsPages
#define	DataBase_GetLatestNGPVersion RPC_GetLatestNGPVersion
#define	DataBase_GetLatestNGP RPC_GetLatestNGP
#define	DataBase_GetLatestGameVersion RPC_GetLatestGameVersion
#define	DataBase_GetGamePatch RPC_GetGamePatch
#define	DataBase_GetGameName RPC_GetGameName
#define DataBase_GetHighestBox RPC_GetHighestBox
#define DataBase_GetConnectCookie RPC_GetConnectCookie
#define	DataBase_GetNumBroadcastMail RPC_GetNumBroadcastMail
#define	DataBase_GetBroadcastMail RPC_GetBroadcastMail

#define	DataBase_AgeWaitQ RPC_AgeWaitQ
#define DataBase_GetExchangeInfo RPC_GetExchangeInfo
#define	PhoneDB_ValidateNumber			RPC_PhoneDB_ValidateNumber
#define	PhoneDB_ValidatePopAny			RPC_PhoneDB_ValidatePopAny
#define PhoneDB_GetPops	RPC_PhoneDB_GetPops
#define DataBase_Reload RPC_Reload
#define DataBase_Checkpoint RPC_Checkpoint
#define DataBase_ICheckpoint RPC_ICheckpoint
#define DataBase_GetZipTown RPC_GetZipTown
#define DataBase_GetDbItem RPC_GetDbItem

#endif /* CLIENT_RPC */

Err RPC_CloseConnection(void);

Err ServerDataBase_Initialize(void);
Err ServerDataBase_Shutdown(void);
void ServerDataBase_SaveToDisk(void);
void ServerDataBase_SaveIfNeeded(void);
void ServerDataBase_AskForSave(void);

// #of debugging fields.  This affects both boxAccount and playerAccount.
// You MUST update sega.x as well if you change this.  The good news is,
// changing this value does not invalidate the save file, so you don't
// need to change happy_region.
//
#define kNumDebugFields	4

#define kX25AddressSize	25

// One of these for each connect; Looked at only by UCA to settle billing disputes.
//
typedef struct ConnectInfo {
	unsigned char playerNum;	// which player (0-3). CAT_FLD_SCCONN_PLAYER
	unsigned long date;			// unix time(2) format CAT_FLD_SCCONN_TYPE
	unsigned char connectType;	
	unsigned long length;		// length of the call. CAT_FLD_SCCONN_LENGTH

	// Source node address for x25 call. CAT_FLD_SCCONN_ADDRESS
	char x25Address[kX25AddressSize];	

	// # of credits that this connect cost. CAT_FLD_SCAT_CONN_COST
	long cost;					

	// which number he dialed (if any).	CAT_FLD_SCAT_NUM_TOCALL
	char phoneNumber[kPhoneNumberSize];	

	// status of last game. CAT_FLD_SCAT_GAME_STATUS
	unsigned char lastGameStatus;	
} ConnectInfo;


// A fatter form of NetErrorRecord, for keeping a long running total.
typedef struct ServerNetErrorRecord {
	unsigned long serverConnects;			// may be redundant if cleared each server contact
	unsigned long peerConnects;				// may be redundant if cleared each server contact
	unsigned long framingError;
	unsigned long overrunError;
	unsigned long packetError;
	unsigned long packetRetransError;
	unsigned long callWaitingInterrupt;
	unsigned long noDialtoneError;
	unsigned long serverBusyError;
	unsigned long peerBusyError;
	unsigned long serverDisconnectError;
	unsigned long peerDisconnectError;
	unsigned long serverAbortError;			// if we were connected to the server and asked for abort
	unsigned long peerAbortError;				
	unsigned long serverNoAnswerError;		// Originate timed out
	unsigned long peerNoAnswerError;		// Originate timed out
	unsigned long serverHandshakeError;		// Connection started but failed.
	unsigned long peerHandshakeError;		// Connection started but failed.
	unsigned long serverX25NoServiceError;	// if there are no circuits available
	unsigned long callWaitingError;			// we got call waiting during connection
	unsigned long remoteCallWaitingError;	// remote modem got call waiting
	unsigned long scriptLoginError;			// selected script flaked out
	unsigned long unused1;
	unsigned long unused2;
	unsigned long unused3;
} ServerNetErrorRecord; 

// One of these for every cartridge played on the box; pointer in
// PlayerAccount.  The "details" are split into a substructure purely
// for poid-happiness.
//
#define kRankNumDays	8

typedef struct RankingInfoDetails {
	long matchWinsTimesTwo;
	long matchLossesTimesTwo;
	long dbid;
	long rankingFlags;
	char dailyToday;
	long dailyDate[kRankNumDays];
	char dailyWins[kRankNumDays];
	char dailyEvilResets[kRankNumDays];
	char dailyTotalGames[kRankNumDays];  
	char dailyCordPulls[kRankNumDays];
} RankingInfoDetails;

typedef struct RankingInfo {
	long gameID;

	// for marketing
	unsigned long totalXBandPoints;	// a/k/a xpoints.  CAT_FLD_SCRANK_POINTS

	// for Kon
	long rating;					// CAT_FLD_SCRANK_RATING
	long numOpponentsPlayed;		// CAT_FLD_SCRANK_NUMOPPONENTSPLAYED
	long totalWinsTimesTwo;			// CAT_FLD_SCRANK_WINS*2
	long totalLossesTimesTwo;		// CAT_FLD_SCRANK_LOSSES*2

	// just for secret rankings
	long pointsFor;					// CAT_FLD_SCRANK_POINTSFOR
	long pointsAgainst;				// CAT_FLD_SCRANK_POINTSAGAINST
	
	// time_t for last play  CAT_FLD_SCRANK_LASTPLAY_T
	unsigned long timeOfLastPlay;			

	RankingInfoDetails	detail;
} RankingInfo;

// values for rankingFlags in RankingInfoDetails
//
#define kRankingIsProvisional	1L
#define kRankingDirty			(1L<<1)

// (65536*32768 - 1) caused an "integer overflow" warning from gcc
#define kMaxXBandPoints	((unsigned long)(65536*32767 +65535)) // max signed int

#define kMaxRankingInfo	32	// temporary

// Everything needed to uniquely identify my previous matches, so we don't
// get matched again too soon.
//
typedef struct PreviousOpponent {
	unsigned long		when;			// UNIX time(2); zero means not valid
	BoxSerialNumber		oppBoxSerialNumber;
	char				oppPlayer;		// 0-3
} PreviousOpponent;

// #of these to keep track of
#define kMaxPreviousOpponent	4

// for LastMatchup.callType field
#define kLocalCall				1
#define kLongCall				2
#define kXBNCall				3

// flag bits for LastMatchup.flag
#define kLM_tallyBoxEst			(1<<0)
#define kLM_weWereMatched		(1<<1)

// Who I played last, needed for ratings.  Because your next rating depends
// on the skill level of your opponent, we need to copy the opponent's
// rankingInfo struct in here.
//
typedef struct LastMatchup {
	// Identify the exact matchup.  The data in here gets copied
	// into the previousMatches list in the playerAccount after a successful
	// match.  It's only set by the master.
	//
	PreviousOpponent	prevOpponent;	// who we played last
	char				player;			// 0-3 (who I played as last time)
	char				wasSpecific;	// 1=I challenged, 2=he chal, 3=both
	char 				callType;		// kLocalCall(1), kLongCall(2), or kXBNCall(3)
	char				flags;			// tallyBoxEst, etc.
	long				magicCookie;	// cookie used on peer connect
	RankingInfo			oppRankingInfo;	// rank of opponent before match began
	UserName			oppUserName;	
	long				when;			
} LastMatchup;

#define kLastIChallenged	0x01
#define kLastOppChallenged	0x02
#define kLastChallengeMask	(kLastIChallenged|kLastOppChallenged)
#define kLastMaster			0x80

// This gets set when I'm the slave, so the next time I log in the server
// can figure out if I'm still on a queue.
//
typedef struct LastSlaveInfo {
	long				gameID;				// what game I wanted
	long				slaveExpireWhen;	// time(2) when we expire
	long				contestantID;		// to make dequeue easy
	long				slaveQueuedWhen;	// time(2) when we were enqueued
	long				randomVal;			// random val sent down
} LastSlaveInfo;

// One of these for every day of the week (or one for Mon-Fri and one for
// Sat-Sun).  Contained in BoxAccount.
typedef struct Restriction {		// need to define what these mean
	short start;
	short end;
} Restriction;

// RestrictArea
#define kRestrictArea_dialLocal						(0L)	// Obsolete - Don't use this!
#define kRestrictArea_dialLongDistance				(1L)	// for both challenge and playerList: 0=local only, 1=LD okay
#define kRestrictArea_playerListDialLongDistance	(1L<<1)	// for playerList challenges: 0=local only, 1=LD okay
#define kRestrictArea_temporaryDialLongDistance		(1L<<2)	// for all challenges if you are in some bumfuck location.
#define kRestrictArea_dialLocalPreferred            (1L<<3) // user temporarily turns off long distance challenges
#define kRestrictArea_XBNLongDistance        		(1L<<5) // both challenge and playerlist XBAND Nationwide
#define kRestrictArea_XBNPlayerListLongDistance		(1L<<6) // playerlist-only XBAND Nationwide
#define kRestrictArea_XBNSubscribed					(1L<<7) // player has ever subscribed to XBN

#define kRestrictArea_longDistanceCapableMask \
			(kRestrictArea_dialLongDistance \
			|kRestrictArea_playerListDialLongDistance \
			|kRestrictArea_temporaryDialLongDistance \
			|kRestrictArea_XBNLongDistance \
			|kRestrictArea_XBNPlayerListLongDistance)

#define kRestrictArea_XBNMask \
			(kRestrictArea_XBNLongDistance \
			|kRestrictArea_XBNPlayerListLongDistance)
			
#define kRestrictArea_longOnlyCapableMask \
			(kRestrictArea_dialLongDistance \
			|kRestrictArea_temporaryDialLongDistance \
			|kRestrictArea_XBNLongDistance)

#define kRestrictArea_PlayerListLDCapableMask \
			(kRestrictArea_playerListDialLongDistance \
			|kRestrictArea_XBNPlayerListLongDistance)
			

// Restriction Times
#define kRestrictionTime_PlayAnytime	(0L)
#define kRestrictionTime_PlayNever		(0xffffffffL)


typedef struct NewsChannel {			// CAT_FLD_ACAT_NEWS_STATE
	unsigned long	channelNumber;
	unsigned long	lastArticleRead;	// CAT_FLD_ACNS_LAST_ARTICLE
} NewsChannel;

#define kMaxNewsChannels	4
#define kBroadcastMailChannel	0
#define kBandwidthChannel		1
#define kXBandNewsChannel		2
#define kVIPBMailChannel		3		// VIP-only broadcast news

// Rockwell modemVersion
//
#define kRockwellUnknown		0				// initial state
#define kRockwell2324			1				// definately 2324
#define kRockwell2424			2				// definately 2424
#define kRockwell2324Assumed	3				// probably 2324
#define kRockwell2424Assumed	4				// probably 2424

#define kRockwell2324Pattern	0x44203030		/* 'D 00' */
#define kRockwell2424Pattern	0x45203030		/* 'E 00' */
#define kRockwellMaskPattern	0xFF000000		/* To isolate revision */

//
// SmartCard rental program info.
//
typedef struct RentalInfo {
	long		dateFirstConnect;		// if 0, this is not a rental acct
	long		rentalCardSerial;
	long		rentalCardPrefix;
	long		reserved1;
} RentalInfo;

//
// Box preferences, used for box restores.
//
typedef struct MiscPreferences {
	char		valid;						// fields have been initialized?
	char		pad[3];						// (not used)
	long		xbandOptions1;				// sega/snes (Options1Valid)
	long		phoneOptions;				// snes
	long		soundOptions;				// snes
	long		user0WaitTime;				// snes
	long		user1WaitTime;				// snes
	long		user2WaitTime;				// snes
	long		user3WaitTime;				// snes (end of SNESBasicValid)
	long		reserved0;					// snes
	long		user0ButtonOptions;			// snes
	long		user1ButtonOptions;			// snes
	long		user2ButtonOptions;			// snes
	long		user3ButtonOptions;			// snes
	long		reserved1;
	long		reserved2;
} MiscPreferences;

// Each constant must include everything that was part of the previous,
// so "<" and ">=" work.
//
enum {
	kMiscPrefsInvalid = 0,			// not valid
	kMiscPrefsOptions1Valid,		// only xbandOptions1 is valid
	kMiscPrefsSNESBasicValid,		// all above the userXButtonOptions valid
	kMiscPrefsAllValid				// every field is valid
};


// Data kept on cord-pullers.
//
typedef struct CordPullData {
	unsigned short		weightedAverage;	// wtd avg ambient level
	unsigned short		min;		// minimum ambient level detected
	unsigned short		max;		// maximum
	unsigned short		reserved3;
} CordPullData;

//
// The kCSUpdatedFlag are for allowing the Customer Service organization (U.C.A.) to
// do things that affect the account next time the box logs in.
//
#define kCSUpdatedFlag_BindLostModem		(1<<0)	/* bind modem to this account if multiple at a single phonenum when restoring */
#define kCSUpdatedFlag_DisableOutgoingMail	(1<<1)	/* disable sending of mail if he is a foul-mouth sunofabitch */
#define kCSUpdatedFlag_Force800Restore		(1<<2)	/* force box to do a 1-800 restore */
#define kCSUpdatedFlag_UpdatedRestrictions	(1<<3)	/* restrictions were updated */
#define kCSUpdatedFlag_ClearBoxPassword		(1<<4)	/* clear the box password */
#define kCSUpdatedFlag_SendPersonification	(1<<5)	/* resend the personification (maybe we edited it for obscenity..) */
#define kCSUpdatedFlag_SendAllBoxInfo		(1<<6)	/* resend all info  */
#define kCSUpdatedFlag_ReplacementModem		(1<<7)	/* resend all info (set this if a customer replaces their modem due to defect). */
#define kCSUpdatedFlag_HomeTownUpdated		(1<<8)	/* resend hometown to box */
#define kCSUpdatedFlag_SplitModemIncest		(1<<9)	/* if modem logs in with this bit set, and their boxPhone
								doesn't match the gamePhone in the account, and
								if their boxPhone doesn't match the originalGamePhone
								in the account, then set their boxid to -1, -1 and
								force the box to look for its own damned account.
								4.10.95  DJ    */
#define kCSUpdatedFlags_DisableInternetMail	(1<<10)	/* disable receiving internet mail */

#define kCSUpdatedFlags_OrigPhoneChanged	(1<<12)	/* Original Game phone has changed. Send info to MCI. This bit will be set on by CatAdmin/UCA and cleared only by MCI batch process*/
#define kCSUpdatedFlag_AwaitingMaxCredits	(1<<13)	/* HACK to handle billing policy; see DataBase_UserAccount.c -- davej 5/31/95 */

#define kCSUpdatedFlag_ccChanged	(1<<14)	/* cc number has changed. Hit the account for plan fee tonight */
#define kCSUpdatedFlag_collectSetupFee	(1<<15)	/* cc number has changed. Hit the account for plan fee tonight */
#define kCSUpdatedFlag_SendXBAccessMail	(1<<16) /* Notify SunSega to send mail containing POP list on next connect */
#define kCSUpdatedFlag_PopOverRide		(1<<17) /* Tell SunSega to force a POP override to occur on next connect */


//
// These are more permanent flags for the box account.
// Bits 0-15 are owned/managed by Oracle/UCA. Bits 16-31 are owned/managed by SunSega.
//
// [ The term "owned/managed" doesn't explain much, but it appears you can
//   set bits 0-15 from wherever and they get stitched appropriately.  The
//   "SunSega" bits presumably just aren't stitched into Oracle. ++ATM ]
//
#define kBoxFlag_FilterMail			(1<<0)	/* filter incoming mail for profanity		*/
#define kBoxFlag_KioskBox			(1<<1)	/* store kiosk demo box.  has special qualities! */
#define kBoxFlag_DisableIncomingMail (1<<2)	/* don't allow mail to be sent to this box. */
#define kBoxFlag_DisableOutgoingMail (1<<3)	/* don't allow mail to be sent from this box. */
#define kBoxFlag_CreditApproved		(1<<4)	/* Credit card has been charged at least once. OK to make XBN calls*/
#define kBoxFlag_FreeXBN			(1<<5)	/* Allow box to make free XBN calls (guest accounts) */
#define kBoxFlag_VIP				(1<<6)	/* Allow box to be a VIP (free XBN, some restrictions, and test patches) */
#define kBoxFlag_XBNCallable		(1<<7)	/* Obsolete */
#define kBoxFlag_DisableXBN			(1<<8)	/* Temporarily disable XBN for box (for Customer Service) */
#define kBoxFlag_GameTester			(1<<9)	/* Allowed to test play early available games */
#define kBoxFlag_OSTester			(1<<10)	/* Allowed to test early available OS Patches*/
#define kBoxFlag_ecpPaperworkReceived		(1<<11)	/* ECP: customer agmt/check received          */
#define kBoxFlag_preNoteSent			(1<<12)	/* ECP: pre-note transaction issued to bank   */
#define kBoxFlag_NoSetupFee			(1<<13)	/* Don't collect setup fee (used for EA promo */
							/* intended to run only thru 951215...?)      */
#define kBoxFlag_MindWipe			(1<<14)		/* wipe it's brain on next connect */

#define kBoxFlag_VIPBox				(1<<16)	/* box put into vip mode (disable chat/play again) */
#define kBoxFlag_TourneyBox			(1<<17)	/* box put into tourney mode (disable certain features) */
#define kBoxFlag_CreditsBroken			(1<<18)	/* credit counters were detected to be bad (0,0,0) */
#define kBoxFlag_PopOverRide			(1<<19) /* Tell Box to use override POP numbers */
#define kBoxFlag_PopOverRideTest		(1<<20) /* Tell Box using special POP override */
												/* pop is not from default list */


// Stuff about the box; contained in Account.
//
typedef struct BoxAccount {					// CAT_FLD_ACCT_CATAPULT
	unsigned long		magicID;			// temporary kluge
	long				platformID;			// *** ADD TO DATABASE
	BoxSerialNumber		box;				// CAT_FLD_ACAT_BOX_REGION, CAT_FLD_ACAT_BOX_ID
	HardwareID			hardwareID;			// hardwareID for this account
	HardwareID			prevHardwareID;		// previous hwid on this account
	RentalInfo			rentalInfo;			// rental program data
	long				validationToken;	// used for incest detection
	Password			password;			// used by server to disable box when no credits in account. CAT_FLD_ACAT_PASSWD
	Hometown			homeTown;			// CAT_FLD_ACAT_HOMETOWN
	Hometown			originalHomeTown;	// *** ADD TO DATABASE
	phoneNumber			gamePhone;			// CAT_FLD_ACAT_GAME_PHONE
	phoneNumber			originalGamePhone;	// CAT_FLD_ACAT_ORIG_GPHONE
	phoneNumber			lastGamePhone;		// *NOT USED* CAT_FLD_ACAT_LAST_GPHONE
	phoneNumber			overrideANI1;		//
	phoneNumber			overridePOP1;		//
	phoneNumber			overrideANI2;		//
	phoneNumber			overridePOP2;		//
	long				dateLastChangedGamePhone;	// CAT_FLD_ACAT_GPHONE_CHANGE_T
	phoneNumber			popPhone;			// CAT_FLD_ACAT_POP_PHONE
	phoneNumber			altPopPhone;		// CAT_FLD_ACAT_ALTPOP_PHONE
	char				*mciPhoneList;		// ?
	XBNBoxUsage			xbnUsage;
	unsigned long		failed800PopConnects;	// # of sequential 800 connects
	unsigned long		totalServerConnects;	// CAT_FLD_ACAT_SERVER_FAILS
	unsigned long		failedClientConnects;	// CAT_FLD_ACAT_PEER_FAILS
	long				usedCredits;		// credits the box has used this month.
	long				maxCredits;			// max # credits you can use per month.  -1 == unlimited.
	long				startCredits;		// how many credits you started the month with (0).
	long				usedFreeCredits;	// **HACK** stolen to track credits used in free-first-month period (Server_CheckAccountCredits.c)
	long				maxFreeCredits;		// *** ADD TO DATABASE
	long				startFreeCredits;	// *** ADD TO DATABASE
	Restriction			restrictInfo[2];	// one for each day of the week CAT_FLD_ACAT_RESTRICT_[A,B]_[START,END]
	unsigned long		restrictArea;		// local or long distance CAT_FLD_ACAT_RESTRICT_AREA
	unsigned long		boxFlags;			// CAT_FLD_ACAT_BOXFLAGS
	long				prevSmartCardSerialNumber;
	CordPullData		cordPullData;		// info on cord pulls
	LastSlaveInfo		lastSlaveInfo;		// *** ADD TO DATABASE
	LastMatchup			lastMatchup;		// CAT_FLD_ACAT_LAST_MATCHUP
	ServerNetErrorRecord netErrorTotals;	// CAT_FLD_ACAT_NET_ERRS
	MiscPreferences		miscPreferences;	// restore prefs
	unsigned long		numberOfBoxCrashes;	// CAT_FLD_ACAT_CRASH_CNT
	long				dateOfLastBoxCrash;	// CAT_FLD_ACAT_CRASH_T
	unsigned long		numNewsChannels;
	NewsChannel			newsChannels[kMaxNewsChannels];
	unsigned long		debug[kNumDebugFields];	// CAT_FLD_CAT_DEBUG
	unsigned long		csUpdatedFlags;		// track what the CS or other tools did to the account.
	unsigned char 		modemVersion[4];	// Rockwell version of box [0]
	OpaqueStore			opaqueStore;		// opaque client data
} BoxAccount;

// Address book entries.  Array contained in PlayerAccount.
typedef struct AddressBook {			// CAT_FLD_SCAT_ADDRESS_BOOK
	unsigned char		serverUniqueID;	// 0-9 ? CAT_FLD_SCAB_SERVER_UNIQID
	BoxSerialNumber		box;			// CAT_FLD_SCAB_BOXID, CAT_FLD_SCAB_BOXREGION
	unsigned char		playerNumber;	// 0-3 CAT_FLD_SCAB_PLAYERNUM
	unsigned long		lastPlayed;		// SEGA date: when last played CAT_FLD_SCAB_LAST_PLAY
	unsigned long		wins;			// CAT_FLD_SCAB_WINS
	unsigned long		losses;			// CAT_FLD_SCAB_LOSSES
} AddressBook;


// All the relevant information about a specific player on a box.  Contained
// in Account.
//
typedef struct PlayerAccount {
	unsigned long		magicID;			// used for kluge
	char				player;				// 0-3
	UserName			userName;			// CAT_FLD_SCAT_HANDLE
	UserName			filteredUserName;	// no whitespace, all lowercase. CAT_FLD_SCAT_FHANDLE_ROOT
	long				filteredNameSuffix;	// *** ADD TO DATABASE
	short				iconID;				// CAT_FLD_SCAT_ICON
	short				colorTableID;		// CAT_FLD_SCAT_COLORTABLEID
	char				*openTaunt;			// CAT_FLD_SCAT_TAUNT
	char				*personInfo;		// CAT_FLD_SCAT_PERSON_INFO
	Password			password;			// CAT_FLD_SCAT_PASSWD
	Password			passwordEraseCode;	// set by server.  Allows player to wipe out passwd if they call UCA. CAT_FLD_SCAT_ERASE_CODE
	unsigned long		birthday;			// CAT_FLD_SCAT_BDAY
	unsigned long		playerFlags;		// stuff like acceptChallenges PCP+FLD_SCAT_PLAYERFLAGS
	unsigned long		lastPersonInfoChange;
	unsigned long		lastAddrBookCheck;
	unsigned long		autoMatchConnects;	// CAT_FLD_SCAT_MATCH_CONNECTS
	unsigned long		challengeConnects;	// CAT_FLD_SCAT_CHALLENGE_CONNECTS
	unsigned long		msgCheckConnects;	// CAT_FLD_SCAT_MAIL_CONNECTS
	short				numEvilResets;		// *** ADD TO DATABASE
	short				numIffyResets;		// *** ADD TO DATABASE
	short				numRankingInfo;		// #of elements in rankingInfo
	short				nextPrevOpponent;	// next index to use in PrevOpp
	RankingInfo			rankingInfo[kMaxRankingInfo];	// BRAIN DAMAGE; should be *
	PreviousOpponent	prevOpponent[kMaxPreviousOpponent];		// CAT_FLD_SCAT_PREV_OPP
	AddressBook			addressBook[kMaxAddressBookEntries];	// CAT_FLD_SCAT_ADDRESS_BOOK
	unsigned long		debug[kNumDebugFields];
	short				mailInBox[kMaxInBoxEntries];	// track which mail items are on the box.
	unsigned long		numNewsChannels;
	NewsChannel			newsChannels[kMaxNewsChannels];
	unsigned long		csUpdatedFlags;		// track what the CS or other tools did to the account.
	long				customIconSize;
	unsigned char *		customIcon;			// this better come last (RPC) CAT_FLD_SCAT_CUSTOMICON
	OpaqueStore			opaqueStore;		// opaque client data
} PlayerAccount;

// playerFlags
#define kPlayerFlags_acceptChallenges	(1L)


// Stuff from Oracle that is controlled by UCA.
//
#define kZipCodeSize		12	// 5+1+4+1 + 1 to make it 3 longs
#define kPromoStringSize	20	// 19 chars + NUL should be enough

typedef struct UserAccount {
	unsigned long		accountStatus;	// open, closed, pending, suspended.
	unsigned long		activationDate;	// UNIX time(2); zero means not valid
	
	unsigned long		customerServiceID;
	unsigned long		dateLastConnect;
	unsigned long		accountFlags;		// why suspended.
	long				typeLastConnect;	// mail-only or challenge request
	char				zipCode[kZipCodeSize];	// not needed? 950602
	unsigned long		dateFirstConnect;	// *** ADD TO DATABASE
	long				billingType;		// *** ADD TO DATABASE
	long				acqusitionType;		// how we got this customer
	unsigned long		closedDate;			// UNIX time(2)
	char				promoString[kPromoStringSize];	// which promotion acct is used for
} UserAccount;

// Values for userAccount.acqusitionType [sic]
//
#define	kAcqTypeEAMadden96	(500)				// EA's Madden '96 deal

// Account is the box info plus info on one of the four players
//
typedef struct Account {
	UserAccount			userAccount;
	BoxAccount			boxAccount;
	PlayerAccount		playerAccount;

	Boolean				playerAccountValid;	// there could be a boxAccount with no playerAccount for a given playernum.  [ why isn't this in boxFlags...? ]

	long				stitcherUpdate;
	long				userModified;
	long				boxModified;
	long				playerModified;

	void				*oracleCache;
} Account;

/*
 * Additional UCA poop.
 */
typedef struct UCAInfo_t {
	unsigned int	cs_id;			// customer service id #
	char		*cc_num;		// credit card #
	char		*cc_expr;		// credit card expiration date

	char		*checkingAccount;	// ECP: checking account number
	char		*bankNumber;		// ECP: bank routine number
	long		datePreNoteSent;	// ECP: when pre-note was issued (time_t)

	char		*prodstr;		// product string
	long		prod_activate;		// who the fuck knows? (really a time_t)
	long		prod_cycle_start;	// who the fuck knows? (really a time_t)
	long		prod_terminate;		// who the fuck knows? (really a time_t)

	char		*home_phone;		// ET phone home
	char		*cc_name;		// name on credit card
	char		*address;		// billing street address
	char		*city;			// billing city
	char		*state;			// billing state
	char		*zip;			// billing zip code
	char		*country;		// duh

	char		*access_code;		// who the fuck knows?
	long		terminate;		// termination date of account? (really a time_t)

	long		created;		// (read only) (really a time_t) who the fuck knows?
	char		*comment;		// (read only) who the fuck knows?
	unsigned int	player_cnt;		// # of players on this box (computable somewhere)
	double		balance;		// compute this smeg
	double		credits;		// compute this smeg
} UCAInfo;

/*
 * Player smeg that UCA needs
 */
typedef struct PInfo_t {
	int		players[4];		// player number
	UserName	names[4];		// usernames of the losers
	Password	eraseCodes[4];		// erase codes for the losers
} PInfo;

/*
 * Analogue of Account that holds UCA poop.
 */
typedef struct UCAAccount_t {
	UCAInfo		ucaInfo;
	PInfo		pInfo;
	unsigned long	ucaModified;		// tells which fields were modified in UCAInfo struct
} UCAAccount;

// API routines
Account *DataBase_GetAccount(const userIdentification *userID);
Err DataBase_UpdateAccount(const Account *account);
Err DataBase_UpdateUCA(Account *account, UCAAccount *ucaaccount);

//
// New happy APIs for DJ.  10/07/94.
//
Account *DataBase_GetAccountByPhoneNumber(phoneNumber gamePhone, unsigned char playerNum);
Err DataBase_StoreConnectInfo(const ConnectInfo *connectInfo, Account *account);
//
// Err DataBase_AddCreditsToAccount(const userIdentification *userID, unsigned long numCredits);


// definition of bit fields for Account->boxModified and playerModified
#define kPA_none					(0L)
#define kPA_magicID					(1L)
#define kPA_userName				(1L<<1)			// incl filteredUserName, suffix
#define kPA_iconID					(1L<<2)
#define kPA_openTaunt				(1L<<3)
#define kPA_colorTableID			(1L<<4)
#define kPA_personInfo				(1L<<5)
#define kPA_password				(1L<<6)
#define kPA_birthday				(1L<<7)
#define kPA_msgState				(1L<<8)
#define kPA_msgChannels				(1L<<9)
#define kPA_autoMatchConnects		(1L<<10)
#define kPA_challengeConnects		(1L<<11)
#define kPA_msgCheckConnects		(1L<<12)
// #define kPA_totalSercerConnects		(1L<<13)
// #define kPA_failedClientConnects		(1L<<14)
#define kPA_ranking					(1L<<15)		// numRankInf and rankInf
#define kPA_addressBook				(1L<<16)		// all 10 entries
#define kPA_playerFlags				(1L<<17)
#define kPA_customIcon				(1L<<18)		// customIconSize, customIcon
#define kPA_mailInBox				(1L<<19)		// all 10 entries
#define kPA_prevOpponent			(1L<<20)		// all 4 entries + nextPO
#define kPA_erasePassword			(1L<<21)
#define kPA_newsChannels			(1L<<22)		// num and channels
#define kPA_csUpdatedFlags			(1L<<23)
#define kPA_numResets				(1L<<24)		// both iffy and evil
#define kPA_opaqueStore				(1L<<25)
#define kPA_lastPersonInfoChange	(1L<<26)
#define kPA_lastAddrBookCheck		(1L<<27)

#define kPA_debug					(1L<<31)

//
// This is the list of debug fields that are used in the PlayerAccount:
//	debug0: used for redial loops.  set by mail to "redial".
//	debug1: used for dialing all POPs.
//	debug2: used for dialing all POPs.
//	debug3: unused.

#define kBA_none				(0L)
#define kBA_box					(1L)
#define kBA_homeTown				(1L<<1)		// incl orig
#define kBA_gamePhone				(1L<<2)		// incl orig, last, and date
#define kBA_popPhone				(1L<<3)		// includes altPopPhone
#define kBA_failed800PopConnects	(1L<<4)
//#define kBA_authCode				(1L<<5)		// not used
#define kBA_restrictInfo			(1L<<6)		// applies to restrictinfo and restrictarea
#define kBA_prevSmartCardSerialNumber (1L<<7)		
#define kBA_cordPullData			(1L<<8)
#define kBA_gameInfo				(1L<<9)
#define kBA_credits					(1L<<10)	// six different items
#define kBA_password				(1L<<11)
#define kBA_boxFlags				(1L<<12)
#define kBA_totalServerConnects		(1L<<13)
#define kBA_failedClientConnects	(1L<<14)
#define kBA_lastMatchup				(1L<<15)
#define kBA_crashes					(1L<<16)		// numCrashes, lastCrash
#define kBA_newsChannels			(1L<<17)		// num and channels
#define kBA_csUpdatedFlags			(1L<<18)
#define kBA_lastSlaveInfo			(1L<<19)
#define kBA_opaqueStore				(1L<<20)
#define kBA_modemVersion			(1L<<21)
#define kBA_platformID				(1L<<22)
#define kBA_hardwareID				(1L<<23)	// hardwareID, prevHardwareID
#define kBA_validationToken			(1L<<24)
#define kBA_overridePhone			(1L<<25)	// overrideANI1/POP1/ANI2/POP2
#define kBA_miscPreferences			(1L<<26)
#define kBA_rentalInfo				(1L<<27)
#define kBA_mciPhoneList			(1L<<28)
#define kBA_xbnUsage				(1L<<29)
// no entry for netErrorTotals; assume it gets updated every time
#define kBA_debug					(1L<<31)

//
// This is the list of debug fields that are used in the BoxAccount:
//	debug0: (has something to do with boxes being turned off)
//	debug1: kBA_debug_dial9
//	        kBA_debug_RattlePatch
//	debug2: when we last sent news to box (UNIX time format).
//	debug3: unused.
//
#define kBA_debug_dial9				0x01
#define kBA_debug_RattlePatch		0x02


// UserAccount modified flags (in Account.userModified field)
//
#define kUA_none					(0L)
#define kUA_accountStatus			(1L)
#define kUA_activationDate			(1L<<1)
#define kUA_customerServiceID		(1L<<2)
#define kUA_lastConnect				(1L<<3)		// dateLastConnect and typeLastConnect
#define kUA_accountFlags			(1L<<4)
#define kUA_zipCode					(1L<<5)
#define kUA_dateFirstConnect		(1L<<6)
#define kUA_billingType				(1L<<7)
#define kUA_promoDescr				(1L<<8)		// only used inside uca lib?
#define kUA_promoString				(1L<<9)
#define kUA_acquisitionType			(1L<<10)
#define kUA_closedDate				(1L<<11)


/*
 * UCAAccount modified flags.
 */
#define	kUCA_none				(0L)
#define kUCA_cc_num				(1L)
#define kUCA_cc_expr				(1L<<1)
#define kUCA_prodstr				(1L<<2)
#define kUCA_prod_activate			(1L<<3)
#define kUCA_prod_cycle_start			(1L<<4)
#define kUCA_prod_terminate			(1L<<5)
#define kUCA_home_phone				(1L<<6)
#define kUCA_cc_name				(1L<<7)
#define kUCA_address				(1L<<8)
#define kUCA_city				(1L<<9)
#define kUCA_state				(1L<<10)
#define kUCA_zip				(1L<<11)
#define kUCA_country				(1L<<12)
#define kUCA_access_code			(1L<<13)
#define kUCA_terminate				(1L<<14)
#define kUCA_created				(1L<<15)
#define kUCA_comment				(1L<<16)
#define kUCA_player_cnt				(1L<<17)
#define kUCA_balance				(1L<<18)
#define kUCA_credits				(1L<<19)
#define kUCA_checkingAccount			(1L<<20)
#define kUCA_bankNumber				(1L<<21)
#define kUCA_datePreNoteSent			(1L<<22)

//typedef struct UserAccountInfo {
//	userIdentification	userID;
//	phoneNumber			boxPhoneNumber;
//} UserAccountInfo;

//Err Database_FindAccountByGamePhoneAndPlayerNum(phoneNumber *newBoxPhoneNumber, unsigned char playerNum, long platformID, Account **account);
//Err Database_FindReplacementAccountByGamePhoneAndPlayerNum(phoneNumber *newBoxPhoneNumber, unsigned char playerNum, long platformID, Account **account);
Err DataBase_FindUCAInfoByCSID(int csid, UCAInfo **ucainfo);
Err Database_FindAccount(const userIdentification *userID, Account **account);
Err Database_FindSerialByPhone(const phoneNumber *phoneNum, long mode, long platformID, BoxSerialNumber *boxp);
Err Database_FindSerialByHWID(const HardwareID *hwid, long platformID, BoxSerialNumber *boxp);
Err Database_FindAccountBySerial(BoxSerialNumber *boxp, int playerNum, long *statusFlagp, Account **accountp);
void ServerDataBase_SaveToDiskTmp(void);

// same as FindAccount, but works even if specified playerAccount isn't there.
//
Err Database_NewFindAccount(const userIdentification *userID, Account **account);

// Values for "mode" flag on Database_FindSerialByPhone.
//
enum {
	kPhoneLookupReplacement,
	kPhoneLookupNew,
	kPhoneLookupAnyOpenUsed,
	kPhoneLookupAnyUsed,
};
// Return values for "statusFlags" in Database_FindAccountBySerial.
//
#define kFindAccountStatusNew			(1L)
#define kFindAccountStatusClosed		(1L<<1)
#define kFindAccountStatusBoxOnly		(1L<<2)

Err DataBase_FindUCAByCSID(unsigned int csid, Account **account, UCAAccount **ucaaccount);
//Err DataBase_FindUCAByGamePhone(phoneNumber *gamePhone, long platformID, Account **account, UCAAccount **ucaaccount);
Err Database_CreatePlayerAccount(userIdentification *userID, long platformID, long *result, Account **account);
Err Database_CreateBoxAndPlayerAccount(userIdentification *userID, phoneNumber *boxPhoneNumber, long platformID, long *result, Account **account);
Err Database_CreateNewAccount(unsigned int csid, phoneNumber *boxPhone, long platformID, char *prodstr, long billingType, Account **account, UCAAccount **ucaaccount);
Err Database_NonUCACreateNewAccount(unsigned int csid, phoneNumber *boxPhone, long platformID, char *prodstr, long billingType, Account **account);
long Database_GetTimeStamp(void);
long Database_IncrementTimeStamp(void);

Err Database_UpdateUserHandle(userIdentification *userID, long platformID, long *result);



// result codes for CreateAccount and UpdateUserHandle
#define kUserNameUniquified		1L

// gets the latest userIdentification for the user account.
Err DataBase_FindUserIdentification(const userIdentification *userID, userIdentification *updatedUserID);


//
// Find player info for address book validation.
//
typedef struct ServerPlayerInfo {
	long		iconPlatformID;		// what platform the ROMIconID matches
	PlayerInfo	playerInfo;
} ServerPlayerInfo;

ServerPlayerInfo **Database_FindPlayerInfoChanges(const userIdentification *userIDList, const userIdentification *userID, const long lastChecked);

ServerPlayerInfo *Database_FindPlayerInfo(const userIdentification *playerID, const userIdentification *userID);

//
// Update the system version and required patches.
//
long DataBase_GetLatestSystemVersion(void);
long DataBase_GetLatestSystemKeyframeVersion(void);
long DataBase_GetSystemNumPatches(long version);
PreformedMessage *DataBase_GetSystemPatch(long version, long patchNum);
Err DataBase_AddSystemPatch(long version, long patchNum, PreformedMessage *patch);


//
// Send kool stuff to the box (news, stats, scores, ads, etc).
//
PreformedMessage *DataBase_GetKoolStuff(void);

//
// Send news to the box
//
ServerNewsPage *DataBase_GetNewsPage(long pageNum, DBType pagetype);
long DataBase_GetNumNewsPages(DBType pagetype, long *modifiedWhen);

//
// Get DataBase objects
//
ServerDbItem *DataBase_GetDbItem(DBType, DBID);
long DataBase_GetHighestBox(int region);

//
// Get unique connection cookie
//
unsigned long DataBase_GetConnectCookie(void);

//
// Update the NGPVersion information if not up to date.
//
short DataBase_GetLatestNGPVersion(long platformID, long special);
PreformedMessage *DataBase_GetLatestNGP(long platformID, short version, long special);


//
// Update Game Patch
//
long DataBase_GetLatestGameVersion(long platformID, long gameID);
PreformedMessage *DataBase_GetGamePatch(long platformID, long gameID, long boxVersion, long *currentVersion);
//char *DataBase_GetGameName(long platformID, long gameID, char *gameName);

//
// Add a new game to the database.  Update to a new game patch version.
//
Err DataBase_NewGame(long platformID, long gameID, long version, char *gameName, PreformedMessage *patch);
Err DataBase_AddGamePatch(long platformID, long gameID, long version, PreformedMessage *patch);


//
// Add Game Results to the database
//
//int DataBase_AddGameResult(userIdentification *userID, const GameResult *result);
//Err DataBase_UpdateRanking(Account *account, const GameResult *result, const GameResult *errorResult);

//
// Lookup your Compuserve POP (comes from CPSNUM.catapult)
//
#ifndef	__PhoneDB_Pop__
#include	"PhoneDB_Pop.h"
#endif

//
// Mail handling
//
Err DataBase_AddMailToIncoming(const Mail *mail);
long DataBase_GetNumIncomingMail(const userIdentification *userID);
Mail *DataBase_GetIncomingMail(const userIdentification *userID, long mailIndex);
void DataBase_MarkMailAsSent(const userIdentification *userID, long mailIndex);
void DataBase_RemoveSentMail(const userIdentification *userID);

long DataBase_GetNumBroadcastMail(unsigned long lastTimeStamp);
Mail *DataBase_GetBroadcastMail(unsigned long *lastTimeStamp, long mailIndex);
void Database_GenerateUniqueBoxSerialNumber(BoxSerialNumber *boxSerialNumber);
void DataBase_PrintMail(const Mail *mail);

unsigned long DataBase_GetCurrentTime(void);
void DataBase_AgeWaitQ(long maxTimeInWaitQ);



//
// Phone number string tweaking.  These should be in *_priv.h, but until
// we have LATA working we need to use them over in the Server_* code.
//
Err DataBase_TweakOpponentPhoneNumber(phoneNumber *oppPhone, const phoneNumber *myPhone);
Err DataBase_GetZipTown(long zip, Hometown town);   /* Get city,state from zipcode */

void DataBase_Reload(void);
void DataBase_Checkpoint(void);
void DataBase_ICheckpoint(void);

#include "ServerDataBase_Util.h"
#include "ServerWrapperDB.h"


#endif __ServerDataBase__
