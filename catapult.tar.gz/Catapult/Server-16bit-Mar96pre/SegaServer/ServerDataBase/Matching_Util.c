/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 *	$Id
 *
 *	$Log: Matching_Util.c,v $
 * Revision 1.5  1996/01/10  14:50:20  hufft
 * use libphonedb
 *
 * Revision 1.4  1995/11/14  20:28:58  hufft
 * rename DataBase_LoadCompuServePops to PhoneDB_Load
 *
 * Revision 1.3  1995/09/27  18:39:59  hufft
 * added Common_Phone support for Japan Server
 *
 * Revision 1.2  1995/05/28  20:41:26  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Matching_Util.c

	Contains:	Routines used by matching stuff

	Written by:	Andy McFadden


	Change History (most recent first):

		<30>	10/26/94	ATM		Fucked around with Matching_Statup for single game matchers.
		<29>	10/19/94	DJ		Removed DataBase_LoadFakeLata.
		<28>	10/15/94	ATM		Logic bug was causing challenge matches to be expired at or
									before the normal wait queue time.
		<27>	10/10/94	ATM		Changed rating to full rankingInfo.
		<26>	 10/9/94	ATM		Print gameID in the contestant print routines.
		<25>	 10/7/94	ATM		Added (and implemented) kOpponentIsDialingForWrongGame.
									Initialize prevOpponent array based on "when".
		<24>	 10/6/94	ATM		Augmented DequeueIfQueued with fancy stuff that generates
									warnings and returns special results.
		<23>	 10/5/94	ATM		Added test game (0x00000001).
		<22>	 10/3/94	ATM		Added call to Reconfigure on bounce.
		<21>	 10/3/94	ATM		Add oppSpecific to LastMatchup and specificShunt to Matchup.
		<20>	 10/1/94	ATM		Removed rankingInfo, and changed skillLevel to rating.
		<19>	 9/30/94	ATM		Changed romID to gamePatchVersion.
		<18>	 9/23/94	ATM		Added a sanity check.
		<17>	 9/23/94	ATM		Implemented more control functions.
		<16>	 9/19/94	ATM		PLogmsg stuff.
		<15>	 9/16/94	DJ		turned on MATCH_BY_AREA_CODE_ONLY
		<14>	 9/16/94	ATM		Changed purgatory queue logging by adding a new argument to
									DumpContestant.  Made specific queue expire people with a
									different timeout.
		<13>	 9/13/94	ATM		Changed to ReloadPhoneStuff.
		<12>	 9/12/94	DJ		added loading of Compuserve POP database as well at LATA
									database (didn't replace LATA because that is still used to stop
									east-west coast opponent matches)
		<11>	 9/12/94	ATM		Handle some new control messages.
		<10>	 9/12/94	ATM		Okay, try that again.
		 <9>	 9/12/94	ATM		Call LoadFakeLata.
		 <8>	 9/12/94	ATM		Implemented MatchingControl stuff.
		 <7>	 9/11/94	ATM		Added MATCH_BY_AREA_CODE_ONLY.  Not tested.
		 <6>	  9/8/94	ATM		Spiffed up the logging.
		 <5>	  9/7/94	ATM		Minor tweaks.
		 <4>	  9/7/94	ATM		Choked on cross-area-code calls.
		 <3>	  9/6/94	ATM		Fixed expiration code.
		 <2>	  9/6/94	ATM		Add TweakPhoneNumber.  Minor fixes.
		 <1>	  9/6/94	ATM		first checked in

	To Do:
*/


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>

#include "Matching.h"
#include "Common_Log.h"

//
// Turn on matching by area code.  If longdistance calling not enabled, box will dial only
// within its area code.  You can add gamephonenumbers of boxes that you want to be able to
// do long distance calling by editing the "LongDistance.phonenumbers" file in /var/catapult
// This file is read by SunSega in Server_ValidateLogin().  This will be obsoleted by the
// database admin tool once we are up on Oracle.  9/16/94  -dj
//
#define MATCH_BY_AREA_CODE_ONLY	1


// ===========================================================================
//		Prototypes for local routines
// ===========================================================================

int Matching_InitializeContestant(Contestant *contestant);
Err Matching_SanityCheckContestant(Contestant *contestant);

Err Matching_Control_DequeueContestant(MatchControl_DequeueContestant *dequeue);
MatchControlResult_Contestant *Matching_Control_GetContestant(
	MatchControl_GetContestant *getc);
MatchControlResult_QueueContents *Matching_Control_GetQueues(
	MatchControl_GetQueues *getQueues);
unsigned char *Matching_CopyContestants(unsigned char *buf, ListHead *queue);
Contestant *Matching_FindContestantByID(ContestantID contestantID);

void Matching_DumpQueues(void);


// ===========================================================================
//		State for this region
// ===========================================================================

static int initialized = 0;				// sanity check

RegionGlobals gRegionGlobals;			// all about us

static GameInfo *gGameInfo = NULL;		// local copy of GameInfo
static long gNumGames;					// (not really global, just here)



// ===========================================================================
//		Startup and Shutdown
// ===========================================================================

//
// Initialize our little world.
//
// Returns TRUE on success, FALSE on failure.
//
Err Matching_MatchingStartup(long gameID)
{
	MatchingGameData *mgd;
	GameInfo *gip;
	ListNode *lnode;
	int i;

	if (initialized) {
		PLogmsg(LOGP_FLAW, "HEY: tried to initialize region %ld twice!\n",
			gRegionGlobals.regionID);
		return (false);
	}

	// Start by zeroing everything to nuke the statistics.
	//
	memset(&gRegionGlobals, 0, sizeof(RegionGlobals));

	// We get this once, and use it forever.
	//
	if ((gGameInfo = Common_GetGameInfo(&gNumGames)) == NULL) {
		PLogmsg(LOGP_FLAW, "Init: unable to get game info\n");
		return (false);
	}
	if (gNumGames < 0 || gNumGames > 512) {
		PLogmsg(LOGP_FLAW, "ERROR: Init: bogus numGames %ld\n",
			gNumGames);
		return (false);
	}

	// Init the useful fields inside RegionGlobals
	//
	gRegionGlobals.regionID = 0;			// for now, only one region
	gRegionGlobals.boxArch = 'sega';		// we like SEGA, yes we do
	gRegionGlobals.nextContestantID = 1;	// 0 looks like a bug...

	gRegionGlobals.globalQueue = NewSortedList();
	gRegionGlobals.specificQueue = NewSortedList();
	gRegionGlobals.purgatoryQueue = NewSortedList();

	// Create an MGD entry for every GameInfo record we have, even if the
	// entry is just an alias.  This makes it easier to search.  I'm
	// optimizing for the non-alias case, and assuming that there won't
	// be all that many aliases.
	//
	// (This is now obsolete, but I'm not going to fix it since Ted is
	// about to replace it all.)
	//
	gRegionGlobals.gameData = NewSortedList();

	for (i = 0; i < gNumGames; i++) {
		mgd = (MatchingGameData *)malloc(sizeof(MatchingGameData));
		if (mgd == NULL) {
			PLogmsg(LOGP_FLAW, "ERROR: Init: malloc failed\n");
			return (false);
		}

		// init fields (notably statistics) to zero
		memset(mgd, 0, sizeof(MatchingGameData));

		mgd->gameID = gGameInfo[i].gameID;
		mgd->gameInfo = &gGameInfo[i];
		mgd->gameQueue = NewSortedList();		// this is the game queue

		lnode = NewSortedListNode((Ptr) mgd, gGameInfo[i].gameID);
		ASSERT(lnode);
		AddListNodeToSortedList(gRegionGlobals.gameData, lnode);
	}

	gRegionGlobals.startTime = time(0);
	gRegionGlobals.gameID = gameID;

	// Load the phone information database.
	//
	PhoneDB_Load();	// Load the Compuserve POPs

	// done!
	//
	PLogmsg(LOGP_PROGRESS, "Matching_MatchingStartup successful\n");
	initialized = true;
	return (true);
}

//
// Shut it down.
//
// Useful mainly as a way to dump the statistics before bailing.
//
// Returns (true) on success, (false) on failure.
//
Err Matching_MatchingShutdown(void)
{
	ListNode *lnode;
	char arch[5];
	time_t now;

	if (!initialized) {		// didn't start up, don't shut down
		PLogmsg(LOGP_FLAW, "GLITCH: Shutdown without Startup\n");
		return (true);
	}

	now = time(0);

	// This is just to make the stats pretty, in case nobody has logged
	// in for a while and we've got a bunch of guys sitting around
	// waiting to be expired.
	//
	Matching_ExpireContestants(now);

	// Dump the statistics
	//
	*(long *)arch = gRegionGlobals.boxArch;
	arch[4] = '\0';
	Logmsg("\n");
	Logmsg("----- MATCHING STATS for arch '%.4s' region %d\n",
		arch, gRegionGlobals.regionID);

	// These ought to be LOGP_DBUG, but we don't currently have any way
	// of saving these in a database (and I haven't even implemented the
	// retrieval call yet).  Besides, they're colorful.
	//
	// Little-known facts about the statistics:
	//	(where "successes" is numSpecificSuc + numAutoSuc + numAutoSpecSuc)
	//	- numSpecificReq + numAutoReq == numRequests
	//	- (successes) + numFailedReq + numTimeouts + numRequeued == numRequests
	//	- numEnqueued + (successes/2) + numFailedReq == numRequests
	//	- numTimeouts + (successes/2) + numRequeued == numEnqueued
	//
	// (May have hosed these with kLeaveOnQueue...)
	//
	Logmsg("  startTime 0x%.8lx, elapsed time %ld minutes %ld seconds\n",
		gRegionGlobals.startTime,
		(now - gRegionGlobals.startTime) / 60,
		(now - gRegionGlobals.startTime) % 60);
	Logmsg("  numConnections      %ld\n", gRegionGlobals.numConnections);
	Logmsg("  numRequests         %ld\n", gRegionGlobals.numRequests);
	Logmsg("  numFailedReq        %ld\n", gRegionGlobals.numFailedReq);
	Logmsg("  numLongDistance     %ld\n", gRegionGlobals.numLongDistance);
	Logmsg("\n");
	Logmsg("  numSpecificReq      %ld\n", gRegionGlobals.numSpecificReq);
	Logmsg("  numSpecificSuc      %ld\n", gRegionGlobals.numSpecificSuc);
	Logmsg("  numAutoReq          %ld\n", gRegionGlobals.numAutoReq);
	Logmsg("  numAutoSuc          %ld\n", gRegionGlobals.numAutoSuc);
	Logmsg("  numAutoSpecificSuc  %ld\n", gRegionGlobals.numAutoSpecificSuc);
	Logmsg("\n");
	Logmsg("  numEnqueued         %ld\n", gRegionGlobals.numEnqueued);
	Logmsg("  numTimeouts         %ld\n", gRegionGlobals.numTimeouts);
	Logmsg("  numRequeued         %ld\n", gRegionGlobals.numRequeued);
	Logmsg("  numReborn           %ld\n", gRegionGlobals.numReborn);
	Logmsg("  timeEnqueued        %ld\n", gRegionGlobals.timeEnqueued);
	Logmsg("\n");

	// Free up data structures.
	//
	Common_FreeGameInfo(gGameInfo);
	gGameInfo = NULL;
	DisposeList(gRegionGlobals.globalQueue);
	gRegionGlobals.globalQueue = NULL;

	// To make Purify happy, free up the mgd structures pointed to by
	// the gameData list before we free the list itself.  While we're
	// at it, print stats for the games.
	//
	for (lnode = GetFirstListNode(gRegionGlobals.gameData); lnode;
		lnode = GetNextListNode(lnode))
	{
		MatchingGameData *mgd = (MatchingGameData *)GetListNodeData(lnode);

		if (mgd != NULL && mgd->gameID == gRegionGlobals.gameID && !mgd->gameInfo->alias) {
			Logmsg("  0x%.8lx (%s):\n", mgd->gameID, mgd->gameInfo->gameName);
			Logmsg("    numRequests       %ld\n", mgd->numRequests);
			Logmsg("    numSuccesses      %ld\n", mgd->numSuccesses);
		}
		if (mgd != NULL)
			free(mgd);
	}
	DisposeList(gRegionGlobals.gameData);
	gRegionGlobals.gameData = NULL;

	initialized = 0;

	Logmsg("Matching_MatchingShutdown successful\n");
	return (true);
}


// ===========================================================================
//		Main entry points from RPC calls
// ===========================================================================

//
// Entry point for all matching requests.
//
Matchup *Matching_FindMatch(Contestant *contestant)
{
	GameInfo *thisGameInfo;
	static Matchup matchup;
	Err err;
	static time_t lastExpire = 0;
	time_t now;

	if (!initialized) {
		PLogmsg(LOGP_FLAW, "Matching was not initialized, aborting.\n");
		Matching_Abort();
		return (NULL);
	}

	gRegionGlobals.numConnections++;		// incr for every RPC function

	//
	// Look for deadwood every so often.
	//
	now = time(0);
	if (now - lastExpire > kMatchScanInterval) {
		Matching_ExpireContestants(now);
		lastExpire = now;
	}

	//
	// Init the matchup struct.
	//
	memset(&matchup, 0, sizeof(Matchup));

	//
	// Sanity-check the contestant args.
	//
	if ((err = Matching_SanityCheckContestant(contestant)) != kNoError) {
		matchup.result = err;
		goto bail;
	}

	gRegionGlobals.numRequests++;		// incr for all requests

	//
	// Initialize the rest of the fields.
	//
	Matching_InitializeContestant(contestant);

	Logmsg("--- ENTRY: => %ld <= '%s' (%s)\n",
		contestant->contestantID, contestant->userName,
		contestant->boxPhoneNumber.phoneNumber);

	// DEBUG: dump the queues before we go to work
	PLogmsg(LOGP_DBUG, "New contestant:\n");
	Matching_DumpContestant(contestant, MDC_VERBOSE);
	Matching_DumpQueues();

	//
	// If he's on a queue already, deal with it appropriately.
	//
	if (Matching_DequeueIfQueued(contestant, &matchup)) {
		// He was already on an auto-match queue for this game, and signed
		// up for another.  Throw the mangy bastard out on his ear.
		//
		goto bail;
	}

	//
	// Depending on challengeFlags, do an auto or specific match.
	//
	switch (contestant->challengeFlags) {
	case kIgnoreChallenges:
	case kAcceptChallenges:
		// auto-match
		Matching_AutoMatch(contestant, &matchup);
		break;
	case kSpecificChallenge:
		// specific match
		Matching_Specific(contestant, &matchup);
		break;
	default:
		PLogmsg(LOGP_FLAW,
			"How the HELL did we get here?  Stupid sanity checker.\n");
		Matching_Abort();
		matchup.result = kFucked;
		break;
	}

bail:
	// DEBUG: dump the queues before we bail
	Matching_DumpQueues();

	// A failed request is anything that doesn't end up as "wait" or "dial".
	// (This may change.)
	//
	if (matchup.result != kMatchDial && matchup.result != kMatchWait)
		gRegionGlobals.numFailedReq++;

	//
	// Return the Matchup struct to the caller.
	//
	Logmsg("--- RETURN:");
	switch (matchup.result) {
	case kMatchDial:
		Logmsg(" kMatchDial");
		break;
	case kMatchWait:
		Logmsg(" kMatchWait");
		break;
	case kLeaveOnQueue:
		Logmsg(" kLeaveOnQueue");
		break;
	case kOpponentIsDialing:
		Logmsg(" REJECT (kOpponentIsDialing)");
		break;
	case kOpponentIsDialingForWrongGame:
		Logmsg(" REJECT (kOpponentIsDialingForWrongGame)");
		break;
	case kNoSuchGameID:
		Logmsg(" REJECT (kNoSuchGameID)");
		break;
	case kChallengeeWaitingForDifferentGame:
		Logmsg(" REJECT (kChallengeeWaitingForDifferentGame)");
		break;
	case kChallengeeWaitingForDifferentUser:
		Logmsg(" REJECT (kChallengeeWaitingForDifferentUser)");
		break;
	case kChallengeeNotAvailable:
		Logmsg(" REJECT (kChallengeeNotAvailable)");
		break;
	case kChallengeeWaitingForAutoMatch:
		Logmsg(" REJECT (kChallengeeWaitingForAutoMatch)");
		break;
	case kChallengeeTooFar:
		Logmsg(" REJECT (kChallengeeTooFar)");
		break;
	case kDifferentRomVersion:
		Logmsg(" REJECT (kDifferentRomVersion)");
		break;
	case kOpponentNotRegistered:
		Logmsg(" REJECT (kOpponentNotRegistered)");
		break;
	case kInvalidArguments:
		Logmsg(" REJECT (kInvalidArguments)");
		break;
	case kInvalidPhoneNumber:
		Logmsg(" REJECT (kInvalidPhoneNumber)");
		break;
	default:
		Logmsg(" %ld", matchup.result);
		break;
	}
	Logmsg("\n");

	return (&matchup);
}


//
// Do all sorts of fascinating things.
//
// The result sometimes has to be allocated dynamically, and can't be
// freed until the next time we get control back from the RPC stuff.  So
// we either return a pointer to a static struct, or a pointer to dynamic
// mem that gets freed next time through.
//
// Returns NULL on error.
//
MatchControlResult *Matching_MatchingControl(MatchControl *matchControl)
{
	static MatchControlResult *result = NULL;
	static MatchControlResult_Status resultStatus = {
		kMatchCtlRes_Status, 0, 0 };
	time_t now;

	if (!initialized) {
		PLogmsg(LOGP_FLAW, "Matching was not initialized, aborting.\n");
		Matching_Abort();
		return (NULL);
	}

	gRegionGlobals.numConnections++;		// incr for every RPC function

	// Free the one we allocated last time.
	//
	if (result != NULL) {
		free(result);
		result = NULL;
	}

	Logmsg("CONTROL: rcvd request %ld\n", matchControl->type);

	// Handle this request.
	//
	switch (matchControl->type) {
	case kMatchCtl_Ping:
		resultStatus.result = kNoError;
		return ((MatchControlResult *) &resultStatus);
	case kMatchCtl_Shutdown:
		if (matchControl->shutdown.validate == kMatchShutdownValidate) {
			Matching_MatchingShutdown();
			PLogmsg(LOGP_NOTICE, "EXITING\n");
			exit(0);
		} else {
			PLogmsg(LOGP_NOTICE, "WARNING: Bogus shutdown request (0x%.8lx)\n",
				matchControl->shutdown.validate);
			resultStatus.result = kFucked;
			return ((MatchControlResult *) &resultStatus);
		}
	case kMatchCtl_Reload:
		Reconfigure();
		PhoneDB_Reload();
		resultStatus.result = kNoError;
		return ((MatchControlResult *) &resultStatus);
	case kMatchCtl_DoExpire:
		if ((now = matchControl->doExpire.when) == 0)
			now = time(0);
		Matching_ExpireContestants(now);
		resultStatus.result = kNoError;
		return ((MatchControlResult *) &resultStatus);
	case kMatchCtl_DequeueContestant:
		resultStatus.result = Matching_Control_DequeueContestant(
			(MatchControl_DequeueContestant *) matchControl);
		return ((MatchControlResult *) &resultStatus);
	case kMatchCtl_GetQueues:
		result = (MatchControlResult *)
			Matching_Control_GetQueues((MatchControl_GetQueues *) matchControl);
		return (result);
	case kMatchCtl_GetContestant:
		return ( (MatchControlResult *) Matching_Control_GetContestant(
			(MatchControl_GetContestant *) matchControl) );

	case kMatchCtl_GrabContestant:
	case kMatchCtl_SetContestant:
	case kMatchCtl_CreateContestant:
		PLogmsg(LOGP_NOTICE, "WARNING: unimplemented control function\n");
		resultStatus.result = kFucked;
		return ((MatchControlResult *) &resultStatus);

	default:
		PLogmsg(LOGP_FLAW, "ERROR: unrecognized control request\n");
		return (NULL);
	}

	/*NOTREACHED*/
}

//
// Control: Dequeue a contestant by contestantID.
//
Err Matching_Control_DequeueContestant(MatchControl_DequeueContestant *dequeue)
{
	ContestantID contestantID = dequeue->contestantID;
	MatchingGameData *mgd;
	Contestant *contestant;

	Logmsg("DEQUEUE: DequeueContestant(%d)\n", contestantID);

	// See if he exists.
	//
	contestant = Matching_FindContestantByID(contestantID);
	if (contestant == NULL) {
		Logmsg("Contestant %d not found\n", contestantID);
		return (kOpponentNotRegistered);	// oh, close enough
	}
	if (contestant->flags == kMatchPurgatory) {
		Logmsg("Contestant %d already in purgatory\n", contestantID);
		return (kOpponentNotRegistered);	// still kinda close
	}

	// Treat it like a match, and put him on the purgatory queue.  That
	// way if we change our mind we can get him back.
	//
	if ((mgd = Matching_FindGameData(contestant->gameID)) == NULL) {
		PLogmsg(LOGP_FLAW, "Can't get mgd for guy on queue in DeqCon\n");
		return (kFucked);
	}
	if (!Matching_DequeueForMatch(contestant, mgd)) {
		PLogmsg(LOGP_FLAW, "Failed to dequeue in DeqCon\n");
		return (kFucked);
	}

	return (kNoError);
}

//
// Control: Get a copy of a contestant, given the contestantID.
//
MatchControlResult_Contestant *Matching_Control_GetContestant(
	MatchControl_GetContestant *getc)
{
	static MatchControlResult_Contestant mcrc;
	ContestantID contestantID = getc->contestantID;
	Contestant *contestant;

	memset(&mcrc, 0, sizeof(MatchControlResult_Contestant));
	mcrc.type = kMatchCtlRes_Contestant;
	mcrc.size = sizeof(MatchControlResult_Contestant);

	// See if he exists.
	//
	contestant = Matching_FindContestantByID(contestantID);
	if (contestant == NULL) {
		Logmsg("Contestant %d not found\n", contestantID);
		mcrc.result = kOpponentNotRegistered;
		return (&mcrc);
	}

	// Great, return it.
	//
	mcrc.result = kNoError;
	memcpy(&mcrc.contestant, contestant, sizeof(Contestant));
	return (&mcrc);
}

//
// Control: Return the contents of one or more queues.
//
// Result needs to be freed by the caller.
//
MatchControlResult_QueueContents *Matching_Control_GetQueues(
	MatchControl_GetQueues *getQueues)
{
	MatchControlResult_QueueContents *result = NULL;
	MatchControlResult *mcr;
	MatchingGameData *mgd;
	Contestant *conp;
	ListHead *queue;
	unsigned char *ucp;
	int numItems, size;

	if (getQueues->getGeneral) {
		// Return the full contents of the global and purgatory queues.
		//
		numItems = NumListNodesInList(gRegionGlobals.globalQueue) +
				   NumListNodesInList(gRegionGlobals.purgatoryQueue);

		size = sizeof(MatchControlResult_QueueContents) +
			numItems * sizeof(Contestant);
		result = (MatchControlResult_QueueContents *)malloc(size);
		if (result == NULL) {
			PLogmsg(LOGP_FLAW, "malloc failed for M_C_GQ result\n");
			Matching_Abort();
			return (NULL);
		}
		result->type = kMatchCtlRes_QueueContents;
		result->size = size;
		result->count = numItems;
		if (numItems) {
			ucp = (unsigned char *)&(result->data);
			ucp = Matching_CopyContestants(ucp, gRegionGlobals.globalQueue);
			ucp = Matching_CopyContestants(ucp, gRegionGlobals.purgatoryQueue);

			// ucp will be slightly off because the final "data" element
			// occupies 1, 2, or 4 bytes depending on structure padding and
			// alignment.  However, in no event should be be larger.
			//
			if (ucp > ((unsigned char *)result) + size) {
				PLogmsg(LOGP_FLAW,
					"Odd: ucp = 0x%.8lx, result + size = 0x%.8lx (size=%d)\n",
					ucp, ((unsigned char *)result)+size, size);
			}
		}
	} else {
		// Return the contents of a single game queue.  A gameID of zero
		// corresponds to the specific queue.  Yeah, that sucks.
		//
		if (!getQueues->gameID) {
			queue = gRegionGlobals.specificQueue;
		} else {
			mgd = Matching_FindGameData(getQueues->gameID);
			if (mgd == NULL) {
				PLogmsg(LOGP_NOTICE, "QueueCon gameID 0x%.8lx not found\n",
					getQueues->gameID);
				return (NULL);
			}
			queue = mgd->gameQueue;
			if (queue == NULL) {
				PLogmsg(LOGP_FLAW, "QueueCon found NULL game queue (0x%.8lx)\n",
					getQueues->gameID);
				Matching_Abort();
				return (NULL);
			}
		}
		numItems = NumListNodesInList(queue);
		size = sizeof(MatchControlResult_QueueContents) +
			numItems * sizeof(Contestant);
		result = (MatchControlResult_QueueContents *)malloc(size);
		if (result == NULL) {
			PLogmsg(LOGP_FLAW, "Malloc failed for M_C_GQ result\n");
			Matching_Abort();
			return (NULL);
		}
		result->type = kMatchCtlRes_QueueContents;
		result->size = size;
		result->count = numItems;
		if (numItems) {
			ucp = (unsigned char *)&(result->data);
			ucp = Matching_CopyContestants(ucp, queue);

			// Sanity check.
			//
			if (ucp > ((unsigned char *)result) + size) {
				PLogmsg(LOGP_FLAW,
					"ODD: ucp = 0x%.8lx, result + size = 0x%.8lx (size=%d)\n",
					ucp, ((unsigned char *)result)+size, size);
			}
		}
	}

	result->result = kNoError;
	mcr = (MatchControlResult *)result;
	if (mcr->generic.size != result->size) {
		PLogmsg(LOGP_FLAW, "structures are sucking\n");
		Matching_Abort();
		return (NULL);
	}
	return (result);
}

//
// Copy the contents of a player queue into a contiguous array.
//
// Returns the "buf" pointer, advanced past the end of the current output.
//
unsigned char *
Matching_CopyContestants(unsigned char *buf, ListHead *queue)
{
	ListNode *lnode;
	Contestant *contestant;

	for (lnode = GetFirstListNode(queue); lnode != NULL; \
		lnode = GetNextListNode(lnode))
	{
		contestant = (Contestant *)GetListNodeData(lnode);
		if (contestant == NULL) {
			PLogmsg(LOGP_FLAW, "Empty contestant on queue in CopyCon\n");
			Matching_Abort();
			continue;
		}
		memcpy(buf, contestant, sizeof(Contestant));
		buf += sizeof(Contestant);
	}

	return (buf);
}



// ===========================================================================
//		Minor utility routines
// ===========================================================================

//
// Make sure all of the arguments are valid.
//
// Returns a value suitable for Matchup.result.
//
Err Matching_SanityCheckContestant(Contestant *contestant)
{
	GameInfo *gameInfo;
	int i;

	// see if the game exists
	//
	for (i = 0, gameInfo = gGameInfo; i < gNumGames; i++, gameInfo++) {
		if (gameInfo->gameID == contestant->gameID)
			break;
	}
	if (i == gNumGames) {
		PLogmsg(LOGP_NOTICE, "REJECT: gameID 0x%.8lx not recognized\n",
			contestant->gameID);
		//Matching_Abort();
		return (kNoSuchGameID);
	}

	// how to check boxSerialNumber?

	// check the player #
	//
	if (contestant->player < 0 || contestant->player > 3) {
		PLogmsg(LOGP_NOTICE, "REJECT: invalid player # %d\n",
			contestant->player);
		return (kInvalidArguments);
	}

	// check userName
	//
	if (*contestant->userName == '\0') {
		PLogmsg(LOGP_NOTICE, "REJECT: blank userName for '%s'\n",
			contestant->boxPhoneNumber.phoneNumber);
		return (kInvalidArguments);
	}

	// Normalize his phone number, and verify that it's sane.
	//
	{
		SuperPhone	phone;

		// Start by stripping the number down to bare digits.
		//
		if (Common_PhoneParseDefault(contestant->boxPhoneNumber.phoneNumber, &phone) != kNoError)
		{
			Matching_Abort();
			PLogmsg(LOGP_NOTICE, "REJECT: invalid phone # '%s'\n",
				contestant->boxPhoneNumber.phoneNumber);
			return (kInvalidPhoneNumber);
		}

		// See if it's remotely valid.  Since we have ANI, a number less
		// than 10 characters should never happen, and we don't need the
		// "add 408 to it" kluge here.
		//
		if (!phone.npa_length)
		{
			PLogmsg(LOGP_NOTICE, "REJECT: short phone # '%s'\n",
				contestant->boxPhoneNumber.phoneNumber);
			return (kInvalidPhoneNumber);
		}

		Common_PhoneFormatDisplay(contestant->boxPhoneNumber.phoneNumber,
			contestant->boxPhoneNumber.phoneNumber);
	}


	// check challengeFlags
	//
	if (contestant->challengeFlags != kMatchInvalid &&
		contestant->challengeFlags != kAcceptChallenges &&
		contestant->challengeFlags != kSpecificChallenge)
	{
		PLogmsg(LOGP_NOTICE, "REJECT: invalid challengeFlags %d\n",
			contestant->challengeFlags);
		return (kInvalidArguments);
	}

	// callLongDistance is boolean

	// check gamePatchVersion
	//
	if (contestant->gamePatchVersion > 1024) {
		PLogmsg(LOGP_NOTICE, "WARNING: huge gp version (%ld)\n",
			contestant->gamePatchVersion);
		// just continue
	}

	// how to check oppBoxSerialNumber?  (either prev opponent or desired opp)

	// Check the oppPlayer #.  Can be -1 if this is an auto-match and we
	// didn't have a previous opponent.  Might be allowable for a specific
	// if we want to be flexible.
	//
	if (contestant->oppPlayer < 0 || contestant->player > 3) {
		if (contestant->oppPlayer != -1 ||
			contestant->challengeFlags == kSpecificChallenge)
		{
			PLogmsg(LOGP_NOTICE,
				"REJECT: invalid oppPlayer # %d\n", contestant->oppPlayer);
			return (kInvalidArguments);
		}
	}

	// can't really check the rankingInfo

	return (kNoError);
}

//
// Init the rest of the fields, mainly to 0 or NULL.
//
// This is where the contestantID gets set.
//
int Matching_InitializeContestant(Contestant *contestant)
{
	time_t now = time(0);
	int i;

	// assign a serial number; this gets used as the "magic cookie"
	//
	contestant->contestantID = gRegionGlobals.nextContestantID++;

	// zero the "when" field of prevOpps older than kMinTimeBeforeRematch
	//
	for (i = 0; i < kMaxPreviousOpponent; i++) {
		if (now - contestant->prevOpponent[i].when > kMinTimeBeforeRematch)
			contestant->prevOpponent[i].when = 0;
	}

	// zero the rest of the fields that weren't passed in
	//
	contestant->aliasedGameID = 0;
	contestant->queuedWhen = 0;
	contestant->globalListNode = NULL;
	contestant->gameListNode = NULL;
	contestant->flags = kMatchValid;

	contestant->purgatoryWhen = 0;
	contestant->opponentID = 0;

	return (true);
}

//
// Given a ContestantID, find the Contestant.  Searches both the global
// and purgatory queues.
//
Contestant *Matching_FindContestantByID(ContestantID contestantID)
{
	ListNode *lnode;
	Contestant *qcon;

	// Search the global queue.
	//
	for (lnode = GetFirstListNode(gRegionGlobals.globalQueue); \
		lnode != NULL; lnode = GetNextListNode(lnode))
	{
		qcon = (Contestant *)GetListNodeData(lnode);
		if (qcon->contestantID == contestantID)
			return (qcon);
	}

	// Search the purgatory queue.
	//
	for (lnode = GetFirstListNode(gRegionGlobals.purgatoryQueue); \
		lnode != NULL; lnode = GetNextListNode(lnode))
	{
		qcon = (Contestant *)GetListNodeData(lnode);
		if (qcon->contestantID == contestantID)
			return (qcon);
	}

	return (NULL);
}

//
// Find the MatchingGameData struct for a given GameID.
//
// Returns NULL if the struct couldn't be found.
//
MatchingGameData *Matching_FindGameData(long gameID)
{
	MatchingGameData *mgd;
	ListNode *lnode;
	int sane = 0;

	if (gRegionGlobals.gameData == NULL) {
		PLogmsg(LOGP_FLAW, "Called FindGameData w/o initializing gameData!\n");
		return (NULL);
	}

	// Run through the mgd list until we find it.  If it's an alias for
	// another game, rewind and try again.
	//
	while (1) {
		if (sane++ > 16) {
			// friends don't let friends loop forever
			PLogmsg(LOGP_FLAW, "ERROR: somebody hosed, aborting\n");
			Matching_Abort();
			return (NULL);
		}

		if ((lnode = SearchList(gRegionGlobals.gameData, gameID)) == NULL) {
			PLogmsg(LOGP_FLAW, "ERROR: unable to find game 0x%.8lx [%d]\n",
				gameID, sane);
			return (NULL);
		}
		mgd = (MatchingGameData *)GetListNodeData(lnode);

		if (mgd->gameInfo == NULL) {
			PLogmsg(LOGP_FLAW, "ERROR: mgd w/o gameInfo?\n");
			Matching_Abort();
			return (NULL);
		}
		if (mgd->gameInfo->alias != 0) {
			gameID = mgd->gameInfo->alias;
			continue;
		}

		// eureka!
		break;
	}

	return (mgd);
}

//
// Compare two BoxSerialNumbers.
//
// (Might want to make this a macro or inline.)
//
int Matching_CompareBoxSerial(BoxSerialNumber *box1, BoxSerialNumber *box2)
{
	if ((box1->box == box2->box) && (box1->region == box2->region))
		return (true);
	else
		return (false);
}


// ===========================================================================
//		Phone stuff
// ===========================================================================

//
// Determine whether the caller is close enough to the callee.  Uses
// the caller's callLongDistance flag and the LATA database.
//
// Doing a full LATA lookup against every queued player will
// probably suck.  We need a fast way to strcmp against the
// area code.  Problem is, they may be able to play against
// adjacent area codes, so we need to determine adjacent areas
// once and then deal with it.
//
// OTOH, two prefixes in the same area code might not be close enough...
//
int Matching_DistanceOkay(Contestant *contestant, Contestant *opponent)
{
	if (contestant->callLongDistance)
		return (true);
		
#ifdef MATCH_BY_AREA_CODE_ONLY
	// match EXCLUSIVELY by area code
	if (strncmp(contestant->boxPhoneNumber.phoneNumber,
				opponent->boxPhoneNumber.phoneNumber, 4) == 0)
		return (true);
	else
		return (false);
#else

	// No LD, see if they're close enough.
	//
	// BRAIN DAMAGE: can't use DB routines that won't exist in this process!
	//
	return (PhoneDB_IsLocal(&contestant->boxPhoneNumber,
		&opponent->boxPhoneNumber));
#endif
}

#if	0
	HUFFT	need to use current Common routines
//
// Given the box's phone number and the opponent's phone number, tweak
// the opponent number so that it has an area code on it iff he's in a
// different area code than we are.
//
// Assumes the phone numbers have been normalized.
//
int Common_PhoneTweakOpponentNumber(phoneNumber *oppPhone, const phoneNumber *myPhone)
{
	phoneNumber tmpPhone;

	// If the first 4 chars match (1xxx, where xxx is the area code), then
	// remove the first four from the oppPhone number.
	//
	if (strncmp(myPhone->phoneNumber, oppPhone->phoneNumber, 4) == 0) {
		// Area codes match, so strip it off.
		//
		tmpPhone = *oppPhone;
		strcpy(oppPhone->phoneNumber, tmpPhone.phoneNumber+4);

		if (strlen(oppPhone->phoneNumber) != 7) {
			PLogmsg(LOGP_FLAW, "GLITCH: nuked the opp phone number!  '%s'\n",
				oppPhone->phoneNumber);
			Matching_Abort();
			return (false);
		}
	}

	return (true);
}
#endif


// ===========================================================================
//		Queue routines
// ===========================================================================

//
// Add the contestant to the global and game/specific queues.  All fields
// of the contestant structure should be filled out.
//
// Contestant is either a new caller or is coming back from purgatory.
//
// This makes a copy of the contestant, since the original may have come
// up from RPC, in which case it'd be a static struct.  The flags field
// in the original will be set to kMatchCopied to indicate that the
// structure has been duplicated and changes to it will be lost.
//
// Returns TRUE if all succeeded, FALSE on failure.
//
int Matching_AddToQueues(Contestant *contestant, MatchingGameData *mgd)
{
	Contestant *newc;
	ListNode *lnode;

	if (mgd->gameQueue == NULL) {
		PLogmsg(LOGP_FLAW, "ERROR: uninitialized game queue for 0x%.8lx\n",
			contestant->gameID);
		Matching_Abort();
		return (false);
	}

	if (contestant->flags != kMatchValid) {
		PLogmsg(LOGP_NOTICE, "WARNING: AddToQueues when not kMatchValid\n");
		// oh, go ahead
	}

	// Make a copy of it for the queues, and invalidate the old.
	//
	newc = (Contestant *)malloc(sizeof(Contestant));
	if (newc == NULL) {
		PLogmsg(LOGP_FLAW, "ERROR: malloc failed in AddToQueues\n");
		return (false);
	}
	memcpy(newc, contestant, sizeof(Contestant));

	contestant->flags = kMatchCopied;	// maybe hose the ID to make it obvious?

	// Add it.  Note we need to create two different list nodes, but they
	// can share the same contestant struct.
	//
	lnode = NewSortedListNode((Ptr) newc, newc->contestantID);
	ASSERT(lnode);
	AddListNodeToSortedList(gRegionGlobals.globalQueue, lnode);
	newc->globalListNode = lnode;

	lnode = NewSortedListNode((Ptr) newc, newc->contestantID);
	ASSERT(lnode);
	if (newc->challengeFlags == kSpecificChallenge)
		AddListNodeToSortedList(gRegionGlobals.specificQueue, lnode);
	else
		AddListNodeToSortedList(mgd->gameQueue, lnode);
	newc->gameListNode = lnode;

	return (true);
}

//
// If this guy (or anybody else from his box) is already on a queue
// somewhere, we deal with it as follows:
//
//	- if he was originally signed up for an auto-match, and wants auto-match
//	  - same player, same game: don't remove from queue, send NASTY message
//	  - different player: requeue, send nasty message
//	  - different game: requeue, send nasty message
//
//	- if he was originally signed up for an auto-match, and wants specific-match
//	  - requeue, send nasty message
//
//	- if he was originally signed up for a specific-match (be nicer?)
//	  - shunt to auto-match queue, send warning message
//
// In all cases we should charge a credit, unless KON wants the specific
// match timeout to be an hour, in which case rematching after a specific
// match should be free (and they'll get free x-mail, etc).
//
// Whether or not we reset their timer is a question of taste.  Probably
// ought to... they just paid a credit for it, and they'll get annoyed if
// they time out 30 seconds later but their box is waiting 5 or 10 minutes.
//
// If he's on the purgatory queue, we check for a different reason.  If
// he was put into purgatory within a fairly short period of time, then
// somebody is probably trying to call him right now.  If they've changed
// games, all we can do is yell.  In NO case should they be put back on a
// queue, since they're either being called or powered down in there
// somewhere.  Whether or not they get charged a credit is TBD.
//
// Returns TRUE if the matcher should bail immediately, FALSE if not.
// Sets Matchup->warning.
//
int Matching_DequeueIfQueued(Contestant *contestant, Matchup *matchup)
{
	ListNode *lnode;
	Contestant *qcon, *found;
	int dequeue;
	time_t now;

	// Scan the global queue.  If he's there, he must've re-registered
	// before getting matched.
	//
	found = NULL;
	for (lnode = GetFirstListNode(gRegionGlobals.globalQueue); \
		lnode != NULL; lnode = GetNextListNode(lnode))
	{
		qcon = (Contestant *)GetListNodeData(lnode);
		if (Matching_CompareBoxSerial(&contestant->boxSerialNumber,
			&qcon->boxSerialNumber))
		{
			// Sanity check.
			//
			if (qcon->globalListNode != lnode) {
				PLogmsg(LOGP_NOTICE,
					"WARNING: funky ListNode mismatch in DequeueIfQueued\n");
				Matching_DumpQueues();
			}
			found = qcon;
			break;
		}
	}

	// Found him.  Handle it in an appropriate manner.
	//
	if (found != NULL) {
		dequeue = 0;

		if (found->challengeFlags == kSpecificChallenge) {
			// Original requests was specific-match.
			//
			if (contestant->challengeFlags == kSpecificChallenge) {
				// He wants a different challenge.  Fine.
				matchup->warning = kMWarnSpecificToSpecific;
				dequeue = 1;
			} else {
				// Changed his mind, wants an auto-match.  Fine.
				matchup->warning = kMWarnSpecificToAuto;
				dequeue = 1;
			}
		} else {
			// Original request was auto-match.
			//
			if (contestant->gameID != found->gameID) {
				// Hoser powered off and changed games.
				matchup->warning = kMWarnAutoChangedGame;
				dequeue = 1;
			} else if (contestant->player != found->player) {
				// He hit reset and switched players
				matchup->warning = kMWarnAutoChangedPlayer;
				dequeue = 1;
			} else if (contestant->challengeFlags == kSpecificChallenge) {
				// He was on auto, now he wants specific challenge.
				matchup->warning = kMWarnAutoToSpecific;
				dequeue = 1;
			} else {
				// auto to auto, same game, same player
				matchup->warning = kMWarnAutoToAuto;
				dequeue = 0;
			}
		}

		now = time(0);

		if (dequeue) {
			// Remove old from queue, do standard processing to add new one.
			//
			Logmsg("REQUEUE: new ID %ld replaces old ID %ld [warning %ld]\n",
				contestant->contestantID, found->contestantID,
				matchup->warning);

			// update stats
			//
			gRegionGlobals.numRequeued++;
			gRegionGlobals.timeEnqueued += now - found->queuedWhen;

			RemoveListNodeFromList(found->globalListNode);
			DisposeListNode(found->globalListNode);
			RemoveListNodeFromList(found->gameListNode);
			DisposeListNode(found->gameListNode);
			free(found);

			return (false);
		} else {
			// He's staying on the queue, so fill out his matchup struct
			// with values from the stuff on the queue.  Reset his queue
			// timer so it matches what the box will think.
			//
			// (This is probably going to screw up our timeEnqueued stat...)
			//
			Logmsg("RETAIN: contestant %ld not requeued [warning %ld]\n",
				contestant->contestantID, matchup->warning);
			matchup->result = kLeaveOnQueue;
			matchup->magicCookie = found->contestantID;		// keep old cookie
			gRegionGlobals.timeEnqueued += now - found->queuedWhen;
			if (found->challengeFlags == kSpecificChallenge)
				matchup->matchOrExpWhen = now + kMaxTimeInSpecificQueue;
			else
				matchup->matchOrExpWhen = now + kMaxTimeInWaitQueue;
			found->queuedWhen = now;
			return (true);
		}
	}

	// Scan the purgatory list.  Being on here means the user either had a
	// short game, or re-registered while his chosen opponent was dialing.
	//
	for (lnode = GetFirstListNode(gRegionGlobals.purgatoryQueue); \
		lnode != NULL; lnode = GetNextListNode(lnode))
	{
		qcon = (Contestant *)GetListNodeData(lnode);
		if (Matching_CompareBoxSerial(&contestant->boxSerialNumber,
			&qcon->boxSerialNumber))
		{
			// Found him out here in purgatory.  Found him too soon?
			//
			if (time(0) - kMinReregisterDelay < qcon->purgatoryWhen) {
				if (contestant->gameID == qcon->gameID) {
					Logmsg("PEERCON: connected %ld seconds after purgatory\n",
						time(0) - qcon->purgatoryWhen);
					matchup->result = kOpponentIsDialing;
					matchup->magicCookie = qcon->contestantID;
				} else {
					Logmsg("PEERCON-: connected %ld seconds after purgatory, different gameID\n",
						time(0) - qcon->purgatoryWhen);
					matchup->result = kOpponentIsDialingForWrongGame;
					matchup->magicCookie = 0;
				}

				return (true);
			} else {
				Logmsg("P-QUEUE: new ID %ld replaces purgatory %ld\n",
					contestant->contestantID, qcon->contestantID);

				RemoveListNodeFromList(lnode);
				DisposeListNode(lnode);
				free(qcon);

				return (false);
			}
		}
	}

	return (false);
}

//
// Look for the guy I want to challenge.  Uses the oppBoxSerialNumber
// and oppPlayer fields to find him.  Look on the global queue, so we'll
// find both the game queues and the specific queue.
//
// Returns NULL if the contestant can't be found.
//
Contestant *Matching_FindMyChallengee(Contestant *contestant)
{
	Contestant *qcon;
	ListNode *lnode;

	for (lnode = GetFirstListNode(gRegionGlobals.globalQueue); \
		lnode != NULL; lnode = GetNextListNode(lnode))
	{
		qcon = (Contestant *)GetListNodeData(lnode);

		if (Matching_CompareBoxSerial(&contestant->oppBoxSerialNumber,
			&qcon->boxSerialNumber))
		{
			if (contestant->oppPlayer == qcon->player)
				return (qcon);

			// somebody else from the same box is logged on... give up now
			return (NULL);
		}
	}

	return (NULL);
}

//
// Look for a guy on the "specific" queue who wants to challenge me.  Returns
// the one who dialed in first.
//
Contestant *Matching_FindMyChallenger(Contestant *contestant)
{
	Contestant *qcon;
	ListNode *lnode;

	for (lnode = GetFirstListNode(gRegionGlobals.specificQueue); \
		lnode != NULL; lnode = GetNextListNode(lnode))
	{
		qcon = (Contestant *)GetListNodeData(lnode);

		if (Matching_CompareBoxSerial(&contestant->boxSerialNumber,
			&qcon->oppBoxSerialNumber))
		{
			if (contestant->player == qcon->oppPlayer)
				return (qcon);

			// He wants somebody else from my box, but maybe someone else
			// is interested in *me*.  Keep looking...
		}
	}

	return (NULL);
}

//
// Used when the contestant's opponent is found.  The opponent goes into
// the "purgatory" list, in case the current contestant chokes and dies
// during the next part of his connection, or the slave calls in right away.
//
// Returns TRUE on success, FALSE on failure.
//
int Matching_DequeueForMatch(Contestant *opponent, MatchingGameData *mgd)
{
	ListNode *lnode;

	if (opponent == NULL || mgd == NULL) {
		PLogmsg(LOGP_FLAW, "NULL args in DequeueForMatch\n");
		Matching_Abort();
		return (false);
	}
	if (opponent->globalListNode == NULL || opponent->gameListNode == NULL) {
		PLogmsg(LOGP_FLAW, "Trying to dequeue for match but queues not set\n");
		Matching_Abort();
		return (false);
	}

	// throw out the game queue node
	//
	RemoveListNodeFromList(opponent->gameListNode);
	DisposeListNode(opponent->gameListNode);
	opponent->gameListNode = NULL;

	// move the global list node to the purgatory list
	//
	RemoveListNodeFromList(opponent->globalListNode);
	AddListNodeToSortedList(gRegionGlobals.purgatoryQueue,
		opponent->globalListNode);
	opponent->purgatoryWhen = time(0);		// reset his queuedWhen
	opponent->flags = kMatchPurgatory;		// show that he's almost gone

	// update stats
	//
	gRegionGlobals.timeEnqueued += time(0) - opponent->queuedWhen;

	return (true);
}

//
// Expire anybody who has been around for more than kMaxTimeInWaitQueue
// seconds (kMaxTimeInSpecificQueue for specific challenges).
//
int Matching_ExpireContestants(time_t now)
{
	ListNode *lnode;
	Contestant *qcon;

	Logmsg("Expiring contestants\n");

	// start with the global queue
	//
restart_global:
	for (lnode = GetFirstListNode(gRegionGlobals.globalQueue); \
		lnode != NULL; lnode = GetNextListNode(lnode))
	{
		qcon = (Contestant *)GetListNodeData(lnode);

		if ((qcon->challengeFlags == kSpecificChallenge &&
				(now - qcon->queuedWhen > kMaxTimeInSpecificQueue)) ||
			(qcon->challengeFlags != kSpecificChallenge &&
				(now - qcon->queuedWhen > kMaxTimeInWaitQueue)) )
		{
			ListNode *prevLnode = GetPrevListNode(lnode);

			// boot them
			//
			Logmsg("EXPIRE: removing %ld: '%s' (%s)\n",
				qcon->contestantID, qcon->userName,
				qcon->boxPhoneNumber.phoneNumber);
			Statusmsg("Matcher: Removed '%s' (%s)\n",
				qcon->userName, qcon->boxPhoneNumber.phoneNumber);

			if (qcon->globalListNode != lnode) {
				PLogmsg(LOGP_FLAW, "GLITCH: Oddity in Expire\n");
				Matching_Abort();
			}
			RemoveListNodeFromList(qcon->gameListNode);
			DisposeListNode(qcon->gameListNode);
			RemoveListNodeFromList(qcon->globalListNode);
			DisposeListNode(qcon->globalListNode);
			free(qcon);

			// update stats
			//
			gRegionGlobals.numTimeouts++;
			gRegionGlobals.timeEnqueued += now - qcon->queuedWhen;

			// back up, so GetNext gets us the removed one's next
			lnode = prevLnode;
			if (lnode == NULL) goto restart_global;
		}
	}

	// do the same for the purgatory list
	//
restart_purgatory:
	for (lnode = GetFirstListNode(gRegionGlobals.purgatoryQueue); \
		lnode != NULL; lnode = GetNextListNode(lnode))
	{
		qcon = (Contestant *)GetListNodeData(lnode);

		if (now - qcon->purgatoryWhen > kMaxTimeInPurgatory) {
			ListNode *prevLnode = GetPrevListNode(lnode);

			// Boot them.  Note that there's no game queue ptr here.
			//
			if (qcon->globalListNode != lnode) {
				PLogmsg(LOGP_FLAW, "GLITCH: Oddity in Expire purgatory\n");
				Matching_Abort();
			}
			RemoveListNodeFromList(qcon->globalListNode);
			DisposeListNode(qcon->globalListNode);
			free(qcon);

			// timing out of purgatory isn't interesting enough for stats

			// back up, so GetNext gets us the removed one's next
			lnode = prevLnode;
			if (lnode == NULL) goto restart_purgatory;
		}
	}

	return (true);
}


// ===========================================================================
//		Debugging stuff
// ===========================================================================

//
// Dump all of the queues.
//
void Matching_DumpQueues(void)
{
	ListNode *lnode, *gameLnode;
	MatchingGameData *mgd;
	Contestant *qcon;

	PLogmsg(LOGP_DBUG, "\n");

	// start with the global queue
	//
	PLogmsg(LOGP_DBUG, "Contents of global queue:\n");
	for (lnode = GetFirstListNode(gRegionGlobals.globalQueue); \
		lnode != NULL; lnode = GetNextListNode(lnode))
	{
//		phoneNumber tmpPhoneNumber;

		qcon = (Contestant *)GetListNodeData(lnode);

		Matching_DumpContestant(qcon, MDC_BRIEF);

	}

	PLogmsg(LOGP_DBUG, "Contents of specific match queue:\n");
	for (lnode = GetFirstListNode(gRegionGlobals.specificQueue); \
		lnode != NULL; lnode = GetNextListNode(lnode))
	{
		qcon = (Contestant *)GetListNodeData(lnode);

		Matching_DumpContestant(qcon, MDC_VERBOSE);
	}

	PLogmsg(LOGP_DBUG, "Contents of game queues:\n");
	for (lnode = GetFirstListNode(gRegionGlobals.gameData); \
		lnode != NULL; lnode = GetNextListNode(lnode))
	{
		mgd = (MatchingGameData *)GetListNodeData(lnode);
		if (mgd->gameInfo->alias)
			continue;

		if (mgd->gameID != gRegionGlobals.gameID)
			continue;

		PLogmsg(LOGP_DBUG, "  0x%.8lx (%s)\n",
			mgd->gameID, mgd->gameInfo->gameName);

		for (gameLnode = GetFirstListNode(mgd->gameQueue); \
			gameLnode != NULL; gameLnode = GetNextListNode(gameLnode))
		{
			qcon = (Contestant *)GetListNodeData(gameLnode);

			Matching_DumpContestant(qcon, MDC_VERBOSE);
		}
	}

	PLogmsg(LOGP_DBUG, "Contents of purgatory queue:\n");
	for (lnode = GetFirstListNode(gRegionGlobals.purgatoryQueue); \
		lnode != NULL; lnode = GetNextListNode(lnode))
	{
		qcon = (Contestant *)GetListNodeData(lnode);

		Matching_DumpContestant(qcon, MDC_BRIEF);
	}

	PLogmsg(LOGP_DBUG, "\n");
}

//
// Print the contents of a Contestant.
//
void Matching_DumpContestant(Contestant *contestant, int brief)
{
	phoneNumber tmpPhone;
	time_t now = time(0);
	int i;

	if (contestant == NULL) {
		PLogmsg(LOGP_DBUG, "GLITCH: NULL contestant passed to DumpContestant\n");
		Matching_Abort();
		return;
	}

	Common_PhoneFormatDisplay(contestant->boxPhoneNumber.phoneNumber, tmpPhone.phoneNumber);
	// One-line summary.
	//
	if (brief == MDC_BRIEF) {
		PLogmsg(LOGP_DBUG, "\t%-6ld (%ld,%ld)[%ld] '%s' (%s)\n",
			contestant->contestantID,
			contestant->boxSerialNumber.box,
			contestant->boxSerialNumber.region,
			(long)contestant->player,
			contestant->userName,
			tmpPhone.phoneNumber);
		return;
	}

	// this is what the user sent us (+ contestantID)
	//
	PLogmsg(LOGP_DBUG, "\t%-6ld (%ld,%ld)[%ld] '%s' (%s)\n",
		contestant->contestantID,
		contestant->boxSerialNumber.box,
		contestant->boxSerialNumber.region,
		(long)contestant->player,
		contestant->userName,
		tmpPhone.phoneNumber);
	PLogmsg(LOGP_DBUG,
		"\t  rating=%ld  callLongDistance=%ld  gamePatchVersion=%ld\n",
		contestant->rankingInfo.rating,
		(long)contestant->callLongDistance,
		contestant->gamePatchVersion);
	PLogmsg(LOGP_DBUG, "\t  challengeFlags=%ld  opponent (%ld,%ld)[%ld]  gameID=0x%.8lx\n",
		(long)contestant->challengeFlags,
		contestant->oppBoxSerialNumber.box,
		contestant->oppBoxSerialNumber.region,
		(long)contestant->oppPlayer,
		contestant->gameID);
	for (i = 0; i < kMaxPreviousOpponent; i++) {
		if (contestant->prevOpponent[i].when == 0)
			PLogmsg(LOGP_DBUG, "\t  prev %ld: (blank)\n", i);
		else
			PLogmsg(LOGP_DBUG, "\t  prev %ld: (%ld,%ld)[%ld] %d ago\n", i,
				contestant->prevOpponent[i].oppBoxSerialNumber.box,
				contestant->prevOpponent[i].oppBoxSerialNumber.region,
				contestant->prevOpponent[i].oppPlayer,
				now - contestant->prevOpponent[i].when);
	}

	// this is our stuff
	//
	PLogmsg(LOGP_DBUG, "\t  flags=%ld  opponentID=%ld\n",
		contestant->flags,
		contestant->opponentID);
	PLogmsg(LOGP_DBUG,
		"\t  queuedWhen=%ld (%d ago)  purgatoryWhen=%ld (%d ago)\n",
		contestant->queuedWhen,
		(contestant->queuedWhen) ? time(0) - contestant->queuedWhen : 0,
		contestant->purgatoryWhen,
		(contestant->purgatoryWhen) ? time(0) - contestant->purgatoryWhen : 0);
	PLogmsg(LOGP_DBUG, "\t  globalListNode=0x%.8lx  gameListNode=0x%.8lx\n",
		contestant->globalListNode,
		contestant->gameListNode);
}


