/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: DataBase_GamePatch.c,v 1.12 1995/09/19 19:33:58 roxon Exp $
 *
 * $Log: DataBase_GamePatch.c,v $
 * Revision 1.12  1995/09/19  19:33:58  roxon
 * Load different game patches based on locale_phone.
 *
 * Revision 1.11  1995/09/17  17:26:49  roxon
 * Add calling DataBase_PlatformLoadGamePatches(kBoxType_sj01).
 *
 * Revision 1.10  1995/09/13  14:15:25  ted
 * Fixed warnings.
 *
 * Revision 1.9  1995/05/28  20:41:01  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		DataBase_GamePatch.c

	Contains:	xxx put contents here xxx

	Written by:	David Jevans


	Change History (most recent first):

		<16>	11/13/94	ATM		Init a pointer.
		<15>	 11/9/94	ATM		Show requested length in error message.
		<14>	10/20/94	ATM		Say more on errors.
		<13>	 9/19/94	ATM		PLogmsg stuff.
		<12>	 9/12/94	ATM		Changed DataBase_*GameInfo to Common_.
		<11>	  9/3/94	ATM		Now use GameInfo struct.
		<10>	 8/25/94	ATM		Fixed reload stuff to not wipe queues.
		 <9>	 8/24/94	ATM		Added reload stuff.
		 <8>	 8/22/94	ATM		Fixed sizeof(PatchDescriptor) problem.
		 <7>	 8/19/94	DJ		make compile on Mac
		 <6>	 8/19/94	ATM		Moved LoadGamePatches in (was Server_SetupGamePatches).
		 <5>	 8/16/94	ATM		Updated FindGame calls.
		 <4>	 7/19/94	DJ		gameName is now just a char*
		 <3>	 7/13/94	DJ		added DataBase_GetGameName
		 <2>	 6/11/94	DJ		looking up in game patch db for latest version
		 <1>	 5/27/94	DJ		first checked in

	To Do:
*/

#include "Server.h"			// this is only for PreformedMessage type
#include "ServerDataBase.h"
#include "ServerDataBase_priv.h"
#include "Common_PlatformID.h"
#include "Common_ReadConf.h"
//#include "Errors.h"

#include "PatchDB.h"
#include "Messages.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Common_Missing.h"

//
// Prototypes.
//
static void DataBase_PlatformLoadGamePatches(long platformID);


//
// This is obsolete, but still here.
//
long
DataBase_GetLatestGameVersion(long platformID, long gameID)
{
SDBGameNode	*game;

	game = Database_FindGame(platformID, gameID);
	if (game)
		return(game->version);

	return (-1);	// no such game
}

//
// The box passes in the version it currently has.  Based on that, the server
// decides whether or not to send a game patch back.  In either case,
// currentVersion is set to the game patch's current version (-1 if the game
// couldn't be found).
//
PreformedMessage *
DataBase_GetGamePatch(long boxType, long gameID, long boxVersion, long *currentVersion)
{
	SDBGameNode	*game;
	long platformID;

	// At present we only have one patch per platform, not one per boxType,
	// so just convert the boxType to a platformID.
	//
	platformID = Common_BoxTypeToPlatformID(boxType);

	game = Database_FindGame(platformID, gameID);
	if (game != NULL) {
		*currentVersion = game->version;

		if (game->patch == NULL) {
			if (Common_GameInfoForGame(platformID, gameID) == NULL) {
				// Never heard of it.
				//
				PLogmsg(LOGP_NOTICE,
					"GLITCH: Request for game patch for unknown game %.4s-0x%.8lx\n",
					(char *)&platformID, gameID);
			} else {
				// Hmm, tell those slackers to write a game patch.
				//
				Logmsg("game->patch is NULL for %.4s-0x%.8lx\n",
					(char *)&platformID, gameID);
			}
			return (NULL);
		} else {
			// If we've got a game patch newer than what they have, return it.
			//
			if (game->version > boxVersion)
				return (game->patch);
			else
				return (NULL);
		}
	}
	
	Logmsg("No game patch found for %.4s-0x%.8lx\n",
		(char *)&platformID, gameID);
	*currentVersion = -1;
	return (NULL);
}


//
// Load game patches.  This should only be called with an empty gSDB->games.
//
// A single linked list holds all the game patches for every game on every
// platform.  While games are uniquely identified by platformID and gameID,
// we may have game patches for different ROM versions on the same platform.
//
// Things are kind of mixed up at the moment (950301).  We've only got one
// patch per platform, so we only need to go through each once.  Mumble.
//
void
DataBase_LoadGamePatches(void)
{
	// BRAIN DAMAGE: Ought to have some way of iterating over all boxTypes.
	//
	if ( LOCALE_PHONE_C() ) {
		DataBase_PlatformLoadGamePatches(kBoxType_segb);
		DataBase_PlatformLoadGamePatches(kBoxType_sn07);
	} else if ( LOCALE_PHONE_JA() ) {
		DataBase_PlatformLoadGamePatches(kBoxType_sj01);
	}
}


//
// Load the game patches for a specific platform.
//
// Remember, *patches* are by boxType, *games* are by platformID.
//
static void
DataBase_PlatformLoadGamePatches(long boxType)
{
	FILE			*fp = NULL;
	char			buf[128], *cp;
	PreformedMessage	msg;
	PatchDescriptor	descr;
	messOut			opCode;
	long 			hdrLength, fullLength;
	int				pdTrueSize;
	long			platformID;

	platformID = Common_BoxTypeToPlatformID(boxType);

	sprintf(buf, "%.4s/%s", (char *)&boxType, kSDB_GamePatchFile);
	if ((fp = fopen(buf, "rb")) == NULL) {
		PLogmsg(LOGP_FLAW,
			"WARNING: Unable to open game patch file '%s'\n", buf);
		goto nofile;
	}
	Logmsg("Reading '%.4s' game patches from '%s'...\n",
		(char *)&boxType, buf);

	// don't use sizeof(PatchDescriptor); has dangler on end
	pdTrueSize = ((unsigned char *) &descr.data) - ((unsigned char *) &descr);

	while (1) {
		// This ought to be done in PreformedMessage.c, somehow.
		//
		if (fread(&opCode, sizeof(opCode), 1, fp) != 1)
			break;
		if (feof(fp))
			break;
		if (opCode != msGamePatch) {
			PLogmsg(LOGP_FLAW,
				"Wrong opCode in game patch file!  Wanted %ld, got %ld\n",
				(long)msGamePatch, (long)opCode);
			goto nofile;
		}
		if (fread(&descr, pdTrueSize, 1, fp) != 1) {
			PLogmsg(LOGP_FLAW, "Unexpected EOF in game patch read\n");
			goto nofile;
		}

		if ((cp = Common_GameName(platformID, descr.gameID)) == NULL) {
			PLogmsg(LOGP_FLAW,
				"GLITCH: game patch for unknown game %.4s-0x%.8lx\n",
				(char *)&platformID, descr.gameID);
		}
		if (descr.patchVersion <= 0) {
			PLogmsg(LOGP_FLAW,
				"GLITCH: found a game patch with version %ld (%.4s-0x%.8lx)\n",
				descr.patchVersion, (char *)&platformID, descr.gameID);
		}

		hdrLength = sizeof(messOut) + pdTrueSize;
		fullLength = descr.codeSize + hdrLength;
		msg.message = (Ptr)malloc((size_t)fullLength);
		ASSERT(msg.message);

		// copy the header bits over
		//
		memcpy(msg.message, &opCode, sizeof(messOut));
		memcpy(msg.message + sizeof(messOut), &descr, pdTrueSize);

		// read what's left; set length to whole thing
		//
		msg.length = fullLength;
		if (fread(msg.message + hdrLength, descr.codeSize, 1, fp) != 1) {
			PLogmsg(LOGP_FLAW,
				"ERROR: Unexpected EOF in game Patch read, wanted %d bytes\n",
				descr.codeSize);
			goto nofile;
		}

		// This will duplicate the PreformedMessage, so we free it right
		// after we add it to the list.
		//
		// BRAIN DAMAGE: this probably ought to be by boxType.
		//
		DataBase_NewGame(platformID, descr.gameID, descr.patchVersion, cp, &msg);
		free(msg.message);

		Logmsg("  Game patch %.4s-0x%.8lx (%s) v%ld (len=%ld)\n",
			(char *)&platformID, descr.gameID, cp,
			(long)descr.patchVersion, (long)descr.codeSize);
	}

nofile:		// get here if no file to read, or file was hosed
	if (fp != NULL)
		fclose(fp);
}


//
// Called when someone bounces the server.
//
void
DataBase_ReloadGamePatches(void)
{
	PLogmsg(LOGP_NOTICE, "Reloading game patches\n");
	DataBase_NukeGamePatches();
	gSDB->games = SDBGames_New();
	DataBase_LoadGamePatches();
}

