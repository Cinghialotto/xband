/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: DataBase_GameResults.c,v 1.2 1995/05/28 20:41:02 jhsia Exp $
 *
 * $Log: DataBase_GameResults.c,v $
 * Revision 1.2  1995/05/28  20:41:02  jhsia
 * switch to rcs keywords
 *
 */

#define CLIENTRPC
/*
	File:		DataBase_GameResults.c

	Contains:	xxx put contents here xxx

	Written by:	David Jevans


	Change History (most recent first):

		<36>	10/17/94	ATM		THIS FILE IS NOW OBSOLETE.  It has been moved to
									Server_GameResults.c.
		<35>	10/17/94	ATM		Removed some logmsgs for provisional stuff.
		<34>	10/14/94	ATM		Fiddle faddle.
		<33>	10/14/94	ATM		Changed a printf.
		<32>	10/14/94	ATM		Something.
		<31>	10/14/94	ATM		Implemented scoring based on all rounds of MK match.  Twiddled
									some logmsgs.
		<30>	10/11/94	ATM		Use NewGameResult to show errors.
		<29>	10/10/94	ATM		Added yet more logging stuff.
		<28>	10/10/94	ATM		Show last opponent even if game ended in error.
		<27>	 10/9/94	ATM		Now pass in game errors as well.  Added some more stuff.
		<26>	 10/8/94	ATM		Improved result printing.
		<25>	 10/7/94	ATM		Updated for new LastMatchup and PreviousOpponent structs.
		<24>	 10/6/94	ATM		Minor tweaks.
		<23>	 10/5/94	ATM		Added "player" to PlayerAccount and LastMatched.  Moved
									LastMatched into BoxAccount.  Added #define CLIENTRPC.  Handle
									case where current player != last player.
		<22>	 10/4/94	ATM		Added gameID to ranking logmsg.
		<21>	 10/3/94	ATM		The "promoted" message didn't work.
		<20>	 10/3/94	ATM		Print the value of wasSpecific.
		<19>	 10/2/94	ATM		Catch some uninitialized stuff.  Don't give credit for
									specific-challenge matches.
		<18>	 10/1/94	ATM		Fix problem with oppRankingInfo.  Add more log messages.
		<17>	 10/1/94	ATM		Reorganize game result handling around new rating stuff.
		<16>	 9/30/94	ATM		Added NHL '95 to kludgy crap.
		<15>	 9/29/94	ATM		Add NHL '94.  Update numRankingInfo if we try to record a rank
									past it.
		<14>	 9/25/94	ATM		Changed RankingInfo for Kon's new stuff.  Don't yet call the
									rating stuff.
		<13>	 9/19/94	ATM		PLogmsg stuff.
		<12>	 9/16/94	ATM		boxFlags->boxModified, playerFlags->playerModified,
									acceptChallenges->playerFlags.
		<11>	  9/3/94	ATM		Handle "xpoints" field.
		<10>	  9/2/94	ATM		Neglected to set kPA_ranking.
		 <9>	  9/2/94	ATM		Fix aforementioned tie crediting.
		 <8>	 8/31/94	ATM		Credit 1 win and 1 loss for a tie.
		 <7>	 8/28/94	ATM		Don't update game rankings if there's an error result.  (This
									may change...)
		 <6>	 8/19/94	ATM		Removed a FreeAccount call.
		 <5>	 8/19/94	ATM		De-RPCed UpdateRanking.
		 <4>	 8/19/94	ATM		Implemented DataBase_UpdateRanking.
		 <3>	  7/2/94	DJ		GameResult struct
		 <2>	 5/29/94	DJ		tweaked api
		 <1>	 5/27/94	DJ		first checked in

	To Do:
*/


// OBSOLETE!


