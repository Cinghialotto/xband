/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: DataBase_Rankings.h,v 1.2 1995/05/28 20:41:17 jhsia Exp $
 *
 * $Log: DataBase_Rankings.h,v $
 * Revision 1.2  1995/05/28  20:41:17  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		DataBase_Rankings.h

	Contains:	Declarations for KON's beloved rating stuff

	Written by:	KON


	Change History (most recent first):

		 <7>	10/17/94	ATM		THIS FILE IS NOW OBSOLETE.  It has been moved to
									Server_Rankings.h.
		 <6>	10/16/94	ATM		It's a bird!  It's a plane!  No, it's kProvisionalGameCount back
									to 5!
		 <5>	10/15/94	ATM		Changed kProvisionalWinCount back to 0.
		 <4>	10/14/94	ATM		Renamed a constant.
		 <3>	10/14/94	ATM		Changed kProvisionalGameCount from 0 to 5.
		 <2>	10/10/94	ATM		Added gameID to InitializePlayerRankings prototype.
		 <1>	 10/1/94	ATM		Checked into server source tree.
		 <6>	 9/27/94	KON		Added GetNextLevelPoints function.
		 <5>	 9/27/94	KON		Added function to return match point values.
		 <4>	 9/25/94	KON		Change starting rating to 3000 to make sure ratings never go
									negative.
		 <3>	 9/24/94	KON		Added a bunch of reserved fields in the ranking struct so we
									don't have to translate the DB the first time the ranking stuff
									changes.
		 <2>	 9/24/94	KON		First checked in.

	To Do:
*/

// OBSOLETE!


