/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 *	$Id
 *
 *	$Log: DataBase_Opponent.c,v $
 * Revision 1.4  1996/01/10  14:50:19  hufft
 * use libphonedb
 *
 * Revision 1.3  1995/09/27  18:39:17  hufft
 * added Common_Phone support for Japan Server
 *
 * Revision 1.2  1995/05/28  20:41:15  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		DataBase_Opponent.c

	Contains:	xxx put contents here xxx

	Written by:	David Jevans


	Change History (most recent first):

		<34>	 11/9/94	DJ		Renamed some DB routines to DataBaseUtil_ and also to WrapperDB_
									(for Oracle).
		<33>	 9/19/94	ATM		Commented Transmogrify out; it's now obsolete.
		<32>	 9/11/94	ATM		Moved SplitPhoneNumber over into Lata.c.
		<31>	  9/7/94	ATM		Removed TweakOpponentPhoneNumber.
		<30>	  9/6/94	ATM		Complete overhaul of matching system.  This file is largely
									obsolete.
		<29>	  9/1/94	ATM		Use fake LATA "regions" in matching.
		<28>	 8/29/94	ATM		Fixes to matching removal routines.
		<27>	 8/29/94	ATM		Compare player ID as well as boxID in a few places for matching.
									May have had side-effects... stay tuned.
		<26>	 8/28/94	ATM		Okay to match seg9 with segb.
		<25>	 8/25/94	ATM		Don't FindOpponent to someone on the same box.  Fixed a logmsg.
		<24>	 8/25/94	ATM		Matching_FindBestMatch.
		<22>	 8/25/94	ATM		boxType and acceptChallenges stuff.  Changed some log messages.
		<21>	 8/23/94	ATM		Added a Transmogrify in FindChallengeOpponent.
		<20>	 8/22/94	ATM		Changed FindGameOpponentByRank to return the opponent's userID.
		<19>	 8/18/94	DJ		kchallengeewaitingforautomatch
		<18>	 8/18/94	ATM		Fixed a broken printf.
		<17>	 8/16/94	ATM		Updated FindGame calls.
		<16>	 8/13/94	ATM		Added transmogrifier.
		<15>	 8/12/94	DJ		print waitq
		<14>	 8/12/94	DJ		print waitq
		<13>	 8/12/94	ATM		Added Server_GameName calls.
		<12>	 8/12/94	ATM		Made the "removed from wait queue" message show something
									useful, and added a Statusmsg call.
		<11>	 8/11/94	ATM		Error checking in TweakOpponentPhoneNumber.
		<10>	 8/11/94	ATM		Converted to Logmsg().
		 <9>	 8/10/94	ATM		Fixed GetCurrentTime for UNIX.
		 <8>	 8/10/94	ATM		Mac-ified some more.
		 <7>	 8/10/94	ATM		Mac-ified.
		 <6>	 8/10/94	ATM		Moved area code mangling stuff in here.
		 <5>	 7/26/94	BET		Remove GetGlobals reference
		 <4>	 7/25/94	DJ		5 days of hacking, including: massive changes to support
									competitive challenges.  added the general waitq for waitq aging
									too.
		 <3>	 7/18/94	DJ		added opponentMagicCookie to FindOpponent and AddToWaitList
		 <2>	 6/11/94	DJ		Attaching waitQs to games, etc
		 <1>	 5/27/94	DJ		first checked in

	To Do:
*/

#include "Server.h"
#include "ServerCore.h"
#include "ServerDataBase.h"
#include "ServerDataBase_priv.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#ifdef SPOOGEBALL		/////////////////////////////////////////////////////

// someday this goes in its own header file
SDBWaitingNode *Matching_FindBestMatch(userIdentification 	*userID,
									long 				gameID,
									long				boxType,
									long				acceptChallenges,
									phoneNumber			*boxPhoneNumber,
									SDBWaitingNode		**wnodep,
									ListNode			**lnodep);

//
// These routines add/remove a player to the general wait list
//
Boolean DataBase_AddOpponentToGeneralWaitList(	userIdentification 	*userID,
		long gameID, long boxType, long acceptChallenges)
{
SDBGames	*games;
phoneNumber opponentPhoneNumber;

	games = SDB_GetGames(gSDB);
	ASSERT(games);

	opponentPhoneNumber.phoneNumber[0] = 0;
	SDBWaiting_AddOpponent(games->generalWaiting,  false, userID, gameID,
		boxType, acceptChallenges, NULL, &opponentPhoneNumber, 0);

	return(kNoError);
}

//
// Scan through the general wait queue.  If the player is already in there, delete her.
//
Err DataBase_RemoveOpponentFromGeneralWaitList(	userIdentification 	*userID, Boolean removeFromGame)
{
ListNode		*lnode;
SDBWaitingNode	*wnode;
SDBGames		*games;
Err				err;
	games = SDB_GetGames(gSDB);
	ASSERT(games);

	for(lnode = GetFirstListNode(games->generalWaiting->waitingQ); lnode; lnode = GetNextListNode(lnode))
	{
		wnode = (SDBWaitingNode *)GetListNodeData(lnode);
		ASSERT(wnode);

		// remove anybody from this box who has signed on
		if(!DataBaseUtil_CompareBoxSerialNumbers(&wnode->userID.box, &userID->box))
			continue;

		// don't compare userID!
		//if(wnode->userID.userID != userID->userID)
		//	continue;

		if(removeFromGame && !wnode->isChallenge)
		{
			err = DataBase_RemoveOpponentFromGameWaitList(userID, wnode->gameID);	// she was waiting for a specific game.  remove her from that game's waitQ
			ASSERT_MESG(err == kNoError, "DataBase_RemoveOpponent returned an error.  But the player is supposed to be waiting for a game?!?!");
		}


		// Remove from the general waitQ
		RemoveListNodeFromList(lnode);
		DisposeListNode(lnode);
		free(wnode);
		break;
	}
	
	DataBase_PrintWaitQ();
	
	return(kNoError);
}



//
// Find an opponent of similar rank for this game.  If found, fill out opponentPhoneNumber and return true.
// The userID will be used to find ranking information in the future.
//
Boolean DataBase_FindGameOpponentByRank(userIdentification 	*userID,
									long 				gameID,
									long				boxType,
									long				acceptChallenges,
									phoneNumber 		*boxPhoneNumber,
									userIdentification	*opponentUserID,
									phoneNumber 		*opponentPhoneNumber,
									long				*opponentMagicCookie)
{
SDBGameNode		*game = NULL;
ListNode		*lnode = NULL;
SDBWaitingNode	*wnode = NULL;

	game = Database_FindGame(gameID, false);

	ASSERT_MESG(game, "Implementation Error: Unsupported game, yet trying to match player?!?");
	if(!game)
	{
		// this is extremely fucked.  ServerCore shouldn't let us get in here, cuz if the
		// game is unsupported it should have aborted before trying to match up players.
		return(false);
	}

	// Find the best possible match, based on a variety of fascinating criteria.
	//
	Matching_FindBestMatch(userID, gameID, boxType, acceptChallenges, boxPhoneNumber, &wnode, &lnode);
	if (wnode == NULL)
		return (false);
	
	*opponentUserID = wnode->userID;
	*opponentPhoneNumber = wnode->opponentPhoneNumber;
	DataBase_TweakOpponentPhoneNumber(opponentPhoneNumber, boxPhoneNumber);
	*opponentMagicCookie = wnode->opponentMagicCookie;

	// remove her from the general waitQ
	DataBase_RemoveOpponentFromGeneralWaitList(&wnode->userID, false);

	// remove her from this game's waiting queue.
	RemoveListNodeFromList(lnode);
	DisposeListNode(lnode);
	free(wnode);

	Logmsg("FindGameOpponentByRank: '%s' (%s) matched with (%s)\n",
		userID->userName, boxPhoneNumber->phoneNumber,
		opponentPhoneNumber->phoneNumber);

	DataBase_PrintWaitQ();

	return(true);
}

SDBWaitingNode *Matching_FindBestMatch(userIdentification 	*userID,
									long 				gameID,
									long				boxType,
									long				acceptChallenges,
									phoneNumber			*boxPhoneNumber,
									SDBWaitingNode		**wnodep,
									ListNode			**lnodep)
{
	SDBGameNode		*game;
	ListNode		*lnode;
	SDBWaitingNode	*wnode;

	wnode = NULL;
	lnode = NULL;

	game = Database_FindGame(gameID, false);
	ASSERT(game);
	if (game == NULL)
		goto fail;		// shouldn't be here if we can't ID the game!!

	lnode = GetFirstListNode(game->waiting->waitingQ);

	// If the queue is empty, we will have great difficulty matching him.
	if (lnode == NULL)
		goto fail;

	// Got some people, find the best match.
	for (; lnode != NULL; lnode = GetNextListNode(lnode)) {
		wnode = (SDBWaitingNode *)GetListNodeData(lnode);
		ASSERT(wnode);

		// don't match players with different ROM versions
		if (wnode->boxType != boxType) {
			if ((wnode->boxType == kBoxType9 && boxType == kBoxTypeb) ||
				(wnode->boxType == kBoxTypeb && boxType == kBoxType9))
			{
				// seg9 and segb can play together; just changed mail upload
			} else {
				continue;
			}
		}

		// Don't match people on the same box.  This is impossible unless
		// they logged in twice, from different player #s.
		if (DataBaseUtil_CompareBoxSerialNumbers(&userID->box, &wnode->userID.box))
			continue;

		// Don't match people with "local area only" against long-distance
		// players.
		// Don't know how this will work in the final product; for now
		// we'll just issue a fake LATA call and hope it works.
		if (!PhoneDB_IsLocal(boxPhoneNumber, &wnode->opponentPhoneNumber))
			continue;

		// found one, just fall out
		break;
	}
	if (lnode == NULL)
		wnode = NULL;

fail:
	// Whatever we got, return it.
	*wnodep = wnode;
	*lnodep = lnode;
	return;
}


//
// In the future, the userID will be used to add you to a list according to your rank.
// for now, it just adds you to a list.
//
Err DataBase_AddOpponentToGameWaitList(	userIdentification 	*userID,
									long 				gameID,
									long				boxType,
									long				acceptChallenges,
									const phoneNumber 	*thePhoneNumber,
									long				*opponentMagicCookie)
{
SDBGameNode	*game;

	game = Database_FindGame(gameID, false);
	ASSERT_MESG(game, "Implementation Error: Unsupported game, yet trying to match player?!?");
	*opponentMagicCookie = Database_NewOpponentMagicCookie();

	SDBWaiting_AddOpponent(game->waiting,  false, userID, gameID, boxType, acceptChallenges, NULL, thePhoneNumber, *opponentMagicCookie);

	DataBase_AddOpponentToGeneralWaitList(userID, gameID, boxType, acceptChallenges);	// add to the general waitlist too.

	return(kNoError);
}

Err DataBase_RemoveOpponentFromGameWaitList(userIdentification 	*userID, long gameID)
{
SDBGameNode		*game;
ListNode		*lnode;
SDBWaitingNode	*wnode;

	game = Database_FindGame(gameID, false);

	ASSERT_MESG(game, "Implementation Error: Unsupported game, yet trying to match player?!?");
	if(!game)
		return(false);// this is extremely fucked.  ServerCore shouldn't let us get in here


	for(lnode = GetFirstListNode(game->waiting->waitingQ); lnode; lnode = GetNextListNode(lnode))
	{
	
		wnode = (SDBWaitingNode *)GetListNodeData(lnode);
		ASSERT(wnode);

		// remove anybody from this box who has logged in
		if(!DataBaseUtil_CompareBoxSerialNumbers(&wnode->userID.box, &userID->box))
			continue;
		// don't compare userID!
		//if(wnode->userID.userID != userID->userID)
		//	continue;

		// remove her from the waiting queue.
		RemoveListNodeFromList(lnode);
		DisposeListNode(lnode);
		free(wnode);
		
		DataBase_PrintWaitQ();
		return(kNoError);
	}
	
	MESG("DataBase_RemoveOpponentFromGameWaitList: this opponent not registered for this game?!?!");
	DataBase_PrintWaitQ();
	return(kOpponentNotRegistered);
}


//
// These routines add/remove players to the challenge list (which is actually just the
// general waitQ, but with the isChallenge flag true and other info stored.
//
Err DataBase_AddOpponentToChallengeWaitList(	userIdentification 	*userID,
									long 				gameID,
									long				boxType,
									long				acceptChallenges,
									userIdentification 	*challengeUserID,
									const phoneNumber 	*thePhoneNumber,
									long				*opponentMagicCookie)
{
SDBGames	*games;

	games = SDB_GetGames(gSDB);
	ASSERT(games);

	SDBWaiting_AddOpponent(games->generalWaiting,  true, userID, gameID, boxType, acceptChallenges, challengeUserID, thePhoneNumber, *opponentMagicCookie);

	return(kNoError);
}

Err DataBase_FindChallengeOpponent(userIdentification 	*userID,
									long 				gameID,
									long				boxType,
									long				acceptChallenges,
									userIdentification 	*challengeUserID,
									phoneNumber 		*boxPhoneNumber,
									phoneNumber 		*opponentPhoneNumber,
									long				*opponentMagicCookie)
{
ListNode		*lnode;
SDBWaitingNode	*wnode;
SDBGames		*games;

	games = SDB_GetGames(gSDB);
	ASSERT(games);

	for(lnode = GetFirstListNode(games->generalWaiting->waitingQ); lnode; lnode = GetNextListNode(lnode))
	{
	
		wnode = (SDBWaitingNode *)GetListNodeData(lnode);
		ASSERT(wnode);
	
		//!BOX! if(!DataBaseUtil_CompareBoxSerialNumbers(&wnode->userID.box, &challengeUserID->box))
		if(!DataBaseUtil_CompareUserIdentifications(&wnode->userID, challengeUserID))
			continue;
		if(wnode->userID.userID != challengeUserID->userID)
			continue;

		if (DataBase_TransmogrifyGameID(wnode->gameID) !=
			DataBase_TransmogrifyGameID(gameID))
		{
			return(kChallengeeWaitingForDifferentGame);
		}

		// Don't match if target is waiting for automatch.
		//
		if(!wnode->isChallenge)
			return(kChallengeeWaitingForAutoMatch);

		// Don't match if ROM versions don't work.
		if (wnode->boxType != boxType) {
			Logmsg("FindChallengeOpponent: [%.8lx] (on queue) vs [%.8lx] (caller)\n",
				wnode->boxType, boxType);
			return (kDifferentRomVersion);
		}

		// OK, he is waiting.  Is he waiting for me?
		//!BOX! if(!DataBaseUtil_CompareBoxSerialNumbers(&wnode->challengeUserID.box, &userID->box) || wnode->challengeUserID.userID != userID->userID)
		if(!DataBaseUtil_CompareUserIdentifications(&wnode->challengeUserID, userID))
			return(kChallengeeWaitingForDifferentUser);

		*opponentPhoneNumber = wnode->opponentPhoneNumber;
		DataBase_TweakOpponentPhoneNumber(opponentPhoneNumber, boxPhoneNumber);
		*opponentMagicCookie = wnode->opponentMagicCookie;

		// remove her from the waiting queue.
		RemoveListNodeFromList(lnode);
		DisposeListNode(lnode);
		free(wnode);

		Logmsg("FindChallengeOpponent: '%s' (%s) matched with (%s)\n",
			userID->userName, boxPhoneNumber->phoneNumber,
			opponentPhoneNumber->phoneNumber);

		DataBase_PrintWaitQ();
		
		return(kNoError);
	}
	
	//MESG("DataBase_FindChallengeOpponent: opponent is not waiting for you.");
	return(kChallengeeNotAvailable);
}


//
// This is the waitQ code.
//

SDBWaiting *SDBWaiting_New(void)
{
SDBWaiting *w;

	w = (SDBWaiting *)malloc(sizeof(SDBWaiting));
	ASSERT_MESG(w, "out of mems");
	if(!w)
		return(NULL);
	
	w->waitingQ = NewList();
	ASSERT(w->waitingQ);
	
	return(w);
}

void SDBWaiting_AddOpponent(	SDBWaiting 			*waiting,
								Boolean				isChallenge,
								userIdentification 	*userID,
								long 				gameID,
								long				boxType,
								long				acceptChallenges,
								userIdentification 	*challengeUserID,
								const phoneNumber 	*thePhoneNumber,
								long				opponentMagicCookie)
{
SDBWaitingNode	*wnode;
ListNode		*lnode;

	ASSERT(waiting);

	wnode = (SDBWaitingNode *)malloc(sizeof(SDBWaitingNode));
	ASSERT(wnode);
	
	wnode->isChallenge = isChallenge;
	
	ASSERT(userID);
	wnode->userID = *userID;

	if (gameID == kNBAJamGameID) {
		Logmsg("Pretending Old NBA Jam (0x%.8lx) is NBA Jam (0x%.8lx)\n",
			kNBAJamGameID, 0x39677bdb);
		Statusmsg("Pretending Old NBA Jam (0x%.8lx) is NBA Jam (0x%.8lx)\n",
			kNBAJamGameID, 0x39677bdb);		// remove this eventually
	}
	//wnode->gameID = gameID;
	// (should use FindGame in here...?)
	wnode->gameID = DataBase_TransmogrifyGameID(gameID);

	if(challengeUserID)
		wnode->challengeUserID = *challengeUserID;

	if(thePhoneNumber)
		wnode->opponentPhoneNumber = *thePhoneNumber;

	wnode->boxType = boxType;
	wnode->acceptChallenges = acceptChallenges;
	wnode->opponentMagicCookie = opponentMagicCookie;

	wnode->addedToWaitQTimestamp = DataBase_GetCurrentTime();
	lnode = NewListNode((Ptr)wnode);
	ASSERT(lnode);
	AddListNodeToList(waiting->waitingQ, lnode);
	
	DataBase_PrintWaitQ();
}


//
// For every game
// 	check the waitq
//		check to see if the time difference is bigger than kMaxTimeInWaitQ
//		if so, remove that dude from the waitQ.  set some kinda free game bit?
//
void DataBase_AgeWaitQ(long	maxTimeInWaitQ)
{
long	curTime;
SDBGames	*games;
ListNode	*node, *tempnode;
SDBGameNode	*game;
SDBWaitingNode	*wnode;
Boolean		listChanged = false;

	curTime = DataBase_GetCurrentTime();
	
	games = SDB_GetGames(gSDB);
	ASSERT(games);

	for(node = GetFirstListNode(games->generalWaiting->waitingQ); node;)
	{
		wnode = (SDBWaitingNode *)GetListNodeData(node);
		ASSERT(wnode);

		if(curTime - wnode->addedToWaitQTimestamp >= maxTimeInWaitQ)
		{
			Logmsg("DataBase_AgeWaitQ timeout!  Removing '%s' (%s) from the waitQ\n",
				wnode->userID.userName, wnode->opponentPhoneNumber.phoneNumber);
			{
				SDBGameNode	*game;

				game = Database_FindGame(wnode->gameID, false);
				if (strlen(wnode->opponentPhoneNumber.phoneNumber) == 0) {
					Statusmsg("segad  : REMOVED: '%s' from queue for %s, queue@%ld\n",
						wnode->userID.userName,
						Server_GameName(wnode->gameID),
						NumListNodesInList(game->waiting->waitingQ) -1);
				} else {
					Statusmsg("segad  : REMOVED: '%s' (%s) from queue for %s, queue@%ld\n",
						wnode->userID.userName,
						wnode->opponentPhoneNumber.phoneNumber,
						Server_GameName(wnode->gameID),
						NumListNodesInList(game->waiting->waitingQ) -1);
				}
			}

			// remove timedout doode from any game specific waitq
			if(!wnode->isChallenge)
				DataBase_RemoveOpponentFromGameWaitList(&wnode->userID, wnode->gameID);

			// remove timedout doode from the waiting queue.
			tempnode = GetNextListNode(node);
			RemoveListNodeFromList(node);
			DisposeListNode(node);
			free(wnode);

			node = tempnode;
			
			listChanged = true;
		}
		else
			node = GetNextListNode(node);
	}
	
	if(listChanged)
		DataBase_PrintWaitQ();
}


//
// For every game
// 	check the waitq
//		check to see if the time difference is bigger than kMaxTimeInWaitQ
//		if so, remove that dude from the waitQ.  set some kinda free game bit?
//
void DataBase_PrintWaitQ(void)
{
SDBGames	*games;
SDBGameNode	*game;
ListNode	*node, *node2, *tempnode;
SDBWaitingNode	*wnode;


	games = SDB_GetGames(gSDB);
	ASSERT(games);

	node = GetFirstListNode(games->generalWaiting->waitingQ);
	if(!node)
		Logmsg("There are no pending specific challenge requests\n");
	else
	{
		Logmsg("Pending specific challenge requests:\n");
		for(; node;)
		{
			wnode = (SDBWaitingNode *)GetListNodeData(node);
			ASSERT(wnode);

			if(wnode->isChallenge)
			{
				Logmsg("   Game #0x%.8lx: %s (%ld,%ld)[%ld] is waiting to play user (%ld,%ld)[%ld]\n",
							wnode->gameID,
							wnode->opponentPhoneNumber.phoneNumber,
							wnode->userID.box.box,
							wnode->userID.box.region,
							wnode->userID.userID,
							wnode->challengeUserID.box.box,
							wnode->challengeUserID.box.region,
							wnode->challengeUserID.userID);
			}

			node = GetNextListNode(node);
		}
	}

	Logmsg("Automatch wait queues:\n");
	for(node = GetFirstListNode(games->list); node; node = GetNextListNode(node))
	{
		game = (SDBGameNode *)GetListNodeData(node);
	
		ASSERT(game);
		if(!game)
			continue;

		node2 = GetFirstListNode(game->waiting->waitingQ);
		if(!node2)
			Logmsg("    Game %s: empty queue\n", game->gameName);
		else
		{
			Logmsg("    Game %s: waiting players:\n", game->gameName);
			for(; node2; node2 = GetNextListNode(node2))
			{
				wnode = (SDBWaitingNode *)GetListNodeData(node2);
				ASSERT(wnode);

				Logmsg("\t- %s (%ld,%ld)[%ld] [0x%.8lx] is waiting to play\n",
					wnode->opponentPhoneNumber.phoneNumber,
					wnode->userID.box.box, wnode->userID.box.region,
					wnode->userID.userID,
					wnode->boxType);
			}
		}
	}

	Logmsg("\n");
}

//
// For games like NBA Jam, match the old and new versions together
// (assuming they actually work together).
//
// This routine can probably be exorcised, since the main reason for
// transmogrification was to make matching work correctly.  That's now
// handled with the "alias" field in the GameInfo struct.
//
long DataBase_TransmogrifyGameID(long gameID)
{
	if (gameID == kNBAJamGameID) {
		return (0x39677bdb);
	} else {
		return (gameID);
	}
}

#endif	/*SPOOGEBALL*/		////////////////////////////////////////////////

#ifdef unix
#include <sys/time.h>
#endif

// This needs to return a steadily increasing value expressed in VBL ticks, i.e.
// it increases 60 times per second.
//
// This will have to be adjusted on UNIX, or we will overflow well before the
// end of the Epoch.
unsigned long DataBase_GetCurrentTime(void)
{

#ifdef unix
struct timeval	tp;

	gettimeofday(&tp, nil);
	return ((tp.tv_sec*60) + (tp.tv_usec/166666));
#else
#ifdef THINK_C
	return( Ticks );
#else
	return( LMGetTicks() );
#endif
#endif

}
