/*
 *	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: BINTree.h,v 1.3 1996/01/22 16:05:13 ted Exp $
 *
 * $Log: BINTree.h,v $
 * Revision 1.3  1996/01/22  16:05:13  ted
 * Added T_NEXT enum, and changed proto of BINDelete.
 *
 * Revision 1.2  1995/05/28  20:40:59  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		BINTree.h

	Contains:	xxx put contents here xxx

	Written by:	Ted


	Change History (most recent first):

		 <1>	 11/7/94	HEC		first checked in

	To Do:
*/


#ifndef __BINTREE__
#define __BINTREE__

enum { T_LT = -1, T_EQ = 0, T_GT = 1, T_DEL=2, T_NEXT=3 };

typedef struct _binnode {
	struct _binnode *	parent;		// points to parent node. Nil means root.
	struct _binnode *	left;		// point to left child
	struct _binnode *	right;		// point to right child
} BINNode, *BINNodePtr;

typedef struct {
	BINNodePtr			root;		// points to top node
	long				members;	// number of nodes in tree
} BINTree, *BINTreePtr;

// user-defined procedure prototypes
typedef long (*BINCMPProc)(BINNodePtr key1, BINNodePtr key2);
typedef void (*BINDumpProc)(BINNodePtr n, long refcon);
typedef BINNodePtr (*BINDelProc)(BINNodePtr n);


void		BINInit(BINTreePtr root);
short		BINInsert(BINTreePtr tree, void *node);
BINNodePtr	BINDelete(register BINTreePtr tree, BINNodePtr node);
BINNodePtr	BINSearch(register BINNodePtr node, register void *data);
void		BINDump(BINNodePtr n, long refcon);
BINDumpProc BINSetDumpProc(BINDumpProc dumpProc);
BINCMPProc	BINSetCompareProc(BINCMPProc cmpProc);
BINDelProc	BINSetDeleteProc(BINDelProc delProc);
void		BINClearNode(BINNodePtr);

#endif __BINTREE__


