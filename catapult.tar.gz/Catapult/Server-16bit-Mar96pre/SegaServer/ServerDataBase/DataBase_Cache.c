/*
 * $Id: DataBase_Cache.c,v 1.6 1995/12/06 00:42:10 steveb Exp $
 *
 * $Log: DataBase_Cache.c,v $
 * Revision 1.6  1995/12/06  00:42:10  steveb
 * Ported to Solaris 2.4 (STDC && SVR4).
 *
 * Revision 1.5  1995/11/16  17:23:15  steveb
 * Fixed stupid error message where I try to print out the fd associated
 * with an fp when fopen() returns null.  Duh.
 *
 * Revision 1.4  1995/09/17  20:44:27  steveb
 * Added support for "smart" stitcher updates.
 *
 * Revision 1.3  1995/09/13  14:15:21  ted
 * Fixed warnings.
 *
 * Revision 1.2  1995/08/21  13:10:52  steveb
 * Caching rpc.segad re-checkin.
 *
 *
 */

#include <errno.h>
#include <malloc.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <sys/param.h>

#include "ServerDataBase_priv.h"
#include "Errors.h"

#include "Common.h"
#include "Common_Log.h"
#include "Common_ReadConf.h"
#include "Common_Missing.h"

#include "DataBase_Cache.h"

#if 0
#define VERBOSE
#endif

#define CACHE_STATS

typedef struct _StitcherInfo {
	time_t timestamp; /* timestamp of last buffer flush */
	int    items;     /* current number of items in sbuf */
	int    max;       /* max number of entries in sbuf */
	char   *sbuf;     /* stitcher buffer */
	FILE   *sfp;      /* stitcher log file pointer */
} StitcherInfo;

typedef struct _SDBCache {
    long entries; /* current number of entries in cache */
    long max;     /* max number of entries allowed in cache */
    long version; /* the database file version */

    BoxRead  read;  /* primitive box read function */
    BoxWrite write; /* primitive box write function */
    BoxFree  free;  /* primitive box free function */

	SDBBoxCachePtr mru;
	SDBBoxCachePtr lru;

#ifdef CACHE_STATS
	unsigned long  hits;
	unsigned long  misses;
#endif

	StitcherInfo si;
} SDBCache;

#if 0
typedef struct _LookupInfo {
	BoxSerialNumber	bsn;
	UserName		player[4];
	PhoneNumber		phone;
	HardwareID		hwid;
	unsigned long	csid;
} LookupInfo;
#endif

typedef struct _SDBBoxCache {
    int valid;  /* true if this is a entry contains a valid box pointer */
	int cached; /* true if this entry is currently cached */
    int dirty;  /* true if this cache entry has been modified */

	BSNPtr bsn;
    SDBBoxPtr      box;  /* pointer to the box account struct (if valid) */
    SDBBoxCachePtr next; /* next box in the cache (if cached) */
    SDBBoxCachePtr prev; /* previous box in the cache (if cached) */
} SDBBoxCache;

SDBCache *gCache = 0;

CacheRWInfo gRDinfo;
CacheRWInfo gWRinfo;

static void list_add_entry  (SDBBoxCachePtr entry, SDBCachePtr cache);
static void list_del_entry  (SDBBoxCachePtr entry, SDBCachePtr cache);
static void inform_stitcher (SDBBoxCachePtr entry, SDBCachePtr cache);
static void flush_stitchlog (SDBCachePtr cache, time_t timestamp);
static void allocate_buffer (SDBCachePtr cache);
static void set_buffering   (SDBCachePtr cache);

/*--------------------------------------------------------------------------*/

/*
 * CacheInit: Initializes the cache data structure.  
 */
SDBCachePtr
Cache_New(long version, BoxRead bread, BoxWrite bwrite, BoxFree bfree)
{
    SDBCachePtr cache = (SDBCachePtr) malloc(sizeof(SDBCache));
	long max;

	if ( !cache ) {
		PLogmsg(LOGP_FLAW, "[Cache_New] malloc failed\n");
		return(NULL);
	}

	cache->entries = 0;

	max = gConfig.cacheMax;
	if ( max < 1 )
		cache->max = 1;
	else if ( max > cache->max )
		cache->max = max;

	cache->version = version;

	cache->read  = bread;
	cache->write = bwrite;
	cache->free  = bfree;

	cache->mru = NULL;
	cache->lru = NULL;

#ifdef CACHE_STATS
	cache->hits = 0;
	cache->misses = 0;
#endif

	cache->si.timestamp = 0;
	cache->si.items = 0;
	cache->si.sfp = NULL;
	cache->si.max = gConfig.stitcherBufferMax;
	allocate_buffer(cache);

	Logmsg("Stitcher update is %s\n", gConfig.stitcherUpdateOn ? "on" : "off");
	Logmsg("Delayed write is %s\n", gConfig.delayWrites ? "on" : "off");
	Logmsg("Backup on write is %s\n", gConfig.backupWrites ? "on" : "off");
	Logmsg("Using cache size of %ld\n", max);

	return(cache);
}

/* 
 * Cache_NewEntry: Initializes a per box cache entry.
 */
SDBBoxCachePtr
Cache_NewEntry(SDBBoxPtr box)
{
    SDBBoxCachePtr entry;

	ASSERT( box );
	if ( box == NULL )
		return(NULL);

    entry = (SDBBoxCachePtr) malloc(sizeof(SDBBoxCache));
	if ( entry == NULL ) {
		PLogmsg(LOGP_FLAW, "[Cache_NewEntry] entry malloc failed\n");
		return(NULL);
	}

	entry->valid  = 1;
	entry->cached = 0;
	entry->dirty  = 0;

	if ( (entry->bsn = (BSNPtr) malloc(sizeof(BoxSerialNumber))) == NULL ) {
		PLogmsg(LOGP_FLAW, "[Cache_NewEntry] bsn malloc failed\n");
		free(entry);
		return(NULL);
	}
	else {
		entry->bsn->region = box->boxAccount.box.region;
		entry->bsn->box    = box->boxAccount.box.box;
	}

    entry->box  = box;
	entry->prev = NULL;
	entry->next = NULL;

    return(entry);
}

void
Cache_InvalidateEntry(SDBBoxCachePtr entry)
{
	ASSERT ( entry );
	if ( entry == NULL )
		return;

	entry->valid  = 0;
	entry->box = NULL;
}

/*
 * Cache_ReadBox:  Get a box pointer for a particular entry.  Either
 * return a valid pointer, or read the box off disk.
 */
SDBBoxPtr
Cache_ReadBox(SDBBoxCachePtr entry, CacheRWInfo *info)
{
	SDBCachePtr	cache;

	ASSERT( entry );
	ASSERT( info );
    if ( entry == NULL || info == NULL ) 
		return(NULL);

	cache = info->cache;
	ASSERT( cache );
	if ( cache == NULL )
		return(NULL);

    /*
	 * Now, lets find the damn box.  If the entry is marked as valid,
	 * just return the box pointer.  Otherwise read it off disk into mem, 
	 * blowing away the oldest cache entry if cache->max will be exceeded, 
	 * and add it to the cache.  Every time a valid entry is accessed, it 
	 * will be moved to the mru position in the list.
	 */
	if ( entry->valid ) {
		if ( entry->cached ) {
			list_del_entry(entry, cache);
			list_add_entry(entry, cache);

#ifdef CACHE_STATS
			cache->hits++;
#endif
		}

		return(entry->box);
	}
	else {
#ifdef CACHE_STATS
		cache->misses++;
#endif

		entry->box = cache->read(entry, cache);
		if ( entry->box ) {
			entry->valid = 1;
			list_add_entry(entry, cache);

			return(entry->box);
		}
		else
			return(NULL);
	}
}

/*
 * Cache_WriteBox:  Write a cached box entry to disk.  
 */
Err
Cache_WriteBox(SDBBoxCachePtr entry, CacheRWInfo *info)
{
	SDBCachePtr	cache;
    Err 		rval;

	ASSERT( entry );
	ASSERT( info );
    if ( entry == NULL || info == NULL ) 
		return(kFucked);

	cache = info->cache;
	ASSERT( cache );
	if ( cache == NULL )
		return(kFucked);

    if ( info->type & kCheckPoint ) {
		/*
		 * Short circuit the caching during a checkpoint.  This
		 * allows all the box entries to be written out without
		 * changing the current contents of the cache.
		 */
		if ( entry->valid && entry->box ) {
			rval = cache->write(entry, cache, info->data);
			if ( rval == kNoError ) {
				if ( entry->dirty ) {
					/* this must be because of a delayed write */
					inform_stitcher(entry, cache);
				}
				entry->dirty = 0;
			}
		}
		else {
			/*
			 * Read from disk, but don't cache, and free box
			 * entry once we are done.
			 */
			entry->box = cache->read(entry, cache);
			if ( entry->box ) {
				entry->valid = 1;
				rval = cache->write(entry, cache, info->data);
				cache->free(entry, info->cache);
			}
			else
				rval = kFucked;
		}
	}
	else if ( entry->valid && entry->box ) {
		if ( info->type & kForceWrite ) {
			if ( gConfig.delayWrites ) {
				Logmsg("Forcing write [%ld, %ld] %ld entries in cache\n", 
					entry->bsn->box, entry->bsn->region, cache->entries);
			}

			rval = cache->write(entry, cache, info->data);
			if ( rval == kNoError ) {
				entry->dirty = 0;
				if ( info->type & kInformStitcher )
					inform_stitcher(entry, cache);
			}
		}
		else if ( gConfig.delayWrites ) {
			entry->dirty = 1;
			rval = kNoError;
		}
		else {
			rval = cache->write(entry, cache, info->data);
			if ( rval == kNoError ) {
				entry->dirty = 0;
				if ( info->type & kInformStitcher )
					inform_stitcher(entry, cache);
			}
		}
	}
	else {
		/* This should not happen */
		PLogmsg(LOGP_FLAW, "[Cache_WriteBox] invalid box entry\n");
		return(kFucked);
	}

	return(rval);
}

BoxSerialNumber *
Cache_GetBsn(SDBBoxCachePtr entry)
{
	ASSERT ( entry );
	if ( entry == NULL )
		return(NULL);

    return(entry->bsn);
}

void
Cache_Stats(SDBCachePtr cache)
{
	float ratio;
	long max;

	if ( !cache ) 
		return;

	Logmsg("Stitcher update is %s\n", gConfig.stitcherUpdateOn ? "on" : "off");

	Logmsg("Delayed write is %s\n", gConfig.delayWrites ? "on" : "off");
	Logmsg("Backup on write is %s\n", gConfig.backupWrites ? "on" : "off");

	max = gConfig.cacheMax;
	if ( max > cache->max )
		cache->max = max;

	Logmsg("Using cache size of %ld\n", cache->max);

	Logmsg("Cache Info: %ld entries in cache out of %ld max\n",
		cache->entries, cache->max);

#ifdef CACHE_STATS
	Logmsg("Cache Stats: %ld hits %ld misses\n", 
		cache->hits, cache->misses);

	if ( (cache->hits + cache->misses) > 0 )
		ratio = (float) cache->hits / (float) (cache->hits+cache->misses);
	else
		ratio = 0.0;

	Logmsg("Cache Stats: hit/miss ratio %.2f%%\n", ratio * 100.0);
#endif
}

/*--------------------------------------------------------------------------*/

/*
 * Here are the read/write/free wrapper functions.  These can be changed
 * if the method of reading/writing/freeing changes.
 */

/* Unpublished function prototypes needed from DataBase_Core.c */
extern SDBBoxPtr SDBBox_Read   (FILE *, long);
extern Err       SDBBox_Write  (SDBBoxPtr, void *);
extern Err 	     OSDBBox_Write (SDBBoxPtr, FILE *);
extern void      SDBBox_Free   (SDBBoxPtr);

/*
 * _read_cached_box: Reads a box entry from it own file on disk.
 */
SDBBoxPtr 
_read_cached_box(SDBBoxCachePtr entry, SDBCachePtr cache)
{
	char fname[256];
    FILE *fp;

#ifdef VERBOSE
		Logmsg("Reading [%ld, %ld] %ld entries in cache\n", 
			entry->bsn->box, entry->bsn->region, cache->entries);
#endif

    /* Determine the pathname of the box file */
	sprintf(fname, "ServerDB.dir.%ld/boxdir.%05ld/box.%05ld",
		entry->bsn->region, entry->bsn->box >> 10, entry->bsn->box);

	if ( (fp = fopen(fname, "r")) == NULL ) {
		PLogmsg(LOGP_FLAW, "[BoxRead] error opening %s: errno = %d\n", 
			fname, errno);
		return(NULL);
	}

	/* And read it into a box struct */
	entry->box = SDBBox_Read(fp, cache->version);

	if ( fclose(fp) != 0 ) {
		PLogmsg(LOGP_FLAW, "[BoxRead] error closing %s: errno = %d\n", 
			fname, errno);
		return(NULL);
	}

	return(entry->box);
}

Err 
_write_cached_box(SDBBoxCachePtr entry, SDBCachePtr cache, void *data)
{
#ifdef VERBOSE
	Logmsg("Writing [%ld, %ld] %ld entries in cache\n", 
		entry->bsn->box, entry->bsn->region, cache->entries);
#endif

    if ( data == NULL ) {
		/* Write the box data to it's own file */
		return(SDBBox_Write(entry->box, NULL));
	}
	else {
		/* Write the box data to the file pointer */
		return(OSDBBox_Write(entry->box, (FILE *) data));
	}
}

void 
_free_cached_box(SDBBoxCachePtr entry, SDBCachePtr cache)
{
#ifdef VERBOSE
	Logmsg("Freeing [%ld, %ld] %ld entries in cache\n", 
		entry->bsn->box, entry->bsn->region, cache->entries);
#endif

	if ( entry->valid && entry->box ) {
		SDBBox_Free(entry->box);
		entry->valid = 0;
		entry->box = NULL;
	}
	else {
		PLogmsg(LOGP_FLAW, "[Cache_FreeBox] [%ld, %ld] is not valid\n", 
			entry->bsn->box, entry->bsn->region);
	}
}

/*--------------------------------------------------------------------------*/

static void
list_add_entry(SDBBoxCachePtr entry, SDBCachePtr cache)
{
    Err	rval;

	if ( cache->entries == cache->max ) {
		/*
		 * Check if box is dirty, if so write it out to disk.  Clear the
		 * dirty flag if the write was successfull.
		 */
		if ( cache->lru->valid && cache->lru->box && cache->lru->dirty ) {
			rval = cache->write(cache->lru, cache, NULL);
			if ( rval == kNoError )
				cache->lru->dirty = 0;
		}

		/* Now remove the box from the cache */
		cache->free(cache->lru, cache);
		list_del_entry(cache->lru, cache);
		cache->lru->cached = 0;
		cache->lru->dirty  = 0;
	}

	if ( cache->entries == 0 ) {
		cache->mru = cache->lru = entry;
		entry->next = NULL;
		entry->prev = NULL;
	}
	else {
		entry->next = NULL;
		entry->prev = cache->mru;
		entry->prev->next = entry;
		cache->mru = entry;
	}

	entry->cached = 1;
	cache->entries++;
}

static void 
list_del_entry(SDBBoxCachePtr entry, SDBCachePtr cache)
{
	if ( entry == cache->mru ) {
		cache->mru = entry->prev;
		if ( cache->mru )
			cache->mru->next = NULL;
	}

	if ( entry == cache->lru ) {
		cache->lru = entry->next;
		if ( cache->lru )
			cache->lru->prev = NULL;
	}

	if ( entry->next )
		entry->next->prev = entry->prev;

	if ( entry->prev )
		entry->prev->next = entry->next;

	entry->cached = 0;
	cache->entries--;
}

/* 
 * I hate to say it, but this is a _temporary hack_ to shut Raja
 * up until I can come up with a cleaner way to do this.
 */
static void
inform_stitcher(SDBBoxCachePtr entry, SDBCachePtr cache)
{
	time_t now = time(0);

	if ( gConfig.stitcherUpdateOn ) {
		if ( cache->si.sfp == NULL ) {
			/*
			 * If cache->si.sfp is NULL, then it hasn't been opened yet
			 * since rpc.segad started.  Open it for reading, write out 
			 * the  contents to a timestamped file for the stitcher, then 
			 * close it, and re-open it for writing.  This will ensure that
			 * nothing gets lost, and that we start out with a clean stitcher
			 * log file.  
			 */
			cache->si.sfp = fopen(gConfig.stitcherLog, "r");
			if ( cache->si.sfp != NULL ) {
				flush_stitchlog(cache, now);
				fclose(cache->si.sfp);
			}

			cache->si.sfp = fopen(gConfig.stitcherLog, "w");
			if ( cache->si.sfp == NULL ) {
				PLogmsg(LOGP_FLAW, "Error opening %s\n", gConfig.stitcherLog);
				return;
			}

			cache->si.timestamp = now;
			cache->si.items = 0;

			set_buffering(cache);
		}
		else if ( (now - cache->si.timestamp) >= gConfig.stitcherInterval )
			flush_stitchlog(cache, now);

		fprintf(cache->si.sfp, "%ld\n", entry->box->boxAccount.box.box);
		cache->si.items++;

		if ( cache->si.items >= cache->si.max )
			flush_stitchlog(cache, now);
	}
}

static void
flush_stitchlog(SDBCachePtr cache, time_t timestamp)
{
	char buf[MAXPATHLEN];
	struct tm *tm_ptr;
	char date_str[10];
	char time_str[10];

	tm_ptr = localtime(&timestamp);
	strftime(date_str, 10, "%y%m%d", tm_ptr);
	strftime(time_str, 10, "%H%M%S", tm_ptr);

	fclose(cache->si.sfp);
	sprintf(buf,"%s.%s.%s", gConfig.stitcherLog, date_str, time_str);
	rename(gConfig.stitcherLog, buf);

	cache->si.sfp = fopen(gConfig.stitcherLog, "w");
	if ( cache->si.sfp == NULL ) {
		PLogmsg(LOGP_FLAW, "Error opening %s\n", gConfig.stitcherLog);
		return;
	}

	cache->si.timestamp = timestamp;
	cache->si.items = 0;

	set_buffering(cache);
}

static void
allocate_buffer(SDBCachePtr cache)
{
	if ( gConfig.stitcherParanoid )
		cache->si.sbuf = NULL;
	else {
		/*
		 * The stitcher buffer is used to buffer writes to the stitchme file.
		 * It will contain the following info:
		 *
		 * <Box ID> <Player Num>
		 *
		 * Assuming box id's will contain at most 7 digits, and a player num
		 * will be [0123], we need at most 10 bytes per entry.  
		 */
		cache->si.sbuf = (char *) malloc(cache->si.max * 10);
		if ( !cache->si.sbuf ) {
			PLogmsg(LOGP_FLAW, "[Cache_New] malloc failed\n");
			gConfig.stitcherUpdateOn = 0;
		}
	}
}

static void
set_buffering(SDBCachePtr cache)
{
	if ( cache->si.sbuf != NULL ) {
		/*
		 * Fully buffer the file pointer so that writes to it will
		 * only fill the buffer, but won't do any I/O.  However, if 
		 * rpc.segad crashes, we are screwed because it is very likely 
		 * that the stitcher log did not get flushed and that we will 
		 * be missing entries in the file.
		 */
		setvbuf(cache->si.sfp, cache->si.sbuf, _IOFBF, cache->si.max * 10);
	}
	else {
		/*
		 * Totally unbuffer the file pointer so that all writes go to
		 * disk immediately.  This is known as paranoid mode.
		 */
		setvbuf(cache->si.sfp, NULL, _IONBF, 0);
	}
}
