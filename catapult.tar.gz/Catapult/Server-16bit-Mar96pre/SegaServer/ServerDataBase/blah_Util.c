/*
 * Copyright:	 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 *	$Id: DataBase_Util.c,v 1.19 1995/11/13 16:08:28 davej Exp $
 *
 *	$Log: DataBase_Util.c,v $
 * Revision 1.19  1995/11/13  16:08:28  davej
 * New function DataBaseUtil_FreeUCA: you guessed it, to free the UCAAccount.
 *
 * Revision 1.18  1995/11/08  19:01:53  jhsia
 * Deleted a vestigal return (fadden)
 *
 * Revision 1.17  1995/10/03  16:57:40  ted
 * Added snes_MeasureTextBold9Width() function.
 *
 * Revision 1.16  1995/09/27  18:39:33  hufft
 * added Common_Phone support for Japan Server
 *
 * Revision 1.15  1995/09/13  14:15:36  ted
 * Fixed warnings.
 *
 * Revision 1.14  1995/09/02  16:03:02  roxon
 * For single-byte locales, bypass calling mblen() for screen width check
 * in name uniquifier, for better performance.
 *
 * Revision 1.13  1995/08/26  11:24:20  roxon
 * Replace Common_PhoneLocale() with LOCALE_PHONE_xxx().
 *
 * Revision 1.12  1995/08/24  19:32:03  rich
 * DataBaseUtil_MakePhoneNumberUgly() doesn't strip Japanese phone numbers.
 *
 * Revision 1.11  1995/08/02  16:25:56  jhsia
 * Add sjne_MeasureTextWidth() and many type char to u_char
 *
 * Revision 1.10  1995/07/18  14:01:16  steveb
 * Added a free(box->boxAccount->mciPhoneList).  Just doing what I can
 * to avoid leaky mems.
 *
 * Revision 1.9  1995/07/04  22:58:15  fadden
 * Added comment about how to make dbwailonaccount shut up.
 *
 * Revision 1.8  1995/06/19  20:58:19  fadden
 * Sub-dispatched IsHandleWidthLegal.
 *
 * Revision 1.7  1995/06/08  14:10:33  fadden
 * Don't dump core if account==NULL in DataBaseUtil_FreeAccount.
 *
 * Revision 1.6  1995/05/28  20:41:22  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		DataBase_Util.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		 <5>	 12/9/94	JMK		Commented out PARANOID_MODE for production
		 <4>	11/26/94	ATM		Updated font metrics for uniquifier.  These changed back at ROM
									freeze time, but it's taken this long to squeeze the new tables
									out of ChortleBoy. 8-)
		 <3>	11/13/94	ATM		Added MakePhoneNumberUgly to remove the dashes from phone #s.
		 <2>	11/10/94	DJ		Moved IsHandleWidthLegal from Database_UISerAccount.c
		 <1>	 11/9/94	DJ		Utils used by both client and rpc.segad server.  Just renamed
									'em all DataBaseUtil_....

	To Do:
*/

// #define PARANOID_MODE		// remove me soon

#include <stdlib.h>
#include <ctype.h>

#include "ServerDataBase.h"
#include "ServerDataBase_priv.h"

#include "Common.h"
#include "Common_ReadConf.h"
#include "Common_PlatformID.h"
#include "Common_Missing.h"


Boolean DataBaseUtil_CompareUserIdentifications(userIdentification *challengeUserID,
											userIdentification *userID)
{
	if(DataBaseUtil_CompareBoxSerialNumbers(&challengeUserID->box, &userID->box))
		if(challengeUserID->userID == userID->userID)
			return(true);
	return(false);
}


// In proper fucked-up C style, this returns true if they match, false if different.
//
Boolean DataBaseUtil_CompareBoxSerialNumbers(BoxSerialNumber *box1, BoxSerialNumber *box2)
{
	if(box1->box == box2->box && box1->region == box2->region)
		return(true);
	else
		return(false);
}

#ifdef PARANOID_MODE
short Original_CompareStrings( const u_char *cString1, const u_char *cString2 );
short Original_CompareStrings( const u_char *cString1, const u_char *cString2 )
{
u_char	byte1, byte2;

	do
	{
		byte1 = *cString1++;
		byte2 = *cString2++;
		
		//
		// strip out spaces
		//
		while( byte1 == ' ')
			byte1 = *cString1++;
		while( byte2 == ' ')
			byte2 = *cString2++;

#ifdef FOO
		//
		// convert to lower case
		//
		if( (byte1 <= 'Z') && (byte1 >= 'A') )
			byte1 += ('a'-'A');
	
		if( (byte2 <= 'Z') && (byte2 >= 'A') )
			byte2 += ('a'-'A');
#else
		//
		// convert to upper case (most char names are upper)
		//
		if( (byte1 <= 'z') && (byte1 >= 'a') )
			byte1 -= ('a'-'A');
	
		if( (byte2 <= 'z') && (byte2 >= 'a') )
			byte2 -= ('a'-'A');
#endif
		
		//
		// compare
		//
		if( byte1 > byte2 )
			return 1;			//string 1 is after string 2 alphabetically
		if( byte1 < byte2 )
			return -1;			//string 1 is before string 2 alphabetically
	}
	while( byte1 );
	
	return 0;	//they're equal
}
#endif /*PARANOID_MODE*/

// Assume most chars will be upper case.
#define MY_TOUPPER(x) ( ((x) >= 'a' && (x) <= 'z') ? (x)-0x20 : (x) )

//
// This should be faster than the original (without using -O, the code
// for this routine is twice as fast using gcc).
//
// Note that this returns, 0, positive, or negative, NOT 0,1,-1.
//
int DataBaseUtil_CompareStrings(register const u_char *str1, register const u_char *str2)
{
	register int c1, c2;
#ifdef PARANOID_MODE
	int retval;
	u_char *orig_str1 = str1;
	u_char *orig_str2 = str2;
#endif

	str1--, str2--;		// you didn't see that
	do {
		// Assume runs of spaces will be short.
		//
		while ((c1 = *++str1) == ' ')
			;
		while ((c2 = *++str2) == ' ')
			;

		if (MY_TOUPPER(c1) != MY_TOUPPER(c2))
			break;
	} while (c1);

#ifndef PARANOID_MODE
	return (MY_TOUPPER(c1) - MY_TOUPPER(c2));
#else
	retval = MY_TOUPPER(c1) - MY_TOUPPER(c2);
	if (retval > 0) retval = 1;
	if (retval < 0) retval = -1;
	if (retval != Original_CompareStrings(orig_str1, orig_str2)) {
		PLogmsg(LOGP_FLAW, "CompareStrings FAILED\n");
		//Common_Abort();
	}
	return (c1 - c2);
#endif /*PARANOID_MODE*/
}


//
// The PlayerInfo structure has a variable-length component, but is
// allocated all in one piece.
//
void DataBaseUtil_ReleaseServerPlayerInfo(ServerPlayerInfo *splayerInfo)
{
	ASSERT(splayerInfo);
	free(splayerInfo);
}


//
// Free an Account
// Note this is *NOT* RPCed; we have a memory leak in the server.
//
Err DataBaseUtil_FreeAccount(Account *account)
{
	ASSERT(account);
	if (account == NULL) {
		PLogmsg(LOGP_FLAW,
			"ERROR: DataBaseUtil_FreeAccount called with NULL account\n");
		return (kFucked);
	}

	if (account->boxAccount.mciPhoneList != NULL) {
	    free(account->boxAccount.mciPhoneList);
	}

	if (account->boxAccount.opaqueStore.buf != NULL) {
	    free(account->boxAccount.opaqueStore.buf);
	}

	free(account->playerAccount.openTaunt);
	/*free(account->playerAccount.closeTaunt);*/
	free(account->playerAccount.personInfo);
	if (account->playerAccount.customIconSize != 0)
		free(account->playerAccount.customIcon);
	if (account->playerAccount.opaqueStore.buf != NULL) {
	    free(account->playerAccount.opaqueStore.buf);
	}

	free(account);

	return (kNoError);
}

//
// DataBaseUtil_FreeUCA
//
// Free a UCAAccount, including all the UCAInfo's strings.
//
Err DataBaseUtil_FreeUCA(UCAAccount *ucaAccount)
{
	ASSERT(ucaAccount);
	if (ucaAccount == NULL) {
		PLogmsg(LOGP_FLAW,
			"ERROR: DataBaseUtil_FreeUCA called with NULL UCAAccount\n");
		return (kFucked);
	}

	if (ucaAccount->ucaInfo.cc_num != NULL)
		free(ucaAccount->ucaInfo.cc_num);
	if (ucaAccount->ucaInfo.cc_expr != NULL)
		free(ucaAccount->ucaInfo.cc_expr);
	if (ucaAccount->ucaInfo.checkingAccount != NULL)
		free(ucaAccount->ucaInfo.checkingAccount);
	if (ucaAccount->ucaInfo.bankNumber != NULL)
		free(ucaAccount->ucaInfo.bankNumber);
	if (ucaAccount->ucaInfo.prodstr != NULL)
		free(ucaAccount->ucaInfo.prodstr);
	if (ucaAccount->ucaInfo.home_phone != NULL)
		free(ucaAccount->ucaInfo.home_phone);
	if (ucaAccount->ucaInfo.cc_name != NULL)
		free(ucaAccount->ucaInfo.cc_name);
	if (ucaAccount->ucaInfo.address != NULL)
		free(ucaAccount->ucaInfo.address);
	if (ucaAccount->ucaInfo.city != NULL)
		free(ucaAccount->ucaInfo.city);
	if (ucaAccount->ucaInfo.state != NULL)
		free(ucaAccount->ucaInfo.state);
	if (ucaAccount->ucaInfo.zip != NULL)
		free(ucaAccount->ucaInfo.zip);
	if (ucaAccount->ucaInfo.country != NULL)
		free(ucaAccount->ucaInfo.country);
	if (ucaAccount->ucaInfo.access_code != NULL)
		free(ucaAccount->ucaInfo.access_code);
	if (ucaAccount->ucaInfo.comment != NULL)
		free(ucaAccount->ucaInfo.comment);
	free(ucaAccount);

	return (kNoError);
}

// NOT RPCed.
//
Err DataBaseUtil_UpdateUserPhoneNumber(Account *account, const phoneNumber *boxPhoneNumber)
{
	// check that phone numbers match and replace if not.
	//
	if (Common_PhoneCompareNumbers(account->boxAccount.gamePhone.phoneNumber, boxPhoneNumber->phoneNumber) != 0)
	{
		account->boxAccount.gamePhone = *boxPhoneNumber;
		account->boxModified |= kBA_gamePhone;
	}

	return(kNoError);
}


long DataBaseUtil_SizeofMail(const Mail *mail)
{
	// +1 taken care of by message[1]
	return(sizeof(Mail) + strlen(mail->message));
}


void DataBaseUtil_ReleaseServerNewsPage(ServerNewsPage *page)
{
	// nothing to do
}

//
// yerga's width-measurement code
//


/* --- Prototypes --- */

PRIVATE short sega_MeasureTextWidth( u_char *cString );
PRIVATE short snes_MeasureTextWidth( u_char *cString );
PRIVATE short sjne_MeasureTextWidth( u_char *cString );
short snes_MeasureTextBold9Width( u_char *cString );

/* --- Constants & Macros --- */

// Max allowable width of a Sega Handle
#define sega_kMaximumHandleWidth 110
#define snes_kMaximumHandleWidth 81
#define sjne_kMaximumHandleWidth 81

/*
 * Updated Character Widths for XBAND Light 9
 */
static unsigned char sega_xBandLight9Widths[256] = {
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		3, 3, 4, 9, 6, 9, 8, 2,
		4, 4, 6, 6, 3, 4, 3, 5,
		7, 7, 7, 7, 7, 7, 7, 7,
		7, 7, 3, 3, 6, 7, 6, 5,
		9, 8, 6, 7, 7, 6, 6, 7,
		7, 3, 5, 6, 6,10, 7, 8,
		6, 8, 6, 6, 6, 7, 8,10,
		7, 7, 7, 3, 5, 3, 6, 6,
		3, 6, 6, 5, 6, 6, 4, 6,
		6, 4, 4, 5, 4,10, 6, 6,
		6, 6, 4, 5, 5, 6, 6, 10,
		6, 6, 5, 4, 4, 4, 7, 255,

		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
	};

//
// Same thing but for SNES.
//
static unsigned char snes_xBandLight9Widths[256] = {
		255, 1,   2,   3,   4,   5,   6,   7,
		8,   9,  10,  11,  12,  13,  14,  15,
		16, 17,  18,  19,  20,  21,  22,  23,
		24, 25,  26,  27,  28,  29,  30,  31,
		3,   3,   4,   9,   6,   9,   8,   2,
		4,   4,   6,   6,   3,   5,   3,   5,
		7,   7,   7,   7,   7,   7,   7,   7,
		7,   7,   3,   3,   6,   6,   6,   5,
		9,   6,   5,   6,   6,   5,   5,   6,
		6,   3,   4,   5,   5,   8,   6,   8,
		5,   7,   5,   5,   6,   6,   6,   10,
		6,   7,   7,   3,   5,   3,   6,   5,
		3,   5,   5,   4,   5,   5,   4,   5,
		5,   3,   4,   5,   3,   8,   5,   5,
		5,   5,   4,   5,   5,   5,   6,   10,
		6,   6,   5,   4,   4,   4,   7,   255,

		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 5,   255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 5,   255, 255, 6,   255, 255,
		8,   8,   10,  255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		5,   3,   255, 255, 255, 255, 255, 255,
		255, 9,   255, 255, 255, 255, 255, 255,
		7,   8,   5,   5,   3,   3,   255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255,
		6,   255, 255, 255, 255, 255, 255, 255,
		255, 255, 255, 255, 255, 255, 255, 255
	};

static unsigned char snes_xBandBold9Widths[256] = {
		255,   1,   2,   3,   4,   5,   6,   7,  
		  8,   9,  10,  11,  12,  13,  14,  15, 
		 16,  17,  18,  19,  20,  21,  22,  23, 
		 24,  25,  26,  27,  28,  29,  30,  31, 
		  2,   4,   5,   7,   6,   9,   8,   3, 
		  4,   4,   6,   6,   3,   5,   3,   4, 
		  6,   6,   6,   6,   6,   6,   6,   6, 
		  6,   6,   3,   3,   6,   6,   6,   5, 
		  8,   8,   6,   6,   7,   6,   5,   7, 
		  7,   3,   4,   7,   5,   9,   7,   8, 
		  6,   8,   6,   6,   7,   7,   8,  11, 
		  7,   7,   6,   3,   4,   3,   6,   5, 
		  3,   6,   6,   5,   6,   6,   4,   6, 
		  6,   3,   3,   6,   3,   9,   6,   6, 
		  6,   6,   5,   5,   4,   6,   7,   9, 
		  6,   7,   6,   4,   3,   4,   6,   3, 
		255, 255, 255, 255, 255, 255, 255, 255, 
		255, 255, 255, 255, 255, 255, 255, 255, 
		255, 255, 255, 255, 255, 255,   6, 255, 
		255, 255, 255, 255, 255, 255, 255, 255, 
		255, 255,   5, 255, 255,   5, 255, 255, 
		  8,   8,  10, 255, 255, 255, 255, 255, 
		255, 255, 255, 255, 255, 255, 255, 255, 
		255, 255, 255, 255, 255, 255, 255, 255, 
		  5,   4, 255, 255, 255, 255, 255, 255, 
		255,   9, 255, 255, 255, 255, 255, 255, 
		  5,   7,   5,   5,   3,   3, 255, 255, 
		255, 255, 255, 255, 255, 255, 255, 255, 
		255, 255, 255, 255, 255, 255, 255, 255, 
		255, 255, 255, 255, 255, 255, 255, 255, 
		  8, 255, 255, 255, 255, 255, 255, 255, 
		255, 255, 255, 255, 255, 255, 255, 255, 
	};

/* MeasureSegaTextWidth()
 *
 * Returns the on-screen pixel width of a cString when drawn in
 * the XBand Light 9pt font. Returns -1 if the string contains
 * illegal characters.
 */
PRIVATE short
sega_MeasureTextWidth( u_char *cString )
{
u_char *walker = cString;
short result = 0;

	while( *walker )
	{
		if ( (sega_xBandLight9Widths[*walker] == 255) )
				return -1;

		result += sega_xBandLight9Widths[*walker];
		++walker;
	}

	return result;
}

//
// Same thing but for SNES.
//
PRIVATE short
snes_MeasureTextWidth( u_char *cString )
{
u_char *walker = cString;
short result = 0;

	while( *walker )
	{
		if ( (snes_xBandLight9Widths[*walker] == 255) )
				return -1;

		result += snes_xBandLight9Widths[*walker];
		++walker;
	}

	return result;
}

short snes_MeasureTextBold9Width( u_char *cString )
{
u_char *walker = cString;
short result = 0;

	while( *walker )
	{
		if ( (snes_xBandBold9Widths[*walker] == 255) )
				return -1;

		result += snes_xBandBold9Widths[*walker];
		++walker;
	}

	return result;
}

//
// Same thing but for SJNE.
//
static short
sjne_MeasureTextWidth( u_char *cString )
{
u_char *walker = cString;
short result = 0;
int	charlen;

	// if locale is not ja/ko/zh - so it is a single-byte locale
	// This would be much faster by not calling mblen.
	if ( !LOCALE_PHONE_JA() ) {
		while( *walker != NULL ) {
			if ( snes_xBandLight9Widths[*walker] == 255 )
				return -1;
			result += snes_xBandLight9Widths[*walker];
			++walker;
		}
		return result;
	}


	while( *walker != NULL )
	{
	  if ( isascii(*walker) ) {	// (*walker < 0x80) is an ascii char
		if ( snes_xBandLight9Widths[*walker] == 255 )
				return -1;

		result += snes_xBandLight9Widths[*walker];
		++walker;
	  } else {				// is a Japanese character (kana or kaiji)
		// the magic 14 is the Japanese character width on SJNES
		result += 14;			// not consider half size kana here
		charlen = mblen(walker, MB_CUR_MAX);

		// should always be true, otherwise something is wrong
		if ( charlen > 0 )
			// In fact, 2 should be a safe bet for Japanese EUC on Sun
			walker += charlen;
		else
			return -1;
	  }
	}

	return result;
}

PRIVATE Boolean sega_IsHandleWidthLegal(u_char *cString);
PRIVATE Boolean snes_IsHandleWidthLegal(u_char *cString);
PRIVATE Boolean sjne_IsHandleWidthLegal(u_char *cString);
PRIVATE Boolean any_IsHandleWidthLegal(u_char *cString);

/* IsHandleWidthLegal()
 *
 * Returns true if the given cString will fit in the handle field
 * on the Sega
 */
Boolean
IsHandleWidthLegal( u_char *cString, long platformID )
{
	SubDispatcher subDisp[] = {
		{ kPlatformGenesis,	kPlatformGenesisMask,	(INT_FUNC_PTR) sega_IsHandleWidthLegal },
		{ kPlatformSNES,	kPlatformSNESMask,		(INT_FUNC_PTR) snes_IsHandleWidthLegal },
		{ kPlatformSJNES,	kPlatformSJNESMask,		(INT_FUNC_PTR) sjne_IsHandleWidthLegal },
		{ kPlatformAny,     0,                      (INT_FUNC_PTR) any_IsHandleWidthLegal },
		{ 0,				0,						NULL },		// bink!
	};

	return ( (Boolean)(Common_SubDispatch(platformID, subDisp))(cString) );
}

PRIVATE Boolean
sega_IsHandleWidthLegal(u_char *cString)
{
	return (sega_MeasureTextWidth(cString) <= sega_kMaximumHandleWidth);
}

PRIVATE Boolean
snes_IsHandleWidthLegal(u_char *cString)
{
	return (snes_MeasureTextWidth(cString) <= snes_kMaximumHandleWidth);
}

PRIVATE Boolean
sjne_IsHandleWidthLegal(u_char *cString)
{
	return (sjne_MeasureTextWidth(cString) <= sjne_kMaximumHandleWidth);
}

PRIVATE Boolean
any_IsHandleWidthLegal(u_char *cString)
{
	PLogmsg(LOGP_FLAW, "ERROR: IsHandleWidthLegal for unknown platform\n");

	// Just assume it's fine.
	//
	return (true);
}



/*
 * DataBaseUtil_FilterName()
 * 
 * Copy a string, removing all spaces and converting to lowercase.
 */
void DataBaseUtil_FilterName(u_char *in, u_char *out)
{
    while (*in) {
	int c;

	while (*in == ' ')
	    in++;

	c = *in++;
	*out++ = isupper(c) ? tolower(c) : c;
    }
}


/*
 * DataBaseUtil_ScrambleBoxID()
 *
 * Scrambles or descrambles the given box id number.
 */

u_long DataBaseUtil_ScrambleBoxID(u_long num, Boolean descramble)
{
    static u_long map[] = { 2, 6, 4, 0, 5, 7, 3, 1 }, revmap[8], mask[8];
    static int inited;
    u_long i, result;
    
#define SCRAMBLER 0x2a7d975a

    /*
     * one-time setup
     */
    if (!inited) {
	for (i = 0; i < 8; i++) {
	    revmap[map[i]] = i;
	    mask[i] = 0xf << (i * 4);
	}
	inited = 1;
    }

    result = 0;

    if (descramble) {
	/*
	 * to descramble,
	 * xor whole thing with constant
	 * xor low half with high half
	 * move nibble n to nibble revmap[n]
	 */

	num ^= SCRAMBLER;
	num ^= num >> 16;
	for (i = 0; i < 8; i++) {
	    u_int value = (num & mask[i]) >> (i * 4);
	    result |= value << (revmap[i] * 4);
	}
    }
    else {
	
	/*
	 * to scramble,
	 * move nibble n to nibble map[n]
	 * xor low half with high half
	 * xor whole thing with constant
	 */
	
	for (i = 0; i < 8; i++) {
	    u_int value = (num & mask[i]) >> (i * 4);
	    result |= value << (map[i] * 4);
	}
	result ^= result >> 16;
	result ^= SCRAMBLER;
    }

    return result;
}
