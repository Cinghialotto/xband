/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 *	$Id
 *
 *	$Log: Matching_Matching.c,v $
 * Revision 1.3  1995/09/27  18:39:52  hufft
 * added Common_Phone support for Japan Server
 *
 * Revision 1.2  1995/05/28  20:41:25  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Matching_Matching.c

	Contains:	Routines that do the actual matching

	Written by:	Andy McFadden


	Change History (most recent first):

		<16>	10/25/94	ATM		Support for matchOrExpWhen.
		<15>	10/10/94	ATM		Copy rankingInfo out into Matchup.
		<14>	 10/7/94	ATM		Do previous opponent checks with prevOpponent list.
		<13>	 10/6/94	ATM		Tweaked something.
		<12>	 10/4/94	ATM		Prevent specific matches between same box but different player.
		<11>	 10/3/94	ATM		Add oppSpecific to LastMatchup and specificShunt to Matchup.
		<10>	 10/2/94	ATM		Disallow matches with person you played last time.
		 <9>	 9/30/94	ATM		Changed romID to gamePatchVersion.
		 <8>	 9/19/94	ATM		PLogmsg stuff.
		 <7>	 9/12/94	ATM		Use aliasedGameID instead of gameID.
		 <6>	  9/7/94	ATM		Set the magicCookie correctly.
		 <5>	  9/7/94	ATM		Minor tweaks.
		 <4>	  9/6/94	ATM		Fix it in the other place, too.
		 <3>	  9/6/94	ATM		You can specific-match against somebody with a different
									cartridge.  Neat.
		 <2>	  9/6/94	ATM		Add TweakPhoneNumber.  Minor fixes.
		 <1>	  9/6/94	ATM		first checked in

	To Do:
*/


#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>

#include "Matching.h"
#include "Common_Log.h"

// ===========================================================================
//		Prototypes for local routines
// ===========================================================================

int Matching_SpecificToAuto(Contestant *contestant, Matchup *matchup,
	MatchingGameData *mgd, Err reason);
int Matching_Matchup(Contestant *contestant, Contestant *opponent,
	Matchup *matchup, MatchingGameData *mgd);
int Matching_Enqueue(Contestant *contestant, Matchup *matchup,
	MatchingGameData *mgd);
int Matching_AutoMatch_FIFO(Contestant *contestant, Matchup *matchup,
	MatchingGameData *mgd);
int Matching_SetValidFlags(Contestant *contestant, MatchingGameData *mgd,
	Contestant **prevOpponent);


// ===========================================================================
//		Specific matches
// ===========================================================================

//
// Entry point for specific matches.
//
// Puts return value in Matchup.result.
//
int Matching_Specific(Contestant *contestant, Matchup *matchup)
{
	Contestant *opponent;
	MatchingGameData *mgd;

	gRegionGlobals.numSpecificReq++;

	// Should we check DistanceOkay here?  Would require the client to
	// pass in the opponent phone number along with his boxSerialNumber.
	// While this makes it so that he can't end up on a queue for a player
	// he won't connect to, it will screw the guy over if his desired
	// challengee has moved and not yet dialed in with "New Number".

	//
	// Find info for this particular game.
	//
	if ((mgd = Matching_FindGameData(contestant->gameID)) == NULL) {
		PLogmsg(LOGP_FLAW,
			"Can't find game 0x%.8lx in Specific.  Not possible?\n",
			contestant->gameID);
		return (kNoSuchGameID);
	}
	mgd->numRequests++;
	contestant->aliasedGameID = mgd->gameID;

	//
	// Figure out if our opponent is already there.
	//
	opponent = Matching_FindMyChallengee(contestant);

	if (opponent == NULL) {
		// Not there, put me on the queue and wait for him to show up.
		//

		// Fun case: what if he's already been challenged by someone
		// else?  There's really nothing we can do, except tell the
		// user that they won't get matched unless the other guy challenges
		// back.  Question is, is it worth the CPU time to check...?

		Matching_Enqueue(contestant, matchup, mgd);
		return (false);

	} else {
		// We're in business, unless he's trying to challenge someone
		// else, is using a different cartridge, or has acceptChallenges off.
		//
		if (contestant->aliasedGameID != opponent->aliasedGameID) {
			Matching_SpecificToAuto(contestant, matchup, mgd,
				kChallengeeWaitingForDifferentGame);
			return (false);
		}

		if (opponent->challengeFlags == kSpecificChallenge) {
			// Other guy wants to challenge someone specific.  Is it me?
			//
			if (Matching_CompareBoxSerial(&contestant->boxSerialNumber,
					&opponent->oppBoxSerialNumber) &&
				(contestant->oppPlayer == opponent->player))
			{
				// we challenged each other, I dial!
				//
				if (Matching_DistanceOkay(contestant, opponent)) {
					Matching_Matchup(contestant, opponent, matchup, mgd);
					return (true);
				}
				Matching_SpecificToAuto(contestant, matchup, mgd,
					kChallengeeTooFar);
				return (false);
			} else {
				// I want him, he doesn't want me, I go sit on auto-queue
				//
				Matching_SpecificToAuto(contestant, matchup, mgd,
					kChallengeeWaitingForDifferentUser);
				return (false);
			}

		} else if (opponent->challengeFlags == kAcceptChallenges) {
			// Other guy is auto, but willing to accept challenges.  In we go!
			//
			if (Matching_DistanceOkay(contestant, opponent)) {
				Matching_Matchup(contestant, opponent, matchup, mgd);
				return (true);
			}
			Matching_SpecificToAuto(contestant, matchup, mgd, kChallengeeTooFar);
			return (false);
		} else {
			// Other guy is auto-matched and not accepting challenges.  Go
			// sit on auto-queue.
			//
			Matching_SpecificToAuto(contestant, matchup, mgd,
				kChallengeeWaitingForAutoMatch);
			return (false);
		}
	}
}

//
// Take a guy who wanted to do a specific-challenge match and put him
// onto a game wait queue.
//
// We could call the auto-match handler, but if we do then he won't have
// a chance to see the dialog we sent him explaining why he got matched
// to someone else.  In some cases (notably when the opponent is online
// but not accepting challenges), this sucks.
//
// (Waiting for KON to give us non-deferred dialogs?)
//
int
Matching_SpecificToAuto(Contestant *contestant, Matchup *matchup,
	MatchingGameData *mgd, Err reason)
{
	Logmsg("Moving %ld from specific to 0x%.8lx queue, reason=%ld\n",
		contestant->contestantID, contestant->gameID, reason);

	matchup->specificShunt = reason;
	// acceptChallenges probably ought to get set to the player default value,
	// but since he was trying to challenge I'm going to assume that he's
	// willing to accept one.  Will probably have to fix this later.
	//
	contestant->challengeFlags = kAcceptChallenges;
	// His oppPlayer stuff no longer refers to his requested challengee.
	// (We used to have to erase this, but now we don't.)
	//
	//contestant->oppBoxSerialNumber.box = -1;
	//contestant->oppBoxSerialNumber.region = -1;
	//contestant->oppPlayer = -1;

	// (Change this to an auto-match handler if we get the dialogs working.)
	//
	Matching_Enqueue(contestant, matchup, mgd);
	return (true);
}


// ===========================================================================
//		Auto-matches
// ===========================================================================

//
// Entry point for auto-matches.
//
// Puts return value in Matchup.result.
//
int Matching_AutoMatch(Contestant *contestant, Matchup *matchup)
{
	Contestant *opponent;
	MatchingGameData *mgd;

	gRegionGlobals.numAutoReq++;

	//
	// Find info for this particular game.
	//
	if ((mgd = Matching_FindGameData(contestant->gameID)) == NULL) {
		PLogmsg(LOGP_FLAW,
			"Can't find game 0x%.8lx in AutoMatch.  Not possible?\n",
			contestant->gameID);
		return (kNoSuchGameID);
	}
	mgd->numRequests++;
	contestant->aliasedGameID = mgd->gameID;

	//
	// First, check the challengeFlags and look for challenges.
	//
	if (contestant->challengeFlags == kAcceptChallenges) {
		opponent = Matching_FindMyChallenger(contestant);

		if (opponent != NULL) {
			// Somebody wants me!  Make sure they're playing the same
			// game, and are within calling range.
			//
			if (contestant->aliasedGameID == opponent->aliasedGameID) {
				if (Matching_DistanceOkay(contestant, opponent)) {
					Matching_Matchup(contestant, opponent, matchup, mgd);
					return (true);
				}
			}
			// We've rejected the challenger, who will eventually time out.
			Logmsg("NOTE: challenge %ld-->%ld ignored because LD call\n",
				opponent->contestantID, contestant->contestantID);
		}

		// no challengers, continue on...
	}

	//
	// If the game queue is empty, we have few options.
	//
	if (NumListNodesInList(mgd->gameQueue) == 0) {
		Matching_Enqueue(contestant, matchup, mgd);
		return (false);
	}

	//
	// What happens next is policy-dependent, so call a subroutine that
	// implements a particular matching policy.
	//
	return (Matching_AutoMatch_FIFO(contestant, matchup, mgd));
}

//
// Very simple matching policy: match the newcomer with the first
// person he can legally play against.
//
int Matching_AutoMatch_FIFO(Contestant *contestant, Matchup *matchup,
	MatchingGameData *mgd)
{
	Contestant *prevOpponent, *qcon;
	ListNode *lnode;

	if (Matching_SetValidFlags(contestant, mgd, &prevOpponent) == false)
		return (false);

#ifdef MATCH_WITH_PREVIOUS
	// For this simple policy, it's okay to match with your previous opponent.
	//
	if (prevOpponent) {
		PLogmsg(LOGP_DBUG, "Found previous opponent on list; marking valid\n");
		prevOpponent->flags = kMatchValid;
	}
#else
	if (prevOpponent) {
		PLogmsg(LOGP_DBUG, "Found previous opponent on list, will not match\n");
	}
#endif

	// Find the first guy with the "valid" flag set.
	//
	for (lnode = GetFirstListNode(mgd->gameQueue); lnode != NULL; \
		lnode = GetNextListNode(lnode))
	{
		qcon = (Contestant *)GetListNodeData(lnode);
		if (qcon == NULL) {
			// SetValidFlags should've already verified this!
			PLogmsg(LOGP_FLAW, "ERROR: null list data, I give up\n");
			Matching_Abort();
			return (false);
		}

		if (qcon->flags == kMatchInvalid)
			continue;

		// Gotcha.
		//
		Matching_Matchup(contestant, qcon, matchup, mgd);
		return (true);
	}

	// Nobody to play, queue him.
	//
	Matching_Enqueue(contestant, matchup, mgd);
	return (true);
}


// ===========================================================================
//		Utility routines
// ===========================================================================

//
// Initialize the "flags" field in the queued Contestants for the game queue.
//
// If, for the specified contestant, the queued guy is:
//	- in a valid calling range
//	- not the last person this guy played
//	- (whatever else I can think of)
// then mark the entry as "valid".  Otherwise, mark it as "invalid".
//
// We could do this by juggling lists, which might make a later operation
// faster, but malloc() and memcpy() calls should be avoided whenever
// possible, and shuffling list nodes around will not be very cheap.
//
// If the previous opponent *is* found, then we set a pointer to him.  Some
// strategies may want to match previous fighters if the queued one has
// been on for a while.
//
// There is no reason to call this routine for a challenge request.
//
int Matching_SetValidFlags(Contestant *contestant, MatchingGameData *mgd,
	Contestant **prevOpponent)
{
	ListNode *lnode;
	Contestant *qcon;
	int i;

	*prevOpponent = NULL;

	if (contestant->challengeFlags == kSpecificChallenge) {
		PLogmsg(LOGP_FLAW, "Why are you calling Matching_SetValidFlags?\n");
		Matching_Abort();
		return (false);
	}
	if (mgd->gameQueue == NULL) {
		PLogmsg(LOGP_FLAW, "In SVF with an invalid gameQueue for 0x%.8lx\n",
			mgd->gameID);
		Matching_Abort();
		return (false);
	}

	// Run through every contestant on the game queue.
	//
retry:
	for (lnode = GetFirstListNode(mgd->gameQueue); lnode != NULL; \
		lnode = GetNextListNode(lnode))
	{
		qcon = (Contestant *)GetListNodeData(lnode);
		if (qcon == NULL) {
			PLogmsg(LOGP_FLAW, "No data associated with a queued node!\n");
			Matching_Abort();
			// try to recover
			if (RemoveListNodeFromList(lnode) != kNoError)
				return (false);
			if (DisposeListNode(lnode) != kNoError)
				return (false);
			goto retry;
		}

		qcon->flags = kMatchValid;		// everybody starts out this way

		// If his game patch version is different, the game isn't going
		// to work very well.
		//
		if (qcon->gamePatchVersion != contestant->gamePatchVersion) {
			qcon->flags = kMatchInvalid;
			continue;
		}

		// If he can't call long distance, then remove anyone who is too far.
		//
		if (!contestant->callLongDistance) {
			// Doing a full LATA lookup against every queued player will
			// probably suck.  Assume Matching_DistanceOkay() operates
			// in an efficient manner.
			if (!Matching_DistanceOkay(contestant, qcon)) {
				qcon->flags = kMatchInvalid;
				continue;
			}
		}

		// If we haven't found a previous opponent yet, check if this is it.
		// For auto-requests, the previous opponent gets passed in via
		// the "opp" fields in Contestant.
		//
		// Whether or not it makes sense to compare the player number too
		// needs to be determined.  Could be the guy's brother, could be
		// the same guy with a different persona.
		//
		// BRAIN DAMAGE: this was only set up to find *one* previous
		// opponent.  The thing we pass back in prevOpponent is therefore
		// rather meaningless... what matters is we nuke the flags.
		//
		// BRAIN DAMAGE: we need to check to see if *I* am one of *his* last
		// opponents as well.
		//

		for (i = 0; i < kMaxPreviousOpponent; i++) {
			if (!contestant->prevOpponent[i].when)
				continue;
			if (Matching_CompareBoxSerial(
					&(contestant->prevOpponent[i].oppBoxSerialNumber),
					&qcon->boxSerialNumber) &&
				contestant->prevOpponent[i].oppPlayer == qcon->player)
			{
				*prevOpponent = qcon;
				qcon->flags = kMatchInvalid;
				break;
			}
		}

		// Looks like this one was valid.  Keep going...
	}

	return (true);
}

//
// Put this player on the appropriate queues.
//
int Matching_Enqueue(Contestant *contestant, Matchup *matchup,
	MatchingGameData *mgd)
{
	time_t now = time(0);

	Logmsg("ENQUEUE: %ld (%s) for %s",
		contestant->contestantID, contestant->userName,
		mgd->gameInfo->gameName);
	if (contestant->challengeFlags == kSpecificChallenge) {
		Logmsg(" (spec for (%ld,%ld)[%ld])\n",
			contestant->oppBoxSerialNumber.box,
			contestant->oppBoxSerialNumber.region,
			contestant->oppPlayer);
		matchup->matchOrExpWhen = now + kMaxTimeInSpecificQueue;
	} else {
		Logmsg(" (auto queue size %ld)\n",
			NumListNodesInList(mgd->gameQueue));
		matchup->matchOrExpWhen = now + kMaxTimeInWaitQueue;
	}

	// Fill out the queue-related fields in the "Contestant" structure.
	//
	contestant->queuedWhen = now;
	//matchup->result = kOpponentNotRegistered;		// should we do this?
	matchup->result = kMatchWait;
	matchup->magicCookie = contestant->contestantID;

	// Add to queues.
	//
	Matching_AddToQueues(contestant, mgd);

	// (contestant is now INVALID; the copy on the queue is now the real one)

	// Update the global "queue" statistics.
	//
	gRegionGlobals.numEnqueued++;

	return (true);
}


//
// Match two people together.  This is called for the person who will dial.
//
// (The MatchingGameData is only passed in to update the success statistics.)
//
int Matching_Matchup(Contestant *contestant, Contestant *opponent,
	Matchup *matchup, MatchingGameData *mgd)
{
	if (contestant == NULL || opponent == NULL || matchup == NULL || mgd == NULL) {
		PLogmsg(LOGP_FLAW, "NULL args to Matching_Matchup, bailing.\n");
		Matching_Abort();
		return (false);
	}

	// Fill out the Matchup structure.
	//
	matchup->result = kMatchDial;
	matchup->magicCookie = contestant->contestantID;
	matchup->matchOrExpWhen = time(0);

	matchup->oppMagicCookie = opponent->contestantID;
	matchup->oppBoxSerialNumber = opponent->boxSerialNumber;
	matchup->oppPlayer = opponent->player;
	matchup->oppSpecific = (opponent->challengeFlags == kSpecificChallenge);
	matchup->oppPhoneNumber = opponent->boxPhoneNumber;
	Common_PhoneTweakOpponentNumber(&matchup->oppPhoneNumber,
		&contestant->boxPhoneNumber);		// remove the area code, if local
	strcpy(matchup->oppUserName, opponent->userName);
	matchup->oppRankingInfo = opponent->rankingInfo;

	// Pull the opponent out of the queue.
	//
	Matching_DequeueForMatch(opponent, mgd);

	// Update the game "success" statistics.
	//
	mgd->numSuccesses += 2;							// both: succeeded

	Logmsg("MATCH: %ld (%s) with %ld (%s)",
		contestant->contestantID, contestant->userName,
		opponent->contestantID, opponent->userName);

	switch (contestant->challengeFlags) {
	case kIgnoreChallenges:							// both: successful auto
		gRegionGlobals.numAutoSuc += 2;
		Logmsg(" auto/auto");
		break;

	case kAcceptChallenges:
		gRegionGlobals.numAutoSuc++;				// me: successful auto

		switch (opponent->challengeFlags) {
		case kIgnoreChallenges:
		case kAcceptChallenges:
			gRegionGlobals.numAutoSuc++;			// him: successful auto
			Logmsg(" auto/auto");
			break;
		case kSpecificChallenge:
			gRegionGlobals.numAutoSpecificSuc++;	// him: successful specific
			Logmsg(" auto/spec");
			break;
		}
		break;

	case kSpecificChallenge:
		switch (opponent->challengeFlags) {
		case kIgnoreChallenges:
			// this should be impossible
			PLogmsg(LOGP_FLAW, "Ignore is impossible!\n");
			break;
		case kAcceptChallenges:
			gRegionGlobals.numAutoSpecificSuc++;	// me: successful specific
			gRegionGlobals.numAutoSuc++;			// him: successful auto
			Logmsg(" spec/auto");
			break;
		case kSpecificChallenge:
			gRegionGlobals.numSpecificSuc += 2;		// both: successful specific
			Logmsg(" spec/spec");
			break;
		}
		break;

	default:
		PLogmsg(LOGP_FLAW, " - Bogus challengeFlags %ld in Matchup!\n",
			contestant->challengeFlags);
		break;
	}
	Logmsg("\n");

	// should update numLongDistance somehow

	return (true);
}


