/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: DataBase_Core.c,v 1.67 1996/03/01 00:52:42 chs Exp $
 *
 * $Log: DataBase_Core.c,v $
 * Revision 1.67  1996/03/01  00:52:42  chs
 * log more info when we fail reading or writing the db.
 *
 * Revision 1.66  1996/01/10  14:50:15  hufft
 * use libphonedb
 *
 * Revision 1.65  1996/01/04  22:55:57  hufft
 * added pop mail
 *
 * Revision 1.64  1995/12/06  00:42:12  steveb
 * Ported to Solaris 2.4 (STDC && SVR4).
 *
 * Revision 1.63  1995/11/30  15:59:59  ansell
 * Tookover gamePlatform for failed800PopConnects.
 *
 * Revision 1.62  1995/11/14  20:28:55  hufft
 * rename DataBase_LoadCompuServePops to PhoneDB_Load
 *
 * Revision 1.61  1995/11/13  15:57:02  davej
 * Added fields for ECP support: checkingAccount, bankNumber, datePreNoteSent.
 * File version now at 42.
 *
 * Revision 1.60  1995/11/07  16:33:46  steveb
 * Renamed boxAccount->eid to boxAccount->prevSmartCardSerialNumber.  File
 * version is now 41.
 *
 * Revision 1.59  1995/10/23  17:39:37  davej
 * Backed out previous changes for ECP DB fields.
 *
 * Revision 1.58  1995/10/23  16:44:53  davej
 * Added code to support three new DB fields in UCAInfo (checkingAccount,
 * bankNumber, datePreNoteSent); bumped file_version from 40 to 41.
 *
 * Revision 1.57  1995/09/27  18:38:47  hufft
 * added Common_Phone support for Japan Server
 *
 * Revision 1.56  1995/09/24  14:05:19  steveb
 * Added XBNUsage struct to BoxAccount.
 *
 * Revision 1.55  1995/09/13  14:15:23  ted
 * Fixed warnings.
 *
 * Revision 1.54  1995/08/21  17:11:40  steveb
 * Re-enabled unlinking the backup file created on box writes.  This was
 * inadvertently left off from my performance testing version of rpc.segad
 *
 * Revision 1.53  1995/08/21  13:02:34  steveb
 * Caching rpc.segad re-checkin.
 *
 * Revision 1.52  1995/08/15  18:47:28  steveb
 * Revert to Revision 1.50
 *
 * Revision 1.51  1995/08/11  17:39:42  steveb
 * Caching rpc.segad checkin.  Changes too numerous to mention.
 *
 * Revision 1.50  1995/08/11  16:12:20  fadden
 * Renamed a couple of fields in CordPullData.
 *
 * Revision 1.49  1995/08/08  16:36:04  steveb
 * Added some new fields to the DB to support cord pull stats.  File version
 * is now 39.
 *
 * Revision 1.48  1995/08/07  21:50:08  fadden
 * Renamed ngpVersion to cordPullData.  No real change in the structure.
 *
 * Revision 1.47  1995/08/04  16:51:57  chs
 * Log memory usage at shutdown.
 *
 * Revision 1.46  1995/07/26  14:05:11  ansell
 * Renamed failedServerConnects to totalServerConnects.
 *
 * Revision 1.45  1995/07/21  21:33:11  fadden
 * Fixed a logmsg.
 *
 * Revision 1.44  1995/07/21  18:19:21  ted
 * Changed hasMailFlags account field to modemVersion.
 *
 * Revision 1.43  1995/07/18  13:56:17  fadden
 * Fixed a fucker when upgrading from v37 to v38.
 *
 * Revision 1.42  1995/07/17  21:47:07  steveb
 * Added new database fields:
 * 	char *BoxAccount.mciPhoneList
 * 	unsigned long BoxAccount.eid - this used to be osVersion
 * 	unsigned long PlayerAccount.lastPersonInfoChange
 * 	unsigned long PlayerAccount.lastAddrBookCheck
 * File version is now 38
 *
 * Revision 1.41  1995/07/05  16:38:07  chs
 * Sort mail by serialnumber again.
 *
 * Revision 1.40  1995/07/04  22:54:59  fadden
 * Added comments about a nasty failure mode.
 *
 * Revision 1.39  1995/06/19  22:11:32  chs
 * Revert to previous version.
 *
 * Revision 1.38  1995/06/12  17:37:24  chs
 * Sort mail by serial number instead of the bogus timestamp.
 *
 * Revision 1.37  1995/06/02  20:58:47  fadden
 * Added several different fields to database (notably hardwareID and other
 * restore-related stuff).  Version now 37.
 *
 * Revision 1.36  1995/05/28  20:41:00  jhsia
 * switch to rcs keywords
 *
 */

#include <string.h>
#include <memory.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#define __DataBase_Core__

#include "ServerDataBase_priv.h"
#include "Errors.h"

#include "Common.h"
#include "Common_Log.h"
#include "Common_ReadConf.h"
#include "Common_PlatformID.h"
#include "Common_Missing.h"

#include "DataBase_Cache.h"

#define kSaveFileVersion	42			// increment this when things change
#define kProgressInterval	500

static long gDebugCount;

/*==========================================================================*\
	Globals
\*==========================================================================*/
SDB *gSDB;

// This gets set by premain().  Eventually this should get passed in
// as an argument.  Of course, eventually the CheeseDB should be
// gone entirely...
char *gRestoreFile = NULL;
Boolean gReadRestoreFile = false;
static int gCookieFd = -1;
static unsigned long gCookie = -1;
#define kDefaultInitCookieJump 2000

/* XXX */
Err OSDB_Save(FILE *fp);
Err OSDBBox_Write(SDBBox *box, FILE *fp);
void DataBase_OpenCookieFile(void);
PRIVATE int DataBase_CheckPW(long boxType, Password password);

Err ServerDataBase_Initialize(void)
{
	FILE	*fp;
	Err		result;
	char	c, *filename;
	int		backup = false;
	DIR		*dirp;
	char		dirname[256];
	int		boxdirnum;


	if(!SDB_New())
		return(kOutOfMemoryErr);

	SDBSystem_LoadSystemPatches();
	
	// Restore database from disk.  As of 94/11/14, it's impossible for
	// gRestoreFile to be == NULL.
	//
	result = kNoError-1;		// just make it != kNoError
	if (gRestoreFile == NULL)
		filename = kSDBFILE;
	else
		filename = gRestoreFile;
	fp = fopen(filename, "r");

	Logmsg("Restore file is '%s' (open %s)\n", filename,
		(fp == NULL) ? "FAILED" : "succeeded");

	//
	// If you specified a restore file and we could not open it, exit the
	// server.  The intelligence for figuring out which restore file is
	// valid resides in "start".
	//
	if(gReadRestoreFile && gRestoreFile && !fp)
	{
		Logmsg("Restore file failed.  Server exiting.\n");
		exit(-1);
	}

	// Check for presence of database directory and create it if not found
	sprintf(dirname, "ServerDB.dir.%ld", gConfig.happyRegion);
	if ((dirp = opendir(dirname)) == NULL) {
		if (errno == ENOENT) {
			if (mkdir(dirname, 0777) < 0) {
				Logmsg("FATAL: Failed to create database directory %s\n", dirname);
				exit(-1);
			}
		}
		else {
			Logmsg("Database restore failed.  Server exiting.\n");
			exit(-1);
		}
	}
	else {
		closedir(dirp);
	}

	/*
	 * Now, create 100 subdirs (each will hold 1024 box.XXXXX files).
	 */
	for(boxdirnum = 0; boxdirnum < 100; boxdirnum++)
	{
		sprintf(dirname, "ServerDB.dir.%ld/boxdir.%05d", gConfig.happyRegion, boxdirnum);
		if ((dirp = opendir(dirname)) == NULL) {
			if (errno == ENOENT) {
				if (mkdir(dirname, 0777) < 0) {
					Logmsg("FATAL: Failed to create boxdatabase directory %s\n", dirname);
					exit(-1);
				}
			}
			else {
				Logmsg("Database restore failed.  Server exiting.\n");
				exit(-1);
			}
		}
		else {
			closedir(dirp);
		}
	}


	// If the name of the server file ends in 'A', 'B', ... then we assume
	// it was a database backup file.  We need to know this so that future
	// saves go to the basename, not the name with 'A' on the end.  Also,
	// we may have created an account right at the end of the previous file,
	// so we need to skip over one just in case.
	//
	c = filename[strlen(filename)-1];
	if (c >= 'A' && c <= 'Z') {
		PLogmsg(LOGP_NOTICE, "*** NOTE: restore is from a backup\n");
		backup = true;
	}

	if(fp)
	{
		result = SDB_Restore(fp, backup);
		fclose(fp);
	}
	if (result == kNoError) {
		PLogmsg(LOGP_NOTICE, "DB was restored\n");
		Statusmsg("segad  : RESTART (DB restored)\n");
	} else {
		// This is probably a bad thing to do on the production server.
		// If the disk ran out of space, the write of the tiny header would
		// have failed, and when we restarted we'd end up in this state.
		//
		// Probably want to check for a zero-length file in the "start"
		// script.
		//
		PLogmsg(LOGP_NOTICE, "DB was NOT restored\n");
		Statusmsg("segad  : RESTART (DB cleared)\n");

		/*
		 * Check if the cache pointer was created.  If not, do it now
		 * because this might be a test server starting from a zero
		 * sized restore file.  Set file version to kSaveFileVersion.
		 */
		if ( !gCache ) {
			gCache = Cache_New(kSaveFileVersion, 
				P_ReadBox, P_WriteBox, P_FreeBox);
		}
	}
	
	// load game patches
	DataBase_LoadGamePatches();

	// read broadcast mail in
	result = DataBase_LoadBroadcastMail();

	// read news in
	result = DataBase_LoadNewsPages();

	// read the Compuserver POP database
	result = PhoneDB_Load();

	// read cookie file value
	DataBase_OpenCookieFile();

	return(kNoError);
}

/*==========================================================================*\
	ServerDataBase_Shutdown
\*==========================================================================*/
Err ServerDataBase_Shutdown(void)
{
Err	err;

	ASSERT(gSDB);

	ServerDataBase_SaveToDisk();
	ServerDataBase_SaveToDiskTmp();

	err = SDB_Dispose(gSDB);
	if(err != kNoError)
		return(err);

	gSDB = NULL;
		
	Statusmsg("segad  : SHUTDOWN (DB saved to disk)\n");

	Logmsg("memory usage at shutdown = %dM\n", (int)sbrk(0) / (1024*1024));
	//return(kNoError);
	exit(0);
}


/*==========================================================================*\
	DataBase_GetHighestBox
\*==========================================================================*/
long DataBase_GetHighestBox(region)
int region;
{
   ASSERT(gSDB);

   ASSERT(region==gConfig.happyRegion); /* for now... */

   return(gSDB->users->uniqueBoxSerialNumber);
}

unsigned long DataBase_GetConnectCookie(void)
{
	long n;

	errno = 0;
	lseek(gCookieFd,0L,SEEK_SET);
	n = write(gCookieFd,(char *)&gCookie,sizeof(gCookie));
	if (n != sizeof(gCookie))
	{
		PLogmsg(LOGP_FLAW,"Error (%d) writing next cookie value\n", errno);
	}
	gCookie++;
	return gCookie;
}

void DataBase_OpenCookieFile(void)
{
	long n;
	
	errno = 0;
	gCookieFd = open(kSDB_CookieFile, O_RDWR|O_CREAT, 0644);
	if (gCookieFd < 0)
	{
		PLogmsg(LOGP_FLAW,"Error (%d) opening CookieFile. Exiting.\n", errno);
		exit(-1);
	}
	n = read(gCookieFd,(char *)&gCookie,sizeof(gCookie));
	if (n != sizeof(gCookie))
	{
		if (n == -1)
		{
			PLogmsg(LOGP_FLAW,"Error (%d) reading CookieFile\n", errno);
			exit(-1);
		}
		else
		{
			gCookie = 0;
			n = write(gCookieFd,(char *)&gCookie,sizeof(gCookie));
			if (n != sizeof(gCookie))
			{
				PLogmsg(LOGP_FLAW,"Error (%d) writing initial cookie value\n", errno);
				exit(-1);
			}
		}
	}
	gCookie += kDefaultInitCookieJump;
	PLogmsg(LOGP_FLAW,"Cookie file read successfully. First cookie = %lu\n", gCookie);
}

/*==========================================================================*\
	ServerDataBase_SaveToDisk - used for checkpointing only
\*==========================================================================*/
void ServerDataBase_SaveToDisk(void)
{
	FILE	*fp;
	char	c, saveName[1024], rensrc[1024], rendst[1024];
	int	err;

	ASSERT(gSDB);

	if (gSDB == NULL) {
		PLogmsg(LOGP_NOTICE, "NOTE: no gSDB, no database save\n");
		return;
	}

	// Rotate the log files.  If we restored from a backup, need to strip
	// the extra character off the end before rotating.
	//
	strcpy(saveName, gRestoreFile);
	c = saveName[strlen(saveName)-1];
	if (c >= 'A' && c <= 'Z') {
		saveName[strlen(saveName)-1] = '\0';
	}
	strcat(saveName, ".ckp");

	// First A --> B.
	//
	strcpy(rensrc, saveName);
	strcat(rensrc, "A");
	strcpy(rendst, saveName);
	strcat(rendst, "B");
	rename(rensrc, rendst);

	// Next blank --> A.
	//
	strcpy(rensrc, saveName);
	strcpy(rendst, saveName);
	strcat(rendst, "A");
	rename(rensrc, rendst);

	// Now we create a new blank.  We hope.
	//
	fp = fopen(saveName, "wb");
	if ((fp != NULL) && (OSDB_Save(fp) == kNoError)) {
		fclose(fp);
		Logmsg("Successful database checkpoint to '%s'\n", saveName);
	} else {
		err = errno;
		fclose(fp);
		fp = fopen("/var/catapult/ServerDB.PANIC.CKP", "w");
		if (fp != NULL)
			OSDB_Save(fp);
		fclose(fp);
		fp = fopen("/tmp/ServerDB.PANIC.CKP", "w");
		if (fp != NULL)
			OSDB_Save(fp);
		fclose(fp);
		PLogmsg(LOGP_FLAW, "*** ALERT: DATABASE CHECKPOINT PANIC SAVE (%d) (aborting)\n",
			err);
		Common_Abort();
	}
}

/*==========================================================================*\
	ServerDataBase_SaveToDisk
\*==========================================================================*/
void ServerDataBase_SaveToDiskTmp(void)
{
	FILE	*fp;
	char	c, saveName[1024], rensrc[1024], rendst[1024];
	int	err;

	ASSERT(gSDB);

	if (gSDB == NULL) {
		PLogmsg(LOGP_NOTICE, "NOTE: no gSDB, no database save\n");
		return;
	}

	// Rotate the log files.  If we restored from a backup, need to strip
	// the extra character off the end before rotating.
	//
	strcpy(saveName, gRestoreFile);
	c = saveName[strlen(saveName)-1];
	if (c >= 'A' && c <= 'Z') {
		saveName[strlen(saveName)-1] = '\0';
	}

	// First A --> B.
	//
	strcpy(rensrc, saveName);
	strcat(rensrc, "A");
	strcpy(rendst, saveName);
	strcat(rendst, "B");
	rename(rensrc, rendst);

	// Next blank --> A.
	//
	strcpy(rensrc, saveName);
	strcpy(rendst, saveName);
	strcat(rendst, "A");
	rename(rensrc, rendst);

	// Now we create a new blank.  We hope.
	//
	fp = fopen(saveName, "wb");
	if ((fp != NULL) && (SDB_Save(fp) == kNoError)) {
		fclose(fp);
		Logmsg("Successful database header write to '%s'\n", saveName);
	} else {
		err = errno;
		fclose(fp);
		fp = fopen("/var/catapult/ServerDB.PANIC", "wb");
		if (fp != NULL)
			SDB_Save(fp);
		fclose(fp);
		fp = fopen("/tmp/ServerDB.PANIC", "wb");
		if (fp != NULL)
			SDB_Save(fp);
		fclose(fp);
		PLogmsg(LOGP_FLAW, "*** ALERT: DATABASE HEADER PANIC SAVE (%d) (aborting)\n",
			err);
		Common_Abort();
	}
}

/*==========================================================================*\
	SDB_New
\*==========================================================================*/
SDB *SDB_New(void)
{
	gSDB = (SDB *)malloc(sizeof(SDB));
	
	if(!gSDB){
		ERROR_MESG("out of mems allocating database\n");
		return(NULL);
	}
	
	gSDB->system = SDBSystem_New();
	//gSDB->ngp = SDBNGP_New();
	gSDB->games = SDBGames_New();
	gSDB->users = SDBUsers_New();
	gSDB->news = SDBNews_New();

	gSDB->broadcastMail = NewSortedList();

	return(gSDB);
}

/*==========================================================================*\
	SDB_Dispose
\*==========================================================================*/
Err SDB_Dispose(SDB *sdb)
{
	// Delete everything....
	// BRAIN DAMAGE.. haven't written dispose yet....

	return(kNoError);
}

/*==========================================================================*\
	SDB_GetSystem
\*==========================================================================*/
SDBSystem *SDB_GetSystem(SDB *sdb)
{
	ASSERT(sdb);
	return(sdb->system);
}

/*==========================================================================*\
	SDB_GetUsers
\*==========================================================================*/
SDBUsers *SDB_GetUsers(SDB *sdb)
{
	ASSERT(sdb);
	return(sdb->users);
}

#ifdef OBSOLETE
/*==========================================================================*\
	SDB_GetNGP
\*==========================================================================*/
SDBNGP *SDB_GetNGP(SDB *sdb)
{
	ASSERT(sdb);
	return(sdb->ngp);
}
#endif

/*==========================================================================*\
	SDB_GetGames
\*==========================================================================*/
SDBGames *SDB_GetGames(SDB *sdb)
{
	ASSERT(sdb);
	return(sdb->games);
}

/*==========================================================================*\
	SDB_GetNews
\*==========================================================================*/
SDBNews *SDB_GetNews(SDB *sdb)
{
	ASSERT(sdb);
	return(sdb->news);
}

// fwrite() a simple type with size=1 and nitems=sizeof(item) to "fp",
// then verify that the bytes were written.
#define ASSERT_FWRITE_ELEM(_item) { \
		long _len = fwrite(&(_item), 1, sizeof(_item), fp); \
		ASSERT(_len == sizeof(_item)); \
		if (_len != sizeof(_item)) { \
			PLogmsg(LOGP_FLAW, "ASSERT failed: ferror = %d, feof = %d\n", \
					ferror(fp), feof(fp)); \
			return (kUnexpectedEOF); \
		} \
	}

static long gDebugCount;

/*==========================================================================*\
	SDB_Save
\*==========================================================================*/
Err SDB_Save(FILE *fp)
{
long		count;
long		tmpl;

	// Write a human-readable header.  To identify partially written files,
	// we initially write it as being bad, and then later we mark it as
	// good.
	//
	// To make sure we don't get out of sync, we always start the "real" stuff
	// at byte 32.  Throw in some spaces to make it look pretty for the
	// viewers at home.
	//
	fprintf(fp, "BAD!\n");
	fprintf(fp, "%lu\n", time(0));
	fprintf(fp, "                            ");
	fseek(fp, 32L, 0);

	//  write a header.
	tmpl = kSDBNewerSaveFormat;
	ASSERT_FWRITE_ELEM(tmpl);
	tmpl = kSaveFileVersion;
	ASSERT_FWRITE_ELEM(tmpl);
	tmpl = gConfig.happyRegion;
	ASSERT_FWRITE_ELEM(tmpl);

	// skip the NGP stuff, the game info, and the broadcast mail

	// dump the SDBUsers stuff out to a file
	ASSERT_FWRITE_ELEM(gSDB->users->timeStamp);
	ASSERT_FWRITE_ELEM(gSDB->users->uniqueBoxSerialNumber);
	ASSERT_FWRITE_ELEM(gSDB->users->numUsers);

	// count up and write out the list of SDBBox structs
	count = Database_CountBoxes(gSDB);
	ASSERT_FWRITE_ELEM(count);

	rewind(fp);
	fprintf(fp, "GOOD\n");
	fflush(fp);
	fsync(fileno(fp));		// sync() returns without waiting, fsync() doesn't
	
	return (kNoError);
}

/*==========================================================================*\
	OSDB_Save
\*==========================================================================*/
Err
OSDB_Save(FILE *fp)
{
	time_t save_begin;
	long count;
	long tmpl;

	// Write a human-readable header.  To identify partially written files,
	// we initially write it as being bad, and then later we mark it as
	// good.
	//
	// To make sure we don't get out of sync, we always start the "real" stuff
	// at byte 32.  Throw in some spaces to make it look pretty for the
	// viewers at home.
	//
	fprintf(fp, "BAD!\n");
	fprintf(fp, "%lu\n", time(0));
	fprintf(fp, "                            ");
	fseek(fp, 32L, 0);

	//  write a header.
	tmpl = kSDBNewSaveFormat;
	ASSERT_FWRITE_ELEM(tmpl);
	tmpl = kSaveFileVersion;
	ASSERT_FWRITE_ELEM(tmpl);
	tmpl = gConfig.happyRegion;
	ASSERT_FWRITE_ELEM(tmpl);

	//
	// Dump the contents of the server DB to a file.
	//

	// skip the NGP stuff, the game info, and the broadcast mail

	// dump the SDBUsers stuff out to a file
	ASSERT_FWRITE_ELEM(gSDB->users->timeStamp);
	ASSERT_FWRITE_ELEM(gSDB->users->uniqueBoxSerialNumber);
	ASSERT_FWRITE_ELEM(gSDB->users->numUsers);

	// count up and write out the list of SDBBox structs
	//
	count = Database_CountBoxes(gSDB);
	ASSERT_FWRITE_ELEM(count);
	Logmsg("Linear-dumping %ld box entries\n", count);

	save_begin = time(0);
	gDebugCount = count;

	gWRinfo.cache = gCache;
	gWRinfo.data = (void *) fp;
	gWRinfo.type = kCheckPoint;
	tmpl = Database_ForEachBox(gSDB, Cache_WriteBox, &gWRinfo);

	ASSERT_MESG(tmpl == 0, "SDB_Save: the write failed somewhere?");
	if ( gDebugCount != 0 )
		PLogmsg(LOGP_FLAW, "ERROR: gDebugCount = %ld\n", gDebugCount);

	Logmsg("Linear-dumped %ld box entries in %d seconds\n",count,
	   time(0) - save_begin);

	rewind(fp);
	fprintf(fp, "GOOD\n");
	fflush(fp);
	fsync(fileno(fp));		// sync() returns without waiting, fsync() doesn't
	
	return(kNoError);
}

/*==========================================================================*\
	SDBBox_Write
\*==========================================================================*/
Err
SDBBox_Write(SDBBox *box, void *foo)
{
FILE		*fp;
char		fname[256];
char		backup[256];
Err			err;

	ASSERT(box);
	if (!box)
		return (kFucked);
	
	/*
	 * Generate name of file to save and backup file
	 * Store 1024 box.XXXXX entries per boxdir.YYYYY subdirectory.
	 */
	sprintf(fname, "ServerDB.dir.%ld/boxdir.%05ld/box.%05ld", 
		gConfig.happyRegion, 
		box->boxAccount.box.box >> 10, 
		box->boxAccount.box.box);

	if ( gConfig.backupWrites ) {
		/*
		 * Save old version of file until new version is safely written
		 */
		sprintf(backup, "ServerDB.dir.%ld/boxdir.%05ld/~box.%05ld", 
			gConfig.happyRegion,
			box->boxAccount.box.box >> 10, 
			box->boxAccount.box.box);
		rename(fname, backup);
	}

	if ((fp = fopen(fname, "w")) == NULL) {
		PLogmsg(LOGP_NOTICE,
			"ERROR: failed to open box file (%s) for writing\n", fname);
		return (kFucked);
	}

	err = OSDBBox_Write(box, fp);
	if (err != kNoError) {
		fclose(fp);
		return (err);
	}

	fclose(fp);

#if 1
	if ( gConfig.backupWrites ) {
		/*
		 * Now that the new version of the box file has been safely written,
		 * remove the backup copy
		 */
		unlink(backup);
	}
#endif

	return(kNoError);
}


/*==========================================================================*\
	OSDBBox_Write
\*==========================================================================*/
Err
OSDBBox_Write(SDBBox *box, FILE *fp)
{
BoxAccount	*boxacc;
UCAInfo		*uca;
int			i, j;
long		dbgcnt;
long		tmpl, len, slen, zero=0L;
	
	gDebugCount--;
	if ((gDebugCount > 0) && !(gDebugCount % kProgressInterval))
		Logmsg("  %5d entries left\n", gDebugCount);
	
	ASSERT(box);
	if (!box)
		return (kFucked);
	
//	-----------------------------------------
	// this lets us determine out if we're out of sync
	tmpl = kSDBStartOfBox;
	ASSERT_FWRITE_ELEM(tmpl);

	// this identifies the data (new for v36)
	tmpl = kSaveFileVersion;
	ASSERT_FWRITE_ELEM(tmpl);

	// write BoxAccount struct
	boxacc = &(box->boxAccount);
	ASSERT_FWRITE_ELEM(boxacc->platformID);
	ASSERT_FWRITE_ELEM(boxacc->box);
	ASSERT_FWRITE_ELEM(boxacc->hardwareID);
	ASSERT_FWRITE_ELEM(boxacc->prevHardwareID);
	ASSERT_FWRITE_ELEM(boxacc->rentalInfo);
	ASSERT_FWRITE_ELEM(boxacc->validationToken);
	ASSERT_FWRITE_ELEM(boxacc->password);
	ASSERT_FWRITE_ELEM(boxacc->homeTown);
	ASSERT_FWRITE_ELEM(boxacc->originalHomeTown);
	ASSERT_FWRITE_ELEM(boxacc->gamePhone);
	ASSERT_FWRITE_ELEM(boxacc->originalGamePhone);
	ASSERT_FWRITE_ELEM(boxacc->lastGamePhone);
	ASSERT_FWRITE_ELEM(boxacc->overrideANI1);
	ASSERT_FWRITE_ELEM(boxacc->overridePOP1);
	ASSERT_FWRITE_ELEM(boxacc->overrideANI2);
	ASSERT_FWRITE_ELEM(boxacc->overridePOP2);
	ASSERT_FWRITE_ELEM(boxacc->dateLastChangedGamePhone);
	ASSERT_FWRITE_ELEM(boxacc->popPhone);
	ASSERT_FWRITE_ELEM(boxacc->altPopPhone);

	if (boxacc->mciPhoneList) {
		slen = strlen(boxacc->mciPhoneList);		// write len for strings
		ASSERT_FWRITE_ELEM(slen);
		if (slen) {
			len = fwrite(boxacc->mciPhoneList, 1, slen, fp);
			ASSERT(len == slen);
		}
	} else {
		ASSERT_FWRITE_ELEM(zero);
	}

	ASSERT_FWRITE_ELEM(boxacc->xbnUsage);

	ASSERT_FWRITE_ELEM(boxacc->failed800PopConnects);
	ASSERT_FWRITE_ELEM(boxacc->totalServerConnects);
	ASSERT_FWRITE_ELEM(boxacc->failedClientConnects);
	ASSERT_FWRITE_ELEM(boxacc->usedCredits);
	ASSERT_FWRITE_ELEM(boxacc->maxCredits);
	ASSERT_FWRITE_ELEM(boxacc->startCredits);
	ASSERT_FWRITE_ELEM(boxacc->usedFreeCredits);
	ASSERT_FWRITE_ELEM(boxacc->maxFreeCredits);
	ASSERT_FWRITE_ELEM(boxacc->startFreeCredits);
	for (i = 0; i < 2; i++)
		ASSERT_FWRITE_ELEM(boxacc->restrictInfo[i]);
	ASSERT_FWRITE_ELEM(boxacc->restrictArea);
	ASSERT_FWRITE_ELEM(boxacc->boxFlags);

	ASSERT_FWRITE_ELEM(boxacc->prevSmartCardSerialNumber);

	ASSERT_FWRITE_ELEM(boxacc->cordPullData);
	ASSERT_FWRITE_ELEM(boxacc->lastSlaveInfo);
	ASSERT_FWRITE_ELEM(boxacc->lastMatchup);
	ASSERT_FWRITE_ELEM(boxacc->netErrorTotals);
	ASSERT_FWRITE_ELEM(boxacc->miscPreferences);
	ASSERT_FWRITE_ELEM(boxacc->numberOfBoxCrashes);
	ASSERT_FWRITE_ELEM(boxacc->dateOfLastBoxCrash);
	ASSERT_FWRITE_ELEM(boxacc->numNewsChannels);
	for (i = 0; i < boxacc->numNewsChannels; i++)
		ASSERT_FWRITE_ELEM(boxacc->newsChannels[i]);
	dbgcnt = kNumDebugFields;
	ASSERT_FWRITE_ELEM(dbgcnt);
	for (i = 0; i < kNumDebugFields; i++)
		ASSERT_FWRITE_ELEM(boxacc->debug[i]);
	ASSERT_FWRITE_ELEM(boxacc->csUpdatedFlags);
	ASSERT_FWRITE_ELEM(boxacc->modemVersion);

	ASSERT_FWRITE_ELEM(boxacc->opaqueStore.numBytes);
	if (boxacc->opaqueStore.numBytes > 0) {
	    len = fwrite(boxacc->opaqueStore.buf, 1, 
			 boxacc->opaqueStore.numBytes, fp);
	    ASSERT(len == boxacc->opaqueStore.numBytes);
	}

	// It's a simple struct, just dump it out.
	//
	ASSERT_FWRITE_ELEM(box->userAccount);

	/*
	 * Write UCAInfo struct
	 */
	uca = &(box->ucaInfo);
	ASSERT_FWRITE_ELEM(uca->cs_id);
	if (uca->cc_num) {
		slen = strlen(uca->cc_num);
		ASSERT_FWRITE_ELEM(slen);
		if (slen) {
			len = fwrite(uca->cc_num, 1, slen, fp);
			ASSERT(len == slen);
		}
	}
	else {
		ASSERT_FWRITE_ELEM(zero);
	}
	if (uca->cc_expr) {
		slen = strlen(uca->cc_expr);
		ASSERT_FWRITE_ELEM(slen);
		if (slen) {
			len = fwrite(uca->cc_expr, 1, slen, fp);
			ASSERT(len == slen);
		}
	}
	else {
		ASSERT_FWRITE_ELEM(zero);
	}
	if (uca->checkingAccount) {
		slen = strlen(uca->checkingAccount);
		ASSERT_FWRITE_ELEM(slen);
		if (slen) {
			len = fwrite(uca->checkingAccount, 1, slen, fp);
			ASSERT(len == slen);
		}
	}
	else {
		ASSERT_FWRITE_ELEM(zero);
	}
	if (uca->bankNumber) {
		slen = strlen(uca->bankNumber);
		ASSERT_FWRITE_ELEM(slen);
		if (slen) {
			len = fwrite(uca->bankNumber, 1, slen, fp);
			ASSERT(len == slen);
		}
	}
	else {
		ASSERT_FWRITE_ELEM(zero);
	}
	ASSERT_FWRITE_ELEM(uca->datePreNoteSent);
	if (uca->prodstr) {
		slen = strlen(uca->prodstr);
		ASSERT_FWRITE_ELEM(slen);
		if (slen) {
			len = fwrite(uca->prodstr, 1, slen, fp);
			ASSERT(len == slen);
		}
	}
	else {
		ASSERT_FWRITE_ELEM(zero);
	}
	ASSERT_FWRITE_ELEM(uca->prod_activate);
	ASSERT_FWRITE_ELEM(uca->prod_cycle_start);
	ASSERT_FWRITE_ELEM(uca->prod_terminate);
	if (uca->home_phone) {
		slen = strlen(uca->home_phone);
		ASSERT_FWRITE_ELEM(slen);
		if (slen) {
			len = fwrite(uca->home_phone, 1, slen, fp);
			ASSERT(len == slen);
		}
	}
	else {
		ASSERT_FWRITE_ELEM(zero);
	}
	if (uca->cc_name) {
		slen = strlen(uca->cc_name);
		ASSERT_FWRITE_ELEM(slen);
		if (slen) {
			len = fwrite(uca->cc_name, 1, slen, fp);
			ASSERT(len == slen);
		}
	}
	else {
		ASSERT_FWRITE_ELEM(zero);
	}
	if (uca->address) {
		slen = strlen(uca->address);
		ASSERT_FWRITE_ELEM(slen);
		if (slen) {
			len = fwrite(uca->address, 1, slen, fp);
			ASSERT(len == slen);
		}
	}
	else {
		ASSERT_FWRITE_ELEM(zero);
	}
	if (uca->city) {
		slen = strlen(uca->city);
		ASSERT_FWRITE_ELEM(slen);
		if (slen) {
			len = fwrite(uca->city, 1, slen, fp);
			ASSERT(len == slen);
		}
	}
	else {
		ASSERT_FWRITE_ELEM(zero);
	}
	if (uca->state) {
		slen = strlen(uca->state);
		ASSERT_FWRITE_ELEM(slen);
		if (slen) {
			len = fwrite(uca->state, 1, slen, fp);
			ASSERT(len == slen);
		}
	}
	else {
		ASSERT_FWRITE_ELEM(zero);
	}
	if (uca->zip) {
		slen = strlen(uca->zip);
		ASSERT_FWRITE_ELEM(slen);
		if (slen) {
			len = fwrite(uca->zip, 1, slen, fp);
			ASSERT(len == slen);
		}
	}
	else {
		ASSERT_FWRITE_ELEM(zero);
	}
	if (uca->country) {
		slen = strlen(uca->country);
		ASSERT_FWRITE_ELEM(slen);
		if (slen) {
			len = fwrite(uca->country, 1, slen, fp);
			ASSERT(len == slen);
		}
	}
	else {
		ASSERT_FWRITE_ELEM(zero);
	}
	if (uca->access_code) {
		slen = strlen(uca->access_code);
		ASSERT_FWRITE_ELEM(slen);
		if (slen) {
			len = fwrite(uca->access_code, 1, slen, fp);
			ASSERT(len == slen);
		}
	}
	else {
		ASSERT_FWRITE_ELEM(zero);
	}
	ASSERT_FWRITE_ELEM(uca->terminate);
	ASSERT_FWRITE_ELEM(uca->created);
	if (uca->comment) {
		slen = strlen(uca->comment);
		ASSERT_FWRITE_ELEM(slen);
		if (slen) {
			len = fwrite(uca->comment, 1, slen, fp);
			ASSERT(len == slen);
		}
	}
	else {
		ASSERT_FWRITE_ELEM(zero);
	}
	ASSERT_FWRITE_ELEM(uca->player_cnt);
	ASSERT_FWRITE_ELEM(uca->balance);			/* XXX: compute this? */
	ASSERT_FWRITE_ELEM(uca->credits);			/* XXX: compute this? */

	// dump all four SDBUser structs
	for (i = 0; i < 4; i++) {
		SDBUser *user;
		PlayerAccount *placc;
		long mailcount;
		ListNode *mailnode;
		char user_exists;
		//long slen, zero=0;

		user = box->users[i];

		user_exists = (user != NULL);		// always 0 or 1
		ASSERT_FWRITE_ELEM(user_exists);
		if (!user_exists) continue;

		//ASSERT_FWRITE_ELEM(user->userID);
		ASSERT_FWRITE_ELEM(user->mailSerialNumber);
		ASSERT_FWRITE_ELEM(user->lastBroadcastMailSent);

		// write PlayerAccount struct
		placc = &(user->playerAccount);
		ASSERT_FWRITE_ELEM(placc->magicID);
		ASSERT_FWRITE_ELEM(placc->player);
		ASSERT_FWRITE_ELEM(placc->userName);
		ASSERT_FWRITE_ELEM(placc->filteredUserName);
		ASSERT_FWRITE_ELEM(placc->filteredNameSuffix);
		ASSERT_FWRITE_ELEM(placc->iconID);
		ASSERT_FWRITE_ELEM(placc->colorTableID);
		if (placc->openTaunt) {
			slen = strlen(placc->openTaunt);		// write len for strings
			ASSERT_FWRITE_ELEM(slen);
			if (slen) {
				len = fwrite(placc->openTaunt, 1, slen, fp);
				ASSERT(len == slen);
			}
		} else {
			ASSERT_FWRITE_ELEM(zero);
		}
		if (placc->personInfo) {
			slen = strlen(placc->personInfo);		// write len for strings
			ASSERT_FWRITE_ELEM(slen);
			if (slen) {
				len = fwrite(placc->personInfo, 1, slen, fp);
				ASSERT(len == slen);
			}
		} else {
			ASSERT_FWRITE_ELEM(zero);
		}
		ASSERT_FWRITE_ELEM(placc->password);
		ASSERT_FWRITE_ELEM(placc->passwordEraseCode);
		ASSERT_FWRITE_ELEM(placc->birthday);
		ASSERT_FWRITE_ELEM(placc->playerFlags);
		ASSERT_FWRITE_ELEM(placc->customIconSize);
		if (placc->customIconSize) {
			len = fwrite(placc->customIcon, 1, placc->customIconSize, fp);
			ASSERT(len == placc->customIconSize);
		}
		ASSERT_FWRITE_ELEM(placc->opaqueStore.numBytes);
		if (placc->opaqueStore.numBytes > 0) {
		    len = fwrite(placc->opaqueStore.buf, 1, 
				 placc->opaqueStore.numBytes, fp);
		    ASSERT(len == placc->opaqueStore.numBytes);
		}
		// msgState, msgChannels

		ASSERT_FWRITE_ELEM(placc->lastPersonInfoChange);
		ASSERT_FWRITE_ELEM(placc->lastAddrBookCheck);

		ASSERT_FWRITE_ELEM(placc->autoMatchConnects);
		ASSERT_FWRITE_ELEM(placc->challengeConnects);
		ASSERT_FWRITE_ELEM(placc->msgCheckConnects);
		ASSERT_FWRITE_ELEM(placc->numEvilResets);
		ASSERT_FWRITE_ELEM(placc->numIffyResets);
		ASSERT_FWRITE_ELEM(placc->numRankingInfo);
		ASSERT_FWRITE_ELEM(placc->nextPrevOpponent);
		for (j = 0; j < placc->numRankingInfo; j++)
			ASSERT_FWRITE_ELEM(placc->rankingInfo[j]);
		for (j = 0; j < kMaxPreviousOpponent; j++)
			ASSERT_FWRITE_ELEM(placc->prevOpponent[j]);
		for (j = 0; j < kMaxAddressBookEntries; j++)
			ASSERT_FWRITE_ELEM(placc->addressBook[j]);
		dbgcnt = kNumDebugFields;
		ASSERT_FWRITE_ELEM(dbgcnt);
		for (j = 0; j < kNumDebugFields; j++)
			ASSERT_FWRITE_ELEM(placc->debug[j]);
		for (j = 0; j < kMaxInBoxEntries; j++)
			ASSERT_FWRITE_ELEM(placc->mailInBox[j]);
		ASSERT_FWRITE_ELEM(placc->numNewsChannels);
		for (j = 0; j < placc->numNewsChannels; j++)
			ASSERT_FWRITE_ELEM(placc->newsChannels[j]);
		ASSERT_FWRITE_ELEM(placc->csUpdatedFlags);

		// dump the user's mail
		mailcount = NumListNodesInList(user->incomingMail);
		ASSERT_FWRITE_ELEM(mailcount);

		mailnode = GetFirstListNode(user->incomingMail);
		while (mailcount--) {
			SDBMail *sdbmail;
			Mail *mail;
			long mlen, key;

			// Mail is sorted based on the server "TimeStamp", but the
			// value isn't explicitly included in the mail struct.
			key = GetSortedListNodeKey(mailnode);
			ASSERT_FWRITE_ELEM(key);

			sdbmail = (SDBMail *)GetListNodeData(mailnode);
			ASSERT_FWRITE_ELEM(sdbmail->sentToBox);

			mail = sdbmail->mail;
			ASSERT(mail);

			// For the Mail struct, we want to dump the whole thing in
			// one piece, because there aren't any substructures, and the
			// userIdentification field is nontrivial (but flat!).  Trick
			// is to deal with the string hanging off the end; to make
			// reads easier we output its length first.
			mlen = strlen(mail->message);
			ASSERT_FWRITE_ELEM(mlen);

			// Want sizeof(mail) + mlen, since sizeof is one too large
			// because of the dummy byte at the end, and mlen is one too
			// small because strlen() doesn't count the null byte.
			len = fwrite(mail, 1, sizeof(Mail) + mlen, fp);
			ASSERT(len == sizeof(Mail) + mlen);

			mailnode = GetNextListNode(mailnode);
		}
	}

	// Write an end-of-data token so we're sure we're getting everything.
	//
	tmpl = kSDBEndOfData;
	ASSERT_FWRITE_ELEM(tmpl);

	return (kNoError);
}

#undef ASSERT_FWRITE_ELEM

// just like ASSERT_FWRITE_ELEM, but read instead
#define ASSERT_FREAD_ELEM(_item) { \
		long _len = fread(&(_item), 1, sizeof(_item), fp); \
		ASSERT(_len == sizeof(_item)); \
		if (_len != sizeof(_item)) { \
			PLogmsg(LOGP_FLAW, "ASSERT failed: ferror = %d, feof = %d\n", \
					ferror(fp), feof(fp)); \
			return (kUnexpectedEOF); \
		} \
	}

/*==========================================================================*\
	SDB_Restore
\*==========================================================================*/
Err
SDB_Restore(FILE *fp, int backup)
{
	time_t save_begin;
	long   save_count;
	long   count;
	long   tmpl;
	long   save_format = -1;
	long   file_version = -1;
	SDBBox *box;

	// seek to the "real" beginning
	//
	fseek(fp, 32L, 0);

	// read the header
	//
	ASSERT_FREAD_ELEM(save_format);
	if (save_format == kSDBNewerSaveFormat) {
		// Reading a stub header; data is in individual box files.
		//
		ASSERT_FREAD_ELEM(file_version);
		if (file_version > kSaveFileVersion) {
			PLogmsg(LOGP_NOTICE,
				"WARNING: save file version is too new (%d vs %d)\n",
				file_version, kSaveFileVersion);
		}
	} else if (save_format == kSDBNewSaveFormat) {
		// Reading from a checkpoint file.  Force a write of all  box files.
		ASSERT_FREAD_ELEM(file_version);
		if (file_version > kSaveFileVersion) {
			PLogmsg(LOGP_NOTICE,
				"WARNING: save file version is too new (%d vs %d\n",
				file_version, kSaveFileVersion);
		}
	} else if (save_format == kSDBCode_Server) {
		// This shouldn't be happening anymore.
		//
		file_version = 0;
	} else {
		PLogmsg(LOGP_FLAW,
			"ERROR: found unexpected code 0x%.8lx at start of DB\n",
			save_format);
		Common_Abort();
	}

	ASSERT_FREAD_ELEM(tmpl);
	if (tmpl != gConfig.happyRegion) {
		PLogmsg(LOGP_NOTICE, "ERROR: save file has different HAPPY_REGION\n");
		Common_Abort();
	}

	// SDBUsers_New() should already have been called
	ASSERT(gSDB);
	ASSERT(gSDB->users);
	
	// load the SDBUsers stuff
	ASSERT_FREAD_ELEM(gSDB->users->timeStamp);
	ASSERT_FREAD_ELEM(gSDB->users->uniqueBoxSerialNumber);
	if (backup) {
		// We're restoring from a backup copy, probably after some sort
		// of crash.  Assume the previous process created an account but
		// failed to register the update.  To prevent assigning the same
		// boxID to two different boxes, we skip over the next serial
		// number.
		//
		gSDB->users->uniqueBoxSerialNumber++;
	}
	ASSERT_FREAD_ELEM(gSDB->users->numUsers);

	// read the #of SDBBox structs
	ASSERT_FREAD_ELEM(count);
	save_count = count;

	/* Create the opaque box cache data structure */
	gCache = Cache_New(file_version, P_ReadBox, P_WriteBox, P_FreeBox);

	/*
	 * Read in SDBBox data.  Hopefully, we're now using the 'newer'
	 * save format, but if we're not, handle the old linear file format
	 * as well
	 */
	if (save_format == kSDBNewerSaveFormat) {
		DIR *dbdir, *boxdir;
		FILE *dbfile;
		struct dirent *boxentry, *subentry;
		char	dirname[256], boxdirname[256];
		char	fname[256];

		Logmsg("Box-reading %ld box entries\n", count);
		sprintf(dirname, "ServerDB.dir.%ld", gConfig.happyRegion);
		if ((dbdir = opendir(dirname)) == NULL) {
			PLogmsg(LOGP_FLAW,
				"ERROR: cannot open server database directory (%s)\n", dirname);
			Common_Abort();
		}

		save_begin = time(0);

		while ((subentry = readdir(dbdir)))
		{
		    if(!strncmp(subentry->d_name, "boxdir.", 7))
		    {
			strcpy(boxdirname, dirname);
			strcat(boxdirname, "/");
			strcat(boxdirname, subentry->d_name);
			
			if ((boxdir = opendir(boxdirname)) == NULL) {
				PLogmsg(LOGP_FLAW,
					"ERROR: cannot open server boxdatabase directory (%s)\n", boxdirname);
				Common_Abort();
			}

			while ((boxentry = readdir(boxdir))) {
				if (!strncmp(boxentry->d_name, "box.", 4)) {
					strcpy(fname, boxdirname);
					strcat(fname, "/");
					strcat(fname, boxentry->d_name);
					if ((dbfile = fopen(fname, "r"))) {
						PLogmsg(LOGP_PROGRESS, "fname='%s'\n", fname);
						box = SDBBox_Read(dbfile, file_version);
						if ( box ) {
							SDBBoxCachePtr entry = Cache_NewEntry(box);
							if ( entry ) {
								Database_AddBox(gSDB, entry);
								SDBBox_Free(box);
								Cache_InvalidateEntry(entry);
							}
						}
						else {
							PLogmsg(LOGP_FLAW, 
								"ERROR: couldn't restore box file %s\n", fname);
						}
						count--;
						if (count && !(count % kProgressInterval))
							Logmsg("  %5d entries left\n", count);
						fclose(dbfile);
					}
					else {
						PLogmsg(LOGP_NOTICE,
							"Failed to open box file %s -- skipping\n", fname);
					}
				}
			}
			closedir(boxdir);
		    }
		}
		closedir(dbdir);

		Logmsg("Box-read %ld box entries in %d seconds\n", save_count,
		   time(0) - save_begin);

	} else if (save_format == kSDBNewSaveFormat) {
		Logmsg("Linear-reading %ld box entries\n", count);

		save_begin = time(0);

		while (count--) {
			box = SDBBox_Read(fp, file_version);
			if ( box ) {
				SDBBoxCachePtr entry = Cache_NewEntry(box);
				if ( entry ) {
					Database_AddBox(gSDB, entry);
					/*
					 * Since we are linear reading the boxes from one large
					 * flat file, we have to write the box entry out
					 * to disk immediately since we are no longer keeping
					 * it in memory.
					 */
					gWRinfo.type  = kBoxWrite;
					gWRinfo.data  = NULL;
					gWRinfo.cache = gCache;
					Cache_WriteBox(entry, &gWRinfo);
					SDBBox_Free(box);
					Cache_InvalidateEntry(entry);
				}
			}
			else {
				PLogmsg(LOGP_FLAW, "ERROR: Error reading box data\n");
			}
			if (count && !(count % kProgressInterval))
				Logmsg("  %5d entries left\n", count);
		}
		Logmsg("Linear-read %ld box entries in %d seconds\n", save_count,
		   time(0) - save_begin);
		count++;		// happy happy make it 0

	} else {
		PLogmsg(LOGP_FLAW, "ERROR: unsupported save format '%.4s'\n",
			(char *)&save_format);
		Common_Abort();
	}

	if (count) {
		PLogmsg(LOGP_FLAW, "FATAL: box counts did not match (count=%d)\n", count);
		Common_Abort();
	}

	return(kNoError);
}

#undef ASSERT_FREAD_ELEM

// just like ASSERT_FREAD_ELEM above, but returns
// NULL pointer instead of integer error value.
#define ASSERT_FREAD_ELEM(_item) { \
		long _len = fread(&(_item), 1, sizeof(_item), fp); \
		ASSERT(_len == sizeof(_item)); \
		if (_len != sizeof(_item)) { return (NULL); } \
	}

/*==========================================================================*\
	SDBBox_Read
\*==========================================================================*/
SDBBox *
SDBBox_Read(FILE *fp, long file_version)
{
	//
	// Read the SDBBox data, appending each new struct to the list that
	// corresponds to their region.
	// The list of region lists is: gSDB->users->list.
	// Uses Database_AddBox to add the box to the database
	//
	SDBBox *box;
	BoxAccount *boxacc;
	UCAInfo *uca;
	int i, j;
	long tmpl;
	long dbgcnt;
	long len, slen;

	ASSERT_FREAD_ELEM(tmpl);
	if (tmpl != kSDBStartOfBox) {
		PLogmsg(LOGP_FLAW,
			"ERROR: start of box not found, can't read database\n");
		return (NULL);
	}

	// Normally the file version in the box files and the version in the
	// main stub file should match.  It's possible they won't; this should
	// be handled gracefully.
	//
	if (file_version >= 36) {
		ASSERT_FREAD_ELEM(tmpl);
		if (tmpl != file_version)
			PLogmsg(LOGP_NOTICE,
				"Read file_version %d (expected %d)\n", tmpl, file_version);
		file_version = tmpl;
	}

	box = (SDBBox *)malloc(sizeof(SDBBox));
	ASSERT_MESG(box, "out of mems");
	memset(box, 0, sizeof(SDBBox));

	// read BoxAccount struct
	boxacc = &(box->boxAccount);
	boxacc->magicID = 0;		// no reason to save/restore this
	if (file_version < 31) {
		boxacc->platformID = kPlatformGenesis;	// init them to Genesis
	} else {
		ASSERT_FREAD_ELEM(boxacc->platformID);
	}
	ASSERT_FREAD_ELEM(boxacc->box);
	if (file_version >= 37) {
		ASSERT_FREAD_ELEM(boxacc->hardwareID);
		ASSERT_FREAD_ELEM(boxacc->prevHardwareID);
		ASSERT_FREAD_ELEM(boxacc->rentalInfo);
		ASSERT_FREAD_ELEM(boxacc->validationToken);
	}
	ASSERT_FREAD_ELEM(boxacc->password);
	if (file_version <= 36) {
		DataBase_CheckPW(boxacc->platformID, boxacc->password);	// conv to ASCII
	}
	ASSERT_FREAD_ELEM(boxacc->homeTown);
	if (file_version < 29) {
		strcpy(boxacc->originalHomeTown, boxacc->homeTown);
	} else {
		ASSERT_FREAD_ELEM(boxacc->originalHomeTown);
	}
	ASSERT_FREAD_ELEM(boxacc->gamePhone);
	ASSERT_FREAD_ELEM(boxacc->originalGamePhone);
	ASSERT_FREAD_ELEM(boxacc->lastGamePhone);
	if (file_version >= 37) {
		ASSERT_FREAD_ELEM(boxacc->overrideANI1);
		ASSERT_FREAD_ELEM(boxacc->overridePOP1);
		ASSERT_FREAD_ELEM(boxacc->overrideANI2);
		ASSERT_FREAD_ELEM(boxacc->overridePOP2);
	}
	ASSERT_FREAD_ELEM(boxacc->dateLastChangedGamePhone);
	if (file_version < 26) {
		// Strip all the dashes out.
		//
		Common_PhoneNormalizeNumber(boxacc->gamePhone.phoneNumber,
			boxacc->gamePhone.phoneNumber);
		Common_PhoneNormalizeNumber(boxacc->originalGamePhone.phoneNumber,
			boxacc->gamePhone.phoneNumber);
		Common_PhoneNormalizeNumber(boxacc->lastGamePhone.phoneNumber,
			boxacc->lastGamePhone.phoneNumber);
	}

	ASSERT_FREAD_ELEM(boxacc->popPhone);
	ASSERT_FREAD_ELEM(boxacc->altPopPhone);

	if ( file_version > 37 ) {
		ASSERT_FREAD_ELEM(slen);
		if (slen) {
			boxacc->mciPhoneList = (char *)malloc(slen+1);
			len = fread(boxacc->mciPhoneList, 1, slen, fp);
			ASSERT(len == slen);
			boxacc->mciPhoneList[slen] = '\0';	// didn't read NULL out of file
		} else {
			boxacc->mciPhoneList = (char *)malloc(1);
			*(boxacc->mciPhoneList) = '\0';
		}
	} else {
		boxacc->mciPhoneList = (char *)malloc(1);
		*(boxacc->mciPhoneList) = '\0';
	}

	if ( file_version >= 40 )
		ASSERT_FREAD_ELEM(boxacc->xbnUsage);

	ASSERT_FREAD_ELEM(boxacc->failed800PopConnects);
	ASSERT_FREAD_ELEM(boxacc->totalServerConnects);
	ASSERT_FREAD_ELEM(boxacc->failedClientConnects);
	ASSERT_FREAD_ELEM(boxacc->usedCredits);
	ASSERT_FREAD_ELEM(boxacc->maxCredits);
	ASSERT_FREAD_ELEM(boxacc->startCredits);
	ASSERT_FREAD_ELEM(boxacc->usedFreeCredits);
	ASSERT_FREAD_ELEM(boxacc->maxFreeCredits);
	ASSERT_FREAD_ELEM(boxacc->startFreeCredits);
	if (file_version < 25) {
		// Start doing "real" crediting.
		//
		boxacc->startCredits = -1000;
		boxacc->usedCredits = -1000;
		boxacc->maxCredits = 0;
		boxacc->startFreeCredits = 0;
		boxacc->usedFreeCredits = 0;
		boxacc->maxFreeCredits = 0;
	}
	for (i = 0; i < 2; i++)
		ASSERT_FREAD_ELEM(boxacc->restrictInfo[i]);
	ASSERT_FREAD_ELEM(boxacc->restrictArea);
	ASSERT_FREAD_ELEM(boxacc->boxFlags);

	ASSERT_FREAD_ELEM(boxacc->prevSmartCardSerialNumber);
	if ( file_version <= 40 ) {
		boxacc->prevSmartCardSerialNumber = 0;
	}

	ASSERT_FREAD_ELEM(boxacc->cordPullData);
	if (file_version < 39) {
		// Added 2 shorts to struct in 38, back up
		fseek(fp, -4L, 1);

		// zero out the new fields
		boxacc->cordPullData.weightedAverage = 0;
		boxacc->cordPullData.min = 0;
		boxacc->cordPullData.max = 0;
		boxacc->cordPullData.reserved3 = 0;
	}

	ASSERT_FREAD_ELEM(boxacc->lastSlaveInfo);
	if (file_version < 37) {
		// Added 1 long to struct in 37, back up
		fseek(fp, -4L, 1);
		boxacc->lastSlaveInfo.randomVal = 0;
	}
	ASSERT_FREAD_ELEM(boxacc->lastMatchup);
	ASSERT_FREAD_ELEM(boxacc->netErrorTotals);
	if (file_version >= 37) {
		ASSERT_FREAD_ELEM(boxacc->miscPreferences);
	}
	ASSERT_FREAD_ELEM(boxacc->numberOfBoxCrashes);
	ASSERT_FREAD_ELEM(boxacc->dateOfLastBoxCrash);
	ASSERT_FREAD_ELEM(boxacc->numNewsChannels);
	ASSERT(boxacc->numNewsChannels <= kMaxNewsChannels);
	for (i = 0; i < boxacc->numNewsChannels; i++)
		ASSERT_FREAD_ELEM(boxacc->newsChannels[i]);
	ASSERT_FREAD_ELEM(dbgcnt);	// what they thought kNumDebugFields was
	if (dbgcnt > kNumDebugFields) {
		PLogmsg(LOGP_NOTICE, "Truncating some box debug fields\n");
		dbgcnt = kNumDebugFields;
	}
	for (i = 0; i < dbgcnt; i++) {
		ASSERT_FREAD_ELEM(boxacc->debug[i]);
	}
	ASSERT_FREAD_ELEM(boxacc->csUpdatedFlags);
	if (file_version >= 32) {
		ASSERT_FREAD_ELEM(boxacc->modemVersion);
	} else {
		memset(boxacc->modemVersion, 0, sizeof(boxacc->modemVersion));
	}

	ASSERT_FREAD_ELEM(boxacc->opaqueStore.numBytes);
	if (boxacc->opaqueStore.numBytes > 0) {
	    boxacc->opaqueStore.buf = 
			(char *)malloc(boxacc->opaqueStore.numBytes);
	    len = fread(boxacc->opaqueStore.buf, 1, 
			boxacc->opaqueStore.numBytes, fp);
	    ASSERT(len == boxacc->opaqueStore.numBytes);
	} else {
	    boxacc->opaqueStore.buf = (char *)NULL;
	}

	// It's a simple struct, just read it in.
	//
	ASSERT_FREAD_ELEM(box->userAccount);
	if (file_version < 29) {
		// added two longs to the end, back up
		fseek(fp, -8L, 1);
		box->userAccount.dateFirstConnect = box->userAccount.activationDate;
		box->userAccount.billingType = 0;
	}
	if (file_version < 37) {
		// added two longs and a 20-byte char array; back up and wipe them
		fseek(fp, -28L, 1);
		box->userAccount.acqusitionType = 0;
		box->userAccount.closedDate = 0;
		memset(box->userAccount.promoString, 0, kPromoStringSize);
	}

	// File version 35 (4.12.95) is the first one where UCA stub accounts
	// will be in the database.  CreateNewBoxAndPlayerAccount relies on the
	// dateLastConnect being == 0 to indicate a new account.  So we'd better
	// make sure that all the accounts have this set before we bring this online!
	// DJ
	//
	if(file_version < 35)
	{
		if(!box->userAccount.dateLastConnect)
		{
			if(!box->userAccount.dateFirstConnect)
				box->userAccount.dateFirstConnect = 1;
			box->userAccount.dateLastConnect = box->userAccount.dateFirstConnect;
			PLogmsg(LOGP_NOTICE,
				"WARNING: boxid %ld has dateLastConnect = 0.\n",
				box->boxAccount.box.box);
		}
	}


	/*
	 * read UCAInfo structure
	 */
	uca = &(box->ucaInfo);
	if (file_version >= 33) {
		ASSERT_FREAD_ELEM(uca->cs_id);
		ASSERT_FREAD_ELEM(slen);
		if (slen) {
			uca->cc_num = (char *) calloc(1, slen+1);
			len = fread(uca->cc_num, 1, slen, fp);
			ASSERT(len == slen);
		}
		else {
			uca->cc_num = (char *) malloc(1);
			*(uca->cc_num) = '\0';
		}
		ASSERT_FREAD_ELEM(slen);
		if (slen) {
			uca->cc_expr = (char *) calloc(1, slen+1);
			len = fread(uca->cc_expr, 1, slen, fp);
			ASSERT(len == slen);
		}
		else {
			uca->cc_expr = (char *) malloc(1);
			*(uca->cc_expr) = '\0';
		}

		if (file_version >= 42) {
			ASSERT_FREAD_ELEM(slen);
			if (slen) {
				uca->checkingAccount = (char *) calloc(1, slen+1);
				len = fread(uca->checkingAccount, 1, slen, fp);
				ASSERT(len == slen);
			}
			else {
				uca->checkingAccount = (char *) malloc(1);
				*(uca->checkingAccount) = '\0';
			}
			ASSERT_FREAD_ELEM(slen);
			if (slen) {
				uca->bankNumber = (char *) calloc(1, slen+1);
				len = fread(uca->bankNumber, 1, slen, fp);
				ASSERT(len == slen);
			}
			else {
				uca->bankNumber = (char *) malloc(1);
				*(uca->bankNumber) = '\0';
			}
			ASSERT_FREAD_ELEM(uca->datePreNoteSent);
		}
		else {
			uca->checkingAccount = (char *) malloc(1);
			*(uca->checkingAccount) = '\0';
			uca->bankNumber = (char *) malloc(1);
			*(uca->bankNumber) = '\0';
			uca->datePreNoteSent = 0;
		}

		ASSERT_FREAD_ELEM(slen);
		if (slen) {
			uca->prodstr = (char *) calloc(1, slen+1);
			len = fread(uca->prodstr, 1, slen, fp);
			ASSERT(len == slen);
		}
		else {
			uca->prodstr = (char *) malloc(1);
			*(uca->prodstr) = '\0';
		}
		ASSERT_FREAD_ELEM(uca->prod_activate);
		ASSERT_FREAD_ELEM(uca->prod_cycle_start);
		ASSERT_FREAD_ELEM(uca->prod_terminate);
		ASSERT_FREAD_ELEM(slen);
		if (slen) {
			uca->home_phone = (char *) calloc(1, slen+1);
			len = fread(uca->home_phone, 1, slen, fp);
			ASSERT(len == slen);
		}
		else {
			uca->home_phone = (char *) malloc(1);
			*(uca->home_phone) = '\0';
		}
		ASSERT_FREAD_ELEM(slen);
		if (slen) {
			uca->cc_name = (char *) calloc(1, slen+1);
			len = fread(uca->cc_name, 1, slen, fp);
			ASSERT(len == slen);
		}
		else {
			uca->cc_name = (char *) malloc(1);
			*(uca->cc_name) = '\0';
		}
		ASSERT_FREAD_ELEM(slen);
		if (slen) {
			uca->address = (char *) calloc(1, slen+1);
			len = fread(uca->address, 1, slen, fp);
			ASSERT(len == slen);
		}
		else {
			uca->address = (char *) malloc(1);
			*(uca->address) = '\0';
		}
		ASSERT_FREAD_ELEM(slen);
		if (slen) {
			uca->city = (char *) calloc(1, slen+1);
			len = fread(uca->city, 1, slen, fp);
			ASSERT(len == slen);
		}
		else {
			uca->city = (char *) malloc(1);
			*(uca->city) = '\0';
		}
		ASSERT_FREAD_ELEM(slen);
		if (slen) {
			uca->state = (char *) calloc(1, slen+1);
			len = fread(uca->state, 1, slen, fp);
			ASSERT(len == slen);
		}
		else {
			uca->state = (char *) malloc(1);
			*(uca->state) = '\0';
		}
		if (file_version >= 34) {
			ASSERT_FREAD_ELEM(slen);
			if (slen) {
				uca->zip = (char *) calloc(1, slen+1);
				len = fread(uca->zip, 1, slen, fp);
				ASSERT(len == slen);
			}
			else {
				uca->zip = (char *) malloc(1);
				*(uca->zip) = '\0';
			}
		}
		else {
			uca->zip = (char *) malloc(1);
			*(uca->zip) = '\0';
		}
		ASSERT_FREAD_ELEM(slen);
		if (slen) {
			uca->country = (char *) calloc(1, slen+1);
			len = fread(uca->country, 1, slen, fp);
			ASSERT(len == slen);
		}
		else {
			uca->country = (char *) malloc(1);
			*(uca->country) = '\0';
		}
		ASSERT_FREAD_ELEM(slen);
		if (slen) {
			uca->access_code = (char *) calloc(1, slen+1);
			len = fread(uca->access_code, 1, slen, fp);
			ASSERT(len == slen);
		}
		else {
			uca->access_code = (char *) malloc(1);
			*(uca->access_code) = '\0';
		}
		ASSERT_FREAD_ELEM(uca->terminate);
		ASSERT_FREAD_ELEM(uca->created);
		ASSERT_FREAD_ELEM(slen);
		if (slen) {
			uca->comment = (char *) calloc(1, slen+1);
			len = fread(uca->comment, 1, slen, fp);
			ASSERT(len == slen);
		}
		else {
			uca->comment = (char *) malloc(1);
			*(uca->comment) = '\0';
		}
		ASSERT_FREAD_ELEM(uca->player_cnt);
		ASSERT_FREAD_ELEM(uca->balance);		/* compute these last two?  If so, */
		ASSERT_FREAD_ELEM(uca->credits);		/* we won't need to store them. */
	}
	else {
		/*
		 * Set some reasonable initial values for the uca structure
		 */
		uca->cs_id = 0;
		uca->cc_num = calloc(1, sizeof(char));
		uca->cc_expr = calloc(1, sizeof(char));
		uca->prodstr = calloc(1, sizeof(char));
		uca->prod_activate = 0;
		uca->prod_cycle_start = 0;
		uca->prod_terminate = 0;
		uca->home_phone = calloc(1, sizeof(char));
		uca->cc_name = calloc(1, sizeof(char));
		uca->address = calloc(1, sizeof(char));
		uca->city = calloc(1, sizeof(char));
		uca->state = calloc(1, sizeof(char));
		uca->zip = calloc(1, sizeof(char));
		uca->country = calloc(1, sizeof(char));
		uca->access_code = calloc(1, sizeof(char));
		uca->terminate = 0;
		uca->created = 0;
		uca->comment = calloc(1, sizeof(char));
		uca->player_cnt = 0;			/* XXX: this should probably be computed now */
		uca->balance = 0.0;			/* XXX: this should probably be computed now */
		uca->credits = 0.0;			/* XXX: this should probably be computed now */
	}

	// read all four SDBUser structs
	for (i = 0; i < 4; i++) {
		SDBUser *user;
		PlayerAccount *placc;
		long mailcount;
		ListNode *mailnode;
		char user_exists;

		ASSERT_FREAD_ELEM(user_exists);
		if (!user_exists) {
			box->users[i] = NULL;
			continue;
		}
		if (user_exists != 1) {
			// Most likely reason for this to occur is a glitch in the
			// previous stuff... we're probably out of sync.
			//
			PLogmsg(LOGP_FLAW, "ERROR: user_exists not 0 or 1\n");
			return (NULL);
		}

		user = (SDBUser *)malloc(sizeof(SDBUser));
		ASSERT_MESG(user, "out of mems");
		memset(user, 0, sizeof(SDBUser));

		box->users[i] = user;

		ASSERT_FREAD_ELEM(user->mailSerialNumber);
		ASSERT_FREAD_ELEM(user->lastBroadcastMailSent);

		// read the PlayerAccount
		placc = &(user->playerAccount);
		placc->player = 0;
		ASSERT_FREAD_ELEM(placc->player);
		if (placc->player != i)		// this isn't initialized for people
			placc->player = i;		//  created prior to version 7
		ASSERT_FREAD_ELEM(placc->magicID);
		ASSERT_FREAD_ELEM(placc->userName);
		ASSERT_FREAD_ELEM(placc->filteredUserName);
		ASSERT_FREAD_ELEM(placc->filteredNameSuffix);
		ASSERT_FREAD_ELEM(placc->iconID);
		ASSERT_FREAD_ELEM(placc->colorTableID);

		ASSERT_FREAD_ELEM(slen);
		if (slen) {
			placc->openTaunt = (char *)malloc(slen+1);
			len = fread(placc->openTaunt, 1, slen, fp);
			ASSERT(len == slen);
			placc->openTaunt[slen] = '\0';	// didn't read NULL out of file
		} else {
			placc->openTaunt = (char *)malloc(1);
			*(placc->openTaunt) = '\0';
		}
		ASSERT_FREAD_ELEM(slen);
		if (slen) {
			placc->personInfo = (char *)malloc(slen+1);
			len = fread(placc->personInfo, 1, slen, fp);
			ASSERT(len == slen);
			placc->personInfo[slen] = '\0';	// didn't read NULL out of file
		} else {
			placc->personInfo = (char *)malloc(1);
			*(placc->personInfo) = '\0';
		}

		ASSERT_FREAD_ELEM(placc->password);
		DataBase_CheckPW(boxacc->platformID, placc->password);	// conv to ASCII?
		ASSERT_FREAD_ELEM(placc->passwordEraseCode);
		DataBase_CheckPW(boxacc->platformID, placc->passwordEraseCode);	// conv to ASCII?
		ASSERT_FREAD_ELEM(placc->birthday);
		ASSERT_FREAD_ELEM(placc->playerFlags);
		ASSERT_FREAD_ELEM(placc->customIconSize);
		if (placc->customIconSize) {
			placc->customIcon = (unsigned char *) malloc(placc->customIconSize);
			ASSERT(placc->customIcon);
			len = fread(placc->customIcon, 1, placc->customIconSize, fp);
			ASSERT(len == placc->customIconSize);
		} else {
			placc->customIcon = NULL;
		}
		ASSERT_FREAD_ELEM(placc->opaqueStore.numBytes);
		if (placc->opaqueStore.numBytes > 0) {
			placc->opaqueStore.buf =
				(char *)malloc(placc->opaqueStore.numBytes);
			len = fread(placc->opaqueStore.buf, 1, 
				placc->opaqueStore.numBytes, fp);
			ASSERT(len == placc->opaqueStore.numBytes);
		} else {
			placc->opaqueStore.buf = (char *)NULL;
		}
		// msgState, msgChannels

		if ( file_version > 37 ) {
			ASSERT_FREAD_ELEM(placc->lastPersonInfoChange);
			ASSERT_FREAD_ELEM(placc->lastAddrBookCheck);
		}

		ASSERT_FREAD_ELEM(placc->autoMatchConnects);
		ASSERT_FREAD_ELEM(placc->challengeConnects);
		ASSERT_FREAD_ELEM(placc->msgCheckConnects);
		ASSERT_FREAD_ELEM(placc->numEvilResets);
		ASSERT_FREAD_ELEM(placc->numIffyResets);
		ASSERT_FREAD_ELEM(placc->numRankingInfo);
		ASSERT_FREAD_ELEM(placc->nextPrevOpponent);
		if (placc->numRankingInfo > kMaxRankingInfo) {
			PLogmsg(LOGP_FLAW, "ERROR: too many rankingInfo structs\n");
			Common_Abort();	/* XXX - Do we really want to abort here */
		}
		for (j = 0; j < placc->numRankingInfo; j++) {
			ASSERT_FREAD_ELEM(placc->rankingInfo[j]);
			if (file_version < 28) {
				// Reset all KONratings to 3000.
				//
				if (placc->rankingInfo[j].gameID != 0)
					placc->rankingInfo[j].rating = 3000;
			}
			if (file_version < 30) {
				// Canonacalize the NBA JAM gameIDs
				//
				if (placc->rankingInfo[j].gameID == 0xe30c296e)
					placc->rankingInfo[j].gameID = 0x39677bdb;
			}
		}
		for (j = 0; j < kMaxPreviousOpponent; j++)
			ASSERT_FREAD_ELEM(placc->prevOpponent[j]);
		for (j = 0; j < kMaxAddressBookEntries; j++)
			ASSERT_FREAD_ELEM(placc->addressBook[j]);
		ASSERT_FREAD_ELEM(dbgcnt);	// what they thought kNumDebugFields was
		if (dbgcnt > kNumDebugFields) {
			PLogmsg(LOGP_NOTICE, "Truncating some player debug fields\n");
			dbgcnt = kNumDebugFields;
		}
		for (j = 0; j < dbgcnt; j++)
			ASSERT_FREAD_ELEM(placc->debug[j]);
		for (j = 0; j < kMaxInBoxEntries; j++)
			ASSERT_FREAD_ELEM(placc->mailInBox[j]);
		ASSERT_FREAD_ELEM(placc->numNewsChannels);
		ASSERT(placc->numNewsChannels < kMaxNewsChannels);
		for (j = 0; j < placc->numNewsChannels; j++)
			ASSERT_FREAD_ELEM(placc->newsChannels[j]);
		ASSERT_FREAD_ELEM(placc->csUpdatedFlags);

		// load the user's mail into the incomingMail list
		user->incomingMail = NewSortedList();
		ASSERT_FREAD_ELEM(mailcount);
		if (mailcount > 2048) {
			PLogmsg(LOGP_FLAW,
				"ERROR: Bogus mailcount in restore, aborting\n");
			return (NULL);
		}

		while (mailcount--) {
			SDBMail *sdbmail;
			//Mail *mail;
			long mlen, key;

			// mail sort key (database "TimeStamp")
			ASSERT_FREAD_ELEM(key);

			sdbmail = (SDBMail *)malloc(sizeof(SDBMail));
			ASSERT_MESG(sdbmail, "out of mems");
			ASSERT_FREAD_ELEM(sdbmail->sentToBox);

			// get the mail message string length
			ASSERT_FREAD_ELEM(mlen);
			ASSERT(mlen < 1024);		// sanity check; screen out old save files
			if (mlen > 1024) {
				PLogmsg(LOGP_FLAW,
					"ERROR: Bogus mail in restore, aborting\n");
				return (NULL);
			}

			// Size of mail message works out to be the size of the
			// struct plus the message string's length (+1 for NULL we add).
			//
			sdbmail->mail = (Mail *)malloc(sizeof(Mail) + mlen +1);
			ASSERT_MESG(sdbmail->mail, "out of mems");

			len = fread(sdbmail->mail, 1, sizeof(Mail) + mlen, fp);
			ASSERT(len == sizeof(Mail) + mlen);
			sdbmail->mail->message[mlen] = '\0';	// NULL-terminate message

			key = sdbmail->mail->serialNumber;
			mailnode = NewSortedListNode((Ptr)sdbmail, key);
			AddListNodeToSortedList(user->incomingMail, mailnode);
		}
	}

	// We should be all done reading.  Make sure there's nothing else to read.
	//
	// A failure here is interesting, because we've successfully read the
	// data in, but for some reason more data was written than we've read.
	// Probably doesn't make sense to abort, though if we're reading from
	// the checkpoint file we're going to fail shortly.
	//
	if (file_version >= 36) {
		ASSERT_FREAD_ELEM(tmpl);
		if (tmpl != kSDBEndOfData) {
			PLogmsg(LOGP_NOTICE,
				"WARNING: end sync token missing: wanted '%.4s', got 0x%.8lx\n",
				kSDBEndOfData, tmpl);
		}
	}

//#define WHACK_HOSED_ACCOUNTS

#ifdef WHACK_HOSED_ACCOUNTS
//#define CUTOFF	0x2e8d0ce6	// Sat Oct  1 00:16:54 1994
#define CUTOFF	0x2eb5f5af	// Tue Nov  1 00:00:47 1994

	// This attempts to get rid of accounts that are clearly bogus
	// (have a hosed gamePhone, have never logged in, or haven't logged
	// in for a very long time).
	//
	// Unlike the "duplicate account" stuff, this will cause the *current*
	// account to be ignored.  We don't actually free the storage, but
	// that shouldn't matter.
	//
	if ( boxacc->box.box < 3000 && (
		 (!strlen(boxacc->gamePhone.phoneNumber)) ||
		 (!isdigit(boxacc->gamePhone.phoneNumber[0])) ||
		 (!isdigit(boxacc->gamePhone.phoneNumber[1])) ||
		 (!box->userAccount.dateLastConnect)
		) )
	{
		int ii;
		char phbuf[16];

		sprintf(phbuf, "'%s'", boxacc->gamePhone.phoneNumber);
		for (ii = 0; (ii < 4) && (box->users[ii] == NULL); ii++)
			;
		Logmsg("Trivial delete: (%d,%d) %-12s '%s'\n",
			boxacc->box.box, boxacc->box.region, phbuf,
			(ii != 4) ? box->users[ii]->playerAccount.userName : "(none)");
		// do me
	} else if ( boxacc->box.box < 3000 && (
		 (box->userAccount.dateLastConnect < CUTOFF)
		) )
	{
		int ii;
		char datebuf[32];
		char phbuf[16];

		sprintf(phbuf, "'%s'", boxacc->gamePhone.phoneNumber);
		strcpy(datebuf, ctime(&box->userAccount.dateLastConnect));

		for (ii = 0; (ii < 4) && (box->users[ii] == NULL); ii++)
			;
		Logmsg("Age delete    : (%d,%d) %-12s '%s' @%.10s\n",
			boxacc->box.box, boxacc->box.region, phbuf,
			(ii != 4) ? box->users[ii]->playerAccount.userName : "(none)",
			datebuf);
		// do me
	} else
#endif	/*WHACK_HOSED_ACCOUNTS*/

	return(box);
}

#undef ASSERT_FREAD_ELEM

/*==========================================================================*\
	SDBBox_Free
\*==========================================================================*/
void
SDBBox_Free(SDBBox *box)
{
	BoxAccount *boxacc;
	UCAInfo *uca;
	int i;

	ASSERT(box);

	if ((boxacc = &(box->boxAccount))) {
		/* free boxacc mallocs */
		if ( boxacc->opaqueStore.buf )
			free(boxacc->opaqueStore.buf);
		if ( boxacc->mciPhoneList )
			free(boxacc->mciPhoneList);
	}

	if ((uca = &(box->ucaInfo))) {
		/* free uca mallocs */
		if ( uca->cc_num )
			free(uca->cc_num);
		if ((uca->cc_expr))
			free(uca->cc_expr);
		if ((uca->checkingAccount))
			free(uca->checkingAccount);
		if ((uca->bankNumber))
			free(uca->bankNumber);
		if ( uca->prodstr )
			free(uca->prodstr);
		if ( uca->home_phone )
			free(uca->home_phone);
		if ( uca->cc_name )
			free(uca->cc_name);
		if ((uca->address))
			free(uca->address);
		if ( uca->city )
			free(uca->city);
		if ( uca->state )
			free(uca->state);
		if ( uca->zip )
			free(uca->zip);
		if ( uca->country )
			free(uca->country);
		if ( uca->access_code )
			free(uca->access_code);
		if ( uca->comment )
			free(uca->comment);
	}

    /* free all 4 user mallocs */
	for (i = 0; i < 4; i++) {
		PlayerAccount *placc;
		SDBUser *user;

		if ((user = box->users[i])) {

			if ((placc = &(user->playerAccount))) {
				/* free player account mallocs */
				if ( placc->openTaunt )
					free(placc->openTaunt);
				if ( placc->personInfo )
					free(placc->personInfo);
				if ( placc->customIcon )
					free(placc->customIcon);
				if ((placc->opaqueStore.buf))
					free(placc->opaqueStore.buf);
			}

			if ((user->incomingMail)) {
				SDBMail *sdb_mail;
				ListNode *node;
				ListNode *next;

				/* free the mail list and all it's data */
				for ( node = GetFirstListNode(user->incomingMail); node; ) {
					next = GetNextListNode(node);
					RemoveListNodeFromList(node);

					sdb_mail = (SDBMail *) GetListNodeData(node);
					if (sdb_mail) {
						if ( sdb_mail->mail )
							free(sdb_mail->mail);
						free(sdb_mail);
					}

					free(node);
					node = next;
				}

				free( user->incomingMail);
			}

			/* free the user struct */
			free(user);
		}
	}

	/* free the box account struct  */
	free(box);
}

//
// Temporary hack to convert passwords from old machine-specific format
// to readable ASCII format.  If it appears to be a binary password, it
// will be converted.
//
// Do we need to do this?  Not really - it would work either way - but
// it makes displaying the data *much* easier, and it may help us on
// future platforms.
//
// Known button values: 0x04, 0x08, 0x10, 0x20, 0x40, 0x80.
//
PRIVATE int
DataBase_CheckPW(long boxType, Password password)
{
	if (!password[0])	// no password?
		return (0);

	if (password[0] < 'A' || password[0] > 'Z') {
		Common_PasswordBinaryToAscii(boxType, password, password);	// change in place
		Logmsg("Converted password from bin to '%.8s'\n", password);
	}

	return (0);
}

