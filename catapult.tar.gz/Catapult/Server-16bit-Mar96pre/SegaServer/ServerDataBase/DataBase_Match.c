/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: DataBase_Match.c,v 1.43 1996/02/13 20:31:03 fadden Exp $
 *
 * $Log: DataBase_Match.c,v $
 * Revision 1.43  1996/02/13  20:31:03  fadden
 * Declare some read-only tables and their pointers as "const".
 *
 * Revision 1.42  1996/01/23  16:49:35  ted
 * Added Queue_Init to clear out a specific queue (in the Contestant struct).
 *
 * Revision 1.41  1996/01/22  16:10:18  ted
 * Major changes to support new vector-based matching algorithm.
 *
 * Revision 1.40  1996/01/10  14:50:17  hufft
 * use libphonedb
 *
 * Revision 1.39  1996/01/04  22:56:02  hufft
 * added pop mail
 *
 * Revision 1.38  1995/12/11  18:01:24  ansell
 * Moved some PLogmsg()s from LOGP_DBUG to higher priority since they
 * represented error conditions.
 *
 * Revision 1.37  1995/12/06  00:42:17  steveb
 * Ported to Solaris 2.4 (STDC && SVR4).
 *
 * Revision 1.36  1995/12/04  16:53:54  ted
 * Log reduction act: don't dump queues all the time. Lower visit logs from
 * NOTICE to DETAIL.
 *
 * Revision 1.35  1995/11/01  17:07:04  chs
 * When removing play history, don't assume that we've played the
 * other guy before.  This can happen if someone plays a tourney match
 * and then doesn't connect again until after we've cleared the history file.
 *
 * Revision 1.34  1995/10/30  16:45:11  ted
 * Fixed bug where I was freeing memory that was realloc'd.
 *
 * Revision 1.33  1995/10/25  16:15:48  chs
 * Add an interface for retrieving the opponent history of a box.
 * When removing the entire opponent history for a game,
 * just rename the file to file.old instead of deleting it.
 *
 * Revision 1.32  1995/10/19  22:29:12  hufft
 * Japan Database Changes
 *
 * Revision 1.31  1995/10/17  10:51:05  ted
 * Removed debug msg. Fixed BoxList dump formatting.
 *
 * Revision 1.30  1995/10/16  19:13:18  ted
 * Added new message kMatchCtl_ForgetBoxOpponentHistory to remove play history
 * from two boxes.  Cleaned up PlayHistory stuff. Display why a match is made or
 * skipped.
 *
 * Revision 1.29  1995/10/12  14:31:18  ted
 * Create historydir if not present in conf directory.
 *
 * Revision 1.28  1995/10/10  10:23:49  ted
 * Added tournament functionality for Sriram. Added previously played boxes to
 * growning list per box in history.gdbm file in conf/historydir directory. File can be
 * deleted with the kMatchCtl_KillPlayHistory message.
 *
 * Revision 1.27  1995/10/03  12:13:02  ted
 * #ifdef out TOURNEY code. Will change soon anyway. Added kLookLongFirst flag.
 *
 * Revision 1.26  1995/09/27  18:39:10  hufft
 * added Common_Phone support for Japan Server
 *
 * Revision 1.25  1995/08/28  13:11:42  ted
 * Only prevent long distance players from matching to same person in last hour.
 *
 * Revision 1.24  1995/08/17  18:05:59  ansell
 * Check return value from Match_InitializeContestant() for errors to see if
 * we need to bail out.
 *
 * Revision 1.23  1995/08/17  17:59:29  ted
 * Don't play someone more than once in the last hour! Can play someone if
 * they played under 3 minutes to allow peer connect failures to be rematched.
 *
 * Revision 1.22  1995/08/16  11:55:32  chs
 * Fix a bounds check on oppPlayer vs. player.
 * Just happened to notice this one.
 *
 * Revision 1.21  1995/08/08  18:52:56  ted
 * Change slightly how we traverse local calling areas in phone database.
 *
 * Revision 1.20  1995/07/19  10:55:23  ted
 * Preclipped to matchAvgWait rather than matchMaxWait.
 *
 * Revision 1.19  1995/07/17  12:27:21  ted
 * Broke out input contestant struct size and internal contestant data to reduce
 * throughput over sockets to matchers. Added wait time preference from boxes.
 * Only SNES currently uploads this option. Don't expire contestants when matchers
 * are bounced (big one).
 *
 * Revision 1.18  1995/06/08  11:18:38  ted
 * Reference gLata is now a pointer.
 *
 * Revision 1.17  1995/05/28  20:41:10  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		DataBase_Match.c

	Contains:	XBAND Player Match Engine

	Written by:	Ted Cohn, 1994, 1995.


	Change History (most recent first):

		<19>	 12/6/94	HEC		Implement new specific challenge logic due to new policy
									devision: bail if no match found - don't do automatch. Also
									tweak phone uses new FL dialing pattern flag.
		<18>	 12/3/94	HEC		Don't force core on cleanshutdown request.
		<17>	 12/2/94	HEC		Fixed challengee not getting matched with specific challenger.
		<16>	11/29/94	HEC		Fixed real player matching. Avoid making people wait who switch
									during low traffic.
		<15>	11/27/94	HEC		Changes exit's to Matching_Abort to dump core. Backed out latest
									change to Match_Auto to avoid FOOBAR's. Related to new player
									matching.
		<14>	11/23/94	HEC		Added FindRealLongMatch so we match long distance people first
									to real players waiting.
		<13>	11/23/94	HEC		Make dumpqueues brief. Make shunted spec-to-auto players wait.
		<12>	11/22/94	HEC		Print how the match was made in the log.
		<11>	11/19/94	HEC		New Player stuff.
		<10>	11/18/94	HEC		Round up box wait time to the nearest minute.
		 <9>	11/16/94	HEC		PlayAgain matches beyond timeout.
		 <8>	11/14/94	HEC		Make VIPs wait only short time if made slaves.
		 <7>	11/13/94	HEC		New features: wait estimation, ranking traffic switch, and
									recently played traffic switch. Scarey!
		 <6>	 11/9/94	HEC		In Match_Specific, check slave->challengeFlags ==
									kIgnoreChallenges, not slave->challengeFlags !=
									kAcceptChallenges
		 <5>	 11/9/94	HEC		Added WaitingForAnother check when looking long distance.
		 <4>	 11/8/94	HEC		Added Match_Control_DequeueContestant proc.
		 <3>	 11/7/94	HEC		Fixed reregister wait time bug.
		 <2>	 11/7/94	HEC		Minor changes to help track down specific match problem.
		 <1>	 11/7/94	HEC		first checked in
*/

/********************************************************************************
	INCLUDES
********************************************************************************/

#include <sys/types.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <time.h>
#include <stdarg.h>
#include <string.h>
#include <fcntl.h>
#include <memory.h>
#include <values.h>
#include <gdbm.h>
#include <sys/stat.h>
#include <errno.h>
#include "Errors.h"
#include "BINTree.h"
#include "ServerDataBase.h"
#include "ServerDataBase_priv.h"
#include "PhoneDB.h"
#include "DataBase_Match.h"
#include "Common.h"
#include "Common_Log.h"
#include "Common_ReadConf.h"
#include "Common_Missing.h"

#undef DEBUG

#ifdef MATCHSIM
long simtime(void);
#define time(_x) simtime()
#else
#define time(_x) time(_x)
#endif

/********************************************************************************
	INPUT FLAGS

	� kNewPlayerFlag
		Lower threshold for more immediate match.

	� kShortWaitFlag
		Obsolete. This should be passed in as a wait flag.

	� kForceSlave
		Don't attempt to match, just put on ice. DONE

	� kForceMaster
		Attempt match. Threshold is set to 0 so any viable match is made. Note
		that some suitability values may be negative which means the master
		absolutely cannot match to a given slave.

	� kForceAcceptChallengeFlag
		Ignore slave's challenge flags. NOT IMPLEMENTED?

	��kTournamentFlag
		Only tourney players can be matched together.

	��kLookLongFirst
		Obsolete.

********************************************************************************/

/********************************************************************************
	GLOBALS		
********************************************************************************/

static const GameInfo *	gGameInfo = NULL;			// info about our game
static long				gInitialized = 0;			// set if ready to rock n' roll
static time_t			gNow = 0;					// for optimized searching
static RegionGlobals	gRegion;					// statistics and stuff
static time_t			gLastExpire = 0;			// when we last expired slaves

/********************************************************************************
	QUEUES/TREES		
********************************************************************************/

static char *			gQueueName[] = { "LOCAL", "LONG", "XBN" };
static Tree				gGlobalTree;				// all waiting contestants
static Tree				gSpecTree;					// player list waiters
static Queue			*gLocalQueue;				// array of local calling queues
static Queue			gQueue[kMaxQueues];			// local, long, and xbn queues
													// (NOTE: gLocalQueue used for local)

/********************************************************************************
	TOURNEY SUPPORT		
********************************************************************************/

GDBM_FILE				gDBF = NULL;
BoxList					*gBoxList = NULL;
char					gHistoryFile[128];

/********************************************************************************
	SUITABILITY		
********************************************************************************/

double gScoreWeightSum = 0;			// sum of weights after bounce:
									//    gConfig.matchSkillWeight
									//    gConfig.matchWaitWeight
									//    gConfig.matchPlayWeight

/********************************************************************************
	LOCAL PROTOTYPES
********************************************************************************/

// MAIN

static void	Match_Auto(ContestantPtr contestant, Matchup *matchup);
static void Match_Specific(ContestantPtr caller, Matchup *matchup);
static Err	Match_Matchup(ContestantPtr master, ContestantPtr slave, Matchup *matchup);
static long	Match_Enqueue(ContestantPtr slave, Matchup *matchup, time_t now);

// SCORING/TRAFFIC/THRESHOLDS

static void ScoreLocalArea(ContestantPtr caller, ContestantPtr *bestSlave, long *bestScore);
static void ScoreQueue(ContestantPtr caller, long qindex, eid_t eid,
			ContestantPtr *bestSlave, long *bestScore);
static long ScorePlayers(ContestantPtr caller, ContestantPtr slave, long *ago);
static void BumpCallerTraffic(ContestantPtr caller);
static double BumpTraffic(Traffic *traffic);
static void SetThresholds(ContestantPtr caller);

// QUEUE RELATED

static void Queue_Init(ContestantPtr slave, long qindex);
static void Queue_Add(ContestantPtr slave, long qindex);
static void Queue_Dump(long qindex);
static void Queue_Remove(ContestantPtr slave, long qindex);
static Err	Match_AddToGlobal(ContestantPtr slave);
static Err	Match_AddToSpecific(ContestantPtr slave);
static void Match_Dequeue(ContestantPtr player);
static Err	Match_DequeueIfQueued(ContestantPtr caller, Matchup *matchup);
static void Match_Control_DequeueContestant(MatchControl_DequeueContestant *matchControl);

// DISPLAY

static void	Match_DumpQueues(long brief);
static void	Match_DumpContestant(ContestantPtr contestant, int brief);
static void	Match_PrintStats(void);

// PLAY HISTORY (TOURNIES)

static long Match_OpenHistoryFile(long create);
static void Match_CloseHistoryFile(void);
static void Match_KillHistoryFile(void);
static BoxList *Match_GetBoxHistory(long box);
static MatchControlResult *Match_GetOpponentHistory(long box);
static void Match_AddBoxHistory(BoxList **list, long box, long opp);
static void Match_RemPlayHistory(long box, long opp);
static long Match_PlayedBefore(BoxList *list, long box);
static void Match_WriteBoxHistory(BoxList *list, long box);

// BINTREE PROCS

static long Compare_BoxProc(void *key1, void *vbsn2);
static long Compare_InsertBoxProc(void *key1, void *key2);
static long Compare_MatchBoxProc(void *key1, void *key2);
static long Compare_OppBoxProc(void *key1, void *key2);
static void DumpContestantProc(BINNodePtr t, long refcon);

// UTILS

static void	Match_Bounce(void);
static long Match_FindMyChallenger(ContestantPtr contestant, Matchup *matchup);
static ContestantPtr FindGlobalSlave(BoxSerialNumber *bsn, long notExpired);
static long WaitingForAnother(ContestantPtr caller, ContestantPtr slave);
static long IsTollCall(ContestantPtr master, ContestantPtr slave);
static void FreeStructs(void);
static char *boxNumString(BoxSerialNumber *box, long player);
static void	dumpboxlist(long box, BoxList *);
static int longcompare(const void *i, const void *j);
static long PlayedBefore(ContestantPtr slave, ContestantPtr caller);
static long	Match_TweakOpponentPhoneNumber(ContestantPtr caller, phoneNumber *oppOrigPhone, phoneNumber *oppPhone);
static Err	Match_InitializeContestant(ContestantPtr caller);
static Err 	Match_SanityCheckContestant(ContestantPtr contestant);
static long	Match_EstWait(ContestantPtr caller);
static void Match_ExpireContestant(ContestantPtr slave);
static void	Match_ExpireContestants(time_t now);

#ifdef UNUSED
static void DumpMatchup(Matchup *matchup);
#endif

#ifdef __svr4__
static void Match_Exit(void);
#else
static void Match_Exit(int status, int arg);
#endif /* __svr4__ */


/********************************************************************************
	THE CODE!
********************************************************************************/

//
// Do all sorts of fascinating things.
//
// The result sometimes has to be allocated dynamically, and can't be
// freed until the next time we get control back from the RPC stuff.  So
// we either return a pointer to a static struct, or a pointer to dynamic
// mem that gets freed next time through.
//
// Returns NULL on error.
//
MatchControlResult *
Match_Control(MatchControl *matchControl)
{
#if	0
	static MatchControlResult *result = NULL;
#endif
	static MatchControlResult_Status resultStatus = {
		kMatchCtlRes_Status, 0, 0 };
	time_t now;

	gNow = time(0);
	gRegion.numConnections++;		// incr for every RPC function
	if (!gInitialized) {
		PLogmsg(LOGP_FLAW, "Matcher was not initialized, aborting.\n");
		Matching_Abort();
		return (NULL);
	}

	gRegion.numConnections++;		// incr for every RPC function

	Logmsg("CONTROL: rcvd request %ld\n", matchControl->type);

	// Handle this request.
	//
	switch (matchControl->type) {
	case kMatchCtl_Ping:
		resultStatus.result = kNoError;
		return ((MatchControlResult *) &resultStatus);
	
	case kMatchCtl_Shutdown:
		if (matchControl->shutdown.validate == kMatchShutdownValidate) {
			PLogmsg(LOGP_NOTICE, "kMatchCtl_Shutdown message.\n");
			Match_Shutdown();
			Flush_Logmsg();
			exit(0);
		} else {
			PLogmsg(LOGP_NOTICE, "WARNING: Bogus shutdown request (0x%.8lx)\n",
				matchControl->shutdown.validate);
			resultStatus.result = kFucked;
			return ((MatchControlResult *) &resultStatus);
		}
	
	case kMatchCtl_Reload:
		PLogmsg(LOGP_NOTICE, "kMatchCtl_Reload message.\n");
		Reconfigure();
		Match_Bounce();
		resultStatus.result = kNoError;
		return ((MatchControlResult *) &resultStatus);
	case kMatchCtl_DoExpire:
		PLogmsg(LOGP_NOTICE, "kMatchCtl_DoExpire message.\n");
		if ((now = matchControl->doExpire.when) == 0)
			now = time(0);
		Match_ExpireContestants(now);
		resultStatus.result = kNoError;
		return ((MatchControlResult *) &resultStatus);
	
	case kMatchCtl_DequeueContestant:
		PLogmsg(LOGP_NOTICE, "kMatchCtl_DequeueContestant message.\n");
		Match_Control_DequeueContestant((MatchControl_DequeueContestant *) matchControl);
		resultStatus.result = kNoError;
		return ((MatchControlResult *) &resultStatus);
	
	case kMatchCtl_GetQueues:
#if	0
		result = (MatchControlResult *)
		Match_Control_GetQueues((MatchControl_GetQueues *) matchControl);
		return (result);
#endif
		return NULL;
	
	case kMatchCtl_GetContestant:
		//return ( (MatchControlResult *) Match_Control_GetContestant(
		//	(MatchControl_GetContestant *) matchControl) );
		return NULL;
	
	case kMatchCtl_GrabContestant:
	case kMatchCtl_SetContestant:
	case kMatchCtl_CreateContestant:
		PLogmsg(LOGP_NOTICE, "WARNING: unimplemented control function\n");
		resultStatus.result = kFucked;
		return ((MatchControlResult *) &resultStatus);
	
	case kMatchCtl_KillPlayHistory:
		PLogmsg(LOGP_NOTICE, "kMatchCtl_KillHistoryDatabase message.\n");
		Match_KillHistoryFile();
		resultStatus.result = kNoError;
		return ((MatchControlResult *) &resultStatus);
	
	case kMatchCtl_ForgetBoxOpponentHistory:
	    {
		struct MatchControl_ForgetBoxOpponentHistory *mc_fboh;
		mc_fboh = (void *)matchControl;
		PLogmsg(LOGP_NOTICE, "kMatchCtl_ForgetBoxOpponentHistory message.\n");
		Match_RemPlayHistory(mc_fboh->box1.box, mc_fboh->box2.box);
		Match_RemPlayHistory(mc_fboh->box2.box, mc_fboh->box1.box);
		resultStatus.result = kNoError;
		return ((MatchControlResult *) &resultStatus);
	    }
	case kMatchCtl_GetOpponentHistory:
	    {
		struct MatchControl_GetOpponentHistory *mc_goh;
		mc_goh = (void *)matchControl;

		return Match_GetOpponentHistory(mc_goh->box.box);
	    }
	default:
		PLogmsg(LOGP_FLAW, "ERROR: unrecognized control request\n");
		return (NULL);
	}
	/*NOTREACHED*/
}


static MatchControlResult *
Match_GetOpponentHistory(long box)
{
    static MatchControlResult mcr;
    BoxList *bl;

    bl = Match_GetBoxHistory(box);
    if (bl == NULL) {
	mcr.getHistory.result = kFucked;
	return &mcr;
    }

    mcr.getHistory.result = 0;
    mcr.getHistory.count = bl->items;
    memcpy(mcr.getHistory.boxes, bl->boxes, bl->items * sizeof(long));
    return &mcr;
}


static void
Match_Control_DequeueContestant(MatchControl_DequeueContestant *matchControl)
{
	ContestantPtr slave;
	
	slave = FindGlobalSlave(&matchControl->boxSerialNumber, 1);
	if (!slave)
		return;

	PLogmsg(LOGP_NOTICE,"Control_DequeueContestant: removing %ld: '%s' %s (%s)\n",
		slave->in.contestantID,
		slave->in.userName,
		boxNumString(&slave->in.boxSerialNumber, slave->in.player),
		slave->in.boxPhoneNumber.phoneNumber);
	Match_Dequeue(slave);
	free(slave);
}

//
// Initialize our little world.
//
// Returns 1 on success, 0 on failure.
//
Err
Match_Startup(long platformID, long gameID)
{
	gNow = time(0);
	if (gInitialized)
	{
		PLogmsg(LOGP_PROGRESS, "Match_Startup already initialized!\n");
		return 0;
	}

#ifdef __svr4__
	atexit(Match_Exit);
#else
	if (on_exit(Match_Exit, 0))
	{
		PLogmsg(LOGP_FLAW, "on_exit(Match_Exit) failed.\n");
		Matching_Abort();
	}
#endif /* __svr4 */

#ifdef __svr4__
    srand(time(0));
#else
    srandom(time(0));       // seed the random number generator
#endif /* __svr4__ */

	memset(&gRegion, 0, sizeof(RegionGlobals));
	gRegion.startTime = time(0);
	if ((gGameInfo = Common_GameInfoForGame(platformID, gameID)) == NULL) {
		PLogmsg(LOGP_FLAW, "ERROR: unable to find game info for %.4s-0x%.8lx\n",
			(char *)&platformID, gameID);
		return 0;
	}
	Match_Bounce();

	gInitialized = 1;
	PLogmsg(LOGP_PROGRESS, "Match_Startup successful.\n");
	return 1;
}

#ifdef __svr4__
static void Match_Exit(void)
#else
static void Match_Exit(int status, int arg)
#endif /* __svr4__ */
{
	Match_CloseHistoryFile();
}

static void
Match_Bounce(void)
{
	Match_PrintStats();

	// Form name of play history database

	Match_CloseHistoryFile();	// reopen lazily

#ifdef MATCHSIM
	sprintf(gHistoryFile,
		"history.0x%08lx.gdbm",
		gGameInfo->gameID);
#else
	sprintf(gHistoryFile,
		"%s/history.0x%08lx.gdbm",
		gConfig.matchHistoryDirectory,
		gGameInfo->gameID);
#endif

	// Expire contestants only if we had to reload the phone database
	// because the exchange information could be completely different.
	if (PhoneDB_Reload())
	{
		Match_ExpireContestants(0);	// expire everyone!

		BINInit(&gSpecTree.tree);
		BINInit(&gGlobalTree.tree);

		FreeStructs();
	
		// re-alloc structs
		gLocalQueue = (Queue *) calloc(PhoneDB_EidCount() + 1, sizeof(Queue));
		if (gLocalQueue == NULL)
		{
			PLogmsg(LOGP_FLAW,"Could not alloc gLocalQueue (%ld bytes). Aborting.\n",
				(PhoneDB_EidCount() + 1)*sizeof(Queue));
			Matching_Abort();
		}
	}
	Logmsg("gHistoryFile = %s\n", gHistoryFile);
	Logmsg("gConfig.matcherLogName       = %ls\n", gConfig.matcherLogName);
	Logmsg("gConfig.matchMinWait         = %ld (seconds)\n", gConfig.matchMinWait);
	Logmsg("gConfig.matchMaxWait         = %ld (seconds)\n", gConfig.matchMaxWait);
	Logmsg("gConfig.matchAvgWait         = %ld (seconds)\n", gConfig.matchAvgWait);
	Logmsg("gConfig.matchSlopWait        = %ld (seconds)\n", gConfig.matchSlopWait);
	Logmsg("gConfig.matchSpecWait        = %ld (seconds)\n", gConfig.matchSpecWait);
	Logmsg("gConfig.matchSkillWeight     = %.1f\n", gConfig.matchSkillWeight);
	Logmsg("gConfig.matchWaitWeight      = %.1f\n", gConfig.matchWaitWeight);
	Logmsg("gConfig.matchPlayWeight      = %.1f\n", gConfig.matchPlayWeight);
	Logmsg("gConfig.matchMinThreshold    = %ld [0,1000]\n", gConfig.matchMinThreshold);
	Logmsg("gConfig.matchMaxThreshold    = %ld [0,1000]\n", gConfig.matchMaxThreshold);
	Logmsg("gConfig.matchThresholdCoeff  = %.1f\n", gConfig.matchThresholdCoeff);
	
	gScoreWeightSum = gConfig.matchSkillWeight
					+ gConfig.matchWaitWeight
					+ gConfig.matchPlayWeight;
}

/********************************************************************************
	Description:
		Shut the matcher down. Dumps stats before bailing.
		Returns 1 on success, 0 on failure.
********************************************************************************/
void
Match_Shutdown(void)
{
	time_t now;

	if (!gInitialized) {		// didn't start up, don't shut down
		PLogmsg(LOGP_FLAW, "GLITCH: Shutdown without Startup!\n");
		return;
	}

	now = time(0);

	// This is just to make the stats pretty, in case nobody has logged
	// in for a while and we've got a bunch of guys sitting around
	// waiting to be expired.
	//
	Match_DumpQueues(MDC_VERBOSE);
	Match_ExpireContestants(0);		// expire everyone!
	Match_DumpQueues(MDC_VERBOSE);
	Match_PrintStats();
	FreeStructs();
	gInitialized = 0;
	Logmsg("Match_Shutdown successful.\n");
}

static void
Match_PrintStats(void)
{
	Logmsg("\n");
	Logmsg("########## MATCHING STATS for game '%s' (0x%08lx)\n",
		gGameInfo->gameName,gGameInfo->gameID);

	// These ought to be LOGP_DBUG, but we don't currently have any way
	// of saving these in a database (and I haven't even implemented the
	// retrieval call yet).  Besides, they're colorful.
	//
	// Little-known facts about the statistics:
	//	(where "successes" is numSpecificSuc + numAutoSuc + numAutoSpecSuc)
	//	- numSpecificReq + numAutoReq == numRequests
	//	- (successes) + numFailedReq + numTimeouts + numRequeued == numRequests
	//	- numEnqueued + (successes/2) + numFailedReq == numRequests
	//	- numTimeouts + (successes/2) + numRequeued == numEnqueued
	//
	// (May have hosed these with kLeaveOnQueue...)
	//
	Logmsg("  startTime 0x%.8lx, elapsed time %ld minutes %ld seconds\n",
		gRegion.startTime,
		(gNow - gRegion.startTime) / 60,
		(gNow - gRegion.startTime) % 60);
	Logmsg("  numConnections      %ld\n", gRegion.numConnections);
	Logmsg("  numRequests         %ld\n", gRegion.numRequests);
	Logmsg("  numFailedReq        %ld\n", gRegion.numFailedReq);
	Logmsg("  numLongDistance     %ld\n", gRegion.numLongDistance);
	Logmsg("\n");
	Logmsg("  numMatches          %ld\n", gRegion.numMatches);
	Logmsg("  numSpecWait         %ld\n", gRegion.numSpecWait);
	Logmsg("  numAutoWait         %ld\n", gRegion.numAutoWait);
	Logmsg("  numSpecificReq      %ld\n", gRegion.numSpecificReq);
	Logmsg("  numSpecificSuc      %ld\n", gRegion.numSpecificSuc);
	Logmsg("  numAutoReq          %ld\n", gRegion.numAutoReq);
	Logmsg("  numAutoSuc          %ld\n", gRegion.numAutoSuc);
	Logmsg("  numAutoSpecificSuc  %ld\n", gRegion.numAutoSpecificSuc);
	Logmsg("\n");
	Logmsg("  numEnqueued         %ld\n", gRegion.numEnqueued);
	Logmsg("  numDequeued         %ld\n", gRegion.numDequeued);
	Logmsg("  numTimeouts         %ld\n", gRegion.numTimeouts);
	Logmsg("  numRequeued         %ld\n", gRegion.numRequeued);
	Logmsg("  numReborn           %ld\n", gRegion.numReborn);
	Logmsg("  timeEnqueued        %ld\n", gRegion.timeEnqueued);
	Logmsg("  predictorError      %ld\n", gRegion.predictorError);
	Logmsg("\n");
	if (gRegion.numRequests)
	{
		Logmsg("  match ratio:        %ld%%\n",100*gRegion.numMatches/gRegion.numRequests);
		Logmsg("  timeout ratio:      %ld%%\n",100*gRegion.numTimeouts/gRegion.numRequests);
	}
}

/********************************************************************************
	Description:
		- If specific request, find or wait for that opponent; don't
		  put on general queue.
		- If not specific request & accept challenges, search for opponents that
		  have challenged you.
		- If not accept challenges, or general request, search for general opponent.		
********************************************************************************/

Matchup *
Match_FindMatch(ContestantPtr caller)
{
	static Matchup matchup;

	gNow = time(0);
	gBoxList = NULL;

	if (!gInitialized) {
		PLogmsg(LOGP_FLAW, "Matching was not initialized, aborting.\n");
		Matching_Abort();
		return (NULL);
	}

	//
	// Init the matchup struct.
	//
	memset(&matchup, 0, sizeof(Matchup));

	//
	// Look for deadwood every so often.
	//
	if (gNow - gLastExpire > kExpireInterval)
		Match_ExpireContestants(gNow);

	//
	// Sanity-check the contestant args.
	//
	if ((matchup.result = Match_SanityCheckContestant(caller)) != kNoError)
		goto bail;

	gRegion.numRequests++;			// incr for all requests

	//
	// Initialize the rest of the fields.
	//
	if ((matchup.result = Match_InitializeContestant(caller)) != kNoError)
		goto bail;

	Logmsg("\n");
	Logmsg("********** NEW %s CONTESTANT for %s (0x%08lx)\n",
		caller->in.challengeFlags == kSpecificChallenge ? "SPECIFIC" : "AUTO",
		gGameInfo->gameName,
		gGameInfo->gameID);

	Match_DumpContestant(caller, MDC_VERBOSE);
	// If caller has tourney bit set, get previously played opponents
	if (caller->in.flags & kTournamentFlag)
	{
		gBoxList = Match_GetBoxHistory(caller->in.boxSerialNumber.box);
		if (gBoxList != NULL)
			dumpboxlist(caller->in.boxSerialNumber.box, gBoxList);
	}

	//
	// If he's on a queue already, deal with it appropriately.
	//
	if (Match_DequeueIfQueued(caller, &matchup)) {
		// He was already on an auto-match queue for this game, and signed
		// up for another.  Throw the mangy bastard out on his ear.
		//
		goto bail;
	}

	//
	// Find a match
	//
	BumpCallerTraffic(caller);
	SetThresholds(caller);

	if (caller->in.challengeFlags == kSpecificChallenge)
		gRegion.numSpecificReq++;
	else
		gRegion.numAutoReq++;

	matchup.result = kMatchWait;	// default wait

	if (!(caller->in.flags & kForceSlave))
	{
		switch (caller->in.challengeFlags)
		{
			case kSpecificChallenge:
				Match_Specific(caller, &matchup);
				break;
			
			case kAcceptChallenges:
				if (Match_FindMyChallenger(caller, &matchup))
					break;
				// else fall thru to auto match
	
			case kIgnoreChallenges:
				Match_Auto(caller, &matchup);
				break;
	
			default:
				PLogmsg(LOGP_FLAW,
					"How the HELL did we get here?  Stupid sanity checker.\n");
				Matching_Abort();
				matchup.result = kFucked;
				break;
		}
	}
	if (matchup.result == kMatchWait)
		if (caller->in.flags & kForceMaster)
			matchup.result = kCannotForceMaster;
		else
			Match_Enqueue(caller, &matchup, time(0));

	//****************************************************************
	// NOTE: CALLER AND OPPONENT RECORDS HAVE BEEN FREED AT THIS POINT
	//****************************************************************
bail:
	// A failed request is anything that doesn't end up as "wait" or "dial".
	// (This may change.)
	//
	if (matchup.result != kMatchDial && matchup.result != kMatchWait)
		gRegion.numFailedReq++;

	//
	// Return the Matchup struct to the caller.
	// 
	Logmsg("RETURNING: ");
	switch (matchup.result)
	{
		case kMatchDial:
			Logmsg("kMatchDial\n");
			break;
		case kMatchWait:
			Logmsg("kMatchWait\n");
			break;
		case kChallengeeWaitingForDifferentUser:
			Logmsg("kChallengeeWaitingForDifferentUser\n");
			break;
		case kChallengeeNotAvailable:
			Logmsg("kChallengeeNotAvailable\n");
			break;
		case kChallengeeWaitingForAutoMatch:
			Logmsg("kChallengeeWaitingForAutoMatch\n");
			break;
		case kChallengeeTooFar:
			Logmsg("kChallengeeTooFar\n");
			break;
		case kLeaveOnQueue:
			Logmsg("kLeaveOnQueue\n");
			break;
		case kChallengeeWaitingForDifferentGame:
			Logmsg("kChallengeeWaitingForDifferentGame\n");
			break;
		case kDifferentRomVersion:
			Logmsg("kDifferentRomVersion\n");
			break;
		case kCannotForceMaster:
			Logmsg("kCannotForceMaster\n");
			break;
		default:
			Logmsg("%ld\n", matchup.result);
			break;
	}
	if (gConfig.logWriteThresh < LOGP_DETAIL )
		Match_DumpQueues(MDC_VERBOSE);
	if (gBoxList != NULL)
	{
		free(gBoxList);
		gBoxList = NULL;
	}
	return &matchup;
}


/********************************************************************************
	Find a specific player waiting on the queue. If not found, return so we can
	wait for him. Otherwise, return why we could not match against him.
********************************************************************************/

static void
Match_Specific(ContestantPtr caller, Matchup *matchup)
{
	ContestantPtr slave;
	long err;

	Logmsg("Searching for Specific Opponent\n");
	// is requested opponent waiting for us?
	slave = FindGlobalSlave(&caller->in.oppBoxSerialNumber, 0);
	
	// requested opponent cannot be found
	if (!slave)
	{
		Logmsg("Specific opponent not found -- wait for him to show up\n");
		return;	// wait for specific opponent to show up
	}
	// We found him! Check references...
	
	// Same game patch vers?
	if (caller->in.gamePatchVersion != slave->in.gamePatchVersion)
	{
		// "our" fault, so let user wait for auto match
		caller->in.challengeFlags = kAcceptChallenges;
		matchup->specificShunt = kDifferentRomVersion;
		caller->in.xbndial = caller->in.xbncallable = caller->in.billme = 0;
		Logmsg("Shunting from specific to auto because patch versions differ\n");
		Logmsg("  Set xbndial = xbncallable = billme = 0\n");
		return;	
	}

	// Is he waiting for someone else?
	if (WaitingForAnother(caller,slave))
	{
		matchup->result = kChallengeeWaitingForDifferentUser;
		return;
	}
	
	// Does he accept challenges?
	if (!(slave->in.flags & kForceAcceptChallengeFlag)
	&& slave->in.challengeFlags == kIgnoreChallenges)
	{
		matchup->result = kChallengeeWaitingForAutoMatch;
		return;
	}

	if ((err = IsTollCall(caller,slave)))
	{
		matchup->result = err;
		return;
	}
	
	PLogmsg(LOGP_DBUG,"matched!\n");\
	Match_Matchup(caller, slave, matchup);
	return;	
}

/********************************************************************************
		Find those that have challenged our caller. Only should be called if the
		player accepts challenges.
		RETURN: 1 if found, 0 if not found
********************************************************************************/

static long
Match_FindMyChallenger(ContestantPtr caller, Matchup *matchup)
{
	void *node;

	// Look up slave using master's boxSerialNumber
	// in tree sorted by masters' box serial numbers.
	BINSetDeleteProc(0);
	BINSetCompareProc((BINCMPProc) Compare_MatchBoxProc);
	node = BINSearch(gSpecTree.tree.root, caller);
	if (!node)
	{
		Logmsg("No Challengers Found\n");
		return 0;
	}
	Logmsg("Found Specific Challenger\n");
	Match_Matchup(caller, SPEC_TO_CONTESTANT(node), matchup);
	return 1;
}

static void
Match_Auto(ContestantPtr caller, Matchup *matchup)
{
	long score;
	long bestScore = kNoScore;
	ContestantPtr slave;
	ContestantPtr bestSlave = NULL;

	ScoreLocalArea(caller, &slave, &score);
	if (score > bestScore)
	{
		bestScore = score;
		bestSlave = slave;
	}
	if (caller->in.callLongDistance)
	{
		if (caller->in.xbndial)
			ScoreQueue(caller, kXBNQueue, 0, &slave, &score);
		else
			ScoreQueue(caller, kLongQueue, 0, &slave, &score);
		if (score > bestScore)
		{
			bestScore = score;
			bestSlave = slave;
		}
	}
	if (bestSlave)
		Match_Matchup(caller, bestSlave, matchup);
}

static long
Match_Enqueue(ContestantPtr contestant, Matchup *matchup, time_t now)
{
	// Fill out the queue-related fields in the "Contestant" structure.
	ContestantPtr slave;
	
	// Copy contestant for cold storage
	slave = (ContestantPtr)malloc(sizeof(Contestant));
	if (!slave)
	{
		Logmsg("Can't duplicate contestant for wait queue\n");
		Matching_Abort();	
	}
	memcpy(slave,contestant,sizeof(Contestant));

	gRegion.numEnqueued++;
	slave->queuedWhen = now;
	slave->stopWhen = now + Match_EstWait(slave);
	slave->expireWhen = slave->stopWhen + gConfig.matchSlopWait;

	// Fill out matchup structure

	matchup->result = kMatchWait;
	matchup->magicCookie = slave->in.contestantID;
	matchup->randomVal = slave->randomVal;
	matchup->matchOrExpWhen = slave->expireWhen;

	// Add slave to queues
	
	Match_AddToGlobal(slave);
	Logmsg("ENQUEUE: %ld (%s), %ld globals, ",
		slave->in.contestantID, slave->in.userName,gGlobalTree.tree.members);

	if (slave->in.challengeFlags == kSpecificChallenge)
	{
		gRegion.numSpecWait++;
		Match_AddToSpecific(slave);
		Logmsg("%ld specific for %s), ",
			gSpecTree.tree.members,
			boxNumString(&slave->in.oppBoxSerialNumber,slave->in.oppPlayer));
	}
	else
	{
		gRegion.numAutoWait++;
		Queue_Add(slave, kLocalQueue);
		Queue_Add(slave, kLongQueue);
		if (slave->in.xbncallable)
			Queue_Add(slave, kXBNQueue);
	}

	Logmsg("wait %ld:%02ld, stop at %ld:%02ld\n",
		(slave->expireWhen-slave->queuedWhen)/60,
		(slave->expireWhen-slave->queuedWhen)%60,
		(slave->stopWhen-slave->queuedWhen)/60,
		(slave->stopWhen-slave->queuedWhen)%60);
	return(kNoError);
}

static long
Match_Matchup(ContestantPtr master, ContestantPtr slave, Matchup *matchup)
{
	char phone1[20], phone2[20];

	if (master == NULL || slave == NULL || matchup == NULL) {
		Logmsg("NULL args to Match_Matchup, bailing.\n");
		Matching_Abort();
		return 0;
	}
	
	if (master == slave)
	{
		Logmsg("BIG FOOBAR: Why is master the same as slave?\n");
		Matching_Abort();	
	}

	// Fill out the Matchup structure.
	//
	matchup->result = kMatchDial;
	matchup->magicCookie = master->in.contestantID;
	matchup->randomVal = slave->randomVal;
	matchup->matchOrExpWhen = gNow;
	matchup->oppMagicCookie = slave->in.contestantID;
	matchup->oppBoxSerialNumber = slave->in.boxSerialNumber;
	matchup->oppPlayer = slave->in.player;
	matchup->oppSpecific = (slave->in.challengeFlags == kSpecificChallenge);
	matchup->oppPhoneNumber = slave->in.boxPhoneNumber;
	matchup->oppOrigPhoneNumber = slave->in.boxPhoneNumber;
	matchup->oppRankingInfo = slave->in.ranking;
	matchup->oppTollCall = Match_TweakOpponentPhoneNumber(master, &matchup->oppOrigPhoneNumber,
		&matchup->oppPhoneNumber);
	matchup->xbnslave = slave->in.xbn;
	matchup->xbnmaster = master->in.xbn;
	matchup->xbndial = master->in.xbndial;
	matchup->billslave = slave->in.billme;
	matchup->billmaster = master->in.billme;
	matchup->oppInputFlags = slave->in.flags;
	strcpy(matchup->oppUserName, slave->in.userName);

	// Pull the opponent off our trees & queues.
	//
	Match_Dequeue(slave);
	gRegion.timeEnqueued += gNow - slave->queuedWhen;

	// Update the game "success" statistics.
	//
	gRegion.numMatches += 2;						// both: succeeded

	Common_PhoneFormatDisplay(master->in.boxPhoneNumber.phoneNumber,phone1);
	Common_PhoneFormatDisplay(slave->in.boxPhoneNumber.phoneNumber,phone2);

	Logmsg("MATCH: '%s' %ld:%ld:%ld %s calls(%s) '%s' %ld:%ld:%ld %s (waited %ld:%02ld)\n",
		master->in.userName,
		master->in.boxSerialNumber.box,
		master->in.boxSerialNumber.region,
		master->in.player,
		phone1,
		matchup->oppTollCall ? "toll" : "local",
		slave->in.userName,
		slave->in.boxSerialNumber.box,
		slave->in.boxSerialNumber.region,
		slave->in.player,
		phone2,
		(gNow - slave->queuedWhen)/60,
		(gNow - slave->queuedWhen)%60
	);
	switch (master->in.challengeFlags)
	{
	case kIgnoreChallenges:						// both: successful auto
		gRegion.numAutoSuc += 2;
		break;

	case kAcceptChallenges:
		gRegion.numAutoSuc++;					// me: successful auto

		switch (slave->in.challengeFlags)
		{
		case kIgnoreChallenges:
		case kAcceptChallenges:
			gRegion.numAutoSuc++;				// him: successful auto
			break;
		case kSpecificChallenge:
			gRegion.numAutoSpecificSuc++;		// him: successful specific
			break;
		}
		break;

	case kSpecificChallenge:
		switch (slave->in.challengeFlags)
		{
		case kIgnoreChallenges:
			// this should be impossible
			Logmsg("Ignore is impossible!\n");
			break;
		case kAcceptChallenges:
			gRegion.numAutoSpecificSuc++;		// me: successful specific
			gRegion.numAutoSuc++;				// him: successful auto
			break;
		case kSpecificChallenge:
			gRegion.numSpecificSuc += 2;		// both: successful specific
			break;
		}
		break;

	default:
		Logmsg(" - Bogus challengeFlags %ld in Matchup!\n",
			master->in.challengeFlags);
		break;
	}
	if (master->in.flags & kTournamentFlag)
	{
		Match_AddBoxHistory(&gBoxList,
			master->in.boxSerialNumber.box,
			slave->in.boxSerialNumber.box);
	}
	return 0;
}

static void
Match_Dequeue(ContestantPtr player)
{
	BINDelete(&gGlobalTree.tree, &player->globalTreeNode);
	BINDelete(&gSpecTree.tree, &player->specTreeNode);

	Queue_Remove(player, kLocalQueue);
	Queue_Remove(player, kLongQueue);
	Queue_Remove(player, kXBNQueue);
	Queue_Remove(player, kGlobalQueue);

	gRegion.numDequeued++;
	Logmsg("DEQUEUE: '%s' (%ld)\n",
		player->in.userName,
		player->in.contestantID
	);
	
	if (player->in.challengeFlags != kSpecificChallenge)
	{
		gRegion.predictorError += abs(gNow - player->stopWhen);
	}
}

//
// If this guy (or anybody else from his box) is already on a queue
// somewhere, we deal with it as follows:
//
//	- if he was originally signed up for an auto-match, and wants auto-match
//	  - same player, same game: don't remove from queue, send NASTY message
//	  - different player: requeue, send nasty message
//
//	- if he was originally signed up for an auto-match, and wants specific-match
//	  - requeue, send nasty message
//
//    - if he was originally signed up for a specific-match (be nicer?)
//	  - shunt to auto-match queue, send warning message
//
// In all cases we should charge a credit, unless KON wants the specific
// match timeout to be an hour, in which case rematching after a specific
// match should be free (and they'll get free x-mail, etc).
//
// Whether or not we reset their timer is a question of taste.  Probably
// ought to... they just paid a credit for it, and they'll get annoyed if
// they time out 30 seconds later but their box is waiting 5 or 10 minutes.
//
// Returns 1 if the matcher should bail immediately, 0 if not.
// Sets Matchup->warning.
//
static Err
Match_DequeueIfQueued(ContestantPtr caller, Matchup *matchup)
{
	ContestantPtr found;
	long dequeue = 0;

	// find slave that's not expired
	found = FindGlobalSlave(&caller->in.boxSerialNumber, 1);
	if (!found)
		return 0;

	// Found him.
	Match_DumpContestant(found,MDC_BRIEF);
	if (found->in.challengeFlags == kSpecificChallenge) {
		Logmsg("Caller is still waiting for specific match\n");
		// Original requests was specific-match.
		//
		if (caller->in.challengeFlags == kSpecificChallenge) {
			// He wants a different challenge.  Fine.
			matchup->warning = kMWarnSpecificToSpecific;
			dequeue = 1;
		} else {
			// Changed his mind, wants an auto-match.  Fine.
			matchup->warning = kMWarnSpecificToAuto;
			dequeue = 1;
		}
	} else {
		Logmsg("Caller is still waiting for auto match\n");
		// Original request was auto-match.
		//
		if (caller->in.player != found->in.player) {
			// He hit reset and switched players
			matchup->warning = kMWarnAutoChangedPlayer;
			dequeue = 1;
		} else if (caller->in.challengeFlags == kSpecificChallenge) {
			// He was on auto, now he wants specific challenge.
			matchup->warning = kMWarnAutoToSpecific;
			dequeue = 1;
		} else {
			// auto to auto, same game, same player
			matchup->warning = kMWarnAutoToAuto;
			dequeue = 0; // don't rematch this jerk
		}
	}
	if (dequeue) {
		// Remove old from queue, do standard processing to add new one.
		//
		Logmsg("REQUEUE: new ID %ld replaces old ID %ld [warning %ld]\n",
			caller->in.contestantID, found->in.contestantID,
			matchup->warning);

		// update stats
		//
		gRegion.numRequeued++;
		gRegion.timeEnqueued += gNow - found->queuedWhen;
		Match_Dequeue(found);
		free(found);

		return 0;	// rematch this jerk
	} else {
		// He's staying on the queue, so fill out his matchup struct
		// with values from the stuff on the queue.  Reset his queue
		// timer so it matches what the box will think.
		//
		// (This is probably going to screw up our timeEnqueued stat...)
		//
		Logmsg("RETAIN: contestant %ld not requeued [warning %ld]\n",
			caller->in.contestantID, matchup->warning);
		matchup->result = kLeaveOnQueue;
		matchup->magicCookie = found->in.contestantID;		// keep old cookie
		matchup->randomVal = found->randomVal;
		gRegion.timeEnqueued += gNow - found->queuedWhen;
		
		found->queuedWhen = gNow;
		found->stopWhen = gNow + Match_EstWait(found);
		found->expireWhen = found->stopWhen + gConfig.matchSlopWait;
		matchup->matchOrExpWhen = found->expireWhen;
		
		return 1;	// throw bastard out on his ear!
	}
}

static Err
Match_AddToGlobal(ContestantPtr slave)
{
	// Add slave to global tree which is sorted by boxSerialNumber.
	BINSetCompareProc((BINCMPProc) Compare_InsertBoxProc);
	BINInsert(&gGlobalTree.tree, GLOBAL_NODE(slave));
	Queue_Add(slave, kGlobalQueue);
	return noErr;
}

static Err
Match_AddToSpecific(ContestantPtr slave)
{
	// Add slave to specific tree which is sorted by desired opponent's boxSerialNumber.
	BINSetCompareProc((BINCMPProc) Compare_OppBoxProc);
	BINInsert(&gSpecTree.tree, SPEC_NODE(slave));
	return noErr;
}

// return 1 if toll, 0 if local(free), and negative if error

static long
Match_TweakOpponentPhoneNumber(ContestantPtr master, phoneNumber *oppOrigPhone, phoneNumber *dialPhone)
{
	return(PhoneDB_FormatDialString(
		&master->in.boxPhoneNumber, master->ht, master->fl, oppOrigPhone, dialPhone));
}

static long
Match_EstWait(ContestantPtr slave)
{
	long wait;
	long list;
	long eid;
	long ppm;	// "players per minute"

	// SPECIFIC CHALLENGES HAVE CONSTANT WAIT TIME

	if (slave->in.challengeFlags == kSpecificChallenge)
		return gConfig.matchSpecWait;

	// WAIT TIME IS BASED ON LOCAL AREA PLUS LONG/XBN IF APPLICABLE

	// SUM LOCAL TRAFFIC FOR THIS PLAYER

	ppm = gLocalQueue[slave->eid].traffic.ppm;
	list = slave->lca_idx;
	if (list > -1)
	{
		while ((eid = PhoneDB_GetEidFromLca(list++)) < (kInvalidEid2))
		{
			ppm += gLocalQueue[eid].traffic.ppm;
		}
	}
	
	// NOW SUM LONG DISTANCE OR XBN TRAFFIC IF APPROPRIATE
	
	if (slave->in.callLongDistance)
	{
		if (slave->in.xbndial || slave->in.xbncallable)
		{
			ppm += gQueue[kLongQueue].traffic.ppm;	
		} else {
			ppm += gQueue[kXBNQueue].traffic.ppm;	
		}
	
	}

	wait = (long)((double)kEstWaitScale/ppm);
	
	// preclip to average max wait
	if (wait > gConfig.matchAvgWait)
		wait = gConfig.matchAvgWait;

	// Adjust wait by user preference
	switch (slave->in.waitTime)
	{
		case kWaitShort:
			wait /= 2;
			break;
		case kWaitLong:
			wait *= 2;
			break;
		case kWaitAverage:
		default:
			break;
	}

	// Round to minutes
	wait = (((wait-1)/60)+1)*60;

	// clip
	if (wait > gConfig.matchMaxWait)
		wait = gConfig.matchMaxWait;
	if (wait < gConfig.matchMinWait)
		wait = gConfig.matchMinWait;
	
	return wait;
}

// Free all contestants who have expired.
// Pass (0) to expire EVERYONE regardless of time.
static void
Match_ExpireContestants(time_t now)
{
	QNodePtr n;
	ContestantPtr slave;
	long expcount = 0;

	if (!gInitialized)
		return;

	if (now == 0)
		Logmsg("Freeing ALL Contestants");
	else
		Logmsg("Freeing Expired Contestants");

	Logmsg(" (%ld global salves)\n", gQueue[kGlobalQueue].count);
	for (n = gQueue[kGlobalQueue].head; n; )
	{
		slave = n->contestant;
		n = n->next;
		if ((now == 0) || (now > slave->expireWhen))
		{
			expcount++;
			Match_ExpireContestant(slave);
		}
	}
	Logmsg("%ld expired, %ld global slaves remain.\n", expcount, gQueue[kGlobalQueue].count);
	gLastExpire = now;
}

static void
Match_ExpireContestant(ContestantPtr slave)
{
	Logmsg("EXPIRED: %8ld (%s) '%s'\n",
		slave->in.contestantID,
		slave->in.boxPhoneNumber.phoneNumber,
		slave->in.userName
	);
	Match_Dequeue(slave);
	free(slave);
	gRegion.numTimeouts++;
}

static Err
Match_InitializeContestant(ContestantPtr caller)
{
	Err		err;
	EAA_EXP	exp;

	BINClearNode(GLOBAL_NODE(caller));
	BINClearNode(SPEC_NODE(caller));
	Queue_Init(caller, kLocalQueue);
	Queue_Init(caller, kLongQueue);
	Queue_Init(caller, kXBNQueue);
	Queue_Init(caller, kGlobalQueue);

#ifdef __svr4__
    caller->randomVal = rand();
#else
    caller->randomVal = random();
#endif /* __svr4__ */

	caller->queuedWhen = 0;
	caller->stopWhen = 0;
	caller->expireWhen = 0;
	caller->flags = 0;

	err = PhoneDB_GetInfo(&caller->in.boxPhoneNumber, &exp);
	caller->eid = exp.eaa.eid;
	caller->lca_idx = PhoneDB_GetLcaIdx(&exp.eaa);
	if (err)
	{
		Logmsg("PhoneDB_FindLCA Error %d\n", err);
		return err;
	}
	caller->ht = exp.eaa.ht;
	caller->fl = exp.eaa.fl;
	if (caller->eid == kInvalidEid)
	{
		Logmsg("Caller eid out of range! (%lu)\n", caller->eid);
		Matching_Abort();
	}

	return kNoError;
}

//
// Make sure all of the arguments are valid.
//
// Returns a value suitable for Matchup.result.
//
static Err
Match_SanityCheckContestant(ContestantPtr contestant)
{
	// how to check boxSerialNumber?

	// check the player #
	//
	if (contestant->in.player < 0 || contestant->in.player > 3) {
		PLogmsg(LOGP_DETAIL, "REJECT: invalid player # %d\n",
			contestant->in.player);
		return (kInvalidArguments);
	}

	// check userName
	//
	if (*contestant->in.userName == '\0') {
		PLogmsg(LOGP_DETAIL, "REJECT: blank userName for '%s'\n",
			contestant->in.boxPhoneNumber.phoneNumber);
		return (kInvalidArguments);
	}
	
	if (!Common_PhoneNormalizeNumber(contestant->in.boxPhoneNumber.phoneNumber,
		contestant->in.boxPhoneNumber.phoneNumber))
	{
		PLogmsg(LOGP_DETAIL, "REJECT: invalid phone number: %s\n",
			contestant->in.boxPhoneNumber.phoneNumber);
		return (kInvalidArguments);
	}

	// check challengeFlags
	//
	if (contestant->in.challengeFlags != kAcceptChallenges &&
		contestant->in.challengeFlags != kIgnoreChallenges &&
		contestant->in.challengeFlags != kSpecificChallenge)
	{
		PLogmsg(LOGP_DETAIL, "REJECT: invalid challengeFlags %d\n",
			contestant->in.challengeFlags);
		return (kInvalidArguments);
	}

	// callLongDistance is boolean

	// check gamePatchVersion
	//
	if (contestant->in.gamePatchVersion > 1024) {
		PLogmsg(LOGP_NOTICE, "WARNING: huge gp version (%ld)\n",
			contestant->in.gamePatchVersion);
		// just continue
	}

	// how to check oppBoxSerialNumber?  (either prev opponent or desired opp)

	// Check the oppPlayer #.  Can be -1 if this is an auto-match and we
	// didn't have a previous opponent.  Might be allowable for a specific
	// if we want to be flexible.
	//
	if (contestant->in.oppPlayer > 3)
	{
		if (contestant->in.challengeFlags == kSpecificChallenge)
		{
			PLogmsg(LOGP_NOTICE,
				"REJECT: invalid oppPlayer # %d\n", contestant->in.oppPlayer);
			return (kInvalidArguments);
		}
	}

	// can't really check the rankingInfo

	return (kNoError);
}

//
// Dump all of the queues.
//
static void
Match_DumpQueues(long brief)
{
	if (brief == MDC_VERBOSE)
	{
		BINSetDumpProc((BINDumpProc) DumpContestantProc);
	
		// DUMP GLOBAL TREE
	
		PLogmsg(LOGP_DBUG, "========== DUMP GLOBAL QUEUE (%ld)\n",
			gGlobalTree.tree.members);
		
		if (gGlobalTree.tree.members)
			BINDump(gGlobalTree.tree.root, 0);
		
		// DUMP SPECIFIC TREE
		
		PLogmsg(LOGP_DBUG, "========== DUMP SPECIFIC QUEUE (%ld)\n",
			gSpecTree.tree.members);
	
		if (gSpecTree.tree.members)
			BINDump(gSpecTree.tree.root, 1);
	
		// DUMP LOCAL QUEUES
	
		Queue_Dump(kLocalQueue);
		
		// DUMP LONG DISTANCE QUEUE
	
		Queue_Dump(kLongQueue);
		
		// DUMP XBN QUEUE
	
		Queue_Dump(kXBNQueue);
	}
}


static void
Match_DumpContestant(ContestantPtr contestant, int brief)
{
	int 		i;
	phoneNumber tmpPhone;
	EAA_EXP		exp;

	if (contestant == NULL)
	{
		PLogmsg(LOGP_FLAW, "GLITCH: NULL contestant passed to DumpContestant\n");
		Matching_Abort();
		return;
	}

	Common_PhoneFormatDisplay(contestant->in.boxPhoneNumber.phoneNumber, tmpPhone.phoneNumber);

	PhoneDB_GetInfo(&contestant->in.boxPhoneNumber, &exp);

	// One-line summary.
	//
	if (brief == MDC_BRIEF)
	{
		Logmsg("%lu %ld:%ld:%ld '%s' %s %s L%ld XB%ld XD%ld XC%ld w%d r%ld",
			contestant->in.contestantID,
			contestant->in.boxSerialNumber.box,
			contestant->in.boxSerialNumber.region,
			contestant->in.player,
			contestant->in.userName,
			tmpPhone.phoneNumber,
			exp.homeTown,
			contestant->in.callLongDistance,
			contestant->in.billme ? 1 : 0,
			contestant->in.xbndial ? 1 : 0,
			contestant->in.xbncallable ? 1 : 0,
			contestant->in.waitTime,
			contestant->in.ranking.rating
		);
		if (contestant->in.challengeFlags == kSpecificChallenge)
			Logmsg(", waiting for %s",
				boxNumString(&contestant->in.oppBoxSerialNumber,contestant->in.oppPlayer));
		else if (contestant->in.challengeFlags == kIgnoreChallenges)
			Logmsg(", ignores challenges");
		Logmsg("\n");
		return;
	}
	Logmsg("NAME '%s'\n",
		contestant->in.userName		
	);
	Logmsg("C%ld B%ld:%ld PH %s EID %5ld TOWN %s\n",
		contestant->in.contestantID,
		contestant->in.boxSerialNumber.box,
		contestant->in.player,
		tmpPhone.phoneNumber,
		contestant->eid,
		exp.homeTown
	);
	Logmsg("REQUEST ");
	if (contestant->in.challengeFlags == kSpecificChallenge)
	{
		Logmsg("SPECIFIC OPPONENT %5ld:%ld\n",
			contestant->in.oppBoxSerialNumber.box,
			contestant->in.oppPlayer
		);
	} else {
		Logmsg("AUTO MATCH (%s CHALLENGES)\n",
			contestant->in.challengeFlags == kAcceptChallenges ? "ACCEPT" : "DENY"
		);
	}
	Logmsg("RATING %4ld LONGDIST %ld XBNDIAL %ld XBNCALLABLE %ld XBNBILL %ld\n",
		contestant->in.ranking.rating,
		contestant->in.callLongDistance,
		contestant->in.xbndial,
		contestant->in.xbncallable,
		contestant->in.billme
	);
	Logmsg("WAIT %ld GAMEVERS %ld\n",
		contestant->in.waitTime,
		contestant->in.gamePatchVersion
	);
	
	Logmsg("FLAGS ");
	if (contestant->in.flags)
	{
		if (contestant->in.flags & kNewPlayerFlag)
			PLogmsg(LOGP_DBUG, "NewPlayer ");
		if (contestant->in.flags & kForceSlave)
			PLogmsg(LOGP_DBUG, "ForceSlave ");
		if (contestant->in.flags & kForceMaster)
			PLogmsg(LOGP_DBUG, "ForceMaster ");
		if (contestant->in.flags & kForceAcceptChallengeFlag)
			PLogmsg(LOGP_DBUG, "kForceAcceptChallengeFlag ");
		if (contestant->in.flags & kTournamentFlag)
			PLogmsg(LOGP_DBUG, "Tourney ");
		Logmsg("\n");
	} else {
		Logmsg("NONE\n");
	}

	Logmsg("PREV ");
	for (i = 0; i < kMaxPreviousOpponent; i++)
	{
		if (contestant->in.prevOpponent[i].when == 0)
			Logmsg("NONE ");
		else
			Logmsg("%5ld:%ld/%ld ",
				contestant->in.prevOpponent[i].oppBoxSerialNumber.box,
				contestant->in.prevOpponent[i].oppPlayer,
				gNow - contestant->in.prevOpponent[i].when
			);
	}
	Logmsg("\n");
}

static void
FreeStructs(void)
{
	if (gLocalQueue)
	{
		free(gLocalQueue);
		gLocalQueue = NULL;
	}
}

// This is used when searching for a slave (key1)
// in the global tree sorted by boxSerialNumber.
//
static long Compare_BoxProc(void *key1, void *vbsn2)
{
	register ContestantPtr k1 = GLOBAL_TO_CONTESTANT(key1);
	register BoxSerialNumber *bsn2 = (BoxSerialNumber *)vbsn2;
	
	if (bsn2->region > k1->in.boxSerialNumber.region)
		return T_GT;
	else if (bsn2->region < k1->in.boxSerialNumber.region)
		return T_LT;

	if (bsn2->box > k1->in.boxSerialNumber.box)
		return T_GT;
	else if (bsn2->box < k1->in.boxSerialNumber.box)
		return T_LT;
	
	// box and region match
	return T_EQ;
}

//
// This is used when inserting a slave (key2)
// into the global tree sorted by boxSerialNumber.
//
static long
Compare_InsertBoxProc(void *key1, void *key2)
{
	register ContestantPtr k1 = GLOBAL_TO_CONTESTANT(key1);
	register ContestantPtr k2 = GLOBAL_TO_CONTESTANT(key2);
	
	if (k2->in.boxSerialNumber.region > k1->in.boxSerialNumber.region)
		return T_GT;
	else if (k2->in.boxSerialNumber.region < k1->in.boxSerialNumber.region)
		return T_LT;
	
	if (k2->in.boxSerialNumber.box > k1->in.boxSerialNumber.box)
		return T_GT;
	else if (k2->in.boxSerialNumber.box < k1->in.boxSerialNumber.box)
		return T_LT;
	
	return T_EQ;
}

//
// This is used when inserting a slave (key2) into the specific tree.
// We sort based on the opponent's BoxSerialNumber we're looking for.
//
static long
Compare_OppBoxProc(void *key1, void *key2)
{
	register ContestantPtr k1 = SPEC_TO_CONTESTANT(key1);
	register ContestantPtr k2 = SPEC_TO_CONTESTANT(key2);
	
	if (k2->in.oppBoxSerialNumber.region > k1->in.oppBoxSerialNumber.region)
		return T_GT;
	else if (k2->in.oppBoxSerialNumber.region < k1->in.oppBoxSerialNumber.region)
		return T_LT;
	
	if (k2->in.oppBoxSerialNumber.box > k1->in.oppBoxSerialNumber.box)
		return T_GT;
	else if (k2->in.oppBoxSerialNumber.box < k1->in.oppBoxSerialNumber.box)
		return T_LT;
	
	return T_EQ;	// bintree will assume T_GT when inserting dups
}

//
// This is used when searching for a slave (key1)
// waiting for a specific master (vbsn2).
// CAREFUL ABOUT THE ORDER OF CHECKS!
//

static long
Compare_MatchBoxProc(void *key1, void *key2)
{
	register ContestantPtr slave = SPEC_TO_CONTESTANT(key1);
	register ContestantPtr caller = (ContestantPtr)key2;
	
	if (caller->in.boxSerialNumber.box > slave->in.oppBoxSerialNumber.box)
		return T_GT;
	else if (caller->in.boxSerialNumber.box < slave->in.oppBoxSerialNumber.box)
		return T_LT;
	
	// Challenger was found, but make sure he didn't time out
	if (gNow > slave->stopWhen)		// if we can no longer match slave
		return T_GT;				// continue search

	if (caller->in.gamePatchVersion != slave->in.gamePatchVersion)
		return T_GT;
	
	// Check to make sure challenger isn't outside calling area
	if (IsTollCall(caller, slave))
		return T_GT;
	return T_EQ;
}

// Return seconds played ago if caller has played slave before and vica versa, (0) if not.
static long
PlayedBefore(ContestantPtr slave, ContestantPtr caller)
{
	long i;
	
	// Caller and slave normally both contain each other as played before,
	// but sometimes one may play more games and shove the other out, while the
	// other may still show him as being played before.

	// Check for slave in caller's list
	for (i = 0; i<kMaxPreviousOpponent; i++)
	{
		if ((caller->in.prevOpponent[i].when)
		&& (caller->in.prevOpponent[i].oppBoxSerialNumber.box == slave->in.boxSerialNumber.box)
		&& (caller->in.prevOpponent[i].oppPlayer == slave->in.player))
		{
			return gNow - caller->in.prevOpponent[i].when;
		}
		if ((slave->in.prevOpponent[i].when)
		&& (slave->in.prevOpponent[i].oppBoxSerialNumber.box == caller->in.boxSerialNumber.box)
		&& (slave->in.prevOpponent[i].oppPlayer == caller->in.player))
		{
			return gNow - slave->in.prevOpponent[i].when;
		}
	}
	return 0;
}

// Pass in potential matchup.  Return (1) if slave is waiting for someone else, (0) if not.
static long
WaitingForAnother(ContestantPtr caller, ContestantPtr slave)
{
	if (slave->in.challengeFlags == kSpecificChallenge)
	{
		if ((caller->in.boxSerialNumber.box == slave->in.oppBoxSerialNumber.box)
		&& (caller->in.oppPlayer == slave->in.player))
			return 0;
		return 1;
	}
	return 0;
}

static ContestantPtr
FindGlobalSlave(BoxSerialNumber *bsn, long notExpired)
{
	void *node;
	ContestantPtr slave;

	// Look up slave in our tree sorted by box serial number
	BINSetCompareProc((BINCMPProc) Compare_BoxProc);
	if (!(node = BINSearch(gGlobalTree.tree.root, bsn)))
		return NULL;
	slave = GLOBAL_TO_CONTESTANT(node);
	if (gNow < slave->stopWhen)
		return slave;
	if (gNow > slave->expireWhen)	
		Match_ExpireContestant(slave);
	else if (notExpired)
		return slave;
	return NULL;
}

static void
SetThresholds(ContestantPtr caller)
{
	// Set thresholds in each queue for current match request for caller
	// based on current traffic.

	long i;
	long list;
	long t;
	eid_t eid;

	// Calculate Threshold for Local queue (this is a special case because
	// the traffic is the summation of traffic in all exchanges local to caller).
	gQueue[kLocalQueue].traffic.ppm = gLocalQueue[caller->eid].traffic.ppm;
	list = caller->lca_idx;
	if (list > -1)
	{
		while ((eid = PhoneDB_GetEidFromLca(list++)) < (kInvalidEid2))
		{
			gQueue[kLocalQueue].traffic.ppm += gLocalQueue[eid].traffic.ppm;
		}
	}

	// Calculate Thresholds for all queues
	for (i=0; i<kMaxQueues; i++)
	{
		// Eventually we might break out scale coefficients based on the queue type.
		// For now, just use a global scale factor.
		
		// If we are supposed to find a master at all costs, just set the threshold
		// to 0 to accept the best match. This avoids waiting as long as there is 
		// *someone* available now.

		if (caller->in.flags & kForceMaster)
			gQueue[i].threshold = kWorstScore;
		else
		{
			// determine a threshold
			t = gConfig.matchMinThreshold + gQueue[i].traffic.ppm * gConfig.matchThresholdCoeff;
			// clip
			t = MIN(t, gConfig.matchMaxThreshold);
			t = MAX(t, gConfig.matchMinThreshold);
			// lower threshold for new players so they end up matching faster
			if (caller->in.flags & kNewPlayerFlag)
				t /= 2;
			gQueue[i].threshold = t;
		}
	}

	Logmsg("TRAF: EID=%4.1f LCL=%4.1f/(%ld) LNG=%4.1f/(%ld) XBN=%4.1f/(%ld)\n",
		gLocalQueue[caller->eid].traffic.ppm,
		gQueue[kLocalQueue].traffic.ppm,
		gQueue[kLocalQueue].threshold,
		gQueue[kLongQueue].traffic.ppm,
		gQueue[kLongQueue].threshold,
		gQueue[kXBNQueue].traffic.ppm,		
		gQueue[kXBNQueue].threshold);		
}

//
// Increase traffic based on the caller's local area and long distance options
//

static void
BumpCallerTraffic(ContestantPtr caller)
{
	// GLOBAL TRAFFIC (for curiosity only)
	BumpTraffic(&gGlobalTree.traffic);

	if (caller->in.challengeFlags == kSpecificChallenge)
	{
		// SPECIFIC TRAFFIC (for curiosity only)
		BumpTraffic(&gSpecTree.traffic);
	}
	else
	{
		// LOCAL TRAFFIC
		BumpTraffic(&gLocalQueue[caller->eid].traffic);
		
		// LONG DISTANCE TRAFFIC
		if (caller->in.challengeFlags != kSpecificChallenge)
			BumpTraffic(&gQueue[kLongQueue].traffic);
		
		// XBAND NATIONWIDE TRAFFIC
		if (caller->in.callLongDistance && (caller->in.xbndial || caller->in.xbncallable))
			BumpTraffic(&gQueue[kXBNQueue].traffic);
	}
}

//
// Increase traffic by one for a specific traffic area
//

/* This version uses the previous ppm for calculation of the next.
static double
BumpTraffic(Traffic *traffic)
{
	long delta;

	delta = (gNow - traffic->lasttime)/60;	// minutes apart
	if (delta > 1)
		traffic->lastppm = (delta < 10) ? (traffic->lastppm / (2<<delta)) : 0;
	traffic->new++;
	if (delta)
	{
		traffic->ppm = (traffic->lastppm + traffic->new) / 2;
		traffic->lasttime = gNow;
		traffic->lastppm = traffic->ppm;
		traffic->new = 0;
	}
	return traffic->ppm;
}
*/

// This version averages the last two counts/min to arrive at ppm.
static double
BumpTraffic(Traffic *traffic)
{
	long delta;

	delta = (gNow - traffic->lasttime)/60;	// minutes apart
	if (delta > 2)
		traffic->new = 0;
	if (delta > 1)
		traffic->lastppm = 0;
	if (delta)
	{
		traffic->ppm = (traffic->lastppm + traffic->new) / 2;
		traffic->lasttime = gNow;
		traffic->lastppm = traffic->new;
		traffic->new = 0;
	}
	traffic->new++;
	return traffic->ppm;
}

static void
ScoreLocalArea(ContestantPtr caller, ContestantPtr *bestSlave, long *bestScore)
{
	long list;
	eid_t eid;
	long score;
	ContestantPtr slave;

	*bestSlave = NULL;
	*bestScore = kNoScore;
	if (gLocalQueue[caller->eid].count != 0)
		ScoreQueue(caller, kLocalQueue, caller->eid, bestSlave, bestScore);
	
	// Search other local exchanges for better scores
	list = caller->lca_idx;
	if (list > -1)
	{
		while ((eid = PhoneDB_GetEidFromLca(list++)) < (kInvalidEid2))
		{
			if (gLocalQueue[eid].count == 0)
				continue;
			ScoreQueue(caller, kLocalQueue, eid, &slave, &score);
			if ((score <= *bestScore) || (score < gQueue[kLocalQueue].threshold))
				continue;
			*bestScore = score;
			*bestSlave = slave;
		}
	}
}

//
// Traverse a queue and return player with the highest score
//
// ---------- SCORING XBN QUEUE (THRESHOLD=%ld)
// Score Boxid:P Skil Wait       Ago LDC Phone      Town        Name					   
// * 700 20222:1 3344  340     23023 000 4085551111 SAN JOSE,CA 'Thrasher' 
//

static void
ScoreQueue(ContestantPtr caller, long qindex, eid_t eid,
	ContestantPtr *bestSlave, long *bestScore)
{
	EAA_EXP	exp;
	long score;
	long ago;
	QNodePtr n;
	QueuePtr q;
	ContestantPtr slave;
	
	if (qindex == kLocalQueue)
	{
		q = &gLocalQueue[eid];
		PLogmsg(LOGP_DETAIL,
			"---------- SCORING LOCAL QUEUE EID %ld (THRESHOLD=%ld)\n",
			eid,
			gQueue[qindex].threshold
		);
	}
	else
	{
		q = &gQueue[qindex];
		PLogmsg(LOGP_DETAIL,
			"---------- SCORING %s QUEUE (THRESHOLD=%ld)\n",
			gQueueName[qindex],
			gQueue[qindex].threshold
		);
	}
	PLogmsg(LOGP_DETAIL,"Score BoxID:P Skil  Wait      Ago LDC Phone      Town          Name\n");

	*bestSlave = NULL;
	*bestScore = kNoScore;
	for (n = q->head; n; n = n->next)
	{
		slave = n->contestant;
		score = ScorePlayers(caller, slave, &ago);
		
		PhoneDB_GetInfo(&slave->in.boxPhoneNumber, &exp);
		PLogmsg(LOGP_DETAIL,"%c%4ld %5ld:%1ld %4ld %5ld %8ld %ld%ld%ld %s %s '%s'\n",
			(score >= gQueue[qindex].threshold) ? '*':' ',
			score,
			slave->in.boxSerialNumber.box,
			slave->in.player,
			abs(caller->in.ranking.rating-slave->in.ranking.rating),
			gNow - slave->queuedWhen,
			ago,
			slave->in.callLongDistance,
			slave->in.xbndial,
			slave->in.xbncallable,
			slave->in.boxPhoneNumber.phoneNumber,
			exp.homeTown,
			slave->in.userName
		);
		if ((score <= *bestScore) || (score < gQueue[qindex].threshold))
			continue;
		*bestScore = score;
		*bestSlave = slave;
	}
}

static long
ScorePlayers(ContestantPtr caller, ContestantPtr slave, long *ago)
{
	long score;
	long skillFactor;
	long waitFactor;
	long playFactor;

	/**** Reject Absolute Missess ****/

	// IGNORE PEOPLE WHO ARE PAST THE POINT OF BEING MATCHED
	if (gNow > slave->stopWhen)
	{
		PLogmsg(LOGP_DETAIL,"reject b/c past slave stopWhen\n");
		return kNoScore;
	}
	// CANNOT MATCH TOURNEY PEOPLE AND NON-TOURNEY PEOPLE TOGETHER
	if ((caller->in.flags ^ slave->in.flags) & kTournamentFlag)
	{
		PLogmsg(LOGP_DETAIL,"reject b/c mutex tourney bits\n");
		return kNoScore;
	}
	// IF TOURNEY PERSON, MAKE SURE CALLER HASN'T PLAYED SLAVE BEFORE
	if ((caller->in.flags & kTournamentFlag) && (gBoxList != NULL)
	&& Match_PlayedBefore(gBoxList, slave->in.boxSerialNumber.box) >= 0)
	{
		PLogmsg(LOGP_DETAIL,"reject b/c played each other before in tourney\n");
		return kNoScore;		// players have played before
	}
	// MAKE SURE GAME VERSION IS THE SAME FOR BOTH CALLER AND SLAVE
	if (caller->in.gamePatchVersion != slave->in.gamePatchVersion)
	{
		PLogmsg(LOGP_DETAIL,"reject b/c game patch version mistmatch (m=%ld,s=%ld)\n",
			caller->in.gamePatchVersion, slave->in.gamePatchVersion);
		return kNoScore;
	}
	// MAKE SURE SLAVE IS NOT WAITING FOR SOMEONE ELSE IN A SPECIFIC MATCH
	if (WaitingForAnother(caller, slave))
	{
		PLogmsg(LOGP_DETAIL,"reject b/c slave waiting for someone else\n");
		return kNoScore;
	}

	/**** Score Player Suitability ****/
	
	skillFactor = kBestScore - MIN(abs(caller->in.ranking.rating - slave->in.ranking.rating),
		kMaxSkillDelta) / kSkillScale;									// [0,1000]

	waitFactor = MIN((gNow-slave->queuedWhen)/kWaitScale, kBestScore);	// [0,1000]

	*ago = PlayedBefore(caller, slave)/kMaxAgo;

	playFactor = *ago ? MIN(*ago/kMaxAgo, kBestScore) : kBestScore;		// [0,1000]
	
	score = (gConfig.matchSkillWeight * skillFactor
			+ gConfig.matchWaitWeight * waitFactor
			+ gConfig.matchPlayWeight * playFactor) / gScoreWeightSum;
	
	PLogmsg(LOGP_JUNK,"skillFactor=%ld waitFactor=%ld playFactor=%ld score=%ld\n", skillFactor, waitFactor, playFactor, score);

	score = MIN(score, kBestScore);

	return score;
}

static long
IsTollCall(ContestantPtr master, ContestantPtr slave)
{
	// quick escape
	if (master->in.callLongDistance && !master->in.xbndial)
		return 0;
	
	if (master->eid != slave->eid)
	{
		// Make sure opponent is within caller's local calling area.
		if (PhoneDB_EidInLca(master->lca_idx, slave->eid))
		{
			return(0);
		}
		if (master->in.callLongDistance)
		{
			if (master->in.xbndial)
			{
				if (!slave->in.xbncallable)
				{
					if (slave->in.xbn) 	// slave subscribes
						return kSlaveUnReachableXBN;
					else
						return kSlaveDoesntHaveXBN; 
				}
			}
			return 0;
		}
		return kChallengeeTooFar;
	}
	return 0; // no restriction
}

//
// QUEUE MANAGEMENT ROUTINES
//

#ifdef UNUSED
static void
fprintqueue(QueuePtr q)
{
	QNodePtr n;
	long i;

	for (i = 1, n = q->head; n; i++, n=n->next)
		fprintf(stderr,"%ld. (0x%08lX) prev(0x%08lX) next(0x%08lX) slave(0x%08lX)\n",
			i, n, n->prev, n->next, n->contestant);
}
#endif

static void
Queue_Init(ContestantPtr slave, long qindex)
{
	memset(&slave->qnode[qindex], 0, sizeof(Queue));
}

static void
Queue_Add(ContestantPtr slave, long qindex)
{
	QNodePtr n;
	QueuePtr q;
	
	n = &slave->qnode[qindex];
	if (qindex == kLocalQueue)
		q = &gLocalQueue[slave->eid];
	else
		q = &gQueue[qindex];

	// Just prepend the item since the list can be in any order.
	if (q->head)
		q->head->prev = n;
	n->next = q->head;
	n->prev = 0;
	n->contestant = slave;
	q->head = n;
	q->count++;
#ifdef DEBUG
	if (qindex == 1)
	{
	fprintf(stderr,"Queue_Add: slave(0x%08lX) and node(0x%08lX) to %s(%ld) queue\n",
		(long)slave, (long)n, gQueueName[qindex], q->count);
	fprintqueue(q);
	}
#endif
}

static void
Queue_Remove(ContestantPtr slave, long qindex)
{
	QNodePtr n;
	QueuePtr q;
	
	n = &slave->qnode[qindex];
	if (qindex == kLocalQueue)
		q = &gLocalQueue[slave->eid];
	else
		q = &gQueue[qindex];

	if (n->prev)
		n->prev->next = n->next;
	else if (q->head == n)
	{
		q->head = n->next;	
	} else
		return;	// slave not part of this queue
	q->count--;
	if (n->next)
		n->next->prev = n->prev;
	n->prev = n->next = 0;
	n->contestant = 0;
#ifdef DEBUG
	if (qindex == 1)
	{
	fprintf(stderr,"Queue_Rem: slave(0x%08lX) and node(0x%08lX) to %s(%ld) queue\n",
		(long)slave, (long)n, gQueueName[qindex], q->count);
	fprintqueue(q);
	}
#endif
}

static void
Queue_Dump(long qindex)
{
	QNodePtr n;
	eid_t eid;

	if (qindex == kLocalQueue)
	{
		for (eid=0; eid<PhoneDB_EidCount(); eid++)
		{
			if (gLocalQueue[eid].count == 0)
				continue;
			
			PLogmsg(LOGP_DETAIL, "========== DUMP LOCAL QUEUE %ld (%ld)\n",
				eid, gLocalQueue[eid].count);
			
			for (n = gLocalQueue[eid].head; n; n = n->next)
			{
				Match_DumpContestant(n->contestant, MDC_BRIEF);
			}
		}
	}
	else
	{
		PLogmsg(LOGP_DETAIL, "========== DUMP %s QUEUE (%ld)\n",
			gQueueName[qindex], gQueue[qindex].count);

		if ((!gQueue[qindex].head && gQueue[qindex].count)
		|| (gQueue[qindex].head && !gQueue[qindex].count))
			Matching_Abort();
		for (n = gQueue[qindex].head; n; n = n->next)
		{
			Match_DumpContestant(n->contestant, MDC_BRIEF);
		}	
	}
}

static void
DumpContestantProc(BINNodePtr t, long refcon)
{
	switch(refcon)
	{
	case 0:
		Match_DumpContestant(GLOBAL_TO_CONTESTANT(t), MDC_BRIEF);
		break;
	case 1:
		Match_DumpContestant(SPEC_TO_CONTESTANT(t), MDC_BRIEF);
		break;
	}
}

#ifdef UNUSED
static void
DumpMatchup(Matchup *matchup)
{
	Logmsg("MATCHUP: result = %ld\n", matchup->result);
	Logmsg("MATCHUP: specificShunt = %ld\n", matchup->specificShunt);
	Logmsg("MATCHUP: warning = %ld\n", matchup->warning);
	Logmsg("MATCHUP: magicCookie = %lu\n", matchup->magicCookie);
	Logmsg("MATCHUP: randomVal = 0x%.8lx\n", matchup->randomVal);
	Logmsg("MATCHUP: matchOrExpWhen = %lu\n", matchup->matchOrExpWhen);
	Logmsg("MATCHUP: oppMagicCookie = %lu\n", matchup->oppMagicCookie);
	Logmsg("MATCHUP: oppBoxSerialNumber = %ld,%ld\n", matchup->oppBoxSerialNumber.box,
		matchup->oppBoxSerialNumber.region);
	Logmsg("MATCHUP: oppPlayer = %ld\n", matchup->oppPlayer);
	Logmsg("MATCHUP: oppSpecific = %ld\n", matchup->oppSpecific);
	Logmsg("MATCHUP: oppPhoneNumber = %s\n", matchup->oppPhoneNumber.phoneNumber);
	Logmsg("MATCHUP: oppUserName = %s\n", matchup->oppUserName);
	Logmsg("MATCHUP: oppRankingInfo(rating) = %ld\n", matchup->oppRankingInfo.rating);
}
#endif

static char *
boxNumString(BoxSerialNumber *box, long player)
{
	static char output[20];
	sprintf(output,"(%ld:%ld:%ld)",
		box->box, box->region, player);
	return output;
}

// The recent play history is stored in a gdbm database (currently used only
// for tournaments). It is opened lazily, i.e., when the first tournament
// player enters the matcher. 
//
// The name of the matcher's database is "history.<gameid>.gdbm" where
// <gameid> is the hexidecimal numeric value of the game id. The file
// is stored in the "recent/" dirtory in the conf directory on the match
// matchine.

// Keys are box id's. Key content is a variable-sized  array of box id's.
//
// The database is only created when the first auto match is made and we
// must store the opponent box id's in corresponding records.
//
// NOTE:
// We could have used the power of gdbm to detect the presence of a recently
// played match between two boxes by combining them into one key value.
// But the hash table could grow enormous and searches would bog down due
// to increased disk access. Instead, we store a list of boxes associated
// with a box and keep the list sorted (there could be a large number of
// opponents over several days).

static long
Match_OpenHistoryFile(long create)
{
	if (!gDBF)
	{
		// mke sure directory exists
    	struct stat buf;
		if (stat(gConfig.matchHistoryDirectory, &buf))
		{
			if (errno== ENOENT)
			{
				PLogmsg(LOGP_FLAW,"Directory missing: mkdir(%s/)\n", gConfig.matchHistoryDirectory);
				if (mkdir(gConfig.matchHistoryDirectory, 0755))
				{
					PLogmsg(LOGP_FLAW,"errno = %ld\n", errno);
				}
			} else {
				PLogmsg(LOGP_FLAW,"stat(%s) errno = %ld\n", gConfig.matchHistoryDirectory, errno);
			}
		}
		// now create/open the file
		gDBF = gdbm_open(gHistoryFile, 512, create ? GDBM_WRCREAT : GDBM_WRITER, 0644, 0);
		if (!gDBF)
		{
			PLogmsg(LOGP_FLAW,"gdbm_open(%s) unsuccessfull! gdbm_errno %ld. Aborting.\n",
				gHistoryFile, gdbm_errno);
			return 0; // Don't die if this is a problem! Keep matching!
		}
		PLogmsg(LOGP_NOTICE,"gdbm_open(%s) successfull.\n", gHistoryFile);
	}
	return 1;
}

static void
Match_CloseHistoryFile(void)
{
	if (gDBF) {
		gdbm_close(gDBF);
		PLogmsg(LOGP_NOTICE, "Closed history file (%s).\n", gHistoryFile);
	}
	gDBF = NULL;
}

static void
Match_KillHistoryFile(void)
{
	char buf[1024];

	sprintf(buf, "%s.old", gHistoryFile);
	Match_CloseHistoryFile();
	if (rename(gHistoryFile, buf) < 0)
	{
		PLogmsg(LOGP_FLAW, "rename(%s,%s) failed (errno=%ld).\n", gHistoryFile, buf, errno);
	}
	else
	{
		PLogmsg(LOGP_FLAW, "rename(%s,%s) succeeded.\n", gHistoryFile, buf);
	}
}

static BoxList *
Match_GetBoxHistory(long box)
// return an array of box ids the box (key) has played since the database
// was created. If there is no history, a NULL pointer is returned.
{
	datum key, content;

	if (!Match_OpenHistoryFile(1))
		return NULL;	// could not open db, return empty record
	key.dptr = (char *)&box;
	key.dsize = sizeof(box);
	content = gdbm_fetch(gDBF, key);
	return (BoxList *)content.dptr;
}

static void
Match_AddBoxHistory(BoxList **list, long box, long opp)
// When a tournament player is matched, we add the opponent box id to the
// box's list of recently played opponents. We do this for the opponent as
// well. We must have already have a BoxList -- we don't want to refetch
// the box's data if it already exists. 'list' can be NULL if there is
// no existing BoxList for the box.
{
	BoxList *opplist;

	if (!gDBF)
	{
		PLogmsg(LOGP_FLAW,"gdbm history file not open! Could not add entry.\n");
		return;
	}

// first add 'opp' to 'box' play history

	// increase size of list if it exists
	if (*list)
	{
		long newsize = sizeof(BoxList) + ((*list)->items) * sizeof(long);
		*list = (BoxList *)realloc((char *)*list, newsize);
		(*list)->boxes[(*list)->items++] = opp;
		Match_WriteBoxHistory(*list, box);
	}
	else // first time
	{
		BoxList tmpList;
		tmpList.items = 1;
		tmpList.boxes[0] = opp;
		Match_WriteBoxHistory(&tmpList, box);
	}

// second add 'box' to 'opp' play history
	
	opplist = Match_GetBoxHistory(opp);
	// increase size of list if it exists
	if (opplist)
	{
		long newsize = sizeof(BoxList) + (opplist->items) * sizeof(long);
		opplist = (BoxList *)realloc((char *)opplist, newsize);
		opplist->boxes[opplist->items++] = box;
		Match_WriteBoxHistory(opplist, opp);
		free(opplist);
	}
	else // first time
	{
		BoxList tmpList;
		tmpList.items = 1;
		tmpList.boxes[0] = box;
		Match_WriteBoxHistory(&tmpList, opp);
	}
}

static void
Match_WriteBoxHistory(BoxList *list, long box)
{
	datum content, key;

	if (!gDBF)
		return;

	if (list->items > 1)
		qsort((char *)list->boxes, list->items, sizeof(long), longcompare);

	key.dptr = (char *)&box;
	key.dsize = sizeof(long);
	content.dsize = sizeof(BoxList) + (list->items-1) * sizeof(long);
	content.dptr = (char *)list;
	
	gdbm_store(gDBF, key, content, GDBM_REPLACE);
}

static void
Match_RemPlayHistory(long box, long opp)
{
	BoxList *list;
	long index;

	// lookup box to remove box from. don't create database if it doesn't exist.
	if (!Match_OpenHistoryFile(0))
		return;	// db does not exist or cannot create, so we don't care here.
	
	// Get list of boxes this box has played before. If none, bug out.
	list = Match_GetBoxHistory(box);
	if (!list)
		return;
	
	// fine, get index into list where opp box was found.
	index = Match_PlayedBefore(list, opp);
	if (index == -1) {
		PLogmsg(LOGP_FLAW,"WEIRD: removing history for %d and %d, but they haven't played\n");
		return;
	}

	// erase history with this box by setting it to -1 (invalid box number)
	list->boxes[index] = -1;
	Match_WriteBoxHistory(list, box);
	PLogmsg(LOGP_NOTICE,"Removed box %ld from box %ld's play history.\n", opp, box);
}

// return -1 if not found or index into list->boxes[] where found
static long
Match_PlayedBefore(BoxList *list, long box)
// is box in list?
{
	long *record;
	
	record = (long *)bsearch((char *)&box,
		(char *)list->boxes,
		list->items,
		sizeof(long),
		longcompare);
	if (!record)
		return -1;
	return record - &list->boxes[0];
}

static void
dumpboxlist(long box, BoxList *list)
{
	long i;

	if (!list)
	{
		Logmsg("BoxList for box %ld (has 0 items).\n", box);
		return;
	}
	Logmsg("BoxList for box %ld (has %ld items):\n", box, list->items);
	for (i=0; i<list->items; i++)
	{
		Logmsg(" %ld", list->boxes[i]);
		if (!((i+1) % 20))
			Logmsg("\n");
	}
	if (i%20)
		Logmsg("\n");
}

static int
longcompare(const void *i, const void *j)
{
	return (*(long *)i - *(long *)j);
}
