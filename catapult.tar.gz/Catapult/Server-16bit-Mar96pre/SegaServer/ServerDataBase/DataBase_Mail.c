/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: DataBase_Mail.c,v 1.26 1996/02/22 14:21:22 chs Exp $
 *
 * $Log: DataBase_Mail.c,v $
 * Revision 1.26  1996/02/22  14:21:22  chs
 * remove last vestiges of oracle mail.
 * add ability to send mail to "xband*" to a file instead of internet.
 *
 * Revision 1.25  1996/02/02  15:43:26  chs
 * use gConfig.catapultTown everywhere.
 *
 * Revision 1.24  1995/11/08  18:59:54  jhsia
 * Pull city name out of gConfig when converting mail so it's from "XBAND".
 *
 * Revision 1.23  1995/10/27  18:27:04  steveb
 * Just did some long needed housecleaning.  No new code.
 *
 * Revision 1.22  1995/09/18  16:32:29  chs
 * Fix think-o in from_catapult stuff.
 *
 * Revision 1.21  1995/09/13  14:15:26  ted
 * Fixed warnings.
 *
 * Revision 1.20  1995/08/29  19:20:25  chs
 * Always deliver mail if it's from xband* or *@catapent.com.
 * Check sender's flags only if (box == -1).  This will catch
 * "Reset Scan" (etc) mail as well as internet mail.
 * Fix a bug I introduced by changing the sort key from the time
 * to the serialnumber where internet mail is always put at the front
 * of the receiver's queue.
 *
 * Revision 1.19  1995/08/29  16:36:39  steveb
 * Fixed change I made in previous rev to actually compile.
 *
 * Revision 1.18  1995/08/29  16:33:06  steveb
 * Write out box when mail is deleted.
 *
 * Revision 1.17  1995/08/21  13:05:43  steveb
 * Caching rpc.segad re-checkin.
 *
 * Revision 1.16  1995/08/15  18:50:04  steveb
 * Revert to Revision 1.14
 *
 * Revision 1.15  1995/08/11  17:39:45  steveb
 * Caching rpc.segad checkin.  Changes too numerous to mention.
 *
 * Revision 1.14  1995/07/07  00:26:34  chs
 * Initial variables to NULL.   AAAAAAA!
 *
 * Revision 1.13  1995/07/05  16:39:15  chs
 * Sort mail by serial number again.
 * Make sure mail titles are null-terminated.
 *
 * Revision 1.12  1995/06/19  22:15:30  chs
 * Revert non-oracle parts to previous version.
 *
 * Revision 1.11  1995/06/12  17:38:21  chs
 * Added oramail_GetConf(), another helper routine
 * for ora_mail.pc.
 *
 * Revision 1.10  1995/06/05  22:38:07  chs
 * Print out the town and date too.
 *
 * Revision 1.9  1995/05/28  20:41:09  jhsia
 * switch to rcs keywords
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

#include "Server.h"
#include "ServerDataBase.h"
#include "ServerDataBase_priv.h"
#include "Mail.h"
#include "Dates.h"
#include "Common_ReadConf.h"
#include "Common_Missing.h"
#include "DataBase_Cache.h"


void DataBase_FreeBroadcastMail(void);
void DataBase_FreeBroadcastMailMessage(SDBMail *header);

Mail *Database_DuplicateMail(const Mail *mail)
{
Mail 	*copy;
long	mailSize;

	mailSize = sizeof(Mail) + strlen(mail->message);	// +1 taken care of by message[1]
	
	copy = (Mail *)malloc(mailSize);
	ASSERT_MESG(copy, "out of mems");
	
	if(copy)
	{
		*copy = *mail;
		strcpy(copy->message, mail->message);
	}
	
	return(copy);
}

//
// This routine doesn't use the userID yet, but it eventually will in order to
// filter and send targetted mail.
//
// a more sophisticated thing would be to go thru the list and count the number
// of mails who's sort id (which is a timestamp) is greater than some timestamp
// stored in the user account.
//
long DataBase_GetNumBroadcastMail(unsigned long lastTimeStamp)
{
long		count;
ListNode	*node;

	ASSERT(gSDB);
	ASSERT(gSDB->broadcastMail);

	node = GetFirstListNode(gSDB->broadcastMail);
	for(count = 0; node; node = GetNextListNode(node))
	{		
		if(GetSortedListNodeKey(node) > lastTimeStamp)
			count++;
	}

#ifdef ONEATATIME
// BRAIN DAMAGE... this little hack sends 1 broadcast mail per connect.  See also DataBase_GetBroadcastMail
//
	return(count ? 1 : 0);	// hack
#else
	return(count);
#endif
}

long DataBase_GetNumIncomingMail(const userIdentification *userID)
{
	SDBBoxCachePtr entry;
	SDBUser	*recvr;
	long	numMails;

	recvr = Database_FindUser( userID, &entry );
	if(!recvr)
	{
		ERROR_MESG("Impl error: there should be a user account.. DataBase_CheckAccount should have been called");
		return(0);
	}
	
	ASSERT(recvr->incomingMail);
	if (!recvr->incomingMail) {
		PLogmsg(LOGP_FLAW, "Bad case in GetNumIncomingMail, aborting\n");
		Common_Abort();
	}
	numMails = NumListNodesInList(recvr->incomingMail);
	
	return(numMails);
}

Mail *DataBase_GetIncomingMail(const userIdentification *userID, long mailIndex)
{
	SDBBoxCachePtr entry;
	SDBUser		*recvr;
	Mail		*mail;
	ListNode	*node;
	long		i, numMails;
	SDBMail		*header;

	recvr = Database_FindUser( userID, &entry );
	if(!recvr)
	{
		ERROR_MESG("Impl error: there should be a user account.. DataBase_CheckAccount should have been called");
		return(0);
	}
	
	numMails = NumListNodesInList(recvr->incomingMail);

	ASSERT(numMails > 0);
	
	if(mailIndex < 0 || mailIndex >= numMails)
	{
		ERROR_MESG("mailIndex not in range");
		return(NULL);
	}
	
	node = GetFirstListNode(recvr->incomingMail);
	for(i = 0; i < mailIndex; i++)
	{
		node = GetNextListNode(node);
		if(!node)
		{
			ERROR_MESG("Impl error: not as many mails in incoming as NumListNodesInList reported!?!");
			return(NULL);
		}
	}
	
	ASSERT(node);
	header = (SDBMail *)GetListNodeData(node);
	ASSERT(header);
	mail = header->mail;
	ASSERT(mail);

	return(mail);
}

//
// Will send a broadcast mail to a given user only once.  Uses mail timestamp and the
// lastBroadcastMailSent stamp in each user account to do this.
//
Mail *DataBase_GetBroadcastMail(unsigned long *lastTimeStamp, long mailIndex)
{
Mail		*mail;
ListNode	*node;
long		numMails;
SDBMail		*header;


	numMails = NumListNodesInList(gSDB->broadcastMail);

	ASSERT(numMails > 0);
	
	if(mailIndex < 0 || mailIndex >= numMails)
	{
		ERROR_MESG("mailIndex not in range");
		return(NULL);
	}
	

#ifndef ONEATATIME

	for( node = GetFirstListNode(gSDB->broadcastMail); node; node = GetNextListNode(node))
	{
		if(GetSortedListNodeKey(node) > *lastTimeStamp)
			if(!mailIndex--)
				break;
	}

	if (node == NULL) {
		// Stupid UDP RPCs were doing this
		PLogmsg(LOGP_FLAW,
			"GLITCH: somebody called DataBase_GetBroadcastMail twice??\n");
		return (NULL);
	}
	
	ASSERT(node);
	header = (SDBMail *)GetListNodeData(node);
	ASSERT(header);
	mail = header->mail;
	ASSERT(mail);

	*lastTimeStamp = GetSortedListNodeKey(node);

	return(mail);

#else

	node = node2 = GetFirstListNode(gSDB->broadcastMail);
	for(i = -1; i < mailIndex; node2 = GetNextListNode(node))
	{
		node = node2;
		if(!node)
		{
			ERROR_MESG("Impl error: not as many mails in incoming as NumListNodesInList reported!?!");
			return(NULL);
		}
		
		if(GetSortedListNodeKey(node) >= *lastTimeStamp)
			i++;
	}
	
	ASSERT(node);
	header = (SDBMail *)GetListNodeData(node);
	ASSERT(header);
	mail = header->mail;
	ASSERT(mail);

//
// BRAIN DAMAGE.  This hack sends the list of broadcast mails, one per connect, then starts
//					at the front of the list again!  Ha ha ha!
//

	node2 = node;
	if(node2)
		for(node2 = GetNextListNode(node2); node2; node2 = GetNextListNode(node2))
			i++;

	if(i == 0)
		*lastTimeStamp = 0;
	else
		*lastTimeStamp = GetSortedListNodeKey(node) + 1;

	return(mail);

#endif ONEATATIME
}


void DataBase_MarkMailAsSent(const userIdentification *userID, long mailIndex )
{
	SDBBoxCachePtr entry;
	SDBUser		*recvr;
	ListNode	*node;
	long		i, numMails;
	SDBMail		*header;

	recvr = Database_FindUser( userID, &entry );
	if(!recvr)
	{
		ERROR_MESG("Impl error: there should be a user account.. DataBase_CheckAccount should have been called");
		return;
	}
	
	numMails = NumListNodesInList(recvr->incomingMail);

	ASSERT(numMails > 0);
	
	if(mailIndex < 0 || mailIndex >= numMails)
	{
		ERROR_MESG("mailIndex not in range");
		return;
	}
	
	node = GetFirstListNode(recvr->incomingMail);
	for(i = 0; i < mailIndex; i++, node = GetNextListNode(node))
	{
		if(!node)
		{
			ERROR_MESG("Impl error: not as many mails in incoming as NumListNodesInList reported!?!");
			return;
		}
	}
	
	ASSERT(node);
	header = (SDBMail *)GetListNodeData(node);
	ASSERT(header);
	header->sentToBox = true;
}


void DataBase_RemoveSentMail(const userIdentification *userID )
{
	SDBBoxCachePtr entry;
	SDBUser		*recvr;
	ListNode	*node, *node2;
	SDBMail		*header;

	recvr = Database_FindUser( userID, &entry );
	if(!recvr)
	{
		ERROR_MESG("Impl error: there should be a user account.. DataBase_CheckAccount should have been called");
		return;
	}

	node = GetFirstListNode(recvr->incomingMail);
	while(node)
	{
		node2 = GetNextListNode(node);

		header = (SDBMail *)GetListNodeData(node);
		ASSERT(header);

		if(header->sentToBox)
		{
			RemoveListNodeFromList(node);
			ASSERT(header->mail);
			free(header->mail);
			free(header);
			DisposeListNode(node);
		}
		
		node = node2;
	}

	/* Save the box to disk */
	gWRinfo.type = kBoxWrite;
	gWRinfo.data = NULL;
	gWRinfo.cache = gCache;
 
	Cache_WriteBox(entry, &gWRinfo);
}

//
// Add Mail to the database
//
//
Err DataBase_AddMailToIncoming(const Mail *mail)
{
	extern FILE *gXBANDMailFile;

    SDBBoxCachePtr	sentry, rentry;
    SDBBoxPtr		sbox, rbox;
    SDBUser		*sender, *recvr;
    Mail		*m;
    ListNode		*node;
    SDBMail		*header;
    int			to_inet, from_catapult;
    const char		*cp;
	int i;

    sbox = NULL;
    to_inet = false;
    from_catapult = false;

	// Database_CheckAccount is called by Server_ValidateLogin
	// to validate/setup a user account.

	if (strchr(mail->to.userName, '@') != NULL) {
	    to_inet = true;
	    goto logme;
	}

	/*
	 * use the From name to determine whether
	 * we should skip various checks.
	 */
	if (!strncasecmp((char *)mail->from.userName, "xband", 5)) {
	    from_catapult = true;
	}

	for (cp = mail->from.userName;
	     isalnum(*cp) || *cp == '-' || *cp == '.' || *cp == '_';
	     cp++) ;

	if (!strcasecmp((char *)cp, "@catapent.com")) {
	    from_catapult = true;
	}

	/*
	 * Check the sender's boxflags if it's not from the internet.
	 * All internet mail should have (box == -1),
	 * so we shouldn't need to check for an @ anymore.
	 */
	if (mail->from.box.box != -1) {
	    sender = Database_FindUser(&mail->from, &sentry);
	    if (sender == NULL) {
		Logmsg("AddMailToIncoming: sender unknown (%d,%d)[%d] '%s'\n",
		       mail->from.box.box, mail->from.box.region,
		       mail->from.userID, mail->from.userName);
	    }
	    else {
		/* 
		 * fetch the box entry
		 */
		gRDinfo.type  = kBoxRead;
		gRDinfo.data  = NULL;
		gRDinfo.cache = gCache;
		sbox = Cache_ReadBox(sentry, &gRDinfo);

		ASSERT(sbox);
		if (sbox == NULL)
		    return (kFucked);

		if (sbox->boxAccount.boxFlags & kBoxFlag_DisableOutgoingMail)
		    return kMailNotDelivered_OutgoingMailDisabled;
	    }
	}

	// more poo for Japan:
	// if the To address starts with "xband" and it's not to the internet
	// AND we're using a XBAND-Mail file, stick the message in the file
	// and we're done.
	//
	if (sbox
		&& !strncasecmp((char *)mail->to.userName, "xband", 5)
		&& strchr((char *)mail->to.userName, '@') == NULL
		&& gXBANDMailFile)
	{
		char *textdate;
		time_t now;

		now = time(NULL);
		textdate = ctime(&now);
		textdate[25] = 0;
		fprintf(gXBANDMailFile,
				"%s\t%s\t%ld %ld %d\t%s\t%ld\t%s\t%ld\t%s\t%s\n",
				mail->to.userName,
				mail->from.userName,
				mail->from.box.box,
				mail->from.box.region,
				mail->from.userID,
				sbox->boxAccount.gamePhone.phoneNumber,
				sbox->boxAccount.platformID,
				textdate,
				now,
				mail->title,
				mail->message);
		fflush(gXBANDMailFile);

		to_inet = true;
		goto logme;
	}

	recvr = Database_FindUser(&mail->to, &rentry);
	if (recvr == NULL)
		return(kNoSuchUserAccount);

	/*
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	rbox = Cache_ReadBox(rentry, &gRDinfo);

	ASSERT(rbox);
	if ( rbox == NULL )
		return (kFucked);

	if (!from_catapult &&
	    rbox->boxAccount.boxFlags & kBoxFlag_DisableIncomingMail)

		return(kMailNotDelivered_IncomingMailDisabled);

	if(rbox->userAccount.accountStatus == CAT_ACCT_STATUS_CLOSED)
		return(kMailNotDelivered_AccountClosed);

	// Check that he doesn't already have 25 mails waiting.
	node = GetFirstListNode(recvr->incomingMail);
	if (node && !from_catapult)
	{
		header = (SDBMail *)GetListNodeData(node);
		ASSERT(header);
		ASSERT(header->mail);
		
		// handle wrapped mailSerNum (16K mails!)
		if(recvr->mailSerialNumber < header->mail->serialNumber)
		{
			if(recvr->mailSerialNumber >= kMaxMailsInBox)
				return(kMailNotDelivered_TooManyMails);
		}
		else
		if ((recvr->mailSerialNumber - header->mail->serialNumber)
		    >= kMaxMailsInBox)
		{
			return(kMailNotDelivered_TooManyMails);
		}
	}


	//
	// Log all mail
	// (moved here from Server_ProcessSendQ.c)
	//
    logme:


	// turn colons into slashes so mailscan is happier
	//
	for (i = 0; i < sizeof(mail->from.userName); i++)
	{
		if (mail->from.userName[i] == ':')
			((char *)mail->from.userName)[i] = '/';
	}

	FPLogmsg(LOG_XBANDMAIL, LOGP_NOTICE,
	    ":%ld/%02ld/%02ld:%s(%ld,%ld,%ld):%s:%d: %s : %s\n",
	    (mail->date & kYearMask) >> kYearShift,
	    ((mail->date & kMonthMask) >> kMonthShift) +1,
	    (mail->date & kDayMask) >> kDayShift,
	    mail->from.userName,
	    mail->from.box.box,
	    mail->from.box.region,
	    (long)mail->from.userID,
	    mail->to.userName,
	    strlen(mail->title) + 2,
	    mail->title,
	    mail->message);

	//
	// if mail is bound for the internet, all we do is log it.
	//
	if (to_inet)
		return(kNoError);

	//
	// Now add the mail.
	//
	m = Database_DuplicateMail(mail);
	ASSERT(m);
	m->serialNumber = recvr->mailSerialNumber++;

	if (sbox != NULL) {
	    m->from.ROMIconID = Common_ConvertROMIconID(
		sbox->boxAccount.platformID,
		rbox->boxAccount.platformID,
		m->from.ROMIconID);
	}

	// Silly hack to make it easier for "official" mail to be sent from
	// Eudora.
	//
	if ((strcmp(m->from.userName, "support@catapent.com") == 0) ||
		(strcmp(m->from.userName, "beta@catapent.com") == 0))
	{
		Logmsg("Converted mail from %s to XBAND\n", m->from.userName);
		strcpy(m->from.userName, "XBAND");
		strcpy(m->from.userTown, gConfig.catapultTown);
		m->from.ROMIconID = kXBANDPlayerIcon;
	}

	header = (SDBMail *)malloc(sizeof(SDBMail));
	ASSERT(header);
	header->mail = (Mail *)m;
	header->sentToBox = false;	

	node = NewSortedListNode((Ptr)header, (unsigned long)m->serialNumber);
	AddListNodeToSortedList(recvr->incomingMail, node);

	/* Save the box to disk */
	gWRinfo.type = kBoxWrite;
	gWRinfo.data = NULL;
	gWRinfo.cache = gCache;
 
	return(Cache_WriteBox(rentry, &gWRinfo));
}

// Non-API routine; does the dirty work.
Err DataBase_AddStampedMailToBroadcast(const Mail *mail, unsigned long timeStamp)
{
//SDBUser 	*sender;
Mail		*m;
ListNode	*node;
SDBMail		*header;

	// This mail is generally from Catapult...
	//
	//sender = Database_FindUser(  &mail->from );
	//ASSERT_MESG(sender, "If Database_CheckAccount was called before FindUser, this call CANNOT FAIL!?!?");

	m = Database_DuplicateMail(mail);
	m->serialNumber = 0;								// 0 serial number
	ASSERT(m);
	header = (SDBMail *)malloc(sizeof(SDBMail));
	ASSERT(header);
	header->mail = (Mail *)m;							// cast the const to make metrowerks happy.
	header->sentToBox = false;	
	
	// Timestamp the mail so we can avoid sending it twice to a given user.
	//
	node = NewSortedListNode((Ptr)header, timeStamp);
	AddListNodeToSortedList(gSDB->broadcastMail, node);

	//Logmsg("Added broadcast[%d] (%s: '%s')\n", timeStamp,
	//	mail->from.userName, mail->message);

	return(kNoError);
}

//
// Load broadcast mail files into database.
//
// Syntax rules:
// - Blank lines and lines beginning with '#' are ignored.
// - Everything up to the first "%%" is ignored.
// - Every entry must be followed by "%%".  
// - First line is '!', eight 'x's, and '!'; this gets changed into a timestamp.
// - Second line is "from", third line is "town", fourth is "date" (year,
//   month, day), fifth line is "title", sixth is "message".  This
//   ordering is fixed; the two-character tags are there for sanity checking
//   and readability.
// - If garbage is detected, this routine scans ahead to the next %%.
//
// %%
// !xxxxxxxx!
// FR Catapult
// TN Happy Town
// DA 1994 8 3
// TI This is the title
// MS This is the message.  It must fit on a single line.
// %%
// !xxxxxxxx!
// FR Cataplot
// TN Another Town
// DA 1994 8 4
// TI This is the second title.
// MS This is yet another broadcast mail message.
// %%
//
#define MY_MAX_MAIL_MESG_SIZE 512

Err DataBase_LoadBroadcastMail()
{
enum { kLookForPercent, kTimeStamp, kFrom, kTown, kDate, kTitle, kMessage };
FILE	*fp;
char	linebuf[MY_MAX_MAIL_MESG_SIZE+4], stampbuf[9];
long	state, len, year, month, day;
Mail	*fakem;
long	cur_offset, stamp_offset;
unsigned long	timeStamp;
userIdentification	catapult = {{-1, -1}, 0, 0, kXBANDPlayerIcon, "Broadcast", "Catapult"};

	if ((fp = fopen(kSDB_BMail, "r+")) == NULL) {	// do NOT want "rb"
		PLogmsg(LOGP_NOTICE, "NOTE: couldn't open '%s'\n", kSDB_BMail);
		return (kNoError);	// little white lie
	}
	
	fakem = (Mail *)malloc(sizeof(Mail) + MY_MAX_MAIL_MESG_SIZE);
	ASSERT(fakem);

	state = kLookForPercent;
	while (1) {
		fgets(linebuf, MY_MAX_MAIL_MESG_SIZE+4, fp);
		if (feof(fp) || ferror(fp)) break;

		if (linebuf[strlen(linebuf)-1] == '\n')
			linebuf[strlen(linebuf)-1] = '\0';
		if (linebuf[0] == '\0' || linebuf[0] == '#') continue;

		switch (state) {
		case kLookForPercent:
			if (strcmp(linebuf, "%%") == 0) {
				state = kTimeStamp;
				stamp_offset = ftell(fp);	// should be start of timestamp line
			}
			break;
		case kTimeStamp:
			if (linebuf[0] != '!' || linebuf[9] != '!') {
				PLogmsg(LOGP_FLAW, "Mail: expected timestamp, got '%s'\n",
					linebuf);
				state = kLookForPercent;
				break;
			}
			timeStamp = 0;
			if (strncmp("xxxxxxxx", linebuf+1, 8) != 0) {
				stamp_offset = 0;	// date already set, don't write to file
				(void) sscanf(linebuf+1, "%8lx", &timeStamp);
			} else {
				timeStamp = 0;		// generate a new one
			}
			state = kFrom;
			break;
		case kFrom:
			if (strncmp(linebuf, "FR ", 3) != 0) {
				PLogmsg(LOGP_FLAW, "Mail: expected FR, got '%s'\n", linebuf);
				state = kLookForPercent;
				break;
			}
			// fake account with boxID(-1,-1) and userName from mail file
			strncpy(catapult.userName, linebuf+3, kUserNameSize-1);
			catapult.userName[kUserNameSize-1] = '\0';
			fakem->from = catapult;
			state = kTown;
			break;
		case kTown:
			if (strncmp(linebuf, "TN ", 3) != 0) {
				PLogmsg(LOGP_FLAW, "Mail: expected TN, got '%s'\n", linebuf);
				state = kLookForPercent;
				break;
			}
			strncpy(catapult.userTown, linebuf+3, kUserTownSize-1);
			catapult.userTown[kUserTownSize-1] = '\0';
			fakem->from = catapult;
			state = kDate;
			break;
		case kDate:
			if (strncmp(linebuf, "DA ", 3) != 0) {
				PLogmsg(LOGP_FLAW, "Mail: expected DA, got '%s'\n", linebuf);
				state = kLookForPercent;
				break;
			}
			if (sscanf(linebuf+3, "%ld %ld %ld", &year, &month, &day) != 3)
				state = kLookForPercent;
			month--;	// sega months start with 0.  sega days start with 1.
			fakem->date = Date(year, month, day);
			state = kTitle;
			break;
		case kTitle:
			if (strncmp(linebuf, "TI ", 3) != 0) {
				PLogmsg(LOGP_FLAW, "Mail: expected TI, got '%s'\n", linebuf);
				state = kLookForPercent;
				break;
			}
			strncpy(fakem->title, linebuf+3, kTitleSize-1);
			fakem->title[kTitleSize-1] = '\0';
			state = kMessage;
			break;
		case kMessage:
			if (strncmp(linebuf, "MS ", 3) != 0) {
				PLogmsg(LOGP_FLAW, "Mail: expected MS, got '%s'\n", linebuf);
				state = kLookForPercent;
				break;
			}
			strncpy(fakem->message, linebuf+3, MY_MAX_MAIL_MESG_SIZE-1);
			fakem->message[MY_MAX_MAIL_MESG_SIZE-1] = '\0';

			// we should have the full message now, so add it to the DB
			if (timeStamp == 0) {
				timeStamp = (unsigned long)time(0);
			}
			DataBase_AddStampedMailToBroadcast(fakem, timeStamp);

			// if timestamp wasn't read in, back up and stuff it into the file
			if (stamp_offset) {
				cur_offset = ftell(fp);
				sprintf(stampbuf, "%.8lx", timeStamp);
				fseek(fp, stamp_offset+1, 0);	// math on offsets is evil
				len = fwrite(stampbuf, 1, 8, fp);
				fseek(fp, cur_offset, 0);
			}

			state = kLookForPercent;
			break;
		default:
			PLogmsg(LOGP_FLAW, "Bad state in BroadcastMail\n");
			goto error;
		}
	}

error:
	fclose(fp);
	free(fakem);
	return (kNoError);	// little white lie when exiting via error
}
#undef MY_MAX_MAIL_MESG_SIZE

void DataBase_PrintMail(const Mail *mail)
{
	Logmsg("Mail from: '%s' (%d,%d)\n", mail->from.userName,
		mail->from.box.box, mail->from.box.region);
	Logmsg("     to: '%s' (%d,%d)\n", mail->to.userName,
		mail->to.box.box, mail->to.box.region);
	Logmsg("     town: '%s'\n", mail->from.userTown);
	Logmsg("     date: %d %d %d\n",
	       MonthOfDate(mail->date) + 1,
	       DayOfDate(mail->date),
	       YearOfDate(mail->date));
	Logmsg("     subject: '%s'\n", mail->title);
	Logmsg("     message: '%s'\n", mail->message);
}


void DataBase_FreeBroadcastMailMessage(SDBMail *header)
{
	free(header->mail);
	free(header);
	return;
}

void DataBase_FreeBroadcastMail(void)
{
	ListNode *lnode;

	if (gSDB->broadcastMail == NULL)
		return;

	for (lnode = GetFirstListNode(gSDB->broadcastMail); lnode != NULL;
		lnode = GetNextListNode(lnode))
	{
		DataBase_FreeBroadcastMailMessage((SDBMail *) lnode->data);
	}
	DisposeList(gSDB->broadcastMail);
	gSDB->broadcastMail = NULL;
}

void DataBase_ReloadBroadcastMail(void)
{
	DataBase_FreeBroadcastMail();

	gSDB->broadcastMail = NewSortedList();		// zot
	PLogmsg(LOGP_NOTICE, "ERASED broadcast mail, reloading\n");
	(void) DataBase_LoadBroadcastMail();
}
