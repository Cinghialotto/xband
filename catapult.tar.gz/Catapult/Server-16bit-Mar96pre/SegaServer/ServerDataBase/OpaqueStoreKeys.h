/*
 * Copyright:	� 1995 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: OpaqueStoreKeys.h,v 1.9 1995/12/04 16:38:22 chs Exp $
 *
 * $Log: OpaqueStoreKeys.h,v $
 * Revision 1.9  1995/12/04  16:38:22  chs
 * Added new key for single-elimination tourney info.
 *
 * Revision 1.8  1995/09/13  14:15:37  ted
 * Fixed warnings.
 *
 * Revision 1.7  1995/06/19  17:35:11  ted
 * Added kXBNFreebieCountKey.
 *
 * Revision 1.6  1995/06/05  22:25:21  chs
 * Added kChallengeCountKey.
 *
 * Revision 1.5  1995/05/28  20:41:27  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		OpaqueStoreKeys.h

	Contains:	Keys for box and player opaque stores

	Written by:	Ted Cohn


	Usage:
	
	OpaqueStore keys are distinct and separate between box and player opaque stores.
*/



// OpaqueStoreKeys for Box Account

#define	kBoxTourneyInfo		1		// TourneyLite
#define	kSmartcardRentalKey 2
#define kTestServerKey		3		// Route people to test server
#define kXBNBoxUsageKey		4		// Stores Nationwide minutes used per box

// OpaqueStoreKeys for Player Account

#define kXBNFreebieCountKey	1		// running count of unsuccessfull games
#define kChallengeCountKey	4
#define kSingleEliminationTourneyKey 5


typedef struct TestServerStore
{
	long version;			// 0 = selector and switch fields only
	char selector[8];		// selector to send from main server, e.g. "SG02"
	char switchserver;		// set once to pass box to opposite server
} TestServerStore;

/* Server Switching Logic:

when present on production:
	if passtotest set, send down selector and clear passtotest.

when present on test server:
	if passtomain set, send down main selector and clear passtomain.
*/
