/*
 *	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 *	$Id: DataBase_UserAccess.c,v 1.24 1995/10/27 18:27:06 steveb Exp $
 *
 *	$Log: DataBase_UserAccess.c,v $
 * Revision 1.24  1995/10/27  18:27:06  steveb
 * Just did some long needed housecleaning.  No new code.
 *
 * Revision 1.23  1995/09/27  18:39:24  hufft
 * added Common_Phone support for Japan Server
 *
 * Revision 1.22  1995/09/13  14:15:31  ted
 * Fixed warnings.
 *
 * Revision 1.21  1995/08/23  16:34:40  steveb
 * Fixed bogus ASSERT message in NameSTree_RemoveUser.
 *
 * Revision 1.20  1995/08/21  13:10:14  steveb
 * Caching rpc.segad re-checkin.
 *
 * Revision 1.19  1995/08/15  18:53:37  steveb
 * Revert to Revision 1.17
 *
 * Revision 1.18  1995/08/11  17:39:48  steveb
 * Caching rpc.segad checkin.  Changes too numerous to mention.
 *
 * Revision 1.17  1995/08/02  17:35:56  jhsia
 * prototype change for DataBase_FindUserByName
 *
 * Revision 1.16  1995/07/07  20:57:47  fadden
 * Use Common_IsValidHWID instead of just checking against kHWID_NoHWID.
 *
 * Revision 1.15  1995/07/07  00:18:00  fadden
 * Remove debugging logmsgs (it works, yay).
 *
 * Revision 1.14  1995/07/04  22:56:30  fadden
 * Changed slimy linear HardwareID lookups to splay-tree lookups.
 *
 * Revision 1.13  1995/06/19  20:56:26  fadden
 * Linear-search implementation of Database_FindBoxByHWID.
 *
 * Revision 1.12  1995/06/09  22:38:29  fadden
 * Return cleanly from Database_FindBoxByPhone if boxReturn == NULL.
 *
 * Revision 1.11  1995/06/01  15:12:24  fadden
 * Merge in from newbr.
 * -> Added platformID check, added "any open" search, fixed bugs in "repl"
 * search.
 *
 * Revision 1.10  1995/05/28  20:41:19  jhsia
 * switch to rcs keywords
 *
 */

#include <string.h>
#include <stdlib.h>

#include "Server.h"
#include "ServerDataBase.h"
#include "ServerDataBase_priv.h"
#include "Common_List.h"
#include "Common_Log.h"
#include "Errors.h"
#include "Util_MFA.h"
#include "Util_STree.h"

#include "DataBase_Cache.h"

#undef VERBOSE

/*****************************************************************************\
	Structures
\*****************************************************************************/
typedef struct SDBBoxListPrivate {
	unsigned long	nBoxes;

	MFA		byRegion; 	/* MFA sorted byBoxID. Contains (SDBBoxCachePtr) */
	STree	byName;		/* Contains (SDBBoxCachePtr). Key is (char *) */
	STree	byPhone;	/* Contains (SDBBoxCachePtr). Key is (phoneNumber *) */
	STree	byHWID;		/* Contains (SDBBoxCachePtr). Key is (HardwareID *) */
	STree	byCSID;		/* Contains (SDBBoxCachePtr). Key is (unsigned long) */
} SDBBoxListPrivate;

/* For iterating through boxes */

typedef struct DBForEachBoxParam {
	MFAForEachProc		action;
	void				*refCon;
} DBForEachBoxParam;

/* Name node */
typedef struct NameSTreeNode {
	char 			*userName;
	unsigned char	player;
	SDBBoxCachePtr	entry;
} NameSTreeNode;

/* Multiple phone number node */

typedef enum PhoneListType {
	kEmptyBox	= 0x00000000,
	kSingleBox	= 0xFE0DF0E5,
	kManyBoxes	= 0xF0EDF155
} PhoneListType;

/* For phone tree only */
typedef struct SDBBoxPhoneList {
	unsigned long	nEntries;
	SDBBoxCachePtr	*entries;
} SDBBoxPhoneList;

typedef struct PhoneSTreeNode {
	phoneNumber	*phoneNumber;
	long		oType;
	union {
		SDBBoxCachePtr  entry;
		SDBBoxPhoneList	many;
	} data;
} PhoneSTreeNode;

/* Multiple hardwareID node */

typedef enum HWIDListType {
	kHWIDEmptyBox	= 0x00000000,
	kHWIDSingleBox	= 0xEFD03F5E,
	kHWIDManyBoxes	= 0xEFD31F55
} HWIDListType;

/* For HWID tree only */
typedef struct SDBBoxHWIDList {
	unsigned long	nEntries;
	SDBBoxCachePtr	*entries;
} SDBBoxHWIDList;

typedef struct HWIDSTreeNode {
	HardwareID	  *hardwareID;
	HWIDListType  oType;
	union {
		SDBBoxCachePtr	entry;
		SDBBoxHWIDList	many;
	} data;
} HWIDSTreeNode;

/* CSID node */
typedef struct CSIDSTreeNode {
	unsigned long	csid;
	SDBBoxCachePtr	entry;
} CSIDSTreeNode;

/*****************************************************************************\
	Static Prototypes
\*****************************************************************************/

static SDBBoxList Database_GetBoxList(
	SDB				*sdb);

static Err RegionMFA_AddBox(
	MFA				byRegion,
	SDBBoxCachePtr	entry);

static Err RegionMFA_RemoveBox(
	MFA			   byRegion,
	SDBBoxCachePtr entry);

static Err RegionMFA_ForEach(
	MFA					regionMFA,
	DBForEachBoxParam	*param);

/* Name Tree */

static NameSTreeNode *NameSTreeNode_New(
	SDBBoxCachePtr  entry,
	unsigned char	player);

static void NameSTreeNode_Delete(
	NameSTreeNode	*node);

static Err NameSTree_AddBox(
	STree			byName,
	SDBBoxCachePtr	entry);

#ifdef UNUSED
static Err NameSTree_RemoveBox(
	STree			byName,
	SDBBoxCachePtr	entry);
#endif UNUSED

static Err NameSTree_AddUser(
	STree			byName,
	SDBBoxCachePtr	entry,
	unsigned char	player);

static Err NameSTree_RemoveUser(
	STree			byName,
	SDBBoxCachePtr	entry,
	unsigned char	player);

static long NameSTree_CompareNodeToNode(
	NameSTreeNode	*node1,
	NameSTreeNode	*node2);

static long NameSTree_CompareNameToNode(
	char			*name,
	NameSTreeNode	*node);

/* Phone Tree */

static Err PhoneSTree_AddBox(
	STree			byPhone,
	SDBBoxCachePtr	entry);

static Err PhoneSTree_RemoveBox(
	STree			byPhone,
	SDBBoxCachePtr	entry);

static long PhoneSTree_CompareNodeToNode(
	PhoneSTreeNode		*node1,
	PhoneSTreeNode		*node2);

static long PhoneSTree_ComparePhoneToNode(
	phoneNumber			*phone,
	PhoneSTreeNode		*node);

static PhoneSTreeNode *PhoneSTreeNode_New(
	SDBBoxCachePtr	    entry);

static Err PhoneSTreeNode_AddBox(
	PhoneSTreeNode		*node,
	SDBBoxCachePtr		entry);

static Err PhoneSTreeNode_RemoveBox(
	PhoneSTreeNode		*node,
	SDBBoxCachePtr		entry,
	Boolean				*isEmpty);

static void PhoneSTreeNode_Delete(
	PhoneSTreeNode		*node);

/* HWID Tree */

static Err HWIDSTree_AddBox(
	STree			byHWID,
	SDBBoxCachePtr	entry);

static Err HWIDSTree_RemoveBox(
	STree			byHWID,
	SDBBoxCachePtr	entry);

static long HWIDSTree_CompareNodeToNode(
	HWIDSTreeNode		*node1,
	HWIDSTreeNode		*node2);

static long HWIDSTree_CompareHWIDToNode(
	HardwareID			*hardwareID,
	HWIDSTreeNode		*node);

static HWIDSTreeNode *HWIDSTreeNode_New(
	SDBBoxCachePtr		entry);

static Err HWIDSTreeNode_AddBox(
	HWIDSTreeNode		*hn,
	SDBBoxCachePtr		entry);

static Err HWIDSTreeNode_RemoveBox(
	HWIDSTreeNode		*node,
	SDBBoxCachePtr		entry,
	Boolean				*isEmpty);

static void HWIDSTreeNode_Delete(
	HWIDSTreeNode		*node);

/* CSID Tree */

static CSIDSTreeNode *CSIDSTreeNode_New(
	SDBBoxCachePtr  entry);

static void CSIDSTreeNode_Delete(
	CSIDSTreeNode	*node);

static Err CSIDSTree_AddBox(
	STree			byCSID,
	SDBBoxCachePtr	entry);

static Err CSIDSTree_RemoveBox(
	STree			byCSID,
	SDBBoxCachePtr	entry);

static long CSIDSTree_CompareCSIDToNode(
	unsigned long		csid,
	CSIDSTreeNode		*node);

static long CSIDSTree_CompareNodeToNode(
	CSIDSTreeNode		*node1,
	CSIDSTreeNode		*node2);

/*============================================================================*\
	Database_NewBoxList
\*============================================================================*/
SDBBoxList Database_NewBoxList(
	void)
{
	SDBBoxList	boxList;
	
	boxList = (SDBBoxList) malloc(sizeof(SDBBoxListPrivate));
	
	if (boxList == NULL)
		return NULL;
	
	boxList->nBoxes			= 0;
	boxList->byRegion	= MFA_New((void (*)(void *)) MFA_Delete);
	
	/* Need notification of new user addition to a box... */
	boxList->byName	= STree_New(
		(STreeCompareFunc) NameSTree_CompareNameToNode,
		(STreeCompareFunc) NameSTree_CompareNodeToNode,
		NULL);

	/* Need notification of phone number changes... */
	boxList->byPhone = STree_New(
		(STreeCompareFunc) PhoneSTree_ComparePhoneToNode,
		(STreeCompareFunc) PhoneSTree_CompareNodeToNode,
		NULL);

	/* Need notification of hardwareID changes... */
	boxList->byHWID = STree_New(
		(STreeCompareFunc) HWIDSTree_CompareHWIDToNode,
		(STreeCompareFunc) HWIDSTree_CompareNodeToNode,
		NULL);

	/* Need notification of CSID changes... */
	boxList->byCSID = STree_New(
		(STreeCompareFunc) CSIDSTree_CompareCSIDToNode,
		(STreeCompareFunc) CSIDSTree_CompareNodeToNode,
		NULL);

	// Make sure all the sub-parts got created right.
	//
	if ((boxList->byRegion == NULL) ||
		(boxList->byName == NULL) ||
		(boxList->byPhone == NULL) ||
		(boxList->byHWID == NULL) ||
		(boxList->byCSID == NULL))
	{
		// Originally there were three consecutive checks on byName; dbunny
		// did a cut & paste and apparently forget to fix it.  I changed
		// one byName to byPhone, and set up byRegion to yell since I don't
		// feel I understand this well enough.
		//
		if (boxList->byRegion) {
			// ay caramba
			PLogmsg(LOGP_FLAW, "Leaking memory because I'm confused\n");
			boxList->byRegion = NULL;
		}
		if (boxList->byName) {
			STree_Delete(boxList->byName);
			boxList->byName = NULL;
		}
		if (boxList->byPhone) {
			STree_Delete(boxList->byPhone);
			boxList->byPhone = NULL;
		}
		if (boxList->byHWID) {
			STree_Delete(boxList->byHWID);
			boxList->byHWID = NULL;
		}
		if (boxList->byCSID) {
			STree_Delete(boxList->byCSID);
			boxList->byCSID = NULL;
		}

		// Should we free boxList?  Should we return NULL?  WTF?  (Looks like
		// the only caller, in SDBUsers_New(), doesn't check the return value
		// anyway.)  ++ATM 950626
		//
		PLogmsg(LOGP_FLAW, "Database_NewBoxList failed\n");
	}
	return boxList;
}

/*============================================================================*\
	Database_CountBoxes
\*============================================================================*/
unsigned long Database_CountBoxes(
	SDB			*sdb)
{
	SDBBoxList		boxList;
	
	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL) return 0;
	
	return boxList->nBoxes;
}


/*============================================================================*\
	Database_AddBox

	This is called whenever a new box is added.  It inserts the box into
	all the relevant search structures.

\*============================================================================*/
Err Database_AddBox(
	SDB			   *sdb,
	SDBBoxCachePtr entry)
{
	SDBBoxList	boxList;
	SDBBoxPtr   box;

	Assert(entry);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	Assert(box);
	if ( box == NULL )
		return (kFucked);

	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL) return(kFucked);
	
	RegionMFA_AddBox(boxList->byRegion, entry);	
	NameSTree_AddBox(boxList->byName, entry);
	PhoneSTree_AddBox(boxList->byPhone, entry);

	// Only insert into the hwid search tree if they have a valid hwid.
	if (Common_IsValidHWID(&box->boxAccount.hardwareID)) {
		HWIDSTree_AddBox(boxList->byHWID, entry);
#ifdef VERBOSE
		Logmsg("Added (%ld,%ld) to hwid\n", box->boxAccount.box.box,
			box->boxAccount.box.region);
#endif
	} else {
		if (box->boxAccount.hardwareID.hardwareIDtype != kHWID_NoHWID)
			PLogmsg(LOGP_NOTICE, "NOTE: invalid hwid in DB, box (%ld,%ld)\n",
				box->boxAccount.box.box, box->boxAccount.box.region);
	}

	CSIDSTree_AddBox(boxList->byCSID, entry);
	
	boxList->nBoxes++;
	
	return kNoError;
}

/*============================================================================*\
	Database_ForEachBox

	"refCon" is used to pass in an arbitrary chunk of data.

	If the "action" routine returns a nonzero value, the foreach loop
	immediately halts, and this routine returns that value.  Otherwise,
	when the end is reached, zero is returned.
\*============================================================================*/
Err Database_ForEachBox(SDB *sdb, ForEachProc action, void *refCon)
{
  SDBBoxList		boxList;
  DBForEachBoxParam	param;
  
  boxList = Database_GetBoxList(sdb);
  Assert(boxList); 
  if (boxList == NULL) return(kFucked);
  
  param.action	= (MFAForEachProc) action;
  param.refCon	= refCon;
  
  return
    MFA_ForEach(boxList->byRegion,
		(MFAForEachProc) RegionMFA_ForEach,
		(void *) &param);
}

/*============================================================================*\
	Database_FindBoxByBSN
\*============================================================================*/
SDBBox *Database_FindBoxByBSN(
	SDB						*sdb,
	const BoxSerialNumber	*boxSerialNumber,
	SDBBoxCachePtr          *entry)
{
	SDBBoxList		boxList;
	MFA				byBoxID;
	
	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL) return NULL;

	byBoxID = MFA_FindKey(boxList->byRegion, boxSerialNumber->region);
	
	if (byBoxID == NULL)
		return NULL;
	
	*entry = MFA_FindKey(byBoxID, boxSerialNumber->box);
	if ( *entry == NULL )
		return(NULL);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;

	return (Cache_ReadBox(*entry, &gRDinfo));
}

/*============================================================================*\
	Database_BeginUpdateBoxID
\*============================================================================*/
Err Database_BeginUpdateBoxID(
	SDB		       *sdb,
	SDBBoxCachePtr entry)
{
	SDBBoxList		boxList;
	Err				err;
	
	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL)
		return NULL;

	err = RegionMFA_RemoveBox(boxList->byRegion, entry);
	if (err != kNoError)
		return err;
		
	boxList->nBoxes--;
	return kNoError;
}

/*============================================================================*\
	Database_EndUpdateBoxID
\*============================================================================*/
Err Database_EndUpdateBoxID(
	SDB		       *sdb,
	SDBBoxCachePtr entry)
{
	SDBBoxList		boxList;
	Err				err;
	
	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL)
		return NULL;

	err = RegionMFA_AddBox(boxList->byRegion, entry);
	if (err != kNoError)
		return err;
		
	boxList->nBoxes++;
	return kNoError;
}

/*===========================================================================*\

	Database_FindBoxByHWID

	From the list of all accounts that match the hardwareID specified,
	choose the best match.  Criteria is:

	- hardwareID and platformID match
	- prefer open over closed
	- prefer most recently used

	kCSUpdatedFlag_BindLostModem and kCSUpdatedFlag_ReplacementModem aren't
	relevant (detected automatically and handled with replacement mail stuff).

	This routine WILL return a never-before-used account.  This situation
	is impossible in the USA, since we don't add the hwid until the first
	time the player logs in; CEJ only.

	Returns NULL if no matching account is found.

\*===========================================================================*/
SDBBox *
Database_FindBoxByHWID(
	SDB					*sdb,
	const HardwareID	*hwid,
	long				platformID,
	SDBBoxCachePtr 		*entry)
{
	SDBBoxList			boxList;
	HWIDSTreeNode		*hwidNode;
	unsigned long		i, nEntries;
	unsigned long		dateLastConnect;
	unsigned long		accountStatus;
	unsigned long		foundOne;
	SDBBoxCachePtr		*entries;
	SDBBoxPtr           box, boxReturn;

	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL) return (NULL);

	Assert(boxList->byPhone);

	hwidNode = STree_FindDataByKey(boxList->byHWID, (void *) hwid);
	
	if (hwidNode == NULL)
		return (NULL);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;

	if (hwidNode->oType == kHWIDSingleBox) {
		*entry = hwidNode->data.entry;
		if ( *entry == NULL )
			return(NULL);

		box = Cache_ReadBox(*entry, &gRDinfo);
		if ( box == NULL )
			return(NULL);

		if (platformID && box->boxAccount.platformID != platformID)
			return (NULL);	// different platform (impossible?)

		return (box);
	}

	Assert(hwidNode->oType == kHWIDManyBoxes);
	Assert(hwidNode->data.many.nEntries > 1);
	
	foundOne		= 0;
	dateLastConnect	= 0;
	accountStatus 	= CAT_ACCT_STATUS_CLOSED;
	boxReturn		= NULL;
	entries			= hwidNode->data.many.entries;
	nEntries		= hwidNode->data.many.nEntries;
	
	for (i = 0; i < nEntries; i++) {
		*entry = entries[i];
		if ( *entry == NULL )
			continue;

		box = Cache_ReadBox(*entry, &gRDinfo);
		if ( box == NULL )
			continue;

		// Don't return an account from another platform (impossible?)
		if (platformID && box->boxAccount.platformID != platformID)
			continue;

		// Do not consider closed accounts if non-closed account(s) is
		// available at this number
		if (box->userAccount.accountStatus == CAT_ACCT_STATUS_CLOSED &&
			accountStatus != CAT_ACCT_STATUS_CLOSED)
		{
			continue;
		}

		// Ensure that a non-closed account overrides any closed account.
		//
		if (box->userAccount.accountStatus != CAT_ACCT_STATUS_CLOSED &&
			accountStatus == CAT_ACCT_STATUS_CLOSED)
		{
			boxReturn		= box;
			dateLastConnect	= box->userAccount.dateLastConnect;
			accountStatus	= box->userAccount.accountStatus;

			foundOne = 1;
			continue;
		}

		/* If we haven't set boxReturn yet, OR, if the current box is
		   Most Recently Used */
		if ((foundOne == false) ||
			(box->userAccount.dateLastConnect >= dateLastConnect))
		{
			boxReturn	    = box;
			dateLastConnect	= box->userAccount.dateLastConnect;
			accountStatus	= box->userAccount.accountStatus;

			foundOne = 1;
		}
	}

	if (boxReturn == NULL) {
		// This probably can't happen.
		//
		return (NULL);
	}

	if (nEntries > 1)
		Logmsg(
			"Database_FindBoxByHWID: "
			"found %ld matching accounts, "
			"returning most recently used (%ld,%ld) (date=0x%.8lx)\n",
			nEntries,
			boxReturn->boxAccount.box.box, boxReturn->boxAccount.box.region,
			dateLastConnect);
		
	return (boxReturn);
}


/*============================================================================*\
	Database_BeginUpdateHWID

	Begins the hardwareID update procedure, concluded by EndUpdateHWID.
	The caller calls this, then changes the hardwareID value in the account,
	then calls EndUpdateHWID.

	The purpose of this is to remove the existing hwid node from the HWID
	tree.  The entry will exist, having been created by HWIDSTreeNode_New
	via Database_CreateBoxAndPlayerAccount.

	Returning NULL doesn't make any sense, but it doesn't matter, since the
	callers of this routine don't check the return value.
\*============================================================================*/
Err	Database_BeginUpdateHWID(
	SDB			   *sdb,
	SDBBoxCachePtr entry)
{
	SDBBoxList	boxList;
	SDBBoxPtr   box;
	Err			err;
	
	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL) return (kFucked);
	Assert(boxList->byHWID);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	Assert(box);
	if ( box == NULL )
		return (kFucked);

	// If they don't have a hwid, they won't be in the tree, so there'd be
	// no point in removing them.
	if (box->boxAccount.hardwareID.hardwareIDtype != kHWID_NoHWID) {
		return (HWIDSTree_RemoveBox(boxList->byHWID, entry));
	} else {
		// (debug) - remove this sometime
		//Logmsg("debug check ok in BeginUpdateHWID\n");
		err = HWIDSTree_RemoveBox(boxList->byHWID, entry);
		if (err == kNoError) {
			PLogmsg(LOGP_FLAW, "EGAD!! in BeginUpdateHWID\n");
			return (kFucked);
		}
	}
	return (kNoError);
}

/*============================================================================*\
	Database_EndUpdateHWID

	Same story as BeginUpdateHWID: NULL results don't matter.

	The purpose of this is to add the box to the appropriate position in
	the HWID tree.
\*============================================================================*/
Err Database_EndUpdateHWID(
	SDB			   *sdb,
	SDBBoxCachePtr entry)
{
	SDBBoxList	boxList;
	SDBBoxPtr   box;
	
	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL) return NULL;
	Assert(boxList->byHWID);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	Assert(box);
	if ( box == NULL )
		return (kFucked);

	// If they don't have a hwid (or the hwid is invalid), don't add them
	// to the tree.
	if (Common_IsValidHWID(&box->boxAccount.hardwareID)) {
		return (HWIDSTree_AddBox(boxList->byHWID, entry));
	} else {
		// (debug)
		//Logmsg("didn't re-add box (%ld,%ld) to hwid tree\n",
		//	box->boxAccount.box.box, box->boxAccount.box.region);
	}
	return (kNoError);
}

/*============================================================================*\

	Database_FindBoxByPhone

	This tries to find the Most Recently Used account.  If they don't have the 
	dateLastConnect set, then it settles for the Most Recently Created.  If 
	the csUpdatedFlags & kCSUpdatedFlag_BindLostModem then we will choose that 
	account preferentially.  CLOSED accounts are the lowest priority for
	being returned.  In fact, a CLOSED account will only be returned from this
	routine if no other account exists at the boxphonenumber.

	This bit can be set by the Customer Service organization 
	(U.C.A.) to force a crashed modem to bind to a specific account if there 
	are multiple accounts at a single phone number.

	This routine will *not* return a NEW account that has never logged in before.
	4.10.95  DJ

	Passing in platformID==0 will match any platformID.

\*============================================================================*/
SDBBox *Database_FindBoxByPhone(
	SDB					*sdb,
	const phoneNumber	*boxPhoneNumber,
	long				platformID,
	SDBBoxCachePtr		*entry)
{
	SDBBoxList			boxList;
	PhoneSTreeNode		*phoneNode;
	unsigned long		i, nEntries;
	unsigned long		boundLostModem;
	unsigned long		dateLastConnect;
	unsigned long		accountStatus;
	unsigned long		foundOne;
	SDBBoxCachePtr		*entries;
	SDBBoxPtr           box, boxReturn;
	
	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL) return NULL;

	Assert(boxList->byPhone);

	phoneNode = STree_FindDataByKey(boxList->byPhone, (void *) boxPhoneNumber);
	
	if (phoneNode == NULL)
		return NULL;

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	
	if (phoneNode->oType == kSingleBox)
	{
		*entry = phoneNode->data.entry;
		if ( *entry == NULL )
			return(NULL);

		box = Cache_ReadBox(*entry, &gRDinfo);
		if ( box == NULL )
			return (NULL);

        // Do not return a NEW uca-created account that has never logged in.
		if(!box->userAccount.dateLastConnect)
			return (NULL);	

		if (platformID && box->boxAccount.platformID != platformID)
			return (NULL);	// don't return acct from another platform

		return (box);
	}

	Assert(phoneNode->oType == kManyBoxes);
	Assert(phoneNode->data.many.nEntries > 1);
	
	boundLostModem	= 0;
	foundOne		= 0;
	dateLastConnect	= 0;
	accountStatus 	= CAT_ACCT_STATUS_CLOSED;
	boxReturn		= NULL;
	entries			= phoneNode->data.many.entries;
	nEntries	    = phoneNode->data.many.nEntries;
	
	for (i = 0; i < nEntries; i++) 
	{
		*entry = entries[i];
		if ( *entry == NULL )
			continue;
		
		box = Cache_ReadBox(*entry, &gRDinfo);
		if ( box == NULL )
			continue;
		
		// Do not return a NEW uca-created account that has never logged in.
		if(!box->userAccount.dateLastConnect)
			continue;

		// Don't return an account from another platform.
		if (platformID && box->boxAccount.platformID != platformID)
			continue;

		// Do not consider closed accounts if non-closed account(s) is 
		// available at this number.
		if(box->userAccount.accountStatus == CAT_ACCT_STATUS_CLOSED &&
		   accountStatus != CAT_ACCT_STATUS_CLOSED)
			continue;

		// Ensure that a non-closed account overrides any closed account.
		if(box->userAccount.accountStatus != CAT_ACCT_STATUS_CLOSED &&
		   accountStatus == CAT_ACCT_STATUS_CLOSED)
		{
			boxReturn	    = box;
			dateLastConnect	= box->userAccount.dateLastConnect;
			accountStatus	= box->userAccount.accountStatus;

			if (box->boxAccount.csUpdatedFlags & kCSUpdatedFlag_BindLostModem)
				boundLostModem = 1;
			else
				foundOne = 1;
			continue;
		}

		if (box->boxAccount.csUpdatedFlags & kCSUpdatedFlag_BindLostModem)
		{
			/* 
			 * If we haven't bound ANY lost modems yet, OR, if the current 
			 * box is Most Recently Used.
			 */
			if ((boundLostModem++ == 0) ||
				(box->userAccount.dateLastConnect >= dateLastConnect))
			{
				boxReturn	    = box;
				dateLastConnect	= box->userAccount.dateLastConnect;
				accountStatus	= box->userAccount.accountStatus;
			}
		}
		/* If we haven't bound a lost modem yet... then select the MRU */
		else if (boundLostModem == 0)
		{
			/* 
			 * If we haven't set boxReturn yet, OR, if the current box is 
			 * Most Recently Used.
			 */
			if ((foundOne == false) ||
				(box->userAccount.dateLastConnect >= dateLastConnect))
			{
				boxReturn	    = box;
				dateLastConnect	= box->userAccount.dateLastConnect;
				accountStatus	= box->userAccount.accountStatus;
				foundOne	    = 1;
			}
		}
	}

	if (boxReturn == NULL) {
		// This can probably only happen if it found several boxes but they
		// were all for accounts on different platforms.
		//
		return (NULL);
	}

	if (nEntries > 1)
		Logmsg(
			"Database_FindBoxByPhone: "
			"found %ld accounts at (%s), "
			"returning most recently used (%ld,%ld) (date=0x%.8lx)\n",
			nEntries, boxPhoneNumber->phoneNumber,
			boxReturn->boxAccount.box.box, boxReturn->boxAccount.box.region,
			dateLastConnect);
		
	if (boundLostModem > 1)
		Logmsg(
			"Database_FindBoxByPhone: "
			"found %ld accounts at '%s' with kCSUpdatedFlag_BindLostModem, "
			"returning most recently used (%ld,%ld) (date=0x%.8lx)\n", 
			boundLostModem, boxPhoneNumber->phoneNumber,
			boxReturn->boxAccount.box.box, boxReturn->boxAccount.box.region,
			dateLastConnect);
	
	return boxReturn;
}


/*============================================================================*\

	Database_FindOpenBoxByPhone

	Just like Database_FindBoxByPhone, but won't return a closed account.

\*============================================================================*/
SDBBox *Database_FindOpenBoxByPhone(
	SDB					*sdb,
	const phoneNumber	*boxPhoneNumber,
	long				platformID,
	SDBBoxCachePtr		*entry)
{
	SDBBox			*boxReturn;

	// Implement this with a call to FindBoxByPhone.  This works because
	// FindBoxByPhone gives priority to open accounts over closed ones, so
	// it will only return a closed account if no open ones are available.
	//
	// So, all we have to do is avoid returning a closed one.
	//
	boxReturn = Database_FindBoxByPhone(
		sdb, boxPhoneNumber, platformID, entry);
	if (boxReturn != NULL &&
		boxReturn->userAccount.accountStatus != CAT_ACCT_STATUS_CLOSED)
	{
		return (boxReturn);
	}

	return (NULL);
}


/*============================================================================*\
	Database_FindReplacementBoxByPhone

	This will never return a CLOSED account.  This routine is used when
	a brand new box logs in and needs to be attached to an existing
	account (ie. the customer replaced their modem).  UCA would set
	the kCSUpdatedFlag_ReplacementModem bit in CSUpdateFlags.

	But, in late January 1995, I decided to change the way Server_RestoreBox.c
	works so that UCA does *not* have to set the replacementModem bit,
	because lots of customers were replacing modems.  So now, when a new
	box comes in, if there is no new account waiting for it, 
	we call DataBase_FindAccountBGamePhoneAndPlayerNumber
	which calls Database_FindBoxByPhone, and will bind the new modem to
	the most recenty used account.  Sigh.  Then we can get problems with
	new modems hooking up to friends accounts.  Asaaaargh!  Give us
	H/W id on the modems, please!    2/10/95 DJ

	This routine will *not* return a NEW account that has never logged in 
	before.  4.10.95  DJ

	Passing in platformID==0 will match any platformID.

\*============================================================================*/
SDBBox *
Database_FindReplacementBoxByPhone(
	SDB					*sdb,
	const phoneNumber	*boxPhoneNumber,
	long				platformID,
	SDBBoxCachePtr		*entry)
{
	SDBBoxList			boxList;
	PhoneSTreeNode		*phoneNode;
	
	unsigned long		i, nEntries;
	unsigned long		dateLastConnect;
	Boolean				foundOne;
	SDBBoxCachePtr      *entries;
	SDBBoxPtr           box, boxReturn;

	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL) return NULL;

	Assert(boxList->byPhone);

	phoneNode = STree_FindDataByKey(boxList->byPhone, (void *) boxPhoneNumber);
	
	if (phoneNode == NULL)
		return NULL;

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;

	if (phoneNode->oType == kSingleBox) {
		*entry = phoneNode->data.entry;
		if ( *entry == NULL )
            return (NULL);

        box = Cache_ReadBox(*entry, &gRDinfo);
        if ( box == NULL )
            return (NULL);

        // Do not return a NEW uca-created account that has never logged in.
		if(!box->userAccount.dateLastConnect)
			return (NULL);

		if (box->userAccount.accountStatus == CAT_ACCT_STATUS_CLOSED)
			return (NULL);	// don't return a closed account

		if (!(box->boxAccount.csUpdatedFlags & kCSUpdatedFlag_ReplacementModem))
			return (NULL);	// don't return acct unless "replace" bit is set

		if (platformID && box->boxAccount.platformID != platformID)
			return (NULL);	// don't return account from another platform

		entries	 = &(phoneNode->data.entry);
		nEntries = 1;
	}
	else {
		Assert(phoneNode->oType == kManyBoxes);
		Assert(phoneNode->data.many.nEntries > 1);
		
		entries	 = phoneNode->data.many.entries;
		nEntries = phoneNode->data.many.nEntries;
	}

	foundOne		= 0;
	dateLastConnect	= 0;
	boxReturn		= NULL;

	for (i = 0; i < nEntries; i++) {
		*entry = entries[i];
		if ( *entry == NULL )
            continue;

        box = Cache_ReadBox(*entry, &gRDinfo);
        if ( box == NULL )
            continue;

		// Do not return a NEW uca-created account that has never logged in.
		if(!box->userAccount.dateLastConnect)
			continue;

		// Don't return an account from another platform.
		if (platformID && box->boxAccount.platformID != platformID)
			continue;

		// Don't return closed accounts.
		if(box->userAccount.accountStatus == CAT_ACCT_STATUS_CLOSED)
			continue;

		// Only want accounts with the "replacement modem" bit set.
		if (box->boxAccount.csUpdatedFlags & kCSUpdatedFlag_ReplacementModem)
		{
			if ((foundOne == false) ||
				(box->userAccount.dateLastConnect >= dateLastConnect))
			{
				boxReturn		= box;
				dateLastConnect	= box->userAccount.dateLastConnect;
				foundOne		= true;
			}
		}
	}

	if (boxReturn != NULL && nEntries > 1)
		Logmsg(
			"Database_FindReplacementBoxByPhone: "
			"found %ld accounts at (%s), "
			"returning most recently used (%ld,%ld) (date=0x%.8lx)\n",
			nEntries, boxPhoneNumber->phoneNumber,
			boxReturn->boxAccount.box.box, boxReturn->boxAccount.box.region,
			dateLastConnect);

	return boxReturn;
}

/*============================================================================*\

	Searches for a new account (dataLastCreated == 0) with the
	specified boxPhoneNumber.  This is used in
	DB_CreateBoxAndPlayerAccount to allow a new box to log in
	after UCA has created a new account for the box.

	This one is a little strange, since currently UCA doesn't initialize
	the platformID field in the account... so there's no way we can match
	it unless the caller passes in 0.  So, accept a 0 in EITHER platformID
	field to act as a wildcard.

\*============================================================================*/
SDBBox *
Database_FindNewBoxByPhone(
	SDB 				*sdb, 
	const phoneNumber 	*boxPhoneNumber, 
	long 				platformID,
	SDBBoxCachePtr		*entry)
{
	SDBBoxList 		boxList;
	PhoneSTreeNode	*phoneNode;
	unsigned long 	i, nEntries;
    SDBBoxCachePtr	*entries;
    SDBBoxPtr		box, boxReturn;

	boxList = Database_GetBoxList(sdb);
	Assert(boxList);
	if (boxList == NULL) return NULL;

	Assert(boxList->byPhone);

	phoneNode = STree_FindDataByKey(boxList->byPhone, (void *) boxPhoneNumber);

	if (phoneNode == NULL)
		return NULL;

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;

	if (phoneNode->oType == kSingleBox) {
		*entry = phoneNode->data.entry;
		if ( *entry == NULL )
			return(NULL);

        box = Cache_ReadBox(*entry, &gRDinfo);
        Assert(box);
        if ( box == NULL )
            return (NULL);

		if (box->userAccount.dateLastConnect)
			return NULL;

		if (platformID && box->boxAccount.platformID &&
			platformID != box->boxAccount.platformID)
		{
			return (NULL);
		}

		return (box);
	}

	Assert(phoneNode->oType == kManyBoxes);
	Assert(phoneNode->data.many.nEntries > 1);

	entries  = phoneNode->data.many.entries;
	nEntries = phoneNode->data.many.nEntries;
	boxReturn = NULL;

	for (i = 0; i < nEntries; i++) {
		*entry = entries[i];
		if ( *entry == NULL )
			return(NULL);

        box = Cache_ReadBox(*entry, &gRDinfo);
        Assert(box);
        if ( box == NULL )
            continue;

		if (platformID && box->boxAccount.platformID &&
			platformID != box->boxAccount.platformID)
		{
			continue;
		}
		if (!box->userAccount.dateLastConnect) {
			boxReturn = box;
			break;
		}
	}

	if (boxReturn != NULL && nEntries > 1)
		Logmsg(
			"Database_FindNewBoxByPhone: "
			"found %ld accounts at (%s), "
			"returning first found (%ld,%ld)\n",
			nEntries, boxPhoneNumber->phoneNumber,
			boxReturn->boxAccount.box.box, boxReturn->boxAccount.box.region);

	return boxReturn;
}


/*============================================================================*\
	Database_BeginUpdatePhone

	Begins the phone number update procedure, concluded by EndUpdatePhone.
	The caller calls this, then changes all the phone number values in the
	account, then calls EndUpdatePhone.

	The purpose of this is to remove the existing phone node from the phone
	tree.  The entry will exist, having been created by PhoneSTreeNode_New
	via Database_CreateBoxAndPlayerAccount.

	Returning NULL doesn't make any sense, but it doesn't matter, since the
	callers of this routine don't check the return value.
\*============================================================================*/
Err	Database_BeginUpdatePhone(
	SDB			   *sdb,
	SDBBoxCachePtr entry)
{
	SDBBoxList	boxList;
	
	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL) return NULL;
	Assert(boxList->byPhone);	// was byName  ++ATM 950626

	return PhoneSTree_RemoveBox(boxList->byPhone, entry);
}

/*============================================================================*\
	Database_EndUpdatePhone

	Same story as BeginUpdatePhone: NULL results don't matter.

	The purpose of this is to add the box to the appropriate position in
	the phone tree.
\*============================================================================*/
Err Database_EndUpdatePhone(
	SDB			    *sdb,
	SDBBoxCachePtr	entry)
{
	SDBBoxList	boxList;
	
	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL) return NULL;
	Assert(boxList->byPhone);	// was byName  ++ATM 950626

	return PhoneSTree_AddBox(boxList->byPhone, entry);
}

/*============================================================================*\
	Database_FindUserByName
\*============================================================================*/
SDBUser *
Database_FindUserByName(
	SDB				*sdb,
	const u_char	*userName,
	SDBBoxCachePtr	*entry)
{
	SDBBoxList		boxList;
	SDBBoxPtr		box;
	NameSTreeNode	*node;
	
	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL) return NULL;
	Assert(boxList->byName);

	node = STree_FindDataByKey(boxList->byName, (void *) userName);
	if ( node ) {
		*entry = node->entry;
		if ( *entry == NULL )
			return(NULL);
	}
	else
		return(NULL);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(*entry, &gRDinfo);

	Assert(box);
	if ( box == NULL )
		return (NULL);
	else
		return(box->users[node->player]);
}

/*============================================================================*\
	Database_BeginUpdateName
\*============================================================================*/
Err	
Database_BeginUpdateName(
	SDB				*sdb,
	SDBBoxCachePtr	entry,
	unsigned char	player)
{
	SDBBoxList	boxList;
	
	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL) 
		return(NULL);

	Assert(boxList->byName);

	return(NameSTree_RemoveUser(boxList->byName, entry, player));
}

/*============================================================================*\
	Database_EndUpdateName
\*============================================================================*/
Err 
Database_EndUpdateName(
	SDB				*sdb,
	SDBBoxCachePtr	entry,
	unsigned char	player)
{
	SDBBoxList	boxList;
	
	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL) 
		return(NULL);

	Assert(boxList->byName);

	return(NameSTree_AddUser(boxList->byName, entry, player));
}

/*============================================================================*\
	Database_BeginUpdateCSID
\*============================================================================*/
Err	
Database_BeginUpdateCSID(
	SDB				*sdb,
	SDBBoxCachePtr	entry)
{
	SDBBoxList	boxList;
	
	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL) 
		return(NULL);

	Assert(boxList->byCSID);

	return(CSIDSTree_RemoveBox(boxList->byCSID, entry));
}

/*============================================================================*\
	Database_EndUpdateCSID
\*============================================================================*/
Err 
Database_EndUpdateCSID(
	SDB				*sdb,
	SDBBoxCachePtr	entry)
{
	SDBBoxList	boxList;
	
	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL) 
		return(NULL);

	Assert(boxList->byCSID);

	return(CSIDSTree_AddBox(boxList->byCSID, entry));
}

/*****************************************************************************
 *	Static routines
 *****************************************************************************/

/*============================================================================*\
	Database_GetBoxList
\*============================================================================*/
static SDBBoxList 
Database_GetBoxList(
	SDB	*sdb)
{
	SDBUsers	*sdbUsers;
	
	sdbUsers = SDB_GetUsers(sdb);
	ASSERT_MESG(sdbUsers != NULL, "Database_GetBoxList: impl err NULL sdbUsers"); 
	if (sdbUsers == NULL) 
		return NULL;
	ASSERT_MESG(sdbUsers->list != NULL, "Database_GetBoxList: impl err NULL sdbUsers->list"); 
	if (sdbUsers->list == NULL)
		return NULL;

	return sdbUsers->list;
}

/*============================================================================*\
	RegionMFA_ForEach
\*============================================================================*/
static Err RegionMFA_ForEach(
	MFA					regionMFA,
	DBForEachBoxParam	*param)
{
	return (Err) MFA_ForEach(regionMFA, (MFAForEachProc) param->action, param->refCon);
}

/*============================================================================*\
	RegionMFA_AddBox
\*============================================================================*/
static Err RegionMFA_AddBox(
	MFA			    byRegion,
	SDBBoxCachePtr	entry)
{
    BoxSerialNumber *bsn;
	Boolean			exists;
	MFA				byBoxID;

	Assert(byRegion);
	Assert(entry);
	
	// Search by region
	bsn = Cache_GetBsn(entry);
	Assert(bsn);
	if ( bsn == NULL )
		return(kFucked);

	byBoxID = (MFA) MFA_FindKey(byRegion, bsn->region);
	
	if (byBoxID == NULL) {
		byBoxID = MFA_New(NULL);
		ASSERT_MESG(byBoxID, "Couldn't alloc a MFA?");
		if (byBoxID == NULL)
			return kNoSuchUserAccount;
		MFA_InsertKey(byRegion, bsn->region, (void*) byBoxID, &exists);
		ASSERT_MESG(exists == false, "IMPL ERR: ID exists in region already?");
	}

	// Insert into the region MFA
	MFA_InsertKey(byBoxID, bsn->box, entry, &exists);
	Assert(exists == false);
	if (exists != false)
		return kNoSuchUserAccount;
	
	return kNoError;
}

/*============================================================================*\
	RegionMFA_RemoveBox
\*============================================================================*/
static Err RegionMFA_RemoveBox(
	MFA			   byRegion,
	SDBBoxCachePtr entry)
{
    BoxSerialNumber *bsn;
	MFA		        byBoxID;
	SDBBox	        *foundBox;
	
	bsn = Cache_GetBsn(entry);
	Assert(bsn);
	if ( bsn == NULL )
		return(kFucked);

	byBoxID = MFA_FindKey(byRegion, bsn->region);
	
	if (byBoxID == NULL)
		return kNoSuchBoxAccount;
	
	foundBox = (SDBBox *) MFA_RemoveKey(byBoxID, bsn->box);
	
	ASSERT_MESG(foundBox == NULL, "RegionMFA_RemoveBox: can't find box");

	if (foundBox == NULL)
		return kNoSuchBoxAccount;
		
	return kNoError;
}

/*============================================================================*\
	NameSTreeNode_New
\*============================================================================*/
static NameSTreeNode *
NameSTreeNode_New(
	SDBBoxCachePtr	entry,
	unsigned char	player)
{
	NameSTreeNode	*node;
    SDBBoxPtr       box;
	
	Assert(entry);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	Assert(box);
	if ( box == NULL )
		return (NULL);

	if ( box->users[player] != NULL ) {
		node = (NameSTreeNode *) malloc(sizeof(NameSTreeNode));
		
		node->userName = strdup(box->users[player]->playerAccount.userName);
		node->player   = box->users[player]->playerAccount.player;
		node->entry    = entry;
	
		return(node);
	}
	else
		return(NULL);
}

/*============================================================================*\
	NameSTreeNode_Delete
\*============================================================================*/
static void 
NameSTreeNode_Delete(
	NameSTreeNode	*node)
{
	Assert(node);

	free(node->userName);
	free(node);
}

/*============================================================================*\
	NameSTree_AddBox
\*============================================================================*/
static Err 
NameSTree_AddBox(
	STree			byName,
	SDBBoxCachePtr	entry)
{
	NameSTreeNode	*node;
	Boolean			exists;
	STreeNode		treeNode;
	char			i;
	
	Assert(byName);
	Assert(entry);
	
	for (i = 0; i < 4; i++) {
		node = NameSTreeNode_New(entry, i);
		if ( node == NULL )
			continue;

		treeNode = STree_InsertNode(byName, (void *) node, &exists);
		ASSERT_MESG(exists == false, "NameSTree_AddBox, Found dup name.");
		Assert(treeNode != NULL);
	}
	
	return kNoError;
}

#ifdef UNUSED
/*============================================================================*\
	NameSTree_RemoveBox
\*============================================================================*/
static Err 
NameSTree_RemoveBox(
	STree			byName,
	SDBBoxCachePtr	entry)
{
	SDBBoxPtr		box;
	SDBUser			*user;
	STreeNode		treeNode;
	NameSTreeNode	*node;
	char			i;
	
	Assert(byName);
	Assert(entry);
	
    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	Assert(box);
	if ( box == NULL )
		return (kFucked);

	for (i = 0; i < 4; i++) {
		user = box->users[i];
		if (user == NULL)
			continue;

		treeNode = STree_FindNodeByKey(byName, 
			(void *) user->playerAccount.userName);
		if (treeNode == NULL)
			continue;

		node = (NameSTreeNode *) STree_RemoveNode(byName, treeNode);
		if ( node )
			NameSTreeNode_Delete(node);
	}

	return(kNoError);
}
#endif UNUSED

/*============================================================================*\
	NameSTree_AddUser
\*============================================================================*/
static Err 
NameSTree_AddUser(
	STree			byName,
	SDBBoxCachePtr	entry,
	unsigned char	player)
{
	NameSTreeNode	*node;
	Boolean			exists;
	STreeNode		treeNode;
	
	Assert(byName);
	Assert(entry);
	
	node = NameSTreeNode_New(entry, player);
	if ( node == NULL )
		return kNoSuchUserAccount;

	treeNode = STree_InsertNode(byName, (void *) node, &exists);
	ASSERT_MESG(exists == false, "NameSTree_AddUser, Found dup name.");
	Assert(treeNode != NULL);

	return kNoError;
}

/*============================================================================*\
	NameSTree_RemoveUser
\*============================================================================*/
static Err 
NameSTree_RemoveUser(
	STree			byName,
	SDBBoxCachePtr	entry,
	unsigned char	player)
{
	SDBBoxPtr		box;
	SDBUser			*user;
	STreeNode		treeNode;
	NameSTreeNode	*node;
	
	Assert(byName);
	Assert(entry);
	
    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	Assert(box);
	if ( box == NULL )
		return (kFucked);

	user = box->users[player];

	Assert(user);
	if ( user == NULL )
		return kNoSuchUserAccount;
	
	treeNode = STree_FindNodeByKey(byName, 
		(void *) user->playerAccount.userName);

	if (treeNode == NULL)
		return kNoSuchUserAccount;
		
	node = (NameSTreeNode *) STree_RemoveNode(byName, treeNode);
	if ( node )
		NameSTreeNode_Delete(node);

	return(kNoError);
}

/*============================================================================*\
	NameSTree_CompareNodeToNode

	byName tree node data compare to byName tree node data
\*============================================================================*/
static long 
NameSTree_CompareNodeToNode(
    NameSTreeNode   *node1,
	NameSTreeNode   *node2)
{
	Assert(node1);
	Assert(node2);

	return(DataBaseUtil_CompareStrings(node1->userName, node2->userName));
}

/*============================================================================*\
	NameSTree_CompareNameToNode
	
	Key compare to byName tree node data
\*============================================================================*/
static long NameSTree_CompareNameToNode(
	char			*name,
	NameSTreeNode   *node)
{
	Assert(name);
	Assert(node);

	return(DataBaseUtil_CompareStrings(name, node->userName));
}

/*============================================================================*\
	PhoneSTree_InsertBox

	Tries to look up the phone node in the tree.  If it can't find it, it
	creates a new one with PhoneSTreeNode_New and STree_InsertNode.

	If it can find it, it adds the box to that phone node (you can have
	more than one box in the database at the same phone number... a very
	common occurrence at Catapult).
\*============================================================================*/
static Err PhoneSTree_AddBox(
	STree			byPhone,
	SDBBoxCachePtr	entry)
{
	PhoneSTreeNode	*phoneNode;
	Boolean			exists;
	STreeNode		checkMemFail;
	SDBBoxPtr       box;
	
	Assert(byPhone);
	Assert(entry);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	Assert(box);
	if ( box == NULL )
		return (kFucked);

	phoneNode = STree_FindDataByKey(
		byPhone, (void *) &(box->boxAccount.gamePhone));

	if (phoneNode == NULL) {
		phoneNode = PhoneSTreeNode_New(entry);
	
		checkMemFail = STree_InsertNode(byPhone, (void *) phoneNode, &exists);
		
		ASSERT_MESG(exists == false, "Phone node exists but wasn't found?");
		ASSERT_MESG(checkMemFail != NULL, "Couldn't insert into tree?");
	
		return kNoError;
	} 
	else 
		return PhoneSTreeNode_AddBox(phoneNode, entry);
}

/*============================================================================*\
	PhoneSTree_RemoveBox
\*============================================================================*/
static Err PhoneSTree_RemoveBox(
	STree			byPhone,
	SDBBoxCachePtr	entry)
{
	STreeNode		treeNode;
	PhoneSTreeNode	*node;
	Err				err;
	Boolean			isEmpty;
	SDBBoxPtr       box;
	
	Assert(byPhone);
	Assert(entry);
	
    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	Assert(box);
	if ( box == NULL )
		return (kFucked);

	treeNode = STree_FindNodeByKey(
		byPhone, (void *) &(box->boxAccount.gamePhone));
	
	if (treeNode == NULL)
		return kNoSuchBoxAccount;

	node = STreeNode_GetData(treeNode);
	
	Assert(node);
	
	err = PhoneSTreeNode_RemoveBox(node, entry, &isEmpty);
	
	if (err != kNoError)
		return err;

	if (isEmpty == true) {
		node = (PhoneSTreeNode *) STree_RemoveNode(byPhone, treeNode);
		if ( node )
			PhoneSTreeNode_Delete(node);
	}
	
	return kNoError;
}

/*============================================================================*\
	PhoneSTree_CompareNodeToNode

	Key compare to byPhone tree node data

	This gets called from things like STree_Find via a function pointer.
\*============================================================================*/
static long PhoneSTree_ComparePhoneToNode(
	phoneNumber			*phone,
	PhoneSTreeNode		*node)
{
	Assert(phone);
	Assert(node);
	Assert((node->oType == kSingleBox) || (node->oType == kManyBoxes));

	if ((node->oType != kSingleBox) && (node->oType != kManyBoxes)) {
		PLogmsg(LOGP_FLAW, "GLITCH: node->oType=%d\n", node->oType);
	}
	
	return
		Common_PhoneCompareNumbers(
			phone->phoneNumber,
			node->phoneNumber->phoneNumber);
}

/*============================================================================*\
	PhoneSTree_CompareNodeToNode

	byPhone tree node data compare to byPhone tree node data
\*============================================================================*/
static long PhoneSTree_CompareNodeToNode(
	PhoneSTreeNode		*node1,
	PhoneSTreeNode		*node2)

{
	Assert(node1);
	Assert((node1->oType == kSingleBox) || (node1->oType == kManyBoxes));
	Assert(node1->phoneNumber != NULL);

	Assert(node2);
	Assert((node2->oType == kSingleBox) || (node2->oType == kManyBoxes));
	Assert(node2->phoneNumber != NULL);
	
	return
		Common_PhoneCompareNumbers(
			node1->phoneNumber->phoneNumber,
			node2->phoneNumber->phoneNumber);
}

/*============================================================================*\
	PhoneSTreeNode_New
\*============================================================================*/
static PhoneSTreeNode *
PhoneSTreeNode_New(
	SDBBoxCachePtr	entry)
{
	PhoneSTreeNode	*node;
	phoneNumber     *pnum;
	SDBBoxPtr       box;
	
	Assert(entry);
	
    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	Assert(box);
	if ( box == NULL )
		return (NULL);

	node = (PhoneSTreeNode *) malloc(sizeof(PhoneSTreeNode));
	pnum = (phoneNumber *) malloc(sizeof(phoneNumber));
	
	/* 
	 * Structure copy box->boxAccount.gamePhone into pnum.
	 */
	*pnum = box->boxAccount.gamePhone;
	
	/*
	 * Since we now have a copy of the gamePhone struct in the phone tree,
	 * there is no longer any danger if box->boxAccount.gamePhone.phoneNumber
	 * changes, as long as we update the tree to reflect the changes.
	 */

	node->phoneNumber = pnum;
	node->oType		= kSingleBox;
	node->data.entry	= entry;
	
	return(node);
}

/*============================================================================*\
	PhoneSTreeNode_Delete
\*============================================================================*/
static void PhoneSTreeNode_Delete(
	PhoneSTreeNode	*node)
{
	Assert(node);
	
	if (node->oType == kManyBoxes) {
		free(node->data.many.entries);
		node->data.many.entries = NULL;
		node->data.many.nEntries = 0;
	} 
	else 
		Assert( (node->oType == kSingleBox) || (node->oType == kEmptyBox));

	if ( node->phoneNumber )
		free(node->phoneNumber);
	
	free(node);
}

/*============================================================================*\
	PhoneSTreeNode_AddBox
	
	The only failure this can have is an out-of-memory error. (Rare.)
\*============================================================================*/
static Err PhoneSTreeNode_AddBox(
	PhoneSTreeNode	*node,
	SDBBoxCachePtr	entry)
{
	SDBBoxCachePtr	*entries;
	unsigned long	nEntries;
	
	Assert(node);
	Assert(entry);
	
	if (node->oType == kSingleBox) {
	
		if (node->data.entry == entry)
			return kNoError;
			
		entries = (SDBBoxCachePtr *) malloc(2 * sizeof(SDBBoxCachePtr));
		
		if (entries == NULL)
			return kOutOfMemoryErr;
			
		entries[0]	= node->data.entry;
		entries[1]	= entry;
		nEntries	= 2;
	} else {
		unsigned long i;
		
		nEntries = i = node->data.many.nEntries;
		while (i--)
			if (node->data.many.entries[i] == entry)
				return kNoError;

		Assert(node->oType == kManyBoxes);
		if (!node->data.many.entries)
			entries =  (SDBBoxCachePtr *)
				malloc((nEntries + 1) * sizeof(SDBBoxCachePtr));
		else
			entries = (SDBBoxCachePtr *) realloc(node->data.many.entries, 
				(nEntries + 1) * sizeof(SDBBoxCachePtr));

		if (entries == NULL)
			return kOutOfMemoryErr;

		entries[nEntries] = entry;
		nEntries++;
	}

	node->oType				 = kManyBoxes;
	node->data.many.entries	 = entries;
	node->data.many.nEntries = nEntries;
	
	return kNoError;
}

/*============================================================================*\
	PhoneSTreeNode_RemoveBox
	
	The only failure this can have is the box doesn't appear in the phone node.
\*============================================================================*/
static Err PhoneSTreeNode_RemoveBox(
	PhoneSTreeNode	*node,
	SDBBoxCachePtr	entry,
	Boolean			*isEmpty)
{
	SDBBoxCachePtr	*entries;
	
	Assert(node);
	Assert(entry);
	Assert(isEmpty);
	
	if (node->oType == kSingleBox) {

		if (node->data.entry != entry)
			return kNoSuchBoxAccount;

		node->data.entry = NULL;
		node->oType 	 = 0;
		*isEmpty 		 = true;

		return kNoError;
	} else {
		unsigned long	i, j;

		Assert(node->oType == kManyBoxes);
		Assert(node->data.many.nEntries > 1);
		
		for (i = 0; i < node->data.many.nEntries; i++) {
			if (node->data.many.entries[i] == entry) {
				if (node->data.many.nEntries == 2) {
					SDBBoxCachePtr	leftover;
					
					Assert((i == 0) || (i == 1));
					
					leftover = node->data.many.entries[1-i];
					free(node->data.many.entries);
					
					node->oType 	 = kSingleBox;
					node->data.entry = leftover;
					*isEmpty 		 = false;
					
					return kNoError;
				} else {
					Assert(node->data.many.nEntries > 2);
					
					for (j = i; j < node->data.many.nEntries - 1; j++)
						node->data.many.entries[j] = 
							node->data.many.entries[j+1];
					
					entries = realloc(node->data.many.entries, 
						(node->data.many.nEntries - 1) * sizeof(SDBBoxCachePtr));

					ASSERT_MESG(entries != NULL, 
						"Realloc to a smaller size failed? Weird!");

					if (entries == NULL) 
						/* Recovery: realloc is non-destructive */
						entries = node->data.many.entries;	
					
					node->data.many.entries	 = entries;
					node->data.many.nEntries -= 1;

					return kNoError;
				}
			}
		}
		return kNoSuchBoxAccount;
	}
}

/*============================================================================*\
	HWIDSTree_AddBox

	Tries to look up the hardwareID node in the tree.  If it can't find it, it
	creates a new one with HWIDSTreeNode_New and STree_InsertNode.

	If it can find it, it adds the box to that hardwareID node (you can have
	more than one box in the database with the same hardwareID... hopefully
	an uncommon occurrence unless we're closing accounts all the time).
\*============================================================================*/
static Err 
HWIDSTree_AddBox(
	STree			byHWID,
	SDBBoxCachePtr	entry)
{
	HWIDSTreeNode	*node;
	STreeNode		treeNode;
	Boolean			exists;
    SDBBoxPtr       box;

	Assert(byHWID);
	Assert(entry);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	Assert(box);
	if ( box == NULL )
		return (kFucked);

	node = (HWIDSTreeNode *) STree_FindDataByKey(
		byHWID, (void *) &(box->boxAccount.hardwareID));

	if (node == NULL) {
		node = HWIDSTreeNode_New(entry);
	
		treeNode = STree_InsertNode(byHWID, (void *) node, &exists);
		
		ASSERT_MESG(exists == false, "HWID node exists but wasn't found?");
		ASSERT_MESG(treeNode != NULL, "Couldn't insert into tree?");
	
		return kNoError;
	} 
	else {
		return HWIDSTreeNode_AddBox(node, entry);
	}
}

/*============================================================================*\
	HWIDSTree_RemoveBox
\*============================================================================*/
static Err 
HWIDSTree_RemoveBox(
	STree			byHWID,
	SDBBoxCachePtr	entry)
{
	STreeNode		treeNode;
	HWIDSTreeNode	*node;
	Err				err;
	Boolean			isEmpty;
    SDBBoxPtr       box;
	
	Assert(byHWID);
	Assert(entry);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	Assert(box);
	if ( box == NULL )
		return (kFucked);

	treeNode = STree_FindNodeByKey(
		byHWID, (void *) &(box->boxAccount.hardwareID));
	
	if (treeNode == NULL)
		return kNoSuchBoxAccount;

	node = STreeNode_GetData(treeNode);
	
	Assert(node);
	
	err = HWIDSTreeNode_RemoveBox(node, entry, &isEmpty);
	
	if (err != kNoError)
		return err;

	if (isEmpty == true) {
		node = (HWIDSTreeNode *) STree_RemoveNode(byHWID, treeNode);
		if ( node )
			HWIDSTreeNode_Delete(node);
	}
	
	return kNoError;
}

/*============================================================================*\
	HWIDSTree_CompareNodeToNode

	Key compare to byHWID tree node data

	This gets called from things like STree_Find via a function pointer.
\*============================================================================*/
static long HWIDSTree_CompareHWIDToNode(
	HardwareID			*hwid,
	HWIDSTreeNode		*node)
{
	Assert(hwid);
	Assert(node);
	Assert((node->oType == kHWIDSingleBox) || (node->oType == kHWIDManyBoxes));

	if ((node->oType != kHWIDSingleBox) && (node->oType != kHWIDManyBoxes)) {
		PLogmsg(LOGP_FLAW, "GLITCH: boxHWID->oType=%d\n", node->oType);
	}

	//Logmsg("Compare ");
	//Common_LogHardwareID(hwid);
	//Logmsg("     to ");
	//Common_LogHardwareID(boxHWID->hardwareID);
	
	return
		(Common_CompareHardwareID(hwid, node->hardwareID));
}

/*============================================================================*\
	HWIDSTree_CompareNodeToNode

	byHWID tree node data compare to byHWID tree node data
\*============================================================================*/
static long HWIDSTree_CompareNodeToNode(
	HWIDSTreeNode		*node1,
	HWIDSTreeNode		*node2)

{
	Assert(node1);
	Assert((node1->oType == kHWIDSingleBox) || (node1->oType == kHWIDManyBoxes));
	Assert(node1->hardwareID != NULL);

	Assert(node2);
	Assert((node2->oType == kHWIDSingleBox) || (node2->oType == kHWIDManyBoxes));
	Assert(node2->hardwareID != NULL);
	
	return
		(Common_CompareHardwareID(node1->hardwareID, node2->hardwareID));
}

/*============================================================================*\
	HWIDSTreeNode_New
\*============================================================================*/
static HWIDSTreeNode *
HWIDSTreeNode_New(
	SDBBoxCachePtr	entry)
{
    HardwareID      *hwid;
	HWIDSTreeNode	*node;
    SDBBoxPtr       box;
	
	Assert(entry);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	Assert(box);
	if ( box == NULL )
		return (NULL);

	node = (HWIDSTreeNode *) malloc(sizeof(HWIDSTreeNode));
	hwid = (HardwareID *) malloc(sizeof(HardwareID));
	
	/* structure copy box->boxAccount.hardwareID into hwid */
	*hwid = box->boxAccount.hardwareID;
	
	node->hardwareID  = hwid;
	node->oType		= kHWIDSingleBox;
	node->data.entry	= entry;
	
	return(node);
}

/*============================================================================*\
	HWIDSTreeNode_Delete
\*============================================================================*/
static void HWIDSTreeNode_Delete(
	HWIDSTreeNode	*node)
{
	Assert(node);
	
	if (node->oType == kHWIDManyBoxes) {
		free(node->data.many.entries);
		node->data.many.entries  = NULL;
		node->data.many.nEntries = 0;
	} else {
		Assert(
            (node->oType == kHWIDSingleBox) || 
            (node->oType == kHWIDEmptyBox));
	}

    if ( node->hardwareID )
        free(node->hardwareID);
	
	free(node);
}

/*============================================================================*\
	HWIDSTreeNode_AddBox
	
	The only failure this can have is an out-of-memory error. (Rare.)
\*============================================================================*/
static Err HWIDSTreeNode_AddBox(
	HWIDSTreeNode	*node,
	SDBBoxCachePtr	entry)
{
	SDBBoxCachePtr	*entries;
	unsigned long	nEntries;
	
	Assert(node);
	Assert(entry);
	
	if (node->oType == kHWIDSingleBox) {
	
		if (node->data.entry == entry)
			return kNoError;
			
		entries = (SDBBoxCachePtr *) malloc(2 * sizeof(SDBBoxCachePtr));
		
		if (entries == NULL)
			return kOutOfMemoryErr;
			
		entries[0]	= node->data.entry;
		entries[1]	= entry;
		nEntries	= 2;
	} else {
		unsigned long i;
		
		nEntries = i = node->data.many.nEntries;
		while (i--)
			if (node->data.many.entries[i] == entry)
				return kNoError;

		Assert(node->oType == kHWIDManyBoxes);
		if (!node->data.many.entries)
			entries = (SDBBoxCachePtr *)
				malloc((nEntries + 1) * sizeof(SDBBoxCachePtr));
		else
			entries = (SDBBoxCachePtr *) realloc(node->data.many.entries, 
				(nEntries + 1) * sizeof(SDBBoxCachePtr));

		if (entries == NULL)
			return kOutOfMemoryErr;

		entries[nEntries] = entry;
		nEntries++;
	}

	node->oType				 = kHWIDManyBoxes;
	node->data.many.entries	 = entries;
	node->data.many.nEntries = nEntries;
	
	return kNoError;
}

/*============================================================================*\
	HWIDSTreeNode_RemoveBox
	
	The only failure this can have is the box doesn't appear in the hwid node.
\*============================================================================*/
static Err HWIDSTreeNode_RemoveBox(
	HWIDSTreeNode	*node,
	SDBBoxCachePtr	entry,
	Boolean			*isEmpty)
{
    SDBBoxCachePtr  *entries;

	Assert(node);
	Assert(entry);
	Assert(isEmpty);
	
	if (node->oType == kHWIDSingleBox) {
		if (node->data.entry != entry)
			return kNoSuchBoxAccount;

		node->data.entry = NULL;
		node->oType 	 = 0;
		*isEmpty 		 = true;

		return kNoError;
	} else {
		unsigned long	i, j;

		Assert(node->oType == kHWIDManyBoxes);
		Assert(node->data.many.nEntries > 1);
		
		for (i = 0; i < node->data.many.nEntries; i++) {
			if (node->data.many.entries[i] == entry) {
				if (node->data.many.nEntries == 2) {
					SDBBoxCachePtr	leftover;
					
					Assert((i == 0) || (i == 1));
					
					leftover = node->data.many.entries[1-i];
					free(node->data.many.entries);
					
					node->oType 	 = kHWIDSingleBox;
					node->data.entry = leftover;
					*isEmpty 		 = false;
					
					return kNoError;
				} else {
					Assert(node->data.many.nEntries > 2);
					
					for (j = i; j < node->data.many.nEntries - 1; j++)
						node->data.many.entries[j] = 
							node->data.many.entries[j+1];
					
					entries = realloc(node->data.many.entries, 
						(node->data.many.nEntries - 1) * sizeof(SDBBoxCachePtr));

					ASSERT_MESG(entries != NULL, 
						"Realloc to a smaller size failed? Weird!");

					if (entries == NULL) 
						/* Recovery: realloc is non-destructive */
						entries = node->data.many.entries;	
					
					node->data.many.entries	  = entries;
					node->data.many.nEntries -= 1;

					return kNoError;
				}
			}
		}
		return kNoSuchBoxAccount;
	}
}

/*============================================================================*\
	CSIDSTreeNode_New
\*============================================================================*/
static CSIDSTreeNode *
CSIDSTreeNode_New(
	SDBBoxCachePtr	entry)
{
	CSIDSTreeNode	*node;
    SDBBoxPtr       box;
	
	Assert(entry);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	Assert(box);
	if ( box == NULL )
		return (NULL);

	node = (CSIDSTreeNode *) malloc(sizeof(CSIDSTreeNode));
	
	node->csid  = box->userAccount.customerServiceID;
	node->entry = entry;
	
	return(node);
}

/*============================================================================*\
	CSIDSTreeNode_Delete
\*============================================================================*/
static void 
CSIDSTreeNode_Delete(
	CSIDSTreeNode	*node)
{
	Assert(node);
	
	free(node);
}

/*============================================================================*\
	CSIDSTree_AddBox

	Tries to look up the CSID node in the tree.  If it can't find it, it
	creates a new one with CSIDSTreeNode_New and STree_InsertNode.

	If it can find it, it compains bitterly and exits.
\*============================================================================*/
static Err 
CSIDSTree_AddBox(
	STree			byCSID,
	SDBBoxCachePtr	entry)
{
    SDBBoxPtr       box;
	CSIDSTreeNode	*node;
	STreeNode		treeNode;
	Boolean			exists;

	Assert(byCSID);
	Assert(entry);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	Assert(box);
	if ( box == NULL )
		return (kFucked);

	/*
	 * Don't add zero valued CSID's to the tree.  This is an unassigned
	 * CSID and will result in tons of duplicates.
	 */
	if ( box->userAccount.customerServiceID == 0 )
		return(kNoError);

	node = (CSIDSTreeNode *) STree_FindDataByKey(
		byCSID, (void *) box->userAccount.customerServiceID);

	if (node == NULL) {
		node = CSIDSTreeNode_New(entry);
	
		treeNode = STree_InsertNode(byCSID, (void *) node, &exists);
		
		ASSERT_MESG(exists == false, "CSID node exists but wasn't found?");
		ASSERT_MESG(treeNode != NULL, "Couldn't insert into tree?");
	} else {
		BSNPtr bsn;

		bsn = Cache_GetBsn(entry);
		PLogmsg(LOGP_FLAW, "ERROR: Duplicate CSID (%ld) in box [%ld, %ld]\n",
			box->userAccount.customerServiceID, bsn->region, bsn->box);

		bsn = Cache_GetBsn(node->entry);
		PLogmsg(LOGP_FLAW, "CSID %ld already assigned to box [%ld, %ld]\n",
			box->userAccount.customerServiceID, bsn->region, bsn->box);
	}
	return(kNoError);
}

/*============================================================================*\
	CSIDSTree_RemoveBox
\*============================================================================*/
static Err 
CSIDSTree_RemoveBox(
	STree			byCSID,
	SDBBoxCachePtr	entry)
{
    SDBBoxPtr   	box;
	STreeNode		treeNode;
	CSIDSTreeNode	*node;
	
	Assert(byCSID);
	Assert(entry);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(entry, &gRDinfo);

	Assert(box);
	if ( box == NULL )
		return (kFucked);

	/* If the CSID is zero, it won't be in the tree */
	if ( box->userAccount.customerServiceID == 0 )
		return(kNoError);

	treeNode = STree_FindNodeByKey(byCSID, 
		(void *) box->userAccount.customerServiceID);

	if (treeNode == NULL)
		return kNoSuchBoxAccount;

	node = (CSIDSTreeNode *) STree_RemoveNode(byCSID, treeNode);
	if ( node )
		CSIDSTreeNode_Delete(node);

	return kNoError;
}

/*============================================================================*\
	CSIDSTree_CompareCSIDToNode

	Key compare to byCSID tree node data

	This gets called from things like STree_Find via a function pointer.
\*============================================================================*/
static long 
CSIDSTree_CompareCSIDToNode(
	unsigned long	csid,
	CSIDSTreeNode	*node)
{
	Assert(node);

    if ( csid < node->csid )
		return(-1);
	else if ( csid > node->csid )
		return(1);
	else
		return(0);
}

/*============================================================================*\
	CSIDSTree_CompareNodeToNode

	byCSID tree node data compare to byCSID tree node data
\*============================================================================*/
static long 
CSIDSTree_CompareNodeToNode(
	CSIDSTreeNode	*node1,
	CSIDSTreeNode	*node2)

{
	Assert(node1);
	Assert(node2);
	
    if ( node1->csid < node2->csid )
		return(-1);
	else if ( node1->csid > node2->csid )
		return(1);
	else
		return(0);
}

/*============================================================================*\
	Database_FindBoxByCSID
\*============================================================================*/
SDBBox *
Database_FindBoxByCSID(
	SDB				*sdb,
	unsigned long	csid,
	SDBBoxCachePtr 	*entry)
{
	CSIDSTreeNode	*node;
	SDBBoxList		boxList;
	SDBBoxPtr		box;
	
	boxList = Database_GetBoxList(sdb);
	Assert(boxList); 
	if (boxList == NULL) return NULL;
	Assert(boxList->byCSID);

	node = STree_FindDataByKey(boxList->byCSID, (void *) csid);
	if ( node ) {
		*entry = node->entry;
		if ( *entry == NULL )
			return(NULL);
	}
	else
		return(NULL);

    /* 
	 * If the entry is valid, this will simply return the box pointer,
	 * otherwise, load the box off disk to validate the entry.
	 */
	gRDinfo.type  = kBoxRead;
	gRDinfo.data  = NULL;
	gRDinfo.cache = gCache;
	box = Cache_ReadBox(*entry, &gRDinfo);

	return(box);
}

