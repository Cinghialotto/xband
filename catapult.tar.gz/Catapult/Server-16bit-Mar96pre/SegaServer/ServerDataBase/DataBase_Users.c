/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 *	$Id
 *
 *	$Log: DataBase_Users.c,v $
 * Revision 1.2  1995/05/28  20:41:22  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		DataBase_Users.c

	Contains:	xxx put contents here xxx

	Written by:	David Jevans


	Change History (most recent first):

		 <8>	11/16/94	KD		users->list is now an abstraction so calls special _New when
									creating users (Database_UserAccess.c)
		 <7>	10/26/94	DJ		SDBUsers->list is now a list of lists, one per region.  Each
									sublist is a list of SDBBox by boxID.
		 <6>	 10/3/94	ATM		Now using gConfig.
		 <5>	 9/25/94	ATM		Changed HAPPY_REGION to gHappyRegion.
		 <4>	 8/17/94	ATM		Changed the "1" to be HAPPY_REGION (now in Server.h).
		 <3>	 8/15/94	DJ		made all new unique boxregions = 1 in order to invalidate all
									existing users (8/15/94)
		 <2>	 7/12/94	DJ		updated Database_GenerateUniqueBoxSerialNumber to new boxsernum
									format
		 <1>	 5/31/94	DJ		Handle user accounts, box serial numbers, etc

	To Do:
*/



#include <stdlib.h>

#include "Server.h"
#include "ServerDataBase_priv.h"
#include "Common_ReadConf.h"
#include "Errors.h"

SDBUsers *SDBUsers_New(void)
{
SDBUsers *users;
	
	users = (SDBUsers *)malloc(sizeof(SDBUsers));
	ASSERT(users);
	if(!users)
	{
		ERROR_MESG("out of mems");
		return(NULL);
	}

	users->numUsers = 0;
	users->uniqueBoxSerialNumber = 1;
	users->timeStamp = 1;
	users->list = Database_NewBoxList();
		/* I wouldn't assume anything about this list, except 
			all access is in DataBase_UserAccess.c */

	return(users);
}

void Database_GenerateUniqueBoxSerialNumber(BoxSerialNumber *boxSerialNumber)
{
SDBUsers *users;

	users = SDB_GetUsers(gSDB);
	ASSERT(users);
	
	boxSerialNumber->box = users->uniqueBoxSerialNumber++;
	boxSerialNumber->region = gConfig.happyRegion;
}

long Database_GetTimeStamp(void)
{
SDBUsers *users;

	users = SDB_GetUsers(gSDB);
	ASSERT(users);
	
	return(users->timeStamp);
}

long Database_IncrementTimeStamp(void)
{
SDBUsers *users;

	users = SDB_GetUsers(gSDB);
	ASSERT(users);
	
	return(++users->timeStamp);
}

