/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: DataBase_Games.c,v 1.5 1995/05/28 20:41:03 jhsia Exp $
 *
 * $Log: DataBase_Games.c,v $
 * Revision 1.5  1995/05/28  20:41:03  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		DataBase_Games.c

	Contains:	xxx put contents here xxx

	Written by:	David Jevans


	Change History (most recent first):

		<13>	 9/19/94	ATM		Don't use Transmogrify anymore.
		<12>	 9/12/94	ATM		Moved GameInfo stuff out.
		<11>	  9/6/94	ATM		Removed references to wait queues and SDBWaiting stuff.
		<10>	  9/3/94	ATM		Added GameInfo stuff.
		 <9>	 8/16/94	ATM		Changed FindGame so that it will selectively Transmogrify for
									cases when Old Jams really is Old Jams.
		 <8>	 8/13/94	ATM		Added call to transmogrifier.
		 <7>	 8/12/94	DJ		made compile with new errors
		 <6>	 7/25/94	DJ		5 days of hacking, including: added general waitq
		 <5>	 7/19/94	DJ		gameName is now just a char*
		 <4>	 7/18/94	DJ		added opponentMagicCookie
		 <3>	 6/12/94	DJ		adding the game to the list on the games struct in
									DataBase_NewGame
		 <2>	 6/11/94	DJ		made it real (adding new game, etc)
		 <1>	 5/31/94	DJ		first checked in

	To Do:
*/



#include <stdlib.h>

#include "Server.h"	// this is only for PreformedMessage type
#include "ServerDataBase.h"
#include "ServerDataBase_priv.h"
#include "Errors.h"

#include <string.h>


SDBGames *
SDBGames_New(void)
{
	SDBGames *games;
	
	games = (SDBGames *)malloc(sizeof(SDBGames));
	ASSERT(games);
	if (!games) {
		ERROR_MESG("out of mems");
		return(NULL);
	}

	games->list = NewList();
	//games->opponentMagicCookie = 0;

	return(games);
}


//
// Find a game in the list of known games.
//
// Returns a pointer to the GameNode, or NULL if the game couldn't be found.
//
// BRAIN DAMAGE: this probably ought to use boxType.
//
SDBGameNode *
Database_FindGame(long platformID, long gameID)
{
	SDBGameNode	*gameNode;
	SDBGames	*games;
	ListNode	*node;

	games = SDB_GetGames(gSDB);
	ASSERT(games);

	// Need to search on both platformID and gameID.
	//
	for (node = GetFirstListNode(games->list); node != NULL;
		node = GetNextListNode(node))
	{
		gameNode = (SDBGameNode *)GetListNodeData(node);
		ASSERT(gameNode);
		if (gameNode == NULL)
			continue;
		if (gameNode->platformID == platformID && gameNode->gameID == gameID)
			return (gameNode);
	}
	
	return (NULL);
}


//
// Add a new game to the list of known games.  The game should not already
// exist in the list.
//
// Passing in a NULL game patch no longer makes sense.
//
// BRAIN DAMAGE: this probably ought to use boxType.
//
Err
DataBase_NewGame(long platformID, long gameID, long version,
	char *gameName, PreformedMessage *patch)
{
SDBGameNode	*gameNode;
SDBGames	*games;
ListNode	*lnode;

	if (patch == NULL) {
		PLogmsg(LOGP_FLAW, "ERROR: NULL game patch for '%.4s' 0x%.8lx\n",
			(char *)&platformID, gameID);
		return (kFucked);
	}

	// Make sure we don't stuff it in twice.
	//
	if (Database_FindGame(platformID, gameID)) {
		ERROR_MESG("duplicate game id");
		return (kDuplicateGameID);
	}
	
	gameNode = (SDBGameNode *)malloc(sizeof(SDBGameNode));
	ASSERT(gameNode);
	if (!gameNode) {
		ERROR_MESG("out of mems");
		return (kOutOfMemoryErr);
	}
	
	gameNode->platformID = platformID;
	gameNode->gameID = gameID;
	gameNode->version = version;
	strncpy(gameNode->gameName, gameName, kGameNameSize);
	
	if (patch) {
		gameNode->patch = PreformedMessage_Duplicate(patch);
		ASSERT(gameNode->patch);
	} else
		gameNode->patch = NULL;	// yes, it is valid for version 1 patches to be NULL

	//gameNode->rankings = NULL;

	// Alloc a list node, point the list node at the gameNode, and add the
	// list node to the list of games.
	//
	games = SDB_GetGames(gSDB);
	ASSERT(games);
	lnode = NewListNode((Ptr)gameNode);
	ASSERT(lnode);
	AddListNodeToList(games->list, lnode);
	
	return(kNoError);
}


#ifdef NOT_USED
//
// Should be setting and updating the NGP too.	6/10/94
//
// Nah.  950203
//
Err
DataBase_AddGamePatch(long platformID, long gameID, long version,
	PreformedMessage *patch)
{
SDBGameNode			*game;
PreformedMessage	*msg;

	game = Database_FindGame(platformID, gameID);
	if (!game) {
		ERROR_MESG("game is not in the database!");
		return (kNoSuchGameID);
	}

	// check that new is newer version.
	// if so, delete old patch, add new patch, set new version.
	if (version <= game->version) {
		ERROR_MESG("new game patch version is not higher than existing patch version");
		return(kPatchVersionNotHigher);
	}
	
	
	msg = PreformedMessage_Duplicate(patch);
	ASSERT(msg)
	if (!msg)
		return(kOutOfMemoryErr);
	
	if (game->patch)
		PreformedMessage_Dispose(game->patch);

	game->patch = msg;
	game->version = version;

	return (kNoError);
}
#endif /*NOT_USED*/


//
// Reset the game list, freeing it if it already exists.  Done as part of
// a reload.
//
Err
DataBase_NukeGamePatches(void)
{
	SDBGameNode	*gameNode;
	SDBGames	*games;
	ListNode	*node;

	games = SDB_GetGames(gSDB);
	if (games != NULL) {
		PLogmsg(LOGP_NOTICE, "ERASING existing game patch list\n");

		// Run through and free the stuff that the listNode's data pointer
		// points to.
		//
		for (node = GetFirstListNode(games->list); node != NULL;
			node = GetNextListNode(node))
		{
			gameNode = (SDBGameNode *)GetListNodeData(node);
			//Logmsg("DBUG freed '%.4s' 0x%.8lx v%ld\n",
			//	(char *)&gameNode->platformID,
			//	gameNode->gameID, gameNode->version);
			PreformedMessage_Dispose(gameNode->patch);
			free(gameNode);
		}

		DisposeList(games->list);
		games->list = NULL;
		free(games);
		gSDB->games = NULL;		// urgh
	}

	return (kNoError);
}

