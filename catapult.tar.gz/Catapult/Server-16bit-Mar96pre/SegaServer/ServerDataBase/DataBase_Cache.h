/*
 * $Id: DataBase_Cache.h,v 1.4 1995/09/17 20:44:28 steveb Exp $
 *
 * $Log: DataBase_Cache.h,v $
 * Revision 1.4  1995/09/17  20:44:28  steveb
 * Added support for "smart" stitcher updates.
 *
 * Revision 1.3  1995/09/13  14:15:22  ted
 * Fixed warnings.
 *
 * Revision 1.2  1995/08/21  13:10:55  steveb
 * Caching rpc.segad re-checkin.
 *
 *
 */

#ifndef __DataBase_Cache_h__
#define __DataBase_Cache_h__

#include <stdio.h>

#include "ServerDataBase_priv.h"
#include "Errors.h"

#define kForceWrite     0x8000
#define kInformStitcher 0x4000
#define kBoxRead        0x0001
#define kBoxWrite       0x0002
#define kCheckPoint     0x0004

typedef struct _SDBBoxCache *SDBBoxCachePtr;
typedef struct _SDBCache    *SDBCachePtr; 
typedef struct _CacheRWInfo *CacheRWInfoPtr;

typedef struct _CacheRWInfo {
    unsigned type; /* what kind of read/write are we doing */
    void *data;    /* pointer to data passed to read/write function */
 
    SDBCachePtr cache; /* pointer to the cache data structure */
} CacheRWInfo;

typedef SDBBox *SDBBoxPtr;
typedef BoxSerialNumber *BSNPtr;

typedef SDBBoxPtr (*BoxRead)  (SDBBoxCachePtr, SDBCachePtr);
typedef Err       (*BoxWrite) (SDBBoxCachePtr, SDBCachePtr, void *);
typedef void      (*BoxFree)  (SDBBoxCachePtr, SDBCachePtr);

/*
 * Primitive read/write/free functions.
 */
SDBBoxPtr _read_cached_box  (SDBBoxCachePtr, SDBCachePtr);
Err       _write_cached_box (SDBBoxCachePtr, SDBCachePtr, void *);
void      _free_cached_box  (SDBBoxCachePtr, SDBCachePtr);

#define P_ReadBox  _read_cached_box
#define P_WriteBox _write_cached_box
#define P_FreeBox  _free_cached_box

/*
 * Cache management prototypes.
 */
SDBCachePtr Cache_New (long, BoxRead, BoxWrite, BoxFree);
SDBBoxCachePtr Cache_NewEntry (SDBBoxPtr);
void Cache_InvalidateEntry (SDBBoxCachePtr);

SDBBoxPtr Cache_ReadBox (SDBBoxCachePtr, CacheRWInfoPtr);
Err Cache_WriteBox (SDBBoxCachePtr, CacheRWInfoPtr);

BSNPtr Cache_GetBsn (SDBBoxCachePtr);
void  Cache_Stats (SDBCachePtr);

/*
 * Some pre-defined variables for your convenience.
 */
extern SDBCachePtr gCache;
extern CacheRWInfo gRDinfo;
extern CacheRWInfo gWRinfo;

/*
 * Following are a bunch of function prototypes that were previously
 * declared elsewhere, but are here now because of their new dependancy
 * on the cache data structures.  This was done to avoid including this
 * header all over the place just to support prototypes in other headers.
 */

typedef Err (*ForEachProc) (SDBBoxCachePtr, CacheRWInfoPtr); // was void *

Err Database_AddBox(SDB *, SDBBoxCachePtr);
Err Database_ForEachBox(SDB *, ForEachProc, void *);

Err Database_BeginUpdateName(SDB *, SDBBoxCachePtr, unsigned char);
Err Database_EndUpdateName(SDB *, SDBBoxCachePtr, unsigned char);
Err Database_BeginUpdateBoxID(SDB *, SDBBoxCachePtr);
Err Database_EndUpdateBoxID(SDB *, SDBBoxCachePtr);
Err Database_BeginUpdateHWID(SDB *, SDBBoxCachePtr);
Err Database_EndUpdateHWID(SDB *, SDBBoxCachePtr);
Err Database_BeginUpdatePhone(SDB *, SDBBoxCachePtr);
Err Database_EndUpdatePhone(SDB *, SDBBoxCachePtr);
Err Database_BeginUpdateCSID(SDB *, SDBBoxCachePtr);
Err Database_EndUpdateCSID(SDB *, SDBBoxCachePtr);

SDBBox *Database_FindBoxByBSN(
	SDB *, 
	const BoxSerialNumber *, 
	SDBBoxCachePtr *);

SDBBox *Database_FindBoxByCSID(
	SDB *, 
	unsigned long,
	SDBBoxCachePtr *);

SDBUser *Database_FindUserByName(
	SDB *, 
	const u_char *, 
	SDBBoxCachePtr *);

SDBBox *Database_FindBoxByHWID(
	SDB *, 
	const HardwareID *, 
	long,
	SDBBoxCachePtr *);
 
SDBBox *Database_FindBoxByPhone(
	SDB *, 
	const phoneNumber *, 
	long, 
	SDBBoxCachePtr *);

SDBBox *Database_FindOpenBoxByPhone(
	SDB *, 
	const phoneNumber *, 
	long, 
	SDBBoxCachePtr *);

SDBBox *Database_FindReplacementBoxByPhone(
	SDB *, 
	const phoneNumber *,
	long platformID,
	SDBBoxCachePtr *);

SDBBox *Database_FindNewBoxByPhone(
	SDB *, 
	const phoneNumber *,
	long,
	SDBBoxCachePtr *);

SDBUser *Database_FindUser(
	const userIdentification *, 
	SDBBoxCachePtr *);

SDBUser *Database_FindUserByHandle(
	const u_char *, 
	SDBBoxCachePtr *);

SDBBox *Database_FindBoxAccount(
	SDBUsers *, 
	BoxSerialNumber *,
	SDBBoxCachePtr *);

#endif /* __DataBase_Cache_h__ */

