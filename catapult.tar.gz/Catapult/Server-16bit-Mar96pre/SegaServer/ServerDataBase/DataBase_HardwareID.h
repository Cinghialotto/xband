/*
 * Copyright: @ 1995 Catapult Entertainment Inc., all rights reserved
 *
 * $Id: DataBase_HardwareID.h,v 1.4 1995/06/19 20:55:19 fadden Exp $
 *
 * $Log: DataBase_HardwareID.h,v $
 * Revision 1.4  1995/06/19  20:55:19  fadden
 * Tweak.
 *
 * Revision 1.3  1995/06/01  15:11:13  fadden
 * Merge in from newbr.
 * -> Added this file (def of HardwareID struct).
 *
 * Revision 1.2  1995/05/28  20:41:04  jhsia
 * switch to rcs keywords
 *
 * Revision 1.1  1995/05/24  01:20:42  fadden
 * Initial version.
 *
 */
#ifndef _DATABASE_PLATFORM_ID_H
#define _DATABASE_PLATFORM_ID_H

#include "SNESHardwareID.h"

// Hardware ID types.
//
#define kHWID_NoHWID			0		/* no HWID, skip it */
#define kHWID_DallasTouch		1		/* used on production SNES */
#define kHWID_SCSecureMicro		2		/* to be defined; for SegaChannel */


#define kServerHWIDPadding		32		// #of bytes for pad; sync with RPC

//
// HardwareID storage definition for the database.
//
// There are different kinds of hwid that will occupy different amounts of
// storage.  The "fakeHWID" type is there so that, if we add another type
// that's larger than the previous definitions, we don't have to do a
// complete database re-thrash.
//
typedef struct HardwareID {
	char	hardwareIDtype;			// how to interpret rest of struct
	char	pad[3];					// XDR doesn't always pad
	union {
		struct {
			short			snesHardwareIDerror;	// hwid valid?
			SnesHardwareID	snesHardwareID;
		} snesHWID;
		struct {
			long			schnHardwareID;			// to be defined
		} schnHWID;
		struct {
			char			padding[kServerHWIDPadding];
		} fakeHWID;
	} hwid;
} HardwareID;

#endif /*_DATABASE_PLATFORM_ID_H*/
