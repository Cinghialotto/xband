/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: BINTree.c,v 1.5 1996/01/24 12:46:47 ted Exp $
 *
 * $Log: BINTree.c,v $
 * Revision 1.5  1996/01/24  12:46:47  ted
 * Removed obsolete ASSERT b/c you can now specify a NULL delete proc.
 *
 * Revision 1.4  1996/01/22  16:04:30  ted
 * Fixed potential bug, made slight optimizations.
 *
 * Revision 1.3  1995/09/13  14:15:20  ted
 * Fixed warnings.
 *
 * Revision 1.2  1995/05/28  20:40:58  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		BINTree.c

	Contains:	xxx put contents here xxx

	Written by:	Ted


	Change History (most recent first):

		 <1>	 11/7/94	HEC		first checked in

	To Do:
*/

/*
	This file implements a standard binary tree.
	
	Written by Ted Cohn
	Copyright 1994, Catapult Entertainment, Inc.
	All Rights Reserved.
	September 1994

	Key Features:

		� No recursion for speed 
		� Caller-supplied node allocation for efficiency and speed
		��Caller-supplied compare, dump, and delete procs
	
	For matching, nodes are part of contestant structures.
	This saves us having to malloc a tree node every time we want
	to insert the contestant into a tree. Since we know what and
	how many trees one will be inserted into, tree nodes are simply
	part of the contestant structure.
	
	The next step would be to upgrade to an AVL or Splay tree
	implementation to keep trees balanced at all times for
	maximum efficiency.

	Using The Tree:
	
	To start using a tree, call BINInit to initialize the tree. Then
	call BINSetCompareProc to set the current compare procedure.
	Then call BINInsert with nodes you wish to insert into the tree.
	Once nodes have been inserted, you can call BINSearch, BINDump,
	and BINDelete.
*/

#include <stdlib.h>
#include "Errors.h"
#include "BINTree.h"

#define nil 0L

static BINCMPProc		gCompareProc;
static BINDelProc		gDeleteProc;
static BINDumpProc		gDumpProc;

/********************************************************************************
	Description:
		Initializes a binary tree.
	Input:
		tree = binary tree to initialize
	Output:
		none
********************************************************************************/

void BINInit(BINTreePtr tree)
{
	tree->root = nil;
	tree->members = 0;
}

BINCMPProc BINSetCompareProc(register BINCMPProc cmpProc)
{
	register BINCMPProc oldproc;
	
	ASSERT(cmpProc);
	oldproc = gCompareProc;
	gCompareProc = cmpProc;
	return oldproc;
}

BINDumpProc BINSetDumpProc(register BINDumpProc dumpProc)
{
	register BINDumpProc oldproc;

	ASSERT(dumpProc);
	oldproc = gDumpProc;
	gDumpProc = dumpProc;
	return oldproc;
}

BINDelProc BINSetDeleteProc(register BINDelProc deleteProc)
{
	register BINDelProc oldproc;

	oldproc = gDeleteProc;
	gDeleteProc = deleteProc;
	return oldproc;
}

/********************************************************************************
	Description:
		Insert given node into a binary tree using the current BINCMPProc.
	Input:
		tree	= binary tree we're insert node into
		node	= node to insert
	Output:
		none
********************************************************************************/

short BINInsert(register BINTreePtr tree, void *key)
{
	register long result;
	register BINNodePtr n;
	register BINNodePtr node;

	ASSERT(tree);
	ASSERT(key);
	
	node = key;
	n = tree->root;
	
	if (n == nil)
	{
		tree->root = node;
		tree->members = 1;
		node->parent = nil;
		return noErr;
	}
	
	while (1) {
		result = (*gCompareProc)(n, node);
		if ( result == T_LT )
		{
			if (n->left == nil)
			{
				n->left = node;
				node->parent = n;
				tree->members++;
				break;
			}
			else n = n->left;
		}
		else // T_GT or T_EQ. We may have to insert a duplicate element
			 // CAREFUL: clients depend on this!
		{
			if (n->right == nil)
			{
				n->right = node;
				node->parent = n;
				tree->members++;
				break;
			}
			else n = n->right;
		}
	}
	node->left = nil;
	node->right = nil;
	return noErr;
}

/********************************************************************************
	Description:
		Find the given node in the tree using the current BINCMPProc.
		Changing to take a node to search from (to continue searches).
	Input:
		tree	= binary tree to search
		node	= node to look up (i.e., node is not part of tree yet)
	Output:
		pointer to node if successfull, otherwise nil.
********************************************************************************/

BINNodePtr BINSearch(register BINNodePtr node, register void *data)
{
	register long result;
	
	while (node)
	{
		result = (*gCompareProc)(node, data);
		if ( result == T_DEL && gDeleteProc)
			node = (*gDeleteProc)(node);
		else if ( result == T_LT )
			node = node->left;
		else if ( result == T_GT )
			node = node->right;
		else
			return node;	// search succeeded, returning node
	}
	return nil;				// search failed
}

/********************************************************************************
	Description:
		Performs "in order" tree traversal to dump (or process) nodes in
		ascending order. This *can* be used to dump a tree. Change the current
		BINDumpProc to do something unique.
		[RECURSIVE]
	Input:
		t		= current tree node to traverse
		refcon	= data from BINDumpProc
	Output:
		none
********************************************************************************/

void BINDump(register BINNodePtr n, register long refcon)
{
	if (n == nil)
		return;
		
	BINDump(n->left, refcon);
	(*gDumpProc)(n, refcon);
	BINDump(n->right, refcon);
}

/********************************************************************************
	Description:
		Given a binary tree, delete the given node.  For speed, we don't need to
		traverse the tree, just use back pointers to find the parent node.
	Input:
		root = binary tree we're deleting from
		node = node to delete
	Output:
		Return the node which replaced the deleted one (to continue searches)
		If nil, then search ends.
********************************************************************************/

BINNodePtr BINDelete(register BINTreePtr tree, BINNodePtr node)
{
	register BINNodePtr repl;
	register BINNodePtr parent;

	ASSERT(tree);

	parent = node->parent;
	
	// return if this node is not in the tree
	if (!parent && tree->root != node)
		return nil;

	if (node->right && node->left)
	{
		register BINNodePtr t = node->right;
	
		if (t->left == nil)
		{
			t->left = node->left;
			repl = t;
		}
		else
		{
			for ( ; t->left->left; t = t->left )
				;
			repl = t->left;
			t->left = repl->right;
			repl->left = node->left;
			node->left->parent = repl;
			repl->right = node->right;
			node->right->parent = repl;
		}
		if (t->left)
			t->left->parent = t;
	}
	else
	{
		repl = node->right;
		if (!repl)
			repl = node->left;
	}
	if (repl)
		repl->parent = node->parent;
	if (parent)
	{
		if (parent->left == node)
			parent->left = repl;
		else
			parent->right = repl;
	}
	else
		tree->root = repl;
	
	// completely sever node link

	node->parent = nil;
	node->left = nil;
	node->right = nil;
	
	tree->members--;
	return repl;
}

void BINClearNode(BINNodePtr n)
{
	n->parent = nil;
	n->left = nil;
	n->right = nil;
}

