select distinct
   sum(decode(cn.net_error_code,13,1)) total_freq,
   count(*) good_freq,
   substr(to_char( (sum(decode(cn.net_error_code,13,1)) /
   count(*)) * 100 ,'99.99'),1,11) percnt_bad,
   substr(bl.area_code,1,5) ac,
   substr(main_number,1,20) main_number
from
   x25_pop, connection_log cl, connection_net_error cn,
   box_log bl, player_log pl
where
   cl.x25_pop_uid = x25_pop.x25_pop_uid and
   cl.start_time between '&&1' and '&&2' and
   cn.connection_uid = cl.connection_uid and
   cl.player_uid = pl.player_uid and
   pl.box_uid = bl.box_uid 
having
   sum(decode(cn.net_error_code,13,1)) >= 5
group by
   lpad(x25_pop_address,10),
   bl.area_code,
   main_number
order by
   substr(to_char( (sum(decode(cn.net_error_code,13,1)) /
   count(*)) * 100 ,'99.99'),1,11) desc
/
