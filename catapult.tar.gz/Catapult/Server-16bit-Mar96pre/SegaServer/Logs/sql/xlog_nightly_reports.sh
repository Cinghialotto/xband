#!/bin/sh
#
# Copyright: @ 1995 Catapult Entertainment Inc., all right reserved
#
# $Id: xlog_nightly_reports.sh,v 1.2 1995/10/03 01:04:27 felix Exp $
#
# $Log: xlog_nightly_reports.sh,v $
# Revision 1.2  1995/10/03  01:04:27  felix
# Added mia to recipient list for X25 pop no answer report
#
# Revision 1.1  1995/09/08  21:02:26  felix
# Created Compuserve POP no answer report for Matt Wagner
#
#

date
 
#  This script runs a X25 no answer by pop report for Matt Wagner

ORACLE_HOME=/opt/oracle
export ORACLE_HOME
TWO_TASK=xlogded
export TWO_TASK

LIBDIR=/opt/catapult/bin/sql   			# sql, control files
LOGDIR=/var/catapult        		 	# log files, report output

PATH=$PATH:/opt/oracle/bin/:/usr/local/bin
export PATH
 
sqlplus -s /@xlog <<EOF
set termout off
set feedback off
spool $LOGDIR/x25_no_answer.lis
col sdate noprint new_value today
select trunc(sysdate) sdate from dual;
col sdate noprint new_value yesterday
select trunc(sysdate-1) sdate from dual;
start $LIBDIR/x25_no_answer.sql &&yesterday &&today;
exit;
EOF

elm -s "Catapult X25 no answer pop report" REGINE@CSI.CompuServe.com felix@catapent.com mwagner@catapent.com mia@catapent.com < $LOGDIR/x25_no_answer.lis

date
