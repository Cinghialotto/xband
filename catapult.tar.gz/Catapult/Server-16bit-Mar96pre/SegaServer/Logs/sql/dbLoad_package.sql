-- Copyright: @ 1995 Catapult Entertainment, Inc., all rights reserved
--
-- $Id: dbLoad_package.sql,v 1.2 1995/05/26 23:09:13 jhsia Exp $
--
-- $Log: dbLoad_package.sql,v $
# Revision 1.2  1995/05/26  23:09:13  jhsia
# switched to rcs keywords
#
--
-- dbLoad_package.sql
--
-- raja aji, feb 95
--
create or replace package dbload_package as
  
  procedure load;

end dbLoad_package;
/
