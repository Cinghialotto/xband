#!/bin/sh 
# 
# Copyright: @ 1995 Catapult Entertainment Inc., all rights reserved 
# 
# $Id: xlog_dbLoad.sh,v 1.19 1995/10/29 19:22:59 felix Exp $
#
# $Log: xlog_dbLoad.sh,v $
# Revision 1.19  1995/10/29  19:22:59  felix
# Removed the '-9' option from gzip when compressing binlogs
#
# Revision 1.18  1995/10/20  14:19:42  felix
# Changed paths to use old versions of Oracle stuff
#
# Revision 1.17  1995/10/09  18:01:16  felix
# Changed INIT discard string to NOT ignore fe1
#
# Revision 1.16  1995/10/09  14:56:37  felix
# Removed all cm[2-4] stuff
#
# Revision 1.15  1995/09/29  14:01:56  felix
# Added fe1-fe5 binlogs to load, took out cm1 binlogs
#
# Revision 1.14  1995/08/21  23:16:55  felix
# Added call to xlog_nightly_reports.sh at the end, after nightly processing done
#
# Revision 1.13  1995/08/16  14:27:45  felix
# Added checks to make sure summaries, XBN reports and XBN billing are successful
#
# Revision 1.11  1995/08/09  13:01:41  felix
# Un-commented call to XBN estimates
#
# Revision 1.10  1995/07/28  03:32:28  felix
# Added ORACLE_HOME, to prevent core-dumping of sqlldr.
#
# Revision 1.9  1995/07/27  11:05:01  felix
# Added stuff to PATH so gzip, elm, etc will run
#
# Revision 1.8  1995/07/25  17:57:08  felix
# grep -v'd macro expansions out of xbn reports before e-mail
#
# Revision 1.7  1995/07/19  13:02:43  felix
# Changed sort directory from /tmp to /export/bilbo/tmp
#
# Revision 1.6  1995/07/14  15:04:58  felix
# Added gzip to log files when complete, and run dumplog under rsh to mgate
#
# Revision 1.5  1995/06/21  17:17:30  felix
# Added full path name for dumplog
#
# Revision 1.4  1995/06/16  14:22:51  felix
# Fixed logical error in testing for file existence
#
# Revision 1.3  1995/06/12  21:21:19  felix
# Updated 'yesterday' to use SteveB's format
#
# Revision 1.2  1995/06/12  17:27:12  felix
# Modified for production on copernicus
#
# Revision 1.1  1995/06/08  23:17:17  felix
# Re-named file from do_dbLoad.sh
#
# Revision 1.3  1995/06/08  13:02:18  felix
# Added full path for "yesterday" command
#
#

date

ORACLE_HOME=/opt/oldoracle
export ORACLE_HOME
TWO_TASK=xlogded
export TWO_TASK

BINDIR=/opt/catapult/bin			# scripts, utilities
LIBDIR=/opt/catapult/bin/sql   			# sql, control files
LOGDIR=/var/catapult        		 	# log files, report output

PATH=$ORACLE_HOME/bin:/usr/local/bin:$PATH
export PATH

# had to do this for kluge to run dumplog on mgate
#
TMPDIR=/export/bilbo/tmp

yesterday=`$BINDIR/yesterday -l`    		# get yesterday 
if test $1 ; then
  yesterday=$1
fi

echo today is `date`, and yesterday is presumed to be $yesterday

datafile=/logs/v7.binlog.${yesterday}
extensions="fe1 fe2 fe3 fe4 fe5" # if you change this, change the
						# grep -v "^INIT.." below, also.

# make sure file has arrived

for extension in $extensions; do

  echo testing $datafile.$extension...

  if test ! -r $datafile.$extension ; then
    echo " "
    echo "****************"
    echo " "
    echo binlog-dbLoad
    echo could not read file $datafile.$extension
    echo " "
    echo "****************"
    echo " "
    if test "$yesterday" -ne "$1" ; then 

  elm -s 'ERROR:binlog_did_not_arrive' felix@catapent.com <<EOF

The requested binlog $datafile.$exension could not be imported because 
it could not be read.  I really tried.  Really.

EOF

    fi
    exit;
  fi
done

workfile=$TMPDIR/temp.$yesterday
controlfile=$LIBDIR/dbLoad.ctl
discardfile=$LOGDIR/discard.$yesterday
badfile=$LOGDIR/bad.$yesterday
logfile=$LOGDIR/log.$yesterday

echo " "
echo "****************"
echo " "
echo binlog-dbLoad
echo processing files $datafile.$extionsions
echo started file parse at `date`
echo " "
echo "****************"
echo " "

for extension in $extensions; do

echo $BINDIR/dumplog -X8 -D $workfile.$extension $datafile.$extension 
$BINDIR/dumplog -X8 -D $workfile.$extension $datafile.$extension > /dev/null

done

cat ${workfile}* | grep -v "^[0-9]*\.[0-9]*$" | 
  sort -T $TMPDIR -n | grep -v "^0\." | 
  grep -v "^[0-9]*\.[0-9]*$" | sed 's/^[0-9.]*	//' |
  grep -v "^INIT.*fe[2-9]" > ${workfile}.sorted

echo " "
echo "****************"
echo " "
echo started sqlldr at `date`
echo " "
echo "****************"
echo " "

sqlldr data=$workfile.sorted control=${controlfile} direct=yes userid=/ discard=${discardfile} bad=${badfile} log=${logfile} 

if test -r ${discardfile} ; then
  echo " "
  echo "*****************"
  echo " "
  echo error : sqlloader failed on ${workfile}
  echo error : discard file created
  echo " "
  echo "*****************"
  echo " "
  elm -s 'ERROR:sqlldr_failed' felix@catapent.com <<EOF

The requested binlog $datafile did not load properly.
It died in the sqlldr step.  Check loadall.log and see for yourself.

EOF
  exit 0 
fi

if test -r ${badfile} ; then
  echo " "
  echo "*****************"
  echo " "
  echo error : sqlloader failed on ${workfile}
  echo error : bad file created
  echo " "
  echo "*****************"
echo " "
  elm -s 'ERROR:sqlldr_failed' felix@catapent.com <<EOF

The requested binlog $datafile did not load properly.
It died in the sqlldr step.  Check loadall.log and see for yourself.

EOF
  exit 0 
fi

echo " "
echo "****************"
echo " "
echo started sqlplus at `date`
echo " "
echo "****************"
echo " "

sqlplus / << EOF
whenever sqlerror exit -1;
set serverout on size 40000;
execute dbLoad_package.load;
exit 0;
EOF

if test "$?" -ne "0" ; then
  echo " "
  echo "***************"
  echo " "
  echo error : plsql failed
  echo " "
  echo "***************"
  echo " "
  elm -s 'ERROR:binlog/plsql_failed' felix@catapent.com <<EOF

The requested binlog $datafile did not load properly.
It died in the plsql step.  Check loadall.log and see for yourself.

EOF
  exit 0 
fi

rm ${workfile}*
echo " "
echo "****************"
echo " "
echo finished processing $datafile at `date`
echo " "
echo "****************"
echo " "

#  ********** post-load nightly processing stuff...  Reports, etc.  *********

echo refreshing snapshots, and calculating/generating summary info...

$BINDIR/xlog_summary.csh
elm -s "Xlog summary reports for $yesterday" \
   felix@catapent.com, ckn@catapent.com, raja@catapent.com < \
   $LOGDIR/summary_report.lis

if test "$?" -ne "0" ; then
  echo " "
  echo "***************"
  echo " "
  echo error : xlog_summary.csh died.
  echo " "
  echo "***************"
  echo " "
  elm -s 'ERROR:xlog_summary.csh failed' felix@catapent.com <<EOF

The nightly xlog summaries failed.  Go fix them.

EOF
  exit 0 
fi

echo running XBN reports...

$BINDIR/run_xbn_reports.sh $yesterday
cat $LOGDIR/xbn_reports.$yesterday | grep -v '^old' | grep -v '^new' |
elm -s "Xlog XBN reports for $yesterday" \
   felix@catapent.com, ted@catapent.com

if test "$?" -ne "0" ; then
  echo " "
  echo "***************"
  echo " "
  echo error : run_xbn_reports.sh failed
  echo " "
  echo "***************"
  echo " "
  elm -s 'ERROR:run_xbn_reports.sh failed' felix@catapent.com <<EOF

The nightly XBN reports failed.  Go fix them.

EOF
  exit 0 
fi

echo running nightly XBN billing update 

$BINDIR/xlog_xbn_nightly.sh

if test "$?" -ne "0" ; then
  echo " "
  echo "***************"
  echo " "
  echo error : nightly XBN billing update failed
  echo " "
  echo "***************"
  echo " "
  elm -s 'ERROR:xlog_xbn_nightly.sh failed' felix@catapent.com <<EOF

The nightly XBN billing update failed.  Go fix it.

EOF
  exit 0 
fi

date

echo running nightly reports...

$BINDIR/xlog_nightly_reports.sh

if test "$?" -ne "0" ; then
  echo " "
  echo "***************"
  echo " "
  echo error : nightly xlog reports died.
  echo " "
  echo "***************"
  echo " "
  elm -s 'ERROR:xlog_nightly_reports.sh failed' felix@catapent.com <<EOF

The nightly xlog reports spontaneously combusted.  Go fix them.

EOF
  exit 0 
fi

echo compressing binlogs, now that we no longer need them...

gzip $datafile*
