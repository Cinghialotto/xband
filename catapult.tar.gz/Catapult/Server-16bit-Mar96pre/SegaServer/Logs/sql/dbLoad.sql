-- @(#) %W% (Catapult Entertainment, Inc.) %E%
--
-- dbLoad.sql
--
-- raja aji, feb 95
--
-- package body for the dbLoad package. These procedures copy data
-- from a temp table populated by sqlloader into the various log tables.
-- mappings from temp table to real tables is set here.
-- 
create or replace package body dbload_package as

  cursor main_cursor is
  	select	record_type, record_num, flex_char1, flex_char2,
		flex_char3, flex_char4, flex_char5, flex_char6,
		flex_char7, flex_char8, flex_char9, flex_char10,
		flex_char11, flex_char12, flex_char13, flex_char14,
		flex_char15, flex_char16, flex_char17, flex_char18,
		flex_char19, flex_char20, flex_char21, flex_char22,
		flex_char23, flex_char24, flex_char25, flex_char26,
		flex_char27, flex_char28, flex_char29, flex_num1,
		flex_num2, flex_num3, flex_num4, flex_num5,
		flex_num6, flex_num7, flex_num8, flex_num9,
		flex_num10, flex_num11, flex_num12, flex_num13,
		flex_num14, flex_num15, flex_num16, flex_num17,
		flex_num18, flex_num19, rowid
	from  	temp_dbload
	order by record_num;

  cdbLoad_Init			varchar2(4) :=	'INIT';
  cdbLoad_ConnectionInfo	varchar2(4) :=	'CONN';
  cdbLoad_ConnCarrier		varchar2(4) :=	'CARR';
-- taken out of V7 logs:
-- cdbLoad_ConnType		varchar2(4) :=	'TYPE'; 
-- replaced with this:
  cdbLoad_ConnTypeGameID	varchar2(4) :=	'GMID'; 
-- and this:
  cdbLoad_ConnTypeOpponent	varchar2(4) :=	'OPON'; 
  cdbLoad_Crash			varchar2(4) :=	'CRAS';
  cdbLoad_CrashDispatch		varchar2(4) :=  'CRDS';
  cdbLoad_CrashPC		varchar2(4) :=	'CRPC';
  cdbLoad_GameResults		varchar2(4) :=	'GAME';
  cdbLoad_GameErrorResults	varchar2(4) :=  'GMER';
  cdbLoad_800Errors		varchar2(4) :=	'800E';
  cdbLoad_X25Errors		varchar2(4) :=	'X25E';
  cdbLoad_StreamErrors		varchar2(4) :=	'STRM';
  cdbLoad_CreditChanges		varchar2(4) :=	'CRED';
  cdbLoad_GameSpecific1		varchar2(4) :=	'GSP1';
  cdbLoad_GameSpecific2		varchar2(4) :=	'GSP2';
 
  restype_game		number := 0;
  restype_gmer		number := 1;

  carrtype_800		number := 1;
  carrtype_x25		number := 0;

  connlog_rec		connection_log%type;
  implog_rec		import_log%type;
  global_game_uid	game.game_uid%type;
  global_game_id	game.game_id%type;
  global_game_name	game.game_name%type;
  global_box_serial_number	box_log.box_serial_number%type;
  global_box_region	box_log.box_region%type;
  
  neterrors_serverconnects	number := 0;
  neterrors_peerconnects	number := 1;


  procedure display_error (procedure_name in varchar2,
	  	 	   error_message  in varchar2,
	         	   sql_code	in number,
                 	   continue       in boolean);

procedure process_init (initrec in main_cursor%rowtype); 
procedure process_conn (connrec in main_cursor%rowtype); 
procedure process_carr (carrrec in main_cursor%rowtype); 
--This was removed for V7:
--procedure process_type (typerec in main_cursor%rowtype);
--and replaced with these:
procedure process_gameid (typerec in main_cursor%rowtype);
procedure process_opponent (typerec in main_cursor%rowtype);
--
procedure process_cras (crasrec in main_cursor%rowtype); 
procedure process_crds (crdsrec in main_cursor%rowtype); 
procedure process_crpc (crpcrec in main_cursor%rowtype); 
procedure process_game (gamerec in main_cursor%rowtype); 
procedure process_nete (neterec in main_cursor%rowtype); 
procedure process_strm (strmrec in main_cursor%rowtype); 
procedure process_cred (credrec in main_cursor%rowtype); 
procedure process_gsp1 (gsp1rec in main_cursor%rowtype); 
procedure process_gsp2 (gsp2rec in main_cursor%rowtype); 

procedure update_import_log; 
procedure insert_connlog;
procedure init_connlog;
function  get_server_uid(p_server_name varchar2) return number;
function  get_player_uid(p_name varchar2, p_phone varchar2,
 		       p_box_serial_number number, p_box_region number,
 		       p_box_player_number number, p_billing_type number) 
  	  return number;

function  get_x25_uid(p_x25_address varchar2, p_main_pop varchar2, 
		      p_alt_pop varchar2) return number;

procedure parse_phone_number (p_full_phone in varchar2, 
			      p_area_code out varchar2,
		    	      p_phone_number out varchar2);

function   get_game_uid (p_game_id in varchar2, 
 			 p_game_name in varchar2,
 			 p_game_version in number) return number;

function match_peers (in_connection_uid in number,
		      in_cookie in number,
		      in_start_time in date
		       ) return number; 

function match_results ( in_box_serial_number in number,
			 in_box_region in number,
			 in_connection_uid in number) 
			return number; 

corrupt_input		exception;	
file_already_loaded	exception;	
no_init_record		exception;
unknown_record_type	exception;
proc_failed_other	exception;

l_othererr		varchar2(30) := 'Other SQL error';
l_firstconn		boolean := true;

procedure load is

mc			main_cursor%rowtype;

commit_interval		number := 100;
records_processed	number := 0;
l_procedure_name	varchar2(30) := 'load';

begin

  open main_cursor;
  fetch main_cursor into mc;
  if main_cursor%notfound then
	raise no_init_record;
  end if;
  process_init (mc);

  loop
	fetch main_cursor into mc;
  exit when main_cursor%notfound;
	if    mc.record_type = cdbLoad_ConnectionInfo then
		process_conn(mc);
	 	implog_rec.connections := nvl(implog_rec.connections,0) + 1;
  	elsif mc.record_type = cdbLoad_ConnCarrier then
		process_carr (mc);
-- V7:  This routine 
--	elsif mc.record_type = cdbLoad_ConnType then
-- 		process_type(mc);
-- V7:  Was replaced by these two routines:
  	elsif mc.record_type = cdbLoad_ConnTypeGameID then
		process_gameid(mc);
  	elsif mc.record_type = cdbLoad_ConnTypeOpponent then
		process_opponent(mc);
  	elsif mc.record_type = cdbLoad_Crash then
		process_cras (mc);
	 	implog_rec.crashes := nvl(implog_rec.crashes,0) + 1;
  	elsif mc.record_type = cdbLoad_CrashDispatch then
		process_crds (mc);
  	elsif mc.record_type = cdbLoad_CrashPC then
		process_crpc (mc);
  	elsif mc.record_type = cdbLoad_GameResults then
		process_game (mc);
	 	implog_rec.game_results := nvl(implog_rec.game_results,0) + 1;
  	elsif mc.record_type = cdbLoad_GameErrorResults then
		process_game (mc);
	 	implog_rec.game_errors := nvl(implog_rec.game_errors,0) + 1;
  	elsif mc.record_type = cdbLoad_800Errors then
		process_nete (mc);
	 	implog_rec.x800_errors := nvl(implog_rec.x800_errors,0) + 1;
  	elsif mc.record_type = cdbLoad_X25Errors then
		process_nete (mc);
	 	implog_rec.x25_errors := nvl(implog_rec.x25_errors,0) + 1;
  	elsif mc.record_type = cdbLoad_StreamErrors then
		process_strm (mc);
  	elsif mc.record_type = cdbLoad_CreditChanges then
		process_cred (mc);
  	elsif mc.record_type = cdbLoad_GameSpecific1 then
		process_gsp1 (mc);
  	elsif mc.record_type = cdbLoad_GameSpecific2 then
		process_gsp2 (mc);
  	elsif mc.record_type = cdbLoad_Init then
		process_init (mc);
	else
              	raise unknown_record_type;
	end if;
 
	if mc.record_type = cdbLoad_ConnectionInfo then
        	records_processed := records_processed + 1;
  		if records_processed >= commit_interval then
			records_processed := 0;
			update_import_log;
			commit;
    		end if;
	end if;
  end loop;

  close main_cursor;

-- do the last connlog record
--
  if connlog_rec.connection_uid is not null then
 	insert_connlog; 
  end if;


  implog_rec.import_end_date := sysdate;
  update_import_log;
 
  commit;

exception
  when no_init_record then
     display_error (l_procedure_name, 'No INIT record in file. File is corrupt',
			0, false);
     raise;
   when unknown_record_type then
      display_error (l_procedure_name, 'unknown record type ' || mc.record_type,
		      0, false);
      rollback;
      raise;
  when file_already_loaded then
     rollback;
     raise;
  when proc_failed_other then
     rollback;
     raise;
  when corrupt_input then
     rollback;
     raise;
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);		
    rollback;
    raise;	

end load;

procedure process_init (initrec in main_cursor%rowtype) is

cursor c1 is
    select import_date 
    from   import_log
    where  file_name = implog_rec.file_name; 

l_date	date; 
l_procedure_name 	varchar2(30) := 'process_init';

begin 

  if initrec.record_num != 1 then
	return;
  end if;

  select import_uid_seq.nextval 
  into 	 implog_rec.import_uid
  from   dual;

  implog_rec.import_date  := sysdate;
  implog_rec.file_name    := initrec.flex_char1;
  implog_rec.file_version := initrec.flex_num1; 
 
  open c1;
  fetch c1 into l_date;
  if c1%found then
     close c1;
     raise file_already_loaded;
  end if; 
  close c1;

  insert into import_log (import_uid, import_date, file_name,
                          file_version)	
  values		 (implog_rec.import_uid, implog_rec.import_date,
			 implog_rec.file_name, implog_rec.file_version);
exception
  when corrupt_input then
    display_error (l_procedure_name,
		   'INIT record in middle of file. File is corrupt',
		   0, false);		
    raise;	
  when file_already_loaded then
    display_error (l_procedure_name, 'File already loaded on ' || to_char(l_date,
			'dd-mon-yy hh24:mi:ss'), 0, false);		
    raise;	
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);		
    raise proc_failed_other;	
end process_init;

procedure display_error (procedure_name in varchar2,
                 	 error_message  in varchar2,
                 	 sql_code       in number,
                 	 continue       in boolean) is
begin

    dbms_output.put_line ('Errors !');
    dbms_output.put_line ('Procedure :	'||procedure_name);
    dbms_output.put_line ('Message :	'||error_message);

    if (sql_code != 0) then
      dbms_output.put_line ('SQL Error :	'||sqlerrm(sqlcode));
    end if;

    if (not continue) then	
    	dbms_output.put_line ('Aborting...');
    else
    	dbms_output.put_line ('Continuing...');
    end if;
   
end display_error;
 

procedure update_import_log is
l_procedure_name	varchar2(30) := 'update_import_log';
begin
	update import_log
	set connections = implog_rec.connections,
		game_results = implog_rec.game_results,
		crashes = implog_rec.crashes,
		x25_errors = implog_rec.x25_errors,
		game_errors = implog_rec.game_errors,
		x800_errors = implog_rec.x800_errors,
		import_end_date = implog_rec.import_end_date
	where   import_uid = implog_rec.import_uid;

	if sql%notfound then
		raise no_data_found;
	end if;

exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);		
    raise proc_failed_other;	

end update_import_log;

procedure process_conn (connrec in main_cursor%rowtype) is
l_procedure_name 	varchar2(30) := 'process_conn';

begin

  if (l_firstconn) then
	l_firstconn := false;
	init_connlog;
  else
    	insert_connlog;
	init_connlog;
  end if;
  
  select connection_uid_seq.nextval 
  into   connlog_rec.connection_uid
  from   dual;

  if connrec.flex_char1 is not null then
    connlog_Rec.server_uid := get_server_uid (connrec.flex_char1);  
  end if;

  connlog_Rec.start_time := to_date('31-dec-69 16:00',
				    'dd-mon-yy hh24:mi') + 
				connrec.flex_num1/86400;
  connlog_rec.exit_status_code := connrec.flex_num2;
  connlog_rec.duration := connrec.flex_num3;

-- v7 changes.  This used to be a numerical value of 1 or 0 coming in.
-- Now we make it that way.

  if connrec.flex_char4 = 'New Player' then
     connlog_rec.creation_code := 0;
  end if;
  if connrec.flex_char4 = 'New Account' then
     connlog_rec.creation_code := 1;
  end if;

-- Also, we now assume that this is a mail connection until proven otherwise.

  connlog_Rec.connection_type_code := 1;

-- Furthermore, autochal_code is assumed unknown until proven different.

  connlog_Rec.autochal_code := 2;

-- end v7 changes

  if connrec.flex_char2 is not null and
     connrec.flex_char3 is not null and
     connrec.flex_num4 is not null and
     connrec.flex_num5 is not null and
     connrec.flex_num6 is not null then

     connlog_Rec.player_uid := get_player_uid (connrec.flex_char2,
				      connrec.flex_char3,
				      connrec.flex_num4,
				      connrec.flex_num5,
   				      connrec.flex_num6,
				      connrec.flex_num7);

     global_box_Serial_number := connrec.flex_num4;
     global_box_region := connrec.flex_num5;
  else
     global_box_Serial_number := null;
     global_box_region := null;
  end if;


exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);		
    raise proc_failed_other;	
end process_conn;

procedure insert_connlog is
l_procedure_name 	varchar2(30) := 'insert_connlog';
begin

connlog_rec.peer_connection_uid := null;

-- if this connlog was a master find corresonding slave
   if connlog_rec.dialed_phone_number is not null 
     and connlog_rec.cookie is not null then
     connlog_rec.peer_connection_uid := match_peers (connlog_rec.connection_uid,
						     connlog_rec.cookie,
						     connlog_rec.start_time);
-- else it's a slave, so update prev_cookie_log

   elsif connlog_rec.connection_type_code = 0 
     and connlog_rec.cookie is not null then                /* game */

     insert into prev_cookie_log
		(connection_uid, cookie, game_name, time_stamp)
     values	(connlog_rec.connection_uid, connlog_rec.cookie, 
                 global_game_name, connlog_rec.start_time);

     delete from prev_cookie_log		           /* clean up stuff */
     where time_stamp < connlog_rec.start_time - 20/1440;    /* > 20 min old */

   end if;

-- in either case, update prev_connection_log.

   declare
   cursor c1 is
	select 'x' from prev_connection_log
   	where	box_serial_number = global_box_serial_number
   	and	box_region = global_box_region
	for update of prev_connection_uid;		  
   dummy varchar2(1);
   begin
   open c1;
   fetch c1 into dummy;
   if c1%notfound then
     insert into prev_connection_log
    		(box_serial_number, box_region, prev_connection_uid)
     values	(global_box_serial_number, global_box_region, 
                 connlog_rec.connection_uid);
   else
     update prev_connection_log 
     set prev_connection_uid = connlog_rec.connection_uid
     where current of c1;
  end if;
  close c1;
  end;

--
	insert into connection_log (
	  connection_uid, import_uid, server_uid, start_time, duration,
	  exit_status_code, player_uid, creation_code, carrier_type_code,
	  x25_pop_uid, connection_type_code,game_uid, 
	  autochal_code, dialwait_code, dialed_phone_number, dialed_area_code,
	  cookie, dialed_player_uid, server_connects, peer_connects,
	  peer_connection_uid, toll_call, xbn_provider_code, xbn_billing)
	values (
	  connlog_rec.connection_uid, connlog_rec.import_uid, 
	  connlog_rec.server_uid, connlog_rec.start_time, connlog_rec.duration,
	  connlog_rec.exit_status_code, connlog_rec.player_uid, 
	  connlog_rec.creation_code, connlog_rec.carrier_type_code,
	  connlog_rec.x25_pop_uid, connlog_rec.connection_type_code, 
	  connlog_rec.game_uid, connlog_rec.autochal_code, 
	  connlog_rec.dialwait_code, connlog_rec.dialed_phone_number, 
	  connlog_rec.dialed_area_code,
	  connlog_rec.cookie, connlog_rec.dialed_player_uid, 
	  connlog_rec.server_connects, connlog_rec.peer_connects,
	  connlog_rec.peer_connection_uid, connlog_rec.toll_call,
	  connlog_rec.xbn_provider_code, connlog_rec.xbn_billing);

exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);		
    raise proc_failed_other;	
end insert_connlog;

procedure init_connlog is
l_procedure_name 	varchar2(30) := 'init_connlog';
begin
	  connlog_rec.connection_uid := null;
	  connlog_rec.import_uid := implog_rec.import_uid;
	  connlog_rec.server_uid := null;
	  connlog_rec.start_time := null;
	  connlog_rec.duration := null;
	  connlog_rec.exit_status_code := null;
	  connlog_rec.player_uid := null;
	  connlog_rec.creation_code := null;
      connlog_rec.carrier_type_code := carrtype_800;
	  connlog_rec.x25_pop_uid := null;
	  connlog_rec.connection_type_code := null;
	  connlog_rec.game_uid := null;
	  connlog_rec.autochal_code := null;
	  connlog_rec.dialwait_code := null;
	  connlog_rec.cookie := null;
	  connlog_rec.dialed_player_uid := null;
	  connlog_rec.dialed_area_code := null;
	  connlog_rec.dialed_phone_number := null;
	  connlog_rec.server_connects := null;
	  connlog_rec.peer_connects := null;
 	  connlog_rec.toll_call := null;
 	  connlog_rec.xbn_provider_code := null;
 	  connlog_rec.xbn_billing := null;
exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);		
    raise proc_failed_other;	
end init_connlog;

function  get_server_uid (p_server_name varchar2) return number is

l_procedure_name	varchar2(30) := 'get server uid';

cursor c1 is
   select server_uid 
   from   server 
   where  server_name = p_server_name;

l_server_uid	server.server_uid%type;

begin
  
  open c1;
  fetch c1 into l_server_uid;
  if c1%notfound then
    select server_uid_seq.nextval 
    into   l_server_uid
    from dual;

    insert into lookup (lookup_type, lookup_code, lookup_description)
    values ('SERVER CODES', l_server_uid, p_server_name);

  end if;
  close c1;

  return l_server_uid;
exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);	
    raise proc_failed_other;	
end get_server_uid;


function  get_player_uid (p_name varchar2, p_phone varchar2,
		       p_box_serial_number number, p_box_region number,
		       p_box_player_number number, p_billing_type number) 	
 	  return number is
l_procedure_name	varchar2(30) := 'get player uid';

l_box_uid		box_log.box_uid%type;
l_player_uid		player_log.player_uid%type;
l_area_code		box_log.area_code%type;
l_phone_number		box_log.phone_number%type;

cursor c1 is
   select box_uid, area_code, billing_type_code , rowid
   from   box_log
   where  box_serial_number = p_box_serial_number
   and    box_region 	    = p_box_region
   and    phone_number      = l_phone_number;

cursor c3 is
   select player_uid 
   from   player_log
   where  box_uid           = l_box_uid
   and    box_player_number = p_box_player_number
   and    name              = p_name;

cursor c4 is
   select player_uid 
   from   player_log
   where  box_uid           = l_box_uid
   and    box_player_number = p_box_player_number
   and    name              is null;

cursor o2 is
   select max(player_uid) 
   from   player_log
   where  box_uid           = l_box_uid
   and    box_player_number = p_box_player_number;

d_area_code 		box_log.area_code%type;
d_billing_type_code  	box_log.billing_type_code%type;
l_rowid			rowid;


begin

  parse_phone_number (p_phone, l_area_code, l_phone_number);

  open c1;
  fetch c1 into l_box_uid, d_area_code, d_billing_type_code, l_rowid;
  if c1%notfound then
      select box_uid_seq.nextval
      into   l_box_uid
      from dual;

      insert into box_log (box_uid, phone_number, area_code,
                       box_Serial_number, box_region, 
		       billing_type_code)
      values (l_box_uid, l_phone_number, l_area_code,
              p_box_serial_number, p_box_region, 
              p_billing_type); 
  else
      if d_area_code != nvl(l_area_code, d_area_code) or
         d_billing_type_code != nvl(p_billing_type, d_billing_type_code) then
         update box_log set area_code = l_area_code,
                        billing_type_code = p_billing_type
         where rowid = l_rowid;
  end if;

  end if;

  close c1;

if p_name is not null then
  open c3;
  fetch c3 into l_player_uid;
  if c3%notfound then
    open c4;
    fetch c4 into l_player_uid;
    if c4%notfound then
      select player_uid_seq.nextval
      into   l_player_uid
      from dual;

      insert into player_log (player_uid, box_uid, box_player_number, name)
      values (l_player_uid, l_box_uid, p_box_player_number, p_name);
    else    -- opponent info exists
      update player_log set name = p_name
      where player_uid = l_player_uid;
    end if;
    close c4;
  end if;
  close c3;

else    -- called from opponent info

  open o2;
  fetch o2 into l_player_uid;
  if o2%notfound then
      select player_uid_seq.nextval
      into   l_player_uid
      from dual;

      insert into player_log (player_uid, box_uid, box_player_number, name)
      values (l_player_uid, l_box_uid, p_box_player_number, p_name);
  end if;

end if;


return l_player_uid;

exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	
end get_player_uid;

procedure process_carr (carrrec in main_cursor%rowtype) is

l_procedure_name	varchar2(30) := 'process carr';

begin

  if carrrec.flex_char1 is null then
    connlog_rec.carrier_type_code := carrtype_800;
  else
    connlog_rec.carrier_type_code := carrtype_x25;
  end if;

  if carrrec.flex_char1 is not null and 
     carrrec.flex_char2 is not null and
     carrrec.flex_char3 is not null then 
     connlog_rec.x25_pop_uid := get_x25_uid (carrrec.flex_char1, 
				  carrrec.flex_char2, carrrec.flex_char3);
  end if;

exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	
end process_carr;


function  get_x25_uid(p_x25_address varchar2, p_main_pop varchar2, 
		      p_alt_pop varchar2) 
return number is

l_procedure_name	varchar2(30) := 'get x25 uid';
l_x25_pop_uid	x25_pop.x25_pop_uid%type;

cursor c1 is
   select x25_pop_uid 
   from   x25_pop 
   where  x25_pop_address = p_x25_address
   and    main_number = p_main_pop
   and    alt_number = p_alt_pop;

begin
  
  open c1;
  fetch c1 into l_x25_pop_uid;
  if c1%notfound then
    select x25_pop_uid_seq.nextval 
    into   l_x25_pop_uid
    from dual;

    insert into lookup (lookup_type, lookup_code, flex_char_1, 
			flex_char_2, flex_char_3)
    values ('X25 CODES', l_x25_pop_uid, p_x25_address, p_main_pop, p_alt_pop);

  end if;
  close c1;

  return l_x25_pop_uid;
exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	
end get_x25_uid;

procedure process_gameid (typerec in main_cursor%rowtype) is 

l_procedure_name 	varchar2(30) := 'process gameid';

begin

  connlog_Rec.connection_type_code := typerec.flex_num1; -- always 0.

  global_game_name := typerec.flex_char2;

  if typerec.flex_char1 is not null and
     typerec.flex_char2 is not null and
     typerec.flex_num2 is not null then
     connlog_Rec.game_uid := get_game_uid (typerec.flex_char1, 
 					typerec.flex_char2,
 					typerec.flex_num2);
  end if;

  if typerec.flex_char3 = 'Automatch' then
    connlog_Rec.autochal_code := 0;
  else -- 'Challenge'
    connlog_Rec.autochal_code := 1;
  end if;

exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	
end process_gameid; 

procedure process_opponent (typerec in main_cursor%rowtype) is

l_procedure_name 	varchar2(30) := 'process opponent';

begin

  connlog_rec.dialwait_code := typerec.flex_num4;
  connlog_rec.cookie        := typerec.flex_num5;

  if typerec.flex_char3 is not null and 
     typerec.flex_num6 is not null and
     typerec.flex_num7 is not null and
     typerec.flex_num8 is not null then
     
     connlog_rec.dialed_player_uid :=  
		       get_player_uid(null, typerec.flex_char3,
		       typerec.flex_num6, typerec.flex_num7,typerec.flex_num8,
		       null); 
     parse_phone_number (typerec.flex_char3, connlog_rec.dialed_area_code, 
		      connlog_rec.dialed_phone_number);

     if typerec.flex_char4 = 'toll' then
        connlog_rec.toll_call := 1;
     elsif typerec.flex_char4 = 'local' then
        connlog_rec.toll_call := 0;
     end if;

     if typerec.flex_char5 = 'Sprint' then
        connlog_rec.xbn_provider_code := 0;
     elsif typerec.flex_char5 = 'MCI' then
        connlog_rec.xbn_provider_code := 1;
     end if;

     if typerec.flex_char6 = 'No' and typerec.flex_char7 = 'Yes'
        then connlog_rec.xbn_billing := 0;
     elsif typerec.flex_char6 = 'Yes' and typerec.flex_char7 = 'No'
        then connlog_rec.xbn_billing := 1;
     elsif typerec.flex_char6 = 'Yes' and typerec.flex_char7 = 'Yes'
        then connlog_rec.xbn_billing := 2;
     end if;

 end if;

exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	
end process_opponent; 

procedure parse_phone_number (p_full_phone in varchar2, 
			      p_area_code out varchar2,
		    	      p_phone_number out varchar2) is
begin
if length (p_full_phone) > 8 then
  p_area_code := substr (p_full_phone, 1, 3);
  p_phone_number := substr (p_full_phone, 5, 3) || 
		    substr (p_full_phone, 9, 4); 
else
  p_phone_number := substr (p_full_phone, 1, 3) || 
		    substr (p_full_phone, 5, 4); 
end if;
 
end parse_phone_number;
 
function   get_game_uid (p_game_id in varchar2, 
 			 p_game_name in varchar2,
 			 p_game_version in number) 
	return number is

l_procedure_name	varchar2(30)	:= 'get game uid';

l_game_uid		game.game_uid%type;

cursor c1 is
  select game_uid from game
  where  game_id = p_game_id
  and    game_name = p_game_name
  and    game_version = p_game_version;

cursor c2 is
  select game_uid from game
  where  game_id = p_game_id
  and    game_name = p_game_name
  and    game_version is null;

begin

if p_game_version is not null then
  open c1;
  fetch c1 into l_game_uid;
  if c1%notfound then

    select game_uid_seq.nextval
    into   l_game_uid 
    from dual;

    insert into game (game_uid, game_name, game_version, game_id)
    values (l_game_uid, p_game_name, p_game_version, p_game_id);

  end if;
  close c1;
else
  open c2;
  fetch c2 into l_game_uid;
  if c2%notfound then

    select game_uid_seq.nextval
    into   l_game_uid 
    from dual;

    insert into game (game_uid, game_name, game_version, game_id)
    values (l_game_uid, p_game_name, p_game_version, p_game_id);

  end if;
  close c2;
end if;

return l_game_uid;

exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	
end get_game_uid;


procedure process_cras (crasrec in main_cursor%rowtype) is

l_procedure_name 	varchar2(30) := 'process cras';

begin

  insert into crash_log(
  connection_uid, d0, d1, d2, d3, d4, d5, d6, d7, a0,
  a1, a2, a3, a4, a5, a6, a7, bus_error_mode, bus_error_address,
  bus_error_instruction, status_register, exception_pc, exception_code,
  stability_pc, prev_entry, os_state, stack_low_water,
  startup_flags, box_state, last_box_state, box_serial_number_Set,
  box_region_Set, box_serial_number_cold, box_region_cold,
  box_serial_number_warm, box_region_warm)
  values
  (connlog_rec.connection_uid, crasrec.flex_char1, 
   crasrec.flex_char2, crasrec.flex_char3, 
   crasrec.flex_char4, crasrec.flex_char5, crasrec.flex_char6, 
   crasrec.flex_char7, crasrec.flex_char8,      
   crasrec.flex_char9, crasrec.flex_char10, crasrec.flex_char11, 
   crasrec.flex_char12, crasrec.flex_char13, crasrec.flex_char14,  
   crasrec.flex_char15, crasrec.flex_char16, crasrec.flex_char27, 
   crasrec.flex_char28, crasrec.flex_char29,      
   crasrec.flex_char17, crasrec.flex_char18, crasrec.flex_char19, 
   crasrec.flex_char20,      
   crasrec.flex_char21, crasrec.flex_char22, crasrec.flex_char23, 
   crasrec.flex_char24, crasrec.flex_char25,      
   crasrec.flex_char26, crasrec.flex_num2, crasrec.flex_num3, 
   crasrec.flex_num4, crasrec.flex_num5, crasrec.flex_num6,
   crasrec.flex_num7);      
         
exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	
end process_cras;

         
procedure process_crds (crdsrec in main_cursor%rowtype) is

l_procedure_name 	varchar2(30) := 'process crds';

begin

insert into crash_log_dispatch (connection_uid, counter, dispatch_number,
		                function_name)
values (connlog_rec.connection_uid, crdsrec.flex_num1, crdsrec.flex_num2,
		crdsrec.flex_char1);
 
exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	
end process_crds;

         
procedure process_crpc (crpcrec in main_cursor%rowtype) is

l_procedure_name 	varchar2(30) := 'process crpc';

begin

insert into crash_log_pc_call (connection_uid, counter, called_from_pc)
values (connlog_rec.connection_uid, crpcrec.flex_num1, crpcrec.flex_char1);
 
exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	
end process_crpc;

procedure process_game (gamerec in main_cursor%rowtype) is

l_procedure_name 	varchar2(30) := 'process game';
l_result_type_code	game_result.result_type_code%type;
l_game_uid		game.game_uid%type;
l_master_connection_uid game_result.master_connection_uid%type := null;
begin

  if gamerec.record_type = cdbLoad_GameResults then
 	l_result_type_code := restype_game;
  else
        l_result_type_code := restype_gmer;
  end if;      

  if gamerec.flex_char1 is not null and gamerec.flex_char2 is not null then
     l_game_uid := get_game_uid (gamerec.flex_char1, gamerec.flex_char2, null);
  end if;

  global_game_uid := l_game_uid;
  global_game_id := gamerec.flex_char1;

  l_master_connection_uid := match_results ( 
			    global_box_serial_number,
			    global_box_region,
			    connlog_rec.connection_uid); 

  insert into game_result (connection_uid, result_type_code, game_uid,
                            gameres_size, game_error,
			    error_location, connect_phase_error, play_time,
			    local1_result, local2_result, remote1_result,
			    remote2_result, data_pointer, data_size, 
			    num_local_players, local_game_error, 
		  	    error_recovers, checksum_errors, timeouts,
			    frame_errors, overrun_errors, master_connection_uid)
  values 		   (connlog_rec.connection_uid, l_result_type_code,
			    l_game_uid, gamerec.flex_num2, 
			    gamerec.flex_num3, gamerec.flex_num4, 
			    gamerec.flex_num5, gamerec.flex_num6, 
			    gamerec.flex_num7, gamerec.flex_num8, 
			    gamerec.flex_num9, gamerec.flex_num10, 
			    gamerec.flex_num11, gamerec.flex_num12, 
			    gamerec.flex_num13, gamerec.flex_num14, 
			    gamerec.flex_num15, gamerec.flex_num16, 
			    gamerec.flex_num17, gamerec.flex_num18, 
			    gamerec.flex_num19, l_master_connection_uid);
			   

exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	
end process_game;


procedure process_nete (neterec in main_cursor%rowtype) is

l_procedure_name 	varchar2(30) := 'process nete';
l_carrier_type_code	carrier_type.carrier_type_code%type;

begin

  if neterec.record_type = cdbLoad_800Errors then
    l_carrier_type_code := carrtype_800;
  else
    l_carrier_type_code := carrtype_x25;
  end if;

  if neterec.flex_num1 = neterrors_serverconnects then	
	connlog_rec.server_connects := nvl(connlog_rec.server_connects,0) + 
					neterec.flex_num2;
  elsif neterec.flex_num1 = neterrors_peerconnects then	
	connlog_rec.peer_connects := nvl(connlog_rec.peer_connects,0) + 
					neterec.flex_num2;
  else
     insert into connection_net_error (connection_uid, carrier_type_code,
				    net_error_code, error_number)
     values 			   (connlog_rec.connection_uid, 
				    l_carrier_type_code, neterec.flex_num1,
				    neterec.flex_num2);
  end if;
             
exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	
end process_nete;

procedure process_strm (strmrec in main_cursor%rowtype) is

l_procedure_name 	varchar2(30) := 'process strm';

begin

  insert into connection_stream_error (connection_uid, version,
				    check_error, open_error, last_opcode)
  values 			   (connlog_rec.connection_uid, 
				    strmrec.flex_num1, strmrec.flex_num2,
				    strmrec.flex_num3, strmrec.flex_num4);
             
exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	
end process_strm;

procedure process_cred (credrec in main_cursor%rowtype) is

l_procedure_name 	varchar2(30) := 'process cred';

begin

  insert into credit_change_log (connection_uid, credit_change_code) 
  values 			   (connlog_rec.connection_uid, 
				    credrec.flex_num1);
             
exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	
end process_cred;

procedure process_gsp1 (gsp1rec in main_cursor%rowtype) is

l_procedure_name 	varchar2(30) := 'process gsp1';

begin

  insert into game_specific_result 
	(connection_uid, game_uid, game_id, incomplete_code, gameres_size,
	 flex_char1, flex_char2, flex_char3, flex_char4, flex_char5,
	 flex_char6, flex_char7, flex_char8, flex_char9, flex_char10,
	 flex_char11, flex_char12, flex_char13, flex_char14, flex_char15,
	 flex_char16, flex_char17, flex_char18, flex_char19, flex_char20,
	 flex_char21, flex_char22, flex_char23, flex_num1) 
  values (connlog_rec.connection_uid, global_game_uid, global_game_id,
	 gsp1rec.flex_num1, gsp1rec.flex_num2,
	 gsp1rec.flex_char1, gsp1rec.flex_char2, 
	 gsp1rec.flex_char3, gsp1rec.flex_char4, gsp1rec.flex_char5,
	 gsp1rec.flex_char6, gsp1rec.flex_char7, 
	 gsp1rec.flex_char8, gsp1rec.flex_char9, gsp1rec.flex_char10,
	 gsp1rec.flex_char11, gsp1rec.flex_char12, 
	 gsp1rec.flex_char13, gsp1rec.flex_char14, gsp1rec.flex_char15,
	 gsp1rec.flex_char16, gsp1rec.flex_char17, 
	 gsp1rec.flex_char18, gsp1rec.flex_char19, gsp1rec.flex_char20,
	 gsp1rec.flex_char21, gsp1rec.flex_char22, 
	 gsp1rec.flex_char23, gsp1rec.flex_num3); 
             
exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	
end process_gsp1;

procedure process_gsp2 (gsp2rec in main_cursor%rowtype) is

l_procedure_name 	varchar2(30) := 'process gsp2';

begin

  insert into game_specific_result2 
	 (connection_uid, game_uid, game_id, counter, flex_char1)
  values (connlog_rec.connection_uid, global_game_uid, global_game_id,
	  gsp2rec.flex_num1, gsp2rec.flex_char1);
             
exception
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	
end process_gsp2;


function match_peers (in_connection_uid in number,
		      in_cookie in number,
		      in_start_time in date
		       ) return number is

slave_connection_uid 	connection_log.connection_uid%TYPE;
l_procedure_name	varchar2(30) := 'match_peers';
l_rowid			rowid;

begin

  slave_connection_uid := null;

  select	connection_uid,			/* find the slave connection */
		rowid
  into		slave_connection_uid,
		l_rowid
  from		prev_cookie_log
  where		cookie = in_cookie
  and           rownum = 1;

  if slave_connection_uid is not null then

    update	connection_log				     /* update slave */ 
    set		peer_connection_uid = in_connection_uid    
    where	connection_uid = slave_connection_uid;

    delete 	from prev_cookie_log			     /* clean up */
    where	rowid = l_rowid;

  end if;

  return slave_connection_uid;

exception
  when NO_DATA_FOUND then 
	slave_connection_uid := null;
        return slave_connection_uid;
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	

end match_peers;
function match_results ( in_box_serial_number in number,
			 in_box_region in number,
			 in_connection_uid in number) 
			return number is

/* update master_connection_uid in each game result so master_connection_uid 
   points to the connection which initialized the game in the first place. */

cm_connection_uid connection_log.connection_uid%TYPE := null;

l_procedure_name varchar2(30) := 'match results';

  begin

    select	prev_connection_uid
    into	cm_connection_uid
    from	prev_connection_log
    where	box_serial_number = in_box_serial_number
    and		box_region = in_box_region
    and		rownum = 1;

  return cm_connection_uid;

exception

  when NO_DATA_FOUND then 
    cm_connection_uid := null;
    return cm_connection_uid;
  when others then
    display_error (l_procedure_name, l_othererr, sqlcode, false);
    raise proc_failed_other;	

end match_results;

end dbLoad_package;
/
