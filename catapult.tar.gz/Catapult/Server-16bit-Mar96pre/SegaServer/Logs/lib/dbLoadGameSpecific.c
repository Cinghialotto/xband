#ifndef lint
static char *sccsid = "$Id: dbLoadGameSpecific.c,v 1.2 1995/05/26 23:01:21 jhsia Exp $";
#endif /* lint */

/*
 * Copyright: @ 1994 Catapult Entertainment Inc., all rights reserved
 *
 * $Log: dbLoadGameSpecific.c,v $
 * Revision 1.2  1995/05/26  23:01:21  jhsia
 * switched to rcs keywords
 *
 */
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include "ServerCore.h"
#include "Server_Log.h"
#include "Server_OSNumbers.h"
#include "ServerDataBase.h"
#include "../include/dbLoadGameSpecific.h"

//
// Known Sega Genesis games (see Common_GameInfo.c for definitive list):
//
//	0x00000000	(game patch not entered)
//	0x0000000?	(test patch, could be anything)
//	0x8f6b9f70	NHL Hockey '95
//	0x39677bdb	NBA JAM	(new)
//	0xa61b53f8	NHL Hockey '94
//	0xab6348e9	Mortal Kombat
//	0xc4cddf0c	Mortal Kombat II
//	0xe30c296e	NBA JAM (old)
//	0x31ed8123	Madden '95
//	0x3fed23f2	Road Rash 3 (beta)
//
static GameSpecificJumpTable segaGameSpecific[] = {
	{ 0xe30c296e, dbDumpJamsSendQ, NULL,
		GetJamsNumWins, CheckJamsScorable, JamsPossiblyLosing, CheckJamsReset },
	{ 0x39677bdb, dbDumpJamsSendQ, NULL,
		GetJamsNumWins, CheckJamsScorable, JamsPossiblyLosing, CheckJamsReset },
	{ 0xab6348e9, NULL, DumpMKResult,
		MatchGetNumWins, NULL, NULL, CheckMKReset },
	{ 0xc4cddf0c, dbDumpMK2SendQ, NULL,
		MatchGetNumWins, NULL, NULL, CheckMK2Reset },
	{ 0xa61b53f8, NULL, DumpNHLResult,
		GenericGetNumWins, NULL, NULL, NULL },
	{ 0x8f6b9f70, NULL, DumpNHLResult,
		GenericGetNumWins, NULL, NULL, CheckNHLReset },
	{ 0x31ed8123, NULL, DumpMaddenResult,
		GenericGetNumWins, NULL, MaddenPossiblyLosing, NULL /*CheckMaddenReset*/ },
	{ 0x3fed23f2, NULL, NULL,
		GenericGetNumWins,	NULL, NULL, NULL },
};


//
// Dump the contents of a kGameResultDataDBID SendQ item.  The first word
// of the sendQ stuff must be the gameID.
//
int
dbDumpGameResultSendQ(long platformID, const unsigned char *data, 
			const long size)
{
	GameSpecificJumpTable *gsjtp;
	long gameID;

	gameID = *((long *) data);
	if ((gsjtp = LookupGameSpecific(platformID, gameID)) == NULL ||
		(gsjtp->displaySendQ == NULL))
	{
		printf(stderr, "  No format routine for 0x%.8lx, dumping hex\n", gameID);
	} else {
		(*gsjtp->displaySendQ)(data, size);
	}
	return (kNoError);
}

//
// Look up a game in the gameSpecific table for the appropriate platform.
//
static GameSpecificJumpTable *
LookupGameSpecific(const long platformID, const long gameID)
{
	switch (platformID) {
	case kPlatformGenesis:
		return (sega_LookupGameSpecific(gameID));
//	case kPlatformSNES:
//		return (snes_LookupGameSpecific(gameID));
	default:
		fprintf(stderr, "GLITCH: unknown platform 0x%.8lx in LookupGameSpecific\n", platformID);
		return (NULL);
	}
	/*NOTREACHED*/
}

//
// Look up a game.
//
// Returns a pointer to the appropriate gameSpecific entry.
//
static GameSpecificJumpTable *
sega_LookupGameSpecific(const long gameID)
{
	int i;

	for (i = 0; i < NELEM(segaGameSpecific); i++) {
		if (segaGameSpecific[i].gameID == gameID)
			return (&segaGameSpecific[i]);
	}
	return (NULL);
}

/*     printfStats.c
       By Steve Perlman 8/23/94
*/


//
// Determine #of wins for each JAMs player.
//
// Assume 10 points are available for the entire game.  The points are
// divided between winner and loser as follows:
//
// Solid victory (12+ points):		10-0
// Strong victory (5-11 points):	9-1
// Narrow victory (1-4 points):		8-2
// Tie game (0 points):				5-5
//
static int
GetJamsNumWins(const NewGameResult *gameResult, long *p1wins, long *p2wins)
{
	long pointsFor, pointsAgainst;
	long delta, win, lose;

	pointsFor = gameResult->localPlayer1Result + gameResult->localPlayer2Result;
	pointsAgainst = gameResult->remotePlayer1Result + gameResult->remotePlayer2Result;

	delta = (pointsFor > pointsAgainst) ?
		pointsFor - pointsAgainst : pointsAgainst - pointsFor;
	if (delta >= 12) {
		win = 10;
		lose = 0;
	} else if (delta >= 5) {
		win = 9;
		lose = 1;
	} else if (delta >= 1) {
		win = 8;
		lose = 2;
	} else {
		win = 5;
		lose = 5;
	}

	if (pointsFor > pointsAgainst) {
		*p1wins = win;
		*p2wins = lose;
	} else {
		*p1wins = lose;
		*p2wins = win;
	}

	return (kNoError);
}

//
// Given a game with no errors or other abnormalities, determine if
// it should actually be recorded.
//
// Only games that run to completion (time == 4 or 5) should be used
// for rankings.  People who set single-quarter mode should not receive
// anything.
//
// Returns kNoError if game should be scored, kFucked otherwise.
//
static int
CheckJamsScorable(const ServerState *state, const NewGameResult *gameResult)
{
	if (gameResult == NULL)
		return (kFucked);		// shouldn't happen

	if (gameResult->playTime < 4 || gameResult->playTime > 6) {
		printf("game not scored\n", gameResult->playTime);
//		if (gameResult->playTime == 9) {
//			SendDialog((ServerState *)state, "Your previous game of NBA Jam only lasted one quarter, because a special code was used.  These games do not affect your Stats.", true);	/* DIALOG */
//		}
		return(kFucked);
	}

	return (kNoError);
}

//
// Determine whether or not a JAMs player was losing.  We don't want them
// to get away with stuff by shooting a 3-pointer and then hitting reset
// or calling themselves.
//
// Returns kNoError if he was probably winning, kFucked if he was possibly
// losing.
//
static int
JamsPossiblyLosing(const ServerState *state, const NewGameResult *gameResult)
{
	long local, remote;

	local = gameResult->localPlayer1Result + gameResult->localPlayer2Result;
	remote = gameResult->remotePlayer1Result + gameResult->remotePlayer2Result;

	if (local <= (remote + 3))
		return (kFucked);

	return (kNoError);
}

//
// Criteria for determining whether or not the reset was intentional:
//
//	- no valid gameResult (if we got those, we can score it)
//	- localGameError == 0
//	- playTime > 0
//	- local score <= remote score (being within 3 counts; no resets during
//	  last-minute 3-pointers!!)
//	- no crash record
//	- frameCount < 2*gameFrames
//
// If the game had started and you weren't winning, it counts as a "maybe"
// reset, which has no effect other than a counter being incremented.
//
static int
CheckJamsReset(const ServerState *state, const NewGameResult *gameResult,
	const NewGameResult *gameErrorResult)
{
	long local, remote;
	QItem *item, *jamsItem;
	JamsStats *j;
	int i;

	if (gameErrorResult == NULL) {
		printf("  Odd: reset detected in gameResult, NO gameErrorResult\n");
		return (kNoError);
	} else {
		if (gameResult != NULL) {
			if ((gameResult->playTime >= 4 && gameResult->playTime <= 5) ||
				gameResult->playTime == 8)
			{
				// Probably reset in a post-"do you want to playl again" match.
				// No stats, no foul.
				//
				printf("  Found gameResult with valid playTime, assuming OK.\n");
				return (kNoError);
			}
		}

/*
	Removed 94/11/20
		// -1  == game not started
		//  0  == in first quarter or fields not yet initialized to -1
		// 1-4 == end of that quarter
		// 5,6 == end of overtime1 or overtime2
		//  8  == in first quarter, 1qtr mode
		//  9  == end of game, 1qtr mode
		if (gameErrorResult->playTime <= 0) {
			printf("  gameErrorResult->playTime <= 0, OK.\n");
			return (kNoError);
		}
*/
		// If game hasn't started, zero the score out.  Otherwise we get
		// wacky stuff like -65513.
		//
		// This violation of const declarations brought to you by the
		// number 7 and the letter P.
		//
		if (gameErrorResult->playTime == -1) {
			gameErrorResult->localPlayer1Result =
				gameErrorResult->localPlayer2Result =
				gameErrorResult->remotePlayer1Result =
				gameErrorResult->remotePlayer2Result = 0;
		}

		local = gameErrorResult->localPlayer1Result +
			gameErrorResult->localPlayer2Result;
		remote = gameErrorResult->remotePlayer1Result +
			gameErrorResult->remotePlayer2Result;

/*
	Removed 94/11/21
		if (local == -1 && remote == -1) {
			printf("  Both scores were -1, OK.\n");
			return (kNoError);
		}
*/

		if ((gameErrorResult->playTime) >= 0 && (local > remote + 3)) {
			printf("  Player was ahead by at least 4, OK.\n");
			return (kResetMaybe);
		}

		if (gameErrorResult->localGameError) {
			printf("  gameErrorResult->localGameError!=0, probably OK\n");
			return (kResetMaybe);
		}

		// Look for a crashRecord.  This is iffy... they could do something
		// to deliberately crash their machine.
		//
		jamsItem = NULL;
		for (i = 0; i < state->sendQData.count; i++) {
			item = &state->sendQData.items[i];

			if (item->theID == kRestartInfoType) {
				printf("  Found a crash record, probably OK.\n");
				return (kResetMaybe);
			}
			if (item->theID == kGameResultDataDBID)
				jamsItem = item;
		}

		if (jamsItem == NULL) {
			printf("  Odd: no Jams SendQ item, skipping test.\n");
				return (kNoError);
		} else {
			j = (JamsStats *)jamsItem->data;
			if (j->frameCount > j->gameFrames * 2) {
				printf("  Found frameCount > 2*gameFrames, OK.\n");
				return (kNoError);
			}
		}
	}

	// If we get all the way down here, we didn't catch on any of the tests.
	//
	return (kResetDefinite);
}


// ===========================================================================
//		Mortal Kombat (0xab6348e9)
// ===========================================================================

static int
DumpMKResult(const NewGameResult *gameResult)
{
	MKResults *mkresults = (MKResults *)gameResult->gameReserved;

	printf("Mortal Kombat stuff:\n");
	printf("  frameDelay: %-5u    totalVBLs: %-5u\n",
		mkresults->frameDelay, mkresults->totalVBLs);
	printf("  skippedVBLs: %-5u   mkState: 0x%.4x\n",
		mkresults->skippedVBLs, mkresults->mkState);
	printf("  checkLineResult: %-5d\n",
		mkresults->checkLineResult);
}

//
// Criteria for determining whether or not the reset was intentional:
//
//	- localGameError != 0
//	- mkState != 0 (make sure it got set)
//	- mkState high byte == 0
//
static int
CheckMKReset(const ServerState *state, const NewGameResult *gameResult,
	const NewGameResult *gameErrorResult)
{
	MKResults *mkresults;
	QItem *item;
	long local, remote;
	int i;

	if (gameErrorResult == NULL) {
		printf("  Odd: reset detected in gameResult, NO gameErrorResult\n");
		return (kNoError);
	} else {
		mkresults = (MKResults *)gameErrorResult->gameReserved;

		if (mkresults->mkState == 0) {
			printf("  mkresults->mkState==0, mkstate not initialized, OK.\n");
			return (kNoError);
		}

		local = gameErrorResult->localPlayer1Result +
			gameErrorResult->localPlayer2Result;
		remote = gameErrorResult->remotePlayer1Result +
			gameErrorResult->remotePlayer2Result;
		if (local > remote) {
			printf("  Player was winning, OK.\n");
			return (kNoError);
		}
		if (!local && !remote) {
			printf("Score was 0-0, probably OK.\n");
			return (kResetMaybe);
		}

		if (gameErrorResult->localGameError != 0) {
			printf("  gameErrorResult->localGameError!=0, probably OK.\n");
			return (kResetMaybe);
		}

		if ((mkresults->mkState & 0xff00) != 0) {
			printf("  According to mkState we were handling err, probably OK.\n");
			return (kResetMaybe);
		}

		for (i = 0; i < state->sendQData.count; i++) {
			item = &state->sendQData.items[i];

			if (item->theID == kRestartInfoType) {
				printf("  Found a crash record, probably OK.\n");
				return (kResetMaybe);
			}
		}

		//printf(//	"Found mkState = 0x%.4lx (&->0x%.4lx); DEBUG:\n",
		//		mkresults->mkState, mkresults->mkState & 0xff00);
		//DumpMKResult(gameErrorResult);
		//printf("--- end DEBUG\n");
	}

	return (kResetDefinite);
}


// ===========================================================================
//		Mortal Kombat II (0xc4cddf0c)
// ===========================================================================


//
// Criteria for determining whether or not the reset was intentional:
//
//	- no valid gameResult (if we got those, we can score it)
//	- scores not zero
//	- my wins <= his wins (including match scores, yay!)
//	- no crash record
//
// If the game had started and you weren't winning, it counts as a "maybe"
// reset, which has no effect other than a counter being incremented.
//
static int
CheckMK2Reset(const ServerState *state, const NewGameResult *gameResult,
	const NewGameResult *gameErrorResult)
{
	long local, remote;
	QItem *item, *mk2Item;
	MK2SendQ *mkq;
	int i;

	if (gameErrorResult == NULL) {
		printf("  Odd: reset detected in gameResult, NO gameErrorResult\n");
		return (kNoError);
	} else {
		// Look for a crashRecord.  This is iffy... they could do something
		// to deliberately crash their machine.
		//
		// Pull out the MK2 item while we're here.
		//
		mk2Item = NULL;
		for (i = 0; i < state->sendQData.count; i++) {
			item = &state->sendQData.items[i];

			if (item->theID == kRestartInfoType) {
				printf("  Found a crash record, probably OK.\n");
				return (kResetMaybe);
			}
			if (item->theID == kGameResultDataDBID)
				mk2Item = item;
		}
		if (mk2Item == NULL) {
			printf("  Odd: no MK2 SendQ item, skipping test.\n");
				return (kNoError);
		}
		mkq = (MK2SendQ *)mk2Item->data;

		local = gameErrorResult->localPlayer1Result +
			gameErrorResult->localPlayer2Result;
		remote = gameErrorResult->remotePlayer1Result +
			gameErrorResult->remotePlayer2Result;

		if (!local && !remote && !mkq->p1RoundWins && !mkq->p2RoundWins) {
			printf("  All scores were 0, OK.\n");
			return (kNoError);
		}

		if (mkq->inResync) {
			printf("  Player was in resync, probably OK.\n");
			return (kResetMaybe);
		}

		// If the round scores were even, factor in the match results
		// current round (which will be either 1 or 0 for each player).
		//
		if (local == remote) {
			if (mkq->isLeader) {
				local += mkq->p1RoundWins;		// leader == master == p1
				remote += mkq->p2RoundWins;
			} else {
				local += mkq->p2RoundWins;		// !leader == slave == p2
				remote += mkq->p1RoundWins;
			}
		}

		// Now compare the adjusted round scores.  If we're at 4-4 with 1-1,
		// we'll be tied, so nail them when tied as well as when losing.
		//
		if (local > remote) {
			printf("  Player was winning, OK.\n");
			return (kNoError);
		}
	}

	// If we get all the way down here, we didn't catch on any of the tests.
	//
	return (kResetDefinite);
}


// ===========================================================================
//		NHL Hockey '94 (0xa61b53f8) and NHL Hockey '95 (0x8f6b9f70)
// ===========================================================================


static int
DumpNHLResult(const NewGameResult *gameResult)
{
	NHLResults *nhlresults = (NHLResults *)gameResult->gameReserved;

	printf("NHL Hockey '94/'95 stuff:\n");
	printf("  stage: 0x%x  gameState: 0x%x  frameDelay: 0x%x\n",
		nhlresults->stage, nhlresults->gameState, nhlresults->frameDelay);
	printf("  gtErrorRecovers: 0x%x  gtRecovered: 0x%x\n",
		nhlresults->gtErrorRecovers, nhlresults->gtRecovered);
	printf("  totalVBLs: 0x%x  skippedVBLs: 0x%x\n",
		nhlresults->totalVBLs, nhlresults->skippedVBLs);
	printf("  controlChksum: 0x%x  controlXOR: 0x%x\n",
		nhlresults->controlChksum, nhlresults->controlXOR);
	printf("  crcErrors: 0x%x  checklineErr: 0x%x\n",
		nhlresults->crcErrors, nhlresults->checklineErr);
	printf("  callWaits: 0x%x  remoteCallWaits: 0x%x\n",
		nhlresults->callWaits, nhlresults->remoteCallWaits);
	printf("  connectLost: 0x%x  errTimeouts: 0x%x\n",
		nhlresults->connectLost, nhlresults->errTimeouts);

	return (kNoError);
}

//
// Criteria for NHL evil reset:
//	- localGameError is zero
//	- either game hasn't started, or game has started and player is losing
//	- no crash record
//
static int
CheckNHLReset(const ServerState *state, const NewGameResult *gameResult,
	const NewGameResult *gameErrorResult)
{
	long local, remote;
	QItem *item;
	int i;

	if (gameErrorResult == NULL) {
		printf("  Odd: reset detected in gameResult, NO gameErrorResult\n");
		return (kNoError);
	} else {
		local = gameErrorResult->localPlayer1Result +
			gameErrorResult->localPlayer2Result;
		remote = gameErrorResult->remotePlayer1Result +
			gameErrorResult->remotePlayer2Result;

		if (gameErrorResult->localGameError != 0) {
			printf("  Reset while in Error Recover, OK.\n");
			return (kNoError);					
		}
		
	   if ((gameErrorResult->playTime) >= 0 && (local > remote)) {
			printf("  Player was ahead by at least 1, OK.\n");
			return (kResetMaybe);
		}
		// Look for a crashRecord.  This is iffy... they could do something
		// to deliberately crash their machine.
		//
		for (i = 0; i < state->sendQData.count; i++) {
			item = &state->sendQData.items[i];

			if (item->theID == kRestartInfoType) {
				printf("  Found a crash record, probably OK.\n");
				return (kResetMaybe);
			}
		}
	}

	// If we get all the way down here, we didn't catch on any of the tests.
	//
	return (kResetDefinite);
}



// ===========================================================================
//		Madden '95 (0x31ed8123)
// ===========================================================================


static int
DumpMaddenResult(const NewGameResult *gameResult)
{
	MaddenResults *maddenres = (MaddenResults *)gameResult->gameReserved;

	printf("Madden '95 stuff:\n");
	printf("  Quarter#: %d, Quarter Index: %d, Home#: %d, Visitor#: %d\n",
		maddenres->quarter, maddenres->quarterLen, maddenres->homeTeam,
		maddenres->visitTeam);

	printf("Game Delays: [%d %d %d %d %d %d %d %d]\n",
			maddenres->delaysPerQuarter[0], maddenres->delaysPerQuarter[1],
			maddenres->delaysPerQuarter[2], maddenres->delaysPerQuarter[3],
			maddenres->delaysPerQuarter[4], maddenres->delaysPerQuarter[5],
			maddenres->delaysPerQuarter[6], maddenres->delaysPerQuarter[7]);

	printf("  Stage: %X, GameState: %X, FrameDelay: %d\n",
		maddenres->stage, maddenres->gameState, maddenres->frameDelay);

	printf("  Last GTError: %d, GTErrRecovers: %d (Good: %d, Bad: %d)\n",
		maddenres->lastGTError, maddenres->gtErrorRecovers,
		maddenres->gtRecovered, maddenres->gtRecoverFailures);

	printf("  Errors: [CheckLine: %d, CallWaits: (local: %d, remote: %d)]\n",
		maddenres->checklineErr, maddenres->callWaits,
		maddenres->remoteCallWaits);

	printf("          [ConnectLost: %d, Timeouts: %d]\n",
		maddenres->connectLost, maddenres->errTimeouts);

	return (kNoError);
}

//
// Determine whether or not a Madden player was losing.  We don't want them
// to try to avoid a last-minute guaranteed field goal by hitting reset
// or calling themselves.
//
// Returns kNoError if he was probably winning, kFucked if he was possibly
// losing.
//
static int
MaddenPossiblyLosing(const ServerState *state, const NewGameResult *gameResult)
{
	long local, remote;

	local = gameResult->localPlayer1Result + gameResult->localPlayer2Result;
	remote = gameResult->remotePlayer1Result + gameResult->remotePlayer2Result;

	if (local <= (remote + 2))
		return (kFucked);

	return (kNoError);
}



//
// (Sequential) criteria for determining whether or not the reset was evil:
//
//	- not evil if we were resynchronizing (unless due to call waiting)
//	- not evil if other guy (?) was doing lots of delays
//	- evil if in non-play mode
//	- evil if we were losing, or winning by only a small amount
//
static int
CheckMaddenReset(const ServerState *state, const NewGameResult *gameResult,
	const NewGameResult *gameErrorResult)
{
	MaddenResults *maddenres;
	QItem *item;
	long local, remote, diff;
	int i;

	if (gameErrorResult == NULL) {
		printf("  Odd: reset detected in gameResult, NO gameErrorResult\n");
		return (kNoError);
	} else {
		maddenres = (MaddenResults *)gameErrorResult->gameReserved;

		// Look for a crash record.
		//
		for (i = 0; i < state->sendQData.count; i++) {
			item = &state->sendQData.items[i];

			if (item->theID == kRestartInfoType) {
				printf("  Found a crash record, probably OK.\n");
				return (kResetMaybe);
			}
		}

		// Check game state.
		//
#ifdef OLD_STATE
		if (maddenres->gameState & kEstablishSynch	||
			maddenres->gameState & kErrorRecover)
#else
		if (maddenres->stage == kstage_inErrorRecovery)
#endif
		{
			// Check if we because of call waiting
			//
			if (gameErrorResult->localGameError == kCallWaitingErr ||
				gameErrorResult->localGameError == kRemoteCallWaitingErr)
			{
				printf("  inErrorRecovery, call waiting error, definite.\n");
				return (kResetDefinite);
			} else {
				printf("  inErrorRecovery, not cw, maybe.\n");
				return (kResetMaybe);
			}
		}

		// Check if we have some delays, but not enough for -440.
		//
		if (maddenres->delaysPerQuarter[maddenres->quarter] >= 2) {
			printf("  Many delays, maybe.\n");
			return (kResetMaybe);
		}

		// Check if we are in non playing modes.
		//
		if (maddenres->stage == kstage_intermission	||
			maddenres->stage == kstage_pauseMode	||
			maddenres->stage == kstage_gameOver)
		{
			printf("  In non-playing mode, definite.\n");
			return (kResetDefinite);
		}

		local = gameErrorResult->localPlayer1Result +
			gameErrorResult->localPlayer2Result;
		remote = gameErrorResult->remotePlayer1Result +
			gameErrorResult->remotePlayer2Result;

		// Check if we are losing and how far into the game we are
		//
		diff = remote - local;
#ifdef SPREAD_WORKS
		if (maddenres->quarter < 3) {
			// Must be large score difference toward beginning.
			//
			// Don't want them to hit reset just as the other guy sets up
			// for an easy field goal.
			//
			if (diff >= -14) {
				printf("  Early in game, score within 14, definite.\n");
				return (kResetDefinite);
			}
		} else if (diff >= -3) {
			printf("  Late in game, score within 3, definite.\n");
			return (kResetDefinite);
		}
#else
		if (diff > 0) {
			printf("  TEMP: I was losing, definite reset.\n");
			return (kResetDefinite);
		}
#endif	/*SPREAD_WORKS*/
	}

	printf("  All criteria checked, looks okay.\n");
	return (kNoError);
}

//
// Sets one value to "1" and the other to "0".
//
static int
GenericGetNumWins(const NewGameResult *gameResult, long *p1wins, long *p2wins)
{
	long pointsFor, pointsAgainst;

	pointsFor = gameResult->localPlayer1Result + gameResult->localPlayer2Result;
	pointsAgainst = gameResult->remotePlayer1Result + gameResult->remotePlayer2Result;

	if (pointsFor > pointsAgainst) {
		*p1wins = 2;
		*p2wins = 0;
	} else if (pointsFor < pointsAgainst) {
		*p1wins = 0;
		*p2wins = 2;
	} else {
		*p1wins = *p2wins = 1;
	}
	return (kNoError);
}

//
// Sets the win values equal to twice the point values.
//
static int
MatchGetNumWins(const NewGameResult *gameResult, long *p1wins, long *p2wins)
{
	long pointsFor, pointsAgainst;

	pointsFor = gameResult->localPlayer1Result + gameResult->localPlayer2Result;
	pointsAgainst = gameResult->remotePlayer1Result + gameResult->remotePlayer2Result;

	*p1wins = pointsFor * 2;
	*p2wins = pointsAgainst * 2;
	return (kNoError);
}


static int
dbDumpJamsSendQ(const unsigned char *data, const long size)
{
	int 		i;
	JamsStats 	*j = (JamsStats *)data;
	double		latencyMSec;

 	printf (cdbLoad_GameSpecific1);	
	if (size != sizeof(JamsStats)) {
                printf("%d\t%d\t", kdbLoad_GameResultsIncomplete,
                                sizeof(JamsStats));
                return;
                }
        else {
                printf("%d\t%d\t", kdbLoad_GameResultsComplete,
                                sizeof(JamsStats));
             }

	printf("%08x\t%08x\t", j->frameCount, j->gameFrames);
	printf("%08x\t%08x\t%08x\t", j->skipCount, j->syncFlagSkips, 
				     	j->rxFifoEmptyCount);
	printf("%08x\t%08x\t%08x\t", j->lateCount, j->caughtLateCount, 
					j->lostSyncCount);

	printf("%08x\t%08x\t", j->endQFrameCount, j->endQGameFrames);
	printf("%08x\t%08x\t%08x\t", j->endQSkipCount, j->endQSyncFlagSkips, 
					j->endQRxFifoEmptyCount);
	printf("%08x\t%08x\t%08x\t", j->endQLateCount, j->endQCaughtLateCount, 
					j->endQLostSyncCount);

	printf("%02x\t%02x\t%02x\t", j->refTimeStamp, j->lastTimeStamp, 
					j->latencyCount);

	printf("%04x\t%02x\t", j->mode, j->isLeader);
	printf("%04u\t%02u\t", j->avgEqm, j->maxEqm );

	latencyMSec = ( ((double)j->latencyCount - 3.0) +
					(((double)j->refTimeStamp - 37.0)/97.0)
				  ) * 16.66667;
	if (latencyMSec < 0.0) latencyMSec = 0.0;

	printf("%.1f\n", latencyMSec);

	for (i = 0; i < j->patchHistPtr; i++) {
		if (i == 32) {
			break;
		}
 		printf (cdbLoad_GameSpecific2);	
		printf("%d\t%02x\n", i, j->patchHistBuf[i]);	
	}
}



// ===========================================================================
//		Mortal Kombat II (0xc4cddf0c)
// ===========================================================================

static int
dbDumpMK2SendQ(const unsigned char *data, const long size)
{
	MK2SendQ *mk2res = (MK2SendQ *)data;

 	printf (cdbLoad_GameSpecific1);	
	if (size != sizeof(MK2SendQ)) {
                printf("%d\t%d\t", kdbLoad_GameResultsIncomplete,
                                sizeof(MK2SendQ));
                return;
                }
        else {
                printf("%d\t%d\t", kdbLoad_GameResultsIncomplete,
                                sizeof(MK2SendQ));
             }

	printf("%.8lx\t%.8lx\t", mk2res->syncFlagSkips, 
				 mk2res->rxFifoEmptyCount);
	printf("%.8lx\t%.8lx\t", mk2res->lateCount, mk2res->lostSyncCount);
	printf("%.8lx\t%.8lx\t", mk2res->caughtLateCount, mk2res->gameFrames);
	printf("0x%.2x\t0x%.2x\t0x%.2x\t", mk2res->refTimeStamp, 
				 mk2res->lastTimeStamp, mk2res->latencyCount);
	printf("0x%.2x\t0x%.2x\t0x%.2x\t", mk2res->isLeader, 
				 mk2res->callWaitingCount, mk2res->gameHoldOff);
	printf("0x%.2x\t0x%.2x\t", mk2res->p1RoundWins, mk2res->p2RoundWins);
	printf("0x%.8lx\t0x%.2x\n", mk2res->errRecoverTime, mk2res->inResync);

	return (kNoError);
}
