#ifndef lint
static char *sccsid = "$Id: CRMachine.c,v 1.15 1995/05/26 23:01:15 jhsia Exp $";
#endif /* lint */

/*
 * Copyright: @ 1994 Catapult Entertainment Inc., all rights reserved
 * 
 * $Id: CRMachine.c,v 1.15 1995/05/26 23:01:15 jhsia Exp $
 *
 * $Log: CRMachine.c,v $
 * Revision 1.15  1995/05/26  23:01:15  jhsia
 * switched to rcs keywords
 *
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include "../include/logutil.h"
#include "Server_Log.h"
#include "../include/CRMachine.h"

#define kErrThreshold 3
#define GAMEERRORSWHERE gameErrorResults

extern int errno;
extern LogSessionParams gSessionParams;
LogSessionRec				gSessionRec;
unsigned int				firstDateSeen = -1;
unsigned int				lastDateSeen;

#define kAllGamesName "all"
#define NUM_GAMES_DEFINED  8
#define CRACKCR

GameIDRecHead    games[NUM_GAMES_DEFINED] = {
    {kAllGamesName  , "All Games", 	0, 0, 0, EMPTYNODE, NULL},
    {"nj"  , "NBA Jam", 	0xe30c296e, 0x39677bdb, 0, EMPTYNODE, NULL},
    {"mk"  , "Mortal Kombat", 	0xab6348e9, 0xab6348e9, 0, EMPTYNODE, NULL},
    {"mk2"  , "Mortal Kombat 2",0xc4cddf0c, 0xc4cddf0c, 0, EMPTYNODE, NULL},
    {"n94" , "NHL 94", 		0xa61b53f8, 0xa61b53f8, 0, EMPTYNODE, NULL},
    {"n95" , "NHL 95", 		0x8f6b9f70, 0x8f6b9f70, 0, EMPTYNODE, NULL},
    {"mdn" , "Madden '95", 	0x31ed8123, 0x31ed8123, 0, EMPTYNODE, NULL},
    {"nlv95" , "NBA Live '95", 	0x00192660, 0x00192660, 0, EMPTYNODE, NULL}
 };

#define NUM_SORTS_DEFINED  3
SortType    sorts[NUM_SORTS_DEFINED] = {
	{"pop", "By POP", (SortProcessor)DumpPOPDB},
	{"box", "By Box ID", (SortProcessor)DumpBoxDB },
	{"gid", "By Game ID", (SortProcessor)DumpGameDB }
};

VectorMachine sCRMachine = {
		"CRMachine", 
		 (kIsReadMachine), {
			// version zero
			EMPTYVERSION(0),
			
			// version one
			EMPTYVERSION(1),
			
			// version two
			EMPTYVERSION(2),
			
			// version three
			EMPTYVERSION(3),
			
			// version four
			{ 4, NULL,
				(VectorMachineInit)VMInit_v4, (VectorMachineConclude)VMConclude_v4, 
				(VectorMachineFilter)VMFilter_v4, (VectorMachineOutput)VMOutput_v4 
			},
			
			{ 5, NULL,
				(VectorMachineInit)VMInit_v5, (VectorMachineConclude)VMConclude_v5, 
				(VectorMachineFilter)VMFilter_v4, (VectorMachineOutput)VMOutput_v5 
			},
			
			{ 6, NULL,
				(VectorMachineInit)VMInit_v6, (VectorMachineConclude)VMConclude_v6, 
				(VectorMachineFilter)VMFilter_v4, (VectorMachineOutput)VMOutput_v6 
			}
		}
	};

#define kLastErr 69
ErrorTuple errors[] = {
	{ 0, "kNoError" },
	{ -1, "kFuckedErr" },
	{ -2, "kOutOfMemoryErr" },
	{ -3, "globalIDRangeErr" },
	{ -4, "procIDRangeErr" },
	{ -5, "managerIDRangeErr" },
	{ -6, "commandSelectorUnknown" },
	{ -7, "badDispatchSelector" },
	{ -8, "outOfSpritesErr" },
	{ -9, "cantCreateCursorErr" },
	{ -10, "boxIDGlobalsCorrupted" },
	{ -11, "kGameFailedErr" },
	{ -12, "kGameHeapTrashedErr" },
	{ -13, "kRebootDuringGameErr" },	
	{ -14, "kDispatcherHosedErr" },
	{ -15, "kCantLoadGameErr" },
	
	/* database errors */
	{ -100, "kDBDuplicateTypeError" },
	{ -101, "kDBUnknownTypeError" },
	{ -102, "kDBDuplicateIDError" },
	{ -103, "kDBUnknownIDError" },
	{ -104, "kDBNullData" },
	{ -105, "kDBPurgeError" },
	{ -106, "kDBROMEntryError" },
	
	/* dialog errors */
	{ -200, "kDialogErr" },
	
	/* message errors */
	{ 0, "kProcessingStream" },
	{ -300, "kUnrecognizedOpCodeError" },
	{ -301, "kStreamDone" },
	{ -302, "kFatalStreamError" },
	{ -303, "kSimulatorUserAborted" },
	{ -304, "kMessageHandlerOutOfMemory" },
	{ -305, "kOSCorrupt" },
	{ -306, "kOpponentVerificationFailed" },
	
	/* network errors */
	{ -400, "kFifoOverflowErr" },
	{ -401, "kFifoUnderflowErr" },
	{ -402, "kFifoWrongType" },
	{ -403, "kSessionNotClosingErr" },
	{ -404, "kSessionClosedErr" },
	{ -405, "kLinkClosed" },
	{ -406, "kForwardResetAborted" },
	{ -407, "kAsyncInProgErr" },
	{ -408, "kNotASession" },
	{ -409, "kWrongPacketType" },
	{ -410, "kNoSessionRecFound" },
	{ -411, "kRuntPacketDetected" },
	{ -412, "kPortOpenErr" },
	{ -413, "kConnectBusy" },
	{ -414, "kConnectFailed" },
	{ -415, "kNoAnswer" },
	{ -416, "kNoDialtone" },
	{ -417, "kFwdResetFailed" },
	{ -418, "kCantOpenConnection" },
	{ -419, "kNoByteReady" },
	{ -420, "kTransmitBufferFull" },
	{ -421, "kConnectionLost" },
	{ -422, "kNoConnection" },
	{ -423, "kParityError" },
	{ -424, "kFrameError" },
	{ -425, "kOverrunError" },
	{ -426, "kTimeout" },
	{ -427, "kCallWaitingErr" },
	{ -428, "kRemoteCallWaitingErr" },
	{ -429, "kHandshakeErr" },
	{ -430, "kLineNoiseErr" },
	{ -431, "kScriptTimeoutErr" },
	{ -432, "kCallWaitingTimeoutErr" },
	{ -433, "kPeerExchGarbledDataErr" },
	{ -434, "kCallWaitingContinuedTimeoutErr" },
	{ -450, "kNoGameResultsGameErr" },
	{ -451, "kNoCallbackGameErr" },
	
	/* smartcard errors */
	{ -500, "kCardNotInstalledErr" },
	{ -501, "kNotCatapultCardErr" },
	{ -502, "kUnknownCardTypeErr" },
	{ -503, "kIncorrectCardTypeErr" },
	{ -504, "kSecretCodeFailedErr" },
	{ -505, "kNoMoreCreditsErr" },
	{ -506, "kDebitErr" },
	{ -507, "kIncompleteDebitErr" },
	{ -508, "kNoXBandCardErr" },
	
	/* gametalk errors */
	{ -600, "kBogusControllerSize" },
	{ -601, "kGibbledPacket" },
	{ -602, "kNoData" },
	{ -603, "kBadControlPacket" },
	{ -604, "kBadPacketData" },
	{ -605, "kFucked" },
	{ kLastErr, "Unknown Error"}
};


// **************************************************************************************
// VectorMachine head routines
// **************************************************************************************

static int
VMInit_v4(VectorMachineVersion *vmv)
{
V4MachineGlobs		*g;
int					err, done, i;
char				inbuf[256];

	vmv->globals = (void *)malloc(sizeof(V4MachineGlobs));
	if (!vmv->globals) {
		return kInitFailed;
		}
	
	memset(vmv->globals, 0, sizeof(V4MachineGlobs));
	g = vmv->globals;
	
	memset(&gSessionRec, 0, sizeof(gSessionRec));
	InitHead(&gSessionRec.allConnsLink, NULL);
	InitHead(&gSessionRec.conns_800.connLink, &gSessionRec.conns_800);
	InitHead(&gSessionRec.bogusBoxList.thisBox, &gSessionRec.bogusBoxList);
	
	gSessionRec.gameList = NULL;
	for (i = NUM_GAMES_DEFINED - 1; i >= 0; i--) {
		InitHead(&games[i].thisGame, &games[i]);
		games[i].otherGame = (struct GameIDRecHead *)gSessionRec.gameList;
		gSessionRec.gameList = &games[i];
		}

	strcpy(gSessionRec.bogusBoxList.user_info.name, "Bogus Box");
	
	// set up the device to output with.  You can change this if you want.
	g->stdioMachine = VMRecoverVectors(kStdioMachine);
	if (err = VMInitVectorMachine(g->stdioMachine)) {
		fprintf(stderr, "Error initializing vector machine: %d\n", err);
		VMDisposeVectors(g->stdioMachine);
		return err;
		}
	
	done = false;
	while (!done) {
		fprintf(stderr, "\nWhich game to filter on [?] ");
		fflush(stderr);
	
		fgets(inbuf, BUFSIZ, stdin);
		if (inbuf[strlen(inbuf) -1] == '\n')
			inbuf[strlen(inbuf) -1] = '\0';
		
		if ((inbuf[0] == '?') || (inbuf[0] == 0)) {
			fprintf(stderr, "Games Supported:\n");
			for (i = 0; i < NUM_GAMES_DEFINED; i++)
				fprintf(stderr, "\tName: %s, Description %s\n", games[i].name, games[i].desc);
			}
		else if (g->game = FindGameIDByStr(inbuf)) {	
			if (!strcmp(g->game->name, kAllGamesName))
				g->game = NULL;
			done = true;
			}
		else
			fprintf(stderr, "\nUnknown game, try again.\n");
		}
	
	done = false;
	while (!done) {
		fprintf(stderr, "\nSort output how [?] ");
		fflush(stderr);
	
		fgets(inbuf, BUFSIZ, stdin);
		if (inbuf[strlen(inbuf) -1] == '\n')
			inbuf[strlen(inbuf) -1] = '\0';
		
		if ((inbuf[0] == '?') || (inbuf[0] == 0)) {
			fprintf(stderr, "Sorts Supported:\n");
			for (i = 0; i < NUM_SORTS_DEFINED; i++)
				fprintf(stderr, "\tName: %s, Description %s\n", sorts[i].sortName, sorts[i].sortDesc);
			}
		else if (g->sort = FindSort(inbuf)) {	
			done = true;
			}
		else
			fprintf(stderr, "\nUnknown sort, try again.\n");
		}
	
	return kNoErr;
}

static int
VMConclude_v4(VectorMachineVersion *vmv)
{
V4MachineGlobs		*g = vmv->globals;

	(*g->sort->processor)(vmv);
	printf("\n\nFirst date seen: %s", ctime(&firstDateSeen));
	printf("Last date seen: %s", ctime(&lastDateSeen));
	
	VMConcludeVectorMachine(g->stdioMachine);
	VMDisposeVectors(g->stdioMachine);

	free(vmv->globals);
	return kNoErr;
}

static Boolean
VMFilter_v4(VectorMachineVersion *vmv, char *blogRecord, VMFlagType *watchFlags)
{
BlogLoginInfo_v3 *loginInfo    = (BlogLoginInfo_v3 *)blogRecord;
VMFlagType flags = *watchFlags;
	
	if ((loginInfo->startTime < gSessionParams.startTime) ||
			(loginInfo->startTime > gSessionParams.endTime))
		return(false);
	
    if (flags == kVMFlagProcessAllConnections)
        return(true);

    if ((flags & kVMFlagProcessX25Connections) && (loginInfo->flags.x25Conn))
        return(true);

    if ((flags & kVMFlagProcess800Connections) && (!loginInfo->flags.x25Conn))
        return(true);

    if ((flags & kVMFlagProcessMailRequest) && (loginInfo->flags.mailOrGame == kBlogMail))
        return(true);

    if ((flags & kVMFlagProcessGameRequest) && (loginInfo->flags.mailOrGame == kBlogGame))
        return(true);

    if ((flags & kVMFlagProcessCrashRecord) && (loginInfo->flags.crashRecord))
        return(true);

    if ((flags & kVMFlagProcessGameResult) && (loginInfo->flags.gameResults))
        return(true);

    if ((flags & kVMFlagProcessGameResult) && (loginInfo->flags.gameErrorResults))
        return(true);

    if ((flags & kVMFlagProcessNetErrors) && (loginInfo->flags.netErrors800))
        return(true);

    if ((flags & kVMFlagProcessNetErrors) && (loginInfo->flags.netErrorsX25))
        return(true);

    if ((flags & kVMFlagProcessStreamError) && (loginInfo->flags.streamError))
        return(true);

    return(false);
}


// 1/29/95 10:08:05 PM (BET): This thing is currently the big pig.  Instead of mallocing
// another blog rec and hanging onto it, the source file should be mmap'd and a pointer
// to that memory kept.
static int
VMOutput_v4(VectorMachineVersion *vmv, char *param)
{
ConnRec				*cr;
unsigned short		size 			= *(unsigned short *)param;
BlogLoginInfo_v3	*loginInfo		= (BlogLoginInfo_v3 *)param;

	if (firstDateSeen > loginInfo->startTime)
		firstDateSeen = loginInfo->startTime;
	else if (lastDateSeen < loginInfo->startTime)
		lastDateSeen = loginInfo->startTime;

	if (!(cr = (ConnRec *)malloc(sizeof(ConnRec))))
		return errno;
	memset(cr, 0, sizeof(ConnRec));
	NodeAdd(cr, &cr->allLink, NULL, &gSessionRec.allConnsLink);
	if (!(cr->blogRec = (void *)malloc(size)))
		abort();
	memcpy(cr->blogRec, param, size);
	
    param += VMProcessLoginInfo_v4(vmv, param, cr);
    param += VMProcessConnCarrier_v4(vmv, param, cr);
    param += VMProcessConnType_v4(vmv, param, cr);
    param += VMProcessCrashRecord_v4(vmv, param, cr);
    param += VMProcessGameResults_v4(vmv, param, cr);
    param += VMProcessGameErrorResults_v4(vmv, param, cr);
    param += VMProcess800NetErrors_v4(vmv, param, cr);
    param += VMProcessX25NetErrors_v4(vmv, param, cr);
    param += VMProcessStreamErrorReport_v4(vmv, param, cr);
	
	return kNoErr;
}


// **************************************************************************************
// VectorMachine head support routines
// **************************************************************************************
static int
VMProcessLoginInfo_v4(VectorMachineVersion *vmv, char *param, ConnRec *cr)
{
BlogLoginInfo_v3	*loginInfo = (BlogLoginInfo_v3 *)param;
char				nameBuf[128];
V4MachineGlobs		*g = vmv->globals;
BoxRecHead			*boxHead;
Node				*n;

	// modify global state;
	cr->flags = g->flags = loginInfo->flags;
	
	if (loginInfo->flags.validLogin) {
		cr->start_time = loginInfo->startTime;
		for (boxHead=gSessionRec.box_list; boxHead; boxHead = boxHead->otherBox) {
			if (CompareBoxInfo(&boxHead->user_info.boxSerial, &loginInfo->boxInfo))
				break;
			}
		
		if (!boxHead) {	
			if (!(boxHead = (BoxRecHead *)malloc(sizeof(BoxRecHead))))
				abort();
			memset(boxHead, 0, sizeof(BoxRecHead));
			boxHead->otherBox = gSessionRec.box_list;
			gSessionRec.box_list = boxHead;
			InitHead(&boxHead->thisBox, boxHead);
			
			boxHead->user_info.boxSerial = loginInfo->boxInfo;
			strcpy(boxHead->user_info.name, loginInfo->nameStr);
			strcpy(boxHead->user_info.phone, loginInfo->nameStr);
			}
			
		boxHead->total_count += 1;
		n = &boxHead->thisBox;
		}
	else {
		// give it the bogus login list
		n = &gSessionRec.bogusBoxList.thisBox;
		}
	
	NodeAdd(cr, &cr->boxLink, NULL, n);

	return sizeof(BlogLoginInfo_v3);
}

static int
VMProcessConnCarrier_v4(VectorMachineVersion *vmv, char *param, ConnRec *cr)
{
BlogPopInfo_v0   	*pop = (BlogPopInfo_v0 *)param;
V4MachineGlobs		*g = vmv->globals;
X25RecHead			*n;

	if (g->flags.x25Conn && (gSessionParams.outputFilterFlags & kVMFlagProcessX25Connections)) {
		for (n=gSessionRec.conns_x25; n; n = n->otherPop) {
			if (!strcmp(n->addr, pop->x25Addr))
				break;
			}
		
		if (!n) {	
			if (!(n = (X25RecHead *)malloc(sizeof(X25RecHead))))
				abort();
			memset(n, 0, sizeof(X25RecHead));
			n->connType = kX25Connection;
			n->otherPop = gSessionRec.conns_x25;
			n->total_count = 0;
			gSessionRec.conns_x25 = n;
			strcpy(n->addr, pop->x25Addr);
			strcpy(n->pop, LogPhoneToStr(&pop->main));
			InitHead(&n->thisPop, n);
			}
		
		n->total_count += 1;
		if (g->flags.netErrorsX25) 
			n->err_count += 1;
			
		NodeAdd(cr, &cr->connLink, NULL, &n->thisPop);

		return sizeof(BlogPopInfo_v0);
		}
	else if (gSessionParams.outputFilterFlags & kVMFlagProcess800Connections) {
		NodeAdd(cr, &cr->connLink, NULL, &gSessionRec.conns_800.connLink);
		}
		
	return 0;
}

static int
VMProcessConnType_v4(VectorMachineVersion *vmv, char *param, ConnRec *cr)
{
V4MachineGlobs		*g = vmv->globals;
char				*localParam = param;
BlogOpponentInfo_v0	*opponent;
GameIDRecHead		*gID;

	if (g->flags.mailOrGame == kBlogGame) {
		GameIDData *gameID	= (GameIDData *)localParam;
		localParam += sizeof(GameIDData);
		
		if (gID = FindGameIDByCheck(gameID->gameID)) {
			NodeAdd(cr, &cr->gameLink, NULL, &gID->thisGame);
			gID->total_count += 1;
			
			if (g->flags.dialOrWait == kBlogDial) {
				cr->master = true;
				opponent = (BlogOpponentInfo_v0 *)localParam;
				localParam += sizeof(BlogOpponentInfo_v0);
				
				cr->cookie = opponent->cookie;
				// do cookie search here to match connRec's
				MatchConnection(cr, &gID->thisGame);
				}
			else if (g->flags.dialOrWait == kBlogWait) {
				cr->master = false;
				cr->cookie = *(long *)localParam;
				localParam += sizeof(long);
				}
			}
		}
		
	return localParam-param;
}

static int
VMProcessCrashRecord_v4(VectorMachineVersion *vmv, char *param, ConnRec *cr)
{
V4MachineGlobs			*g = vmv->globals;

    if (!g->flags.crashRecord) 
		return 0;
	else
		return sizeof(struct BoxRestartInfo);
}

static int
VMProcess800NetErrors_v4(VectorMachineVersion *vmv, char *param, ConnRec *cr)
{
V4MachineGlobs		*g = vmv->globals;

    if (g->flags.netErrors800) 
		return sizeof(NetErrorRecord);
	else
		return 0;
}

static int
VMProcessX25NetErrors_v4(VectorMachineVersion *vmv, char *param, ConnRec *cr)
{
V4MachineGlobs		*g = vmv->globals;

    if (g->flags.netErrorsX25) 
		return sizeof(NetErrorRecord);
	else
		return 0;
}

static int
VMProcessStreamErrorReport_v4(VectorMachineVersion *vmv, char *param, ConnRec *cr)
{
V4MachineGlobs		*g = vmv->globals;
StreamErrorReport	*streamError = (StreamErrorReport *)param;

    if (g->flags.streamError) 
		return sizeof(StreamErrorReport);
    else
		return 0;
}

static int
VMProcessGameResults_v4(VectorMachineVersion *vmv, char *param, ConnRec *cr)
{
V4MachineGlobs		*g = vmv->globals;

    if (g->flags.gameResults) {
		ProcessGenericGameResult_v4((NewGameResult *)param, cr, false);
		return ((NewGameResult *)param)->size;
		}
	else
		return 0;
}

static int
VMProcessGameErrorResults_v4(VectorMachineVersion *vmv, char *param, ConnRec *cr)
{
V4MachineGlobs		*g = vmv->globals;

    if (g->flags.gameErrorResults) {
		ProcessGenericGameResult_v4((NewGameResult *)param, cr, true);
		return ((NewGameResult *)param)->size;
		}
	else
		return 0;
}

static void
ProcessGenericGameResult_v4(NewGameResult *gameResult, ConnRec *cr, Boolean gameError)
{
	long     structSize, extraSize;
	GameResultsRec *gr;
	
	structSize = ((unsigned char *)&gameResult->pad) -
				((unsigned char *)gameResult);

	if (gameResult->size < structSize) {
		fprintf(stderr, "\tRunt game result, size=%d\n", gameResult->size);
		return;
		}
		
	extraSize = gameResult->size - structSize;
	extraSize -= 2;		// guess we need this

	// do a sanity check so we don't go nuts
	if (extraSize < 0 || extraSize > 1024) {
		fprintf(stderr, "extraSize = %ld, wrong!\n", extraSize);
		return;
	}
	
	if (gameError) 
		cr->gameErrorResults = gr = (GameResultsRec *)malloc(sizeof(GameResultsRec));
	else
		cr->gameResults = gr = (GameResultsRec *)malloc(sizeof(GameResultsRec));
	
	if (!gr)
		abort();
	memset(gr, 0, sizeof(GameResultsRec));
	gr->id = gameResult->gameID;
	gr->err_status = gameResult->gameError;
	gr->err_where = gameResult->errorWhere;
	gr->err_phase = gameResult->connectPhase;
	gr->local_err = gameResult->localGameError;
	gr->play_time = gameResult->playTime;
	gr->local1 = gameResult->localPlayer1Result;
	gr->local2 = gameResult->localPlayer2Result;
	gr->remote1 = gameResult->remotePlayer1Result;
	gr->remote2 = gameResult->remotePlayer2Result;
//	gr->identity = kMaster | kSlave;
}


// **************************************************************************************
// Node routines
// **************************************************************************************

// has a pointer to the data to link into the node structure, the head to link into, and
// the node to link to the head
// doesn't pay attention to list order, so searching is currently no faster than 
// old crlog.  Could use a node findfunc here until it went from negative to positive
// 1/23/95 11:42:59 AM (BET): This is actually important for output routines that want
// to walk the lists for inorder output.  It may be sufficient to just add new nodes
// on the end of the lists.
int NodeAdd(void *data, Node *node, Node *after, Node *head)
{
	node->head = head;
	node->data = data;
	
	// put at end of list
	if (!after)
		after = head->prev;
		
	// do backchain
	(after->next)->prev = node;
	node->prev = after;
	// do forechain
	node->next = after->next;
	after->next = node;
	
	return kNoErr;
}

// node parameter has a both list head and data params linked in
int NodeDelete(Node *node)
{
	// check that it is a semi-valid node
	if (!(node->next && node->prev && (node->next == node->prev))) 
		return -1;
	
	// if it's the head, just return, don't clobber the data.
	if (node->next == node->prev)
		return -1;
		
	node->head = NULL;
	node->data = NULL;

	(node->next)->prev = node->prev;
	(node->prev)->next = node->next;
	return kNoErr;
}

// returns node data or nil
void *NodeFind(Node *head, NodeFindFunc func, void *iterData)
{
Node			*walker;

	walker = head->next;
	while (walker != head) {
		if (!(*func)(walker->data, iterData))
			return walker->data;
		walker = walker->next;
		}
	return NULL;
}

void InitHead(Node *head, void *data)
{
	head->next = head->prev = head;
	head->head = NULL;
	head->data = data;
}


// **************************************************************************************
// qsort sort routines
// **************************************************************************************

static int TotalErrSort(X25RecHead **n1, X25RecHead **n2)
{
	return((*n2)->err_count - (*n1)->err_count);
}

static int ErrTupleHeadSort(ErrTupleHead **n1, ErrTupleHead **n2)
{
	return((*n2)->count - (*n1)->count);
}

static int ErrTupleSort(ErrSortTuple *e1, ErrSortTuple *e2)
{
	return(e2->count - e1->count);
}

// **************************************************************************************
// sort output routines
// **************************************************************************************

static void
DumpPOPDB(VectorMachineVersion *vmv)
{
X25RecHead			*n, **sortList;
ConnRec				*cr, *nextCR = NULL, *matchNextCR = NULL;
Node				*crn;
int					i, j, temp, popCount, gameResultsErrSeen;
V4MachineGlobs		*g = vmv->globals;
BoxRecHead			*box, *boxMatch;
int					noCallbackConnCount, noMatchCount;

	temp = gameResultsErrSeen = noMatchCount = noCallbackConnCount = popCount = 0;
	
	printf("\n\n*************************\n");
	printf("XRef by POP\n");
	for (n=gSessionRec.conns_x25; n; n = n->otherPop) {
		popCount += 1;
		printf("*************************\n");
		printf("Pop Address: %s\n", n->addr);
		printf("Num connections: %d\n", n->total_count);
		crn = n->thisPop.next;
		for (i = n->total_count; i > 0; i-=1) {
			cr = (ConnRec *)crn->data;
			box = (BoxRecHead *)cr->boxLink.head->data;
			if (!cr->processed) {
				cr->processed = true;
				if (cr->match) {
					cr->match->processed = true;
					boxMatch = (BoxRecHead *)cr->match->boxLink.head->data;
					if (!LASTNODE(cr->boxLink))
						nextCR = (ConnRec *)cr->boxLink.next->data;
					else
						nextCR = NULL;
						
					if (!LASTNODE(cr->match->boxLink))
						matchNextCR = (ConnRec *)cr->match->boxLink.next->data;
					else
						matchNextCR = NULL;
						
					// check the box to see if it called back
					if (nextCR) {
						if (nextCR->GAMEERRORSWHERE) 
							temp = (cr->master ? (nextCR->GAMEERRORSWHERE->err_status << 16) : (nextCR->GAMEERRORSWHERE->err_status & 0xffff));
						if (nextCR->gameResults && nextCR->gameResults->err_status) 
							gameResultsErrSeen += 1;
						}
					else 
						temp = (kNoCallbackGameErr << 16) | (kNoCallbackGameErr & 0xffff);
	
					// check the match to see if it called back
					if (matchNextCR) {
						VMOutputConnection(g->stdioMachine, matchNextCR->blogRec);
						if (matchNextCR->GAMEERRORSWHERE) 
							temp |= (cr->match->master ? (matchNextCR->GAMEERRORSWHERE->err_status << 16) : (matchNextCR->GAMEERRORSWHERE->err_status & 0xffff));
						if (matchNextCR->gameResults && matchNextCR->gameResults->err_status) 
							gameResultsErrSeen += 1;
						}
					else 
						temp |= (temp & 0xffff ? (kNoCallbackGameErr << 16) : (kNoCallbackGameErr & 0xffff));
					}
				else 
					noMatchCount += 1;
				OutputMatch(vmv, cr);
				}
			else {
				boxMatch = (BoxRecHead *)cr->match->boxLink.head->data;
				printf("\tALREADY PROCESSED - Login Name: \"%s\", Match: \"%s\"\n", box->user_info.name, boxMatch->user_info.name);
				}
			crn = crn->next;
			}
		}
		
	// now dump the X25 error list
	printf("\n\n*************************\n");
	printf("X25 POP listing\n");
	printf("Printing pops with more than %d errors\n\n", kErrThreshold);
	sortList = (X25RecHead **)malloc(sizeof(X25RecHead *) * popCount);
	if (!sortList)
		abort();
	for (n=gSessionRec.conns_x25, i=0; n; n = n->otherPop, i+=1) 
		sortList[i] = n;
	
	qsort(sortList, popCount, sizeof(X25RecHead *), TotalErrSort);
	for (i=0; i < popCount; i++) {
		if (sortList[i]->err_count <= kErrThreshold)
			break;
		else
			printf("\tPop Address: %s, errors: %d/%d (%d%%)\n", sortList[i]->addr, sortList[i]->err_count, sortList[i]->total_count, 
					sortList[i]->err_count*100/sortList[i]->total_count);
		}
}

static void
DumpBoxDB(VectorMachineVersion *vmv)
{
BoxRecHead			*n, **sortList;
ConnRec				*cr, *nextCR = NULL, *matchNextCR = NULL;
Node				*crn;
int					i, j, temp, popCount;
V4MachineGlobs		*g = vmv->globals;
BoxRecHead			*box, *boxMatch;
int					gameResultsErrSeen, tupleCount, totalCount, noCallbackConnCount, noMatchCount;
ErrTupleHead		*errHead, **sortBlob;

	tupleCount = totalCount = gameResultsErrSeen = noMatchCount = noCallbackConnCount = popCount = 0;
	
	printf("\n\n*************************\n");
	printf("XRef by Box\n");
	for (n=gSessionRec.box_list; n; n = n->otherBox) {
		temp = 0;
		popCount += 1;
		crn = n->thisBox.next;
		for (i = n->total_count; i > 0; i-=1) {			
			cr = (ConnRec *)crn->data;
			if (g->game) {
				if (cr->gameLink.head) {
					if (((GameIDRecHead *)cr->gameLink.head->data) != g->game) {
						crn = crn->next;
						continue;
						}
					}
				else {
					crn = crn->next;
					continue;
					}
				}

			printf("*************************\n");
			printf("BoxID: %s\n", n->user_info.name);
			printf("Num connections: %d\n", n->total_count);
			box = (BoxRecHead *)cr->boxLink.head->data;
			if (!cr->processed) {
				cr->processed = true;
				if (cr->match) {
					cr->match->processed = true;
					boxMatch = (BoxRecHead *)cr->match->boxLink.head->data;
						
					// check the box to see if it called back
					if (!LASTNODE(cr->boxLink)) {
						nextCR = (ConnRec *)cr->boxLink.next->data;
						if (nextCR->GAMEERRORSWHERE) 
							temp = (cr->master ? (nextCR->GAMEERRORSWHERE->err_status << 16) : (nextCR->GAMEERRORSWHERE->err_status & 0xffff));
						if (nextCR->gameResults && nextCR->gameResults->err_status)
							gameResultsErrSeen += 1;
						}
					else 
						temp = (kNoCallbackGameErr << 16) | (kNoCallbackGameErr & 0xffff);
	
					// check the match to see if it called back
					if (!LASTNODE(cr->match->boxLink)) {
						matchNextCR = (ConnRec *)cr->match->boxLink.next->data;
						if (matchNextCR->GAMEERRORSWHERE)
							temp |= (cr->match->master ? (matchNextCR->GAMEERRORSWHERE->err_status << 16) : (matchNextCR->GAMEERRORSWHERE->err_status & 0xffff));
						if (matchNextCR->gameResults && matchNextCR->gameResults->err_status) 
							gameResultsErrSeen += 1;
						}
					else 
						temp |= (temp & 0xffff ? (kNoCallbackGameErr << 16) : (kNoCallbackGameErr & 0xffff));

					// find a similar tuple
					for (errHead=gSessionRec.errList; errHead; errHead = (ErrTupleHead *)errHead->next) {
						if (errHead->error == temp)
							break;
						}
					
					// if there isn't one, add it to the primary list
					if (!errHead) {	
						if (!(errHead = (ErrTupleHead *)malloc(sizeof(ErrTupleHead))))
							abort();
						memset(errHead, 0, sizeof(ErrTupleHead));
						InitHead(&errHead->masterBoxLink, errHead);
						errHead->error = temp;
						errHead->next = (struct ErrTupleHead *)gSessionRec.errList;
						gSessionRec.errList = errHead;
						tupleCount += 1;
						}
						
					// then add the connection record to the list
					NodeAdd(cr, &cr->errorLink, NULL, &errHead->masterBoxLink);
					totalCount += 1;
					errHead->count += 1;
					}
				else 
					noMatchCount += 1;
				
				OutputMatch(vmv, cr);
				}
			// perlman asked that this is not printed
			// 3/2/95 2:07:05 PM (BET): now he wants it printed again
			// 3/3: but we can't yet, because it confuses all the other parsers
			else if (cr->match) {
				boxMatch = (BoxRecHead *)cr->match->boxLink.head->data;
				printf("\tALREADY PROCESSED - Login Name: \"%s\", Match: \"%s\"\n", box->user_info.name, boxMatch->user_info.name);
				// printf("\t(printed again for posterity\n");
				// OutputMatch(vmv, cr);
				}
			crn = crn->next;
			}
		}
		
	// build the list of sort pointers
	if (totalCount) {
		sortBlob = (ErrTupleHead **)malloc(tupleCount*sizeof(ErrTupleHead *));
		if (!sortBlob)
			abort();
		tupleCount = 0;
		for (errHead=gSessionRec.errList; errHead; errHead = (ErrTupleHead *)errHead->next)
			sortBlob[tupleCount++] = errHead;				
		
		// dump the error match list
		qsort(sortBlob, tupleCount, sizeof(ErrTupleHead *), ErrTupleHeadSort);

		for (i = 0; i < tupleCount; i++) {
			Node		*boxNode, *boxHead;
			short		master, slave;
			
			master = (sortBlob[i]->error >> 16) & 0xffff;
			slave = sortBlob[i]->error & 0xffff;
			printf("\t%4d (%2d%%) instances of Master: %4d, Slave: %4d (%s, %s)\n", 
					sortBlob[i]->count, sortBlob[i]->count*100/totalCount, master, slave, GetGameErr(master), GetGameErr(slave));
			
			boxHead = &sortBlob[i]->masterBoxLink;
			boxNode = boxHead->next;
			while (boxNode != boxHead) {
				OutputMatch(vmv, (ConnRec *)boxNode->data);
				boxNode = boxNode->next;
				}
			}

		printf("\n\n*************************\n");
		printf("%d connections got matched, %d matches\n", totalCount*2, totalCount);
		printf("%d connections did not get matched\n", noMatchCount);
		printf("%d total connections\n", noMatchCount + totalCount*2);
		printf("%d connections reporting errors in GameResults\n", gameResultsErrSeen);
		
		printf("List of return value pairs from GameErrorResults (counted as kNoErr in absence of GameErrorResults)\n");
		for (i = 0; i < tupleCount; i++) {
			short		master, slave;
			
			master = (sortBlob[i]->error >> 16) & 0xffff;
			slave = sortBlob[i]->error & 0xffff;
			printf("\t%4d (%2d%%) instances of Master: %4d, Slave: %4d (%s, %s)\n", 
					sortBlob[i]->count, sortBlob[i]->count*100/totalCount, master, slave, GetGameErr(master), GetGameErr(slave));
			}
		}
	else
		printf("no connections in this version\n");
}

static void
DumpGameDB(VectorMachineVersion *vmv)
{
GameIDRecHead		*n;
long				*blob;
V4MachineGlobs		*g = vmv->globals;

	printf("\n\n*************************\n");
	printf("XRef by Game\n");
	if (g->game) 
		DumpGame(vmv, g->game);
	else {
		for (n=gSessionRec.gameList; n; n = (GameIDRecHead *)n->otherGame) 
			DumpGame(vmv, n);
		}
}

void DumpGame(VectorMachineVersion *vmv, GameIDRecHead *n)
{
ConnRec				*cr, *nextCR = NULL, *matchNextCR = NULL;
Node				*crn;
int					i, j, k, temp;
BoxRecHead			*box;
int					gameResultsErrSeen, tupleCount, totalCount, noMatchCount;
ErrTupleHead		*errHead, **sortBlob;

	totalCount = gameResultsErrSeen = noMatchCount = tupleCount = 0;
	
	printf("*************************\n");
	printf("Game name: %s\n", n->desc);
	printf("Num connections: %d\n", n->total_count);
	crn = n->thisGame.next;
	for (i = n->total_count; i > 0; i-=1) {
		cr = (ConnRec *)crn->data;
		box = (BoxRecHead *)cr->boxLink.head->data;
		if (!cr->processed) {
			cr->processed = true;
			if (cr->match) {
				matchNextCR = nextCR = NULL;
				temp = 0;
				cr->match->processed = true;
				if (!LASTNODE(cr->boxLink)) {
					nextCR = (ConnRec *)cr->boxLink.next->data;
					if (nextCR->GAMEERRORSWHERE)
						temp = (cr->master ? (nextCR->GAMEERRORSWHERE->err_status << 16) : (nextCR->GAMEERRORSWHERE->err_status & 0xffff));
					if (nextCR->gameResults && nextCR->gameResults->err_status) {
						gameResultsErrSeen += 1;
						}
					}
				else {
					temp = (kNoCallbackGameErr << 16) | (kNoCallbackGameErr & 0xffff);
					}

				// check the match to see if it called back
				if (!LASTNODE(cr->match->boxLink)) {
					matchNextCR = (ConnRec *)cr->match->boxLink.next->data;
					if (matchNextCR->GAMEERRORSWHERE)
						temp |= (cr->match->master ? (matchNextCR->GAMEERRORSWHERE->err_status << 16) : (matchNextCR->GAMEERRORSWHERE->err_status & 0xffff));
					if (matchNextCR->gameResults && matchNextCR->gameResults->err_status) {
						gameResultsErrSeen += 1;
						}
					}
				else {
					temp |= (temp & 0xffff ? (kNoCallbackGameErr << 16) : (kNoCallbackGameErr & 0xffff));
					}

				// find a similar tuple
				for (errHead=gSessionRec.errList; errHead; errHead = (ErrTupleHead *)errHead->next) {
					if (errHead->error == temp)
						break;
					}
				
				// if there isn't one, add it to the primary list
				if (!errHead) {	
					if (!(errHead = (ErrTupleHead *)malloc(sizeof(ErrTupleHead))))
						abort();
					memset(errHead, 0, sizeof(ErrTupleHead));
					InitHead(&errHead->masterBoxLink, errHead);
					errHead->error = temp;
					errHead->next = (struct ErrTupleHead *)gSessionRec.errList;
					gSessionRec.errList = errHead;
					tupleCount += 1;
					}
					
				// then add the connection record to the list
				NodeAdd(cr, &cr->errorLink, NULL, &errHead->masterBoxLink);
				totalCount += 1;
				errHead->count += 1;
				}
			else {
				noMatchCount += 1;
				}
			}
		crn = crn->next;
		}		
	
	// build the list of sort pointers
	if (totalCount) {
		sortBlob = (ErrTupleHead **)malloc(tupleCount*sizeof(ErrTupleHead *));
		if (!sortBlob)
			abort();
			
		tupleCount = 0;
		for (errHead=gSessionRec.errList; errHead; errHead = (ErrTupleHead *)errHead->next)
			sortBlob[tupleCount++] = errHead;				
		
		// dump the error match list
		qsort(sortBlob, tupleCount, sizeof(ErrTupleHead *), ErrTupleHeadSort);

		for (i = 0; i < tupleCount; i++) {
			Node		*boxNode, *boxHead;
			short		master, slave;
			
			master = (sortBlob[i]->error >> 16) & 0xffff;
			slave = sortBlob[i]->error & 0xffff;
			printf("\t%4d (%2d%%) instances of Master: %4d, Slave: %4d (%s, %s)\n", 
					sortBlob[i]->count, sortBlob[i]->count*100/totalCount, master, slave, GetGameErr(master), GetGameErr(slave));
			
			boxHead = &sortBlob[i]->masterBoxLink;
			boxNode = boxHead->next;
			while (boxNode != boxHead) {
				OutputMatch(vmv, (ConnRec *)boxNode->data);
				boxNode = boxNode->next;
				}
			}

		printf("\n\n*************************\n");
		printf("%d connections got matched, %d matches\n", totalCount*2, totalCount);
		printf("%d connections did not get matched\n", noMatchCount);
		printf("%d total connections\n", noMatchCount + totalCount*2);
		printf("%d connections reporting errors in GameResults\n", gameResultsErrSeen);
		
		printf("List of return value pairs from GameErrorResults (counted as kNoErr in absence of GameErrorResults)\n");
		for (i = 0; i < tupleCount; i++) {
			short		master, slave;
			
			master = (sortBlob[i]->error >> 16) & 0xffff;
			slave = sortBlob[i]->error & 0xffff;
			printf("\t%4d (%2d%%) instances of Master: %4d, Slave: %4d (%s, %s)\n", 
					sortBlob[i]->count, sortBlob[i]->count*100/totalCount, master, slave, GetGameErr(master), GetGameErr(slave));
			}
		}
	else
		printf("no connections in this version\n");
		
}


// **************************************************************************************
// misc junk
// **************************************************************************************

static int
CookieMatch(void *iterData, void *findData)
{
ConnRec		*iterCR = (ConnRec *)iterData;
ConnRec		*findCR = (ConnRec *)findData;

	if (findCR->cookie != iterCR->cookie)
		return -1;
	else if (findCR->gameLink.head != iterCR->gameLink.head)
		return -1;
	else if (findCR == iterCR)
		return -1;
	else if (ABS(findCR->start_time) - ABS(iterCR->start_time) > MAX_WAIT_TIME)
		return -1;
	else
		return 0;
}

static void
MatchConnection(ConnRec *cr, Node *head)
{
ConnRec			*foundCR;

	if (foundCR = (ConnRec *)NodeFind(head, CookieMatch, cr)) {
		foundCR->match = cr;
		cr->match = foundCR;
		}
}

static Boolean
CompareBoxInfo(BlogBoxInfo_v0 *b0, BlogBoxInfo_v0 *b1)
{
	if ((b0->serialNum.box == b1->serialNum.box) && (b0->serialNum.region == b1->serialNum.region))
		return true;
	else
		return false;
}

static char *
AppendAlloc(
	char		**blogBlob,
	int			*blogBlobSize,
	void		*data,
	int			dataSize
)
{
	if (*blogBlob = (char *)realloc(*blogBlob, *blogBlobSize + dataSize)) {
		memcpy(*blogBlob+*blogBlobSize, data, dataSize);
		*blogBlobSize += dataSize;
		}

	return *blogBlob;
}

static char*
GetGameErr(int clierr)
{
ErrorTuple	*err = errors;
	
	while (err->err != kLastErr) {
		if (err->err == clierr)
			break;
		err += 1;
		}
		
	return err->name;
}

static SortType *
FindSort(char *str)
{
	int  i;
	SortType *ptr = NULL;

	for (i = 0; i < NUM_SORTS_DEFINED; i++)
		if (!strcmp(sorts[i].sortName, str)) {
			ptr = &sorts[i];
			break;
		}

	return(ptr);
}

static GameIDRecHead *
FindGameIDByStr(char *str)
{
	int  i;
	GameIDRecHead *ptr = NULL;

	for (i = 0; i < NUM_GAMES_DEFINED; i++)
		if (!strcmp(games[i].name, str)) {
			ptr = &games[i];
			break;
		}

	return(ptr);
}


static GameIDRecHead *
FindGameIDByCheck(long id)
{
	GameIDRecHead *ptr = NULL;
	int  i;

	for (i = 0; i < NUM_GAMES_DEFINED; i++)
		if ((games[i].id1 == id) || 
				(games[i].id2 == id)) {
			ptr = &games[i];
			break;
		}

	return(ptr);
}

static char *
FindGameNameByID(long id)
{
	char *str = NULL;
	int  i;

	for (i = 0; i < NUM_GAMES_DEFINED; i++)
		if ((games[i].id1 == id) || 
				(games[i].id2 == id)) {
			str = games[i].desc;
			break;
		}

	if (str == NULL)
		str = "unknown game";

	return(str);
}


// **************************************************************************************
// version 5 entry points
// **************************************************************************************

static int
VMInit_v5(VectorMachineVersion *vmv)
{
V5MachineGlobs		*g;
int					err, done, i;
char				inbuf[256];

	vmv->globals = (void *)malloc(sizeof(V5MachineGlobs));
	if (!vmv->globals) {
		return kInitFailed;
		}
	
	memset(vmv->globals, 0, sizeof(V5MachineGlobs));
	g = vmv->globals;
	
	memset(&gSessionRec, 0, sizeof(gSessionRec));
	InitHead(&gSessionRec.allConnsLink, NULL);
	InitHead(&gSessionRec.conns_800.connLink, &gSessionRec.conns_800);
	InitHead(&gSessionRec.bogusBoxList.thisBox, &gSessionRec.bogusBoxList);
	
	gSessionRec.gameList = NULL;
	for (i = NUM_GAMES_DEFINED - 1; i >= 0; i--) {
		InitHead(&games[i].thisGame, &games[i]);
		games[i].otherGame = (struct GameIDRecHead *)gSessionRec.gameList;
		gSessionRec.gameList = &games[i];
		}

	strcpy(gSessionRec.bogusBoxList.user_info.name, "Bogus Box");
	
	// set up the device to output with.  You can change this if you want.
	g->stdioMachine = VMRecoverVectors(kStdioMachine);
	if (err = VMInitVectorMachine(g->stdioMachine)) {
		fprintf(stderr, "Error initializing vector machine: %d\n", err);
		VMDisposeVectors(g->stdioMachine);
		return err;
		}
	
	done = false;
	while (!done) {
		fprintf(stderr, "\nWhich game to filter on [?] ");
		fflush(stderr);
	
		fgets(inbuf, BUFSIZ, stdin);
		if (inbuf[strlen(inbuf) -1] == '\n')
			inbuf[strlen(inbuf) -1] = '\0';
		
		if ((inbuf[0] == '?') || (inbuf[0] == 0)) {
			fprintf(stderr, "Games Supported:\n");
			for (i = 0; i < NUM_GAMES_DEFINED; i++)
				fprintf(stderr, "\tName: %s, Description %s\n", games[i].name, games[i].desc);
			}
		else if (g->game = FindGameIDByStr(inbuf)) {	
			if (!strcmp(g->game->name, kAllGamesName))
				g->game = NULL;
			done = true;
			}
		else
			fprintf(stderr, "\nUnknown game, try again.\n");
		}
	
	done = false;
	while (!done) {
		fprintf(stderr, "\nSort output how [?] ");
		fflush(stderr);
	
		fgets(inbuf, BUFSIZ, stdin);
		if (inbuf[strlen(inbuf) -1] == '\n')
			inbuf[strlen(inbuf) -1] = '\0';
		
		if ((inbuf[0] == '?') || (inbuf[0] == 0)) {
			fprintf(stderr, "Sorts Supported:\n");
			for (i = 0; i < NUM_SORTS_DEFINED; i++)
				fprintf(stderr, "\tName: %s, Description %s\n", sorts[i].sortName, sorts[i].sortDesc);
			}
		else if (g->sort = FindSort(inbuf)) {	
			done = true;
			}
		else
			fprintf(stderr, "\nUnknown sort, try again.\n");
		}
	
	return kNoErr;
}

static int
VMConclude_v5(VectorMachineVersion *vmv)
{
V5MachineGlobs		*g = vmv->globals;

	(*g->sort->processor)(vmv);
	printf("\n\nFirst date seen: %s", ctime(&firstDateSeen));
	printf("Last date seen: %s", ctime(&lastDateSeen));
	
	VMConcludeVectorMachine(g->stdioMachine);
	VMDisposeVectors(g->stdioMachine);

	free(vmv->globals);
	return kNoErr;
}

static Boolean
VMFilter_v5(VectorMachineVersion *vmv, char *blogRecord, VMFlagType *watchFlags)
{
BlogLoginInfo_v3 *loginInfo    = (BlogLoginInfo_v3 *)blogRecord;
VMFlagType flags = *watchFlags;
	
	if ((loginInfo->startTime < gSessionParams.startTime) ||
			(loginInfo->startTime > gSessionParams.endTime))
		return(false);
	
    if (flags == kVMFlagProcessAllConnections)
        return(true);

    if ((flags & kVMFlagProcessX25Connections) && (loginInfo->flags.x25Conn))
        return(true);

    if ((flags & kVMFlagProcess800Connections) && (!loginInfo->flags.x25Conn))
        return(true);

    if ((flags & kVMFlagProcessMailRequest) && (loginInfo->flags.mailOrGame == kBlogMail))
        return(true);

    if ((flags & kVMFlagProcessGameRequest) && (loginInfo->flags.mailOrGame == kBlogGame))
        return(true);

    if ((flags & kVMFlagProcessCrashRecord) && (loginInfo->flags.crashRecord))
        return(true);

    if ((flags & kVMFlagProcessGameResult) && (loginInfo->flags.gameResults))
        return(true);

    if ((flags & kVMFlagProcessGameResult) && (loginInfo->flags.gameErrorResults))
        return(true);

    if ((flags & kVMFlagProcessNetErrors) && (loginInfo->flags.netErrors800))
        return(true);

    if ((flags & kVMFlagProcessNetErrors) && (loginInfo->flags.netErrorsX25))
        return(true);

    if ((flags & kVMFlagProcessStreamError) && (loginInfo->flags.streamError))
        return(true);

    return(false);
}


// 1/29/95 10:08:05 PM (BET): This thing is currently the big pig.  Instead of mallocing
// another blog rec and hanging onto it, the source file should be mmap'd and a pointer
// to that memory kept.
static int
VMOutput_v5(VectorMachineVersion *vmv, char *param)
{
ConnRec				*cr;
unsigned short		size 			= *(unsigned short *)param;
BlogLoginInfo_v3	*loginInfo		= (BlogLoginInfo_v3 *)param;

	if (firstDateSeen > loginInfo->startTime)
		firstDateSeen = loginInfo->startTime;
	else if (lastDateSeen < loginInfo->startTime)
		lastDateSeen = loginInfo->startTime;

	if (!(cr = (ConnRec *)malloc(sizeof(ConnRec))))
		return errno;
	memset(cr, 0, sizeof(ConnRec));
	NodeAdd(cr, &cr->allLink, NULL, &gSessionRec.allConnsLink);
	if (!(cr->blogRec = (void *)malloc(size)))
		abort();
	
	memcpy(cr->blogRec, param, size);
	
    param += VMProcessLoginInfo_v4(vmv, param, cr);
    param += VMProcessConnCarrier_v4(vmv, param, cr);
    param += VMProcessConnType_v4(vmv, param, cr);
    param += VMProcessCrashRecord_v4(vmv, param, cr);
    param += VMProcessGameResults_v4(vmv, param, cr);
    param += VMProcessGameErrorResults_v5(vmv, param, cr);
    param += VMProcess800NetErrors_v4(vmv, param, cr);
    param += VMProcessX25NetErrors_v4(vmv, param, cr);
    param += VMProcessStreamErrorReport_v4(vmv, param, cr);
	
	return kNoErr;
}

static int
VMProcessGameErrorResults_v5(VectorMachineVersion *vmv, char *param, ConnRec *cr)
{
V5MachineGlobs		*g = vmv->globals;
NewGameResult 		*gameResult = (NewGameResult *)param;
int					size = 0;

    if (g->flags.gameErrorResults) {
		ProcessGenericGameResult_v4((NewGameResult *)param, cr, true);
		size = gameResult->size;
		if (gameResult->dbIDDataSize) {
			size += gameResult->dbIDDataSize;
			}
		}
	return size;
}



// **************************************************************************************
// version 6 entry points
// **************************************************************************************

static int
VMInit_v6(VectorMachineVersion *vmv)
{
V6MachineGlobs		*g;
int					err, done, i;
char				inbuf[256];

	vmv->globals = (void *)malloc(sizeof(V6MachineGlobs));
	if (!vmv->globals) {
		return kInitFailed;
		}
	
	memset(vmv->globals, 0, sizeof(V6MachineGlobs));
	g = vmv->globals;
	
	memset(&gSessionRec, 0, sizeof(gSessionRec));
	InitHead(&gSessionRec.allConnsLink, NULL);
	InitHead(&gSessionRec.conns_800.connLink, &gSessionRec.conns_800);
	InitHead(&gSessionRec.bogusBoxList.thisBox, &gSessionRec.bogusBoxList);
	
	gSessionRec.gameList = NULL;
	for (i = NUM_GAMES_DEFINED - 1; i >= 0; i--) {
		InitHead(&games[i].thisGame, &games[i]);
		games[i].otherGame = (struct GameIDRecHead *)gSessionRec.gameList;
		gSessionRec.gameList = &games[i];
		}

	strcpy(gSessionRec.bogusBoxList.user_info.name, "Bogus Box");
	
	// set up the device to output with.  You can change this if you want.
	g->stdioMachine = VMRecoverVectors(kStdioMachine);
	if (err = VMInitVectorMachine(g->stdioMachine)) {
		fprintf(stderr, "Error initializing vector machine: %d\n", err);
		VMDisposeVectors(g->stdioMachine);
		return err;
		}
	
	done = false;
	while (!done) {
		fprintf(stderr, "\nWhich game to filter on [?] ");
		fflush(stderr);
	
		fgets(inbuf, BUFSIZ, stdin);
		if (inbuf[strlen(inbuf) -1] == '\n')
			inbuf[strlen(inbuf) -1] = '\0';
		
		if ((inbuf[0] == '?') || (inbuf[0] == 0)) {
			fprintf(stderr, "Games Supported:\n");
			for (i = 0; i < NUM_GAMES_DEFINED; i++)
				fprintf(stderr, "\tName: %s, Description %s\n", games[i].name, games[i].desc);
			}
		else if (g->game = FindGameIDByStr(inbuf)) {	
			if (!strcmp(g->game->name, kAllGamesName))
				g->game = NULL;
			done = true;
			}
		else
			fprintf(stderr, "\nUnknown game, try again.\n");
		}
	
	done = false;
	while (!done) {
		fprintf(stderr, "\nSort output how [?] ");
		fflush(stderr);
	
		fgets(inbuf, BUFSIZ, stdin);
		if (inbuf[strlen(inbuf) -1] == '\n')
			inbuf[strlen(inbuf) -1] = '\0';
		
		if ((inbuf[0] == '?') || (inbuf[0] == 0)) {
			fprintf(stderr, "Sorts Supported:\n");
			for (i = 0; i < NUM_SORTS_DEFINED; i++)
				fprintf(stderr, "\tName: %s, Description %s\n", sorts[i].sortName, sorts[i].sortDesc);
			}
		else if (g->sort = FindSort(inbuf)) {	
			done = true;
			}
		else
			fprintf(stderr, "\nUnknown sort, try again.\n");
		}
	
	return kNoErr;
}

static int
VMConclude_v6(VectorMachineVersion *vmv)
{
V6MachineGlobs		*g = vmv->globals;

	(*g->sort->processor)(vmv);
	printf("\n\nFirst date seen: %s", ctime(&firstDateSeen));
	printf("Last date seen: %s", ctime(&lastDateSeen));
	
	VMConcludeVectorMachine(g->stdioMachine);
	VMDisposeVectors(g->stdioMachine);

	free(vmv->globals);
	return kNoErr;
}

static int
VMOutput_v6(VectorMachineVersion *vmv, char *param)
{
ConnRec				*cr;
unsigned short		size 			= *(unsigned short *)param;
BlogLoginInfo_v3	*loginInfo		= (BlogLoginInfo_v3 *)param;

	if (firstDateSeen > loginInfo->startTime)
		firstDateSeen = loginInfo->startTime;
	else if (lastDateSeen < loginInfo->startTime)
		lastDateSeen = loginInfo->startTime;

	if (!(cr = (ConnRec *)malloc(sizeof(ConnRec))))
		return errno;
	memset(cr, 0, sizeof(ConnRec));
	NodeAdd(cr, &cr->allLink, NULL, &gSessionRec.allConnsLink);
	if (!(cr->blogRec = (void *)malloc(size)))
		abort();
	memcpy(cr->blogRec, param, size);
	
    param += VMProcessLoginInfo_v4(vmv, param, cr);
    param += VMProcessConnCarrier_v4(vmv, param, cr);
    param += VMProcessConnType_v4(vmv, param, cr);
    param += VMProcessCrashRecord_v4(vmv, param, cr);
    param += VMProcessGameResults_v6(vmv, param, cr);
    param += VMProcessGameErrorResults_v4(vmv, param, cr);
    param += VMProcess800NetErrors_v4(vmv, param, cr);
    param += VMProcessX25NetErrors_v4(vmv, param, cr);
    param += VMProcessStreamErrorReport_v4(vmv, param, cr);
	
	return kNoErr;
}

static int
VMProcessGameResults_v6(VectorMachineVersion *vmv, char *param, ConnRec *cr)
{
V4MachineGlobs		*g = vmv->globals;
NewGameResult		*ngr;

    if (g->flags.gameResults) {
		ngr = (NewGameResult *)(param+4);
		ProcessGenericGameResult_v4(ngr, cr, false);
		return ngr->size+4;
		}
	else
		return 0;
}

static void
OutputMatch(VectorMachineVersion *vmv, ConnRec *cr)
{
V4MachineGlobs		*g = vmv->globals;
BoxRecHead			*box, *boxMatch;
ConnRec				*nextCR = NULL, *matchNextCR = NULL;

	box = (BoxRecHead *)cr->boxLink.head->data;
	if (boxMatch = (cr->match ? (BoxRecHead *)cr->match->boxLink.head->data : 0))
		printf("\tLogin Name: \"%s\", Match: \"%s\"\n", box->user_info.name, boxMatch->user_info.name);
	else {
		printf("\tLogin Name: \"%s\", No match\n", box->user_info.name);
		return;
		}
	
#ifndef CRACKCR
	VMOutputConnection(g->stdioMachine, cr->blogRec);
	VMOutputConnection(g->stdioMachine, cr->match->blogRec);
#else
	printf("(Initial connection suppressed)\n");
#endif
	printf("**** FOLLOWING CONNECTION:\n");
	if (!LASTNODE(cr->boxLink))
		nextCR = (ConnRec *)cr->boxLink.next->data;
	else
		nextCR = NULL;
		
	if (!LASTNODE(cr->match->boxLink))
		matchNextCR = (ConnRec *)cr->match->boxLink.next->data;
	else
		matchNextCR = NULL;
			
	if (nextCR && matchNextCR) {
		if (nextCR->gameResults && matchNextCR->gameResults) {
			if ((nextCR->gameResults->id != matchNextCR->gameResults->id) ||
				(nextCR->gameResults->local1 != matchNextCR->gameResults->remote1) ||
				(nextCR->gameResults->remote1 != matchNextCR->gameResults->local1)) {
					printf("**** WARNING:\n\tGame result scores do not match, server lost a record!\n");
					printf("\tGame results don't have cookie in them yet, can't tell which to trust!\n");
					}
			}
		else {
			printf("**** WARNING:\n\tGame results not reported from one or another box!\n");
			printf("\tGame results don't have cookie in them yet, can't tell if remaining scores are real!\n");
			}
		}
			
		
	// check the box to see if it called back
	if (nextCR) {
		if (nextCR->gameResults && nextCR->gameResults->err_status) {
			printf("**** WARNING:\n\tGame results have an error reported in them!\n");
			}

		VMOutputConnection(g->stdioMachine, nextCR->blogRec);
		}
	else 
		printf("\t%s did not call back in yet\n", box->user_info.name);

	// check the match to see if it called back
	if (matchNextCR) {
		if (matchNextCR->gameResults && matchNextCR->gameResults->err_status) {
			printf("**** WARNING:\n\tGame results have an error reported in them!\n");
			}
		VMOutputConnection(g->stdioMachine, matchNextCR->blogRec);
		}
	else 
		printf("\t%s did not call back in yet\n", boxMatch->user_info.name);
}
