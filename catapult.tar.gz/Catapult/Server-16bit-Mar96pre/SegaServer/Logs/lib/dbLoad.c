
#ifndef lint
static char *sccsid = "$Id: dbLoad.c,v 1.15 1995/05/26 23:01:20 jhsia Exp $";
#endif /* lint */

/*
 * Copyright: @ 1994 Catapult Entertainment Inc., all rights reserved
 *
 * $Log: dbLoad.c,v $
 * Revision 1.15  1995/05/26  23:01:20  jhsia
 * switched to rcs keywords
 *
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include "../include/logutil.h"
#include "../include/dbLoad.h"
#include "ServerCore.h"

extern int errno;
extern LogSessionParams gSessionParams;

VectorMachine sdbLoad = {
		"Database load - Create file", 
		 (kIsReadMachine), {
			// version zero
			EMPTYVERSION(0),
			
			// version one
			EMPTYVERSION(1),
			
			// version two
			EMPTYVERSION(2),
			
			// version three
			{ 3, NULL,
				(VectorMachineInit)VMInitdb_v3, 
				(VectorMachineConclude)VMConcludedb_v3, 
				(VectorMachineFilter)VMFilterdb_v3, 
				(VectorMachineOutput)VMOutputdb_v3 
			},
			// version four
			{ 4, NULL,
				(VectorMachineInit)VMInitdb_v3, 
				(VectorMachineConclude)VMConcludedb_v3, 
				(VectorMachineFilter)VMFilterdb_v3, 
				(VectorMachineOutput)VMOutputdb_v3 
			},

			// version five
			{ 5, NULL,
				(VectorMachineInit)VMInitdb_v3, 
				(VectorMachineConclude)VMConcludedb_v3, 
				(VectorMachineFilter)VMFilterdb_v3, 
				(VectorMachineOutput)VMOutputdb_v5 
			},
			
			// version six
			{ 6, NULL,
				(VectorMachineInit)VMInitdb_v3, 
				(VectorMachineConclude)VMConcludedb_v3, 
				(VectorMachineFilter)VMFilterdb_v3, 
				(VectorMachineOutput)VMOutputdb_v6 
			},
			// version seven	
			{ 7, NULL,
				(VectorMachineInit)VMInitdb_v3, 
				(VectorMachineConclude)VMConcludedb_v3, 
				(VectorMachineFilter)VMFilterdb_v3, 
				(VectorMachineOutput)VMOutputdb_v6 
			}
			
			
		}
	};

// strings for evil reset detection
struct {
        short   err;
        char    *name;
        } errNames2[] = {
                { kCreditChange_Deduct_SuccessfulGame, "Deduct_SuccessfulGame" },
                { kCreditChange_Deduct_OnQueue, "Deduct_OnQueue" },
                { kCreditChange_Deduct_EvilReset, "Deduct_EvilReset" },
                { kCreditChange_Deduct_EvilCW, "Deduct_EvilCW" },
                { kCreditChange_Deduct_WaitReset, "Deduct_WaitReset" },
                { kCreditChange_Deduct_MailOnly, "Deduct_MailOnly" },
                { kCreditChange_Deduct_HosedSpecific, "Deduct_HosedSpecific" },
                { kCreditChange_Deduct_HosedAuto, "Deduct_HosedAuto" },
                { kCreditChange_Penalize_WaitReset, "Penalize_WaitReset" },
                { kCreditChange_Penalize_EvilReset, "Penalize_EvilReset" },
                { kCreditChange_Penalize_PasswordCode, "Penalize_PasswordCode" }};

//****************************************************************************
//**** V3 vector routines ****************************************************
//**** Copy from here down as template for new machine or version ************
//****************************************************************************
int
VMInitdb_v3(VectorMachineVersion *vmv)
{
	vmv->globals = (void *)malloc(sizeof(V3MachineGlobs));
	if (vmv->globals) {
		memset(vmv->globals, 0, sizeof(V3MachineGlobs));
		return kNoErr;
		}
	else
		return kInitFailed;
}

int
VMConcludedb_v3(VectorMachineVersion *vmv)
{
	free(vmv->globals);
	return kNoErr;
}

Boolean
VMFilterdb_v3(VectorMachineVersion *vmv, char *blogRecord, VMFlagType *watchFlags)
{
BlogLoginInfo_v3 *loginInfo    = (BlogLoginInfo_v3 *)blogRecord;
VMFlagType flags = *watchFlags;
	
	if ((loginInfo->startTime < gSessionParams.startTime) ||
			(loginInfo->startTime > gSessionParams.endTime))
		return(false);

    if (flags == kVMFlagProcessAllConnections)
        return(true);

    if ((flags & kVMFlagProcessSpecifiedBox) && (loginInfo->boxInfo.serialNum.box != gSessionParams.boxNumber))
	return(false);

    if ((flags & kVMFlagProcessX25Connections) && (loginInfo->flags.x25Conn))
        return(true);

    if ((flags & kVMFlagProcess800Connections) && (!loginInfo->flags.x25Conn))
        return(true);

    if ((flags & kVMFlagProcessMailRequest) && (loginInfo->flags.mailOrGame == kBlogMail))
        return(true);

    if ((flags & kVMFlagProcessGameRequest) && (loginInfo->flags.mailOrGame == kBlogGame))
        return(true);

    if ((flags & kVMFlagProcessCrashRecord) && (loginInfo->flags.crashRecord))
        return(true);

    if ((flags & kVMFlagProcessGameResult) && (loginInfo->flags.gameResults))
        return(true);

    if ((flags & kVMFlagProcessGameResult) && (loginInfo->flags.gameErrorResults))
        return(true);

    if ((flags & kVMFlagProcessNetErrors) && (loginInfo->flags.netErrors800))
        return(true);

    if ((flags & kVMFlagProcessNetErrors) && (loginInfo->flags.netErrorsX25))
        return(true);

    if ((flags & kVMFlagProcessStreamError) && (loginInfo->flags.streamError))
        return(true);

    return(false);
}

int
VMOutputdb_v3(VectorMachineVersion *vmv, char *param)
{
    param += VMProcessLoginInfodbLoad_v3(vmv, param);
    param += VMProcessConnCarrierdbLoad_v3(vmv, param);
    param += VMProcessConnTypedbLoad_v3(vmv, param);
    param += VMProcessCrashRecorddbLoad_v3(vmv, param);
    param += VMProcessGameResultsdbLoad_v3(vmv, param);
    param += VMProcessGameErrorResultsdbLoad_v3(vmv, param);
    param += VMProcess800NetErrorsdbLoad_v3(vmv, param);
    param += VMProcessX25NetErrorsdbLoad_v3(vmv, param);
    param += VMProcessStreamErrorReportdbLoad_v3(vmv, param);
	
	return kNoErr;
}

int
VMProcessLoginInfodbLoad_v3(VectorMachineVersion *vmv, char *param)
{
BlogLoginInfo_v3	*loginInfo = (BlogLoginInfo_v3 *)param;
char				nameBuf[128];
V3MachineGlobs		*g = vmv->globals;
struct hostent          *h;
extern Boolean		dbLoadFileRecPrinted;
extern char		*dbLoadProcessingFileName;

	
	// modify global state;
	g->flags = loginInfo->flags;

	// figure out the machine this record came from
	h = gethostbyaddr(&loginInfo->hostAddr, 4, AF_INET);

	if (!dbLoadFileRecPrinted)
	{
		dbLoadFileRecPrinted = true;
		printf(cdbLoad_Init);
		printf("%s\t%d\n", dbLoadProcessingFileName,
				   loginInfo->version); 
	}

	printf(cdbLoad_ConnectionInfo);
	printf("%s\t", h->h_name);

	if (loginInfo->flags.validLogin) {
		printf("%d\t", loginInfo->startTime);
		printf("%d\t", loginInfo->exitStatus);
		printf("%d\t", loginInfo->duration);

		printf("%s\t", loginInfo->nameStr);
		printf("%s\t", LogPhoneToStr(&loginInfo->callingNumber));
		printf("%d\t", loginInfo->boxInfo.serialNum.box); 
		printf("%d\t", loginInfo->boxInfo.serialNum.region);
		printf("%d\t", loginInfo->boxInfo.userNum);
	
		if (loginInfo->flags.validAccount) {
			printf("%d\t", loginInfo->billingType);

			if (loginInfo->flags.accountCreation == kBlogPlayerCreated)
				printf("%d\t", kdbLoad_PlayerCreated);
			else if (loginInfo->flags.accountCreation == kBlogAccountCreated)
				printf("%d\t", kdbLoad_AccountCreated);
			}
		}

	else {
		printf("%d\t", loginInfo->startTime);
		printf("%d\t", loginInfo->exitStatus);
		}

	printf ("\n");
	return sizeof(BlogLoginInfo_v3);
}

int
VMProcessConnCarrierdbLoad_v3(VectorMachineVersion *vmv, char *param)
{
BlogPopInfo_v0   	*pop = (BlogPopInfo_v0 *)param;
V3MachineGlobs		*g = vmv->globals;
		
	printf(cdbLoad_ConnCarrier);

	if (g->flags.x25Conn) {
		printf("%s\t", pop->x25Addr);
		printf("%s\t", LogPhoneToStr(&pop->main));
		printf("%s\n", LogPhoneToStr(&pop->alt));
		return sizeof(BlogPopInfo_v0);
		}

	printf("\n");	
	return 0;
}

int
VMProcessConnTypedbLoad_v3(VectorMachineVersion *vmv, char *param)
{
V3MachineGlobs		*g = vmv->globals;
char			*localParam = param;

	printf(cdbLoad_ConnType);

	if (g->flags.mailOrGame == kBlogGame) {
		

		GameIDData *gameID	= (GameIDData *)localParam;
		localParam += sizeof(GameIDData);

		printf("%d\t", kdbLoad_GameConnect);
		
		if (g->flags.autoOrChall == kBlogAutomatch)
			printf("%d\t", kdbLoad_AutoMatch);
		else if (g->flags.autoOrChall == kBlogChallenge)
			printf("%d\t", kdbLoad_Challenge);
		else
			printf("%d\t", kdbLoad_AutoChal_Unknown);

			
		printf("0x%.8lx\t%s\t%ld\t", gameID->gameID,
		Common_GameName('sega', gameID->gameID), gameID->version);
			
		if (g->flags.dialOrWait == kBlogDial) {
			BlogOpponentInfo_v0 *opponent = (BlogOpponentInfo_v0 *)localParam;
			localParam += sizeof(BlogOpponentInfo_v0);
			
			printf("%d\t%d\t", kdbLoad_Dial, opponent->cookie);
			printf("%d\t%d\t%d\t",
			opponent->boxInfo.serialNum.box,
			opponent->boxInfo.serialNum.region,
			opponent->boxInfo.userNum);
			printf("%s\t", LogPhoneToStr(&opponent->phone));
			}
		else if (g->flags.dialOrWait == kBlogWait) {
			printf("%d\t%d\t", kdbLoad_Wait, *(long *)localParam);
			localParam += sizeof(long);
			}
		}
	else if (g->flags.mailOrGame == kBlogMail)
		printf("%d\t", kdbLoad_MailConnect);
	
	printf("\n");
	
	return localParam-param;
}

int
VMProcessCrashRecorddbLoad_v3(VectorMachineVersion *vmv, char *param)
{
V3MachineGlobs			*g = vmv->globals;
unsigned long			addr, dispNum;
int				count;
struct BoxRestartInfo	*cr = (struct BoxRestartInfo *)param;

    if (!g->flags.crashRecord) 
		return 0;

	printf(cdbLoad_Crash);
	
	printf("%.8lX\t%.8lX\t%.8lX\t%.8lX\t",
		cr->reg[ 0], cr->reg[ 1], cr->reg[ 2], cr->reg[ 3]);
	printf("%.8lX\t%.8lX\t%.8lX\t%.8lX\t",
		cr->reg[ 4], cr->reg[ 5], cr->reg[ 6], cr->reg[ 7]);
	printf("%.8lX\t%.8lX\t%.8lX\t%.8lX\t",
		cr->reg[ 8], cr->reg[ 9], cr->reg[10], cr->reg[11]);
	printf("%.8lX\t%.8lX\t%.8lX\t%.8lX\t",
		cr->reg[12], cr->reg[13], cr->reg[14], cr->reg[15]);
	
		
	addr = (cr->excPC[0] << 16) | (cr->excPC[1]);
	printf("%X\t%.8lX\t%x\t",
		cr->excSR, addr, cr->excCode);
		
	if (cr->unstablePC < 0)
		printf("%d\t%.8lx\t", kdbLoad_OSUnstable,
			cr->unstablePC);
	else
		printf("%d\t%.8lx\t", kdbLoad_OSStable,
			cr->unstablePC);

	printf("%X\t%X\t%.8lX\t",
		cr->prevEntry/2, cr->osState, cr->stackLowWater);
	
	printf("%.8lX\t%.8lX\t%.8lX\t",
		cr->startupFlags, cr->boxState, cr->lastBoxState);
		
	printf("%ld\t%ld\t%ld\t%ld\t%ld\t%ld\t",
		cr->setBoxID.box, cr->setBoxID.region, 
		cr->coldBoxID.box, cr->coldBoxID.region, 
		cr->warmBoxID.box, cr->warmBoxID.region);
	
	if (cr->excCode == kBusError)	{
		addr = (cr->excAddr[0] << 16) | (cr->excAddr[1]);
		
		printf("%X\t%.8lX\t%x",
			cr->excMode, addr, cr->excInstrReg);
	}

	printf("\n");

	for (count = 0; count < kHistorySize; ++count) {
		dispNum = cr->histCallNums[count] / 4;
		printf(cdbLoad_CrashDispatch);
		printf("%2d\t%d\t%s\n", count, dispNum,
			(dispNum >= 0 && dispNum < NELEM(dispCallStrs)) ?
				dispCallStrs[dispNum] : "(invalid)");
	}
	
	for (count = 0; count < kHistorySize; ++count)	{
		printf(cdbLoad_CrashPC);
		printf("%2d\t%8lX\n", count, cr->histCallers[count]);
	}
	
		
	return sizeof(struct BoxRestartInfo);
}

int
VMProcessGameResultsdbLoad_v3(VectorMachineVersion *vmv, char *param)
{
V3MachineGlobs		*g = vmv->globals;

    if (g->flags.gameResults) {
		PrintGenericGameResult_dbLoad_v3((NewGameResult *)param, 
			cdbLoad_GameResults);
		return sizeof(NewGameResult);
		}
	
	return 0;
}

int
VMProcessGameErrorResultsdbLoad_v3(VectorMachineVersion *vmv, char *param)
{
V3MachineGlobs		*g = vmv->globals;

    if (g->flags.gameErrorResults) {
		PrintGenericGameResult_dbLoad_v3((NewGameResult *)param, 
			cdbLoad_GameErrorResults);
		return sizeof(NewGameResult);
		}
	
	return 0;
}

int
VMProcess800NetErrorsdbLoad_v3(VectorMachineVersion *vmv, char *param)
{
V3MachineGlobs		*g = vmv->globals;

    if (g->flags.netErrors800) {
		PrintGenericNetErrors_dbLoad_v3((NetErrorRecord *)param, 
			cdbLoad_800Errors);
		return sizeof(NetErrorRecord);
		}

	return 0;
}

int
VMProcessX25NetErrorsdbLoad_v3(VectorMachineVersion *vmv, char *param)
{
V3MachineGlobs		*g = vmv->globals;

    if (g->flags.netErrorsX25) {
		PrintGenericNetErrors_dbLoad_v3((NetErrorRecord *)param, 
			cdbLoad_X25Errors);
		return sizeof(NetErrorRecord);
		}
	return 0;
}

int
VMProcessStreamErrorReportdbLoad_v3(VectorMachineVersion *vmv, char *param)
{
V3MachineGlobs		*g = vmv->globals;
StreamErrorReport	*streamError = (StreamErrorReport *)param;

    if (g->flags.streamError) {
		printf(cdbLoad_StreamErrors);
		printf("%-2d\t%-5d\t%-5d\t%-5d\t",
			streamError->version, streamError->checkErr, 
			streamError->openErr, streamError->lastOpcode);
		printf("\n");
		return sizeof(StreamErrorReport);
    	}
	return 0;
}

void
PrintGenericGameResult_dbLoad_v3(NewGameResult *gameResult, char *header)
{
	long     structSize, extraSize;

	printf(header);
	structSize = ((unsigned char *)&gameResult->pad) -
				((unsigned char *)gameResult);

	if (gameResult->size < structSize) {
		printf("%d\t%d\n", kdbLoad_GameResultsIncomplete,
				gameResult->size);
		return;
		}
	else {
		printf("%d\t%d\t", kdbLoad_GameResultsComplete,
				gameResult->size);
	     }
		
		
	printf("0x%.8lx\t%s\t%d\t%d\t%d\t%ld\t",
		gameResult->gameID, Common_GameName('sega', gameResult->gameID),
		gameResult->gameError, gameResult->errorWhere,
		gameResult->connectPhase, gameResult->playTime);

	printf("%ld\t%ld\t%ld\t%ld\t",
		gameResult->localPlayer1Result, gameResult->localPlayer2Result,
		gameResult->remotePlayer1Result, gameResult->remotePlayer2Result);
	printf("%ld\t%ld\t%ld\t",
		gameResult->dbIDDataPtr, gameResult->dbIDDataSize,
		(long)gameResult->numLocalPlayers);

	printf("%-5d\t%-5d\t",
		gameResult->localGameError, gameResult->errorRecovers);

	printf("%-3d\t%-3d\t",
		gameResult->checksumErrors, gameResult->timeouts);

	printf("%-3d\t%-3d\t",
		gameResult->frameErrors, gameResult->overrunErrors);

	printf("\n");

}

void
PrintGenericNetErrors_dbLoad_v3(NetErrorRecord *netErrors, char *header)
{
    printf("%s\t%d\t%d\n", header, kdbLoad_NetError_ServerConnects,
		 			netErrors->serverConnects);
    printf("%s\t%d\t%d\n", header,  kdbLoad_NetError_PeerConnects,
					netErrors->peerConnects);

    // determine if 90% of the following contain set errors.
    // ...if so, box has lost its mind, so we mark it as allErrors.

    if ((1 && netErrors->framingError) +
    	(1 && netErrors->overrunError) +
    	(1 && netErrors->packetError) +
   	(1 && netErrors->callWaitingInterrupt) +
  	(1 && netErrors->noDialtoneError) +
    	(1 && netErrors->serverBusyError) +
    	(1 && netErrors->peerBusyError) +
   	(1 && netErrors->serverDisconnectError) +
  	(1 && netErrors->peerDisconnectError) +
 	(1 && netErrors->serverAbortError) +
	(1 && netErrors->peerAbortError) +
    	(1 && netErrors->serverNoAnswerError) +
    	(1 && netErrors->peerNoAnswerError) +
    	(1 && netErrors->serverHandshakeError) +
    	(1 && netErrors->peerHandshakeError) +
    	(1 && netErrors->serverX25NoServiceError) +
    	(1 && netErrors->callWaitingError) +
    	(1 && netErrors->remoteCallWaitingError) +
    	(1 && netErrors->scriptLoginError) +
    	(1 && netErrors->packetRetransError) /* +
      	(1 && netErrors->unused1) +
    	(1 && netErrors->unused2) */ >= 18)
 
    {
	printf("%s\t%d\t%d\n", header,  kdbLoad_NetError_allErrors,
					0);
    }
    else
    {
    if (netErrors->framingError) 
	printf("%s\t%d\t%d\n", header,  kdbLoad_NetError_FrameErrors,
					netErrors->framingError);
    if (netErrors->overrunError ) 
	printf("%s\t%d\t%d\n", header,  kdbLoad_NetError_OverrunErrors,
					netErrors->overrunError);
    if (netErrors->packetError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_PacketErrors,
					netErrors->packetError);
    if (netErrors->callWaitingInterrupt ) 
	printf("%s\t%d\t%d\n",header,  kdbLoad_NetError_CallWaitingInterrupt,
					netErrors->callWaitingInterrupt);
    if (netErrors->noDialtoneError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_NoDialTone,
					netErrors->noDialtoneError);
    if (netErrors->serverBusyError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_ServerBusy,
					netErrors->serverBusyError);
    if (netErrors->peerBusyError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_PeerBusy,
					netErrors->peerBusyError);
    if (netErrors->serverDisconnectError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_ServerDisconnect,
					netErrors->serverDisconnectError);
    if (netErrors->peerDisconnectError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_PeerDisconnect,
					netErrors->peerDisconnectError);
    if (netErrors->serverAbortError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_ServerAbort,
					netErrors->serverAbortError);
    if (netErrors->peerAbortError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_PeerAbort,
					netErrors->peerAbortError);
    if (netErrors->serverNoAnswerError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_ServerNoAnswer,
					netErrors->serverNoAnswerError);
    if (netErrors->peerNoAnswerError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_PeerNoAnswer,
					netErrors->peerNoAnswerError);
    if (netErrors->serverHandshakeError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_ServerHandshake,
					netErrors->serverHandshakeError);
    if (netErrors->peerHandshakeError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_PeerHandshake,
					netErrors->peerHandshakeError);
    if (netErrors->serverX25NoServiceError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_X25NoService,
					netErrors->serverX25NoServiceError);
    if (netErrors->callWaitingError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_CallWaitingError,
					netErrors->callWaitingError);
    if (netErrors->remoteCallWaitingError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_RemoteCallWaitingError,
					netErrors->remoteCallWaitingError);
    if (netErrors->scriptLoginError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_ScriptLogin,
					netErrors->scriptLoginError);
    if (netErrors->packetRetransError ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_PacketRetrans,
					netErrors->packetRetransError);
/*    if (netErrors->unused1 ) 
	printf("%s\t%d\t%d\n",header,  kdbLoad_NetError_UsedAltPop,
					netErrors->unused1);
    if (netErrors->unused2 ) 
	printf("%s\t%d\t%d\n", header, kdbLoad_NetError_ctsTimeout,
					netErrors->unused2);
*/

    }
}

//****************************************************************************
//**** V4 vector routines ****************************************************
// V4 is the same as V3 but the Game Error results are filled in instead of
// being truncated at the size of a NewGameResult.
//****************************************************************************
int
VMOutputdb_v5(VectorMachineVersion *vmv, char *param)
{
    param += VMProcessLoginInfodbLoad_v3(vmv, param);
    param += VMProcessConnCarrierdbLoad_v3(vmv, param);
    param += VMProcessConnTypedbLoad_v3(vmv, param);
    param += VMProcessCrashRecorddbLoad_v3(vmv, param);
    param += VMProcessGameResultsdbLoad_v5(vmv, param);
    param += VMProcessGameErrorResultsdbLoad_v5(vmv, param);
    param += VMProcess800NetErrorsdbLoad_v3(vmv, param);
    param += VMProcessX25NetErrorsdbLoad_v3(vmv, param);
    param += VMProcessStreamErrorReportdbLoad_v3(vmv, param);
	
	return kNoErr;
}

int
VMProcessGameResultsdbLoad_v5(VectorMachineVersion *vmv, char *param)
{
V5MachineGlobs		*g = vmv->globals;

    if (g->flags.gameResults) {
		return PrintGenericGameResult_dbLoad_v5((NewGameResult *)param, 
			cdbLoad_GameResults);
		}
	
    return 0;
}

int
VMProcessGameErrorResultsdbLoad_v5(VectorMachineVersion *vmv, char *param)
{
V5MachineGlobs          *g = vmv->globals;
NewGameResult           *gameResult = (NewGameResult *)param;
int                                     size = 0;


    if (g->flags.gameErrorResults) {
		size = PrintGenericGameResult_dbLoad_v5((NewGameResult *)param, 
			cdbLoad_GameErrorResults);
 		if (gameResult->dbIDDataSize) 
                        size += gameResult->dbIDDataSize;
		}
	
	return size;
}

int
PrintGenericGameResult_dbLoad_v5(NewGameResult *gameResult, char *header)
{
	long     structSize, extraSize;

	printf(header);
	structSize = ((unsigned char *)&gameResult->pad) -
				((unsigned char *)gameResult);

	if (gameResult->size < structSize) {
		printf("%d\t%d\n", kdbLoad_GameResultsIncomplete,
				gameResult->size);
		return gameResult->size;
		}
	else {
		printf("%d\t%d\t", kdbLoad_GameResultsComplete,
				gameResult->size);
	     }
		
		
	printf("0x%.8lx\t%s\t%d\t%d\t%d\t%ld\t",
		gameResult->gameID, Common_GameName('sega', gameResult->gameID),
		gameResult->gameError, gameResult->errorWhere,
		gameResult->connectPhase, gameResult->playTime);

	printf("%ld\t%ld\t%ld\t%ld\t",
		gameResult->localPlayer1Result, gameResult->localPlayer2Result,
		gameResult->remotePlayer1Result, gameResult->remotePlayer2Result);
	printf("%ld\t%ld\t%ld\t",
		gameResult->dbIDDataPtr, gameResult->dbIDDataSize,
		(long)gameResult->numLocalPlayers);

	printf("%-5d\t%-5d\t",
		gameResult->localGameError, gameResult->errorRecovers);

	printf("%-3d\t%-3d\t",
		gameResult->checksumErrors, gameResult->timeouts);

	printf("%-3d\t%-3d\t",
		gameResult->frameErrors, gameResult->overrunErrors);

	printf("\n");

	return (gameResult->size);

}


static char *
LogPhoneToStr(
    BlogPhoneNumber_v0 *phone
)
{
    static char buf[32];
    char        localNum[32];

    memset(buf, 0, 32);

    if (phone->areaCode > 0)
        sprintf(buf, "%d-", phone->areaCode);

    sprintf(localNum, "%d", phone->localNumber);
    if (strlen(localNum) == 7) {
        strncat(buf, localNum, 3);
        strcat(buf, "-");
        strncat(buf, localNum+3, 4);
    }

    return(buf);
}


int
VMOutputdb_v6(VectorMachineVersion *vmv, char *param)
{
    param += VMProcessLoginInfodbLoad_v3(vmv, param);
    param += VMProcessConnCarrierdbLoad_v3(vmv, param);
    param += VMProcessConnTypedbLoad_v3(vmv, param);
    param += VMProcessCrashRecorddbLoad_v3(vmv, param);
    param += VMProcessGameResultsdbLoad_v6(vmv, param);
    param += VMProcessGameErrorResultsdbLoad_v3(vmv, param);
    param += VMProcess800NetErrorsdbLoad_v3(vmv, param);
    param += VMProcessX25NetErrorsdbLoad_v3(vmv, param);
    param += VMProcessStreamErrorReportdbLoad_v3(vmv, param);

    param += VMProcessSendQGameErrorResultsdbLoad_v6(vmv, param);
    param += VMProcessSendQBoxErrordbLoad_v6(vmv, param);
        
        return kNoErr;
}

int
VMProcessSendQGameErrorResultsdbLoad_v6(VectorMachineVersion *vmv, char *param)
{
V6MachineGlobs		*g = vmv->globals;

	if (g->flags.gameSendQErrors) {


                dbDumpGameResultSendQ(kPlatformGenesis, param+sizeof(long), 
				*((long *)param));

		return (*(long *)param)+4;
		}
	else
		return 0;
}

int
VMProcessGameResultsdbLoad_v6(VectorMachineVersion *vmv, char *param)
{
V4MachineGlobs		*g = vmv->globals;
NewGameResult		*ngr = (NewGameResult *)(param+4);
int					size;
	
    if (g->flags.gameResults) {
		size = ngr->size;
		PrintCreditChangeFlagsDb_v6((unsigned long *)param);
		PrintGenericGameResult_dbLoad_v3(ngr, cdbLoad_GameResults);
		
		// sometimes the server nulls out error results, it should 
		//   fix the size though.  For version 7!?!?
		if (!size)
			size = sizeof(NewGameResult);
			
		return size + 4;
		}
	
	return 0;
}

int
PrintCreditChangeFlagsDb_v6(unsigned long *param)
{
int                                     i;
 
        for (i = 0; i < NELEM(errNames2); i++) 
                if (*param & errNames2[i].err) { 
			printf(cdbLoad_CreditChanges);
			printf("%d\n", i);
                }
}


int
VMProcessSendQBoxErrordbLoad_v6(VectorMachineVersion *vmv, char *param)
{
V6MachineGlobs		*g = vmv->globals;
unsigned short		size, totalSize = 0;
short 				*localParam = (short *)param;

	if (g->flags.boxSendQErrors) {
		while (size = *localParam++) {
			((char *)localParam) += size;
			}
		return ((char *)localParam)-param;
		}
	else
		return 0;
}
