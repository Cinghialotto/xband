#ifndef lint
static char *sccsid = "$Id: BatteryCheck.c,v 1.6 1995/11/12 20:30:46 davej Exp $";
#endif /* lint */

/*
 * Copyright: @ 1994 Catapult Entertainment Inc., all rights reserved
 *
 * $Log: BatteryCheck.c,v $
 * Revision 1.6  1995/11/12  20:30:46  davej
 * Added new kBlogBillEcp and retrofitted kBlogBillPromo.
 *
 * Revision 1.5  1995/05/26  23:01:14  jhsia
 * switched to rcs keywords
 *
 */


#include <stdio.h>
#include "../include/logutil.h"
#include "../include/BatteryCheck.h"

extern int errno;
extern LogSessionParams gSessionParams;

VectorMachine sBatteryCheck = {
		"Bad Battery Search", 
			(kIsReadMachine | kUsesStandardFiltering), {
			// version zero
			EMPTYVERSION(0),
			
			// version one
			EMPTYVERSION(1),
			
			// version two
			EMPTYVERSION(2),
			
			// version three
			EMPTYVERSION(3),
			
			// version four
			{ 4, NULL,
				(VectorMachineInit)VMInit_v4, (VectorMachineConclude)VMConclude_v4, 
				(VectorMachineFilter)VMFilter_v4, (VectorMachineOutput)VMOutput_v4
			},
			
			// version five
			{ 5, NULL,
				(VectorMachineInit)VMInit_v4, (VectorMachineConclude)VMConclude_v4, 
				(VectorMachineFilter)VMFilter_v4, (VectorMachineOutput)VMOutput_v4
			},
			
			{ 6, NULL,
				(VectorMachineInit)VMInit_v4, (VectorMachineConclude)VMConclude_v4, 
				(VectorMachineFilter)VMFilter_v4, (VectorMachineOutput)VMOutput_v4
			}
		}
	};

//****************************************************************************
//**** V4 vector routines ****************************************************
//****************************************************************************
static int
VMInit_v4(VectorMachineVersion *vmv)
{
	return kNoErr;
}

static int
VMConclude_v4(VectorMachineVersion *vmv)
{
	return kNoErr;
}

static Boolean
VMFilter_v4(VectorMachineVersion *vmv, char *blogRecord, VMFlagType *watchFlags)
{
BlogLoginInfo_v3 *loginInfo    = (BlogLoginInfo_v3 *)blogRecord;
VMFlagType flags = *watchFlags;
	
	if ((loginInfo->startTime < gSessionParams.startTime) ||
			(loginInfo->startTime > gSessionParams.endTime))
		return(false);
	
    if (flags == kVMFlagProcessAllConnections)
        return(true);

    if ((flags & kVMFlagProcessSpecifiedBox) && (loginInfo->boxInfo.serialNum.box == gSessionParams.boxNumber))
	return(true);

    if ((flags & kVMFlagProcessX25Connections) && (loginInfo->flags.x25Conn))
        return(true);

    if ((flags & kVMFlagProcess800Connections) && (!loginInfo->flags.x25Conn))
        return(true);

    if ((flags & kVMFlagProcessMailRequest) && (loginInfo->flags.mailOrGame == kBlogMail))
        return(true);

    if ((flags & kVMFlagProcessGameRequest) && (loginInfo->flags.mailOrGame == kBlogGame))
        return(true);

    if ((flags & kVMFlagProcessCrashRecord) && (loginInfo->flags.crashRecord))
        return(true);

    if ((flags & kVMFlagProcessGameResult) && (loginInfo->flags.gameResults))
        return(true);

    if ((flags & kVMFlagProcessGameResult) && (loginInfo->flags.gameErrorResults))
        return(true);

    if ((flags & kVMFlagProcessNetErrors) && (loginInfo->flags.netErrors800))
        return(true);

    if ((flags & kVMFlagProcessNetErrors) && (loginInfo->flags.netErrorsX25))
        return(true);

    if ((flags & kVMFlagProcessStreamError) && (loginInfo->flags.streamError))
        return(true);

    return(false);
}

static int
VMOutput_v4(VectorMachineVersion *vmv, char *param)
{
BlogLoginInfo_v3		*loginInfo;
GameIDData	     		*gameID;
BlogOpponentInfo_v0		*opponentInfo;
unsigned char			*cp;
int						i, count;

	loginInfo = (BlogLoginInfo_v3 *)param;
    param += sizeof(BlogLoginInfo_v3);
	
	if (loginInfo->flags.x25Conn)
		param += sizeof(BlogPopInfo_v0);

	if (loginInfo->flags.mailOrGame == kBlogGame) {
		gameID = (GameIDData *)param;
		param += sizeof(GameIDData);
		
		if (loginInfo->flags.dialOrWait == kBlogDial) {
			opponentInfo = (BlogOpponentInfo_v0 *)param;
			param += sizeof(BlogOpponentInfo_v0);
			}
		else if (loginInfo->flags.dialOrWait == kBlogWait) {
			param += sizeof(long);
			}
		}
		
    if (loginInfo->flags.crashRecord) {
		cp = param;
		count = 0;
		for (i=0; i<sizeof(struct BoxRestartInfo); i+=1) {	
			if (*cp == 0xff) count += 1;
			}
		if (count > (sizeof(struct BoxRestartInfo) *.95))
			PrintConnRec_v4(loginInfo, gameID, opponentInfo);
		}
		
	return kNoErr;
}


// needs a ConnRec structure consisting of loginInfo, gameInfo, gameResult, and opponentInfo
static void
PrintConnRec_v4
(BlogLoginInfo_v3 *loginInfo, GameIDData *gameInfo, BlogOpponentInfo_v0 *opponentInfo)
{
    char		timeBuf[64];	
    char		nameBuf[128];
    char		phoneBuf[32];
    char		errorBuf[16];

    strftime(timeBuf, 64, "%X", localtime(&loginInfo->startTime));

    if (!loginInfo->flags.validLogin) {
	printf("%-10s Login Information not available: exit status = %s\n",
	    timeBuf, ExitToStr(loginInfo->exitStatus));
	return;
    }

    if (LogIsRealCustomer(loginInfo->billingType) == true)
        sprintf(nameBuf, ":REAL:'%s'", loginInfo->nameStr);
    else
        sprintf(nameBuf, "'%s'", loginInfo->nameStr);

    sprintf(phoneBuf, LogPhoneToStr(&loginInfo->callingNumber));

    if (!loginInfo->flags.x25Conn) {
	printf("%-10s 800 connect from %s (%s)\n", timeBuf, nameBuf, phoneBuf);
	return;
    }


    if (loginInfo->flags.validAccount) {
	if (loginInfo->flags.accountCreation == kBlogPlayerCreated)
	    printf("%-10s %s - New Player created \n", timeBuf, nameBuf);
	else if (loginInfo->flags.accountCreation == kBlogAccountCreated)
	    printf("%-10s %s - New Account created \n", timeBuf, nameBuf);
    }



    if (loginInfo->flags.mailOrGame == kBlogMail) {
	printf("%-10s Mail-only connect from %s (%s)", timeBuf, nameBuf, phoneBuf);
    } else if (loginInfo->flags.mailOrGame == kBlogGame) {
	printf("%-10s %s (%s)", timeBuf, nameBuf, phoneBuf);
	if (loginInfo->flags.dialOrWait == kBlogDial) {
	    printf(" told to dial [%d] (%s) for",
		opponentInfo->boxInfo.serialNum.box,
		LogPhoneToStr(&opponentInfo->phone));
	} else if (loginInfo->flags.dialOrWait == kBlogWait) {
	    printf(" waiting for");
	} else 
	    printf(" unknown dial/wait status for");

	printf(" %s", Common_GameName(gameInfo->gameID));

	if (loginInfo->flags.autoOrChall == kBlogChallenge)
	    printf(" - challenge request");
    } else {
	printf("%-10s %s (%s) - unknown mail-connect/game-request status", 
	    timeBuf, nameBuf, phoneBuf); 
    }

    if (loginInfo->exitStatus != kConnExitGraceful)
	printf(" *** %s ***", ExitToStr(loginInfo->exitStatus));

    printf("\n");
}


static char *
ExitToStr(
    unsigned char status
)
{
    switch(status) {
	case kConnExitUnknown:
		return("unknown");
	case kConnExitGraceful:
		return("normal termination");
	case kConnNeverConnected:
		return("never connected");
	case kConnExitServerAbort:
		return("server aborted midway.");
	case kConnExitSighup:
		return("premature SIGHUP");
	case kConnExitTimeout:
		return("timed out");
	case kConnExitGenericSignal:
		return("generic signal");
	case kConnExitRpcAbort:
		return("RPC abort");
	default:
		return("unknown");
    }
}

static Boolean
LogIsRealCustomer(
    unsigned billingType
)
{
    switch(billingType) {
        case kBlogBillPrepaid :
        case kBlogBillInvoice:
        case kBlogBillDebit :
        case kBlogBillVisa :
        case kBlogBillMcard:
        case kBlogBillAmex:
        case kBlogBillSmartc:
        case kBlogBillSubord:
        case kBlogBillEcp:
                return(true);
        case kBlogBillBeta :
        case kBlogBillInternal:
        case kBlogBillGuest:
        case kBlogBillPromo:
        case kBlogBillUndefined:
        default:
                return(false);
    }
}


