#ifndef lint
static char *sccsid = "$Id: CursesMachine.c,v 1.7 1995/11/12 20:39:39 davej Exp $";
#endif /* lint */

/*
 * Copyright: @ 1994 Catapult Entertainment Inc., all rights reserved
 *
 * $Log: CursesMachine.c,v $
 * Revision 1.7  1995/11/12  20:39:39  davej
 * Added new kBlogBillEcp and retrofitted kBlogBillPromo.
 *
 * Revision 1.6  1995/05/26  23:01:16  jhsia
 * switched to rcs keywords
 *
 */
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <curses.h>

#undef reg		// blasted lazy curses programmers!

#include "../include/logutil.h"
#include "../include/CursesMachine.h"

extern int errno;
extern LogSessionParams gSessionParams;

VectorMachine sCursesMachine = {
		"Scoreboard Style Generator", 
		 (kIsChaseMachine), {
			// version zero
			EMPTYVERSION(0),
			
			// version one
			EMPTYVERSION(1),
			
			// version two
			EMPTYVERSION(2),
			
			// version three
			{ 3, NULL,
				(VectorMachineInit)VMCursesInit_v3, (VectorMachineConclude)VMCursesConclude_v3, 
				(VectorMachineFilter)VMCursesFilter_v3, (VectorMachineOutput)VMCursesOutput_v3, 
			},

			// version four
			{ 4, NULL,
				(VectorMachineInit)VMCursesInit_v3, (VectorMachineConclude)VMCursesConclude_v3, 
				(VectorMachineFilter)VMCursesFilter_v3, (VectorMachineOutput)VMCursesOutput_v3, 
			},

			// version five
			{ 5, NULL,
				(VectorMachineInit)VMCursesInit_v3, (VectorMachineConclude)VMCursesConclude_v3, 
				(VectorMachineFilter)VMCursesFilter_v3, (VectorMachineOutput)VMCursesOutput_v3, 
			},
			{ 6, NULL,
				(VectorMachineInit)VMCursesInit_v3, (VectorMachineConclude)VMCursesConclude_v3, 
				(VectorMachineFilter)VMCursesFilter_v3, (VectorMachineOutput)VMCursesOutput_v3, 
			}
		}
	};


static void
ScreenInitialize(
	V3CursesMachineGlobs *sessionInfo
)
{
	sessionInfo->win = initscr();;
	mvwprintw(sessionInfo->win, LINES/2, 0, 
		"Processing %s - hold on ....", sessionInfo->fileName);
	wrefresh(sessionInfo->win);

	// This is more efficient than calling werase() for the 
	// entire window.
	wmove(sessionInfo->win, LINES/2, 0);
	wclrtoeol(sessionInfo->win);
}

static void
ScreenCleanup(void)
{
	endwin();
}


static void
RedisplayScreen(
	V3CursesMachineGlobs *sessionInfo
)
{
	mvwprintw(sessionInfo->win, 0, 0, "\n%s\n", sessionInfo->date);

	wprintw(sessionInfo->win, "%-25s%-10s\n",
		"CONNECTION TYPE", "COUNT");
	wprintw(sessionInfo->win, "%-25s%-10s\n",
		"---------------", "-----");

	wprintw(sessionInfo->win, "%-25s%-10d\n",
		"X25 Connections", sessionInfo->ConnX25);

	wprintw(sessionInfo->win, "%-25s%-10d\n",
		"Real Customer logins", sessionInfo->real);

	wprintw(sessionInfo->win, "%-25s%-10d\n",
		"New Account logins", sessionInfo->newAccount);

	wprintw(sessionInfo->win, "%-25s%-10d\n",
		"Mail Connections", sessionInfo->mail);

	wprintw(sessionInfo->win, "%-25s%-10d\n",
		"Game Connections", sessionInfo->game);

	wprintw(sessionInfo->win, "%-25s%-10d\n",
		"Server Connect Errors", sessionInfo->sighups);

	wprintw(sessionInfo->win, "%-25s%-10d\n",
		"800 Connections", sessionInfo->Conn800);

	// wmove(sessionInfo->win, LINES, 0);
	// leaveok(sessionInfo->win, TRUE);
	wrefresh(sessionInfo->win);
}

static void
DoSessionMidnight(
	V3CursesMachineGlobs *sessionInfo
)
{
	struct tm	*tm;

	tm = localtime(&sessionInfo->endOfDay);
	strftime(sessionInfo->date, kDateLen, "%b %d %Y", tm);

	sessionInfo->endOfDay		+= kSecondsInDay;
	sessionInfo->totalConn		= 0;
	sessionInfo->real			= 0;
	sessionInfo->ConnX25		= 0;
	sessionInfo->Conn800		= 0;
	sessionInfo->mail			= 0;
	sessionInfo->game			= 0;
	sessionInfo->sighups		= 0;
	sessionInfo->newAccount 	= 0;
}
	


static time_t
findMidnight(void)
{
	time_t		now;
	struct tm	*tm;

	now = time(NULL);
	tm	= localtime(&now);

	tm->tm_sec	= 0;
	tm->tm_min	= 0;
	tm->tm_hour = 0;

	return(mktime(tm));
}


int
VMCursesInit_v3(VectorMachineVersion *vmv)
{
V3CursesMachineGlobs 		*sessionInfo;
struct tm					*tm;
LogSessionParams			logParams;

	vmv->globals = (void *)malloc(sizeof(V3CursesMachineGlobs));
	if (vmv->globals) {
		memset(vmv->globals, 0, sizeof(V3CursesMachineGlobs));
		}
	else
		return kInitFailed;
	
	sessionInfo = (V3CursesMachineGlobs *)vmv->globals;
	logParams.chase 	= 1;
	logParams.startTime = findMidnight();
	logParams.endTime	= kDefaultEndTime;

	sessionInfo->endOfDay = logParams.startTime + kSecondsInDay;
	// we can reinit these here, kinda skanky but readlog doesn't care as long
	// as we are in the init phase.
	LogSessionInitialize(&logParams);

	tm = localtime(&logParams.startTime);
	strftime(sessionInfo->date, kDateLen, "%b %d %Y", tm);

	ScreenInitialize(sessionInfo);

	return kNoErr;
}

int
VMCursesConclude_v3(VectorMachineVersion *vmv)
{
	ScreenCleanup();
	free(vmv->globals);
	return kNoErr;
}

Boolean
VMCursesFilter_v3(VectorMachineVersion *vmv, char *blogRecord, VMFlagType *watchFlags)
{
BlogLoginInfo_v3 *loginInfo    = (BlogLoginInfo_v3 *)blogRecord;

	if ((loginInfo->startTime < gSessionParams.startTime) ||
			(loginInfo->startTime > gSessionParams.endTime))
		return(false);

	return true;
}

int
VMCursesOutput_v3(VectorMachineVersion *vmv, char *param)
{
V3CursesMachineGlobs *sessionInfo = (V3CursesMachineGlobs *)vmv->globals;
BlogLoginInfo_v3	*loginInfo = (BlogLoginInfo_v3 *)param;

	if (loginInfo->startTime >= sessionInfo->endOfDay)
		DoSessionMidnight(sessionInfo);
	
	++sessionInfo->totalConn;
	
	if (loginInfo->flags.x25Conn)
		++sessionInfo->ConnX25;
	else
		++sessionInfo->Conn800;
	
	if (LogIsRealCustomer(loginInfo->billingType) == true)
		++sessionInfo->real;
	
	if (loginInfo->exitStatus != kConnExitGraceful)
		++sessionInfo->sighups;
	
	if (loginInfo->flags.validAccount &&
			(loginInfo->flags.accountCreation == kBlogAccountCreated))
		++sessionInfo->newAccount;
	
	if (loginInfo->flags.mailOrGame == kBlogGame) 
		++sessionInfo->game;
	else if (loginInfo->flags.mailOrGame == kBlogMail)
		++sessionInfo->mail;
	
	RedisplayScreen(sessionInfo);
	
	return kNoErr;
}


static Boolean
LogIsRealCustomer(
    unsigned billingType
)
{
    switch(billingType) {
        case kBlogBillPrepaid :
        case kBlogBillInvoice:
        case kBlogBillDebit :
        case kBlogBillVisa :
        case kBlogBillMcard:
        case kBlogBillAmex:
        case kBlogBillSmartc:
        case kBlogBillSubord:
        case kBlogBillEcp:
                return(true);
        case kBlogBillBeta :
        case kBlogBillInternal:
        case kBlogBillGuest:
        case kBlogBillPromo:
        case kBlogBillUndefined:
        default:
                return(false);
    }
}

