#ifndef lint
static char *sccsid = "$Id: StdioMachine.c,v 1.19 1995/11/12 20:39:40 davej Exp $";
#endif /* lint */

/*
 * Copyright: @ 1994 Catapult Entertainment Inc., all rights reserved
 *
 * $Log: StdioMachine.c,v $
 * Revision 1.19  1995/11/12  20:39:40  davej
 * Added new kBlogBillEcp and retrofitted kBlogBillPromo.
 *
 * Revision 1.18  1995/05/26  23:01:19  jhsia
 * switched to rcs keywords
 *
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include "../include/logutil.h"
#include "../include/StdioMachine.h"
#include "../include/StdioGameSpecific.h"
#include "ServerCore.h"

#define kDelimiter	"\n*************************************************\n\n"

extern int errno;
extern LogSessionParams gSessionParams;


# define NELEM(x)       (sizeof(x) / sizeof(x[0]))

VectorMachine sStdioMachine = {
		"Verbose Stdio Generator", 
		 (kIsReadMachine | kIsChaseMachine | kUsesStandardFiltering), {
			// version zero
			EMPTYVERSION(0),
			
			// version one
			EMPTYVERSION(1),
			
			// version two
			EMPTYVERSION(2),
			
			// version three
			{ 3, NULL,
				(VectorMachineInit)VMInit_v3, (VectorMachineConclude)VMConclude_v3, 
				(VectorMachineFilter)VMFilter_v3, (VectorMachineOutput)VMOutput_v3 
			},
			
			// version four
			{ 4, NULL,
				(VectorMachineInit)VMInit_v4, (VectorMachineConclude)VMConclude_v4, 
				(VectorMachineFilter)VMFilter_v3, (VectorMachineOutput)VMOutput_v4 
			},
			
			// version five
			{ 5, NULL,
				(VectorMachineInit)VMInit_v5, (VectorMachineConclude)VMConclude_v5, 
				(VectorMachineFilter)VMFilter_v3, (VectorMachineOutput)VMOutput_v5 
			},
			
			// version six
			{ 6, NULL,
				(VectorMachineInit)VMInit_v6, (VectorMachineConclude)VMConclude_v6, 
				(VectorMachineFilter)VMFilter_v3, (VectorMachineOutput)VMOutput_v6 
			}
		}
	};


// strings for evil reset detection
struct {
	short	err;
	char	*name;
	} errNames[] = {
		{ kCreditChange_Deduct_SuccessfulGame, "Deduct_SuccessfulGame" },
		{ kCreditChange_Deduct_OnQueue, "Deduct_OnQueue" },
		{ kCreditChange_Deduct_EvilReset, "Deduct_EvilReset" },
		{ kCreditChange_Deduct_EvilCW, "Deduct_EvilCW" },
		{ kCreditChange_Deduct_WaitReset, "Deduct_WaitReset" },
		{ kCreditChange_Deduct_MailOnly, "Deduct_MailOnly" },
		{ kCreditChange_Deduct_HosedSpecific, "Deduct_HosedSpecific" },
		{ kCreditChange_Deduct_HosedAuto, "Deduct_HosedAuto" },
		{ kCreditChange_Penalize_WaitReset, "Penalize_WaitReset" },
		{ kCreditChange_Penalize_EvilReset, "Penalize_EvilReset" },
		{ kCreditChange_Penalize_PasswordCode, "Penalize_PasswordCode" }
};


//****************************************************************************
//**** V3 vector routines ****************************************************
//**** Copy from here down as template for new machine or version ************
//****************************************************************************
int
VMInit_v3(VectorMachineVersion *vmv)
{
	vmv->globals = (void *)malloc(sizeof(V3MachineGlobs));
	if (vmv->globals) {
		memset(vmv->globals, 0, sizeof(V3MachineGlobs));
		return kNoErr;
		}
	else
		return kInitFailed;
}

int
VMConclude_v3(VectorMachineVersion *vmv)
{
	free(vmv->globals);
	return kNoErr;
}

Boolean
VMFilter_v3(VectorMachineVersion *vmv, char *blogRecord, VMFlagType *watchFlags)
{
BlogLoginInfo_v3 *loginInfo    = (BlogLoginInfo_v3 *)blogRecord;
VMFlagType flags = *watchFlags;
	
	if ((loginInfo->startTime < gSessionParams.startTime) ||
			(loginInfo->startTime > gSessionParams.endTime))
		return(false);

    if (flags == kVMFlagProcessAllConnections)
        return(true);

    if ((flags & kVMFlagProcessSpecifiedBox) && (loginInfo->boxInfo.serialNum.box != gSessionParams.boxNumber))
	return(false);

    if ((flags & kVMFlagProcessX25Connections) && (loginInfo->flags.x25Conn))
        return(true);

    if ((flags & kVMFlagProcess800Connections) && (!loginInfo->flags.x25Conn))
        return(true);

    if ((flags & kVMFlagProcessMailRequest) && (loginInfo->flags.mailOrGame == kBlogMail))
        return(true);

    if ((flags & kVMFlagProcessGameRequest) && (loginInfo->flags.mailOrGame == kBlogGame))
        return(true);

    if ((flags & kVMFlagProcessCrashRecord) && (loginInfo->flags.crashRecord))
        return(true);

    if ((flags & kVMFlagProcessGameResult) && (loginInfo->flags.gameResults))
        return(true);

    if ((flags & kVMFlagProcessGameResult) && (loginInfo->flags.gameErrorResults))
        return(true);

    if ((flags & kVMFlagProcessNetErrors) && (loginInfo->flags.netErrors800))
        return(true);

    if ((flags & kVMFlagProcessNetErrors) && (loginInfo->flags.netErrorsX25))
        return(true);

    if ((flags & kVMFlagProcessStreamError) && (loginInfo->flags.streamError))
        return(true);

    return(false);
}

int
VMOutput_v3(VectorMachineVersion *vmv, char *param)
{
	printf("%s", kDelimiter);
    param += VMProcessLoginInfoStdio_v3(vmv, param);
    param += VMProcessConnCarrierStdio_v3(vmv, param);
    param += VMProcessConnTypeStdio_v3(vmv, param);
    param += VMProcessCrashRecordStdio_v3(vmv, param);
    param += VMProcessGameResultsStdio_v3(vmv, param);
    param += VMProcessGameErrorResultsStdio_v3(vmv, param);
    param += VMProcess800NetErrorsStdio_v3(vmv, param);
    param += VMProcessX25NetErrorsStdio_v3(vmv, param);
    param += VMProcessStreamErrorReportStdio_v3(vmv, param);
	printf("%s", kDelimiter);
	
	return kNoErr;
}

int
VMProcessLoginInfoStdio_v3(VectorMachineVersion *vmv, char *param)
{
BlogLoginInfo_v3	*loginInfo = (BlogLoginInfo_v3 *)param;
char				nameBuf[128];
V3MachineGlobs		*g = vmv->globals;
struct hostent          *h;

	
    printf("Connection Info:\n");

	printf("\tBlog Size   = %d\n", loginInfo->size);
	printf("\tversion     = %d\n", loginInfo->version);

	// modify global state;
	g->flags = loginInfo->flags;

	// figure out the machine this record came from
	h = gethostbyaddr(&loginInfo->hostAddr, 4, AF_INET);
	printf("\tServer host name  = %s\n", h->h_name);

	if (loginInfo->flags.validLogin) {
		printf("\tStart time  = %s", ctime(&(loginInfo->startTime)));
		printf("\tDuration    = %d secs\n", loginInfo->duration);
		printf("\tExit status = %s\n", ExitToStr(loginInfo->exitStatus));
		printf("Login Info:\n");
		
		if (LogIsRealCustomer(loginInfo->billingType) == true)
			sprintf(nameBuf, "'%s' :REAL:", loginInfo->nameStr);
		else
			sprintf(nameBuf, "'%s'", loginInfo->nameStr);
		
		printf("\tName  = %s\n", nameBuf);
		printf("\tPhone = %s\n", LogPhoneToStr(&loginInfo->callingNumber));
		printf("\tBox info = (%d,%d) [%d]\n", 
		loginInfo->boxInfo.serialNum.box, 
		loginInfo->boxInfo.serialNum.region,
		loginInfo->boxInfo.userNum);

		if (loginInfo->flags.validAccount) {
			printf("\tBilling type = %s\n", 
			BillingTypeToString(loginInfo->billingType));
			if (loginInfo->flags.accountCreation == kBlogPlayerCreated)
				printf("\tNew Player created \n");
			else if (loginInfo->flags.accountCreation == kBlogAccountCreated)
				printf("\tNew Account created \n");
			}
		}
	else {
		printf("\tStart time  = %s", ctime(&(loginInfo->startTime)));
		printf("\tLogin Information not available\n");
		printf("\tExit status = %s\n", ExitToStr(loginInfo->exitStatus));
		}
	return sizeof(BlogLoginInfo_v3);
}

int
VMProcessConnCarrierStdio_v3(VectorMachineVersion *vmv, char *param)
{
BlogPopInfo_v0   	*pop = (BlogPopInfo_v0 *)param;
V3MachineGlobs		*g = vmv->globals;
		
	if (g->flags.x25Conn) {
		if (gSessionParams.outputFilterFlags & kVMFlagProcessX25Connections) {
			printf("X25 info:\n");
			printf("\tx25 addr = %s\n", pop->x25Addr);
			printf("\tmain pop = %s\n", LogPhoneToStr(&pop->main));
			printf("\talt pop  = %s\n", LogPhoneToStr(&pop->alt));
			}
		return sizeof(BlogPopInfo_v0);
		}
	else if (gSessionParams.outputFilterFlags & kVMFlagProcess800Connections)
		printf("This is an 800 connection\n");
		
	return 0;
}

int
VMProcessConnTypeStdio_v3(VectorMachineVersion *vmv, char *param)
{
V3MachineGlobs		*g = vmv->globals;
char				*localParam = param;

	if (gSessionParams.outputFilterFlags & kVMFlagProcessGameRequest) 
		printf("Connection type:\n");

	if (g->flags.mailOrGame == kBlogGame) {
		GameIDData *gameID	= (GameIDData *)localParam;
		localParam += sizeof(GameIDData);
		
		if (gSessionParams.outputFilterFlags & kVMFlagProcessGameRequest) {
			if (g->flags.autoOrChall == kBlogAutomatch)
				printf("\tAutomatch game request\n");
			else if (g->flags.autoOrChall == kBlogChallenge)
				printf("\tChallenge game request\n");
			else
				printf("\tAutomatch or Challenge unknown\n");
			
			printf("\tgameID = 0x%.8lx (%s), version = %ld\n", gameID->gameID,
			Common_GameName('sega', gameID->gameID), gameID->version);
			}
			
		if (g->flags.dialOrWait == kBlogDial) {
			BlogOpponentInfo_v0 *opponent = (BlogOpponentInfo_v0 *)localParam;
			localParam += sizeof(BlogOpponentInfo_v0);
			
			if (gSessionParams.outputFilterFlags & kVMFlagProcessGameRequest) {
				printf("\tTold to dial opponent with cookie %d\n", opponent->cookie);
				printf("Opponent info:\n");
				printf("\tBox info = (%d,%d) [%d]\n",
				opponent->boxInfo.serialNum.box,
				opponent->boxInfo.serialNum.region,
				opponent->boxInfo.userNum);
				printf("\tphone = %s\n", LogPhoneToStr(&opponent->phone));
				}
			}
		else if (g->flags.dialOrWait == kBlogWait) {
			if (gSessionParams.outputFilterFlags & kVMFlagProcessGameRequest) {
				printf("\tTold to wait for opponent with cookie %d\n", *(long *)localParam);
				}
			localParam += sizeof(long);
			}
		else if (gSessionParams.outputFilterFlags & kVMFlagProcessGameRequest) {
			printf("\tDial or wait status unknown\n");
			}
		}
	else if (g->flags.mailOrGame == kBlogMail)
		if (gSessionParams.outputFilterFlags & kVMFlagProcessMailRequest) {
			printf("\tMail only connection\n");
			}
	else 
		printf("\tMail or game request: status unknown\n");
		
	return localParam-param;
}

int
VMProcessCrashRecordStdio_v3(VectorMachineVersion *vmv, char *param)
{
V3MachineGlobs			*g = vmv->globals;
unsigned long			addr, dispNum;
int						count;
struct BoxRestartInfo	*cr = (struct BoxRestartInfo *)param;

    if (!g->flags.crashRecord) 
		return 0;
	
	if (gSessionParams.outputFilterFlags & kVMFlagProcessCrashRecord) {
		printf("Crash record: \n");
	
		printf("\tD0-D3:  %.8lX %.8lX %.8lX %.8lX\n",
			cr->reg[ 0], cr->reg[ 1], cr->reg[ 2], cr->reg[ 3]);
		printf("\tD4-D7:  %.8lX %.8lX %.8lX %.8lX\n",
			cr->reg[ 4], cr->reg[ 5], cr->reg[ 6], cr->reg[ 7]);
		printf("\tA0-A3:  %.8lX %.8lX %.8lX %.8lX\n",
			cr->reg[ 8], cr->reg[ 9], cr->reg[10], cr->reg[11]);
		printf("\tA4-A7:  %.8lX %.8lX %.8lX %.8lX\n",
			cr->reg[12], cr->reg[13], cr->reg[14], cr->reg[15]);
	
		if (cr->excCode == kBusError)	{
			addr = (cr->excAddr[0] << 16) | (cr->excAddr[1]);
			
			printf("\tBus Error, mode %X, addr %.8lX, instr %x\n",
				cr->excMode, addr, cr->excInstrReg);
		}
		
		addr = (cr->excPC[0] << 16) | (cr->excPC[1]);
		printf("\tStatus Reg %X, Exception PC %.8lX, Exception Code %x\n",
			cr->excSR, addr, cr->excCode);
		
		if (cr->unstablePC < 0)
			printf("\tOS WAS UNSTABLE, from PC %.8lx\n",
				cr->unstablePC);
		else
			printf("\tos was stable, from PC %.8lx\n",
				cr->unstablePC);
	
		printf("\tdispatched calls:  ");
		printf("\n");
		for (count = 0; count < kHistorySize; ++count) {
			dispNum = cr->histCallNums[count] / 4;
			printf("\t\t%2d: %d (%s)\n", count, dispNum,
				(dispNum >= 0 && dispNum < NELEM(dispCallStrs)) ?
					dispCallStrs[dispNum] : "(invalid)");
		}
	
		printf("\n");
		printf("\tcalled from PC's:  ");
		for (count = 0; count < kHistorySize; ++count)	{
			printf("\t%8lX ", cr->histCallers[count]);
			if (count == 3) {
				printf("\n");
				printf("\t                   ");
			}
		}
		printf("\n");
	
		printf("\tprevEntry/2:  %X   OS state:  %X   Stack low water:  %.8lX\n",
			cr->prevEntry/2, cr->osState, cr->stackLowWater);
	
		printf("\tstartupFlags:  %.8lX   boxState:  %.8lX   lastBoxState:  %.8lX\n",
			cr->startupFlags, cr->boxState, cr->lastBoxState);
		
		printf("\tBox id's:  Set [ %ld, %ld ]  Cold [ %ld, %ld ]  Warm [ %ld, %ld ] \n",
			cr->setBoxID.box, cr->setBoxID.region, 
			cr->coldBoxID.box, cr->coldBoxID.region, 
			cr->warmBoxID.box, cr->warmBoxID.region);
		}
		
	return sizeof(struct BoxRestartInfo);
}

int
VMProcessGameResultsStdio_v3(VectorMachineVersion *vmv, char *param)
{
V3MachineGlobs		*g = vmv->globals;

    if (g->flags.gameResults) {
		if (gSessionParams.outputFilterFlags & kVMFlagProcessGameResult) {
			PrintGenericGameResult_v3((NewGameResult *)param, "Game results: \n");
			}
		return sizeof(NewGameResult);
		}
	
	return 0;
}

int
VMProcessGameErrorResultsStdio_v3(VectorMachineVersion *vmv, char *param)
{
V3MachineGlobs		*g = vmv->globals;

    if (g->flags.gameErrorResults) {
		if (gSessionParams.outputFilterFlags & kVMFlagProcessGameResult) {
			PrintGenericGameResult_v3((NewGameResult *)param, "Game error results: \n");
			}
		return sizeof(NewGameResult);
		}
	
	return 0;
}

int
VMProcess800NetErrorsStdio_v3(VectorMachineVersion *vmv, char *param)
{
V3MachineGlobs		*g = vmv->globals;

    if (g->flags.netErrors800) {
		if (gSessionParams.outputFilterFlags & kVMFlagProcessNetErrors) {
			PrintGenericNetErrors_v3((NetErrorRecord *)param, "Box net 800: \n");
			}
		return sizeof(NetErrorRecord);
		}
	return 0;
}

int
VMProcessX25NetErrorsStdio_v3(VectorMachineVersion *vmv, char *param)
{
V3MachineGlobs		*g = vmv->globals;

    if (g->flags.netErrorsX25) {
		if (gSessionParams.outputFilterFlags & kVMFlagProcessNetErrors) {
			PrintGenericNetErrors_v3((NetErrorRecord *)param, "Box net X25: \n");
			}
		return sizeof(NetErrorRecord);
		}
	return 0;
}

int
VMProcessStreamErrorReportStdio_v3(VectorMachineVersion *vmv, char *param)
{
V3MachineGlobs		*g = vmv->globals;
StreamErrorReport	*streamError = (StreamErrorReport *)param;

    if (g->flags.streamError) {
		if (gSessionParams.outputFilterFlags & kVMFlagProcessStreamError) {
			printf("Stream error report:\n");
			printf("\tversion=%-2d checkErr=%-5d openErr=%-5d lastOpcode=%-5d\n",
				streamError->version, streamError->checkErr, 
				streamError->openErr, streamError->lastOpcode);
			}
		return sizeof(StreamErrorReport);
    	}
	return 0;
}

void
PrintGenericGameResult_v3(NewGameResult *gameResult, char *header)
{
	long     structSize, extraSize;

	printf(header);
	structSize = ((unsigned char *)&gameResult->pad) -
				((unsigned char *)gameResult);

	if (gameResult->size < structSize) {
		printf("\tRunt game result, size=%d\n", gameResult->size);
		return;
		}
		
	printf("\tgameID=0x%.8lx (%s) gameError=%d/%d/%d  playTime=%ld\n",
		gameResult->gameID, Common_GameName('sega', gameResult->gameID),
		gameResult->gameError, gameResult->errorWhere,
		gameResult->connectPhase, gameResult->playTime);
	printf("\tlocal1=%ld  local2=%ld  remote1=%ld  remote2=%ld\n",
		gameResult->localPlayer1Result, gameResult->localPlayer2Result,
		gameResult->remotePlayer1Result, gameResult->remotePlayer2Result);
	printf("\tdbIDDataPtr=%ld  dbIDDataSize=%ld  numPlayers=%ld gameReserved:\n",
		gameResult->dbIDDataPtr, gameResult->dbIDDataSize,
		(long)gameResult->numLocalPlayers);
	printf("\tlocalGameError: %-5d  errorRecovers: %-5d\n",
		gameResult->localGameError, gameResult->errorRecovers);
	printf("\tchecksumErrors: %-3d    timeouts: %-3d\n",
		gameResult->checksumErrors, gameResult->timeouts);
	printf("\tframeErrors: %-3d       overrunErrors: %-3d\n",
		gameResult->frameErrors, gameResult->overrunErrors);
	LogHexDump((unsigned char *) &gameResult->gameReserved,
		sizeof(gameResult->gameReserved));

	extraSize = gameResult->size - structSize;
	extraSize -= 2;		// guess we need this

	// do a sanity check so we don't go nuts
	if (extraSize < 0 || extraSize > 1024) {
		fprintf(stderr, "extraSize = %ld, wrong!\n", extraSize);
		return;
	}
	if (extraSize) {
		printf("\tExtra stuff (%ld bytes):\n", extraSize);
		LogHexDump((unsigned char *)&gameResult->pad, extraSize);
	} else {
		printf("\tNo extra stuff\n");
	}
}

void
PrintGenericNetErrors_v3(NetErrorRecord *netErrors, char *header)
{
	printf(header);
    printf("\t serverConnects = %d\n", netErrors->serverConnects);
    printf("\t peerConnects = %d\n", netErrors->peerConnects);
    if (netErrors->framingError) printf("\t framingError = %d\n", netErrors->framingError);
    if (netErrors->overrunError ) printf("\t overrunError = %d\n", netErrors->overrunError);
    if (netErrors->packetError ) printf("\t packetError = %d\n", netErrors->packetError);
    if (netErrors->callWaitingInterrupt ) printf("\t callWaitingInterrupt = %d\n", netErrors->callWaitingInterrupt);
    if (netErrors->noDialtoneError ) printf("\t noDialtoneError = %d\n", netErrors->noDialtoneError);
    if (netErrors->serverBusyError ) printf("\t serverBusyError = %d\n", netErrors->serverBusyError);
    if (netErrors->peerBusyError ) printf("\t peerBusyError = %d\n", netErrors->peerBusyError);
    if (netErrors->serverDisconnectError ) printf("\t serverDisconnectError = %d\n", netErrors->serverDisconnectError);
    if (netErrors->peerDisconnectError ) printf("\t peerDisconnectError = %d\n", netErrors->peerDisconnectError);
    if (netErrors->serverAbortError ) printf("\t serverAbortError = %d\n", netErrors->serverAbortError);
    if (netErrors->peerAbortError ) printf("\t peerAbortError = %d\n", netErrors->peerAbortError);
    if (netErrors->serverNoAnswerError ) printf("\t serverNoAnswerError = %d\n", netErrors->serverNoAnswerError);
    if (netErrors->peerNoAnswerError ) printf("\t peerNoAnswerError = %d\n", netErrors->peerNoAnswerError);
    if (netErrors->serverHandshakeError ) printf("\t serverHandshakeError = %d\n", netErrors->serverHandshakeError);
    if (netErrors->peerHandshakeError ) printf("\t peerHandshakeError = %d\n", netErrors->peerHandshakeError);
    if (netErrors->serverX25NoServiceError ) printf("\t serverX25NoServiceError = %d\n", netErrors->serverX25NoServiceError);
    if (netErrors->callWaitingError ) printf("\t callWaitingError = %d\n", netErrors->callWaitingError);
    if (netErrors->remoteCallWaitingError ) printf("\t remoteCallWaitingError = %d\n", netErrors->remoteCallWaitingError);
    if (netErrors->scriptLoginError ) printf("\t scriptLoginError = %d\n", netErrors->scriptLoginError);
    if (netErrors->packetRetransError ) printf("\t packetRetransError = %d\n", netErrors->packetRetransError);
    if (netErrors->usedAltPOPNumber ) printf("\t usedAltPOP = %d\n", netErrors->usedAltPOPNumber);
    if (netErrors->ctsTimeouts ) printf("\t ctsTimeouts = %d\n", netErrors->ctsTimeouts);
    if (netErrors->spinloopTimeouts ) printf("\t spinloopTimeouts = %08X\n", netErrors->spinloopTimeouts);
}

static char *
BillingTypeToString(
    unsigned	billingType
)
{
    char *str;

    switch(billingType) {
	case kBlogBillPrepaid:        
	    str = "prepaid";
	    break;
	case kBlogBillInvoice:        
	    str = "invoiced monthly";
	    break;
	case kBlogBillDebit:          
	    str = "checking account";
	    break;
	case kBlogBillVisa:           
	    str = "Visa";
	    break;
	case kBlogBillMcard:          
	    str = "Mastercard";
	    break;
	case kBlogBillAmex:           
	    str = "American Express";
	    break;
	case kBlogBillSmartc:         
	    str = "Smartcard";
	    break;
	case kBlogBillSubord:         
	    str = "subordinate account";
	    break;
	case kBlogBillBeta:           
	    str = "beta tester";
	    break;
	case kBlogBillInternal:       
	    str = "internal employee";
	    break;
	case kBlogBillGuest:          
	    str = "guest";
	    break;
	case kBlogBillPromo:          
	    str = "promotional";
	    break;
	case kBlogBillEcp:          
	    str = "ECP";
	    break;
	case kBlogBillUndefined:
	default:
	    str = "undefined";
	    break;
    }

    return(str);
}


static char *
ExitToStr(
    unsigned char status
)
{
    switch(status) {
	case kConnExitUnknown:
		return("unknown");
	case kConnExitGraceful:
		return("normal termination");
	case kConnNeverConnected:
		return("never connected");
	case kConnExitServerAbort:
		return("server aborted midway.");
	case kConnExitSighup:
		return("premature SIGHUP");
	case kConnExitTimeout:
		return("timed out");
	case kConnExitGenericSignal:
		return("generic signal");
	case kConnExitRpcAbort:
		return("RPC abort");
	default:
		return("unknown");
    }
}

static Boolean
LogIsRealCustomer(
    unsigned billingType
)
{
    switch(billingType) {
        case kBlogBillPrepaid :
        case kBlogBillInvoice:
        case kBlogBillDebit :
        case kBlogBillVisa :
        case kBlogBillMcard:
        case kBlogBillAmex:
        case kBlogBillSmartc:
        case kBlogBillSubord:
        case kBlogBillEcp:
                return(true);
        case kBlogBillBeta :
        case kBlogBillInternal:
        case kBlogBillGuest:
        case kBlogBillPromo:
        case kBlogBillUndefined:
        default:
                return(false);
    }
}


//****************************************************************************
//**** V4 vector routines ****************************************************
// V4 is the same as V3 but the Game Error results are filled in instead of
// being truncated at the size of a NewGameResult.
//****************************************************************************
int
VMInit_v4(VectorMachineVersion *vmv)
{
	vmv->globals = (void *)malloc(sizeof(V4MachineGlobs));
	if (!vmv->globals)
		return kInitFailed;

	memset(vmv->globals, 0, sizeof(V4MachineGlobs));
	
	return kNoErr;
}

int
VMConclude_v4(VectorMachineVersion *vmv)
{
	free(vmv->globals);
	return kNoErr;
}

int
VMOutput_v4(VectorMachineVersion *vmv, char *param)
{
	printf("%s", kDelimiter);
    param += VMProcessLoginInfoStdio_v3(vmv, param);
    param += VMProcessConnCarrierStdio_v3(vmv, param);
    param += VMProcessConnTypeStdio_v3(vmv, param);
    param += VMProcessCrashRecordStdio_v3(vmv, param);
    param += VMProcessGameResultsStdio_v4(vmv, param);
    param += VMProcessGameErrorResultsStdio_v4(vmv, param);
    param += VMProcess800NetErrorsStdio_v3(vmv, param);
    param += VMProcessX25NetErrorsStdio_v3(vmv, param);
    param += VMProcessStreamErrorReportStdio_v3(vmv, param);
	printf("%s", kDelimiter);
	
	return kNoErr;
}

int
VMProcessGameResultsStdio_v4(VectorMachineVersion *vmv, char *param)
{
V4MachineGlobs		*g = vmv->globals;

    if (g->flags.gameResults) {
		if (gSessionParams.outputFilterFlags & kVMFlagProcessGameResult) {
			PrintGenericGameResult_v4((NewGameResult *)param, "Game results: \n");
			}
		return ((NewGameResult *)param)->size;
		}
	
	return 0;
}

int
VMProcessGameErrorResultsStdio_v4(VectorMachineVersion *vmv, char *param)
{
V4MachineGlobs		*g = vmv->globals;

    if (g->flags.gameErrorResults) {
		if (gSessionParams.outputFilterFlags & kVMFlagProcessGameResult) {
			PrintGenericGameResult_v4((NewGameResult *)param, "Game error results: \n");
			}
		return ((NewGameResult *)param)->size;
		}
	
	return 0;
}

void
PrintGenericGameResult_v4(NewGameResult *gameResult, char *header)
{
	long     structSize, extraSize;

	printf(header);
	structSize = ((unsigned char *)&gameResult->pad) -
				((unsigned char *)gameResult);

	if (gameResult->size < structSize) {
		printf("\tRunt game result, size=%d\n", gameResult->size);
		return;
		}
		
	printf("\tgameID=0x%.8lx (%s) gameError=%d/%d/%d  playTime=%ld\n",
		gameResult->gameID, Common_GameName('sega', gameResult->gameID),
		gameResult->gameError, gameResult->errorWhere,
		gameResult->connectPhase, gameResult->playTime);
	printf("\tlocal1=%ld  local2=%ld  remote1=%ld  remote2=%ld\n",
		gameResult->localPlayer1Result, gameResult->localPlayer2Result,
		gameResult->remotePlayer1Result, gameResult->remotePlayer2Result);
	printf("\tdbIDDataPtr=%ld  dbIDDataSize=%ld  numPlayers=%ld gameReserved:\n",
		gameResult->dbIDDataPtr, gameResult->dbIDDataSize,
		(long)gameResult->numLocalPlayers);
	printf("\tlocalGameError: %-5d  errorRecovers: %-5d\n",
		gameResult->localGameError, gameResult->errorRecovers);
	printf("\tchecksumErrors: %-3d    timeouts: %-3d\n",
		gameResult->checksumErrors, gameResult->timeouts);
	printf("\tframeErrors: %-3d       overrunErrors: %-3d\n",
		gameResult->frameErrors, gameResult->overrunErrors);
	LogHexDump((unsigned char *) &gameResult->gameReserved,
		sizeof(gameResult->gameReserved));

	extraSize = gameResult->size - structSize;
	extraSize -= 2;		// guess we need this

	// do a sanity check so we don't go nuts
	if (extraSize < 0 || extraSize > 1024) {
		fprintf(stderr, "extraSize = %ld, wrong!\n", extraSize);
		return;
	}
	if (extraSize) {
		printf("\tExtra stuff (%ld bytes):\n", extraSize);
		LogHexDump((unsigned char *)&gameResult->pad, extraSize);
	} else {
		printf("\tNo extra stuff\n");
	}
}


//****************************************************************************
//**** V5 vector routines ****************************************************
// More gameResults changes.  Grab the size of the dbID data, and then display
// it based on the size of the entire record.
//****************************************************************************
int
VMInit_v5(VectorMachineVersion *vmv)
{
	vmv->globals = (void *)malloc(sizeof(V5MachineGlobs));
	if (!vmv->globals)
		return kInitFailed;

	memset(vmv->globals, 0, sizeof(V5MachineGlobs));
	
	return kNoErr;
}

int
VMConclude_v5(VectorMachineVersion *vmv)
{
	free(vmv->globals);
	return kNoErr;
}

int
VMOutput_v5(VectorMachineVersion *vmv, char *param)
{
	printf("%s", kDelimiter);
    param += VMProcessLoginInfoStdio_v5(vmv, param);
    param += VMProcessConnCarrierStdio_v3(vmv, param);
    param += VMProcessConnTypeStdio_v3(vmv, param);
    param += VMProcessCrashRecordStdio_v3(vmv, param);
    param += VMProcessGameResultsStdio_v5(vmv, param);
    param += VMProcessGameErrorResultsStdio_v5(vmv, param);
    param += VMProcess800NetErrorsStdio_v3(vmv, param);
    param += VMProcessX25NetErrorsStdio_v3(vmv, param);
    param += VMProcessStreamErrorReportStdio_v3(vmv, param);
	printf("%s", kDelimiter);
	
	return kNoErr;
}

int
VMProcessLoginInfoStdio_v5(VectorMachineVersion *vmv, char *param)
{
BlogLoginInfo_v5	*loginInfo = (BlogLoginInfo_v5 *)param;
char				nameBuf[128];
V5MachineGlobs		*g = vmv->globals;
struct hostent          *h;

	
    printf("Connection Info:\n");

	printf("\tBlog Size   = %d\n", loginInfo->size);
	printf("\tversion     = %d\n", loginInfo->version);

	// modify global state;
	g->flags = loginInfo->flags;
	
	// figure out the machine this record came from
	h = gethostbyaddr(&loginInfo->hostAddr, 4, AF_INET);
	printf("\tServer host name  = %s\n", h->h_name);

	if (loginInfo->flags.validLogin) {
		printf("\tStart time  = %s", ctime(&(loginInfo->startTime)));
		printf("\tDuration    = %d secs\n", loginInfo->duration);
		printf("\tExit status = %s\n", ExitToStr(loginInfo->exitStatus));
		printf("Login Info:\n");
		
		if (LogIsRealCustomer(loginInfo->billingType) == true)
			sprintf(nameBuf, "'%s' :REAL:", loginInfo->nameStr);
		else
			sprintf(nameBuf, "'%s'", loginInfo->nameStr);
		
		printf("\tName  = %s\n", nameBuf);
		printf("\tPhone = %s\n", LogPhoneToStr(&loginInfo->callingNumber));
		printf("\tBox info = (%d,%d) [%d]\n", 
		loginInfo->boxInfo.serialNum.box, 
		loginInfo->boxInfo.serialNum.region,
		loginInfo->boxInfo.userNum);
		if (loginInfo->flags.tournament)
			printf("\t**** Tournament Player ****\n");

		if (loginInfo->flags.validAccount) {
			printf("\tBilling type = %s\n", 
			BillingTypeToString(loginInfo->billingType));
			if (loginInfo->flags.accountCreation == kBlogPlayerCreated)
				printf("\tNew Player created \n");
			else if (loginInfo->flags.accountCreation == kBlogAccountCreated)
				printf("\tNew Account created \n");
			}
		}
	else {
		printf("\tStart time  = %s", ctime(&(loginInfo->startTime)));
		printf("\tLogin Information not available\n");
		printf("\tExit status = %s\n", ExitToStr(loginInfo->exitStatus));
		}
	return sizeof(BlogLoginInfo_v5);
}

int
VMProcessGameResultsStdio_v5(VectorMachineVersion *vmv, char *param)
{
V5MachineGlobs		*g = vmv->globals;

    if (g->flags.gameResults) 
		return PrintGenericGameResult_v5((NewGameResult *)param, "Game results: \n");
	else
		return 0;
}

int
VMProcessGameErrorResultsStdio_v5(VectorMachineVersion *vmv, char *param)
{
V5MachineGlobs		*g = vmv->globals;
NewGameResult 		*gameResult = (NewGameResult *)param;
int					size = 0;

    if (g->flags.gameErrorResults) {
		size = PrintGenericGameResult_v5(gameResult, "Game error results: \n");
		if (gameResult->dbIDDataSize) {
			if (gSessionParams.outputFilterFlags & kVMFlagProcessGameResult)
				DumpGameResultSendQ(kPlatformGenesis, param+size, gameResult->dbIDDataSize);
			size += gameResult->dbIDDataSize;
			}
		}
	return size;
}

int
PrintGenericGameResult_v5(NewGameResult *gameResult, char *header)
{
	long     structSize, extraSize;

	if (gSessionParams.outputFilterFlags & kVMFlagProcessGameResult) {
		printf(header);
		structSize = ((unsigned char *)&gameResult->pad) -
					((unsigned char *)gameResult);
	
		if (gameResult->size < structSize) {
			printf("\tRunt game result, size=%d\n", gameResult->size);
			return;
			}
			
		printf("\tgameID=0x%.8lx (%s) gameError=%d/%d/%d  playTime=%ld\n",
			gameResult->gameID, Common_GameName('sega', gameResult->gameID),
			gameResult->gameError, gameResult->errorWhere,
			gameResult->connectPhase, gameResult->playTime);
		printf("\tlocal1=%ld  local2=%ld  remote1=%ld  remote2=%ld\n",
			gameResult->localPlayer1Result, gameResult->localPlayer2Result,
			gameResult->remotePlayer1Result, gameResult->remotePlayer2Result);
		printf("\tdbIDDataPtr=%ld  dbIDDataSize=%ld  numPlayers=%ld gameReserved:\n",
			gameResult->dbIDDataPtr, gameResult->dbIDDataSize,
			(long)gameResult->numLocalPlayers);
		printf("\tlocalGameError: %-5d  errorRecovers: %-5d\n",
			gameResult->localGameError, gameResult->errorRecovers);
		printf("\tchecksumErrors: %-3d    timeouts: %-3d\n",
			gameResult->checksumErrors, gameResult->timeouts);
		printf("\tframeErrors: %-3d       overrunErrors: %-3d\n",
			gameResult->frameErrors, gameResult->overrunErrors);
		LogHexDump((unsigned char *) &gameResult->gameReserved,
			sizeof(gameResult->gameReserved));
	
		extraSize = gameResult->size - structSize;
		extraSize -= 2;		// guess we need this
	
		// do a sanity check so we don't go nuts
		if (extraSize < 0 || extraSize > 1024) {
			fprintf(stderr, "extraSize = %ld, wrong!\n", extraSize);
			return;
		}
		if (extraSize) {
			printf("\tExtra stuff (%ld bytes):\n", extraSize);
			LogHexDump((unsigned char *)&gameResult->pad, extraSize);
		} else {
			printf("\tNo extra stuff\n");
		}
	}
		
		
	return (gameResult->size);
}

//****************************************************************************
//**** V6 vector routines ****************************************************
// Will it ever end?  Move SendQGameresults to a separate subrecord
//****************************************************************************
int
VMInit_v6(VectorMachineVersion *vmv)
{
	vmv->globals = (void *)malloc(sizeof(V6MachineGlobs));
	if (!vmv->globals)
		return kInitFailed;

	memset(vmv->globals, 0, sizeof(V6MachineGlobs));
	
	return kNoErr;
}

int
VMConclude_v6(VectorMachineVersion *vmv)
{
	free(vmv->globals);
	return kNoErr;
}

int
VMOutput_v6(VectorMachineVersion *vmv, char *param)
{
	printf("%s", kDelimiter);
    param += VMProcessLoginInfoStdio_v5(vmv, param);
    param += VMProcessConnCarrierStdio_v3(vmv, param);
    param += VMProcessConnTypeStdio_v3(vmv, param);
    param += VMProcessCrashRecordStdio_v3(vmv, param);
    param += VMProcessGameResultsStdio_v6(vmv, param);
    param += VMProcessGameErrorResultsStdio_v4(vmv, param);
    param += VMProcess800NetErrorsStdio_v3(vmv, param);
    param += VMProcessX25NetErrorsStdio_v3(vmv, param);
    param += VMProcessStreamErrorReportStdio_v3(vmv, param);
    param += VMProcessSendQGameErrorResultsStdio_v6(vmv, param);
    param += VMProcessSendQBoxErrorStdio_v6(vmv, param);
	printf("%s", kDelimiter);
	
	return kNoErr;
}

int
VMProcessSendQGameErrorResultsStdio_v6(VectorMachineVersion *vmv, char *param)
{
V6MachineGlobs		*g = vmv->globals;

	if (g->flags.gameSendQErrors) {
		if (gSessionParams.outputFilterFlags & kVMFlagProcessGameResult) 
			DumpGameResultSendQ(kPlatformGenesis, param+sizeof(long), *((long *)param));
		return (*(long *)param)+4;
		}
	else
		return 0;
}

int
VMProcessGameResultsStdio_v6(VectorMachineVersion *vmv, char *param)
{
V4MachineGlobs		*g = vmv->globals;
NewGameResult		*ngr = (NewGameResult *)(param+4);
int					size;
	
    if (g->flags.gameResults) {
		size = ngr->size;
		if (gSessionParams.outputFilterFlags & kVMFlagProcessGameResult) {
			PrintCreditChangeFlags_v6((unsigned long *)param);
			PrintGenericGameResult_v4(ngr, "Game results: \n");
			}
		
		// sometimes the server nulls out error results, it should fix the size though.  For version 7!?!?
		if (!size)
			size = sizeof(NewGameResult);
			
		return size + 4;
		}
	
	return 0;
}

int
PrintCreditChangeFlags_v6(unsigned long *param)
{
int					i;
Boolean				comma = false;

	printf("CreditChangeFlags: 0x%X (", *param);
	for (i = 0; i < NELEM(errNames); i++) {
		if (*param & errNames[i].err) {
			if (comma)
				printf(", ");
			else
				comma = true;
			printf (errNames[i].name);
			}
		}
	printf(")\n");
}

int
VMProcessSendQBoxErrorStdio_v6(VectorMachineVersion *vmv, char *param)
{
V6MachineGlobs		*g = vmv->globals;
unsigned short		size, totalSize = 0;
short 				*localParam = (short *)param;

	if (g->flags.boxSendQErrors) {
		while (size = *localParam++) {
			if (gSessionParams.outputFilterFlags & kVMFlagProcessGameResult) {
				printf("Dump of Box Error dbid #0x%X:\n", *localParam);
				LogHexDump((unsigned char *)localParam, size);
				}
			((char *)localParam) += size;
			}
		return ((char *)localParam)-param;
		}
	else
		return 0;
}
