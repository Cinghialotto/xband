#ifndef lint
// Copyright: @ 1994 Catapult Entertainment, Inc., all rights reserved
#endif /* lint */

/*
 * $Id: logutil.c,v 1.22 1995/05/26 23:01:22 jhsia Exp $
 *
 * $Log: logutil.c,v $
 * Revision 1.22  1995/05/26  23:01:22  jhsia
 * switched to rcs keywords
 *
 */

#include <stdio.h>
#include <signal.h>
#include <setjmp.h>
#include <sys/unistd.h>

#include "../include/logutil.h"

extern int errno;

/*

Let's keep this documentation up to date, can't we?  2/28/95 15:01 (SLS)
I've come up with a whole new theory for the binglogs that makes it 
much more extensible, without injuring existing tools.  The
principle theory is make each datum utterly self-evident.  Begin
with a "size" (long) and a tag (long) that identifies a given chunk.
This allows tools (at run time!) to skip over chunks they don't understand.

Notes 1/9/95 11:18:53 PM (BET):
The trick with this library is to try to abstract as much as possible the output
of the parsed record from the input of it.  To what extent that is possible with
a multiple versions of the record as source input, a structure of the following
is defined.  Each binary log subrecord type is given a constant, and a row in
a two dimensional array.  Over the second dimension, routine vectors to output the
various versions are loaded.  Finally, a third implicit dimension is added, that
being one of output type.  While a printing output type is the only one currently
defined, one could relatively easily define an oracle database output type array.
This would instead of printing the output to stdout would generate a database
record instead.

This implies that there is some constant state defined that acts as globals over
the various third dimension arrays.  A printing array would have drastically
different initialization and global requirements from one that created databases
or statistical analyses.

The operation of the library at the most basic level is as such.  To use the
embedded printing library, one would simply call VMRecoverVectors(kStdioMachine).
This would return a pointer of type (VectorMachine *) that needs to be passed to
all public library calls for parsing records.  So long as the embedded library
has a vector for the version and subrecord type in the array, the information
will be output.  Along these lines, one could override a standard output routine
by (*** either setting the vector directly or calling a public call to set it ***).
This override would automatically be called in the future when records of the
specified type were encountered.

Once the client application is happy with the VectorMachine static state, it calls
VMInitVectorMachine(VectorMachine *).  This returns an error or zero if kNoErr.  On
success, the vector machine is ready for use.  On completion, calling
VMConcludeVectorMachine(VectorMachine *) closes down the state associated with the
machine (open databases, files, screens, memory, etc.).  If the VectorMachine came
from a call to VMRecoverVectors, a call to VMDisposeVectors must be made to dispose
the vector machine.

Between these two points, calls are alternated between library routines to read
the binlog file and VectorMachine calls to output them for fine granularity, or
a single call to LogProcessFile() to do them all.

DIFFERENCES WITH THE OLD LOGUTIL LIBRARY:
As with the old logutil library, the concept of a client callback has been retained.
The old logutil library required that a callback be provided.  In this version, if
no callback is provided, a default functionality of calling VMPrintConnection is
provided.  In the old version, the callback was used to call one of either a verbose
or concise format output proc embedded in the logutil library, the new version expects
that this variable functionality will be provided by a different VectorMachine.
The callback is still useful as an override mechanism, but since binlog records are
now an abstract blob that the output client does not nessecarily understand, the
utility of the callback is small.

Filtering of records via a user-selected criteria was handled by looking at the record
directly and deciding if the flags matched a search criteria.  In the new version,
blob abstraction requires that a version-inspecific bitmap be sent to a filter routine
for the individual version.  In this manner, obsolete flags can be ignored by later
filters, as well at-writing undefined flags by earlier versions.  This means the user
may see records that he did not really want to, but since filtering is typically only
used in interactive mode, the records processed should all be of the latest version.

FEATURES THAT COULD BE IMPLEMENTED:
Viewers could become complex enough that they could retain state across launches.
The advantage of this is that the viewer could know nothing about the data that
it is filtering, but call a VectorMachine utility to return a list of available
flags and symbolic representations for all of the versions it supports.  In this
way, the viewer would not have to change when the VectorMachine was extended to
support a new subrecord type.  Since this increases the configuration complexity,
per-user configuration saves become important.
*/


extern VectorMachine sStdioMachine;
extern VectorMachine sTerseMachine;
extern VectorMachine sCursesMachine;
extern VectorMachine sCRMachine;
extern VectorMachine sBatteryCheck;
extern VectorMachine sdbLoad;

static VectorMachine *VectorMachineArray[kLastMachineType] = { 
	&sStdioMachine,
	&sTerseMachine,
	&sCursesMachine,
	&sCRMachine,
	&sBatteryCheck,
	&sdbLoad
	};


LogSessionParams gSessionParams = {
    0,
    kDefaultStartTime,		
    kDefaultEndTime,
	-1,
	-1
};

static sigjmp_buf				gJmpbuf;
static volatile int				gCanJump;
static void						sig_common(int);

//****************************************************************************
//**** version-inspecific input utilities ************************************
//****************************************************************************
static int
freadBlock(
    void        *buf,
    int         numBytes,
    int         numItems,
    FILE        *fp
)
{
    int nleft, nread;                   // number of items

    nleft = numItems;
    while(nleft > 0) {
        clearerr(fp);
        nread = fread(buf, numBytes, numItems, fp);
        if (nread == 0) {
            // EOF or error
            if (feof(fp))
                sleep(kSleepInterval);
            else
                return(-1);
        } else {
            nleft -= nread;
            buf   += nread;
        }
    }    

    return(numItems);
}


static int
freadWrapper(
    void        *buf,
    int         numBytes,
    int         numItems,
    FILE        *fp
)
{
    int    status;

	if (gSessionParams.chase)
		status = freadBlock(buf, numBytes, numItems, fp);
	else
		status = fread(buf, numBytes, numItems, fp);

	return(status);
}

void
LogSessionInitialize(
    LogSessionParams *params
)
{
    gSessionParams = *params;
}

void
LogSkipConnection(
    FILE	*fp
)
{
char		search[4];
int			i;
char		buf;
int			tell;

	*((long *)search) = kLogConnStartMarker;
	while (1) {
		freadWrapper(&buf, 1, 1, fp);
		if ((buf == EOF) && feof(fp)) {
			fprintf(stderr, "Error: LogSkipConnection called, found eof\n");
			return;
			}
		if (buf != search[0])
			continue;
		
		tell = ftell(fp);
		for (i=1; i<4; i++) {
			freadWrapper(&buf, 1, 1, fp);
			if ((buf == EOF) && feof(fp)) {
				fprintf(stderr, "Error: LogSkipConnection called, found eof\n");
				return;
				}
			if (buf != search[i]) {
				fseek(fp, tell, SEEK_SET);
				break;
				}
			}
		if (i == 4) {
			fseek(fp, tell-1, SEEK_SET);
			fprintf(stderr, "Error: LogSkipConnection called, found next record\n");
			return;
			}
		}
}


FILE *
LogOpenFile(
    char 	   *filename,
    BlogFileHeader *fileHeader
)
{
    FILE *fp;
    char prompt;

    fp = fopen(filename, "r");
    if (fp == NULL) {
	fprintf(stderr, "Unable to open file %s\n", filename);
	return(NULL);
    }

    if (freadWrapper(fileHeader, sizeof(BlogFileHeader), 1, fp) != 1) {
        fprintf(stderr, "LogOpenFile: unable to read file header\n");
	fclose(fp);
	return(NULL);
    }

    if (fileHeader->identifier != kLogConnStartMarker) {
        fprintf(stderr, "LogOpenFile: %s is not a binary log file\n",
	    filename);
	fclose(fp);
	return(NULL);
    }
  	
    if (fileHeader->version < 3) {
        fprintf(stderr,
            "Readlog requires version 3 or greater files; log file is of version %d\n",
            fileHeader->version);
	    fclose(fp);
	    return(NULL); 
    }

    return(fp);
}

void
LogCloseFile(
    FILE	*fp
)
{
    fclose(fp);
}


void
LogProcessFile(
	VectorMachine *vm,
	FILE 		*fp,
    void 		(*func)(VectorMachine *, char *, void *), 
    void 		*clientData
)
{
    long					marker;
	short					s;
	char					*blogRec;
	int						sigreturn;
	
    clearerr(fp);

	if (signal(SIGBUS, sig_common) == SIG_ERR) {
		fprintf(stderr, "fatal error: couldn't install signal handler\n");
		exit(2);
		}
	if (signal(SIGSEGV, sig_common) == SIG_ERR) {
		fprintf(stderr, "fatal error: couldn't install signal handler\n");
		exit(2);
		}
	if (signal(SIGINT, sig_common) == SIG_ERR) {
		fprintf(stderr, "fatal error: couldn't install signal handler\n");
		exit(2);
		}
	
	switch (sigsetjmp(gJmpbuf, 1)) {
		case SIGINT:
			goto bail;
		case SIGBUS:
		case SIGSEGV:
			fprintf(stderr, "\n\n****************************************************\n");
			fprintf(stderr, "Signal caught while processing malformed connection record.\n");
			fprintf(stderr, "Dump of record follows:\n");
//			LogHexDump(blogRec, *(short *)blogRec);
			free(blogRec);
			fprintf(stderr, "****************************************************\n");
			goto more;
		}
		
	gCanJump = 1;
	
	while(1) {
	
#ifdef READ_DEBUG
		fprintf(stderr, "reading start marker\n");
#endif  
		if (freadWrapper(&marker, sizeof(long), 1, fp) != 1) {
			if (feof(fp))
				break;
			else
				goto error;
			}
	
		if (marker != kLogConnStartMarker)
			goto skipit;
	
		// read in data to new memory
		// first find size of data
		if (freadWrapper(&s, sizeof(short), 1, fp) != 1) {
			if (feof(fp))
				break;
			else
				goto error;
			}
	
		// allocate and fill the mems
		blogRec = (char *)malloc(s);
		if (!blogRec)
			goto error;
			
		*((short *)blogRec) = s;
		if (freadWrapper(blogRec+2, s-2, 1, fp) != 1) {
			if (feof(fp))
				break;
			else
				goto error;
			}
	
		/* check if entire connection record is consistent */
#ifdef READ_DEBUG
		fprintf(stderr, "reading end marker\n");
#endif
		if (freadWrapper(&marker, sizeof(long), 1, fp) != 1) 
			goto error;
	
		if (marker != kLogConnEndMarker) 
			goto skipit;
	
		// well formed connection record - so callback to client if it exists
		// or just call the print routine
		if (func)
			(*func)(vm, blogRec, clientData);
		else
			VMOutputConnection(vm, blogRec);

more:
		free(blogRec);
		continue;

skipit:
		LogSkipConnection(fp);
		continue;

error:
		fprintf(stderr, "LogProcessFile: error while reading connection - skipping rest of file\n");
		break;
		}
bail:
	// remove signal handlers
	if (signal(SIGBUS, SIG_DFL) == SIG_ERR) {
		fprintf(stderr, "fatal error: couldn't install signal handler\n");
		exit(2);
		}
	if (signal(SIGSEGV, SIG_DFL) == SIG_ERR) {
		fprintf(stderr, "fatal error: couldn't install signal handler\n");
		exit(2);
		}
	
}
 
void
LogProcessFiles(
	VectorMachine *vm,
    char **files,
    int  numFiles,
    void (*func)(VectorMachine *, char *, void *),
    void *clientData
)
{
    int  	   i;
    FILE 	   *fp;
    BlogFileHeader fileHeader;

    for(i = 0; i < numFiles; i++) {
		if ((fp = LogOpenFile(files[i], &fileHeader)) == NULL) {
			fprintf(stderr, "Skipping file %s ..\n", files[i]);
			}
		else {
			LogProcessFile(vm, fp, func, clientData);
			}
    }
}


static void sig_common(int sig)
{
	if (gCanJump == 0)
		return;
	
	gCanJump = 0;
	siglongjmp(gJmpbuf, sig);
}

void
LogHexDump(
    const unsigned char *data, 
    const long length
)
{
        const unsigned char *ucp;
        char linebuf[16*3 +3];
        char charbuf[16 +3];
        int i;

        if (!length) {
                fprintf(stderr, "Called LogHexDump for zero bytes\n");
                return;
        }

        strcpy(linebuf, " ");
        strcpy(charbuf, "");
        for (i = 0, ucp = data; i < length; i++, ucp++) {
                sprintf(linebuf + strlen(linebuf), "%.2X ", *ucp);
                if ((*ucp >= ' ') && (*ucp <= '~'))
                        sprintf(charbuf + strlen(charbuf), "%c", *ucp);
                else
                        sprintf(charbuf + strlen(charbuf), ".");
                if (i % 16 == 15) {
                        printf("%s [%s]\n", linebuf, charbuf);
                        strcpy(linebuf, " ");
                        strcpy(charbuf, "");
                } else if (i % 8 == 7) {
                        strcat(linebuf, " ");
                        strcat(charbuf, " ");
                }
        }
        if (i % 16) {
                printf("%s [%s]\n", linebuf, charbuf);
        }
}

char *
LogPhoneToStr(
    BlogPhoneNumber_v0 *phone
)
{
    static char buf[32];
    char        localNum[32];

    memset(buf, 0, 32);

    if (phone->areaCode > 0)
        sprintf(buf, "%d-", phone->areaCode);

    sprintf(localNum, "%d", phone->localNumber);
    if (strlen(localNum) == 7) {
        strncat(buf, localNum, 3);
        strcat(buf, "-");
        strncat(buf, localNum+3, 4);
    }

    return(buf);
}


//****************************************************************************
//**** version-inspecific output utilities ***********************************
//****************************************************************************
VectorMachine *
VMRecoverVectors(const int vmID)
{
	if (vmID < kLastMachineType)
		return VectorMachineArray[vmID];
	else
		return NULL;
}

void
VMDisposeVectors(VectorMachine *vm)
{
	// since all VectorMachines returned by VMRecoverVectors are statically
	// allocated, nothing needs to be disposed for now.  Later, if these are
	// dynamically loaded from files, they will need to be dealt with here.
}

int
VMInitVectorMachine(VectorMachine *vm)
{
int i, err;

	for (i=0; i<= kLogVersionNumber; i+=1) {
		if (err = (*((*vm).vectorVersion[i].init))((struct VectorMachineVersion *)&(*vm).vectorVersion[i])) {
			if (err == kVMWarnEmptyVersion) {
				// don't worry about empty versions
				continue;
				}
			else
				return err;
			}
		}
	return kNoErr;
}

int
VMConcludeVectorMachine(VectorMachine *vm)
{
int i, err;

	for (i=0; i<= kLogVersionNumber; i+=1) {
		if (err = (*((*vm).vectorVersion[i].conclude))((struct VectorMachineVersion *)&(*vm).vectorVersion[i])) {
			if (err = kVMWarnEmptyVersion) {
				// don't worry about empty versions
				continue;
				}
			else
				return err;
			}
		}
	return kNoErr;
}

Boolean
VMFilterConnection(VectorMachine *vm, char *blogRecord, VMFlagType *watchFlags)
{
int i = ((short *)blogRecord)[1];
	
	if (i > kLogVersionNumber) {
		fprintf(stderr, "Wow, guess readlog hasn't been updated.  Version %d is greater than latest I understand, %d.\n", i, kLogVersionNumber);
		return kVMWarnEmptyVersion;
		}
	else
		return (((*vm).vectorVersion[i].filter))((struct VectorMachineVersion *)&(*vm).vectorVersion[i], blogRecord, watchFlags);
}

int
VMOutputConnection(VectorMachine *vm, char *blogRecord)
{
int i = ((short *)blogRecord)[1];

	if (i > kLogVersionNumber) {
		fprintf(stderr, "Wow, guess readlog hasn't been updated.  Version %d is greater than latest I understand, %d.\n", i, kLogVersionNumber);
		return kVMWarnEmptyVersion;
		}
	else
		return (*((*vm).vectorVersion[i].output))((struct VectorMachineVersion *)&(*vm).vectorVersion[i], blogRecord);
}

//****************************************************************************
//**** Empty vector routines *************************************************
//****************************************************************************
int
VMInitUnknownVec(VectorMachineVersion *vmv)
{
//	fprintf(stderr, "Attempted init via empty vector machine, version %d.\n", vmv->version);
	return kVMWarnEmptyVersion;
}

int
VMConcludeUnknownVec(VectorMachineVersion *vmv)
{
//	fprintf(stderr, "Attempted conclude via empty vector machine.\n");
	return kVMWarnEmptyVersion;
}

// the default empty VecMachine filter proc says don't display by default because
// the display function couldn't display it anyways
Boolean
VMFilterUnknownVec(VectorMachineVersion *vmv, char *blogRecord, VMFlagType *watchFlags)
{
	fprintf(stderr, "Attempted filtering via empty vector machine, filtered out by default.\n");
	return false;
}

int
VMOutputUnknownVec(VectorMachineVersion *vmv, char *param)
{
	fprintf(stderr, "Attempted processing via empty vector machine, record ignored.\n");
	return true;
}

