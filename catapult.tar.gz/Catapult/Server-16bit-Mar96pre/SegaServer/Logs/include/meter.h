/*
 *	Copyright: � 1995 Catapult Entertainment Inc., all rights reserved
 *	
 *	$Id: meter.h,v 1.1 1995/11/15 16:25:42 sriram Exp $
 *
 *	$Log: meter.h,v $
 * Revision 1.1  1995/11/15  16:25:42  sriram
 * added file.
 *
 *
 */

#ifndef __meter_h__
#define __meter_h__

#define kServerPort		5135
#define kNumMinutesInDay	1440
#define kNumSecsInDay		(kNumMinutesInDay * 60)

// connect types
#define kConnect800		(1L<<0)
#define kConnectX25		(1L<<1)
#define kConnectMail		(1L<<2)
#define kConnectGame		(1L<<3)
#define kConnectChallenge	(1L<<4)
#define kConnectAutoMatch	(1L<<5)
#define kConnectPrematureHup	(1L<<6)

typedef struct EventPacket {
    long	when;
    int		flag;
} EventPacket;


typedef struct ConnectCountInfo {
    int	connects800;
    int mailConnects;
    int challengeConnects;
    int automatchConnects;
    int x25UnknownGameConnects; // challenge or automatch
    int x25UnknownConnects;	// mail or game
    int unknownConnects;	// 800 or x25
    int	prematureHups;		// premature hangups on both 800 and X25
} ConnectCountInfo;


// client request protocol
#define kReqPrintDebugging	1
#define kReqByMinuteAbsolute	2
#define kReqByHourAbsolute	3
#define kReqByMinuteRelative	4
#define kReqByHourRelative	5
#define kReqToMinuteRelative	6
#define kReqToHourRelative	7

// 
// If using an absolute opcode, value refers to an absolute time.
// If using a relative opcode, value refers to a duration in the 
// past from NOW ! (may be useful to specificy as an offset/duration.
// 
typedef struct ClientRequest {
    int		opcode;
    int		value;
} ClientRequest;


typedef struct ClientReply {
    int			status;		// zero indicates failure
    int		     	value;
    ConnectCountInfo 	info;
} ClientReply;


typedef struct ConnectCounter {
	int			midnight;
	ConnectCountInfo	info[kNumMinutesInDay];
} ConnectCounter;

#endif __meter_h__
