// Copyright: @ 1994 Catapult Entertainment, Inc., all rights reserved
//
// $Id: dbLoadGameSpecific.h,v 1.2 1995/05/26 22:51:31 jhsia Exp $
//
// $Log: dbLoadGameSpecific.h,v $
 * Revision 1.2  1995/05/26  22:51:31  jhsia
 * switch to rcs keywords
 *

typedef int (*ERR_FUNC_PTR)();

typedef struct {
	long			gameID;					// which game it is
	ERR_FUNC_PTR	displaySendQ;			// pretty-print stuff from SendQ
	ERR_FUNC_PTR	displayGameResult;		// pretty-print gameReserved field

	ERR_FUNC_PTR	getNumWins;				// compute #of wins for each side
	ERR_FUNC_PTR	checkScorable;			// determine if game is scorable
	ERR_FUNC_PTR	possiblyLosing;			// might player have been losing?
	ERR_FUNC_PTR	checkReset;				// determine if reset was malicious
} GameSpecificJumpTable;


typedef struct JamsStats {
	long	gameID;
	long	frameCount;
	long	lateCount;
	long	lostSyncCount;
	long	caughtLateCount;
	long	gameFrames;
	long	skipCount;
	long	syncFlagSkips;
	long	rxFifoEmptyCount;

	long	endQFrameCount;
	long	endQLateCount;
	long	endQLostSyncCount;
	long	endQCaughtLateCount;
	long	endQGameFrames;
	long	endQSkipCount;
	long	endQSyncFlagSkips;
	long	endQRxFifoEmptyCount;

	unsigned char	refTimeStamp;				// syncOTron reference time stamp
	unsigned char	lastTimeStamp;				// last rxByte's timeStamp
	unsigned char	latencyCount;				// frames of latency
	unsigned char	isLeader;					// 1 if IAmLeader, 0 if IAmFollower

//	long			syncPtr;
//	unsigned char	syncList[24];

	long			patchHistPtr;
	unsigned char	patchHistBuf[32];				// patch history

	short			mode;
	unsigned short	avgEqm;
	unsigned short	maxEqm;
	//unsigned short	recoveryCount;
} JamsStats;

typedef struct MKResults {
	unsigned short	frameDelay;
	unsigned short	totalVBLs;
	unsigned short	skippedVBLs;
	unsigned short	mkState;
	short			checkLineResult;
} MKResults;

typedef struct MK2SendQ {
	u_long	gameID;
	u_long	syncFlagSkips;			// synco junk
	u_long	rxFifoEmptyCount;
	u_long	lateCount;
	u_long	lostSyncCount;
	u_long	caughtLateCount;
	u_long	gameFrames;				// count of non-skipped vbls

	u_char	refTimeStamp;			// more synco junk
	u_char	lastTimeStamp;
	u_char	latencyCount;			// frame delta between the two machines
	u_char	isLeader;				// true if i am the master

	u_char	callWaitingCount;		// # of call waiting events
	u_char	gameHoldOff;			// (counts by 2) frames to hold off
									//   while other catches up

	u_char	p1RoundWins;			// # of P1 wins THIS ROUND
	u_char	p2RoundWins;			// # of P2 wins THIS ROUND

	u_long	errRecoverTime;			// error recovery timeout tick count

	u_char	inResync;				// Nonzero -> in resync
	u_char	uploadPad[3];			// padbyte
} MK2SendQ;

typedef struct NHLResults {
	short   stage;
	short   gameState;
	short   frameDelay;
	short   gtErrorRecovers;
	short   gtRecovered;
	short   skippedVBLs;
	long    totalVBLs;
	long    controlChksum;
	long    controlXOR;
	short   crcErrors;
	short   checklineErr;
	char    callWaits;
	char    remoteCallWaits;
	char    connectLost;
	char    errTimeouts;
} NHLResults;

typedef struct MaddenResults {
	char				quarter;
	char				quarterLen;
	char				homeTeam;
	char				visitTeam;

	char				delaysPerQuarter[8];

	unsigned short int	stage;
	unsigned short int	gameState;
	short int			frameDelay;
	short int			gtErrorRecovers;
	short int			gtRecovered;
	short int			gtRecoverFailures;
	short int			lastGTError;
	short int			checklineErr;

	unsigned char		callWaits;
	unsigned char		remoteCallWaits;
	unsigned char		connectLost;
	unsigned char		errTimeouts;
} MaddenResults;

//
// Madden defs for reset check
//
#define kEstablishSynch			0x100
#define kErrorRecover			0x200

#define kstage_pauseMode		5
#define kstage_intermission		6
#define kstage_gameOver			7
#define kstage_inErrorRecovery	9


int dbDumpGameResultSendQ(long platformID, const unsigned char *data, const long size);
static GameSpecificJumpTable * LookupGameSpecific(const long platformID, const long gameID);
static GameSpecificJumpTable *sega_LookupGameSpecific(const long gameID);
static int GenericGetNumWins(const NewGameResult *gameResult, long *p1wins, long *p2wins);
static int MatchGetNumWins(const NewGameResult *gameResult, long *p1wins, long *p2wins);

// Jams
static int dbDumpJamsSendQ(const unsigned char *data, const long size);
static int GetJamsNumWins(const NewGameResult *gameResult, long *p1wins, long *p2wins);
static int CheckJamsScorable(const ServerState *state, const NewGameResult *gameResult);
static int JamsPossiblyLosing(const ServerState *state, const NewGameResult *gameResult);
static int CheckJamsReset(const ServerState *state, const NewGameResult *gameResult, const NewGameResult *gameErrorResult);

// MK
static int DumpMKResult(const NewGameResult *gameResult);
static int CheckMKReset(const ServerState *state, const NewGameResult *gameResult, const NewGameResult *gameErrorResult);

// MK2
static int CheckMK2Reset(const ServerState *state, const NewGameResult *gameResult, const NewGameResult *gameErrorResult);
static int dbDumpMK2SendQ(const unsigned char *data, const long size);

// NHL
static int DumpNHLResult(const NewGameResult *gameResult);
static int CheckNHLReset(const ServerState *state, const NewGameResult *gameResult, const NewGameResult *gameErrorResult);

// Madden
static int DumpMaddenResult(const NewGameResult *gameResult);
static int MaddenPossiblyLosing(const ServerState *state, const NewGameResult *gameResult);
static int CheckMaddenReset(const ServerState *state, const NewGameResult *gameResult, const NewGameResult *gameErrorResult);

enum {
        kdbLoad_GameResultsIncomplete =0,
        kdbLoad_GameResultsComplete
};
#define cdbLoad_GameSpecific1   "GSP1\t"
#define cdbLoad_GameSpecific2   "GSP2\t"


