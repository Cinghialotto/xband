/*
 *	Copyright: � 1995 Catapult Entertainment Inc., all rights reserved
 *
 *	$Id: meterclient.h,v 1.1 1995/11/15 16:30:02 sriram Exp $
 *
 *	$Log: meterclient.h,v $
 * Revision 1.1  1995/11/15  16:30:02  sriram
 * added meterclient.h
 *
 */

#include "meter.h"

// public prototypes
void *  MclStringToAddress(char*, int);
int     MclGetConnectInfoToHourRelative(void*, int, void(*)(ConnectCountInfo *, int));

