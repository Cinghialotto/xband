// Copyright: @ 1994 Catapult Entertainment, Inc., all rights reserved
//
// $Id: BatteryCheck.h,v 1.3 1995/05/26 22:51:24 jhsia Exp $
//
// $Log: BatteryCheck.h,v $
 * Revision 1.3  1995/05/26  22:51:24  jhsia
 * switch to rcs keywords
 *
//
#ifndef __BatteryCheck__
#define __BatteryCheck__



// v4 protos
static int VMInit_v4(VectorMachineVersion *);
static int VMConclude_v4(VectorMachineVersion *);
static Boolean VMFilter_v4(VectorMachineVersion *vmv, char *blogRecord, VMFlagType *watchFlags);
static int VMOutput_v4(VectorMachineVersion *, char *);

static void PrintConnRec_v4(BlogLoginInfo_v3 *loginInfo, GameIDData *gameInfo, BlogOpponentInfo_v0 *opponentInfo);
static char *ExitToStr(unsigned char status);
static Boolean LogIsRealCustomer(unsigned billingType);



#endif // __BatteryCheck__


