/*
 * Copyright: @ 1994 Catapult Entertainment, Inc., all rights reserved
 *
 * $Id: logutil.h,v 1.20 1995/09/13 14:09:10 ted Exp $
 *
 * $Log: logutil.h,v $
 * Revision 1.20  1995/09/13  14:09:10  ted
 * Fixed warnings.
 *
 * Revision 1.19  1995/05/26  22:51:32  jhsia
 * switch to rcs keywords
 */

#ifndef __logutil__
#define __logutil__

#include "Server_Log.h"

// time to sleep in chase mode when blocked on read
#define kSleepInterval	1

#define kDefaultStartTime	0
#define kDefaultEndTime         978249600       // sometime in 2000 AD

//********************************************************
// version-inspecific filtering flags
//********************************************************
typedef int VMFlagType;
enum {
	kVMFlagProcessAllConnections			= ~0,
	kVMFlagProcessLoginInfo					= 1<<0,
	kVMFlagProcessMailRequest				= 1<<1,
	kVMFlagProcessGameRequest				= 1<<2,
	kVMFlagProcessCrashRecord				= 1<<3,
	kVMFlagProcessGameResult				= 1<<4,
	kVMFlagProcessNetErrors					= 1<<5,
	kVMFlagProcessStreamError				= 1<<6,
	kVMFlagProcessX25Connections			= 1<<7,
	kVMFlagProcess800Connections			= 1<<8,
	kVMFlagProcessSpecifiedBox			= 1<<9,
	kVMFlagProcessSpecifiedBoxTelephone		= 1<<10
	};

typedef long MachineFlags;
enum {
	kIsChaseMachine						= 1<<0,
	kIsReadMachine						= 1<<1,
	kUsesStandardFiltering				= 1<<2
	};


enum {
	kNoErr								= 0,
	kVMFirstWarning						= 1000,
	kVMWarnEmptyVersion					= kVMFirstWarning,
	
	kVMFirstError						= 2000,
	kInitFailed							= kVMFirstError
	};
	
	

// predefined machine enumeration
enum {
	kStdioMachine						= 0,
	kTerseMachine,
	kCursesMachine,
	kCRMachine,
	kBatteryCheck,
	kdbLoad,

	// add new machines before this line
	kLastMachineType								// placeholder, must be last
	};

struct VectorMachineVersion;

typedef int (*VectorMachineInit)(struct VectorMachineVersion *);
typedef int (*VectorMachineConclude)(struct VectorMachineVersion *);
typedef Boolean (*VectorMachineFilter)(struct VectorMachineVersion *, char *, VMFlagType *);
typedef int (*VectorMachineOutput)(struct VectorMachineVersion *, char *);

typedef struct {
	int						version;
	void					*globals;
	VectorMachineInit		init;
	VectorMachineConclude	conclude;
	VectorMachineFilter		filter;
	VectorMachineOutput		output;
} VectorMachineVersion;

typedef struct {
    int							chase;
    time_t						startTime;
    time_t						endTime;
	VMFlagType					blogFilterFlags;
	VMFlagType					outputFilterFlags;
	int							boxNumber;
	int							boxAreaCode;
	int							boxTelephoneNumber;
} LogSessionParams;

typedef  struct {
	char						*name;
	MachineFlags				flags;
	VectorMachineVersion		vectorVersion[kLogVersionNumber+1];
} VectorMachine;

#define EMPTYVERSION(vers) { vers, NULL, \
		(VectorMachineInit)VMInitUnknownVec, \
		(VectorMachineConclude)VMConcludeUnknownVec, \
		(VectorMachineFilter)VMFilterUnknownVec, \
		(VectorMachineOutput)VMOutputUnknownVec, \
		 }
		
//********************************************************
// prototypes
//********************************************************
// typedef for unused vectors
int VMInitUnknownVec(VectorMachineVersion *);
int VMConcludeUnknownVec(VectorMachineVersion *);
Boolean VMFilterUnknownVec(VectorMachineVersion *, char *, VMFlagType *);
int VMOutputUnknownVec(VectorMachineVersion *, char *);

VectorMachine *VMRecoverVectors(const int);
void VMDisposeVectors(VectorMachine *);

int VMInitVectorMachine(VectorMachine *);
int VMConcludeVectorMachine(VectorMachine *);
Boolean VMFilterConnection(VectorMachine *, char *, VMFlagType *);
int VMOutputConnection(VectorMachine *, char *);

void	LogSessionInitialize(LogSessionParams *params);
FILE 	*LogOpenFile(char *, BlogFileHeader *);
void	LogCloseFile(FILE *);
void	LogProcessFiles(VectorMachine *, char **, int, void (*)(VectorMachine *, char *, void *), void *);
void	LogProcessFile(VectorMachine *, FILE *, void (*)(VectorMachine *, char *, void *), void *);
void	LogSkipConnection(FILE	*fp);
char	*LogPhoneToStr(BlogPhoneNumber_v0 *phone);
void	LogHexDump(FILE *fp, const unsigned char *data, const long length);
void	Blog_Abort(void);


#endif //__logutil__
