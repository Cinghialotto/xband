// Copyright: @ 1994 Catapult Entertainment, Inc., all rights reserved
//
// $Id: StdioMachine.h,v 1.7 1995/05/26 22:51:29 jhsia Exp $
//
// $Log: StdioMachine.h,v $
 * Revision 1.7  1995/05/26  22:51:29  jhsia
 * switch to rcs keywords
 *
//

#ifndef __StdioMachine__
#define __StdioMachine__


// from OSCore/Exceptions.h
#define kBusError 1

// from ServerState.h
#define kCreditChange_Deduct_SuccessfulGame	(1L)
#define kCreditChange_Deduct_OnQueue		(1L<<1)
#define kCreditChange_Deduct_EvilReset		(1L<<2)
#define kCreditChange_Deduct_EvilCW			(1L<<3)
#define kCreditChange_Deduct_WaitReset		(1L<<4)
#define kCreditChange_Deduct_MailOnly		(1L<<5)
#define kCreditChange_Deduct_HosedSpecific	(1L<<6)
#define kCreditChange_Deduct_HosedAuto		(1L<<7)
#define kCreditChange_Penalize_WaitReset	(1L<<16)
#define kCreditChange_Penalize_EvilReset	(1L<<17)
#define kCreditChange_Penalize_PasswordCode	(1L<<18)

typedef struct {
	BlogLoginInfoFlags_v0		flags;
	} V3MachineGlobs;

typedef struct {
	BlogLoginInfoFlags_v0		flags;
	} V4MachineGlobs;

typedef struct {
	BlogLoginInfoFlags_v1		flags;
	} V5MachineGlobs;

typedef struct {
	BlogLoginInfoFlags_v2		flags;
	} V6MachineGlobs;

// v3 protos
int VMInit_v3(VectorMachineVersion *);
int VMConclude_v3(VectorMachineVersion *);
Boolean VMFilter_v3(VectorMachineVersion *, char *, VMFlagType *);
int VMOutput_v3(VectorMachineVersion *, char *);

int VMProcessLoginInfoStdio_v3(VectorMachineVersion *, char *);
int VMProcessConnCarrierStdio_v3(VectorMachineVersion *, char *);
int VMProcessConnTypeStdio_v3(VectorMachineVersion *, char *);
int VMProcessCrashRecordStdio_v3(VectorMachineVersion *, char *);
int VMProcessGameResultsStdio_v3(VectorMachineVersion *, char *);
int VMProcessGameErrorResultsStdio_v3(VectorMachineVersion *, char *);
int VMProcess800NetErrorsStdio_v3(VectorMachineVersion *, char *);
int VMProcessX25NetErrorsStdio_v3(VectorMachineVersion *, char *);
int VMProcessStreamErrorReportStdio_v3(VectorMachineVersion *, char *);
void PrintGenericGameResult_v3(NewGameResult *gameResult, char *header);
void PrintGenericNetErrors_v3(NetErrorRecord *netErrors, char *header);

static char *BillingTypeToString(unsigned billingType);
static char *ExitToStr(unsigned char status);
static Boolean LogIsRealCustomer(unsigned billingType);
void LogSessionInitialize(LogSessionParams *params);

// v4 protos
int VMInit_v4(VectorMachineVersion *);
int VMConclude_v4(VectorMachineVersion *);
// v4 filter is same as v3 filter
int VMOutput_v4(VectorMachineVersion *, char *);

int VMProcessGameResultsStdio_v4(VectorMachineVersion *, char *);
int VMProcessGameErrorResultsStdio_v4(VectorMachineVersion *, char *);
void PrintGenericGameResult_v4(NewGameResult *gameResult, char *header);

// v5 protos
int VMInit_v5(VectorMachineVersion *);
int VMConclude_v5(VectorMachineVersion *);
// v5 filter is same as v3 filter
int VMOutput_v5(VectorMachineVersion *, char *);

int VMProcessLoginInfoStdio_v5(VectorMachineVersion *, char *);
int VMProcessGameResultsStdio_v5(VectorMachineVersion *, char *);
int VMProcessGameErrorResultsStdio_v5(VectorMachineVersion *, char *);
int PrintGenericGameResult_v5(NewGameResult *gameResult, char *header);
static void PrintDBIDData_v5(void *dbData, int dbdSize);

// v6 protos
int VMInit_v6(VectorMachineVersion *);
int VMConclude_v6(VectorMachineVersion *);
// v6 filter is same as v3 filter
int VMOutput_v6(VectorMachineVersion *, char *);
int VMProcessGameErrorResultsStdio_v6(VectorMachineVersion *vmv, char *param);
int VMProcessGameResultsStdio_v6(VectorMachineVersion *vmv, char *param);
int VMProcessSendQGameErrorResultsStdio_v6(VectorMachineVersion *vmv, char *param);
int VMProcessSendQBoxErrorStdio_v6(VectorMachineVersion *vmv, char *param);
int PrintCreditChangeFlags_v6(unsigned long *param);

#endif // __StdioMachine__

