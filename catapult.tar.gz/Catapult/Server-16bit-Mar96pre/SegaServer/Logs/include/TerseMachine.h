// Copyright: Catapult Entertainment, Inc., all rights reserved
//
// $Id: TerseMachine.h,v 1.4 1995/05/26 22:51:30 jhsia Exp $
//
// $Log: TerseMachine.h,v $
 * Revision 1.4  1995/05/26  22:51:30  jhsia
 * switch to rcs keywords
 *

#ifndef __TerseMachine__
#define __TerseMachine__



// v4 protos
int VMTerseInit_v4(VectorMachineVersion *);
int VMTerseConclude_v4(VectorMachineVersion *);
Boolean VMTerseFilter_v4(VectorMachineVersion *vmv, char *blogRecord, VMFlagType *watchFlags);
int VMTerseOutput_v4(VectorMachineVersion *, char *);

static void TersePrintConnRec_v4(BlogLoginInfo_v3 *loginInfo, GameIDData *gameInfo, NewGameResult *gameResult, BlogOpponentInfo_v0 *opponentInfo);
static char *TerseExitToStr(unsigned char status);
static Boolean TerseLogIsRealCustomer(unsigned billingType);

int VMTerseOutput_v5(VectorMachineVersion *, char *);
static void TersePrintConnRec_v5(BlogLoginInfo_v5 *loginInfo, GameIDData *gameInfo, NewGameResult *gameResult, BlogOpponentInfo_v0 *opponentInfo);

int VMTerseOutput_v6(VectorMachineVersion *, char *);


#endif // __TerseMachine__


