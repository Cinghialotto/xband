// Copyright: @ 1994 Catapult Entertainment, Inc., all rights reserved
//
// $Id: dbLoad.h,v 1.9 1995/05/26 22:51:31 jhsia Exp $
//
// $Log: dbLoad.h,v $
 * Revision 1.9  1995/05/26  22:51:31  jhsia
 * switch to rcs keywords
 *

#ifndef __dbLoad__
#define __dbLoad__



// from OSCore/Exceptions.h
#define kBusError 1

// typedefs for v3 vectors

typedef struct {
	BlogLoginInfoFlags_v0		flags;
	} V3MachineGlobs;

typedef struct {
	BlogLoginInfoFlags_v0		flags;
	} V4MachineGlobs;

typedef struct {
	BlogLoginInfoFlags_v1		flags;
	} V5MachineGlobs;

typedef struct {
	BlogLoginInfoFlags_v2		flags;
	} V6MachineGlobs;

enum {
	kdbLoad_PlayerCreated =0,
	kdbLoad_AccountCreated
};

enum {
	kdbLoad_GameConnect =0,
	kdbLoad_MailConnect
};

enum {
	kdbLoad_AutoMatch =0,
	kdbLoad_Challenge,
	kdbLoad_AutoChal_Unknown
};

enum {
	kdbLoad_Dial =0,
	kdbLoad_Wait
};

enum {
	kdbLoad_OSStable =0,
	kdbLoad_OSUnstable
};

enum {
	kdbLoad_GameResultsIncomplete =0,
	kdbLoad_GameResultsComplete 
};

enum {
	kdbLoad_NetError_ServerConnects =0,
	kdbLoad_NetError_PeerConnects,
	kdbLoad_NetError_FrameErrors,
	kdbLoad_NetError_OverrunErrors,
	kdbLoad_NetError_PacketErrors,
	kdbLoad_NetError_CallWaitingInterrupt,
	kdbLoad_NetError_NoDialTone,
	kdbLoad_NetError_ServerBusy,
	kdbLoad_NetError_PeerBusy,
	kdbLoad_NetError_ServerDisconnect,
	kdbLoad_NetError_PeerDisconnect,
	kdbLoad_NetError_ServerAbort,
	kdbLoad_NetError_PeerAbort,
	kdbLoad_NetError_ServerNoAnswer,
	kdbLoad_NetError_PeerNoAnswer,
	kdbLoad_NetError_ServerHandshake,
	kdbLoad_NetError_PeerHandshake,
	kdbLoad_NetError_X25NoService,
	kdbLoad_NetError_CallWaitingError,
	kdbLoad_NetError_RemoteCallWaitingError,
	kdbLoad_NetError_ScriptLogin,
	kdbLoad_NetError_PacketRetrans,
	kdbLoad_NetError_UsedAltPop,
	kdbLoad_NetError_ctsTimeout,
	kdbLoad_NetError_allErrors
};

#define cdbLoad_Init		"INIT\t"
#define cdbLoad_ConnectionInfo	"CONN\t"
#define cdbLoad_ConnCarrier	"CARR\t"
#define cdbLoad_ConnType	"TYPE\t"
#define cdbLoad_Crash		"CRAS\t"
#define cdbLoad_CrashDispatch	"CRDS\t"
#define cdbLoad_CrashPC		"CRPC\t"
#define cdbLoad_GameResults	"GAME\t"
#define cdbLoad_GameErrorResults	"GMER\t"
#define cdbLoad_800Errors	"800E"
#define cdbLoad_X25Errors	"X25E"
#define cdbLoad_StreamErrors	"STRM\t"
#define cdbLoad_CreditChanges	"CRED\t"
#define cdbLoad_GameSpecific1	"GSP1\t"
#define cdbLoad_GameSpecific2	"GSP2\t"

// v3 protos
int VMInitdb_v3(VectorMachineVersion *);
int VMConcludedb_v3(VectorMachineVersion *);
Boolean VMFilterdb_v3(VectorMachineVersion *, char *, VMFlagType *);
int VMOutputdb_v3(VectorMachineVersion *, char *);

int VMProcessLoginInfodbLoad_v3(VectorMachineVersion *, char *);
int VMProcessConnCarrierdbLoad_v3(VectorMachineVersion *, char *);
int VMProcessConnTypedbLoad_v3(VectorMachineVersion *, char *);
int VMProcessCrashRecorddbLoad_v3(VectorMachineVersion *, char *);
int VMProcessGameResultsdbLoad_v3(VectorMachineVersion *, char *);
int VMProcessGameErrorResultsdbLoad_v3(VectorMachineVersion *, char *);
int VMProcess800NetErrorsdbLoad_v3(VectorMachineVersion *, char *);
int VMProcessX25NetErrorsdbLoad_v3(VectorMachineVersion *, char *);
int VMProcessStreamErrorReportdbLoad_v3(VectorMachineVersion *, char *);
void PrintGenericGameResult_dbLoad_v3(NewGameResult *gameResult, char *header);
void PrintGenericNetErrors_dbLoad_v3(NetErrorRecord *netErrors, char *header);

// static char *BillingTypeToString(unsigned billingType);
// static void LogHexDump(const unsigned char *data, const long length);
static char *LogPhoneToStr(BlogPhoneNumber_v0 *phone);
// static char *ExitToStr(unsigned char status);
// static Boolean LogIsRealCustomer(unsigned billingType);
// void LogSessionInitialize(LogSessionParams *params);

// v5 protos
int VMOutputdb_v5(VectorMachineVersion *, char *);

int VMProcessGameResultsdbLoad_v5(VectorMachineVersion *, char *);
int VMProcessGameErrorResultsdbLoad_v5(VectorMachineVersion *, char *);
int PrintGenericGameResult_dbLoad_v5(NewGameResult *gameResult, char *header);


// v6 protos
int VMOutputdb_v6(VectorMachineVersion *, char *);
int VMProcessGameErrorResultsdbload_v6(VectorMachineVersion *vmv, char *param);
int VMProcessGameResultsdbLoad_v6(VectorMachineVersion *vmv, char *param);
int VMProcessSendQGameErrorResultsdbLoad_v6(VectorMachineVersion *vmv, char *param);
int VMProcessSendQBoxErrordbLoad_v6(VectorMachineVersion *vmv, char *param);
int PrintCreditChangeFlagsDb_v6(unsigned long *param);

#endif // __dbLoad__
