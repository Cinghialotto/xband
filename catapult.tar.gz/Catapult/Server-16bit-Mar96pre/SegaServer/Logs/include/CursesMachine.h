// Copyright: @ 1994 Catapult Entertainment, Inc., all rights reserved
//
// $Id: CursesMachine.h,v 1.3 1995/05/26 22:51:26 jhsia Exp $
//
// $Log: CursesMachine.h,v $
 * Revision 1.3  1995/05/26  22:51:26  jhsia
 * switch to rcs keywords
 *

#define kMuxedBinlog	"/var/catapult/muxedbinlog"
// #define kMuxedBinlog "./muxedbinlog"
#define kSecondsInDay	(24 * 60 * 60)
#define kDateLen		256

typedef struct {
	BlogLoginInfoFlags_v0		flags;
	WINDOW						*win;
	char						date[kDateLen];
	time_t						endOfDay;
	char						*fileName;
	int 						totalConn;
	int 						real;
	int 						ConnX25;
	int 						Conn800;
	int 						mail;
	int 						game;
	int 						sighups;
	int 						newAccount;
	} V3CursesMachineGlobs;


// prototypes
static void 	ProcessConnectionInfo(VectorMachine *vm, char *blogRec, void *clientData);
static void 	ScreenInitialize(V3CursesMachineGlobs *);
static void 	ScreenCleanup(void);
static void 	RedisplayScreen(V3CursesMachineGlobs *);
static time_t	findMidnight(void);
static void 	InterruptHandler(int);
static void 	DoSessionMidnight(V3CursesMachineGlobs *);

int VMCursesInit_v3(VectorMachineVersion *);
int VMCursesConclude_v3(VectorMachineVersion *);
Boolean VMCursesFilter_v3(VectorMachineVersion *, char *, VMFlagType *);
int VMCursesOutput_v3(VectorMachineVersion *, char *);

static Boolean LogIsRealCustomer(unsigned billingType);
