// Copyright: @ 1994 Catapult Entertainment, Inc., all rights reserved
//
// $Id: CRMachine.h,v 1.8 1995/05/26 22:51:25 jhsia Exp $
//
// $Log: CRMachine.h,v $
 * Revision 1.8  1995/05/26  22:51:25  jhsia
 * switch to rcs keywords
 *
//

#ifndef __CRMachine__
#define __CRMachine__

/* Wait time */
#define MAX_WAIT_TIME		(10 * 60)    /* setting to 10 min for now */
#define ABS(x)			((x) >= 0 ? (x) : ((x) * -1))


// from OSCore/Exceptions.h
#define kBusError 1

#define MAX_X25_ADDR 16
#define MAX_PHONE_LEN 32
#define MAX_NAME_LEN 32

// used in both ConnRecHead and X25RecHead, used to distinguish record type
enum {
	kBogusConnection = 0,
	k800Connection,
	kX25Connection
};
	
// game errors
enum {
	kNoGameResultsGameErr = -450,
	kNoCallbackGameErr = -451
	};
	
typedef struct {
	int				err;
	char			*name;
	} ErrorTuple;
	
	
// linked list node, contained in key data structures
typedef struct Node {
	void			*data;					// points to the containing structure, has key in it
											// in list heads, points to associative data
	struct Node		*head;					// points to list head, which contains associative data 
											// (like box list or x25 node list which have same data)
	struct Node		*next;					// next record
	struct Node		*prev;					// previous record
} Node;

#define EMPTYNODE { NULL, NULL, NULL, NULL }

typedef struct {
	BlogLoginInfoFlags_v0	connFlags;
	// other cheeze as needed
} ConnectType;

typedef struct {
	int				count;
	short			master;
	short			slave;
	} ErrSortTuple;
	
typedef int (*SortProcessor)(VectorMachineVersion *);

typedef struct {
	char			*sortName;
	char			*sortDesc;
	SortProcessor	processor;
	} SortType;

// **************************************************************************************
// list head structures.  The lists are organized individually as 2D sparce matricies.  For instance,
// Each row of data is a box, and each column is a different login for this box.  Since there are multiple
// lists, 3D space is formed.  If the different lists are considered Z axis, the connection record that
// binds multiple nodes can be considered a thread through the individual nodes that make up the information
// about a connection
// **************************************************************************************

typedef struct {
	BlogBoxInfo_v0		boxSerial;
	char				name[MAX_NAME_LEN];
	char				phone[MAX_PHONE_LEN];
} UserRec;

typedef struct BoxRecHead {
	UserRec				user_info;
	int					total_count;
	Node				thisBox;				// all the logins this box made (column)
	struct BoxRecHead	*otherBox;				// the logins made by other boxes (row)
} BoxRecHead;

typedef struct X25RecHead {
	short				connType;					// must be same format to distinguish from ConnRecHead
	char				addr[MAX_X25_ADDR];
	char				pop[MAX_PHONE_LEN];
	int					total_count;
	int					err_count;
	Node				thisPop;					// forms column head for connections on this pop
	struct X25RecHead	*otherPop;					// forms row link for other pops
} X25RecHead;

// generic head for either 800 or bogus connections
typedef struct {
	short				connType;					// must be same format to distinguish from X25RecHead
	Node				connLink;
} ConnRecHead;

// generic head for either 800 or bogus connections
typedef struct {
	struct ErrTupleHead	*next;
	long				error;
	int					count;
	Node				masterBoxLink;
} ErrTupleHead;

// **************************************************************************************
// misc strtuctures
// **************************************************************************************
typedef struct {
	long			id;
	short			err_status;
	char			err_where;
	char			err_phase;
	short			local_err;
	int				play_time;
	int				local1;
	int				local2;
	int				remote1;
	int				remote2;
	short			identity;
} GameResultsRec;

typedef struct {
	unsigned char   flag;
	unsigned int	error1;
	unsigned int	error2;
	unsigned int	count;
} MatchedErrorsRec;

// part of ParamsRec (next structure)
typedef struct {
	char			*name;
	char			*desc;
	long			id1;
	long			id2;
	int				total_count;
	Node			thisGame;					// forms column head for connections on this game
	struct GameIDRecHead *otherGame;
} GameIDRecHead;

typedef struct {
	Boolean			do_verbose;
	int				do_phone;
	GameIDRecHead	*do_game;
	time_t			start_time;
	time_t			end_time;
} ParamsRec; 

typedef struct {
	int				automatch_wait;
	int				automatch_dial;
	int				automatch_err;
	int				chall_wait;
	int				chall_dial;
	int				chall_err;
	int				reregisters;
} MatchRec; 


// **************************************************************************************
// single connection record - collection of Nodes makes Z space binding of lists
// **************************************************************************************
typedef struct conn_rec_struct {
	BlogLoginInfoFlags_v0 flags;
	unsigned		processed			: 1;
	unsigned		master				: 1;
	int				cookie;
	time_t			start_time;
	GameResultsRec	*gameResults;
	GameResultsRec	*gameErrorResults;
	Node			errorLink;					// thread through all error pairs with match
	Node			gameLink;					// thread through all connections of this game
	Node			boxLink;					// thread through all connections this box has made
	Node			allLink;					// thread through all connections
	Node			connLink;					// thread through all connections of head connection type
												// head is either SessionRec.conns_800, SR.conns_x25, SR.conns_bogus
	struct conn_rec_struct *match;				// the box this connection peered with
	void			*blogRec;
} ConnRec;

// **************************************************************************************
// global state record
// **************************************************************************************
typedef struct {
	BoxRecHead		*box_list;
	BoxRecHead		bogusBoxList;
	X25RecHead		*conns_x25;
	GameIDRecHead	*gameList;
	ConnRecHead		conns_800;
	ErrTupleHead	*errList;
	Node			allConnsLink;
	int				num_x25;
	int				num_800;
	int				num_x25_bogus;
	int				num_800_bogus;
	time_t			start_time;	
	time_t			end_time;	
	int				num_boxes;
} LogSessionRec;

typedef int (*NodeFindFunc)(void *iterData, void *findData);

#define FIRSTNODE(node) (node.prev == node.head)
#define LASTNODE(node) (node.next == node.head)

// **************************************************************************************
// prototypes
// **************************************************************************************

int NodeAdd(void *data, Node *node, Node *after, Node *head);
int NodeDelete(Node *node);

// returns node data or nil
void *NodeFind(Node *head, NodeFindFunc func, void *iterData);
void InitHead(Node *head, void *data);

typedef struct {
	VectorMachine				*stdioMachine;
	GameIDRecHead				*game;
	SortType					*sort;
	BlogLoginInfoFlags_v0		flags;
	} V4MachineGlobs;

typedef struct {
	VectorMachine				*stdioMachine;
	GameIDRecHead				*game;
	SortType					*sort;
	BlogLoginInfoFlags_v0		flags;
	} V5MachineGlobs;

typedef struct {
	VectorMachine				*stdioMachine;
	GameIDRecHead				*game;
	SortType					*sort;
	BlogLoginInfoFlags_v2		flags;
	} V6MachineGlobs;

// v4 protos
static int VMInit_v4(VectorMachineVersion *);
static int VMConclude_v4(VectorMachineVersion *);
static Boolean VMFilter_v4(VectorMachineVersion *vmv, char *blogRecord, VMFlagType *watchFlags);
static int VMOutput_v4(VectorMachineVersion *, char *);

static int VMProcessLoginInfo_v4(VectorMachineVersion *, char *, ConnRec *);
static int VMProcessConnCarrier_v4(VectorMachineVersion *, char *, ConnRec *);
static int VMProcessConnType_v4(VectorMachineVersion *, char *, ConnRec *);
static int VMProcessCrashRecord_v4(VectorMachineVersion *, char *, ConnRec *);
static int VMProcessGameResults_v4(VectorMachineVersion *, char *, ConnRec *);
static int VMProcessGameErrorResults_v4(VectorMachineVersion *, char *, ConnRec *);
static int VMProcess800NetErrors_v4(VectorMachineVersion *, char *, ConnRec *);
static int VMProcessX25NetErrors_v4(VectorMachineVersion *, char *, ConnRec *);
static int VMProcessStreamErrorReport_v4(VectorMachineVersion *, char *, ConnRec *);
static void PrintGenericGameResult_v4(NewGameResult *gameResult, char *header, ConnRec *);
static void PrintGenericNetErrors_v4(NetErrorRecord *netErrors, char *header, ConnRec *);

static char *BillingTypeToString(unsigned billingType);
static char *ExitToStr(unsigned char status);
static Boolean LogIsRealCustomer(unsigned billingType);
static void ProcessGenericGameResult_v4(NewGameResult *, ConnRec *, Boolean);

static void MatchConnection(ConnRec *, Node *);
static void OutputMatch(VectorMachineVersion *vmv, ConnRec *cr);
static int CookieMatch(void *, void *);
static void DumpDB(VectorMachineVersion *);
static Boolean CompareBoxInfo(BlogBoxInfo_v0 *, BlogBoxInfo_v0 *);
static char *AppendAlloc(char **,int *, void *, int);

static void DumpPOPDB(VectorMachineVersion *);
static void DumpBoxDB(VectorMachineVersion *);
static void DumpGameDB(VectorMachineVersion *);
void DumpGame(VectorMachineVersion *, GameIDRecHead *);

static GameIDRecHead *FindGameIDByStr(char *);
static GameIDRecHead *FindGameIDByCheck(long );
static SortType *FindSort(char *);
static char *FindGameNameByID(long);
static char *GetGameErr(int);

// v5 protos
static int VMInit_v5(VectorMachineVersion *);
static int VMConclude_v5(VectorMachineVersion *);
static int VMOutput_v5(VectorMachineVersion *, char *);
static int VMProcessGameErrorResults_v5(VectorMachineVersion *, char *, ConnRec *);

// v6 protos
static int VMInit_v6(VectorMachineVersion *);
static int VMConclude_v6(VectorMachineVersion *);
static int VMOutput_v6(VectorMachineVersion *, char *);
static int VMProcessGameResults_v6(VectorMachineVersion *, char *, ConnRec *);


#endif // __CRMachine__


