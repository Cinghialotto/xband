#!/bin/sh

# $Id: summary_report.sh,v 1.1 1995/11/02 10:35:03 raja Exp $
# $Log: summary_report.sh,v $
# Revision 1.1  1995/11/02  10:35:03  raja
# Changes after the first successful run of the binlog loader from estragon
#

sdate=`date +%y%m%d`
userid=/
usage="$0 -u <userid> -d <summarydate-yymmdd>"
 

while getopts d:u: c
 do
        case $c in
        u)      userid=$OPTARG;;
        d)      sdate=$OPTARG;;
        \?)     echo $USAGE
                        exit 2;;
        esac
done

bindir=`dirname $0`;

SUMMARY_REPORT_FILE=/var/catapult/reports/daily_summary.$sdate
export SUMMARY_REPORT_FILE

sqlplus -s $userid <<EOF
set verify off
whenever sqlerror exit 100
start $bindir/summary_report $sdate
exit 0;
EOF

if [ $? -ne 0 ] 
then
	echo $0 failed with an error
	exit 2;
else
	cat $SUMMARY_REPORT_FILE | /usr/ucb/mail -s "BINLOG Summary Report" \
	raja@catapent.com
	exit 0
fi
