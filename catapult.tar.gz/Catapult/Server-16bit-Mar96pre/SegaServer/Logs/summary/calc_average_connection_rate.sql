rem Copyright: @ 1995 Catapult Entertainment Inc., all rights reserved
rem
rem $Id: calc_average_connection_rate.sql,v 1.9 1995/11/02 10:34:55 raja Exp $
rem
rem

declare 

l_end_time	date;
l_start_time	date;

cursor c1 is
select  trunc(start_time) + 
		trunc(((start_time-trunc(start_time)) * 1440)/30) * 30/1440
			 summary_date,
		round(count(*)/30 ,2) per_minute
from 	connection_log
where 	start_time between l_start_time and l_end_time
group by trunc(start_time) + 
		 trunc(((start_time-trunc(start_time)) * 1440)/30) * 30/1440;

begin

l_start_time := nvl (to_date('&&1', 'yymmdd'), trunc(sysdate)-1); 
l_end_time   := l_start_time + 86399/86400;

for rc1 in c1 loop

	delete from average_connection_rate
	where  summary_date = rc1.summary_date;

	insert into average_connection_rate (summary_date, rate)
	values				   (rc1.summary_date, rc1.per_minute); 

end loop;

commit;

end;
/
exit;
