rem $Id: build_summary.sql,v 1.5 1995/11/02 10:34:53 raja Exp $
rem $Log: build_summary.sql,v $
# Revision 1.5  1995/11/02  10:34:53  raja
# Changes after the first successful run of the binlog loader from estragon
#

declare 

	dcs		daily_connection_summary%rowtype;
	
	cursor main (l_start_time in date, l_end_time in date) is 
		select 	mail_or_game,
                x25_or_800,
                dial_or_wait,
                automatch_or_challenge,
                exit_status_code,
				duration
        from   	connection_code cc,
				connection_log cl
        where   start_time between l_start_time and l_end_time
		and	    cc.connection_code(+) = cl.connection_code;

	cursor neterror (l_start_time in date , l_end_time in date) is 
			select  
				count(be.server_connects) server_connects,
				count(be.peer_connects) peer_connects,
				count(frame_errors) frame_errors,
				count(overrun_errors) overrun_errors,
				count(packet_errors) packet_errors,
				count(call_waiting_interrupt) call_waiting_interrupt,
				count(no_dial_tone) no_dial_tone,
				count(server_busy) server_busy,
				count(peer_busy) peer_busy,
				count(server_disconnect) server_disconnect,
				count(peer_disconnect) peer_disconnect,
				count(server_abort) server_abort,
				count(peer_abort) peer_abort,
				count(server_no_answer) server_no_answer,
				count(peer_no_answer) peer_no_answer,
				count(server_handshake) server_handshake,
				count(peer_handshake) peer_handshake,
				count(x25_no_service) x25_no_service,
				count(call_waiting_error) call_waiting_error,
				count(remote_call_waiting_error) remote_call_waiting_error,
				count(script_login) script_login,
				count(packet_retrans) packet_retrans,
				count(used_alt_pop) used_alt_pop,
				count(cts_timeout) cts_timeout,
				count(all_errors) all_errors,
				count(spinloop_timeouts) spinloop_timeouts
            from   	
					box_error be, connection_log cl
            where  	start_time between l_start_time and l_end_time
            and 	cl.connection_uid = be.connection_uid;

	cursor games (l_start_time in date, l_end_time in date) is 
			select 	platform,
					game_name,
                    sum (decode (dial_or_wait, 'DIAL', 1, 0)) told_to_call,
                    sum (decode (dial_or_wait, 'WAIT', 1, 0)) told_to_wait
             from   game g,
					connection_code cc,
					connection_log cl
             where  start_time between l_start_time and l_end_time
             and    g.game_uid = cl.game_uid
             and    g.game_name not like 'Unknown%'
             and    g.game_name not like 'Test%'
             and    g.game_name is not null 
             and    g.platform  is not null 
			 and	cc.connection_code = cl.connection_code
			 and 	cc.mail_or_game = 'GAME'
             group  by 
					platform,
					game_name;

	cursor credit_change (l_start_time in date, l_end_time in date) is 
			select  
					sum(successful_game) successful_game,
					sum(on_queue) on_queue,
					sum(evil_reset) evil_reset,
					sum(evil_call_waiting) evil_call_waiting,
					sum(wait_reset) wait_reset,
					sum(mail_only) mail_only,
					sum(hosed_specific) hosed_specific,
					sum(hosed_auto) hosed_auto,
					sum(penalize_wait_reset) penalize_wait_reset,
					sum(penalize_evil_reset) penalize_evil_reset,
					sum(penalize_password_code) penalize_password_code
            from   	connection_log cl, 
					credit_log c
            where  	start_time between l_start_time and l_end_time
            and 	cl.connection_uid = c.connection_uid;
			

l_total_connections			number := 0;
l_total_duration			number := 0;

l_start_time				date;
l_end_time					date;


begin

	l_start_time := trunc (nvl (to_date ('&&1','yymmdd') , sysdate - 1));
	l_end_time := l_start_time + 86399/86400;

 	dcs.summary_date := trunc(l_start_time);
 	dcs.connections_800 := 0;
 	dcs.connections_x25 := 0;
 	dcs.new_accounts_logged := 0;
 	dcs.mail_only_connects := 0;
 	dcs.game_only_connects := 0;
 	dcs.unknown_connects := 0;
 	dcs.no_of_distinct_phones := 0;
 	dcs.no_of_hosed_batteries := 0;
 	dcs.duration_under_10 := 0;
 	dcs.duration_10_20 := 0;
 	dcs.duration_20_30 := 0;
 	dcs.duration_30_40 := 0;
 	dcs.duration_40_50 := 0;
 	dcs.duration_50_60 := 0;
 	dcs.duration_60_70 := 0;
 	dcs.duration_70_80 := 0;
 	dcs.duration_80_90 := 0;
 	dcs.duration_90_120 := 0;
 	dcs.duration_120_180 := 0;
 	dcs.duration_180_240 := 0;
 	dcs.duration_240_or_more := 0;
 	dcs.average_duration := 0;
 	dcs.total_no_of_connections := 0;
 	dcs.net_error_server_connect := 0;
 	dcs.net_error_peer_connect := 0;
 	dcs.net_error_frame_error := 0;
 	dcs.net_error_overrun_error := 0;
 	dcs.net_error_packet_error := 0;
 	dcs.net_error_cw_interrupt := 0;
 	dcs.net_error_nodial_tone := 0;
 	dcs.net_error_server_busy := 0;
 	dcs.net_error_peer_busy := 0;
 	dcs.net_error_server_disconnect := 0;
 	dcs.net_error_peer_disconnect := 0;
 	dcs.net_error_server_abort := 0;
 	dcs.net_error_peer_abort := 0;
 	dcs.net_error_server_no_answer := 0;
 	dcs.net_error_peer_no_answer := 0;
 	dcs.net_error_server_handshake := 0;
 	dcs.net_error_peer_handshake := 0;
 	dcs.net_error_x25_no_service := 0;
 	dcs.net_error_cw_error := 0;
 	dcs.net_error_remote_cw_error := 0;
 	dcs.net_error_script_login := 0;
 	dcs.net_error_packet_retrans := 0;
 	dcs.net_error_used_alt_pop := 0;
 	dcs.net_error_cts_timeout := 0;
 	dcs.net_error_all_errors := 0;
 	dcs.total_no_of_net_errors := 0;
 	dcs.unexpected_sighups_under_60 := 0;
 	dcs.unexpected_sighups_60_120 := 0;
 	dcs.unexpected_sighups_120_180 := 0;
 	dcs.unexpected_sighups_180_240 := 0;
 	dcs.unexpected_sighups_240_or_more := 0;
 	dcs.total_unexpected_sighups := 0;
 	dcs.no_of_streamerrors := 0;
 	dcs.told_to_wait_automatch := 0;
 	dcs.told_to_wait_specificmatch := 0;
 	dcs.total_told_to_wait := 0;
 	dcs.told_to_call_automatch := 0;
 	dcs.told_to_call_specificmatch := 0;
 	dcs.total_told_to_call := 0;
 	dcs.game_result_posted_to_log := 0;
 	dcs.total_no_of_crashes := 0;
 	dcs.success_game_deductions := 0;
 	dcs.reregister_deductions := 0;
 	dcs.evil_reset_deductions := 0;
 	dcs.call_waiting_deductions := 0;
 	dcs.reset_waiting_deductions := 0;
 	dcs.mail_only_deductions := 0;
 	dcs.hosed_specific_deductions := 0;
 	dcs.hosed_auto_deductions := 0;
 	dcs.total_no_of_credit_deducted := 0;
		
	for mc in main (l_start_time, l_end_time) loop

		if mc.x25_or_800 = 'X25' then 
			dcs.connections_x25 := dcs.connections_x25 + 1;
		elsif mc.x25_or_800 = '800' then 
			dcs.connections_800 := dcs.connections_800 + 1;
		end if;


		if mc.mail_or_game = 'MAIL' then
			dcs.mail_only_connects := dcs.mail_only_connects + 1;
		elsif mc.mail_or_game = 'GAME' then
			dcs.game_only_connects := dcs.game_only_connects + 1;
		else
			dcs.unknown_connects := dcs.unknown_connects + 1;
		end if;

		if mc.duration < 10 then
			dcs.duration_under_10 := dcs.duration_under_10 + 1;
		elsif mc.duration between 10 and 19 then 
			dcs.duration_10_20 := dcs.duration_10_20 + 1;
		elsif mc.duration between 20 and 29 then 
			dcs.duration_20_30 := dcs.duration_20_30 + 1;
		elsif mc.duration between 30 and 39 then 
			dcs.duration_30_40 := dcs.duration_30_40 + 1;
		elsif mc.duration between 40 and 49 then 
			dcs.duration_40_50 := dcs.duration_40_50 + 1;
		elsif mc.duration between 50 and 59 then 
			dcs.duration_50_60 := dcs.duration_50_60 + 1;
		elsif mc.duration between 60 and 69 then 
			dcs.duration_60_70 := dcs.duration_60_70 + 1;
		elsif mc.duration between 70 and 79 then 
			dcs.duration_70_80 := dcs.duration_70_80 + 1;
		elsif mc.duration between 80 and 89 then 
			dcs.duration_80_90 := dcs.duration_80_90 + 1;
		elsif mc.duration between 90 and 119 then 
			dcs.duration_90_120 := dcs.duration_90_120 + 1;
		elsif mc.duration between 120 and 179 then 
			dcs.duration_120_180 := dcs.duration_120_180 + 1;
		elsif mc.duration between 180 and 239 then 
			dcs.duration_180_240 := dcs.duration_180_240 + 1;
		elsif mc.duration >= 240 then
			dcs.duration_240_or_more := dcs.duration_240_or_more + 1;
		end if; 
            
		if mc.duration is not null then
        	l_total_connections := l_total_connections + 1;
        	l_total_duration := l_total_duration + mc.duration;
		end if;
            
 		if mc.exit_status_code = 4 then				-- sighup
			dcs.total_unexpected_sighups := dcs.total_unexpected_sighups + 1;
   			if mc.duration < 60 then
				dcs.unexpected_sighups_under_60 := 
						dcs.unexpected_sighups_under_60 + 1;
			elsif mc.duration < 120 then
				dcs.unexpected_sighups_60_120 := 
						dcs.unexpected_sighups_60_120 + 1;
			elsif mc.duration < 180 then
				dcs.unexpected_sighups_120_180 := 
						dcs.unexpected_sighups_120_180 + 1;
			elsif mc.duration < 240 then
				dcs.unexpected_sighups_180_240 := 
						dcs.unexpected_sighups_180_240 + 1;
			else
				dcs.unexpected_sighups_240_or_more := 
						dcs.unexpected_sighups_240_or_more + 1;
			end if;

		end if;

		if mc.mail_or_game = 'GAME' then
		if mc.dial_or_wait = 'WAIT' then 

			dcs.total_told_to_wait := dcs.total_told_to_wait + 1;
			if mc.automatch_or_challenge = 'AUTO' then
				dcs.told_to_wait_automatch := dcs.told_to_wait_automatch + 1;
			elsif mc.automatch_or_challenge = 'CHALLENGE' then
				dcs.told_to_wait_specificmatch := dcs.told_to_wait_specificmatch + 1;
			end if;

		elsif mc.dial_or_wait = 'DIAL' then 

			dcs.total_told_to_call := dcs.total_told_to_call + 1;
			if mc.automatch_or_challenge = 'AUTO' then
				dcs.told_to_call_automatch := dcs.told_to_call_automatch + 1;
			elsif mc.automatch_or_challenge = 'CHALLENGE' then
				dcs.told_to_call_specificmatch := dcs.told_to_call_specificmatch + 1;
			end if;

		end if;
		end if;

	end loop;

	if l_total_connections > 0 then
		dcs.average_duration := round (l_total_duration / 
									 	l_total_connections, 0);
	end if;


    open neterror (l_start_time, l_end_time);
	fetch neterror into
			dcs.net_error_server_connect,
			dcs.net_error_peer_connect,
			dcs.net_error_frame_error,
			dcs.net_error_overrun_error,
			dcs.net_error_packet_error,
			dcs.net_error_cw_interrupt,
			dcs.net_error_nodial_tone,
			dcs.net_error_server_busy,
			dcs.net_error_peer_busy,
			dcs.net_error_server_disconnect,
			dcs.net_error_peer_disconnect,
			dcs.net_error_server_abort,
			dcs.net_error_peer_abort,
			dcs.net_error_server_no_answer,
			dcs.net_error_peer_no_answer,
			dcs.net_error_server_handshake,
			dcs.net_error_peer_handshake,
			dcs.net_error_x25_no_service,
			dcs.net_error_cw_error,
			dcs.net_error_remote_cw_error,
			dcs.net_error_script_login,
			dcs.net_error_packet_retrans,
			dcs.net_error_used_alt_pop,
			dcs.net_error_cts_timeout,
			dcs.net_error_all_errors,
			dcs.net_error_spinloop_timeouts;
	close neterror;

    open credit_change (l_start_time, l_end_time);
	fetch credit_change into
					dcs.success_game_deductions,
					dcs.reregister_deductions,
					dcs.evil_reset_deductions,
					dcs.call_waiting_deductions,
					dcs.reset_waiting_deductions,
					dcs.mail_only_deductions,
					dcs.hosed_specific_deductions,
					dcs.hosed_auto_deductions,
					dcs.penalize_wait_reset_deductions,
					dcs.penalize_evil_reset_deductions,
					dcs.password_code_deductions;

                
	delete 
	from 	daily_connection_summary 
	where 	summary_date = dcs.summary_date;


insert into daily_connection_summary (
 	summary_date,
 	connections_800,
 	connections_x25,
 	new_accounts_logged,
 	mail_only_connects,
 	game_only_connects,
 	unknown_connects,
 	no_of_distinct_phones,
 	no_of_hosed_batteries,
 	duration_under_10,
 	duration_10_20,
 	duration_20_30,
 	duration_30_40,
 	duration_40_50,
 	duration_50_60,
 	duration_60_70,
 	duration_70_80,
 	duration_80_90,
 	duration_90_120,
 	duration_120_180,
 	duration_180_240,
 	duration_240_or_more,
 	average_duration,
 	total_no_of_connections,
 	net_error_server_connect,
 	net_error_peer_connect,
 	net_error_frame_error,
 	net_error_overrun_error,
 	net_error_packet_error,
 	net_error_cw_interrupt,
 	net_error_nodial_tone,
 	net_error_server_busy,
 	net_error_peer_busy,
 	net_error_server_disconnect,
 	net_error_peer_disconnect,
 	net_error_server_abort,
 	net_error_peer_abort,
 	net_error_server_no_answer,
 	net_error_peer_no_answer,
 	net_error_server_handshake,
 	net_error_peer_handshake,
 	net_error_x25_no_service,
 	net_error_cw_error,
 	net_error_remote_cw_error,
 	net_error_script_login,
 	net_error_packet_retrans,
 	net_error_used_alt_pop,
 	net_error_cts_timeout,
 	net_error_all_errors,
 	net_error_spinloop_timeouts,
 	total_no_of_net_errors,
 	unexpected_sighups_under_60,
 	unexpected_sighups_60_120,
 	unexpected_sighups_120_180,
 	unexpected_sighups_180_240,
 	unexpected_sighups_240_or_more,
 	total_unexpected_sighups,
 	no_of_streamerrors,
 	told_to_wait_automatch,
 	told_to_wait_specificmatch,
 	total_told_to_wait,
 	told_to_call_automatch,
 	told_to_call_specificmatch,
 	total_told_to_call,
 	game_result_posted_to_log,
 	total_no_of_crashes,
 	success_game_deductions,
 	reregister_deductions,
 	evil_reset_deductions,
 	call_waiting_deductions,
 	reset_waiting_deductions,
 	mail_only_deductions,
 	hosed_specific_deductions,
 	hosed_auto_deductions,
	penalize_wait_reset_deductions,
	penalize_evil_reset_deductions,
	password_code_deductions,
 	total_no_of_credit_deducted)
values (
 	dcs.summary_date,
 	dcs.connections_800,
 	dcs.connections_x25,
 	dcs.new_accounts_logged,
 	dcs.mail_only_connects,
 	dcs.game_only_connects,
 	dcs.unknown_connects,
 	dcs.no_of_distinct_phones,
 	dcs.no_of_hosed_batteries,
 	dcs.duration_under_10,
 	dcs.duration_10_20,
 	dcs.duration_20_30,
 	dcs.duration_30_40,
 	dcs.duration_40_50,
 	dcs.duration_50_60,
 	dcs.duration_60_70,
 	dcs.duration_70_80,
 	dcs.duration_80_90,
 	dcs.duration_90_120,
 	dcs.duration_120_180,
 	dcs.duration_180_240,
 	dcs.duration_240_or_more,
 	dcs.average_duration,
 	l_total_connections,
 	dcs.net_error_server_connect,
 	dcs.net_error_peer_connect,
 	dcs.net_error_frame_error,
 	dcs.net_error_overrun_error,
 	dcs.net_error_packet_error,
 	dcs.net_error_cw_interrupt,
 	dcs.net_error_nodial_tone,
 	dcs.net_error_server_busy,
 	dcs.net_error_peer_busy,
 	dcs.net_error_server_disconnect,
 	dcs.net_error_peer_disconnect,
 	dcs.net_error_server_abort,
 	dcs.net_error_peer_abort,
 	dcs.net_error_server_no_answer,
 	dcs.net_error_peer_no_answer,
 	dcs.net_error_server_handshake,
 	dcs.net_error_peer_handshake,
 	dcs.net_error_x25_no_service,
 	dcs.net_error_cw_error,
 	dcs.net_error_remote_cw_error,
 	dcs.net_error_script_login,
 	dcs.net_error_packet_retrans,
 	dcs.net_error_used_alt_pop,
 	dcs.net_error_cts_timeout,
 	dcs.net_error_all_errors,
 	dcs.net_error_spinloop_timeouts,
 	dcs.total_no_of_net_errors,
 	dcs.unexpected_sighups_under_60,
 	dcs.unexpected_sighups_60_120,
 	dcs.unexpected_sighups_120_180,
 	dcs.unexpected_sighups_180_240,
 	dcs.unexpected_sighups_240_or_more,
 	dcs.total_unexpected_sighups,
 	dcs.no_of_streamerrors,
 	dcs.told_to_wait_automatch,
 	dcs.told_to_wait_specificmatch,
 	dcs.total_told_to_wait,
 	dcs.told_to_call_automatch,
 	dcs.told_to_call_specificmatch,
 	dcs.total_told_to_call,
 	dcs.game_result_posted_to_log,
 	dcs.total_no_of_crashes,
 	dcs.success_game_deductions,
 	dcs.reregister_deductions,
 	dcs.evil_reset_deductions,
 	dcs.call_waiting_deductions,
 	dcs.reset_waiting_deductions,
 	dcs.mail_only_deductions,
 	dcs.hosed_specific_deductions,
 	dcs.hosed_auto_deductions,
	dcs.penalize_wait_reset_deductions,
	dcs.penalize_evil_reset_deductions,
	dcs.password_code_deductions,
 	dcs.total_no_of_credit_deducted);



     delete 
	 from 	daily_games_summary 
     where 	summary_date = dcs.summary_date;

     for rc1 in  games (l_start_time, l_end_time) loop

           insert into daily_games_summary (summary_date,
											game_name,
											platform,
											told_to_wait,
											told_to_call)
           values (dcs.summary_date,
                   rc1.game_name,
				   rc1.platform,
                   rc1.told_to_wait,
                   rc1.told_to_call);
     end loop;
commit;

end;
/
