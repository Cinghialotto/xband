declare

	cursor c2 is
	select 	game_id,
		trunc(start_time,'hh24') call_time,
		decode(toll_call, 0, 0,
				  null, 0,
				  decode(xbn_provider_code, 1, 1, 2)) call_type,
		mgr.game_error master_error,
		sgr.game_error slave_error,
		count(*) frequency
	from 	connection_log cl,
		game_result mgr,
		game_result sgr,
		game g
	where   cl.dialed_phone_number is not null
	and     start_time between to_date('&&1') and to_date('&&2')
	and     mgr.master_connection_uid = cl.connection_uid
	and     sgr.master_connection_uid = cl.peer_connection_uid
	and	g.game_uid = cl.game_uid
	group by game_id,
		trunc(start_time,'hh24'),
		decode(toll_call, 0, 0,
				  null, 0,
				  decode(xbn_provider_code, 1, 1, 2)),
		mgr.game_error,
		sgr.game_error;

commit_counter		number := 0;
ps			phone_stats%rowtype;

begin

ps.game_id		:= null;
ps.call_type		:= null;
ps.call_time		:= null;

for rc2 in c2 loop

	if (ps.call_type != rc2.call_type or
	   ps.game_id != rc2.game_id or
	   ps.call_time != rc2.call_time) or
	   ps.call_type is null then


	if ps.call_type is not null then

	  delete 
	  from 	phone_stats
	  where   game_id = ps.game_id
	  and     call_time = ps.call_time
	  and 	call_type = ps.call_type;

	  insert into phone_stats
		(game_id,
		call_time,
		call_type,
		good_games,
		bad_games,
		busy_call_waiting,
		busy_never_called,
		busy_no_answer,
		busy_reset,
		busy_timeout,
		call_waiting,
		call_waiting_timeout,
		garbled_peer_exchange_data,
		handshake,
		handshake_problem,
		master_reset,
		no_answer_opponent_verify,
		no_dialtone_call_waiting,
		no_dialtone_never_called,
		no_dialtone_no_answer,
		no_dialtone_reset,
		no_dialtone,
		opponent_verify_failed,
		opponent_verify_failed_cw,
		opponent_verify_failed_re,
		reset,
		reset_call_waiting,
		reset_never_called,
		reset_no_answer,
		reset_opponent_verification,
		slave_never_got_called,
		slave_reset,
		timeout,
		timeout_never_called,
		timeout_reset,
		unknown,
		unknown_call_waiting,
		unknown_opponent_verification,
		unknown_reset)
	values
		(ps.game_id,
		ps.call_time,
		ps.call_type,
		ps.good_games,
		ps.bad_games,
		ps.busy_call_waiting,
		ps.busy_never_called,
		ps.busy_no_answer,
		ps.busy_reset,
		ps.busy_timeout,
		ps.call_waiting,
		ps.call_waiting_timeout,
		ps.garbled_peer_exchange_data,
		ps.handshake,
		ps.handshake_problem,
		ps.master_reset,
		ps.no_answer_opponent_verify,
		ps.no_dialtone_call_waiting,
		ps.no_dialtone_never_called,
		ps.no_dialtone_no_answer,
		ps.no_dialtone_reset,
		ps.no_dialtone,
		ps.opponent_verify_failed,
		ps.opponent_verify_failed_cw,
		ps.opponent_verify_failed_re,
		ps.reset,
		ps.reset_call_waiting,
		ps.reset_never_called,
		ps.reset_no_answer,
		ps.reset_opponent_verification,
		ps.slave_never_got_called,
		ps.slave_reset,
		ps.timeout,
		ps.timeout_never_called,
		ps.timeout_reset,
		ps.unknown,
		ps.unknown_call_waiting,
		ps.unknown_opponent_verification,
		ps.unknown_reset);

	    if commit_counter > 10 then
		commit;
		commit_counter := 0;
	    end if;
	    commit_counter := commit_counter + 1;

	end if;

	  ps.game_id 	:= rc2.game_id;
	  ps.call_time 	:= rc2.call_time;
	  ps.call_type	:= rc2.call_type;
  
	  ps.busy_call_waiting := null;
	  ps.busy_never_called := null;
	  ps.busy_no_answer := null;
	  ps.busy_reset := null;
	  ps.busy_timeout := null;
	  ps.call_waiting := null;
	  ps.call_waiting_timeout := null;
	  ps.garbled_peer_exchange_data := null;
	  ps.handshake := null;
	  ps.handshake_problem := null;
	  ps.master_reset := null;
	  ps.no_answer_opponent_verify := null;
	  ps.no_dialtone_call_waiting := null;
	  ps.no_dialtone_never_called := null;
	  ps.no_dialtone_no_answer := null;
	  ps.no_dialtone_reset := null;
	  ps.no_dialtone := null;
	  ps.opponent_verify_failed := null;
	  ps.opponent_verify_failed_cw := null;
	  ps.opponent_verify_failed_re := null;
	  ps.reset := null;
	  ps.reset_call_waiting := null;
	  ps.reset_never_called := null;
	  ps.reset_no_answer := null;
	  ps.reset_opponent_verification := null;
	  ps.slave_never_got_called := null;
	  ps.slave_reset := null;
	  ps.timeout := null;
	  ps.timeout_never_called := null;
	  ps.timeout_reset := null;
	  ps.unknown := null;
	  ps.unknown_call_waiting := null;
	  ps.unknown_opponent_verification := null;
	  ps.unknown_reset := null;
	  ps.good_games := null;
	  ps.bad_games := null;
	  ps.good_games	:= 0;
	  ps.bad_games	:= 0;

	end if;




	if (rc2.master_error = -413 and rc2.slave_error = -432) or
   	(rc2.master_error = -413 and rc2.slave_error = -434) then
		ps.busy_call_waiting := nvl(ps.busy_call_waiting,0) +
					 rc2.frequency;
	end if;
	
	if (rc2.master_error = -413 and rc2.slave_error = 0) then
		ps.busy_never_called := rc2.frequency;
	end if;
	
	if (rc2.master_error = -413 and rc2.slave_error = -415) then
		ps.busy_no_answer := rc2.frequency;
	end if;
	
	if (rc2.master_error = -413 and rc2.slave_error = -13) then
		ps.busy_reset := rc2.frequency;
	end if;
	
	if (rc2.master_error = -413 and rc2.slave_error = -426) then
		ps.busy_timeout := rc2.frequency;
	end if;
	
	if (rc2.master_error = -432 and rc2.slave_error = -434) or
   	(rc2.master_error = -415 and rc2.slave_error = -434) or
   	(rc2.master_error = -415 and rc2.slave_error = -432) then
		ps.call_waiting := nvl(ps.call_waiting, 0) +
 			rc2.frequency;
	end if;
	
	if (rc2.master_error = -432 and rc2.slave_error = -432) or
   	(rc2.master_error = -415 and rc2.slave_error = -426) then
		ps.call_waiting_timeout := nvl(ps.call_waiting_timeout,0) + 
			rc2.frequency;
	end if;
	
	if (rc2.master_error = -433 and rc2.slave_error = -433) then
		ps.garbled_peer_exchange_data := rc2.frequency;
	end if;
	
	if (rc2.master_error = -429 and rc2.slave_error = -429) or
   	(rc2.master_error = -415 and rc2.slave_error = -429) or
   	(rc2.master_error = -413 and rc2.slave_error = -429) then
		ps.handshake := nvl(ps.handshake,0) + 
			rc2.frequency;
	end if;
	
	if (rc2.master_error = -415 and rc2.slave_error = -415) or
   	(rc2.master_error = -429 and rc2.slave_error = -415) then
		ps.handshake_problem := nvl(ps.handshake_problem,0) + 
			rc2.frequency;
	end if;
	
	if (rc2.master_error = -13 and rc2.slave_error = -426) then
		ps.master_reset := rc2.frequency;
	end if;
	
	if (rc2.master_error = -415 and rc2.slave_error = -306) then
		ps.no_answer_opponent_verify := rc2.frequency;
	end if;
	
	if (rc2.master_error = -416 and rc2.slave_error = -434) then
		ps.no_dialtone_call_waiting := rc2.frequency;
	end if;
	
	if (rc2.master_error = -416 and rc2.slave_error = 0) then
		ps.no_dialtone_never_called := rc2.frequency;
	end if;
	
	if (rc2.master_error = -416 and rc2.slave_error = -415) then
		ps.no_dialtone_no_answer := rc2.frequency;
	end if;
	
	if (rc2.master_error = -416 and rc2.slave_error = -13) then
		ps.no_dialtone_reset := rc2.frequency;
	end if;
	
	if (rc2.master_error = -416 and rc2.slave_error = -426) then
		ps.no_dialtone := rc2.frequency;
	end if;
	
	if (rc2.master_error = -306 and rc2.slave_error = -306) or
   	(rc2.master_error = -306 and rc2.slave_error = 0) then
		ps.opponent_verify_failed := nvl(ps.opponent_verify_failed,0) + 
			rc2.frequency;
	end if;
	
	if (rc2.master_error = -306 and rc2.slave_error = -432) then
		ps.opponent_verify_failed_cw := rc2.frequency;
	end if;
	
	if (rc2.master_error = -306 and rc2.slave_error = -13) then
		ps.opponent_verify_failed_re := rc2.frequency;
	end if;
	
	if (rc2.master_error = -13 and rc2.slave_error = -13) then
		ps.reset := rc2.frequency;
	end if;
	
	if (rc2.master_error = -13 and rc2.slave_error = -432) then
		ps.reset_call_waiting := rc2.frequency;
	end if;
	
	if (rc2.master_error = -13 and rc2.slave_error = 0) then
		ps.reset_never_called := rc2.frequency;
	end if;
	
	if (rc2.master_error = -13 and rc2.slave_error = -415) then
		ps.reset_no_answer := rc2.frequency;
	end if;
	
	if (rc2.master_error = -13 and rc2.slave_error = -306) then
		ps.reset_opponent_verification := rc2.frequency;
	end if;
	
	if (rc2.master_error = -415 and rc2.slave_error = 0) then
		ps.slave_never_got_called := rc2.frequency;
	end if;
	
	if (rc2.master_error = -415 and rc2.slave_error = -13) then
		ps.slave_reset := rc2.frequency;
	end if;
	
	if (rc2.master_error = -415 and rc2.slave_error = -426) or
   	(rc2.master_error = -426 and rc2.slave_error = -426) then
		ps.timeout := nvl(ps.timeout,0) + 
			rc2.frequency;
	end if;
	
	if (rc2.master_error = -426 and rc2.slave_error = 0) then
		ps.timeout_never_called := rc2.frequency;
	end if;
	
	if (rc2.master_error = -426 and rc2.slave_error = -13) then
		ps.timeout_reset := rc2.frequency;
	end if;
	
	if (rc2.master_error = 0 and rc2.slave_error = -426) or
   	(rc2.master_error = 0 and rc2.slave_error = -415) then
		ps.unknown := nvl(ps.unknown, 0) + 
			rc2.frequency;
	end if;
	
	if (rc2.master_error = -436 and rc2.slave_error = -432) then
		ps.unknown_call_waiting := rc2.frequency;
	end if;
	
	if (rc2.master_error = 0 and rc2.slave_error = -306) then
		ps.unknown_opponent_verification := rc2.frequency;
	end if;
	
	if (rc2.master_error = 0 and rc2.slave_error = -13) then
		ps.unknown_reset := rc2.frequency;
	end if;

	if rc2.master_error = 0 and rc2.slave_error = 0 then
		ps.good_games := ps.good_games + rc2.frequency;
	else
		ps.bad_games := ps.bad_games + rc2.frequency;
	end if;



end loop;

	insert into phone_stats
		(game_id,
		call_time,
		call_type,
		good_games,
		bad_games,
		busy_call_waiting,
		busy_never_called,
		busy_no_answer,
		busy_reset,
		busy_timeout,
		call_waiting,
		call_waiting_timeout,
		garbled_peer_exchange_data,
		handshake,
		handshake_problem,
		master_reset,
		no_answer_opponent_verify,
		no_dialtone_call_waiting,
		no_dialtone_never_called,
		no_dialtone_no_answer,
		no_dialtone_reset,
		no_dialtone,
		opponent_verify_failed,
		opponent_verify_failed_cw,
		opponent_verify_failed_re,
		reset,
		reset_call_waiting,
		reset_never_called,
		reset_no_answer,
		reset_opponent_verification,
		slave_never_got_called,
		slave_reset,
		timeout,
		timeout_never_called,
		timeout_reset,
		unknown,
		unknown_call_waiting,
		unknown_opponent_verification,
		unknown_reset)
	values
		(ps.game_id,
		ps.call_time,
		ps.call_type,
		ps.good_games,
		ps.bad_games,
		ps.busy_call_waiting,
		ps.busy_never_called,
		ps.busy_no_answer,
		ps.busy_reset,
		ps.busy_timeout,
		ps.call_waiting,
		ps.call_waiting_timeout,
		ps.garbled_peer_exchange_data,
		ps.handshake,
		ps.handshake_problem,
		ps.master_reset,
		ps.no_answer_opponent_verify,
		ps.no_dialtone_call_waiting,
		ps.no_dialtone_never_called,
		ps.no_dialtone_no_answer,
		ps.no_dialtone_reset,
		ps.no_dialtone,
		ps.opponent_verify_failed,
		ps.opponent_verify_failed_cw,
		ps.opponent_verify_failed_re,
		ps.reset,
		ps.reset_call_waiting,
		ps.reset_never_called,
		ps.reset_no_answer,
		ps.reset_opponent_verification,
		ps.slave_never_got_called,
		ps.slave_reset,
		ps.timeout,
		ps.timeout_never_called,
		ps.timeout_reset,
		ps.unknown,
		ps.unknown_call_waiting,
		ps.unknown_opponent_verification,
		ps.unknown_reset);

commit;

end;
/
