declare
	cursor c1 is
	select 	box_serial_number,
			connection_type_code,
			sum(duration) duration,
			sum(play_time) play_time,
			count(*) connects
	from	box_log bl,
			player_log pl,
			game_result gr,
			connection_log cl
	where 	pl.player_uid = cl.player_uid
	and		bl.box_uid = pl.box_uid
	and		gr.master_connection_uid (+) = cl.connection_uid
	and 	(result_type_code = 0 or result_type_code is null)
	and		trunc(start_time) between '01-sep-95' and '30-sep-95'
	group by box_serial_number, 
			connection_type_code;
			

n		number := 0;

begin

for rc1 in c1 loop

	insert into box_connects (box, connection_type_code, duration, play_time,
							  connects)
	values (rc1.box_Serial_number, rc1.connection_type_code, 
			rc1.duration, rc1.play_time, rc1.connects);

	n := n+1;

	if n> 100 then
		commit;
		n := 0;
	end if;
							
end loop;

commit;
end;
/
exit;
