#!/bin/sh 

#
# Copyright: @ 1995 Catapult Entertainment Inc., all right reserved
#
# $Id: binlog_summaries.sh,v 1.3 1996/02/05 16:30:29 raja Exp $
#
# $Log: binlog_summaries.sh,v $
# Revision 1.3  1996/02/05  16:30:29  raja
# added steveb to list of people the average copnnection rate report is mailed
# to
#
# Revision 1.2  1995/11/07  07:53:59  raja
# better error handling
#
# Revision 1.1  1995/11/02  10:34:51  raja
# Changes after the first successful run of the binlog loader from estragon
#


bindir=`dirname $0`
userid=/
sdate=`date +%y%m%d`
usage="$0 -u <userid> -d <summarydate-yymmdd>"


 while getopts d:u: c
 do
        case $c in
        u)      userid=$OPTARG;;
        d)      sdate=$OPTARG;;
        \?)     echo $USAGE
                        exit 2;;
        esac
 done


date
$bindir/build_summary.sh -u $userid -d $sdate
if [ $? -eq 0 ] 
then
	$bindir/summary_report.sh -u $userid -d $sdate
fi

date

$bindir/calc_xbn_summary.sh -u $userid -d $sdate

$bindir/calc_average_connection_rate.sh -u $userid -d $sdate

runrep userid=$userid report=$bindir/connrate.rep batch=yes paramform=no destype=file desname=/var/catapult/reports/connrate.$sdate

/usr/ucb/mail -s "Average Connection Rates" raja@mgate steveb@mgate </var/catapult/reports/connrate.$sdate

if [ `date +%a` = 'Mon' ]
then
/usr/ucb/mail -s "Average Connection Rates" jevans@mgate richard@mgate </var/catapult/reports/connrate.$sdate
fi

exit 0
