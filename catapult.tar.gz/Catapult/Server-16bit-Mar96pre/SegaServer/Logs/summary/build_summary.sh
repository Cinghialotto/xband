#!/bin/sh

# $Id: build_summary.sh,v 1.1 1995/11/02 10:34:52 raja Exp $
# $Log: build_summary.sh,v $
# Revision 1.1  1995/11/02  10:34:52  raja
# Changes after the first successful run of the binlog loader from estragon
#

sdate=`date +%y%m%d`
userid=/
usage="$0 -u <userid> -d <summarydate-yymmdd>"
 

while getopts d:u: c
 do
        case $c in
        u)      userid=$OPTARG;;
        d)      sdate=$OPTARG;;
        \?)     echo $USAGE
                        exit 2;;
        esac
done

bindir=`dirname $0`;

sqlplus $userid <<EOF
set verify off
rem set echo off
set termout off
whenever sqlerror exit 100
start $bindir/build_summary.sql $sdate
exit;
EOF

if [ $? -eq 0 ] 
then
	exit 0;
else
	echo $0 failed.
	exit 2
fi
