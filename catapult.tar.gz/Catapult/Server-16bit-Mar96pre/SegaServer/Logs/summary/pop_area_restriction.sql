declare
cursor c1 is
	select box_serial_number,
		box_region,
		nvl(area_restriction,0) area_restriction
	from box;

nrecs	number := 0;
l_area_restriction	varchar2(30);

begin

for rc1 in c1 loop

	if (rc1.area_restriction = 0) then
		l_area_restriction := 'Local';
	end if;

	if (get_bit(rc1.area_restriction,0) = 1) then
		l_area_restriction := 'Long Distance';
	elsif (get_bit(rc1.area_restriction,1) = 1) then
		l_area_restriction := 'Player List Long Distance';
	elsif (get_bit(rc1.area_restriction,5) = 1) then
		l_area_restriction := 'XBN Long Distance';
	elsif (get_bit(rc1.area_restriction,6) = 1) then
		l_area_restriction := 'XBN Player List Long Distance';
	end if;

	update area_restriction
	set area_restriction = l_area_restriction
	where box_serial_number = rc1.box_serial_number
	and   box_region = rc1.box_region;

	if sql%notfound then
		insert into area_restriction (box_serial_number,
					      box_region,
					      area_restriction)
		values 			 (rc1.box_serial_number,
					      rc1.box_region,
					      l_area_restriction);
	end if;

	nrecs := nrecs + 1;
	if (nrecs >  100) then
		commit;
		nrecs := 0;
	end if;

end loop;

commit;

end;
/

