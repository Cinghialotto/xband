set verify off

declare
	t_as 	varchar2(60) := '%Account status changed from Active to Suspended%';
	t_ap	varchar2(60) := '%Account status changed from Active to Pending%';
	t_ac	varchar2(60) := '%Account status changed from Active to Closed%';
	t_sa	varchar2(60) := '%Account status changed from Suspended to Active%';
	t_sp	varchar2(60) := '%Account status changed from Suspended to Pending%';
	t_sc	varchar2(60) := '%Account status changed from Suspended to Closed%';
	t_pc	varchar2(60) := '%Account status changed from Pending to Closed%';
	t_pa	varchar2(60) := '%Account status changed from Pending to Active%';
	t_ps	varchar2(60) := '%Account status changed from Pending to Suspended%';
	t_cs	varchar2(60) := '%Account status changed from Closed to Suspended%';
	t_ca	varchar2(60) := '%Account status changed from Closed to Active%';
	t_cp	varchar2(60) := '%Account status changed from Closed to Pending%';

	cursor c1 (p_date in date, p_text in varchar2) is
		select 	count(*) 
		from 	box_history bh, 
				box b
		where 	creation_date between p_date and p_date + 86399/86400
		and     b.box_serial_number = bh.box_serial_number
		and 	b.billing_type_code in (10003, 10004, 10000)
		and		description like p_text;

	l_status_activity		status_activity%rowtype;

begin

	l_status_activity.summary_date := to_date(nvl('&&1', to_char(sysdate)));

	open c1 (l_status_activity.summary_date, t_as);
	fetch c1 into l_status_activity.active_to_suspended;
	close c1;

	open c1 (l_status_activity.summary_date, t_ap);
	fetch c1 into l_status_activity.active_to_pending;
	close c1;


	open c1 (l_status_activity.summary_date, t_ac);
	fetch c1 into l_status_activity.active_to_closed;
	close c1;

	open c1 (l_status_activity.summary_date, t_sa);
	fetch c1 into l_status_activity.suspended_to_active;
	close c1;

	open c1 (l_status_activity.summary_date, t_sc);
	fetch c1 into l_status_activity.suspended_to_closed;
	close c1;

	open c1 (l_status_activity.summary_date, t_sp);
	fetch c1 into l_status_activity.suspended_to_pending;
	close c1;

	open c1 (l_status_activity.summary_date, t_cp);
	fetch c1 into l_status_activity.closed_to_pending;
	close c1;

	open c1 (l_status_activity.summary_date, t_ca);
	fetch c1 into l_status_activity.closed_to_active;
	close c1;

	open c1 (l_status_activity.summary_date, t_cs);
	fetch c1 into l_status_activity.closed_to_suspended;
	close c1;

	open c1 (l_status_activity.summary_date, t_ps);
	fetch c1 into l_status_activity.pending_to_suspended;
	close c1;

	open c1 (l_status_activity.summary_date, t_pa);
	fetch c1 into l_status_activity.pending_to_active;
	close c1;

	open c1 (l_status_activity.summary_date, t_pc);
	fetch c1 into l_status_activity.pending_to_closed;
	close c1;

	delete 
	from 	status_activity
	where	summary_date = l_status_activity.summary_date;

	insert 
	into	status_activity (summary_date,
							 active_to_closed,
							 active_to_suspended,
							 active_to_pending,
							 pending_to_closed,
							 pending_to_suspended,
							 pending_to_active,
							 closed_to_pending,
							 closed_to_suspended,
							 closed_to_active,
							 suspended_to_pending,
							 suspended_to_closed,
							 suspended_to_active)
	values                  (l_status_activity.summary_date,
							 l_status_activity.active_to_closed,
							 l_status_activity.active_to_suspended,
							 l_status_activity.active_to_pending,
							 l_status_activity.pending_to_closed,
							 l_status_activity.pending_to_suspended,
							 l_status_activity.pending_to_active,
							 l_status_activity.closed_to_pending,
							 l_status_activity.closed_to_suspended,
							 l_status_activity.closed_to_active,
							 l_status_activity.suspended_to_pending,
							 l_status_activity.suspended_to_closed,
							 l_status_activity.suspended_to_active);

	commit;

end;
/

