#!/bin/sh

#	$Id: populate_status_activity.sh,v 1.3 1996/01/29 09:45:14 raja Exp $
#	$Log: populate_status_activity.sh,v $
# Revision 1.3  1996/01/29  09:45:14  raja
# made japanese versions of my stuff
#
# Revision 1.2  1995/11/07  07:54:00  raja
# better error handling
#
# Revision 1.1  1995/11/02  10:35:01  raja
# Changes after the first successful run of the binlog loader from estragon
#
# Revision 1.1  1995/10/03  02:55:05  raja
# croned csh script which executes the pl/sql proceedure
#

bindir=`dirname $0`
sdate=
userid=/
usage="$0 -u <userid> -d <summarydate-yymmdd>"


while getopts d:u: c
 do
        case $c in
        u)      userid=$OPTARG;;
        d)      sdate=$OPTARG;;
        \?)     echo $USAGE
                        exit 2;;
        esac
done

bindir=`dirname $0`;

sqlplus -s $userid <<EOF
set verify off
whenever sqlerror exit 100
col y1 noprint new_value yesterday
select nvl(to_date('$sdate','yymmdd'),sysdate-1) y1 from dual;
start $bindir/populate_status_activity.sql &&yesterday 
exit 0
EOF

if [ $? -ne 0 ] 
then
	echo $0 failed 
	exit 2;
else
	exit 0
fi
