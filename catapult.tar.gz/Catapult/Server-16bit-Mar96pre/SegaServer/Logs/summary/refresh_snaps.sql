execute dbms_snapshot.refresh ('box', 'c');
execute dbms_snapshot.refresh ('player', 'c');
