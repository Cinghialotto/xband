#!/bin/sh

# $Id: calc_xbn_summary.sh,v 1.3 1995/12/04 14:34:15 raja Exp $
# $Log: calc_xbn_summary.sh,v $
# Revision 1.3  1995/12/04  14:34:15  raja
# use /usr/ucb/mail instead of elm to mail report out to xbn-interest
#
# Revision 1.2  1995/11/03  10:19:13  raja
# mionor bug fixes
#
# Revision 1.1  1995/11/02  10:34:57  raja
# Changes after the first successful run of the binlog loader from estragon
#

bindir=`dirname $0`
userid=/
sdate=`date +%y%m%d`
usage="$0 -u <userid> -d <summarydate-yymmdd>"


 while getopts d:u: c
 do
        case $c in
        u)      userid=$OPTARG;;
        d)      sdate=$OPTARG;;
        \?)     echo $USAGE
                        exit 2;;
        esac
 done



sqlplus -s $userid <<EOF
set verify off
whenever sqlerror exit 100
start $bindir/calc_xbn_summary.sql $sdate
exit 0;
EOF

if [ $? -ne 0 ] 
then
		echo $0 failed 
		exit 2;
else
	XBNSUM_REPORT_FILE=/var/catapult/reports/daily_xbn_summary.$sdate

	runrep report=$bindir/xbnsum.rep userid=$userid batch=yes paramform=no destype=file desname=$XBNSUM_REPORT_FILE
	
	/usr/ucb/mail -s "Daily XBN Summary" xbn-interest@mgate < $XBNSUM_REPORT_FILE

	date
	exit 0
fi
