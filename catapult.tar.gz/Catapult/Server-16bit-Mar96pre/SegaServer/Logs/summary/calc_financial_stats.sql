rem Copyright: @ 1995 Catapult Entertainment Inc., all rights reserved
rem
rem $Id: calc_financial_stats.sql,v 1.1 1995/11/02 10:34:56 raja Exp $
rem
rem

declare 

lfin			financial_stats%rowtype;
l_end_time		date;
l_start_time	date;

cursor status_cursor is
	select	platform_description,
			sum(decode(account_status_code, 10100, 
				decode(billing_plan_code, 10, 1, 11, 1, 2, 1, 0))) active_cc,
	      	sum(decode(account_status_code, 10100, 
				decode(billing_plan_code, 12, 1, 13, 1, 0))) active_checking,
	      	sum(decode(account_status_code, 10101, 1, 0)) pending, 
	      	sum(decode(account_status_code, 10102, 1, 0)) suspended, 
	      	sum(decode(account_status_code, 10103, 1, 0)) closed, 
	      	sum(decode(account_status_code, 10100, 
					decode(get_bit(area_restriction, 5), 1, 1),
						decode(get_bit(area_restriction, 6), 1, 1, 0)))) xbn
	from	box b, platform p
	where	p.platform_uid = b.platform_uid
	group by platform_description;


cursor daily_cursor is
	select	platform_description,
		    decode(billing_plan_code, 12, 1, 11, 1, 0))) new_basic,
			decode(billing_plan_code, 10, 1, 13, 1, 0))) new_unlimited,
	from	box b, platform p
	where	b.platform_uid = p.platform_uid
	and		created_date between l_start_time and l_end_time;
	group by platform_description;

cursor suspended_cursor is
	select	platform_description,
		    count(*)
	from	box b, platform p
	where	b.platform_uid = p.platform_uid
	and		last_suspended between l_start_time and l_end_time;
	group by platform_description;

cursor closed_cursor is
	select	platform_description,
		    count(*)
	from	box b, platform p
	where	b.platform_uid = p.platform_uid
	and		closed_date between l_start_time and l_end_time;
	group by platform_description;

cursor reactivated_cursor is
	select	platform_description,
		    count(*)
	from	box b, platform p
	where	b.platform_uid = p.platform_uid
	and		last_activated between l_start_time and l_end_time;
	group by platform_description;

cursor binlog_stats  is
	select platform,
		   sum(decode(connection_type_code, 0, 1, 0)) game_connects,
	       sum(decode(connection_type_code, 1, 1, 0)) mail_connects,
	       sum( decode(connection_type_code, 0, 
				decode(peer_connection_uid, null, 0, 1, 0), 0)) matched_games
	from	connection_log cl
			game g
	where start_time between l_start_time and l_end_time
	and   g.game_uid = cl.game_uid
	group by platform;

cursor game_results (l_platform in varchar2) is
	select 	platform,
		   	count(m.connection_uid) game_results,
			sum(decode(mgr.game_result, 0,
					decode(sgr.game_result, 0, 1, 0), 0))) successful_games
	from	connection_log m,
			game g,
			connection_log s,
			game_result mgr
			game_result sgr
	where m.start_time between l_start_time and l_end_time
	and   s.start_time between l_start_time and l_end_time
	and   g.game_uid = g.game_uid
	and   s.peer_connection_uid = m.connection_uid
	and	  mgr.master_connection_uid = m.connection_uid
	and	  sgr.master_connection_uid = s.connection_uid
	and	  m.dialed_phone_number is not null
	and   m.connection_type_code = 0;
	group by platform;

cursor debt_cursor is
	select sum(current_balance+xbn_balance) total_debt
	from	box_balance bb, box b
	where	bb.box_Serial_number = b.box_serial_number
	and		b.account_status_code in (10101, 10102, 10103)
	and     (current_balance+xbn_balance) > 0;

cursor billing_totals is
	select 

begin

l_start_time := nvl (to_date('&&1'), trunc(sysdate)) - 1; 
l_end_time   := l_start_time + 86399/86400;

for rc1 in c1 loop

	delete from average_connection_rate
	where  summary_date = rc1.summary_date;

	insert into average_connection_rate (summary_date, rate)
	values				   (rc1.summary_date, rc1.per_minute); 

end loop;

commit;

end;
/
exit;
