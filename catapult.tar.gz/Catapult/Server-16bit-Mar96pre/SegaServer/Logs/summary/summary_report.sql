rem	$Id: summary_report.sql,v 1.5 1995/11/02 10:35:04 raja Exp $
rem	$Log: summary_report.sql,v $
# Revision 1.5  1995/11/02  10:35:04  raja
# Changes after the first successful run of the binlog loader from estragon
#

set linesize 45
set heading off
set pagesize 0
set arraysize 1
set termout off
set verify off
set feedback off

spool $SUMMARY_REPORT_FILE

select 'Summary Date : ' || to_char (summary_date, 'mm/dd/yy'),
       '---------------------',
       '                                   ',
       'Connection Information             ',
       '----------------------             ',
       '    Total connections              ' || 
							to_char (total_no_of_connections,'999,990'),
       '    800 connections                ' || 
							to_char (connections_800,'999,990'),
       '    X25 connections                ' || 
							to_char (connections_x25,'999,990'),
       '                                   ',
       '    Mail connects                  ' || 
							to_char (mail_only_connects,'999,990'),
       '    Game connects                  ' || 
							to_char (game_only_connects,'999,990'),
       '    Unknown connections            ' || 
							to_char (unknown_connects,'999,990'),
       '                                   ',
       '                                   ',
       'Connection Durations               ',
       '------------------                 ',  
       '     < 0:10                        ' || 
							to_char (duration_under_10,'999,990'),
       '     0:10 - 0:19                   ' || 
							to_char (duration_10_20,'999,990'),
       '     0:20 - 0:29                   ' || 
							to_char (duration_20_30,'999,990'),
       '     0:30 - 0:39                   ' || 
							to_char (duration_30_40,'999,990'),
       '     0:40 - 0:49                   ' || 
							to_char (duration_40_50,'999,990'),
       '     0:50 - 0:59                   ' || 
							to_char (duration_50_60,'999,990'),
       '     1:00 - 1:09                   ' || 
							to_char (duration_60_70,'999,990'),
       '     1:10 - 1:19                   ' || 
							to_char (duration_70_80,'999,990'),
       '     1:20 - 1:29                   ' || 
							to_char (duration_80_90,'999,990'),
       '     1:30 - 1:59                   ' || 
							to_char (duration_90_120,'999,990'),
       '     2:00 - 2:59                   ' || 
							to_char (duration_120_180,'999,990'),
       '     3:00 - 3:59                   ' || 
							to_char (duration_180_240,'999,990'),
       '     > 4:00                        ' || 
							to_char (duration_240_or_more,'999,990'),
	   '                                   ',
       'Average duration                   ' || 
							to_char (average_duration,'999,990'),
       '                                   ',
       'Net Errors                         ',
       '----------                         ',
       '    Server connect                 ' || 
							to_char (net_error_server_connect,'999,990'),
       '    Peer connect                   ' || 
							to_char (net_error_peer_connect,'999,990'),
       '    Frame error                    ' || 
							to_char (net_error_frame_error,'999,990'),
       '    Overrun error                  ' || 
							to_char (net_error_overrun_error,'999,990'),
       '    Packet error                   ' || 
							to_char (net_error_packet_error,'999,990'),
       '    Call waiting interrupt         ' || 
							to_char (net_error_cw_interrupt,'999,990'),
       '    Nodial tone                    ' || 
							to_char (net_error_nodial_tone,'999,990'),
       '    server busy                    ' || 
							to_char (net_error_server_busy,'999,990'),
       '    Peer busy                      ' || 
							to_char (net_error_peer_busy,'999,990'),
       '    Server disconnect              ' || 
							to_char (net_error_server_disconnect,'999,990'),
       '    Peer disconnect                ' || 
							to_char (net_error_peer_disconnect,'999,990'),
       '    Server abort                   ' || 
							to_char (net_error_server_abort,'999,990'),
       '    Peer abort                     ' || 
							to_char (net_error_peer_abort,'999,990'),
       '    Server no answer               ' || 
							to_char (net_error_server_no_answer,'999,990'),
       '    Peer no answer                 ' || 
							to_char (net_error_peer_no_answer,'999,990'),
       '    Server handshake               ' || 
							to_char (net_error_server_handshake,'999,990'),
       '    Peer handshake                 ' || 
							to_char (net_error_peer_handshake,'999,990'),
       '    X25 no service                 ' || 
							to_char (net_error_x25_no_service,'999,990'),
       '    Call waiting error             ' || 
							to_char (net_error_cw_error,'999,990'),
       '    Remote call waiting error      ' || 
							to_char (net_error_remote_cw_error,'999,990'),
       '    Script login                   ' || 
							to_char (net_error_script_login,'999,990'),
       '    Packet retrans                 ' || 
							to_char (net_error_packet_retrans,'999,990'),
       '    Used alt POP                   ' || 
							to_char (net_error_used_alt_pop,'999,990'),
       '    CTS timeout                    ' || 
							to_char (net_error_cts_timeout,'999,990'),
       '    Spinloop Timeouts              ' || 
							to_char (net_error_spinloop_timeouts,'999,990'),
       '    All errors                     ' || 
							to_char (net_error_all_errors,'999,990'),
       '                                   ',
       'SIGHUPs                            ',
       '------------------                 ',
       '    Under 1:00                  ' || 
							to_char (unexpected_sighups_under_60,'999,990'),
       '    1:00 - 2:00                 ' || 
							to_char (unexpected_sighups_60_120,'999,990'),
       '    2:00 - 3:00                 ' || 
							to_char (unexpected_sighups_120_180,'999,990'),
       '    3:00 - 4:00                 ' || 
							to_char (unexpected_sighups_180_240,'999,990'),
       '    More than 4:00              ' || 
							to_char (unexpected_sighups_240_or_more,'999,990'),
       '                                   -----',
       'Total SIGHUPs                   ' || 
							to_char (total_unexpected_sighups,'999,990'),
       '                                   ',
       'Game statistics                    ',
       '---------------                    ',
       '    Told to wait for auto-match     ' || 
							to_char (told_to_wait_automatch,'999,990'),
       '    Told to wait for specific match ' || 
							to_char (told_to_wait_specificmatch,'999,990'),
       '                                    ------',
       'Total told to wait                  ' || 
							to_char (total_told_to_wait,'999,990'),
       '                                   ',
       '    Told to call for automatch      ' || 
							to_char (told_to_call_automatch,'999,990'),
       '    Told to call for specific match ' || 
							to_char (told_to_call_specificmatch,'999,990'),
       '                                     ------',
       'Total told to call                  ' || 
							to_char (total_told_to_call,'999,990'),
       '                                   ',
       'Game results received               ' || 
							to_char (game_result_posted_to_log,'999,990'),
       '                                   ',
       'Credit statistics                  ',
       '-----------------                  ',
       '    Successful games               ' || 
							to_char (success_game_deductions,'999,990'),
       '    Reregister                     ' || 
							to_char (reregister_deductions,'999,990'),
       '    Evil reset                     ' || 
							to_char (evil_reset_deductions,'999,990'),
       '    Call waiting                   ' || 
							to_char (call_waiting_deductions,'999,990'),
       '    Reset waiting                  ' || 
							to_char (reset_waiting_deductions,'999,990'),
       '    Mail only                      ' || 
							to_char (mail_only_deductions,'999,990'),
       '    Hosed specific                 ' || 
							to_char (hosed_specific_deductions,'999,990'),
       '    Hosed auto                     ' || 
							to_char (hosed_auto_deductions,'999,990'),
       '    Penalize wait reset            ' || 
							to_char (penalize_wait_reset_deductions,'999,990'),
       '    Penalize evil reset            ' || 
							to_char (penalize_evil_reset_deductions,'999,990'),
       '    Penalize password code         ' || 
							to_char (password_code_deductions,'999,990'),
       '                                          '
from   daily_connection_summary
where summary_date = nvl(to_date('&&1','yymmdd'),trunc(sysdate-1))
;

set heading on
set arraysize 15
set pagesize 60
set linesize 80
col game format a30 heading "|Game"
col platform format a4 heading "Plat|form"
col told_to_wait format 999,999 heading "Told   |to Wait"
col told_to_call format 999,999 heading "Told   |to Call"
col no_of_crashes format 999,999 heading "|Crashes"
col successful_game_credit_taken format 999,999 heading  "Successful Game|Credits Taken"
 select platform,
		game_name game ,  
        told_to_wait,
        told_to_call, 
        successful_game_credit_taken,
        no_of_crashes
from    daily_games_summary
where summary_date = nvl (to_date('&&1','yymmdd'),trunc(sysdate-1))
/
set termout on
set feedback on
set verify on
spool off
