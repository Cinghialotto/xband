set verify off

declare

l_8am		date;
l_5pm		date;
l_start_date	date;
l_end_date	date;

	cursor c1 is
		select sum(decode(platform_description, 'Sega',1,0))
						total_sega_customers,
		       sum(decode(platform_description, 'SNES',1,0)) 
						total_snes_customers,
			sum(decode( platform_description,'Sega',
			  get_bit(area_restriction,5) +
			  get_bit(area_restriction,6),0)) sega_xbn_customers,
			sum(decode( platform_description,'SNES',
			  get_bit(area_restriction,5) +
			  get_bit(area_restriction,6),0)) snes_xbn_customers
		from platform p,
		     box b
		where billing_type_code in (10003, 10004, 10000)
		and   account_status_code != 10103
		and   p.platform_uid = b.platform_uid
		and   created_date < l_end_date;

	cursor c2 (l_platform in number) is
		select count(*) games,
		       sum (decode (xbn_provider_code, 'XBN-MCI', 1, 0)) xbn_games,
		       sum (decode (xbn_provider_code, 'XBN-MCI',
			    		decode (sign(local_time - l_8am), 
								-1, 1,
				   				decode (sign(local_time - l_5pm),
					  				   	1,1,
					  					0
								)
						),
						0)
					) xbn_5to8
		from    connection_code cc,
				xbn_code xc,
				connection_log c
		where	platform_id = l_platform
		and		cc.connection_code = c.connection_code
		and		xc.xbn_code = c.xbn_code
		and		mail_or_game = 'GAME'
		and		start_time between l_start_date and l_end_date;

l_sum		daily_xbn_summary%rowtype;
l_c1		c1%rowtype;
l_c2		c2%rowtype;

l_plat	varchar2(10);

begin

	l_start_date := to_date('&&1', 'yymmdd');
	l_end_date := l_start_date + 86399/86400;
	l_8am      := l_start_date + 8/24;
	l_5pm      := l_start_date + 17/24;

	open c1;
	fetch c1 into l_c1;
	close c1;

	l_sum.summary_date := l_start_date;
	l_sum.total_sega_customers := l_c1.total_sega_customers;
	l_sum.total_snes_customers := l_c1.total_snes_customers;
	l_sum.sega_xbn_customers := l_c1.sega_xbn_customers;
	l_sum.snes_xbn_customers := l_c1.snes_xbn_customers;

	open c2 (0); 							-- sega
	fetch c2 into l_c2;
	close c2;

	l_sum.sega_xbn_games_8to5 := l_c2.xbn_games - l_c2.xbn_5to8;  
	l_sum.sega_xbn_games_5to8 := l_c2.xbn_5to8;
	l_sum.sega_non_xbn_games  := l_c2.games - l_c2.xbn_games;

	open c2 (1);							-- snes
	fetch c2 into l_c2;
	close c2;

	l_sum.snes_xbn_games_8to5 := l_c2.xbn_games - l_c2.xbn_5to8;  
	l_sum.snes_xbn_games_5to8 := l_c2.xbn_5to8;
	l_sum.snes_non_xbn_games  := l_c2.games - l_c2.xbn_games;

	delete from daily_xbn_summary
	where	summary_date = l_sum.summary_date;

	insert into daily_xbn_summary (	summary_date,
					total_sega_customers,
					total_snes_customers,
					sega_xbn_customers,
					sega_xbn_games_8to5,
					sega_xbn_games_5to8,
					sega_non_xbn_games,
					snes_xbn_customers,
					snes_xbn_games_8to5,
					snes_xbn_games_5to8,
					snes_non_xbn_games)
	values                        (	l_sum.summary_date,
					l_sum.total_sega_customers,
					l_sum.total_snes_customers,
					l_sum.sega_xbn_customers,
					l_sum.sega_xbn_games_8to5,
					l_sum.sega_xbn_games_5to8,
					l_sum.sega_non_xbn_games,
					l_sum.snes_xbn_customers,
					l_sum.snes_xbn_games_8to5,
					l_sum.snes_xbn_games_5to8,
					l_sum.snes_non_xbn_games);

	commit;

end;
/
