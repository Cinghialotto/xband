#!/bin/sh 

#
# Copyright: @ 1995 Catapult Entertainment Inc., all right reserved
#
# $Id: kat_summaries.sh,v 1.4 1996/01/29 09:45:13 raja Exp $
#
# $Log: kat_summaries.sh,v $
# Revision 1.4  1996/01/29  09:45:13  raja
# made japanese versions of my stuff
#
# Revision 1.3  1995/11/07  07:54:00  raja
# better error handling
#
# Revision 1.2  1995/11/03  10:19:14  raja
# mionor bug fixes
#
# Revision 1.1  1995/11/02  10:34:59  raja
# Changes after the first successful run of the binlog loader from estragon
#


bindir=`dirname $0`
userid=/
sdate=`date +%y%m%d`
usage="$0 -u <userid> -d <summarydate-yymmdd>"

ORACLE_HOME=/opt/oracle; export ORACLE_HOME
PATH=/opt/oracle/bin:${PATH}; export PATH


 while getopts d:u: c
 do
        case $c in
        u)      userid=$OPTARG;;
        d)      sdate=$OPTARG;;
        \?)     echo $USAGE
                        exit 2;;
        esac
 done


date

sqlplus -s $userid <<EOF
set verify off
whenever sqlerror exit 100
@ $bindir/refresh_snaps.sql
@ $bindir/pop_area_restriction.sql
exit 0;
EOF

status=$?
if [ $status -ne 0 ] 
then
	echo unable to refresh snapshots	
 	$bindir/dbl_support.sh "$status: Unable to refresh snapshots"
fi

$bindir/populate_status_activity.sh -u $userid
status=$?
if [ $status -ne 0 ] 
then
	echo unable to populate status activity
 	$bindir/dbl_support.sh "$status: Unable to populate status activity"
fi


exit $?
