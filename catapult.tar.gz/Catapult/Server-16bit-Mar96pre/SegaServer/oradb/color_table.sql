rem $Id: color_table.sql,v 1.2 1995/10/02 23:22:28 raja Exp $
rem $Log: color_table.sql,v $
rem Revision 1.2  1995/10/02  23:22:28  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- Color scheme or something like that chosen on the box. Not used


delete from color_table;

create or replace view color_table
as
select 	lookup_code color_table_id,
	lookup_description color_table_description
from 	lookup
where	lookup_type = 'COLOR TABLE'
;

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('COLOR TABLE', 0, 'Unknown');

commit;
