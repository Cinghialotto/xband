rem $Id: game_names.sql,v 1.2 1995/10/02 23:22:51 raja Exp $
rem $Log: game_names.sql,v $
# Revision 1.2  1995/10/02  23:22:51  raja
# added comments and cvs headers to all sql command files. removed
# obsolete stuff
#

-- view on the games table which excludes bogus games and ignores
-- game versions 

create or replace view game_names as
select 	game_id, 
		game_name,
		platform 
from 	game 
where	game_name not like 'Unknown%'
group by game_id,
		 game_name,
		 platform;
