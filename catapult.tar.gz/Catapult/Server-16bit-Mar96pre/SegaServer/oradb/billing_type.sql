rem $Id: billing_type.sql,v 1.6 1995/11/29 09:32:14 ckn Exp $
rem $Log: billing_type.sql,v $
rem Revision 1.6  1995/11/29  09:32:14  ckn
rem ECP Billing - new billing type and transaction codes.
rem Returned billing file - new structure to reflect username and billing_type_code
rem
rem Revision 1.5  1995/11/15  11:16:13  ckn
rem ECP billing - added new transaction codes, ECP billing type, new fields to
rem box table and relative changes to the Db triggers.
rem
rem Revision 1.4  1995/10/02  23:22:20  raja
rem
rem 95/11/14	ck
rem added new billing type - 10002 for ecp
rem
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- contains billing type codes
--

delete from billing_type;

create or replace view billing_type
as
select 	lookup_code billing_type_code,
		lookup_description billing_type_description,
		flex_num_1 real,					-- is this a real customer?
		flex_num_2 credit_card 				-- is this a credit card type?
from 	lookup
where	lookup_type = 'BILLING TYPE'
;

insert into lookup (lookup_type, lookup_code, lookup_description, flex_num_1, flex_num_2)
values ('BILLING TYPE', 0, 'Unknown', 0, 0);

insert into lookup (lookup_type, lookup_code, lookup_description, flex_num_1, flex_num_2)
values ('BILLING TYPE', 10000, 'Prepaid', 1, 0);


insert into lookup (lookup_type, lookup_code, lookup_description, flex_num_1, flex_num_2)
values ('BILLING TYPE', 10003, 'Visa', 1, 1);

insert into lookup (lookup_type, lookup_code, lookup_description, flex_num_1, flex_num_2)
values ('BILLING TYPE', 10004, 'Master card', 1, 1);

insert into lookup (lookup_type, lookup_code, lookup_description, flex_num_1, flex_num_2)
values ('BILLING TYPE', 10008, 'Beta tester', 0, 0);

insert into lookup (lookup_type, lookup_code, lookup_description, flex_num_1, flex_num_2)
values ('BILLING TYPE', 10009, 'Internal', 0, 0);

insert into lookup (lookup_type, lookup_code, lookup_description, flex_num_1, flex_num_2)
values ('BILLING TYPE', 10010, 'Guest', 0, 0);

insert into lookup (lookup_type, lookup_code, lookup_description, flex_num_1, flex_num_2)
values ('BILLING TYPE', 10011, 'Promo', 0, 0);

insert into lookup (lookup_type, lookup_code, lookup_description, flex_num_1, flex_num_2)
values ('BILLING TYPE', 10012, 'ECP', 1, 1);

commit;
