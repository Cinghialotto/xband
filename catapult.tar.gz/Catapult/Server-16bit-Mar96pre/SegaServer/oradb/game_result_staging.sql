rem $Id: game_result_staging.sql,v 1.1 1995/10/30 20:59:06 raja Exp $
rem $Log: game_result_staging.sql,v $
rem Revision 1.1  1995/10/30  20:59:06  raja
rem major reorganization of the binlogs database. Out with the old in with
rem the new. This is not a make work project. Truly. I swear. OK whatever
rem

create table game_result_staging
(
connection_uid				number(10),
record_type					char(4),
cookie						number(10),
master_slave				char(1),
opp_box_serial_number		number(8),
opp_box_region				number(8),
game_id						varchar2(10),
game_version				varchar2(10),
match_date					date,
game_error					number(12),
play_time					number(12),
local_result				number(12),
remote_result				number(12)
)
tablespace tb1
storage (initial 10M next 10M pctincrease 0)
pctfree 0 pctused 60
;
