rem $Id: connection_log_staging.sql,v 1.2 1996/02/05 16:32:11 raja Exp $
rem $Log: connection_log_staging.sql,v $
rem Revision 1.2  1996/02/05  16:32:11  raja
rem changed game version to varchar
rem
rem Revision 1.1  1995/10/30  20:59:00  raja
rem major reorganization of the binlogs database. Out with the old in with
rem the new. This is not a make work project. Truly. I swear. OK whatever
rem
rem

create table connection_log_staging
(
connection_uid				number(10)		not null,
record_type					char(4),
server_ip					varchar2(15),
start_time					date,
local_time					date,
exit_status_code			number(2),
duration					number(4),
player_name					varchar2(50),
ani							varchar2(16),
box_serial_number			number(6),
box_region					number(6),
box_player_no				number(1),
billing_type				number(6),
new							varchar2(20),
x25_address					varchar2(30),
x25_main_phone				varchar2(16),
x25_alt_phone				varchar2(16),
platform_name				varchar2(4),
connection_type				number(1),
game_id						varchar2(10),
game_name					varchar2(50),
game_version				varchar2(30),
autochal					varchar2(9),
opponent_exists				number(1),
dialed_box_serial_number	number(6),
dialed_box_region			number(6),
dialed_box_player_no		number(1),
dialed_phone				varchar2(16),
toll_local					varchar2(5),
mci_sprint					varchar2(6),
bill_slave					varchar2(3),
bill_master					varchar2(3),
cookie						number(10),
junk1						number
)
tablespace tb1
storage (initial 10M next 10M pctincrease 0)
pctfree 5 pctused 80
;
