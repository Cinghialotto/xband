rem $Id: status_activity.sql,v 1.2 1995/10/23 09:54:55 raja Exp $
rem $Log: status_activity.sql,v $
rem Revision 1.2  1995/10/23  09:54:55  raja
rem new xlog schema
rem
rem Revision 1.1  1995/10/03  02:52:14  raja
rem new table for richard. this table will keep track of changes to
rem account status. stuff like - how manyaccounts changed from pending
rem to active today and so on.
rem

-- This table will store account status change activities. There
-- are 4 possible account statuses. Pending, Active, Suspended,
-- Closed. For each day we keep track of the number of accounts
-- that changed from each status to the other three.

create table status_activity (
summary_date			date not null,
active_to_pending		number(5),
active_to_suspended		number(5),
active_to_closed		number(5),
closed_to_pending		number(5),
closed_to_suspended		number(5),
closed_to_active		number(5),
pending_to_closed		number(5),
pending_to_suspended	number(5),
pending_to_active		number(5),
suspended_to_closed		number(5),
suspended_to_pending	number(5),
suspended_to_active		number(5),
constraint pk$status_activity primary key (summary_date)
using index tablespace tb2 storage (initial 500k next 500k pctincrease 0)
)
tablespace tb1
storage (initial 2M next 1M pctincrease 0)
;
