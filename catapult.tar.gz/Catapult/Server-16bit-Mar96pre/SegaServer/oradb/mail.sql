rem 
rem $Id: mail.sql,v 1.3 1995/05/24 16:07:47 chs Exp $
rem 
rem $Log: mail.sql,v $
rem Revision 1.3  1995/05/24  16:07:47  chs
rem Fix rcs comments
rem
rem Revision 1.2  1995/05/24  14:19:40  chs
rem Added icon, color, and town for from player.
rem 
rem 

create table mail ( 
mailid number not null,
from_box number not null,
from_region number not null,
from_player number not null,
from_color number not null,
to_box number not null,
to_region number not null,
to_player number not null,
date_sent date not null,
title varchar2(34) not null,
from_address varchar2(100),
from_town varchar2(100) not null,
to_address varchar2(100),
message varchar2(500) not null,
constraint pk$mail primary key (mailid)
using index tablespace index1
	storage (initial 10M next 10M pctincrease 0) 
)
tablespace data1
storage (initial 100M next 20M pctincrease 0) 
pctfree 5 pctused 40
;
