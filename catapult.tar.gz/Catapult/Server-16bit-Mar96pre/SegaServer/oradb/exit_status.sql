rem $Id: exit_status.sql,v 1.2 1995/10/02 23:22:47 raja Exp $
rem $Log: exit_status.sql,v $
rem Revision 1.2  1995/10/02  23:22:47  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem
 
-- various reasons as to why a connection to the server ended


delete from exit_status;

create or replace view exit_status
as
select 	lookup_code exit_status_code,
	lookup_description exit_status_description
from 	lookup
where	lookup_type = 'EXIT STATUS'
;

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('EXIT STATUS', 0, 'Unknown');

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('EXIT STATUS', 1, 'Normal termination');

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('EXIT STATUS', 2, 'Never connected');

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('EXIT STATUS', 3, 'Server aborted midway');

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('EXIT STATUS', 4, 'Premature SIGHUP');

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('EXIT STATUS', 5, 'Timed out');

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('EXIT STATUS', 6, 'Generic signal');

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('EXIT STATUS', 7, 'RPC abort');

commit;
