rem $Id: billing_plan.sql,v 1.4 1995/10/02 23:22:17 raja Exp $
rem $Log: billing_plan.sql,v $
rem Revision 1.4  1995/10/02  23:22:17  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem


-- This table stores the rates associated with each billing plan
-- for a given period in time. It is not useful to us right now
-- because we have not ever changed rates for an existing plan

create table billing_plan
(billing_plan_uid		number not null,
 billing_plan_code		number not null,
 start_date				date   not null,
 end_date				date,
 minimum_fee			number,
 free_credits			number,
 extra_credit_fee		number,
 constraint pk$billing_plan primary key (billing_plan_uid)
 using index tablespace index1
 	     storage (initial 100K next 100K pctincrease 0)
)
tablespace data1
storage (initial 100K next 100K pctincrease 0)
pctfree 0 pctused 95 
;
  
