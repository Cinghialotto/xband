rem $Id: xlog_snaps.sql,v 1.3 1995/10/30 20:59:15 raja Exp $
rem $Log: xlog_snaps.sql,v $
rem Revision 1.3  1995/10/30  20:59:15  raja
rem major reorganization of the binlogs database. Out with the old in with
rem the new. This is not a make work project. Truly. I swear. OK whatever
rem
rem Revision 1.2  1995/10/02  23:23:35  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- create snapshots of box and player on xlog (from kat)


create snapshot box
tablespace tb1
storage (initial 10M next 10M pctincrease 0)
pctfree 40 pctused 40 
refresh complete  next sysdate + 1
as select * from catapult.box@kat
;

create index pk$box 
on snap$_box (box_Serial_number, box_region) 
tablespace tb2 
storage (initial 5M next 5M pctincrease 0)
;

create index i$box$cs_id on snap$_box (cs_id) 
tablespace tb2 
storage (initial 2M next 2M pctincrease 0)
;

create index i$box$name on snap$_box (name) 
tablespace tb2 
storage (initial 4M next 4M pctincrease 0)
;

create index i$box$game_phone on snap$_box (game_phone) 
tablespace tb2 
storage (initial 4M next 4M pctincrease 0)
;

create snapshot player
tablespace tb1
storage (initial 10M next 10M pctincrease 0)
pctfree 40 pctused 40
refresh complete next sysdate + 1
as select * from catapult.player@kat
;

create index pk$player on snap$_player (box_serial_number, box_region, box_player_no)
tablespace tb2 
 	    storage (initial 5M next 5M pctincrease 0)
;

create index i$player$name on snap$_player (search_name)
storage (initial 1M next 1M pctincrease 0)
;
