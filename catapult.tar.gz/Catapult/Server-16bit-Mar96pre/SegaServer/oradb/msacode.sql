create table msacode
(code		number(5) not null,
 description	varchar2(50) not null,
 short_name		varchar2(20),
 constraint pk$msacode primary key (code)
 using index 
 tablespace tb2
 storage (initial 100k next 100k pctincrease 0)
)
 tablespace tb1
 storage (initial 1M next 1M pctincrease 0)
;
