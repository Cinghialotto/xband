rem $Id: display_templine.sql,v 1.1 1995/12/06 15:46:31 raja Exp $
rem $Log: display_templine.sql,v $
rem Revision 1.1  1995/12/06  15:46:31  raja
rem temporary tables used by my warehouse tool
rem
rem Revision 1.1  1995/11/29  19:42:58  raja
rem warehouse tables
rem

create table display_templine
(sessid		number not null,
 sdate		date,
 category	varchar2(30),
 num_value	number
)
tablespace tb1
storage (initial 100K next 100K pctincrease 0)
pctfree 0 pctused 95 
;

create index i$display_templine$sessid on display_templine (sessid)
tablespace tb2
storage (initial 100K next 100K pctincrease 0)
pctfree 0 
;
