delete from display_code;

create table display_code 
(code		number(3) not null,
 text		varchar2(30) not null,
 db_code	number,
 code_type  varchar2(30)
)
tablespace tb1
;

insert into display_code values (0, 'Sega', 1936025441, 'platform_uid');
insert into display_code values (1, 'SNES', 1936614771, 'platform_uid');
insert into display_code values (2, 'Active', 10100, 'account_status_code');
insert into display_code values (3, 'Closed', 10103, 'account_status_code');
insert into display_code values (4, 'Pending', 10101, 'account_status_code');
insert into display_code values (5, 'Suspended', 10102, 'account_status_code');
insert into display_code values (6, 'XBN', 1, 'area_restriction');
insert into display_code values (7, 'Local', 0, 'area_restriction');
insert into display_code values (8, 'Visa', 10003, 'billing_type_code');
insert into display_code values (9, 'Mastercard', 10004, 'billing_type_code');
insert into display_code values (10, 'Prepaid', 10000, 'billing_type_code');
insert into display_code values (11, 'ECP', 10012, 'billing_type_code');
insert into display_code values (12, 'Guest', 10010, 'billing_type_code');
insert into display_code values (13, 'Internal', 10009, 'billing_type_code');
insert into display_code values (14, 'Promo', 10011, 'billing_type_code');
insert into display_code values (15, 'CC-Unlimited', 10, 'billing_plan_code');
insert into display_code values (16, 'CC-Basic', 11, 'billing_plan_code');
insert into display_code values (17, 'Ch-Basic', 12, 'billing_plan_code');
insert into display_code values (18, 'Ch-Unlimited', 13, 'billing_plan_code');
insert into display_code values (19, '<1 Month', 0, 'age');
insert into display_code values (20, '1-2 Months', 1, 'age');
insert into display_code values (21, '2-3 Months', 2, 'age');
insert into display_code values (22, '3-4 Months', 3, 'age');
insert into display_code values (23, '4-5 Months', 4, 'age');
insert into display_code values (24, '5-6 Months', 5, 'age');
insert into display_code values (25, '6+ Months', 99, 'age');
insert into display_code values (26, 'NY', 5602, 'market');
insert into display_code values (27, 'LA', 4472, 'market');
insert into display_code values (28, 'SF', 7362, 'market');
insert into display_code values (29, 'Dallas', 1922, 'market');
insert into display_code values (30, 'Atlanta', 520, 'market');
insert into display_code values (31, 'Chicago', 1602, 'market');
insert into display_code values (32, 'KC', 3760, 'market');
insert into display_code values (33, 'DC', 8840, 'market');
insert into display_code values (34, 'Miami', 4992, 'market');
insert into display_code values (35, 'Detroit', 2162, 'market');
insert into display_code values (36, 'Rest', 9999, 'market');
insert into display_code values (37, 'Unknown', 0, 'billing_type_code');
insert into display_code values (38, 'Unknown', 9999, 'billing_plan_code');
insert into display_code values (39, 'Old 6for5', 2, 'billing_plan_code');

commit;
