rem $Id: daily_xbn_summary.sql,v 1.3 1995/10/23 09:54:48 raja Exp $
rem $Log: daily_xbn_summary.sql,v $
# Revision 1.3  1995/10/23  09:54:48  raja
# new xlog schema
#
# Revision 1.2  1995/10/02  23:22:45  raja
# added comments and cvs headers to all sql command files. removed
# obsolete stuff
#
 
-- daily summary of xbn activity

create table daily_xbn_summary
(
summary_date			date not null,
total_sega_customers	number,
total_snes_customers	number,
sega_xbn_customers		number,
sega_xbn_games_8to5		number,
sega_xbn_games_5to8		number,
sega_non_xbn_games		number,
snes_xbn_customers		number,
snes_xbn_games_5to8		number,
snes_non_xbn_games		number,
snes_xbn_games_8to5		number,
constraint pk$daily_xbn_summary primary key (summary_date)
using index tablespace tb2 
	    storage (initial 500k next 500k pctincrease 0)
)
tablespace tb1
storage (initial 500K next 500k pctincrease 0)
;

