rem $Id: connection_log.sql,v 1.8 1996/01/17 10:38:33 raja Exp $
rem $Log: connection_log.sql,v $
rem Revision 1.8  1996/01/17  10:38:33  raja
rem added new index on box serial number
rem
rem Revision 1.7  1995/11/03  10:19:40  raja
rem final changes for xlog on calcutta
rem
rem Revision 1.6  1995/10/30  20:58:59  raja
rem major reorganization of the binlogs database. Out with the old in with
rem the new. This is not a make work project. Truly. I swear. OK whatever
rem
rem Revision 1.5  1995/10/23  09:54:42  raja
rem new xlog schema
rem
rem Revision 1.4  1995/10/11  15:37:23  raja
rem changes for the new binlogs
rem

rem drop table connection_log;

create table connection_log
(
connection_uid				number(10)		not null,
server_uid					number(2),
start_time					date,
local_time					date,
duration					number(4),
player_uid					number(8),
box_serial_number			number(6),
platform_id					number(1),
connection_code				number(2),
exit_status_code			number(2),
xbn_code					number(2),
area_code					number(3),
phone_number				number(7),
x25_pop_uid					number(6),
game_uid					number(6),
dialed_player_uid			number(8),
dialed_box_serial_number	number(6),
dialed_phone_number			varchar2(7),
dialed_area_code			varchar2(3),
peer_connection_uid			number(10),			-- cookie
game_error              	number(12),
play_time               	number(12),
local_result    	       	number(12),
remote_result      	    	number(12),
e_game_error              	number(12),
e_play_time               	number(12),
e_local_result           	number(12),
e_remote_result          	number(12),
constraint pk$connection_log primary key (connection_uid)
using index tablespace tb2 storage (initial 100M next 50M pctincrease 0)
							  pctfree 0 
)
tablespace tb1
storage (initial 100M next 100M pctincrease 0)
pctfree 5 pctused 80
;

create index i$connection_log$start_time on connection_log (start_time, 
															box_serial_number)
tablespace tb2
storage (initial 100M next 50M pctincrease 0)
pctfree 0
;

create index i$connection_log$peer on connection_log (peer_connection_uid)
tablespace tb2
storage (initial 100M next 50M pctincrease 0)
pctfree 0
;

create index i$connection_log$box on connection_log (box_serial_number) 
tablespace tb2
storage (initial 50M next 20M pctincrease 0)
pctfree 0
;
