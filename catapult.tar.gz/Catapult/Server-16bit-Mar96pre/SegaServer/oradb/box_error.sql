rem $Id: box_error.sql,v 1.1 1995/10/30 20:58:58 raja Exp $
rem $Log: box_error.sql,v $
rem Revision 1.1  1995/10/30  20:58:58  raja
rem major reorganization of the binlogs database. Out with the old in with
rem the new. This is not a make work project. Truly. I swear. OK whatever
rem
rem Revision 1.4  1995/10/23  09:54:45  raja
rem new xlog schema
rem
rem Revision 1.3  1995/10/11  15:37:25  raja
rem changes for the new binlogs
rem

rem drop table connection_net_error;

create table box_error
(
connection_uid				number(10) not null,
carrier_type_code			number(1)  not null,				-- 0=x25, 1=800
server_connects				number(4),
peer_connects				number(5),
frame_errors				number(5),
overrun_errors				number(5),
packet_errors				number(5),
call_waiting_interrupt		number(5),
no_dial_tone				number(5),
server_busy					number(5),
peer_busy					number(5),
server_disconnect			number(5),
peer_disconnect				number(5),
server_abort				number(5),
peer_abort					number(5),
server_no_answer			number(5),
peer_no_answer				number(5),
server_handshake			number(5),
peer_handshake				number(5),
x25_no_service				number(5),
call_waiting_error			number(5),
remote_call_waiting_error	number(5),
script_login				number(5),
packet_retrans				number(5),
used_alt_pop				number(5),
cts_timeout					number(5),
all_errors					number(5),
spinloop_timeouts			number(5),
constraint pk$box_error primary key (connection_uid, 
									carrier_type_code)
using index tablespace tb2 storage (initial 50M next 50M pctincrease 0)
							 pctfree 0
)
tablespace tb1
storage (initial 100M next 100M pctincrease 0)
pctfree 0 pctused 80
;
