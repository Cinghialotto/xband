rem $Id: average_connection_rate.sql,v 1.1 1995/10/23 10:02:45 raja Exp $
rem $Log: average_connection_rate.sql,v $
rem Revision 1.1  1995/10/23  10:02:45  raja
rem fixed file name to match table name
rem
rem Revision 1.4  1995/10/23  09:54:41  raja
rem new xlog schema
rem
rem Revision 1.3  1995/10/02  23:22:15  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- this summary table has the average connections/minute rate for every
-- day in half hour increments. It is populated every night after the binlogs
-- are loaded. A report runs off this table and is mailed to me.

create table average_connection_rate
(
summary_date		date 		not null,
rate				number,
constraint pk$average_connection_rate
primary key (summary_date)
using index 
	tablespace tb2
	storage (initial 200k next 200k pctincrease 0)
)
tablespace tb1
storage (initial 300k next 300k pctincrease 0)
;
