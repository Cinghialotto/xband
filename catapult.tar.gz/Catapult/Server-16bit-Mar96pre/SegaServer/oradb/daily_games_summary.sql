rem $Id: daily_games_summary.sql,v 1.4 1995/10/30 20:59:05 raja Exp $
rem $Log: daily_games_summary.sql,v $
rem Revision 1.4  1995/10/30  20:59:05  raja
rem major reorganization of the binlogs database. Out with the old in with
rem the new. This is not a make work project. Truly. I swear. OK whatever
rem
rem Revision 1.3  1995/10/23  09:54:47  raja
rem new xlog schema
rem
rem Revision 1.2  1995/10/02  23:22:44  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem
 
-- daily summary by game

create table daily_games_summary
(summary_date                  date, 
 game_name                     varchar2(80),
 platform					   varchar2(10),
 told_to_wait                  number,
 told_to_call                  number,
 successful_game_credit_taken  number,
 no_of_crashes                 number,
 constraint pk$daily_games_summary primary key (summary_date,game_name, platform)
 using index tablespace tb2
		storage (initial 1M next 1M pctincrease 0))
tablespace tb1
storage (initial 2M next 1M pctincrease 0)
;
