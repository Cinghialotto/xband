rem $Id: daily_connection_summary.sql,v 1.4 1995/10/30 20:59:04 raja Exp $
rem $Log: daily_connection_summary.sql,v $
rem Revision 1.4  1995/10/30  20:59:04  raja
rem major reorganization of the binlogs database. Out with the old in with
rem the new. This is not a make work project. Truly. I swear. OK whatever
rem
rem Revision 1.3  1995/10/23  09:54:46  raja
rem new xlog schema
rem
rem Revision 1.2  1995/10/02  23:22:44  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem
 
-- daily summary on the connection_log table

create table daily_connection_summary
(summary_date                  date not null,
 connections_800               number,
 connections_x25               number,
 new_accounts_logged           number,
 mail_only_connects            number,
 game_only_connects            number,
 unknown_connects              number,
 no_of_distinct_phones         number,
 no_of_hosed_batteries         number,
 duration_under_10             number,
 duration_10_20                number,
 duration_20_30                number,
 duration_30_40                number,
 duration_40_50                number,
 duration_50_60                number,
 duration_60_70                number,
 duration_70_80                number,
 duration_80_90                number,
 duration_90_120               number,
 duration_120_180              number,
 duration_180_240              number,
 duration_240_or_more          number,
 average_duration              number,
 total_no_of_connections       number,
 net_error_server_connect      number,
 net_error_peer_connect        number,
 net_error_frame_error         number,
 net_error_overrun_error       number,
 net_error_packet_error        number,
 net_error_cw_interrupt        number,
 net_error_nodial_tone         number,
 net_error_server_busy         number,
 net_error_peer_busy           number,
 net_error_server_disconnect   number,
 net_error_peer_disconnect     number,
 net_error_server_abort        number,
 net_error_peer_abort          number,
 net_error_server_no_answer    number,
 net_error_peer_no_answer      number,
 net_error_server_handshake    number,
 net_error_peer_handshake      number,
 net_error_x25_no_service      number,
 net_error_cw_error            number,
 net_error_remote_cw_error     number,
 net_error_script_login        number,
 net_error_packet_retrans      number,
 net_error_used_alt_pop        number,
 net_error_cts_timeout         number,
 net_error_all_errors          number,
 net_error_spinloop_timeouts   number,
 total_no_of_net_errors        number,
 unexpected_sighups_under_60   number,
 unexpected_sighups_60_120     number,
 unexpected_sighups_120_180    number,
 unexpected_sighups_180_240    number,
 unexpected_sighups_240_or_more number,
 total_unexpected_sighups      number,
 no_of_streamerrors            number,
 told_to_wait_automatch        number,
 told_to_wait_specificmatch    number,
 total_told_to_wait            number,
 told_to_call_automatch        number,
 told_to_call_specificmatch    number,
 total_told_to_call            number,
 game_result_posted_to_log     number,
 total_no_of_crashes           number,
 success_game_deductions     	number,
 reregister_deductions          number,
 evil_reset_deductions          number,
 call_waiting_deductions        number,
 reset_waiting_deductions  number,
 mail_only_deductions   number,
 hosed_specific_deductions      number,
 hosed_auto_deductions          number,
 penalize_wait_reset_deductions number,
 penalize_evil_reset_deductions number,
 password_code_deductions number,
 total_no_of_credit_deducted   number,
 constraint pk$daily_connection_summary primary key (summary_date)
 using index tablespace tb2
 storage (initial 1M next 1M pctincrease 0))
tablespace tb1
storage (initial 2M next 1M pctincrease 0)
;
