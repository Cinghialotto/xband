rem	$Id: player.sql,v 1.8 1995/10/02 23:23:14 raja Exp $
rem	$Log: player.sql,v $
rem Revision 1.8  1995/10/02  23:23:14  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

rem	Contains information about the players in each box. Each box can have 
rem upto 4 players. Most of the information here comes from rpc.segad's
rem account.playerAccount struct.


create table player
(
box_serial_number		number(10) not null,
box_region				number(3) not null,
box_player_no			number(1) not null,		-- 0-4
name					varchar2(34),
filtered_name			varchar2(34),
filtered_name_suffix	number(3),
icon_id					number(3),				-- see std_icon table
color_table_id			number(3),				-- see color table
password				varchar2(8),
password_erase_code		varchar2(8),
birthday				date,					-- not used
player_flags			number,					-- bit mask
automatches				number,
challenges				number,
mail_connects			number,
evil_resets				number,
iffy_resets				number,
cs_updated_flags		number,
search_name				varchar2(50),			-- name with special characters
												-- removed, sanitized,... for
												-- faster querying
taunt					varchar2(500),
personal_info			varchar2(500),
constraint pk$player primary key (box_serial_number, box_region, box_player_no)
using index tablespace index1 
 	    storage (initial 5M next 5M pctincrease 0)
)
tablespace data1
storage (initial 20M next 10M pctincrease 0)
pctfree 25 pctused 60
;

create index uk$player$search_name on player (search_name)
tablespace index1 
storage (initial 4M next 2M pctincrease 0)
;
