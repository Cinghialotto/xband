rem $Id: order_activity.sql,v 1.2 1995/10/02 23:23:05 raja Exp $
rem $Log: order_activity.sql,v $
rem Revision 1.2  1995/10/02  23:23:05  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- activity associated with an order placed with the xband store.
--

create table order_activity 
(
order_id					number(10),				-- see orders
activity_code				number(3),				-- see activity
activity_date				date,
comments					varchar2(200)
)
tablespace data1
storage	(initial 2M next 1M pctincrease 0)
; 

create index i$order_activity$order_id 
on order_activity (order_id)	
tablespace index1
storage	(initial 1M next 1M pctincrease 0)
; 


