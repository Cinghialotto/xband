rem $Id: result_type.sql,v 1.2 1995/10/02 23:23:22 raja Exp $
rem $Log: result_type.sql,v $
rem Revision 1.2  1995/10/02  23:23:22  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- table used in game_results to identify whether a result is a 
-- regular or error result

delete from result_type;

create or replace view result_type
as
select 	lookup_code result_type_code,
	lookup_description result_type_description
from 	lookup
where	lookup_type = 'RESULT TYPES'
;

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('RESULT TYPES', 0, 'Regular');

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('RESULT TYPES', 1, 'Error results');

commit;

