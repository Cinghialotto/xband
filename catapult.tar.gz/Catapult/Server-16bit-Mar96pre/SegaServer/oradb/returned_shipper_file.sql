rem $Id: returned_shipper_file.sql,v 1.2 1995/10/02 23:23:23 raja Exp $
rem $Log: returned_shipper_file.sql,v $
rem Revision 1.2  1995/10/02  23:23:23  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem
rem Revision 1.1  1995/10/01  17:47:01  raja
rem Cleaning up this directory
rem

-- temporary table used to process file returned by shipper - grimes

create table returned_shipper_file 
(
order_id			number,
product_keyword		varchar2(30),
name				varchar2(30),
address				varchar2(100),
city				varchar2(30),
state				varchar2(2),
zip					varchar2(15),
airbill_number		varchar2(30),
shipping_date		date
)
tablespace data1
storage (initial 1m next 1m pctincrease 0)
;
