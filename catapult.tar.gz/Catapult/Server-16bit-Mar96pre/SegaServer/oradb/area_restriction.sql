rem $Id: area_restriction.sql,v 1.3 1995/11/03 10:19:38 raja Exp $
rem $Log: area_restriction.sql,v $
rem Revision 1.3  1995/11/03  10:19:38  raja
rem final changes for xlog on calcutta
rem
rem Revision 1.2  1995/10/02  23:22:14  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- this table stores a text description of the area restriction.
-- business objects cannot deal with using the get_bit() function
-- in certain queries. This table is maintained by a script that runs
-- every night. This table should be removed and replaced with maybe a 
-- view?


create table area_restriction
(box_serial_number		number,
 box_region				number,
 area_restriction		varchar2(30),
 constraint pk$area_restriction primary key (box_serial_number, box_region)
 using index tablespace tb2 
	     storage (initial 2M next 2M)
)
tablespace tb1
storage (initial 5M next 5M pctincrease 0)
;
