rem $Id: connection_code.sql,v 1.3 1995/11/02 10:37:45 raja Exp $
rem $Log: connection_code.sql,v $
rem Revision 1.3  1995/11/02  10:37:45  raja
rem final changes to the new xlog schema
rem
rem Revision 1.2  1995/10/23  09:54:42  raja
rem new xlog schema
rem
rem Revision 1.1  1995/10/11  15:37:22  raja
rem changes for the new binlogs
rem


create table connection_code (
connection_code				number(2)	 not null,
mail_or_game				varchar2(4)  null,
dial_or_wait				varchar2(4)  null,
x25_or_800					varchar2(3)  null,
automatch_or_challenge		varchar2(9)  null)
tablespace tb1
storage (initial 100k next 100k pctincrease 0)
pctused 80 pctfree 0
;

delete from connection_code;

insert into connection_code (connection_code, mail_or_game, x25_or_800, 
							 dial_or_wait, automatch_or_challenge) values
(0, 'GAME', 'X25', 'DIAL', 'AUTO');
							
insert into connection_code (connection_code, mail_or_game, x25_or_800, 
							 dial_or_wait, automatch_or_challenge) values
(1, 'GAME', 'X25', 'DIAL', 'CHALLENGE');
							

insert into connection_code (connection_code, mail_or_game, x25_or_800, 
							 dial_or_wait, automatch_or_challenge) values
(2, 'GAME', 'X25', 'WAIT', 'AUTO');
							
insert into connection_code (connection_code, mail_or_game, x25_or_800, 
							 dial_or_wait, automatch_or_challenge) values
(3, 'GAME', 'X25', 'WAIT', 'CHALLENGE');
							
insert into connection_code (connection_code, mail_or_game, x25_or_800, 
							 dial_or_wait, automatch_or_challenge) values
(4, 'GAME', '800', 'DIAL', 'AUTO');
							
insert into connection_code (connection_code, mail_or_game, x25_or_800, 
							 dial_or_wait, automatch_or_challenge) values
(5, 'GAME', '800', 'DIAL', 'CHALLENGE');
							

insert into connection_code (connection_code, mail_or_game, x25_or_800, 
							 dial_or_wait, automatch_or_challenge) values
(6, 'GAME', '800', 'WAIT', 'AUTO');
							
insert into connection_code (connection_code, mail_or_game, x25_or_800, 
							 dial_or_wait, automatch_or_challenge) values
(7, 'GAME', '800', 'WAIT', 'CHALLENGE');

insert into connection_code (connection_code, mail_or_game, x25_or_800, 
							 dial_or_wait, automatch_or_challenge) values
(8, 'MAIL', 'X25', null, null);
							
insert into connection_code (connection_code, mail_or_game, x25_or_800, 
							 dial_or_wait, automatch_or_challenge) values
(9, 'MAIL', 'X25', null, null);
							

insert into connection_code (connection_code, mail_or_game, x25_or_800, 
							 dial_or_wait, automatch_or_challenge) values
(10, 'MAIL', 'X25', null, null);
							
insert into connection_code (connection_code, mail_or_game, x25_or_800, 
							 dial_or_wait, automatch_or_challenge) values
(11, 'MAIL', 'X25', null, null);
							
insert into connection_code (connection_code, mail_or_game, x25_or_800, 
							 dial_or_wait, automatch_or_challenge) values
(12, 'MAIL', '800', null, null);
							
insert into connection_code (connection_code, mail_or_game, x25_or_800, 
							 dial_or_wait, automatch_or_challenge) values
(13, 'MAIL', '800', null, null);
							

insert into connection_code (connection_code, mail_or_game, x25_or_800, 
							 dial_or_wait, automatch_or_challenge) values
(14, 'MAIL', '800', null, null);
							
insert into connection_code (connection_code, mail_or_game, x25_or_800, 
							 dial_or_wait, automatch_or_challenge) values
(15, 'MAIL', '800', null, null);

commit;
