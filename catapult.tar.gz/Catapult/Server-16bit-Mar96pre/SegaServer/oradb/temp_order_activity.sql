rem $Id: temp_order_activity.sql,v 1.2 1995/10/02 23:23:32 raja Exp $
rem $Log: temp_order_activity.sql,v $
rem Revision 1.2  1995/10/02  23:23:32  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- temporary table used to process orders placed at the xband store 

create table temp_order_activity 
(
product_keyword		varchar2(30),
activity_code		number(3),
box_serial_number	number(6),
box_region			number(2),
box_player_no		number(1),
activity_date		date
)
tablespace data1
storage (initial 1m next 1m pctincrease 0)
;
