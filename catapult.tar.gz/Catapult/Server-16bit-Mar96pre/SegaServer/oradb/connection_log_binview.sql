rem @(#)connection_log_binview.sql	1.3 95/04/19 

create or replace view connection_log_binview as
	select 	c.start_time, 
		c.connection_uid, 
		decode(c.platform_id, 0, 'SEGA', 'SNES') platform,
		c.player_uid, 
		c.box_serial_number, 
		19 box_region, 
		p.name player_name,
		c.game_uid, 
		c.connection_code, 
		c.server_uid,
		c.duration,
		c.exit_status_code,
		c.x25_pop_uid,
		c.dialed_box_serial_number,
		19 dialed_box_region,
		c.dialed_player_uid,
		c.dialed_area_code,
		c.dialed_phone_number,
		c.peer_connection_uid,
		c.xbn_code,
		c.game_error,
		c.local_result,
		c.remote_result,
		c.play_time,
		g.game_name
	from 	connection_log c, 
		player_log p, 
		game g
	where 	p.player_uid = c.player_uid 
   	and 	g.game_uid(+) = c.game_uid
/
	

