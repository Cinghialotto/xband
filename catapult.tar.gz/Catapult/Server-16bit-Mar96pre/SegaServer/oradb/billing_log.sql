rem	$Id: billing_log.sql,v 1.5 1996/01/17 12:37:39 raja Exp $
rem	$Log: billing_log.sql,v $
rem Revision 1.5  1996/01/17  12:37:39  raja
rem added an index on run date to speed up some reports
rem
rem Revision 1.4  1995/10/02  23:22:16  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

rem  This table contains information common to a batch of billing 
rem  transactions.

rem drop table billing_log;

create table billing_log
(
billing_uid			number		not null,	-- unique id
billing_date		date		not null,	-- billing as of this date
run_date			date		not null,	-- actual date this batch was run
daily_month			varchar2(1)	not null,	-- an obsolete code which classified
											-- batches
trans_code 	        number(3),				-- new and improved replacement for
											-- daily month. see transaction_code
											-- table
billing_plan_code	number,					-- see billing plan code
boxes_billed		number,
billing_errors		number,
total_amount_due	number,
min_tran_uid		number,
max_tran_uid		number,
billing_end_time	date,
no_billing_Trans	number,
no_other_trans		number,
file_Sent			date,					-- not used
file_received		date,					-- not used
constraint pk$billing_log primary key (billing_uid)
using index tablespace index1 
            storage (initial 100K next 100K pctincrease 0)
)
tablespace data1
storage (initial 1M next 1M pctincrease 0)
pctfree 5 pctused 90 
;

create index billing_log$run_date on billing_log (run_date)
tablespace index1
storage (initial 1m next 1m pctincrease 0);
