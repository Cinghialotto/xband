create table zipcode
(zip		number(5) not null,
 msacode	number(5) not null,
 constraint pk$zipcode primary key (zip)
 using index 
 tablespace tb2
 storage (initial 2M next 2M pctincrease 0)
)
 tablespace tb1
 storage (initial 2M next 2M pctincrease 0)
;
