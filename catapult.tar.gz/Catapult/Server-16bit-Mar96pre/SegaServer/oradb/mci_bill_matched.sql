rem $Id: mci_bill_matched.sql,v 1.2 1995/11/08 12:35:06 raja Exp $
rem $Log: mci_bill_matched.sql,v $
rem Revision 1.2  1995/11/08  12:35:06  raja
rem increased the length of some columns to match mci_bill
rem
rem Revision 1.1  1995/10/30  20:59:08  raja
rem major reorganization of the binlogs database. Out with the old in with
rem the new. This is not a make work project. Truly. I swear. OK whatever
rem
rem Revision 1.3  1995/10/23  09:54:52  raja
rem new xlog schema
rem
rem Revision 1.2  1995/10/02  23:23:01  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- this table is a copy of the mci_bill table. It is a permanent record of
-- the transactions we could not match to the binlogs. Useful for debugging
-- and fraud detection

rem drop table mci_bill_unmatched;

create table mci_bill_matched
(
call_date_local				number			not null,
call_date_pst				date,
area_code					varchar2(3),
phone_number				varchar2(7),
dialed_area_code			varchar2(3),
dialed_phone_number         varchar2(7),
duration					number(10),
id_code						number(10),
total_amount				number(8,2),
undiscounted_taxes			number(8,2),
total_excl_surcharges		number(8,2),
federal_taxes 				number(8,2),
state_taxes					number(8,2),
surcharges					number(8,2),
rate_code					varchar2(4),
intra_inter_code			number(2),
connection_uid				number(12),
import_uid					number(8),
match_level					number(1),
master						number(1),
slave						number(1)
) tablespace tb1 storage (initial 5M next 5M pctincrease 0) ;

