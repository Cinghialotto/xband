rem $Id: product.sql,v 1.2 1995/10/02 23:23:21 raja Exp $
rem $Log: product.sql,v $
rem Revision 1.2  1995/10/02  23:23:21  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem


-- our inventory table. This table is very simple. If we are going to sell
-- a lot stuff at the xband store, this thing will have to replaced
-- by a whole inventory system

delete from product;

create or replace view product
as
select 	lookup_code product_id,
		lookup_description product_description,
		flex_num_1	inventory
from 	lookup
where	lookup_type = 'PRODUCT'
;

insert into lookup (lookup_type, lookup_code, lookup_description, flex_num_1)
values ('PRODUCT', 0, 'Sega keyboard', 450);

insert into lookup (lookup_type, lookup_code, lookup_description, flex_num_1)
values ('PRODUCT', 1, 'SNES keyboard', 450);

commit;
