rem $Id: sequences.sql,v 1.10 1996/02/19 12:16:16 raja Exp $
rem $Log: sequences.sql,v $
rem Revision 1.10  1996/02/19  12:16:16  raja
rem connection_mci_uid_seq qas missing from this file
rem
rem Revision 1.9  1995/10/30  20:59:13  raja
rem major reorganization of the binlogs database. Out with the old in with
rem the new. This is not a make work project. Truly. I swear. OK whatever
rem
rem Revision 1.8  1995/10/02  23:23:25  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- sequences used in xlog and kat


create sequence box_uid_seq;
create sequence import_uid_seq;
create sequence connection_uid_seq;
create sequence x25_pop_uid_seq;
create sequence server_uid_seq;
create sequence game_uid_seq;
create sequence player_uid_seq;

create sequence problem_code_Seq;


create sequence billing_uid_seq;
create sequence tran_uid_seq;
create sequence account_uid_seq;
create sequence billing_plan_uid_seq;

create sequence fee_uid_seq;
create sequence order_id_seq;
create sequence xbn_mci_file_no;
create sequence mail_seq;

create sequence mci_import_uid_seq;
create sequence connection_mci_uid_seq;
