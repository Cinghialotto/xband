rem $Id: display_table.sql,v 1.1 1995/11/29 19:42:58 raja Exp $
rem $Log: display_table.sql,v $
rem Revision 1.1  1995/11/29  19:42:58  raja
rem warehouse tables
rem

create table display_table
(sessid		number not null,
 category	varchar2(30),
 num_value	number,
 pct_value  number
)
tablespace tb1
storage (initial 100K next 100K pctincrease 0)
pctfree 0 pctused 95 
;

create index i$display_table$sessid on display_table (sessid)
tablespace tb2
storage (initial 100K next 100K pctincrease 0)
pctfree 0 
;

  
