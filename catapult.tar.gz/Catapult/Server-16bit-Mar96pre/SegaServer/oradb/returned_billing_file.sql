rem $Id: returned_billing_file.sql,v 1.7 1996/01/17 10:38:54 raja Exp $
rem $Log: returned_billing_file.sql,v $
rem Revision 1.7  1996/01/17  10:38:54  raja
rem changes for the avs system
rem
rem Revision 1.6  1995/12/06  15:58:02  raja
rem added avs_response_code and zip_code
rem
rem Revision 1.5  1995/11/29  09:32:16  ckn
rem ECP Billing - new billing type and transaction codes.
rem Returned billing file - new structure to reflect username and billing_type_code
rem
rem Revision 1.4  1995/10/02  23:23:23  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- temporary table used to process file Litle returns

create table returned_billing_file 
(
tran_uid			number,
credit_card_num		varchar2(30),
credit_card_expiration	varchar2(10),
amount				number,
merchant_id			varchar2(30),
auth_code			varchar2(30),
auth_tran_id		varchar2(30),
auth_tran_date		varchar2(30),
auth_vendor_code	varchar2(30),
authorization_source varchar2(2),
username			varchar2(30),
billing_type_code	number(5),
avs_response_code	varchar2(2),
zip_code			varchar2(5),
force				varchar2(1)
)
tablespace data1
storage (initial 1m next 1m pctincrease 0)
pctfree 0 pctused 95 
;
