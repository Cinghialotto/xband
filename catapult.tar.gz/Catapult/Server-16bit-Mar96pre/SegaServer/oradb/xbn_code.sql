rem $Id: xbn_code.sql,v 1.2 1995/10/23 09:54:58 raja Exp $
rem $Log: xbn_code.sql,v $
rem Revision 1.2  1995/10/23  09:54:58  raja
rem new xlog schema
rem
rem Revision 1.1  1995/10/11  15:37:34  raja
rem changes for the new binlogs
rem


create table xbn_code (
xbn_code					number(2)	 	not null,
xbn_provider_code			varchar2(7)    		null,		-- 0 local
														-- 1 XBN-MCI
														-- 2 OTHER	
master						number(1)  	 	null,
slave						number(1)  	 	null)
tablespace tb1
storage (initial 100k next 100k pctincrease 0)
pctused 80 pctfree 0
;

delete from xbn_code;

insert into xbn_code (xbn_code, xbn_provider_code, master, slave)
values (0, 'LOCAL', 0, 0);
							
insert into xbn_code (xbn_code, xbn_provider_code, master, slave)
values (4, 'XBN-MCI', 0, 0);
							
insert into xbn_code (xbn_code, xbn_provider_code, master, slave)
values (5, 'XBN-MCI', 0, 1);
							
insert into xbn_code (xbn_code, xbn_provider_code, master, slave)
values (6, 'XBN-MCI', 1, 0);
							
insert into xbn_code (xbn_code, xbn_provider_code, master, slave)
values (7, 'XBN-MCI', 1, 1);

insert into xbn_code (xbn_code, xbn_provider_code, master, slave)
values (8, 'OTHER', 0, 0);
							
							
commit;
