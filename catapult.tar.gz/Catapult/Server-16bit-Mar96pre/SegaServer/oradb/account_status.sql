rem	$Id: account_status.sql,v 1.2 1995/10/02 23:22:12 raja Exp $
rem	$Log: account_status.sql,v $
rem Revision 1.2  1995/10/02  23:22:12  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- View that stores account status codes. Mirrors codes stored in rpc.segad


delete from account_status;

create or replace view account_status
as
select 	lookup_code account_status_code,
	lookup_description account_status_description
from 	lookup
where	lookup_type = 'ACCOUNT STATUS'
;

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACCOUNT STATUS', 0, 'Beta');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACCOUNT STATUS', 10010, 'Guest');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACCOUNT STATUS', 10100, 'Active');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACCOUNT STATUS', 10101, 'Pending');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACCOUNT STATUS', 10102, 'Suspended');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACCOUNT STATUS', 10103, 'Closed');

commit;

