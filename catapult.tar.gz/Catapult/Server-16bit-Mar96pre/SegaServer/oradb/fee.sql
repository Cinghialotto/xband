rem $Id: fee.sql,v 1.3 1995/10/02 23:22:48 raja Exp $
rem $Log: fee.sql,v $
rem Revision 1.3  1995/10/02  23:22:48  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem
 
-- what was the dollar amount of a certain fee on a certain date. Not
-- really used, since we have one fee (Setup fee) and it has always
-- been $2.95


create table fee
(fee_uid		number not null,
 fee_code		number not null,
 fee_amount		number not null,
 start_date		date   not null,
 end_date		date,
 constraint pk$fee primary key (fee_uid)
 using index tablespace index1
 	     storage (initial 100K next 100K pctincrease 0)
)
tablespace data1
storage (initial 100K next 100K pctincrease 0)
pctfree 0 pctused 90 
;
  
