rem $Id: peer_error.sql,v 1.2 1995/10/02 23:23:10 raja Exp $
rem $Log: peer_error.sql,v $
rem Revision 1.2  1995/10/02  23:23:10  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- view which gives us all the errors codes for a peer connection.
-- used in some reports


create or replace view peer_error
as
select  m.connection_uid 	master_connection_uid,
		s.connection_uid 	slave_connection_uid,
		m.start_time 		master_start_time,
		gm.game_error		master_game_Error,
		gs.game_error		slave_game_Error
from	connection_log m,
		connection_log s,
		game_Result gm,
		game_Result gs
where	s.connection_uid = m.peer_connection_uid
and		gm.master_connection_uid = m.connection_uid
and		gs.master_connection_uid = s.connection_uid
and		m.peer_connection_uid is not null;
