rem $Id: peer_error_category.sql,v 1.2 1995/10/02 23:23:11 raja Exp $
rem $Log: peer_error_category.sql,v $
rem Revision 1.2  1995/10/02  23:23:11  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- classification of peer error code pairs. Not used

delete from peer_error_category;

create or replace view peer_error_category
as
select 	lookup_code 		peer_Error_category_code,
	lookup_description 	peer_error_category_desc
from 	lookup
where	lookup_type = 'PEER ERROR CATEGORIES'
;

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('PEER ERROR CATEGORIES', 0, 'Happy Customer');

commit;

