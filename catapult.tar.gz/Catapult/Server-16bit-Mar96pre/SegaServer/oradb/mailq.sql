rem 
rem $Id: mailq.sql,v 1.3 1995/05/24 16:07:49 chs Exp $
rem 
rem $Log: mailq.sql,v $
rem Revision 1.3  1995/05/24  16:07:49  chs
rem Fix rcs comments
rem
rem Revision 1.2  1995/05/24  14:19:41  chs
rem Added icon, color, and town for from player.
rem 
rem 

create table mailq (
box number not null,
region number not null,
player number not null,
mailid number not null,
from_icon number not null,
serialno number,
flags number not null,
constraint pk$mailq primary key (box, region, player, mailid)
	using index tablespace index1
			storage (initial 10M next 10M pctincrease 0)
)
tablespace data1
storage (initial 20M next 10M pctincrease 0)
pctfree 20 pctused 40
;

