rem $Id: display_category.sql,v 1.1 1995/12/06 15:46:30 raja Exp $
rem $Log: display_category.sql,v $
rem Revision 1.1  1995/12/06  15:46:30  raja
rem temporary tables used by my warehouse tool
rem
rem Revision 1.1  1995/11/29  19:42:58  raja
rem warehouse tables
rem

create table display_category
(sessid		number not null,
 category1	varchar2(30),
 category2	varchar2(30),
 category3	varchar2(30),
 category4	varchar2(30)
)
tablespace tb1
storage (initial 100K next 100K pctincrease 0)
pctfree 0 pctused 95 
;

create index i$display_category$sessid on display_category (sessid)
tablespace tb2
storage (initial 100K next 100K pctincrease 0)
pctfree 0 
;

  
