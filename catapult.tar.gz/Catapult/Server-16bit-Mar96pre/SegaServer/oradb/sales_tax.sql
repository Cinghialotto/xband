rem $Id: sales_tax.sql,v 1.2 1995/10/09 17:11:29 raja Exp $
rem $Log: sales_tax.sql,v $
rem Revision 1.2  1995/10/09  17:11:29  raja
rem added field county
rem
rem Revision 1.1  1995/10/02  23:23:24  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- this table contains sales tax rates. If the zip code is null, the
-- tax rate applies to the whole state. If there are exceptions to
-- the state-wide rate, they will in records with zip codes

create table sales_tax 
(
state		char(2) not null,
zip			varchar2(5) null,
rate		number, -- percent
county		varchar2(30)
)
tablespace data1
storage (initial 100k next 100k pctincrease 0)
;

create unique index uk$sales_tax on sales_tax (state, zip)
tablespace index1
storage (initial 100k next 100k pctincrease 0)
;
