rem $Id: autochal.sql,v 1.2 1995/10/02 23:22:15 raja Exp $
rem $Log: autochal.sql,v $
rem Revision 1.2  1995/10/02  23:22:15  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- used in connection_log. was a certain game connection
-- a challenge or off the player list?
--	autochal == automatch/challenge

delete from autochal;

create or replace view autochal
as
select 	lookup_code autochal_code,
	lookup_description autochal_description
from 	lookup
where	lookup_type = 'AUTOMATCH/CHALLENGE'
;

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('AUTOMATCH/CHALLENGE', 0, 'Auto Match');

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('AUTOMATCH/CHALLENGE', 1, 'Challenge');

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('AUTOMATCH/CHALLENGE', 2, 'AutoMatch or Challenge Unknown');

commit;
