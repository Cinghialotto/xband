rem $Id: phone_stats.sql,v 1.2 1995/10/02 23:23:13 raja Exp $
rem $Log: phone_stats.sql,v $
# Revision 1.2  1995/10/02  23:23:13  raja
# added comments and cvs headers to all sql command files. removed
# obsolete stuff
#

-- statistics on various peer error failures. Some business objects
-- reports were run off this table by ted. I don't think this
-- is in use

create table phone_stats
(
game_id						varchar2(30),
call_time					date,
call_type					number(1),
good_games					number(5),	
bad_games					number(5),
busy_call_waiting			number(4),
busy_never_called			number(4),
busy_no_answer				number(4),
busy_reset					number(4),
busy_timeout				number(4),
call_waiting				number(4),
call_waiting_timeout		number(4),
garbled_peer_exchange_data	number(4),
handshake					number(4),
handshake_problem			number(4),
master_reset				number(4),
no_answer_opponent_verify	number(4),
no_dialtone_call_waiting	number(4),
no_dialtone_never_called	number(4),
no_dialtone_no_answer		number(4),
no_dialtone_reset			number(4),
no_dialtone					number(4),
opponent_verify_failed		number(4),
opponent_verify_failed_cw	number(4),
opponent_verify_failed_re	number(4),
reset						number(4),
reset_call_waiting			number(4),
reset_never_called			number(4),
reset_no_answer				number(4),
reset_opponent_verification	number(4),
slave_never_got_called		number(4),
slave_reset					number(4),
timeout						number(4),
timeout_never_called		number(4),
timeout_reset				number(4),
unknown						number(4),
unknown_call_waiting		number(4),
unknown_opponent_verification	number(4),
unknown_reset				number(4)
)
tablespace data1
storage (initial 1M next 1M pctincrease 0)
;

create index i$phone_stats$game_id
on phone_stats (game_id)
tablespace index1
storage (initial 1M next 1M pctincrease 0)
;

create index i$phone_stats$call_time
on phone_stats (call_time)
tablespace index1
storage (initial 1M next 1M pctincrease 0)
;
