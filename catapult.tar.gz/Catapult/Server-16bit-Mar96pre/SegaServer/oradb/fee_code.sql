rem $Id: fee_code.sql,v 1.3 1995/10/02 23:22:49 raja Exp $
rem $Log: fee_code.sql,v $
rem Revision 1.3  1995/10/02  23:22:49  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem
 
-- descriptions of fees. All except the setup fees are bogus

delete from fee_code;

create or replace view fee_code
as
select 	lookup_code 		fee_code,
	lookup_description 	fee_description
from 	lookup
where	lookup_type = 'FEE CODE'
;

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('FEE CODE', 0, 'Password change fee');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('FEE CODE', 1, 'Custom icon fee');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('FEE CODE', 2, 'Setup fee for /xband/monthly/regular');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('FEE CODE', 3, 'Setup fee for /xband/6for5/monthly');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('FEE CODE', 10, 'Setup fee for /xband/unlimitedcredits/monthly');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('FEE CODE', 11, 'Setup fee for /xband/50credits/monthly');

commit;
