rem $Id: connection_mci.sql,v 1.6 1995/10/30 20:59:01 raja Exp $
rem $Log: connection_mci.sql,v $
rem Revision 1.6  1995/10/30  20:59:01  raja
rem major reorganization of the binlogs database. Out with the old in with
rem the new. This is not a make work project. Truly. I swear. OK whatever
rem
rem Revision 1.5  1995/10/23  09:54:44  raja
rem new xlog schema
rem
rem Revision 1.3  1995/10/02  23:22:31  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- this table is the link between connection_log, mci_bill and
-- the billing system. It keeps information about each game 
-- played over XBN. It also stores information from mci_bill
-- since mci_bill is trasient data and this guy is permanent.

rem drop table connection_mci;

create table connection_mci
(
connection_mci_uid	number(10)		not null,
connection_uid		number(10)		not null,
master_box_number	number(8),
master_box_region	number(2),
slave_box_number	number(8),
slave_box_region	number(2),
est_duration		number(8),
duration			number(8),
number_of_calls		number(4),
cost				number,
tax					number,
record_type			number(1),
match_level			number(1),
call_date_pst		date,
constraint pk$connection_mci primary key (connection_mci_uid)
using index tablespace tb2 storage (initial 20M next 20M pctincrease 0)
					   pctfree 0
)
tablespace tb1
storage (initial 50M next 20M pctincrease 0)
pctfree 5 pctused 80
;

create index i$connmci$connection_uid on connection_mci (connection_uid)
tablespace tb2 storage (initial 10M next 10M pctincrease 0)
					   pctfree 0
;
