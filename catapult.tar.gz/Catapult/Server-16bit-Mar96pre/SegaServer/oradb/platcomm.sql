create or replace view platcomm as
	select	box_serial_number,
			box_region,
			name,
			address,
			city,
			state,
			zip,
			home_phone,
			game_phone,
			cs_id,
			platform_uid
	from	box
	union
	select	box    box_serial_number,
			region box_region,
			name,
			address,
			city,
			state,
			zip,
			home_phone,
			game_phone,
			box cs_id,
			2000 platform_uid
	from	pcbox
;
				
				
