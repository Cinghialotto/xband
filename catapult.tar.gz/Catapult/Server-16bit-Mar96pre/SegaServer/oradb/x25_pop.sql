rem $Id: x25_pop.sql,v 1.5 1995/11/02 10:37:48 raja Exp $
rem $Log: x25_pop.sql,v $
rem Revision 1.5  1995/11/02  10:37:48  raja
rem final changes to the new xlog schema
rem
rem Revision 1.3  1995/10/11  15:37:33  raja
rem changes for the new binlogs
rem
rem Revision 1.2  1995/10/02  23:23:34  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- list of x25 pops used to access our server

create table x25_pop (
	x25_pop_uid				number,
	x25_pop_description		varchar2(50),
	x25_pop_address			varchar2(50),	
	main_number				varchar2(15),	
	alt_number				varchar2(15),
	constraint pk$x25_pop primary key (x25_pop_uid)
	using index tablespace tb2 storage (initial 1M next 1M pctincrease 0)
									pctfree 0)
tablespace tb1
storage (initial 2M next 1M pctincrease 0)
pctused 80 pctfree 0
; 

create index i$x25_pop$add on x25_pop (x25_pop_address,
main_number, alt_number)
storage (initial 5M next 5M pctincrease 0)
pctfree 0
/
