rem	$Id: box_change_log.sql,v 1.24 1996/03/06 08:35:53 raja Exp $
rem	$Log: box_change_log.sql,v $
rem	Revision 1.24  1996/03/06 08:35:53  raja
rem	added support to stitch pop numbers
rem
rem Revision 1.23  1995/12/21  13:47:34  raja
rem changes for setting pop overrides in catadmin
rem
rem Revision 1.22  1995/11/16  18:15:45  raja
rem fucked up column names in both tables
rem
rem Revision 1.21  1995/11/16  18:00:00  raja
rem changes from ECP
rem
rem Revision 1.20  1995/11/08  12:36:14  raja
rem added columns acquisition_type and no_setup_fee_bit to support
rem EA Madden 96 accounts
rem
rem Revision 1.19  1995/10/17  21:33:54  raja
rem added total_server_connects and terms_not_signed_bit
rem
rem Revision 1.18  1995/10/05  15:43:14  raja
rem left out termination_date which ck added
rem
rem Revision 1.17  1995/10/05  15:42:12  raja
rem I now stitch several new fields :-
rem     suspend_behavior_bit
rem     agreed_to_terms_bit
rem     comments
rem     termination_date
rem     xbn_cap
rem     xbn_usage_last_month
rem     xbn_usage_this_month
rem     bank_num and checking_acct_num (partly)
rem
rem Revision 1.16  1995/10/02  23:22:22  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- used by the stitcher to figure out what has changed in the
-- oracle databse. This table is populated by a trigger on
-- box


rem drop table box_change_log;

create table box_change_log
(
box_serial_number		number,
box_region				number,
account_status			number(1),
billing_type_code		number(1),
area_restriction		number(1),
weekend_restrict_start	number(1),
weekend_restrict_end	number(1),
weekday_restrict_start	number(1),
weekday_restrict_end	number(1),
credits_used			number(1),
max_credits				number(1),
max_free_credits		number(1),
start_credits			number(1),
hometown				number(1),
game_phone				number(1),
orig_game_phone			number(1),
credit_card_num			number(1),
credit_card_expiration	number(1),
profanity_filter		number(1),
access_code				number(1),
name					number(1),
address					number(1),
city					number(1),
state					number(1),
zip						number(1),
country					number(1),
home_phone				number(1),
disable_xmail_bit		number(1),
rebilling_bit			number(1),
suspend_bit				number(1),
pending_bit				number(1),
split_modem_incest_bit	number(1),
billing_plan_code		number(1),
bind_lost_modem_bit		number(1),
credit_approved    		number(1),
free_xbn_bit			number(1),
vip_xbn_bit				number(1),
xbn_subscribed_bit		number(1),
activation_date			number(1),
created_date			number(1),
promo_string			number(1),
product_activate		number(1),
platform_uid			number(1),
cc_changed				number(1),
mci_phone_list			number(1),
closed_date				number(1),
disable_xbn_bit			number(1),
game_tester_bit			number(1),
os_tester_bit			number(1),
comments				number(1),
suspend_behavior_bit	number(1),
agreed_to_terms_bit		number(1),
xbn_cap					number(1),
checking_acct_num		number(1),
bank_num				number(1),
termination_date		number(1),
total_server_connects	number(1),
terms_not_signed_bit	number(1),
acquisition_type		number(1),
no_setup_fee_bit		number(1),
prenote_processed_bit	number(1),
prenote_sent_date		number(1),
paperwork_received_bit	number(1),
collect_setup_fee_bit	number(1),
override_phones			number(1),
seq_800_connects		number(1),
send_xbaccess_mail_bit	number(1),
box_pop_override_bit	number(1),
cs_pop_override_bit		number(1),
reset_pops				number(1),
to_be_processed			number(1)
)
tablespace data1
storage (initial 4M next 2M pctincrease 0)
pctfree 10 pctused 90 
;

create unique index pk$box_change_log on box_change_log (box_serial_number,
												  		 box_region)
tablespace index1
storage (initial 2M next 2M pctincrease 0)
;
