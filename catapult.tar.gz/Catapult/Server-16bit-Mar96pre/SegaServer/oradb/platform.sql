rem $Id: platform.sql,v 1.6 1995/10/30 20:59:12 raja Exp $
rem $Log: platform.sql,v $
rem Revision 1.6  1995/10/30  20:59:12  raja
rem major reorganization of the binlogs database. Out with the old in with
rem the new. This is not a make work project. Truly. I swear. OK whatever
rem
rem Revision 1.5  1995/10/02  23:23:14  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- platform codea and descriptions

delete from platform;

create or replace view platform
as
select 	lookup_code platform_uid,
	lookup_description platform_description
from 	lookup
where	lookup_type = 'PLATFORM'
;

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('PLATFORM', 1936025441, 'Sega');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('PLATFORM', 1936614771, 'SNES');

commit;
