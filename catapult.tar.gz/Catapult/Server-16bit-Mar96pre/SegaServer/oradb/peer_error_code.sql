rem $Id: peer_error_code.sql,v 1.3 1995/10/02 23:23:11 raja Exp $
rem $Log: peer_error_code.sql,v $
rem Revision 1.3  1995/10/02  23:23:11  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- descriptions of peer error code pairs. not used.


delete from peer_error_code;

create or replace view peer_error_code
as
select 	lookup_code 		peer_Error_code,
	lookup_description 	peer_error_description,
	flex_num_1		peer_error_category_code,
	flex_num_2		master_error_code,
	flex_num_3		slave_error_code
from 	lookup
where	lookup_type = 'PEER ERROR CODES'
;


insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 1,  null, 
-13,	-426, 	'Master Reset');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 2,  null, 
-415,	-13 ,	'Slave Reset');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 3,  null, 
-13, 	-13 ,	'Reset');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 4,  null, 
-415, 	-415, 	'Handshake Problem');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 5,  null, 
-415, 	-426, 	'Timeout');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 6,  null, 
-429, 	-415, 	'Handshake Problem');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 7,  null, 
-415, 	0 ,	'Slave	never got called');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 8,  null, 
0, 	-426, 	'Unknown');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 9,  null, 
0, 	-415, 	'Unknown');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 10,  null, 
-432, 	-434, 	'Call Waiting');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES',  11, null,
-413, 	-13 ,	'Busy/Reset');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 12,  null, 
0, 	-13 ,	'Unknown/Reset');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 13,  null, 
-13, 	0 ,	'Reset/Never called');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 14,  null, 
-415, 	-434, 	'Call Waiting');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 15,  null, 
-416, 	-426, 	'No dialtone');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 16,  null, 
-413, 	0, 	'Busy/Never called');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 17,  null, 
-432, 	-432, 	'Call Waiting Timeout');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 18,  null, 
-415, 	-432, 	'Call Waiting');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 19,  null, 
0, 	-306, 	'Unknown/Opponent Verification Failed');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 20,  null, 
-413, 	-415, 	'Busy/No Answer');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 21,  null, 
-413, 	-426, 	'Busy/Timeout');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 22,  null, 
-426,	0 ,	'Timeout/Never called');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 23,  null, 
-416, 	-415, 	'No Dialtone/No Answer');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 24,  null, 
-433, 	-433, 	'Garbled Peer Exchange Data');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 25,  null, 
-416,  	-13 ,	'No Dialtone/Reset');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 26,  null, 
-306,  	-13 ,	'Opponent Verification Failed/Reset');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 27,  null, 
-306, 	-306, 	'Opponent Verification Failed');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 28,  null, 
-426, 	-426, 	'Timeout');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 29,  null, 
-13, 	-432, 	'Reset/Call Waiting');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 30,  null, 
-13, 	-415, 	'Reset/No Answer');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 31,  null, 
-415, 	-306, 	'No Answer/Opponent Verification Failed');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 32,  null, 
-413, 	-432, 	'Busy/Call Waiting');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 33,  null, 
-429, 	-429, 	'Handshake');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 34,  null, 
-426,  	-13 ,	'Timeout/Reset');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 35,  null, 
-416,	0 ,	'No Dialtone/Never called');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 36,  null, 
-306, 	-432, 	'Opponent Verification Failed/Call Waiting');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 37,  null, 
-413, 	-434, 	'Busy/Call Waiting');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 38,  null, 
-415, 	-429, 	'Handshake');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 39,  null, 
-416, 	-434, 	'No Dialtone/Call Waiting');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 40,  null, 
-436, 	-432, 	'Unknown/Call Waiting');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 41,  null, 
-432, 	-426, 	'Call Waiting/Timeout');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 42,  null, 
-13, 	-306, 	'Reset/Opponent Verification Failed');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 43,  null, 
-306,	0, 	'Opponent Verification Failed');

insert into lookup (lookup_type, lookup_code, flex_num_1,
flex_num_2, flex_num_3, lookup_description)
values ('PEER ERROR CODES', 44,  null, 
-413, 	-429, 	'Handshake');

commit;
