rem $Id: pop_dial.sql,v 1.1 1996/02/03 15:11:27 raja Exp $
rem $Log: pop_dial.sql,v $
rem Revision 1.1  1996/02/03  15:11:27  raja
rem new table to keep track of all valid pop_dialing combinations
rem

create table pop_dial
(pop					varchar2(10) not null,
 dial					varchar2(11) not null,
 city					varchar2(30),
 state					varchar2(2)
)
tablespace data1
storage (initial 1M next 1M pctincrease 0)
;

create index i$pop_dial$pop on pop_dial (pop) 
tablespace index1
storage (initial 500k next 500k pctincrease 0)
;

create index i$pop_dial$dial on pop_dial (dial)
tablespace index1
storage (initial 500k next 500k pctincrease 0)
;
