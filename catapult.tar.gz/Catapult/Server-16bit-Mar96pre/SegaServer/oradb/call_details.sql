rem $Id: call_details.sql,v 1.4 1996/01/11 11:07:27 ckn Exp $
rem $Log: call_details.sql,v $
rem Revision 1.4  1996/01/11  11:07:27  ckn
rem Added caller_name - to keep track of the person calling.
rem
rem Revision 1.3  1996/01/02  16:04:33  raja
rem changes for "escalated" radio button in catadmin
rem
rem Revision 1.2  1995/11/17  14:56:09  ckn
rem Added comments
rem
rem View based on Call Tracking Info.

create or replace view call_details 
as 	select 	record_type, 
			start_time, 
			end_time, 
			substr(description, 14, 10) game_phone,
			substr(description, 25) description,
		    box_serial_number,
		    box_region,
			problem_code,
			hangup_time,
			userid,
			escalated,
			caller_name
from call_tracking
where record_type = 2;

