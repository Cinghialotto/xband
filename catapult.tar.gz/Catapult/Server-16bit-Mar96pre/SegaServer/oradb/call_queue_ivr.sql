rem $Id: call_queue_ivr.sql,v 1.2 1995/11/03 11:42:29 raja Exp $
rem $Log: call_queue_ivr.sql,v $
rem Revision 1.2  1995/11/03  11:42:29  raja
rem minor bugs fixed
rem
rem Revision 1.1  1995/11/03  11:27:19  raja
rem New tables for the IVR-Operator Matcher
rem

create or replace view call_queue_ivr as
select * from call_queue
;
