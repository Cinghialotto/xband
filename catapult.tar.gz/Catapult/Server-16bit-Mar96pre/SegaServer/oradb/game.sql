rem $Id: game.sql,v 1.5 1995/10/23 09:54:49 raja Exp $
rem $Log: game.sql,v $
rem Revision 1.5  1995/10/23  09:54:49  raja
rem new xlog schema
rem
rem Revision 1.4  1995/10/11  15:37:27  raja
rem changes for the new binlogs
rem

create table game
(
game_uid			number(10)		not null,
game_id				varchar2(30)	not null,
game_version		varchar2(50)	null,
game_name			varchar2(50)	not null,
game_description	varchar2(50)	null,
platform			varchar2(10) null,
constraint pk$game primary key (game_uid)
using index tablespace tb2 storage (initial 1M next 1M pctincrease 0)
)
tablespace tb1
storage (initial 2M next 1M pctincrease 0)
;


create index i$game$game_id on game (game_id, game_name, game_version)
tablespace tb2
storage (initial 1M next 1M pctincrease 0)
;
