rem %Id%
rem %Log%
rem 95/11/95  ck
rem added new transaciton codes for ecp billing - starts from 50
rem

-- billing transaction codes. Used to classify billing events


create table transaction_code (
	trans_code  	number(3)     not null,
	trans_desc  	varchar2(80)  not null,
	merchant_id 	varchar2(30),
	due				number(1),
	collect			number(1),
	force			number(1),
	daily_month		varchar2(1),
	balance_type	varchar2(1),
	catadmin_update varchar2(1),
	balance_update  varchar2(1),
	description		varchar2(30),
	constraint 	pk$transaction_codes primary key (trans_code)
	using index tablespace index1
		    storage (initial 50K next 25K pctincrease 0))
tablespace data1
storage (initial 100K next 50K pctincrease 0)
pctfree 0 pctused 95
;

delete from transaction_code;

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(0, 'Rebill  service', 'BILLPLAN', 0, 1,0, 'D', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(1, 'Setup   cc unlimited', '126961', 1, 1,0, 'D', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(2, 'Setup   cc basic', '126961', 1, 1,0, 'D', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(3, 'Convert cc basic->cc unlimited', '126987', 1, 1,0, 'D', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(4, 'Convert check basic->cc unlimited', '126987', 1, 1,0, 'D', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(5, 'Convert check basic->cc basic', '126979', 1, 1,0, 'D', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(6, 'Convert check basic->check unlimited', 'NONE', 1, 1,0, 'D', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(7, 'Convert cc basic->check unlimited', '126979', 1, 1,0, 'D', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(8, 'Convert cc basic->check basic', '126979', 1, 1,0, 'D', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(9, 'Prebill convert check->cc unlimited', '126987', 0, 1,0, 'P', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(10, 'Prebill convert check->cc basic', '126979', 0, 1,0, 'P', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(11, 'Prebill cc changed', 'BILLPLAN', 0, 1,0, 'P', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type, description)
values
(12, 'XBN     estimated', 'NONE', 1, 0,0, 'E', 'X','Estimated');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type, description)
values
(13, 'XBN     cdrom', 'NONE', 1, 0,0, 'R', 'X', 'Phone Bill');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type, description)
values
(14, 'XBN     threshold', '114793', 0, 1,0, 'T', 'X', '$20 threshold');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type, description)
values
(15, 'XBN     rebill', '114793', 0, 1,0, 'X', 'X', 'Retry');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type, description)
values
(16, 'XBN     aniversary', '114793', 0, 1,0, 'T', 'X', 'Monthly');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(17, 'Anniv   cc unlimited', '126987', 1, 1,0, 'M', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(18, 'Anniv   cc basic', '126979', 1, 1,0, 'M', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(19, 'Convert cc unlimited->cc basic', '126979', 1, 1,0, 'M', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(20, 'Convert cc unlimited->check unlimited', '126987', 1, 1,0, 'D', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(21, 'Convert cc unlimited->check basic', '126987', 1, 1,0, 'D', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(22, 'Convert check unlimited->cc basic', '126979', 1, 1,0, 'M', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(23, 'Convert check unlimited->cc unlimited', '126987', 1, 1,0, 'M', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(24, 'Oper    check unlimited-first check', 'NONE', 1, 1,0, 'C', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(25, 'Oper    check unlimited-subsequent check', 'NONE', 1, 1,0, 'C', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(26, 'Oper    check basic-first check', 'NONE', 1, 1,0, 'C', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(27, 'Oper    check basic-subsequent check', 'NONE', 1, 1,0, 'C', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(28, 'Adjust  service balance', 'BILLPLAN', 1, 0,0, 'A', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type, description)
values
(29, 'Adjust  XBN balance', '114793', 1, 0,0, 'Y', 'X', 'Adjust');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(30, 'Anniv   old 7.95 plan', 'NONE', 1, 1,0, 'M', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(35, 'Sales   Keyboard authorization', '128017', 0, 0,0, 'S', 'N');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(36, 'Sales   Keyboard deposit', '128017', 0, 0,0, 'S', 'N');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(50, 'Prenote new account', '128017', 0, 0,0, 'J', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(51, 'Prenote cc convert', '128017', 0, 0,0, 'J', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(52, 'Prenote prepaid convert', '128017', 0, 0,0, 'J', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(53, 'Prenote ECP changes', '128017', 0, 0,0, 'J', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(54, 'Day10   setup fee-cc unlimited', '126961', 1, 1,0, 'K', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(55, 'Day10   setup fee-cc basic', '126961', 1, 1,0, 'K', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(56, 'Day10   prebill-cc unlimited', '126987', 0, 1,0, 'K', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(57, 'Day10   prebill-cc basic', '126979', 0, 1,0, 'K', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(58, 'Day10   collect-service balance', 'BILLPLAN', 0, 1,0, 'K', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type, description)
values
(59, 'Day10   collect-XBN balance', '114793', 0, 1,0, 'K', 'X', 'Collect balance');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type, description)
values
(70, 'Rebill  XBN auto retry', '114793', 0, 1,1, 'B', 'X', 'Retry');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type)
values
(71, 'Rebill  service auto retry', 'BILLPLAN', 0, 1,1, 'B', 'S');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type, catadmin_update, balance_update)
values
(80, 'Oper    Service balance refund', 'BILLPLAN', 0, 1,0, 'A', 'S', 'Y', 'Y');

insert into transaction_code (trans_code, trans_desc, merchant_id, due, collect,								force,daily_month, balance_type, catadmin_update, balance_update, description)
values
(81, 'Oper    XBN balance refund', '114793', 0, 1,0, 'Y', 'X', 'Y', 'Y', 'Refund');

commit;
