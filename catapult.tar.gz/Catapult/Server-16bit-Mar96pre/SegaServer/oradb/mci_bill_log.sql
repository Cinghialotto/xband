rem	$Id: mci_bill_log.sql,v 1.1 1995/10/30 20:59:08 raja Exp $
rem	$Log: mci_bill_log.sql,v $
rem Revision 1.1  1995/10/30  20:59:08  raja
rem major reorganization of the binlogs database. Out with the old in with
rem the new. This is not a make work project. Truly. I swear. OK whatever
rem


create table mci_bill_log
(
import_uid			number(10),
import_date			date,
file_name			varchar2(100),
min_connection_mci_uid	number(10),
max_connection_mci_uid	number(10),
calls				number(7),
level0				number(7),
level1				number(7),
level2				number(7),
unmatched			number(7),
bill_start			date,
bill_end			date,
mci_minutes			number(10),
rounded_minutes		number(10),
estimated_minutes	number(10),
total_cost_day		number(10,2),
total_tax_day		number(10,2),
total_cost_en		number(10,2),
total_tax_en		number(10,2),
import_end_date		date,
constraint pk$mci_bill_log primary key (import_uid)
using 	index tablespace tb2 storage (initial 1M next 1M pctincrease 0)
)
tablespace tb1
storage (initial 2M next 1M pctincrease 0)
;
