rem $Id: completion.sql,v 1.2 1995/10/02 23:22:29 raja Exp $
rem $Log: completion.sql,v $
rem Revision 1.2  1995/10/02  23:22:29  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- silly code that tells us whether a game result we received is
-- complete or not

delete from completion;

create or replace view completion
as
select 	lookup_code completion_code,
	lookup_description completion_description
from 	lookup
where	lookup_type = 'COMPLETION'
;

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('COMPLETION', 0, 'Incomplete');

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('COMPLETION', 1, 'Complete');

commit;

