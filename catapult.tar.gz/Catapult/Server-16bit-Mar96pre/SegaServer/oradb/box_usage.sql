rem	$Id: box_usage.sql,v 1.3 1995/10/02 23:22:25 raja Exp $
rem	$Log: box_usage.sql,v $
rem Revision 1.3  1995/10/02  23:22:25  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- tracks box's usage of credits every month

create table box_usage 
(
	box_serial_number	number not null,
    box_region			number not null,
    month				date not null,
    start_credits		number,
    credits_used		number,
    usage				number,
constraint pk$box_usage primary key (box_Serial_number, box_region, month)
using index tablespace index1
storage (initial 2M next 2M pctincrease 0)
)
tablespace data1
storage (initial 4M next 2M pctincrease 0)
pctfree 10 pctused 90 
;

