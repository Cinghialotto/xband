rem $Id: carrier_type.sql,v 1.2 1995/10/02 23:22:27 raja Exp $
rem $Log: carrier_type.sql,v $
rem Revision 1.2  1995/10/02  23:22:27  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- X25 or 800 . used in connection log and some summaries

delete from carrier_type;

create or replace view carrier_type
as
select 	lookup_code carrier_type_code,
	lookup_description carrier_type_description
from 	lookup
where	lookup_type = 'CARRIER TYPES'
;

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('CARRIER TYPES', 0, 'X25');

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('CARRIER TYPES', 1, '800');

commit;

