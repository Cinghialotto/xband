rem $Id: order_status.sql,v 1.2 1995/10/02 23:23:07 raja Exp $
rem $Log: order_status.sql,v $
rem Revision 1.2  1995/10/02  23:23:07  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- order statuses for orders placed at the xband store

delete from order_status;

create or replace view order_status
as
select 	lookup_code status,
		lookup_description status_description
from 	lookup
where	lookup_type = 'ORDER STATUS'
;

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ORDER STATUS', 10, 'Pre-Order');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ORDER STATUS', 20, 'Accepted');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ORDER STATUS', 30, 'Allocated');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ORDER STATUS', 40, 'Authorized');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ORDER STATUS', 50, 'Sent to Shipper');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ORDER STATUS', 60, 'Shipped');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ORDER STATUS', 70, 'Completed');


commit;
