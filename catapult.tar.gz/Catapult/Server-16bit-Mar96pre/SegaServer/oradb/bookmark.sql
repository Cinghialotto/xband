rem $Id: bookmark.sql,v 1.1 1995/11/29 19:52:32 raja Exp $
rem $Log: bookmark.sql,v $
rem Revision 1.1  1995/11/29  19:52:32  raja
rem data warehouse tables
rem

create table bookmark
(
bookmark_uid		number,
text				varchar2(511),
sum_by				varchar2(30),
add_up				varchar2(30),
add_up2				varchar2(30),
add_up3				varchar2(30),
add_up4				varchar2(30),
date_type			number,
val					varchar2(511),
userid				varchar2(30),
form_name			varchar(30),
constraint pk$bookmark primary key (bookmark_uid)
using index
		tablespace tb2 
		storage (initial 1M next 1M pctincrease 0)
)
tablespace tb1 
storage (initial 5M next 1M pctincrease 0)
;

create sequence bookmark_uid_seq;
