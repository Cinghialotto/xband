rem	$Id: billing_tran.sql,v 1.15 1996/02/05 17:51:05 raja Exp $
rem	$Log: billing_tran.sql,v $
rem Revision 1.15  1996/02/05  17:51:05  raja
rem col order_id was missing. Added this a long time ago for the keyboard sales
rem
rem Revision 1.14  1996/01/30  11:20:29  raja
rem added an index on billing_date
rem
rem Revision 1.13  1996/01/17  12:52:53  raja
rem added an index on billing_uid
rem
rem Revision 1.12  1996/01/09  16:29:20  raja
rem new billing programs. Added merchant_id and an attempt_to_collect field
rem
rem Revision 1.11  1995/12/27  12:00:47  raja
rem add merchant id to this table. This will make it easier to generate
rem one giant transaction file
rem
rem Revision 1.10  1995/12/06  15:58:55  raja
rem added avs_response_code. This is the "Address verification Service" code
rem which checks zip code of credit card holder
rem
rem Revision 1.9  1995/10/02  23:22:19  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- this table contains information about billing transactions. A billing
-- transaction is any event that has any financial impact on the box

create table billing_tran
(
tran_uid				number 		not null,	-- unique number
box_serial_number		number		not null,	-- see box
box_region				number		not null,
billing_type_code		number		not null,	-- see billing_type
total_amount_due		number		not null,
amount_collected		number,
minimum_fee				number,					-- for anniversary billing
total_credits			number,
extra_credits			number,
extra_credit_fee		number,
credit_card_num			varchar2(30),
credit_card_expiration	varchar2(10),
check_number			varchar2(30),			-- for checking transactions
charge_back             number(1),				-- did the customer dispute this
												-- charge
billing_uid				number,					-- see billing_log
billing_date			date,
billing_plan_uid		number,					-- see billing_plan
billing_days			number,					-- not used
auth_code				varchar2(30),			-- from litle
auth_tran_id			varchar2(30),			-- from litle
auth_tran_date			date,					-- from litle
auth_vendor_code		varchar2(30),			-- from litle
authorization_source	varchar2(2),			-- from litle
rebilling_tran_uid		number,					-- pointer to previous txn
												-- being rebilled here
error_text				varchar2(255),
comments				varchar2(200),
min_connection_mci		number,					-- see connection_mci
max_connection_mci		number,					-- see connection_mci
avs_response_code		varchar2(2),
merchant_id				number(6),
attempt_to_collect		number,
order_id				number,
constraint pk$billing_tran primary key (tran_uid)
using index tablespace index1 
	    storage (initial 2M next 2M pctincrease 0)
)
tablespace data1
storage	(initial 10M next 10M pctincrease 0)
pctfree 20 pctused 75 
;

create index i$btran$box on billing_tran (box_serial_number, box_region) 
tablespace index1 
storage (initial 4M next 2M pctincrease 0)
;

create index i$btran$billing_uid on billing_tran (billing_uid) 
tablespace index1 
storage (initial 4M next 2M pctincrease 0)
;

create index i$btran$billing_date on billing_tran (billing_date) 
tablespace index1 
storage (initial 8M next 4M pctincrease 0)
;
