create table mci_connection_log 
(connection_uid			number(10) not null,
 start_time				date,
 local_time				date,
 area_code				number(3),
 phone_number			number(7),
 dialed_area_code		number(3),
 dialed_phone_number	number(7),
 master					number(1),
 slave					number(1),
 box_serial_number		number(8),
 dialed_box_serial_number		number(8)
)
tablespace tb1
storage (initial 5m next 5m pctincrease 0)
pctfree 0 pctused 80
;

create index i$mci_connlog$first_round on mci_connection_log
									  ( 
									   dialed_area_code, 
									   dialed_phone_number,
									   area_code, 
									   phone_number,
									   start_time,
									   connection_uid)
tablespace tb2
storage (initial 5m next 5m pctincrease 0)
pctfree 0 
;
 
