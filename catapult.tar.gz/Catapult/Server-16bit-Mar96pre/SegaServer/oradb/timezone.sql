rem $Id: timezone.sql,v 1.4 1995/11/07 17:13:08 raja Exp $
rem $Log: timezone.sql,v $
rem Revision 1.4  1995/11/07  17:13:08  raja
rem increased size of city from 7 to 15 characters
rem
rem Revision 1.3  1995/10/30  20:59:14  raja
rem major reorganization of the binlogs database. Out with the old in with
rem the new. This is not a make work project. Truly. I swear. OK whatever
rem
rem Revision 1.2  1995/10/02  23:23:32  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- table used to store an area_code + exchange vs timezone cross reference
-- used in the mci billing programs. Will become obsolete once we start
-- storing box's local time in the binlogs

rem drop table timezone;

create table timezone
(
area_code				number		not null,
exchange  				number		not null,
time_zone 	 			number		not null,
daylight_savings_flag	number		not null,
city               		varchar2(15),
state           		varchar2(2),
constraint pk$timezone primary key (area_code, exchange)
using index tablespace tb2 storage (initial 2m next 1m pctincrease 0)
pctfree 0
)
tablespace tb1
storage (initial 2M next 1M pctincrease 0)
pctfree 0 pctused 80
;
