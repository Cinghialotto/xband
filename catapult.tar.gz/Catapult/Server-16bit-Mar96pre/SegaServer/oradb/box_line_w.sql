rem $Id: box_line_w.sql,v 1.2 1995/12/21 13:47:08 raja Exp $
rem $Log: box_line_w.sql,v $
rem Revision 1.2  1995/12/21  13:47:08  raja
rem fixed storage settings
rem
rem Revision 1.1  1995/11/29  19:52:35  raja
rem data warehouse tables
rem

create table box_line_all_w
(
sdate				date,
plan_code			number(2),
type_code			number(2),
platform_code		number(2),
status_code			number(2),
market_code			number(2),
age_code			number(2),
xbn_code			number(2),
boxes				number(5),
mail_connects		number(7),
game_connects		number(7),
connects			number(7),
collected			number(8,2),
delta_boxes			number(5),
delta_mail_connects	number(7),
delta_game_connects	number(7),
delta_connects		number(7),
delta_collected		number(8,2)
)
tablespace tb1
storage (initial 10M next 5M pctincrease 0)
pctfree 0 pctused 60
;

create index i$box_line_all_w$sdate on box_line_all_w (sdate)
tablespace tb2
storage (initial 5M next 2M pctincrease 0)
pctfree 0 
;

create table box_line_basic_w
(
sdate				date,
plan_code			number(2),
platform_code		number(2),
status_code			number(2),
xbn_code			number(2),
boxes				number(5),
mail_connects		number(7),
game_connects		number(7),
connects			number(7),
collected			number(8,2),
delta_boxes			number(5),
delta_mail_connects	number(7),
delta_game_connects	number(7),
delta_connects		number(7),
delta_collected		number(8,2)
)
tablespace tb1
storage (initial 10M next 5M pctincrease 0)
pctfree 0 pctused 60
;

create index i$box_line_basic_w$sdate on box_line_basic_w (sdate)
tablespace tb2
storage (initial 5M next 2M pctincrease 0)
pctfree 0
;


create table box_line_market_w
(
sdate				date,
plan_code			number(2),
platform_code		number(2),
status_code			number(2),
market_code			number(2),
xbn_code			number(2),
boxes				number(5),
mail_connects		number(7),
game_connects		number(7),
connects			number(7),
collected			number(8,2),
delta_boxes			number(5),
delta_mail_connects	number(7),
delta_game_connects	number(7),
delta_connects		number(7),
delta_collected		number(8,2)
)
tablespace tb1
storage (initial 10M next 5M pctincrease 0)
pctfree 0 pctused 60
;

create index i$box_line_market_w$sdate on box_line_market_w (sdate)
tablespace tb2
storage (initial 5M next 2M pctincrease 0)
pctfree 0
;


create table box_line_type_w
(
sdate				date,
plan_code			number(2),
type_code			number(2),
platform_code		number(2),
status_code			number(2),
xbn_code			number(2),
boxes				number(5),
mail_connects		number(7),
game_connects		number(7),
connects			number(7),
collected			number(8,2),
delta_boxes			number(5),
delta_mail_connects	number(7),
delta_game_connects	number(7),
delta_connects		number(7),
delta_collected		number(8,2)
)
tablespace tb1
storage (initial 10M next 5M pctincrease 0)
pctfree 0 pctused 60
;

create index i$box_line_type_w$sdate on box_line_type_w (sdate)
tablespace tb2
storage (initial 5M next 2M pctincrease 0)
pctfree 0 
;


create table box_line_age_w
(
sdate				date,
plan_code			number(2),
platform_code		number(2),
status_code			number(2),
age_code			number(2),
xbn_code			number(2),
boxes				number(5),
mail_connects		number(7),
game_connects		number(7),
connects			number(7),
collected			number(8,2),
delta_boxes			number(5),
delta_mail_connects	number(7),
delta_game_connects	number(7),
delta_connects		number(7),
delta_collected		number(8,2)
)
tablespace tb1
storage (initial 10M next 5M pctincrease 0)
pctfree 0 pctused 60
;

create index i$box_line_age_w$sdate on box_line_age_w (sdate)
tablespace tb2
storage (initial 5M next 2M pctincrease 0)
pctfree 0 
;



