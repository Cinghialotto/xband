rem $Id: call_tracking.sql,v 1.8 1996/02/19 12:14:08 raja Exp $
rem $Log: call_tracking.sql,v $
rem Revision 1.8  1996/02/19  12:14:08  raja
rem added an index on start_time
rem
rem Revision 1.7  1996/02/03  15:04:34  ckn
rem Problem codes - Action Codes imlementation. Problem code is now of
rem varchar2 datatype.
rem
rem Changed problem_code datatype from 'number' to 'varchar2'
rem Also introduced pctfree/pctused
rem
rem Revision 1.6  1996/01/11  11:07:28  ckn
rem Added caller_name - to keep track of the person calling.
rem
rem Revision 1.5  1996/01/02  16:04:32  raja
rem changes for "escalated" radio button in catadmin
rem
rem Revision 1.4  1995/12/14  10:50:31  ckn
rem BoxSerialnumber/Region added to call_tracking table
rem New view call_phone_list created.
rem
rem Revision 1.3  1995/11/17  14:56:10  ckn
rem Added comments
rem
rem Call Tracking Info.

create table call_tracking ( record_type	number(1),
			     start_time			date,
			     end_time 			date,
			     description		varchar2(2000),
			     problem_code		varchar2(10),
			     hangup_time		date,
			     userid				varchar2(30),
				 box_serial_number 	number(10),
				 box_region 		number(3),
				 escalated			number,
				 caller_name		varchar2(30))
tablespace data1
storage (initial 5M next 2M pctincrease 0)
pctfree 5, pctused 80;

create index i$call_Tracking$time on call_tracking (start_time)
tablespace index1
storage (initial 5M next 5M pctincrease 0);

create index i$call_Tracking$box on call_tracking (box_serial_number, box_region)
tablespace index1
storage (initial 5M next 5M pctincrease 0);

