rem $Id: orders.sql,v 1.4 1995/10/30 20:59:11 raja Exp $
rem $Log: orders.sql,v $
rem Revision 1.4  1995/10/30  20:59:11  raja
rem major reorganization of the binlogs database. Out with the old in with
rem the new. This is not a make work project. Truly. I swear. OK whatever
rem
rem Revision 1.3  1995/10/02  23:23:08  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- orders placed with the xband store
--

create table orders 
(
order_id				number(10),
box_serial_number		number(6),
box_region				number(2),
box_player_no			number(1),
status					number(3),				-- see order status
product_id				number(5),				-- see product
quantity				number(3),
cost					number(7,2),
tax						number(7,2),
sh						number(7,2),
total_amount			number(7,2),
auth_tran_uid			number(10),
completion_code			number(3),				-- see order completion
airbill_number			varchar2(30),
payment_type			number(1),
constraint pk$orders primary key (order_id)
using index tablespace index1
			storage (initial 1M next 1M pctincrease 0)
)
tablespace data1
storage (initial 2M next 1M pctincrease 0)
;


