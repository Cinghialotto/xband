rem $Id: call_queue.sql,v 1.1 1995/11/03 11:27:18 raja Exp $
rem $Log: call_queue.sql,v $
rem Revision 1.1  1995/11/03  11:27:18  raja
rem New tables for the IVR-Operator Matcher
rem

create table call_queue 
(	channel_number	number(4),
	game_phone		varchar2(10),
	extension		number(7),
	waiting_from	date,
	waiting			number(1)
)
tablespace data1
storage (initial 100k next 100k pctincrease 0)
;
