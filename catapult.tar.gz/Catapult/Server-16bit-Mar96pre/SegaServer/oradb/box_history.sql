rem $Id: box_history.sql,v 1.6 1996/02/03 15:04:33 ckn Exp $
rem $Log: box_history.sql,v $
rem Revision 1.6  1996/02/03  15:04:33  ckn
rem Problem codes - Action Codes imlementation. Problem code is now of
rem varchar2 datatype.
rem
rem Changed problem_code datatype from 'number' to 'varchar2'
rem Also introduced pctfree/pctused
rem Changed script to disable primary key and instead create a non-unique
rem index. In fact in production system, there isn't a primary key. A 
rem index exists on the same set of keys.  The script was earlier not 
rem changed to reflect the index.
rem
rem Revision 1.5  1995/10/02  23:22:23  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- big brother himself. This table keeps track of who changed
-- what and when in the box table. I track almost all the
-- fields in box. Very useful for debugging also. really.
-- populated by a trigger on box

create table box_history (
box_serial_number 	number			not null,
box_region 			number			not null,
problem_code 		varchar2(10)	not null,
creation_date 		date			not null,
user_name 			varchar2(20)	not null,
description 		varchar2(2000)
)
tablespace data1
storage (initial 20M next 10M pctincrease 0)
pctfree 5 pctused 90 
;
create index pk$box_history  on 
	box_history (box_serial_number, box_region, creation_date)
tablespace index1
storage (initial 6M next 2M pctincrease 0);
