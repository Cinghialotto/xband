rem $Id: player_log.sql,v 1.5 1995/11/02 10:37:47 raja Exp $
rem $Log: player_log.sql,v $
rem Revision 1.5  1995/11/02  10:37:47  raja
rem final changes to the new xlog schema
rem
rem Revision 1.3  1995/10/11  15:37:31  raja
rem changes for the new binlogs
rem

rem drop table player_log;

create table player_log
(
player_uid			number(8) 	not null,
box_serial_number	number(8) 	not null,
box_player_number	number(1)	not null,
name				varchar2(50),
constraint pk$player_log primary key (player_uid) 
using index tablespace tb2
storage (initial 10M next 10M pctincrease 0)
		pctfree 0
)
tablespace tb1
storage (initial 10M next 10M pctincrease 0)
		pctused 80 pctfree 0
;


create index i$player_log$name on player_log (box_Serial_number,
box_player_number, name)
storage (initial 5M next 5M pctincrease 0)
pctfree 0
;
