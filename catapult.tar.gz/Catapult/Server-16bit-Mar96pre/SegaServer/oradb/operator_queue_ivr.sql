rem $Id: operator_queue_ivr.sql,v 1.2 1995/11/03 11:42:30 raja Exp $
rem $Log: operator_queue_ivr.sql,v $
rem Revision 1.2  1995/11/03  11:42:30  raja
rem minor bugs fixed
rem
rem Revision 1.1  1995/11/03  11:27:21  raja
rem New tables for the IVR-Operator Matcher
rem

create or replace view operator_queue_ivr as 
select * from operator_queue
;
