-- Call_phone_list is a view on lookup table that keeps a list of valid 
-- phone numbers that an operator can enter as his extension number when 
-- he logs unto PCCatadmin.
-- This is used for primarly two reasons
--  a. One that the operator enters a valid extension number - should be one of
--	   the tuples in call_phone_list table.
--  b. No two operators enter the same extension number - is denoted by the
--     'selected' column value. 

create view call_phone_list(call_phone_number, selected)
as select lookup_code, flex_num_1
   from lookup
   where lookup_type = 'PHONE_LIST';

