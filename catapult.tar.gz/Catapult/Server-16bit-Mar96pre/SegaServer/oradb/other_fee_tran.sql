rem $Id: other_fee_tran.sql,v 1.2 1995/10/02 23:23:09 raja Exp $
rem $Log: other_fee_tran.sql,v $
rem Revision 1.2  1995/10/02  23:23:09  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- billing tran like table to stores collections of other fees.
-- currently used for storing setup fee transactions only. Maybe
-- I should get rid of this table now that I have a transaction codes
-- table


create table other_fee_tran
(
tran_uid			number not null,
line_number			number not null,
fee_uid				number not null,
fee_date			date   not null,
fee_amount			number not null,
constraint pk$other_fee_tran primary key (tran_uid, line_number)
using index tablespace index1 
	    storage (initial 2M next 2M pctincrease 0)
)
tablespace data1
storage	(initial 5M next 5M pctincrease 0)
;
