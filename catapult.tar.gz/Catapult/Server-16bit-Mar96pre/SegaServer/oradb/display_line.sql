rem $Id: display_line.sql,v 1.1 1995/11/29 19:42:57 raja Exp $
rem $Log: display_line.sql,v $
rem Revision 1.1  1995/11/29  19:42:57  raja
rem warehouse tables
rem

create table display_line
(sessid		number not null,
 sdate		date,
 stext		varchar2(10),
 num_value1	number,
 num_value2	number,
 num_value3	number,
 num_value4	number,
 num_value5	number,
 num_value6	number,
 num_value7	number
)
tablespace tb1
storage (initial 100K next 100K pctincrease 0)
pctfree 0 pctused 95 
;

create index i$display_line$sessid on display_line (sessid)
tablespace tb2
storage (initial 100K next 100K pctincrease 0)
pctfree 0 
;

  
