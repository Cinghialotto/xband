rem $Id: mci_phone_list.sql,v 1.5 1995/10/02 23:23:02 raja Exp $
rem $Log: mci_phone_list.sql,v $
rem Revision 1.5  1995/10/02  23:23:02  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- our copy of the dial-plan with mci. Only phone numbers listed in 
-- the dial plan can be called over XBN

create table mci_phone_list
(
box_Serial_number		number not null,
box_region			number not null,
phone_number			varchar2(30) not null,
constraint pk$mci_phone_list primary key (box_Serial_number, box_Region,
				          phone_number)
using index	tablespace index1
		storage (initial 6M next 2M pctincrease 0)
)
tablespace data1
storage (initial 6M next 4M pctincrease 0)
pctfree 5 pctused 90 
;

create index i$mci$phone_number on mci_phone_list (phone_number)
tablespace index1
storage (initial 4M next 2M pctincrease 0)
;
