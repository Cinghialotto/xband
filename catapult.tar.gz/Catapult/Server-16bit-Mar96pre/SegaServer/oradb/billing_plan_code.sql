rem $Id: billing_plan_code.sql,v 1.5 1995/11/16 17:59:59 raja Exp $
rem $Log: billing_plan_code.sql,v $
rem Revision 1.5  1995/11/16  17:59:59  raja
rem changes from ECP
rem
rem Revision 1.4  1995/10/02  23:22:18  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- list of billing plan codes.
-- codes 0, 1, 2 are obsolete
-- code 100 is a special code which points to XBN transactions


delete from billing_plan_code;

create or replace view billing_plan_code
as
select 	lookup_code 		billing_plan_code,
		lookup_description 	billing_plan_description,
		flex_char_1 			billing_plan_name
from 	lookup
where	lookup_type = 'BILLING PLAN CODE'
;

insert into lookup (lookup_type, lookup_code, lookup_description, flex_char_1)
values ('BILLING PLAN CODE', 0, '/xband/monthly/regular', 'Old CC');

insert into lookup (lookup_type, lookup_code, lookup_description, flex_char_1)
values ('BILLING PLAN CODE', 1, '/xband/6for5/bulk', 'Old Check');

insert into lookup (lookup_type, lookup_code, lookup_description, flex_char_1)
values ('BILLING PLAN CODE', 2, '/xband/6for5/monthly', 'Old 6for5');

insert into lookup (lookup_type, lookup_code, lookup_description, flex_char_1)
values ('BILLING PLAN CODE', 10, '/xband/unlimitedcredits/monthly', 'CC-Unlimited');

insert into lookup (lookup_type, lookup_code, lookup_description, flex_char_1)
values ('BILLING PLAN CODE', 11, '/xband/50credits/monthly', 'CC-Basic');

insert into lookup (lookup_type, lookup_code, lookup_description, flex_char_1)
values ('BILLING PLAN CODE', 12, '/xband/250credits/unlimitedmonths', 'Check-Basic');

insert into lookup (lookup_type, lookup_code, lookup_description, flex_char_1)
values ('BILLING PLAN CODE', 13, '/xband/unlimitedcredits/5months', 'Check-Unlimited');

insert into lookup (lookup_type, lookup_code, lookup_description, flex_char_1)
values ('BILLING PLAN CODE', 100, 'xband nationwide','XBN');

commit;
