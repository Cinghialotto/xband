rem $Id: lookup.sql,v 1.4 1995/10/23 09:54:51 raja Exp $
rem $Log: lookup.sql,v $
rem Revision 1.4  1995/10/23  09:54:51  raja
rem new xlog schema
rem
rem Revision 1.3  1995/10/02  23:22:59  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem
 
-- this is the table that stores all lookup codes. Every code/description
-- type table is a view on this table


create table lookup
(
lookup_type		varchar2(30) not null,		-- what kind of code is this?
lookup_code		number	     not null,		-- actual code
lookup_description	varchar2(50),			-- description
flex_char_1		varchar2(50),				-- next few fields store additional
flex_char_2		varchar2(50),				-- info depending on the code
flex_char_3		varchar2(50),
flex_num_1		number,
flex_num_2		number,
flex_num_3		number,
constraint pk$lookup primary key (lookup_type, lookup_code)
using 	index tablespace tb2 storage (initial 1M next 1M pctincrease 0)
)
tablespace tb1
storage (initial 2M next 1M pctincrease 0)
pctfree 5 pctused 90 
;

create index i$lookup$flex_char123 on lookup (lookup_type, 
					      flex_char_1,flex_char_2,
					      flex_char_3)
tablespace tb2
storage (initial 100K next 100K pctincrease 0);

create index i$lookup$description on lookup (lookup_type, 
					     lookup_Description)
tablespace tb2
storage (initial 100K next 100K pctincrease 0);

