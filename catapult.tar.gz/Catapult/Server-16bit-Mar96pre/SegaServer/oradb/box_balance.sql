rem $Id: box_balance.sql,v 1.6 1996/01/17 10:36:45 raja Exp $
rem $Log: box_balance.sql,v $
rem Revision 1.6  1996/01/17  10:36:45  raja
rem added fields for the auto-rebilling system
rem
rem Revision 1.5  1995/11/29  09:32:15  ckn
rem ECP Billing - new billing type and transaction codes.
rem Returned billing file - new structure to reflect username and billing_type_code
rem
rem Revision 1.4  1995/10/02  23:22:21  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- how much does this box owe us?

create table box_balance
(
box_serial_number			number not null,
box_region					number not null,
current_balance				number,
current_balance_date		date,
xbn_balance					number,
xbn_balance_date			date,
auth_vendor_code			varchar2(30),
auth_code					varchar2(30),
auth_tran_date				date,
service_auto_rebill_date	date,
service_auto_rebill_n		number,
xbn_auto_rebill_date		date,
xbn_auto_rebill_n			number,
constraint pk$box_balance primary key (box_serial_number, box_region)
using index tablespace index1
	    storage (initial 2M next 2M pctincrease 0)
)
tablespace data1
storage    (initial 5M next 5M pctincrease 0)
pctfree 25 pctused 60
;
