rem New table to take care of the New Problem Codes ie Action Codes.
rem Earlier problem_code was a view on lookup table.
rem
create table problem_code
(problem_code	varchar2(10)	not null,
 description	varchar2(50)	not null,
constraint pk_problem_code primary key (problem_code)
using index tablespace index1 
            storage (initial 250K next 250K pctincrease 0)
)
tablespace data1
storage (initial 1M next 1M pctincrease 0)
pctfree 0 pctused 90 
;
