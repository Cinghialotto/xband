rem $Id: credit_log.sql,v 1.2 1995/11/02 10:37:46 raja Exp $
rem $Log: credit_log.sql,v $
rem Revision 1.2  1995/11/02  10:37:46  raja
rem final changes to the new xlog schema
rem
rem Revision 1.1  1995/10/30  20:59:03  raja
rem major reorganization of the binlogs database. Out with the old in with
rem the new. This is not a make work project. Truly. I swear. OK whatever
rem
rem Revision 1.4  1995/10/23  09:54:45  raja
rem new xlog schema
rem
rem Revision 1.3  1995/10/11  15:37:26  raja
rem changes for the new binlogs
rem
rem Revision 1.2  1995/10/02  23:22:42  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem
 
-- information on why we deducted a credit for a box



rem drop table credit_log;

create table credit_log
(
connection_uid						number(10) not null,
successful_game						number(1),
on_queue							number(1),
evil_reset							number(1),
evil_call_waiting					number(1),
wait_reset							number(1),
mail_only							number(1),
hosed_specific						number(1),
hosed_auto							number(1),
penalize_wait_reset					number(1),
penalize_evil_reset					number(1),
penalize_password_code				number(1),
constraint pk$credit_log primary key (connection_uid)
using index tablespace tb2 storage (initial 20M next 20M pctincrease 0)
pctfree 0 
)
tablespace tb1
storage (initial 20M next 20M pctincrease 0)
pctfree 0 pctused 60
;
