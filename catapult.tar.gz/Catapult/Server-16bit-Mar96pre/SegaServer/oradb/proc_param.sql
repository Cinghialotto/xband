rem $Id: proc_param.sql,v 1.7 1995/11/15 11:16:16 ckn Exp $
rem $Log: proc_param.sql,v $
rem Revision 1.7  1995/11/15  11:16:16  ckn
rem ECP billing - added new transaction codes, ECP billing type, new fields to
rem box table and relative changes to the Db triggers.
rem
rem Revision 1.6  1995/10/02  23:23:20  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- static records used by the billing programs as "persistent memory"
-- stuff like what was the last connection_mci_uid billed and so on
--

delete from proc_param;

create table proc_param
(
proc		varchar2(30),
param		varchar2(30),
char_value	varchar2(30),
num_value	number,
constraint pk$proc_param primary key (proc, param)
using index tablespace index1 
storage (initial 100k next 100k)
)
tablespace data1 
storage (initial 100k next 100k)
pctfree 0 pctused 95 
;

insert into proc_param values ('daily billing', 'last billing uid sent',
			null, 0);

insert into proc_param values ('monthly billing', 'last billing uid sent',
			null, 0);

insert into proc_param values ('pre billing', 'last billing uid sent',
			null, 0);

insert into proc_param values ('xbn billing', 'last billing uid sent',
			null, 0);

insert into proc_param values ('xbn billing', 'last connection-mci estimated',
			null, 0);

insert into proc_param values ('xbn billing', 'last connection-mci billed',
			null, 0);

insert into proc_param values ('setup fee cc unlimited', 'last box billed',
			null, 0);

insert into proc_param values ('setup fee cc credits', 'last box billed',
			null, 0);


insert into proc_param values ('catadmin', 'current version',
			null, 0);

insert into proc_param values ('ecp billing', 'last billing uid sent',
			null, 0);
commit;

