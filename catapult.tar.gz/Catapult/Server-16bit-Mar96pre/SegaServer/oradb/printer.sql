rem $Id: printer.sql,v 1.2 1995/10/02 23:23:18 raja Exp $
rem $Log: printer.sql,v $
rem Revision 1.2  1995/10/02  23:23:18  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- printer names. used by the report printing screens of catadmin

delete from printer;

create or replace view printer
as
select 	lookup_code printer_code,
	lookup_description printer_name,
	flex_char_1 unix_name
from 	lookup
where	lookup_type = 'PRINTER'
;

insert into lookup (lookup_type, lookup_code, lookup_description, flex_char_1)
values ('PRINTER', 0, 'Finishing Move', 'fm');

insert into lookup (lookup_type, lookup_code, lookup_description, flex_char_1)
values ('PRINTER', 1, 'Rhino Writer', 'rhino');

insert into lookup (lookup_type, lookup_code, lookup_description, flex_char_1)
values ('PRINTER', 2, 'Pulp Fiction', 'pf');


commit;

