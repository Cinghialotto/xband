rem $Id: std_icon.sql,v 1.2 1995/10/02 23:23:28 raja Exp $
rem $Log: std_icon.sql,v $
rem Revision 1.2  1995/10/02  23:23:28  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- list of standard icons on the box. not used


delete from std_icon;

create or replace view std_icon
as
select 	lookup_code icon_id,
	lookup_description icon_description
from 	lookup
where	lookup_type = 'STANDARD ICON'
;

insert into lookup (lookup_type, lookup_code, lookup_description)
values
('STANDARD ICON', 0, 'Unknown');

commit;
