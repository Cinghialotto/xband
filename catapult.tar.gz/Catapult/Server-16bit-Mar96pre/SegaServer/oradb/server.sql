rem $Id: server.sql,v 1.2 1995/10/02 23:23:26 raja Exp $
rem $Log: server.sql,v $
rem Revision 1.2  1995/10/02  23:23:26  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- list of servers sunsega runs on


create or replace view server
as
select	lookup_code 		server_uid,
	lookup_description 	server_name,
	flex_char_1		server_address,	 
	flex_char_2		server_description
from 	lookup
where 	lookup_type = 'SERVER CODES'
;
