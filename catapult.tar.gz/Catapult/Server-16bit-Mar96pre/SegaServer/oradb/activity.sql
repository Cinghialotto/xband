rem	$Id: activity.sql,v 1.4 1995/10/02 23:22:13 raja Exp $
rem	$Log: activity.sql,v $
rem Revision 1.4  1995/10/02  23:22:13  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- this view stores activity codes for ordering from the xband store

delete from activity;

create or replace view activity
as
select 	lookup_code activity_code,
		lookup_description activity_description
from 	lookup
where	lookup_type = 'ACTIVITY'
;

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACTIVITY', 0, 'Order acknowledged');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACTIVITY', 1, 'Wrong access code');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACTIVITY', 2, 'Wrong last 4 numbers from cc');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACTIVITY', 3, 'Account is prepaid');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACTIVITY', 4, 'Account is suspended');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACTIVITY', 5, 'Account is suspended');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACTIVITY', 6, 'Junk in customer order');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACTIVITY', 7, 'Manual order from customer support');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACTIVITY', 8, 'Order created');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACTIVITY', 9, 'Order completed');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACTIVITY', 10, 'Order allocated');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACTIVITY', 11, 'Credit authorized');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACTIVITY', 12, 'Sent to Shiper');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACTIVITY', 13, 'Money Deposited');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ACTIVITY', 14, 'Product shipped');

commit;
