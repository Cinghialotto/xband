rem $Id: platform_xlog.sql,v 1.1 1995/10/11 15:37:31 raja Exp $
rem $Log: platform_xlog.sql,v $
rem Revision 1.1  1995/10/11  15:37:31  raja
rem changes for the new binlogs
rem
rem

-- platform codea and descriptions

delete from platform_xlog;

create or replace view platform_xlog
as
select 	lookup_code platform_id,
	 	flex_num_1   platform_uid,
		lookup_description platform_description
from 	lookup
where	lookup_type = 'PLATFORM'
;

insert into lookup (lookup_type, lookup_code, flex_num_1, lookup_description)
values ('PLATFORM', 0, 1936025441, 'SEGA');

insert into lookup (lookup_type, lookup_code, flex_num_1, lookup_description)
values ('PLATFORM', 1, 1936614771, 'SNES');

commit;
