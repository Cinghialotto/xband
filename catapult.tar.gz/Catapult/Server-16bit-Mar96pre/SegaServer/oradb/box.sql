rem $Id: box.sql,v 1.20 1996/02/05 17:50:40 raja Exp $
rem $Log: box.sql,v $
rem Revision 1.20  1996/02/05  17:50:40  raja
rem type fixed
rem
rem Revision 1.19  1996/01/13  15:27:09  ckn
rem problem_code_entered - new field to take of action codes
rem
rem Revision 1.18  1996/01/02  16:07:49  raja
rem Added a column called next_anniversary_date.
rem
rem Revision 1.17  1995/12/21  13:47:33  raja
rem changes for setting pop overrides in catadmin
rem
rem Revision 1.16  1995/11/16  18:15:45  raja
rem fucked up column names in both tables
rem
rem Revision 1.15  1995/11/15  11:16:14  ckn
rem ECP billing - added new transaction codes, ECP billing type, new fields to
rem box table and relative changes to the Db triggers.
rem
rem Revision 1.14  1995/11/08  12:35:42  raja
rem
rem 95/11/14 	ck
rem added active checking_account_number, active_bank_number and
rem active_billing_type_code for ecp billing
rem
rem added  a column acquisition type
rem
rem Revision 1.13  1995/10/03  00:15:43  raja
rem added fields for ecp and xbn cap
rem
rem Revision 1.12  1995/10/02  23:22:20  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

rem 	Box is the key table in the kat table. It stores information
rem		about the box. Most of the information in this table is 
rem		copied from rpc.segad's account.boxAccount, account.userAccount
rem		and UCAAccount structs.


create table box
(
box_serial_number			number(10) 	not null,	-- unique number generated
													-- by the server
box_region					number(3) 	not null,
cs_id						number(10) 	not null,	-- customer service id
account_status_code			number(5) 	not null,	-- see account status table
activation_date				date,
closed_date					date,
first_connect				date,
last_connect				date,
account_flags				number,					-- bit mask. see segad
billing_type_code			number(5),				-- see billing type table
billing_plan_code			number(3),				-- see billing plan table
active_billing_plan_code	number(3),				-- for boxes changing plans
													-- this will be different 
													-- from billing_plan_code
check_received				number(1),				-- used for checking customer
													-- s who send checks early
platform_uid				number(10),				-- see platform table
password					varchar2(8),
hometown_uid				number,					-- see hometown table
game_phone					varchar2(24),
orig_game_phone				varchar2(24),
last_game_phone				varchar2(24),
game_phone_changed			date,
main_pop					varchar2(24),
alt_pop						varchar2(24),
total_server_connects		number(10),
total_client_connects		number(10),
credits_used				number(5),				-- credit counters used in
max_credits					number(5),				-- in billing
start_credits				number(5),
max_free_credits			number(5),
area_restriction			number,					-- XBN/Local/...
weekday_restrict_start		number(4),				-- time restrictions
weekday_restrict_end		number(4),
weekend_restrict_start		number(4),
weekend_restrict_end		number(4),
box_flags					number,					-- bit mask
cs_updated_flags			number,					-- bit mask
time_of_last_play			date,
num_box_crashes				number(5),
last_box_crash				date,
credit_card_num				varchar2(30),
credit_card_expiration		varchar2(10),
access_code					varchar2(50),
product_activate			date,					-- password
home_phone					varchar2(24),
name						varchar2(50),
address						varchar2(100),
city						varchar2(50),
state						varchar2(2),
zip							varchar2(15),
country						varchar2(50),
termination_date			date,
created_date				date,
promo_string				varchar2(18),
do_not_stitch				number(1),				-- internal field used by
													-- the stitcher
last_suspended				date,
last_activated				date,
times_suspended				number(3),
box_history_entered			varchar2(255),			-- internal field used by
													-- catadmin
comments					varchar2(2000),
reactivation_date 			date,					-- date to reactivate
													-- after suspension
xbn_usage_this_month 		number(6),				-- in minutes
xbn_usage_last_month 		number(6),				-- in minutes
xbn_cap 					number(6),				-- in minutes
prenote_sent_date 			date,					-- for ecp
checking_acct_num 			varchar2(30),			
bank_num 					varchar2(30),			-- router number?
acquisition_type			number(5),
active_checking_acct_num 	varchar2(30),			-- active
active_bank_num 			varchar2(30),			-- active
active_billing_type_code	number(5),				-- active
override_ani1				varchar2(24),
override_pop1				varchar2(24),
override_pop2				varchar2(24),
seq_800_connects			number(5),
next_anniversary_date		date,
problem_code_entered		varchar2(10),
constraint pk$box primary key (box_serial_number, box_region) 
using index tablespace index1 
            storage (initial 4M next 2M pctincrease 0)
)
tablespace data1
storage (initial 20M next 10M pctincrease 0)
pctfree 20 pctused 60 
;

create index i$box$cs_id on box (cs_id) 
tablespace index1 
storage (initial 4M next 2M pctincrease 0)
;

create index i$box$name on box (name) 
tablespace index1 
storage (initial 6M next 4M pctincrease 0)
;

create index i$box$game_phone on box (game_phone) 
tablespace index1 
storage (initial 6M next 4M pctincrease 0)
;

create index i$box$home_phone on box (home_phone) 
tablespace index1 
storage (initial 6M next 4M pctincrease 0)
;
