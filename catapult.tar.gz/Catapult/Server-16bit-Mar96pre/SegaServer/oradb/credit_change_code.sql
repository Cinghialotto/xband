rem $Id: credit_change_code.sql,v 1.2 1995/10/02 23:22:41 raja Exp $
rem $Log: credit_change_code.sql,v $
rem Revision 1.2  1995/10/02  23:22:41  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem
 
-- information on why we deducted a credit for a box


delete from credit_change_code;

create or replace view credit_change_code
as
select 	lookup_code credit_change_code,
	lookup_description credit_change_description
from 	lookup
where	lookup_type = 'CREDIT CHANGE'
;

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('CREDIT CHANGE', 0, 'Deduct successful game');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('CREDIT CHANGE', 1, 'Deduct on queue');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('CREDIT CHANGE', 2, 'Deduct evil reset');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('CREDIT CHANGE', 3, 'Deduct evil CW');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('CREDIT CHANGE', 4, 'Deduct wait reset');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('CREDIT CHANGE', 5, 'Deduct mail only');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('CREDIT CHANGE', 6, 'Deduct hosed specific');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('CREDIT CHANGE', 7, 'Deduct hosed auto');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('CREDIT CHANGE', 8, 'Penalize wait reset ');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('CREDIT CHANGE', 9, 'Penalize evil reset');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('CREDIT CHANGE', 10, 'Penalize passwod code');

commit;

