rem $Id: financial_stats.sql,v 1.2 1995/10/02 23:22:50 raja Exp $
rem $Log: financial_stats.sql,v $
rem Revision 1.2  1995/10/02  23:22:50  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem
 
-- first cut at what Phil wants. This table has a long
-- way to go and will probably look nothing like this
-- when I am done.

create table financial_stats
(
summary_date					date not null,
active_cc_sega					number,
active_checking_sega			number,
pending_sega					number,
closed_sega						number,
suspended_sega					number,
new_basic_sega					number,
new_unlimited_sega				number,
suspended_today_sega			number,
closed_today_sega				number,
reactivated_today_sega			number,
xbn_sega						number,
active_cc_snes					number,
active_checking_snes			number,
pending_snes					number,
suspended_snes					number,
closed_snes						number,
new_basic_snes					number,
new_unlimited_snes				number,
suspended_today_snes			number,
closed_today_snes				number,
reactivated_today_snes			number,
xbn_snes						number,
mail_connects_sega					number,
game_connects_sega					number,
matched_games_sega					number,
game_results_sega					number,
successful_games_sega				number,
xbn_games_sega						number,
mail_connects_snes					number,
game_connects_snes					number,
matched_games_snes					number,
game_results_snes					number,
successful_games_snes				number,
xbn_games_sega						number,
amount_collected				number,
amount_due						number,
total_debt						number,
basic_setup_fees				number,
unlimited_setup_fees			number,
basic_service_fees				number,
unlimited_service_fees			number,
extra_credit_fees				number,
xbn_collected					number,
xbn_due							number,
xbn_over_threshold				number,
other_fees						number,
total_check_receipts			number,
total_cc_receipts				number,
number_of_checks				number,
constraint pk$financial_stats primary key (summary_date)
using index tablespace index1 storage (initial 1m next 1m pctincrease 0)
)
tablespace data1
storage (initial 2M next 2M pctincrease 0)
;



