rem $Id: box_view.sql,v 1.1 1995/11/03 11:27:18 raja Exp $
rem $Log: box_view.sql,v $
rem Revision 1.1  1995/11/03  11:27:18  raja
rem New tables for the IVR-Operator Matcher
rem

create or replace view box_view as
select 	box_serial_number,
		nvl(name,'-1') name,
		game_phone,
		access_code,
		get_bit(area_restriction, 5) calling_area,
		get_bit(box_flags, 0) profanity_filter,
		account_status_code,
		get_bit(account_flags, 2) suspend_bit,
		billing_type_code,
		area_restriction,
		box_flags
from box;
