rem $Id: order_completion.sql,v 1.2 1995/10/02 23:23:06 raja Exp $
rem $Log: order_completion.sql,v $
rem Revision 1.2  1995/10/02  23:23:06  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

-- Reasons on why a order was marked completed (closed)

delete from order_completion;

create or replace view order_completion
as
select 	lookup_code completion_code,
		lookup_description completion_description
from 	lookup
where	lookup_type = 'ORDER COMPLETION'
;

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ORDER COMPLETION', 10, 'Shipped');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ORDER COMPLETION', 20, 'Out of stock');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ORDER COMPLETION', 30, 'Manually closed');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ORDER COMPLETION', 40, 'Authorization failed');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ORDER COMPLETION', 50, 'Deposit failed');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('ORDER COMPLETION', 60, 'Duplicate order');

commit;
