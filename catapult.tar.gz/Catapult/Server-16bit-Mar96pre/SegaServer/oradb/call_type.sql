rem	$Id: call_type.sql,v 1.2 1995/10/02 23:22:26 raja Exp $
rem $Log: call_type.sql,v $
rem Revision 1.2  1995/10/02  23:22:26  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem

rem call types. actually carriers. but carrier type was
rem already taken. and I wanted to lessen the confusion


delete from call_type;

create or replace view call_type
as
select 	lookup_code call_type,
	lookup_description call_type_description
from 	lookup
where	lookup_type = 'CALL TYPE'
;

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('CALL TYPE', 0, 'Local');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('CALL TYPE', 1, 'MCI');

insert into lookup (lookup_type, lookup_code, lookup_description)
values ('CALL TYPE', 2, 'Long Dist');

commit;
