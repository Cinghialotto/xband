rem $Id: operator_queue.sql,v 1.1 1995/11/03 11:27:20 raja Exp $
rem $Log: operator_queue.sql,v $
rem Revision 1.1  1995/11/03  11:27:20  raja
rem New tables for the IVR-Operator Matcher
rem

create table operator_queue 
(	extension		number(7),
	game_phone		varchar2(10),
	waiting_from	date,
	waiting			number(1)
)
tablespace data1
storage (initial 100k next 100k pctincrease 0)
;
