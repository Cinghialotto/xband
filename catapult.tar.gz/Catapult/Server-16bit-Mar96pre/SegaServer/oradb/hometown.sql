rem $Id: hometown.sql,v 1.2 1995/10/02 23:22:55 raja Exp $
rem $Log: hometown.sql,v $
rem Revision 1.2  1995/10/02  23:22:55  raja
rem added comments and cvs headers to all sql command files. removed
rem obsolete stuff
rem
 
-- hometowns. populated by catadmin and the stitcher


create or replace view hometown
as
select 	lookup_code hometown_uid,
		lookup_description hometown
from 	lookup
where	lookup_type = 'HOMETOWN'
;

create sequence hometown_uid_seq;

