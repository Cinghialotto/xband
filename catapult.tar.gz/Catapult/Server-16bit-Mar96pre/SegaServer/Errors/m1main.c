#ifndef lint
static char *sccsid = " $Id: m1main.c,v 1.13 1995/09/13 14:08:45 ted Exp $";
#endif /* lint */


/*
	File:		m1main.c

	Contains:	main entry point for ErrorService multiplexer
	
	Guilty:		Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

	$Log: m1main.c,v $
 * Revision 1.13  1995/09/13  14:08:45  ted
 * Fixed warnings.
 *
 * Revision 1.12  1995/05/24  21:21:27  steveb
 * Added support for dotted-decimal inet addresses
 *
 * Revision 1.11  1995/05/11  23:20:41  jhsia
 * switch to rcs keywords
 *

	To Do:
*/
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/file.h>
#include <fcntl.h>
#include <errno.h>
#include <netinet/in.h>
#include <netdb.h>
#include <syslog.h>
#include <string.h>

#include "SegaTypes.h"
#include "ServerDataBase.h"
#include "Common_ReadConf.h"
#include "Server_Log.h"
#include "Common.h"

extern int getopt(int, char * const *, const char *);
extern char *optarg;
extern int opterr;
extern int optind;
int debug = false;

int	client_connect(char *target);

#define kErrSvcPort 	10690
#define kBufSiz 512
char buf[kBufSiz];
char	pidfilename[256];
#define kPidfilename "/var/catapult/m1errormux.pid"

void
Common_Abort(void)
{
	abort();
}

int
daemon_init()
{
	pid_t	pid;

	if ( (pid = fork()) < 0)
		return(-1);
	else if (pid != 0) 
		exit(0);	/* parent goes bye-bye */

	/* child continues */
	setsid();		/* become session leader */

	chdir("/tmp");	/* change working directory */

	umask(0);		/* clear our file mode creation mask */

	return(0);
}

//
// Parse args, init stuff, etc.
//
void
main(int argc, char *argv[])
{
int					c, err, pipeInput, outputD; 
FILE				*fileOutputP;
char				*user;
char				*config_file = NULL, *rangeStart, *cp, *oldCP;
FILE				*tempfile;
BlogFileHeader      fileHeader;
fd_set				set;
FILE				*fp, *pidfile;

	log_open("m1errormux", LOG_PID, LOG_USER);

	opterr = 0;
	while ((c = getopt(argc, argv, "df:")) != EOF) {
		switch (c) {
			case 'd':		/* debug */
				debug = 1;
				break;
			case 'f':
				config_file = optarg;
				continue;
usage:
			default:
				log_err("Unknown option %s\n", argv[0], argv[optind-1]);
				log_err("Usage:\t%s [-f config_file]\n", argv[0], argv[0]);
				exit(2);
			}
		}
	
	strcpy(pidfilename, kPidfilename);
	if (debug == 0)
		daemon_init();

	log_msg("starting up, compiled %s", __DATE__);
	if (config_file == NULL) {
		// Nobody has set config_file yet.  User must want the default.
		config_file = DEFAULT_CONFIG_FILE;
		}

	// Try to make /opt/catapult/conf the current directory.  This is so all
	// our system patches and other goodies will be found there instead of
	// in /var/selector.
	//
	if (err = chdir("/opt/catapult/conf"))
		log_ret("WARNING: not able to chdir to /opt/catapult/conf");

	if (Common_ReadConfigFile("m1errormux", config_file) < 0)
		exit(1);
	
	// bring up the input fifo
	err = mkfifo(gConfig.serverBinaryPipeName, S_IRWXU+S_IRWXG);
	if (err == -1) {
		if (errno != EEXIST) {
			log_ret("Could not create named pipe");
			exit(1);
			}
		}
	umask(0);
	
	// this is opened RDWR so no writers will not give an EOF
	pipeInput = open(gConfig.serverBinaryPipeName, O_RDWR+O_NDELAY);
	if (pipeInput == -1) {
		log_ret("Could not open named pipe");
		exit(1);
	}

	// we only want O_NDELAY to get the thing open without blocking, turn it off now
	c = 0;
	ioctl(pipeInput, FIONBIO, &c);

	pidfile = fopen(pidfilename, "w");
	fprintf(pidfile, "%d\n", getpid());
	fclose(pidfile);

	// make the connection to the master multiplexer
	outputD = client_connect(gConfig.serverBinaryM2Server);
	if (outputD == -1)
		exit(1);

	// descriptors are up, read and write on them forever
	while (1) {
		c = read(pipeInput, buf, kBufSiz);
		if (c == 0) {
			// EOF indication, shouldn't happen
			log_ret("EOF on pipe");
			exit(0);
			}
		if (c == -1) {
			switch (errno) {
				case EWOULDBLOCK:
					// friggin SVR4 won't listen to the ioctl above, so...
			                FD_ZERO(&set);
					FD_SET(pipeInput, &set);
					if ( (c = select(pipeInput + 1, &set, NULL, NULL, NULL)) < 0)
						log_ret("select error");
					c = read(pipeInput, buf, kBufSiz);
					break;
				default:
					log_ret("Could not read, aborting");
					unlink(pidfilename);
					abort();
				}
			}
		
		c = write(outputD, buf, c);
		if (c == -1) {
			switch (errno) {
				case EPIPE:
					// SIGPIPE, probably on sunsega client, ignore it
					break;
				default:
					log_ret("unexpected write error, aborting");
					unlink(pidfilename);
					abort();
					break;
				}
			}
		}
}

int
client_connect(char *target)
{
	struct sockaddr_in addr;
	struct hostent *hostname;
	unsigned long inaddr;
	int sd;
	
	if ( (sd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
		return(-1);
	
	bzero((char *)&addr, sizeof(addr));

	addr.sin_family = AF_INET;
	addr.sin_port = kErrSvcPort;

    /* 
	 * First, check if the host name is in dotted decimal format.  Only
	 * if that fails do we call gethostbyname().
	 */
	if ( (inaddr = inet_addr(target)) != -1 ) {
		bcopy(&inaddr, &addr.sin_addr.s_addr, sizeof(inaddr));
	}
	else {
		hostname = gethostbyname(target);
		if ( !hostname )
			return(-1);
		if ( hostname->h_addrtype != AF_INET )
			return(-1);

		bcopy(hostname->h_addr, &addr.sin_addr.s_addr, hostname->h_length);
	}

	if ( connect(sd, &addr, sizeof(addr)) < 0 )
		return(-1);
	else
		return(sd);
}

