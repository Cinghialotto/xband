/*
 *	Copyright:	@ 1995 Catapult Entertainment Inc., all rights reserved
 *
 */


void log_open(const char *ident, int option, int facility);
void log_msg(const char *fmt, ...);
void log_ret(const char *fmt, ...);
void log_sys(const char *fmt, ...);
void log_err(const char *fmt, ...);
void log_quit(const char *fmt, ...);
