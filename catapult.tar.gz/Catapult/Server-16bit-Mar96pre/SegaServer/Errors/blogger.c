/*
 * Copyright: 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: blogger.c,v 1.6 1995/11/29 21:28:47 chs Exp $
 *
 * $Log: blogger.c,v $
 * Revision 1.6  1995/11/29  21:28:47  chs
 * Quiet a warning.
 *
 * Revision 1.5  1995/09/13  14:08:42  ted
 * Fixed warnings.
 *
 * Revision 1.4  1995/09/06  22:54:39  steveb
 * Added support for writing pid files to the directory specified by the new
 * log_dir server.conf tag.  Added support for communicating on a port specified
 * by the new mux_port server.conf.
 *
 * Revision 1.3  1995/05/24  21:21:26  steveb
 * Added support for dotted-decimal inet addresses
 *
 * Revision 1.2  1995/05/11  23:20:38  jhsia
 * switch to rcs keywords
 *
 *--------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/file.h>
#include <sys/param.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "errorlog.h"
#include "Common.h"
#include "Common_ReadConf.h"
#include "Common_Missing.h"

#define kPidFileName "blogger.pid"

#define kBufSiz     512   /* a binlog can't ever be bigger than this */

static char buf[kBufSiz];
static char pid_file[MAXPATHLEN];
static char *config_file = NULL;

static int daemon_init(void);
static int client_connect(char *);

extern char *optarg;
extern int opterr;
extern int optind;

int debug = 0;

/*--------------------------------------------------------------------------*/

void Common_Abort(void)
{
	unlink(pid_file);
	abort();
}


int main(int argc, char *argv[])
{
	int in, out; 
	fd_set fds;
	int flags;
	FILE *fp;
	char c;
	int n;

	opterr = 0;
	while ( (c = getopt(argc, argv, "df:")) != EOF ) {
		switch (c) {
			case 'd':
				debug = 1;
				break;
			case 'f':
				config_file = optarg;
				continue;
			default:
				fprintf(stderr, "unknown option %s\n", argv[optind-1]);
				fprintf(stderr, "usage: %s [-d] [-f config_file]\n", argv[0]);
				exit(1);
		}
	}
	
	if ( debug == 0 )
		daemon_init();
	umask(0);

	log_open("blogger", LOG_PID, LOG_USER);
	log_msg("starting up, compiled %s", __DATE__);

	if ( config_file == NULL ) {
		/* Nobody has set config_file yet.  User must want the default */
		config_file = DEFAULT_CONFIG_FILE;
	}

	/* 
	 * Try to make /opt/catapult/conf the current directory.  This is so core
	 * dumps will be stuffed there.
	 */
	if ( chdir("/opt/catapult/conf") < 0 )
		log_ret("WARNING: not able to chdir to /opt/catapult/conf");

    /*
	 * Read the server configuration.
	 */
	if ( Common_ReadConfigFile("blogger", config_file) < 0 )
		exit(1);
	
	/* 
	 * Make the connection to the master multiplexer.
	 */
	if ( (out = client_connect(gConfig.serverBinLogMuxServer)) < 0 )
		log_sys("error connecting to blogmuxer");

	/* 
	 * Create the input fifo if it doesn't exist.
	 */
	if ( mkfifo(gConfig.serverBinLogPipeName, 0664) < 0 )
		if (errno != EEXIST)
			log_sys("could not create fifo %s", gConfig.serverBinLogPipeName);
	
	/* 
	 * This is opened RDWR so no writers will not give an EOF.  We use
	 * O_NONBLOCK to get the thing open without blocking, but once it's
	 * open, return it to blocking mode.
	 */
	if ( (in = open(gConfig.serverBinLogPipeName, O_RDWR + O_NONBLOCK)) < 0)
		log_sys("could not open fifo %s", gConfig.serverBinLogPipeName);

	flags = fcntl(in, F_GETFL, 0) & ~O_NONBLOCK;
	fcntl(in, F_SETFL, flags);

    /*
	 * write out our pid for easy kills.
	 */
    strcpy(pid_file, gConfig.logDir);
    strcat(pid_file, "/");
    strcat(pid_file, kPidFileName);
    fp = fopen(pid_file, "w");
    fprintf(fp, "%d\n", getpid());
    fclose(fp);

	/* 
	 * Descriptors are up, spin in a loop copying data from the pipe
	 * to the blogmuxer socket.
	 */
	FD_ZERO(&fds);
	for (;;) {
		FD_SET(in, &fds);

		if ( select(in + 1, &fds, 0, 0, 0) < 0 ) {
			log_ret("select error");
			continue;
		}

		if ( FD_ISSET(in, &fds) ) {
			if ( (n = read(in, buf, kBufSiz)) <= 0) {
				log_ret("read error - exiting");
				unlink(pid_file);
				exit(1);
			}
			else {
				if ( write(out, buf, n) <= 0 ) {
					log_ret("write error - exiting");
					unlink(pid_file);
					exit(1);
				}
			}
		}
	}
	return 0;
}

/*--------------------------------------------------------------------------*/

static int
daemon_init(void)
{
    pid_t   pid;

    if ( (pid = fork()) < 0 )
        return(-1);
    else if ( pid != 0 )
		exit(0);

	setsid();
	chdir("/tmp");
	umask(0);
	return(0);
}

static int
client_connect(char *target)
{
	struct sockaddr_in addr;
	struct hostent *hostname;
	unsigned long inaddr;
	int sd;
	
	if ( (sd = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
		return(-1);
	
	bzero((char *)&addr, sizeof(addr));

	addr.sin_family = AF_INET;
	addr.sin_port = htons(gConfig.serverBinLogMuxPort);

    /* 
	 * First, check if the host name is in dotted decimal format.  Only
	 * if that fails do we call gethostbyname().
	 */
	if ( (inaddr = inet_addr(target)) != -1 ) {
		bcopy(&inaddr, &addr.sin_addr.s_addr, sizeof(inaddr));
	}
	else {
		hostname = gethostbyname(target);
		if ( !hostname )
			return(-1);
		if ( hostname->h_addrtype != AF_INET )
			return(-1);

		bcopy(hostname->h_addr, &addr.sin_addr.s_addr, hostname->h_length);
	}

	if ( connect(sd, (struct sockaddr *)&addr, sizeof(addr)) < 0 )
		return(-1);
	else
		return(sd);
}

