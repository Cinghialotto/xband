/*
 * Copyright: 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: blogmuxer.c,v 1.5 1995/11/29 21:29:04 chs Exp $
 *
 * $Log: blogmuxer.c,v $
 * Revision 1.5  1995/11/29  21:29:04  chs
 * Quiet some warnings.
 *
 * Revision 1.4  1995/09/13  14:08:43  ted
 * Fixed warnings.
 *
 * Revision 1.3  1995/09/06  22:54:41  steveb
 * Added support for writing pid files to the directory specified by the new
 * log_dir server.conf tag.  Added support for communicating on a port specified
 * by the new mux_port server.conf.
 *
 * Revision 1.2  1995/05/11  23:20:39  jhsia
 * switch to rcs keywords
 *
 *--------------------------------------------------------------------------*/
 
#include <errno.h>
#include <fcntl.h>
#include <memory.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <sys/file.h>
#include <sys/param.h>
#include  <netinet/in.h>

#include  "Common_ReadConf.h"
#include  "Server_Log.h"
#include  "errorlog.h"
#include  "Common.h"
#include  "Common_Log.h"
#include  "Common_Missing.h"

#define kPidFileName "blogmuxer.pid"

#define kMaxLine    256   /* max line length */
#define kAlloc      10    /* # client structs to alloc/realloc for */

/* one client struct per connected client */
typedef struct {
  int           fd;         /* fd, or -1 if available */
  char          *record;    /* malloc'd buffer for stream data */
  int           recordSize; /* total size of this blog record */
  int           lastRead;   /* amount we have read so far */
} Client;

static Client *client = NULL;
static int    client_size = 0;
static char   *config_file = NULL;
static char   pid_file[MAXPATHLEN];
static int    reload;
static int    out;
static char   buf[kMaxLine];

static int daemon_init(void);
static void reload_file(int);
static void sighandler(int);
static void loop(int);
static int serv_accept(int);
static void client_alloc(void);
static int client_add(int);
static void client_del(Client *, fd_set *);
static void write_blogrec(Client *);
static void request(Client *, fd_set *);

extern char *optarg;
extern int opterr;
extern int optind;

int debug = 0;

/*--------------------------------------------------------------------------*/

int main(int argc, char *argv[])
{
	struct sockaddr_in addr;
    struct sigaction act;
	FILE *fp;
	int len;
	int ld;
	char c;

	opterr = 0;
	while ( (c = getopt(argc, argv, "df:")) != EOF ) {
		switch (c) {
			case 'd':
				debug = 1;
				break;
			case 'f':
				config_file = optarg;
				break;
			default:
                fprintf(stderr, "unknown option %s\n", argv[optind-1]);
                fprintf(stderr, "usage: %s [-d] [-f config_file]\n", argv[0]);
                exit(1);
		}
	}
	
	if ( debug == 0 )
		daemon_init();
	umask(0);

	log_open("blogmuxer", LOG_PID, LOG_USER);
	log_msg("starting up, compiled %s", __DATE__);

    if ( config_file == NULL ) {
        /* Nobody has set config_file yet.  User must want the default */
        config_file = DEFAULT_CONFIG_FILE;
    }
 
    /*
     * Try to make /opt/catapult/conf the current directory.  This is so core
     * dumps will be stuffed there.
     */
    if ( chdir("/opt/catapult/conf") < 0 )
        log_ret("WARNING: not able to chdir to /opt/catapult/conf");
 
    /*
     * Read the server configuration.
     */
    if ( Common_ReadConfigFile("blogmuxer", config_file) < 0 )
        exit(1);
 
	printf("%s\n", config_file);

	reload_file(0);
	
    act.sa_handler = sighandler;
	act.sa_mask = 0;
	act.sa_flags = 0;
	sigaction(SIGUSR1, &act, NULL);
	
    /* 
	 * Create the listen socket and bind it to the muxer port.
	 * Mark socket as listening and wait for connections.
	 */
	if ( (ld = socket(AF_INET, SOCK_STREAM, 0)) < 0 )
		log_sys("socket error");
	
    memset((char *)&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = INADDR_ANY;
	addr.sin_port = htons(gConfig.serverBinLogMuxPort);

    len = sizeof(addr);
	if ( (bind(ld, (struct sockaddr *) &addr, len)) < 0 )
		log_sys("bind error");

	if ( listen(ld, SOMAXCONN) < 0 )
		log_sys("listen error");

    /*
     * write out our pid for easy kills.
     */
    strcpy(buf, gConfig.logDir);
    strcat(buf, "/");
    strcat(buf, kPidFileName);
    fp = fopen(buf, "w");
    fprintf(fp, "%d\n", getpid());
    fclose(fp);

	loop(ld);
	return 0;
}

/*--------------------------------------------------------------------------*/

void Common_Abort(void)
{
	unlink(kPidFileName);
	abort();
}

static int
daemon_init(void)
{
    pid_t   pid;
 
    if ( (pid = fork()) < 0 )
        return(-1);
    else if ( pid != 0 )
        exit(0);
 
    setsid();
    chdir("/tmp");
    umask(0);
    return(0);
}

static void
reload_file(int alreadyOpen)
{
	BlogFileHeader fileHeader;
	char filename[256];
	char date[32];
	time_t t;
	FILE *fp;

	reload = 0;
	if ( alreadyOpen ) {              
		close(out);

		strcpy(filename, gConfig.serverBinLogMuxFileName);
		t = time(NULL);
		strftime(date, 32, "%m-%d-%y", localtime(&t));
		strcat(filename, date);
		if (rename(gConfig.serverBinLogMuxFileName, filename))
			log_ret("could not rename old file, continuing");
		else
			log_msg("closing old binlog file, renamed to %s", filename);
	}

	out = open(gConfig.serverBinLogMuxFileName, 
		O_WRONLY | O_APPEND | O_CREAT, 0664);

	if ( out < 0 )
		log_quit("could not open master log file: %d", errno);
	
	fp = fdopen(out, "a");
	fseek(fp, 0, SEEK_END);

	/* if this is a new log file, write the file header */
	if (ftell(fp) == 0) {
		log_msg("new binlog: writing header info");
		fileHeader.identifier = kLogConnStartMarker;
		fileHeader.version    = kLogVersionNumber;
		fileHeader.createTime = time(0);

		fwrite(&fileHeader, sizeof(BlogFileHeader), 1, fp);
		//ferror(fp); // no effect!
		fflush(fp);
	}
			
	log_msg("opened binlog file, named %s", gConfig.serverBinLogMuxFileName);
}

static void
sighandler(int signo)
{
	if (signo == SIGUSR1) {
		reload = 1;
	}
	else {
		log_ret("caught signal %d, aborting!", signo);
		unlink(pid_file);
		abort();
	}
}

static void
loop(int ld)
{
	int i, n, maxfd, maxi, clifd;
	fd_set allset;
	fd_set rset;

	FD_ZERO(&allset);
	FD_SET(ld, &allset);
	maxfd = ld;
	maxi = -1;

	for (;;) {
		if (reload) 
			reload_file(1);

		rset = allset;
		if ( (n = select(maxfd + 1, &rset, NULL, NULL, NULL)) < 0 ) {
			if ( errno == EINTR )
				continue;
			else
				log_sys("select error");
		}

		if (FD_ISSET(ld, &rset)) {
			/* accept new client request */
			if ( (clifd = serv_accept(ld)) < 0 )
				log_ret("serv_accept error: %d", clifd);
					
			i = client_add(clifd);
			FD_SET(clifd, &allset);
			if (clifd > maxfd)
				maxfd = clifd;  
			if (i > maxi)
				maxi = i; 
		}

		for (i = 0; i <= maxi; i++) {
			if ( (clifd = client[i].fd) < 0)
				continue;
			if (FD_ISSET(clifd, &rset))
				request(&client[i], &allset);
		}
	}
}

/* Wait for a client connection to arrive, and accept it.
 * We also obtain the client's user ID from the pathname
 * that it must bind before calling us. 
 */
static int
serv_accept(int ld)
{
	struct sockaddr_in addr;
	int len;
	int fd;

	len = sizeof(addr);
	if ( (fd = accept(ld, (struct sockaddr *) &addr, &len)) < 0 )
		return(-1);

	return(fd);
}

static void
client_alloc(void)
{
	int i;

	if ( client == NULL )
		client = (Client *) malloc(kAlloc * sizeof(Client));
	else
		client = (Client *) realloc(client, (client_size + kAlloc) * sizeof(Client));

	if ( client == NULL )
		log_sys("can't alloc for client array");

	/* have to initialize the new entries */
	for ( i = client_size; i < client_size + kAlloc; i++ )
		client[i].fd = -1;

	client_size += kAlloc;
}

static int
client_add(int fd)
{
	int i;

	if ( client == NULL )
		client_alloc();

    while (1) {
		for ( i = 0; i < client_size; i++ ) {
			if (client[i].fd == -1) {
				client[i].fd = fd;
				client[i].recordSize = 0;
				client[i].record = NULL;
				return(i);
			}
		}

		/* client array full, time to realloc for more */
		client_alloc();
	}
}

static void
client_del(Client *clientP, fd_set *allset)
{
	int clifd = clientP->fd;

	clientP->fd = -1;
	clientP->recordSize = 0;
	clientP->record = NULL;

	FD_CLR(clifd, allset);
	close(clifd);
	log_msg("blogger channel closed: fd %d", clifd);
}

static void
write_blogrec(Client *clientP)
{
	if ( write(out, clientP->record, clientP->recordSize) < clientP->recordSize ) {
		log_ret("panic: can't write to output file, aborting");
		abort();
	}
}

/* 
 * This routine could be optimized to use a static allocated buffer
 * and only malloc when the whole buffer could not be read
 */
static void
request(Client *clientP, fd_set *allset)
{
	char tbuf[10];
	int toRead;
	int nread;
	
	if ( !clientP->recordSize ) {
		/* read start token and size from stream */
		if ( (nread = read(clientP->fd, tbuf, 8)) <= 0 ) {
			/* error on client or client has closed connection */
			log_ret("read error on fd %d", clientP->fd);
			client_del(clientP, allset);
			return;
		}
		else if (nread < 8) {
			/* didn't get all of the header.  Block here until we get it */
			while (nread < 8) {
				int nread2;

				if ( (nread2 = read(clientP->fd, &tbuf[nread], 8-nread)) <= 0 )   {
					/* error on client or client has closed conn */
					log_ret("read error on fd %d", clientP->fd);
					client_del(clientP, allset);
					return;
				}

				nread += nread2;
			}
		}

		/* check header for magic, bail on connection if missing */
		if ( *((long *)tbuf) != kLogConnStartMarker ) {
			/* client is crapping on the stream */
			log_ret("framing error on fd %d", clientP->fd);
			client_del(clientP, allset);
			return;
		}
		
		/* extra 8 bytes for the beginning and end cookies */
		clientP->recordSize = *((long *)&tbuf[4]) + 8;
		if ( !(clientP->record = malloc(clientP->recordSize)) ) {
			log_ret("out of memory on client record read, dropping record");
			return;
		}
		
		/* have a buffer for the data, read it in */
		memcpy(clientP->record, tbuf, 8);
		clientP->lastRead = 8;
	}
			
	/* 
	 * We have some remaining from last service of this descriptor
	 * append new data to end, see if we get the full block, then
	 * flush it out
	 */
	toRead = clientP->recordSize - clientP->lastRead;
	
	nread = read(clientP->fd, &clientP->record[clientP->lastRead], toRead);
	if ( nread <= 0) {
		/* error on client or client has closed conn */
		free(clientP->record);
		log_ret("read error on fd %d", clientP->fd);
		client_del(clientP, allset);
		return;
	}
	else if (nread == toRead) {
		write_blogrec(clientP);
		free(clientP->record);
		clientP->record = NULL;
		clientP->recordSize = 0;
	}
	else
		clientP->lastRead += nread;
}

