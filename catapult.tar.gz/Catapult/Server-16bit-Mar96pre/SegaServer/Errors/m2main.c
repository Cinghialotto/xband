#ifndef lint
static char *sccsid = " $Id: m2main.c,v 1.10 1995/09/13 14:08:46 ted Exp $";
#endif /* lint */


/*
	File:		m2main.c

	Contains:	main entry for m2 multiplexor

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

	$Log: m2main.c,v $
 * Revision 1.10  1995/09/13  14:08:46  ted
 * Fixed warnings.
 *
 * Revision 1.9  1995/05/11  23:20:42  jhsia
 * switch to rcs keywords
 *

*/


#include	<sys/types.h>
#include	<sys/stat.h>
#include	<sys/socket.h>
#include	<sys/un.h>
#include	<sys/time.h>
#include	<netinet/in.h>
#include	<stdio.h>
#include	<syslog.h>
#include	<string.h>
#include	<stropts.h>
#include	<fcntl.h>
#include	<stddef.h>
#include	<time.h>
#include	<stdlib.h>
#include	<unistd.h>
#include	<signal.h>
#include	<sys/errno.h>
#include	"Common.h"
#include	"Common_ReadConf.h"
#include	"Server_Log.h"


#define	kMaxLine		4096		// max line length
#define	kAlloc			10			// #Client structs to alloc/realloc for
#define	kStaleTime		30			// client's name can't be older than this (sec)
#define kErrSvcPort 	10690
#define kPidfilename "/var/catapult/m2errormux.pid"

/* one Client struct per connected client */
typedef struct {
  int		fd;				// fd, or -1 if available
  char		*record;		// malloc'd buffer for stream data
  int		recordSize;		// total size of this blog record
  int		lastRead;		// amount we have read so far
} Client;


// extern prototypes
extern int getopt(int, char * const *, const char *);
extern char *optarg;
extern int opterr;
extern int optind;
extern void bzero(char *, int);
extern int select (int, fd_set *, fd_set *, fd_set *, struct timeval *);
extern char *strerror(int);
extern int accept(int, struct sockaddr *, int *);
extern time_t time(time_t *);
extern int socket(int, int, int);
extern char *memset(char *, int, int);
extern int bind(int, struct sockaddr *, int);
extern int listen(int, int);

// define global variables 
int		debug;
char	errmsg[kMaxLine];
int		oflag;
char	*pathname;
Client	*client = NULL;
int		client_size;
int		gOutputFile;
extern int errno;
Boolean	gDoReload;
char	pidfilename[256];

void
Common_Abort(void)
{
	abort();
}

int
daemon_init()
{
	pid_t	pid;

	if ( (pid = fork()) < 0)
		return(-1);
	else if (pid != 0) 
		exit(0);	/* parent goes bye-bye */

	/* child continues */
	setsid();		/* become session leader */

	chdir("/tmp");	/* change working directory */

	umask(0);		/* clear our file mode creation mask */

	return(0);
}

/* Wait for a client connection to arrive, and accept it.
 * We also obtain the client's user ID from the pathname
 * that it must bind before calling us. */

int			/* returns new fd if all OK, <0 on error */
serv_accept(int listenfd)
{
	int					clifd, len;
	struct sockaddr_in	inet_addr;

	len = sizeof(inet_addr);
	if ( (clifd = accept(listenfd, (struct sockaddr *) &inet_addr, &len)) < 0)
		return(-1);		/* often errno=EINTR, if signal caught */

	return(clifd);
}


static void
client_alloc(void)		/* alloc more entries in the client[] array */
{
	int		i;

	if (client == NULL)
		client = (Client *)malloc(kAlloc * sizeof(Client));
	else
		client = (Client *)realloc(client, (client_size + kAlloc) * sizeof(Client));
	if (client == NULL)
		log_sys("can't alloc for client array");

			/* have to initialize the new entries */
	for (i = client_size; i < client_size + kAlloc; i++) {
		client[i].fd = -1;	/* fd of -1 means entry available */
		}

	client_size += kAlloc;
}
/* Called by loop() when connection request from a new client arrives */

int
client_add(int fd)
{
	int		i;

	if (client == NULL)		/* first time we're called */
		client_alloc();
again:
	for (i = 0; i < client_size; i++) {
		if (client[i].fd == -1) {	/* find an available entry */
			client[i].fd = fd;
			client[i].recordSize = 0;
			client[i].record = NULL;
			return(i);	/* return index in client[] array */
		}
	}
			/* client array full, time to realloc for more */
	client_alloc();
	goto again;		/* and search again (will work this time) */
}

/* Called by loop() when we're done with a client */

void
client_del(Client *clientP, fd_set *allset)
{
	int clifd = clientP->fd;
	clientP->fd = -1;
	clientP->recordSize = 0;
	clientP->record = NULL;

	FD_CLR(clifd, allset);
	close(clifd);
	log_msg("m1 channel closed: fd %d", clifd);
}

// if we want to do something tricky with multiple files over major and minor revisions,
// do it here.
void
writeBlogRec(Client *clientP)
{
	if (write(gOutputFile, clientP->record, clientP->recordSize) < clientP->recordSize) {
		log_ret("panic: can't write to output file, aborting");
		abort();
		}
}

// this routine could be optimized to use a static allocated buffer
// and only malloc when the whole buffer could not be read
void
request(Client *clientP, fd_set *allset)
{
	char			buf[10];
	int				nread, toRead;
	BlogLoginInfo	*blogRec;
	
	if (!clientP->recordSize) {	
		/* read start token and size from stream */
		if ( (nread = read(clientP->fd, buf, 6)) <= 0) {
			/* error on client or client has closed conn */
			log_ret("read error on fd %d", clientP->fd);
			client_del(clientP, allset);
			return;
			}
		else if (nread < 6) {
			// didn't get all of the header.  Block here until we get it.
			while (nread < 6) {
				int nread2;
				if ( (nread2 = read(clientP->fd, &buf[nread], 6-nread)) <= 0)	{
					/* error on client or client has closed conn */
					log_ret("read error on fd %d", clientP->fd);
					client_del(clientP, allset);
					return;
					}
				nread += nread2;
				}
			}
				
		// check header for magic, bail on connection if missing
		if (*((long *)buf) != kLogConnStartMarker) {
			// client is crapping on the stream
			log_ret("framing error on fd %d", clientP->fd);
			client_del(clientP, allset);
			return;
			}
		
		// extra 8 bytes for the beginning and end cookies
		clientP->recordSize = *((short *)&buf[4]) + 8;
		if (!(clientP->record = malloc(clientP->recordSize))) {
			// this is a pretty severe error, I doubt it will ever happen.  If it does,
			// there needs to be a way to cache the records we dumped.
			log_ret("Out of memory on client record read, dropping binlog record: size %d, fd %d",
				clientP->recordSize, clientP->fd);
			client_del(clientP, allset);
			return;
			}
		
		// have a buffer for the data, read it in
		memcpy(clientP->record, buf, 6);
		clientP->lastRead = 6;
		}
		
	// we have some remaining from last service of this descriptor
	// append new data to end, see if we get the full block, then
	// flush it out
	toRead = clientP->recordSize - clientP->lastRead;
	
	if ( (nread = read(clientP->fd, &clientP->record[clientP->lastRead], toRead)) <= 0) {
		/* error on client or client has closed conn */
		free(clientP->record);
		log_ret("read error on fd %d", clientP->fd);
		client_del(clientP, allset);
		return;
		}
	if (nread == toRead) {
		writeBlogRec(clientP);
		free(clientP->record);
		clientP->record = NULL;
		clientP->recordSize = 0;
		}
	else
		clientP->lastRead += nread;
}

void
reloadFile(Boolean alreadyOpen)
{
	int		c;
	FILE	*fp;
    BlogFileHeader	fileHeader;
	char	filename[256], date[32];
	time_t	t;

	gDoReload = false;
 	if (alreadyOpen) {		
		close(gOutputFile);
		strcpy(filename, gConfig.serverBinaryM2LogName);
		t = time(NULL);
		strftime(date, 32, "%m-%d-%y", localtime(&t));
		strcat(filename, date);
		if (rename(gConfig.serverBinaryM2LogName, filename))
			log_ret("could not rename old file, continuing");
		else
			log_msg("closing old binlog file, renamed to %s", filename);
		}
		
	if ((gOutputFile = open(gConfig.serverBinaryM2LogName, O_WRONLY|O_APPEND|O_CREAT, 0644)) < 0)
		log_quit("Could not open master log file: %d\n", errno);
	
	fp = fdopen(gOutputFile, "a");
	
    // seek to the end of the file
    c = fseek(fp, 0, 2);

    // if this is a new log file, write the file header.
    if (ftell(fp) == 0) {
		log_msg("New binlog: writing header info\n");
		fileHeader.identifier = kLogConnStartMarker;
		fileHeader.version    = kLogVersionNumber;
		fileHeader.createTime = time(0);
		c = fwrite(&fileHeader, sizeof(BlogFileHeader), 1, fp);
		c = ferror(fp);
		c = fflush(fp);
		}
		
	log_msg("opened binlog file, named %s\n", gConfig.serverBinaryM2LogName);
}

void
loop(int listenfd)
{
	int		i, n, maxfd, maxi, clifd, nread;
	char	buf[kMaxLine];
	fd_set	rset, allset;

	FD_ZERO(&allset);

	FD_SET(listenfd, &allset);
	maxfd = listenfd;
	maxi = -1;

	for ( ; ; ) {
loop:
		if (gDoReload) 
			reloadFile(true);

		rset = allset;		/* rset gets modified each time around */
		if ( (n = select(maxfd + 1, &rset, NULL, NULL, NULL)) < 0) {
			if (errno == EINTR)
				goto loop;
			else
				log_sys("select error");
			}

		if (FD_ISSET(listenfd, &rset)) {
					/* accept new client request */
			if ( (clifd = serv_accept(listenfd)) < 0)
				log_ret("serv_accept error: %d", clifd);
				
			i = client_add(clifd);
			FD_SET(clifd, &allset);
			if (clifd > maxfd)
				maxfd = clifd;	/* max fd for select() */
			if (i > maxi)
				maxi = i;		/* max index in client[] array */
			log_msg("new connection: fd %d", clifd);
			continue;
		}

		for (i = 0; i <= maxi; i++) {	/* go through client[] array */
			if ( (clifd = client[i].fd) < 0)
				continue;
			if (FD_ISSET(clifd, &rset)) {
				request(&client[i], &allset);
			}
		}
	}
}

static void
sighandler(int signo)
{
	if (signo == SIGUSR1) {
		signal(SIGUSR1, sighandler);
		gDoReload = true;
		}
	else {
		log_ret("caught signal %d, aborting!", signo);
		unlink(pidfilename);
		abort();
		}
}

int
main(int argc, char *argv[])
{
	int		c, listenfd;
	char	*config_file = NULL, *cp, *oldCP;
	FILE	*fp;
	/* obtain fd to listen for client requests on */
	struct sockaddr_in	inet_addr;

	log_open("m2errormux", LOG_PID, LOG_USER);

	opterr = 0;		/* don't want getopt() writing to stderr */
	while ( (c = getopt(argc, argv, "df:")) != EOF) {
		switch (c) {
		case 'd':		/* debug */
			debug = 1;
			break;
		case 'f':
			config_file = optarg;
			break;
		case '?':
			log_quit("unrecognized option: -%c\n", *optarg);
		default:
			exit(1);
		}
	}
	
	strcpy(pidfilename, kPidfilename);
	if (debug == 0)
		daemon_init();

	if (config_file == NULL) {
		// Nobody has set config_file yet.  User must want the default.
		config_file = DEFAULT_CONFIG_FILE;
		}

	// Try to make /opt/catapult/conf the current directory.  This is so all
	// our system patches and other goodies will be found there instead of
	// in /var/selector.
	//
	if (chdir("/opt/catapult/conf"))
		log_ret("WARNING: not able to chdir to /opt/catapult/conf");

	if (Common_ReadConfigFile("m2errormux", config_file) < 0)
		exit(1);
			
	log_msg("starting up, compiled %s", __DATE__);
	reloadFile(false);
//	kill(getpid(), 17);
	
	if (signal(SIGUSR1, sighandler) == SIG_ERR) {
		log_ret("Couldn't catch SIGUSR1, aborting.");
		abort();
		}
	
	// create a Unix domain stream socket
	if ( (listenfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		log_sys("serv_listen error");
	
	// set up the address
	bzero((char *)&inet_addr, sizeof(inet_addr));
	inet_addr.sin_family = AF_INET;
	inet_addr.sin_port = kErrSvcPort;
	inet_addr.sin_addr.s_addr = INADDR_ANY;

	// bind the name to the descriptor
	if (bind(listenfd, (struct sockaddr *) &inet_addr, sizeof(struct sockaddr_in)) < 0)
		log_sys("serv_listen error");

	if (listen(listenfd, 5) < 0)	/* tell kernel we're a server */
		log_sys("serv_listen error");

	/* don't do the pidfile until we are sure we could get the socket */
	fp = fopen(pidfilename, "w");
	if (fp != NULL) {
		fprintf(fp, "%d\n", getpid());
		(void) fclose(fp);
		}

	loop(listenfd);		/* never returns */
	return(0);
}
