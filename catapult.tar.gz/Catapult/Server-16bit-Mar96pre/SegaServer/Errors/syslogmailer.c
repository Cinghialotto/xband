#ifndef lint
static char *sccsid = "$Id: syslogmailer.c,v 1.3 1995/09/13 14:08:47 ted Exp $";
#endif /* lint */


/*
	File:		syslogmailer.c

	Contains:	takes feed from unix domain pipe, sends it in email
	
	Guilty:		Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

	$Log: syslogmailer.c,v $
 * Revision 1.3  1995/09/13  14:08:47  ted
 * Fixed warnings.
 *
 * Revision 1.2  1995/05/11  23:20:43  jhsia
 * switch to rcs keywords
 *

	To Do:
*/
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/fcntl.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>
#include <netinet/in.h>
#include <netdb.h>
#include <syslog.h>
#include <string.h>

#include "SegaTypes.h"
#include "ServerDataBase.h"
#include "Common_ReadConf.h"
#include "Server_Log.h"
#include "Common.h"

extern int getopt(int, char * const *, const char *);
extern char *optarg;
extern int opterr;
extern int optind;
int debug = false;

int	client_connect(char *target);

#define kErrSvcPort 	10690
#define kBufSiz 512
char buf[kBufSiz];
char	pidfilename[256];
#define kPidfilename "/var/catapult/syslogmailer.pid"
#define kPipeName "/var/catapult/syslogmailpipe"


void
Common_Abort(void)
{
	abort();
}

int
daemon_init(char *pidfilename)
{
	pid_t	pid;

	if ( (pid = fork()) < 0)
		return(-1);
	else if (pid != 0) {
		FILE *fp = fopen(pidfilename, "w");
		fprintf(fp, "%d\n", pid);
		fclose(fp);
		exit(0);	/* parent goes bye-bye */
		}

	/* child continues */
	setsid();		/* become session leader */

	chdir("/tmp");	/* change working directory */

	umask(0);		/* clear our file mode creation mask */

	return(0);
}

//
// Parse args, init stuff, etc.
//
void
main(int argc, char *argv[])
{
int					c, count, err, pipeInput, outputD; 
FILE				*fileOutputP;
char				*user, commandline[80];
char				*config_file = NULL, *rangeStart, *cp, *oldCP;
FILE				*tempfile;
BlogFileHeader      fileHeader;
fd_set				set;
FILE				*fp;

	log_open("syslogmailer", LOG_PID, LOG_USER);

	opterr = 0;
	while ((c = getopt(argc, argv, "df:")) != EOF) {
		switch (c) {
			case 'd':		/* debug */
				debug = 1;
				break;
			case 'f':
				config_file = optarg;
				continue;
usage:
			default:
				log_err("Unknown option %s\n", argv[0], argv[optind-1]);
				log_err("Usage:\t%s [-f config_file]\n", argv[0], argv[0]);
				exit(2);
			}
		}
	
	strcpy(pidfilename, kPidfilename);
	if (debug == 0)
		daemon_init(pidfilename);
	else {
                FILE *fp = fopen(pidfilename, "w");
                fprintf(fp, "%d\n", getpid());
                fclose(fp);
		}


	log_msg("starting up, compiled %s", __DATE__);
	
	// bring up the input fifo
	err = mkfifo(kPipeName, S_IRWXU+S_IRWXG);
	if ((err == -1) && (errno != EEXIST)) {
		log_ret("Could not create named pipe");
		exit(1);
		}
	umask(c);
	
	// this is opened RDWR so no writers will not give an EOF
	pipeInput = open(kPipeName, O_RDWR+O_NDELAY);
	if (pipeInput == -1) {
		log_ret("Could not open named pipe");
		exit(1);
		}

	// we only want O_NDELAY to get the thing open without blocking, turn it off now
	c = 0;
	ioctl(pipeInput, FIONBIO, &c);
	
	fp = fdopen(pipeInput, "r");

	// descriptors are up, read and write on them forever
	count = 0;
	while (1) {
		c = read(pipeInput, &buf[count], kBufSiz - count);
		if (c == 0) {
			// EOF indication, shouldn't happen
			log_ret("EOF on pipe");
			exit(0);
			}
		if (c == -1) {
			switch (errno) {
				case EWOULDBLOCK:
					// friggin SVR4 won't listen to the ioctl above, so...
			                FD_ZERO(&set);
					FD_SET(pipeInput, &set);
					if ( (c = select(pipeInput + 1, &set, NULL, NULL, NULL)) < 0)
						log_ret("select error");
					c = read(pipeInput, &buf[count], kBufSiz - count);
					break;
				default:
					log_ret("Could not read, aborting");
					unlink(pidfilename);
					abort();
				}
			}
		
		count += c;
		if (!(cp = strchr(buf, '\n')))
			continue;
		
		*cp++ = 0;
		if (fp = popen("/bin/mail sysloguser", "w")) {
			fprintf(fp, "From: syslog\nTo: sysloguser\nSubject: %s\n\n", buf);
			pclose(fp);
			}

		if (cp != &buf[count]) {
			count = &buf[count]-cp;
			memcpy(buf, cp, count);
			}
		else
			count = 0;
		}
}


