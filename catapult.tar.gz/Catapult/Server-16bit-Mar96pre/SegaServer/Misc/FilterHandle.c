/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: FilterHandle.c,v 1.3 1995/09/13 14:10:22 ted Exp $
 *
 * $Log: FilterHandle.c,v $
 * Revision 1.3  1995/09/13  14:10:22  ted
 * Fixed warnings.
 *
 * Revision 1.2  1995/05/26  23:20:07  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		FilterHandle.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		 <4>	10/17/94	DJ		fixing stuff
		 <3>	 9/27/94	DJ		moved some #defines into FilterHandle.h
		 <2>	 9/27/94	DJ		.h files
		 <1>	 9/27/94	DJ		first checked in

	To Do:
*/



#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "Server.h"

#include "FilterHandle.h"
#include "Common_Missing.h"


#define MAX_LINE_LENGTH		256


typedef struct WordList
{
	char 				*word;
	struct WordList 	*next;
	Boolean 			matchWholeWord;
	Boolean				contractions;
	Boolean				ignoreWhitespace;
	Boolean				ignoreDelimiters;
	Boolean				caseSensitive;
	Boolean				entireLine;
} WordList;

static WordList 	*gReservedWords = NULL, *gObsceneWords = NULL;


Boolean FilterWords(char *text, WordList *wordList, char *replace);
WordList *LoadWords(FILE *fp);

Err LoadFilterFile(void)
{
	FILE 		*fp, *fp2;


	gReservedWords = gObsceneWords = NULL;

	if ((fp = fopen(kReservedWordsFile, "rb")) == NULL) {
		Logmsg("There is no reserved words file '%s'\n", kReservedWordsFile);
	}
	else
	{
		gReservedWords = LoadWords(fp);
		fclose(fp);
	}
	
	if ((fp2 = fopen(kObsceneWordsFile, "rb")) == NULL) {
		Logmsg("There is no obscene words file '%s'\n", kObsceneWordsFile);
	}
	else
	{
		gObsceneWords = LoadWords(fp2);
		fclose(fp2);
	}
	
	if(!fp && !fp2)
		return( kNoFileLoaded );
	
	return(kNoError);
}


		
WordList *LoadWords(FILE *fp)
{
	WordList	*wordList, *word;
	char		linebuf[MAX_LINE_LENGTH];
	char 		*cp;
	
	ASSERT(fp);
	if(!fp)
		return(NULL);

	wordList = word = NULL;

	while (1) {

		fgets(linebuf, MAX_LINE_LENGTH, fp);

		if (feof(fp) || ferror(fp))
			break;

		if (linebuf[strlen(linebuf)-1] == '\n')
			linebuf[strlen(linebuf)-1] = '\0';
		if (linebuf[0] == '\0' || linebuf[0] == '#')
			continue;



		if ((cp = strtok(linebuf, WHITESPACE)) == NULL)
			continue;

		word = (WordList *)calloc(1, sizeof(WordList));
		ASSERT(word);
		if(!word)
			return( NULL );


		word->word = malloc(strlen(cp)+1);
		strcpy(word->word, cp);

		word->matchWholeWord = false;
		word->caseSensitive = true;
		word->ignoreDelimiters = false;
		word->ignoreWhitespace = false;
		word->entireLine = false;
		while((cp = strtok(NULL, WHITESPACE)))
		{
			// control token is 'word' to match by word (ie. 'fuck' matches, 'fuck.' doesn't.)
			//
			if(!strcmp(cp, kMatchWholeWord))
				word->matchWholeWord = true;
			else
			// control token is 'contractions' to enable match on 'fucking'.
			if(!strcmp(cp, kContractions))
				word->contractions = true;
			else
			// control token is 'case' to enable case sensitive, so 'fuck' doesn't match 'FuCk'.
			if(!strcmp(cp, kNotCaseSensitive))
				word->caseSensitive = false;
			else
			if(!strcmp(cp, kabideDelimiters))
				word->ignoreDelimiters = true;
			else
			if(!strcmp(cp, kabideWhitespace))
				word->ignoreWhitespace = true;
			else
			if(!strcmp(cp, kEntireLine))
				word->entireLine = true;
			else
				Logmsg("Bogus control word '%s' in filter file.\n", cp);
		}

		word->next = wordList;
		wordList = word;


	}
	
	fclose(fp);

	return(wordList);
}



Err FilterTextObscene(char *text)
{
Err err;

	err = 0;
	if(gObsceneWords)
		if(FilterWords(text, gObsceneWords, kObsceneFiller))
			err = kTextHadObscenity;
			
	return(err);
}

Err FilterTextReserved(char *text)
{
Err err;

	err = 0;
	if(gReservedWords)
		if(FilterWords(text, gReservedWords, kReservedFiller))
			err = kTextWasReserved;	
			
	return(err);
}

Boolean FilterWords(char *text, WordList *wordList, char *replace)
{
char 			*cp;
WordList 		*word;
unsigned long	i;
Boolean 		filtered = false;
char			linebuf[MAX_LINE_LENGTH];

	for(word = wordList; word; word = word->next)
	{
		if(word->entireLine)
		{
			if(!strcmpIgnoreWDC(text, word->word, word->ignoreWhitespace, word->ignoreDelimiters, word->caseSensitive))
			{
				strcpyIgnoreWD(text, word->word, replace, word->ignoreWhitespace, word->ignoreDelimiters);
				filtered = true;
			}
		}
		else
		if(word->matchWholeWord)
		{
			strncpy(linebuf, text, MAX_LINE_LENGTH);
			linebuf[MAX_LINE_LENGTH - 1] = 0;
		
			// needs strtokWDC()
			//
			cp = strtok(linebuf, WHITESPACE);
			while(cp)
			{
				if(!strcmpIgnoreWDC(cp, word->word, false, word->ignoreDelimiters, word->caseSensitive))
				{
					i = (unsigned long)(cp - linebuf);
					strncpy(&text[i], replace, strlen(cp));
					filtered = true;
				}
			
				cp = strtok(NULL, WHITESPACE);
			}
		}
		else
		{
		//  this thing ignores caps and whitespace and delimiters.
		//
			while((cp = strstrIgnoreWDC(text, word->word, word->ignoreWhitespace, word->ignoreDelimiters, word->caseSensitive)))
			{
				strcpyIgnoreWD(cp, word->word, replace, word->ignoreWhitespace, word->ignoreDelimiters);
				filtered = true;
			}

		}
	}
	
	return(filtered);
}


void RemoveDelimitersFromText(char *text)
{
	char *p, *s, *t;
	
	for(p = s = text; *p; p++)
	{
		for(t = DELIMITERS; *t; t++)
			if(*p == *t)
				break;
		if(*t == 0)
			*s++ = *p;
	}
	*s = 0;
}

void RemoveWhitespaceFromText(char *text)
{
	char *p, *s, *t;
	
	for(p = s = text; *p; p++)
	{
		for(t = WHITESPACE; *t; t++)
			if(*p == *t)
				break;
		if(*t == 0)
			*s++ = *p;
	}
	*s = 0;
}


void CapitalizeText(char *text)
{
	char *s;

	for(s = text; *s; s++)
		if(*s >= 'a' && *s <= 'z')
			*s = *s - 'a' + 'A';
}




