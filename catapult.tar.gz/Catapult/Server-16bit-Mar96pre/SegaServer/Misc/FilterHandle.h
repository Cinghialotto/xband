/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: FilterHandle.h,v 1.3 1996/02/21 12:11:56 fadden Exp $
 *
 * $Log: FilterHandle.h,v $
 * Revision 1.3  1996/02/21  12:11:56  fadden
 * Changed kReservedFilter so that filtering "xbandxbandxband" doesn't cause
 * the SNES to explode.
 *
 * Revision 1.2  1995/05/26  23:20:07  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		FilterHandle.h

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		 <4>	10/22/94	ATM		Added ":" to ILLEGALCHARS.
		 <3>	10/17/94	DJ		fixing stuff
		 <2>	 9/27/94	DJ		no '@' in kObsceneFiller
		 <1>	 9/27/94	DJ		first checked in

	To Do:
*/


#ifndef FilterHandle_h
#define FilterHandle_h

#define kNoFileLoaded		-1
#define kTextHadObscenity	0x1	/* naughty words */
#define kTextWasReserved	0x2	/* reserved word */

Err LoadFilterFile(void);
Err FilterTextObscene(char *text);
Err FilterTextReserved(char *text);



#define WHITESPACE			" \t\n\r"
#define DELIMITERS			".,-=_+!@#$%^&*()\\/<>~:;|[]{}"
#define ILLEGALCHARS		"@:"					/* illegal in a handle */


//
// These are what we replace reserved words and obscene words with.
//
#define kReservedFiller	"****!****!****!****!****!****!****!****!****!****!****!****!****!****!*"
#define kObsceneFiller	"!!!*^%!-!!(*#)%*&!&^#!*&(%!!!*&%%!&#(*!#(*#)(##!*#(%()%*!*#(*(%#!!"



void RemoveDelimitersFromText(char *text);
void CapitalizeText(char *text);
void RemoveWhitespaceFromText(char *text);

Boolean IsCharOfType(char c, char *tokens);
Boolean CompareAndIgnoreCaps(unsigned char c, unsigned char d);


#define kReservedWordsFile 	"ReservedWords.filter"
#define kObsceneWordsFile 	"ObsceneWords.filter"

#define kMatchWholeWord		"word"				/* match by word. */
#define kContractions		"contractions"		/* match if contraction (fuck-ing). */ /* NOT IMPLEMENTED 10/17/94 */
#define kNotCaseSensitive	"nocase"			/* don't be case-sensitive. */
#define kabideDelimiters	"delimiters"		/* ignore delimiters like '!@#%^&^*($)' */
#define kabideWhitespace	"whitespace"		/* ignore whitespace */
#define kEntireLine			"entire"			/* match the whole line, not word by word */
//
// Format of files is each line has a string.
// eg.
// fuck
// shit
//
// If you want to screen that string by word (must be separated by
// whitespace or be alone), add the string "word" after it.
// eg.
// xband word
// you can force case sensitivity with the keyword 'case'
// Jevans word case
//
//
// match by 'word' forces whitespace to be obeyed.
// 

/***** string utils *********/

char *strstrIgnoreWDC(char *text, char *word, Boolean ignoreWhitespace, Boolean ignoreDelimiters, Boolean caseSensitive);
void strcpyIgnoreWD(char *dest, char *src, char *replace, Boolean ignoreWhitespace, Boolean ignoreDelimiters);
char *strtokIgnoreC(char *text, char *tokens, Boolean caseSensitive);
long strcmpIgnoreWDC(char *text, char *word, Boolean ignoreWhitespace, Boolean ignoreDelimiters, Boolean caseSensitive);
Boolean filterString(char *text, char *tokens, char *replace);

#endif FilterHandle_h

