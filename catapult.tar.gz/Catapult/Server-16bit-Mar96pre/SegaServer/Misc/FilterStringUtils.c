/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: FilterStringUtils.c,v 1.3 1995/09/13 14:10:23 ted Exp $
 *
 * $Log: FilterStringUtils.c,v $
 * Revision 1.3  1995/09/13  14:10:23  ted
 * Fixed warnings.
 *
 * Revision 1.2  1995/05/26  23:20:08  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		FilterStringUtils.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		 <3>	10/17/94	DJ		fixing stuff
		 <2>	 9/27/94	DJ		.h files
		 <1>	 9/27/94	DJ		first checked in

	To Do:
*/



#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "Server.h"
#include "FilterHandle.h"

Boolean CompareAndIgnoreCaps(unsigned char c, unsigned char d)
{
	if(c >= 'a' && c <= 'z')
		c = (c - 'a') + 'A';

	if(d >= 'a' && d <= 'z')
		d = (d - 'a') + 'A';

	if(c == d)
		return( true );
	
	return(false);
}
	
	
Boolean IsCharOfType(char c, char *tokens)
{
char *p;
	
	for(p = tokens; *p; p++)
		if(c == *p)
			return( true );
	
	return(false);
}


//
// replace string must be as long as text.  total cheese.
//

// need to filter illegal chars like '@' in handles
//
Boolean filterString(char *text, char *tokens, char *replace)
{
	char *t, *tok;
	Boolean filtered = false;
	
	for(t = text; *t; t++)
		for(tok = tokens; *tok; tok++)
			if(*t == *tok)
			{
				*t = *replace++;
				filtered = true;
			}
	
	return(filtered);
}

long strcmpIgnoreWDC(char *text, char *word, Boolean ignoreWhitespace, Boolean ignoreDelimiters, Boolean caseSensitive)
{
	for(; *text && *word; text++)
	{
		if(ignoreDelimiters)
			if(IsCharOfType(*text, DELIMITERS))
				continue;
		if(ignoreWhitespace)
			if(IsCharOfType(*text, WHITESPACE))
				continue;

		if(caseSensitive)
		{
			if(*text != *word)
				return(*text - *word);
		}
		else
		{
			if(CompareAndIgnoreCaps(*text, *word) == false)
				return(*text - *word);
		}
		
		word++;
	}
	
	//
	// Gobble trailing text if it is whitespace or delimiters.
	//
	if(*text && !*word)
		for(; *text; text++)
		{
			if(ignoreDelimiters)
				if(IsCharOfType(*text, DELIMITERS))
					continue;
			if(ignoreWhitespace)
				if(IsCharOfType(*text, WHITESPACE))
					continue;
			
			break;
		}

	return(*text - *word);
}


//
// scan thru text.  ignore leading whitespace
// find whitespace.  put a NULL there.
//

static char *strtokPtr = NULL;

char *strtokIgnoreC(char *text, char *tokens, Boolean caseSensitive)
{
char 		*t;

	if(text)
		strtokPtr = text;
	
	if(!strtokPtr)
		return( NULL );

	// gobble leading whitespace
	//
	for(; *strtokPtr; strtokPtr++)
		if(!IsCharOfType(*strtokPtr, WHITESPACE))
			break;

	for(t = strtokPtr; *strtokPtr; strtokPtr++)
	{
		if(IsCharOfType(*strtokPtr, WHITESPACE))
		{
			*strtokPtr = 0;
			strtokPtr++;
			break;
		}
	}

	if(*t)
		return(t);
	
	return(NULL);
}

char *strstrIgnoreWDC(char *text, char *word, Boolean ignoreWhitespace, Boolean ignoreDelimiters, Boolean caseSensitive)
{
char 		*t, *w, *s;
Boolean 	matchedOneChar = false;


	for(t = text; *t; t++)
	{
		w = word;
		for(s = NULL, matchedOneChar = false; *t && *w; t++)
		{
			if(ignoreWhitespace && IsCharOfType(*t, WHITESPACE))
				continue;
			if(ignoreDelimiters && IsCharOfType(*t, DELIMITERS))
				continue;


			if(caseSensitive)
			{
				if(*t != *w)
					break;
			}
			else
			if(!CompareAndIgnoreCaps(*t, *w))
				break;

			// it matches.

			matchedOneChar = true;
			
			if(!s)
				s = t;	// mark where 'word' starts in the text.

			w++;
		}
		
		if(!*w)
			return(s);		// We matched to 'word'.
		else
			if(matchedOneChar)
				t--;	// keep 't' on this char that didn't match in order to
						// check it against the start of 'word'.
						// avoids bug where we wouldn't detect this: 'fufuck'
	}

	return(NULL);
}


void strcpyIgnoreWD(char *dest, char *src, char *replace, Boolean ignoreWhitespace, Boolean ignoreDelimiters)
{
	for(; *dest && *src; dest++)
	{
		if(ignoreWhitespace && IsCharOfType(*dest, WHITESPACE))
			continue;
		if(ignoreDelimiters && IsCharOfType(*dest, DELIMITERS))
			continue;

		*dest = *replace++;	// replace it.

		src++;
	}
}

