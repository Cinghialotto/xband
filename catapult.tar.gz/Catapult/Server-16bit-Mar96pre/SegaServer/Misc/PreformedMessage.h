/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: PreformedMessage.h,v 1.2 1995/05/26 23:20:11 jhsia Exp $
 *
 * $Log: PreformedMessage.h,v $
 * Revision 1.2  1995/05/26  23:20:11  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		PreformedMessage.h

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		 <2>	  8/4/94	DJ		make PackStrings a generally avail util
		 <1>	 6/11/94	DJ		first checked in

	To Do:
*/



#ifndef __PreformedMessage__
#define __PreformedMessage__

// message is a data chunk that contains opCode and the data.
typedef struct PreformedMessage {
	long 	length;
	Ptr		message;
} PreformedMessage;


PreformedMessage *PreformedMessage_Duplicate(PreformedMessage *message);
void PreformedMessage_Dispose(PreformedMessage *message);

PreformedMessage *PreformedMessage_ReadFromFile(char *filename);

// String packing, used by news and rankings.
//
void PackStrings(char *packed, long numStrings, char **strings);

#endif __PreformedMessage__

