/*
 * $Id: MiscComm.h,v 1.2 1995/05/11 23:22:40 jhsia Exp $
 */

/*
	File:		MiscComm.h

	Contains:	Comm headers for loading tool

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

	$Log: MiscComm.h,v $
 * Revision 1.2  1995/05/11  23:22:40  jhsia
 * switch to rcs keywords
 *
		 <1>	10/16/94	BET		first checked in

	To Do:
*/

#define NULL 0

#include "PhysicalLayer.h"
#include "TransportLayer.h"


extern SessionRec transRec;
