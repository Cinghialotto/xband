/*
 * $Id: MiscComm.c,v 1.2 1995/05/11 23:22:39 jhsia Exp $
 */

/*
	File:		MiscComm.c

	Contains:	Misc comm cheeze for load simulator

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

	$Log: MiscComm.c,v $
 * Revision 1.2  1995/05/11  23:22:39  jhsia
 * switch to rcs keywords
 *
		 <2>	10/25/94	BET		I dunno, maybe nothing.
		 <1>	10/16/94	BET		first checked in

	To Do:
*/


#include "MiscComm.h"
#include "Messages.h"
#include "TransportLayer.h"



SessionRec *aGame;

int InitServerConnection()
{

OSErr		err;
char		*config;
NetParamBlock	net;

	TInit();
	aGame = (SessionRec *)malloc(sizeof(SessionRec));
	if(!aGame) 
	{
		return(-1);	// some kind of error notification, please
	}

	err = POpen(NULL, kUseServerProtocol);
	if(err != noErr)
	{
		PCheckError();
		return(-1);
	}
	
	
	if((err = TNetIdle(&net)) != noErr)
	{
		TCheckError();
		PCheckError();
		free(aGame);
		aGame = NULL;
		return(-1);
	}
	
	err = TOpen(aGame, 0, 0);
	if(err != noErr)
	{
		TCheckError();
		if(PClose() != noErr)
			PCheckError();

		free(aGame);
		aGame = NULL;
		return(-1);
	}
	return(0);
}

//
// Close a connection.
//
int CloseServerConnection()
{
Boolean	retVal;
OSErr		err;
#ifdef unix
extern long gHangupOkay;
#endif

	retVal = false;
	if( TClose(aGame) != noErr)	// shouldn't hang anymore
		TCheckError();
		
	err = PClose();
	if(err != noErr)
	{
		// chances are we catch a SIGHUP before we get here
		PCheckError();
	}

	return(0);
}


