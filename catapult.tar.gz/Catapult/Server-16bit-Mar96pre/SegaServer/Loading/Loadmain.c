/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Loadmain.c,v 1.3 1995/05/26 22:40:59 jhsia Exp $
 */

/*
	File:		Loadmain.c

	Contains:	Main entry for load simulator
	
	Guilty:		Brian Topping


	Change History (most recent first):

	$Log: Loadmain.c,v $
 * Revision 1.3  1995/05/26  22:40:59  jhsia
 * added copyright
 *
 * Revision 1.2  1995/05/11  23:22:37  jhsia
 * switch to rcs keywords
 *
		 <3>	11/29/94	BET		It works!  Fixed selector so it doesn't munge the pipes on
									"type=netdata" and everything works!  Check it in, add options
									later.
		 <2>	10/25/94	BET		Working on direct load of SunSega, but maybe not on selector for
									some reason.
		 <1>	10/16/94	BET		first checked in

	To Do:
*/
#include <stdio.h>
#include <sys/types.h>
#include <errno.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/ioctl.h>
#include <fcntl.h>

#include "TransportLayer.h"
#include "SegaTypes.h"
#include "ServerDataBase.h"
#include "Common_ReadConf.h"


#define BUFFSIZE		1024

static void				sig_pipe(int);		/* our signal handler */
extern int 				getopt(int, char * const *, const char *);
void 					set_fl(int fd, int flags);
void					pipe_handler();

extern char				*optarg;
extern int				opterr;
extern int				optind;
extern SessionRec		*aGame;
char					gBuf[BUFFSIZE];


//
// Parse args, init stuff, etc.
//
void
main(int argc, char *argv[])
{
int						chdir_failed, ioctl_failed, c, onoff, verbose = false, selector = true;
char					*segaData = NULL,*config_file = NULL;
int						n, fd1[2], fd2[2], fdInput = -1;
pid_t					pid;
struct sgttyb 			sg;
char					ch[6];


	opterr = 0;
	while ((c = getopt(argc, argv, "vcf:i:")) != EOF) {
		switch (c) {
			case 'i':
				fdInput = open(optarg, O_RDONLY);
				continue;
			case 'c':
				selector = false;
				fdInput = dup(fileno(stdin));
				continue;
			case 'f':
				selector = false;
				config_file = optarg;
				continue;
			case 'v':
				verbose = true;
				continue;
usage:
			default:
				(void) fprintf(stderr, "# %s: Unknown option %s\n", argv[0], argv[optind-1]);
				(void) fprintf(stderr, "# %s: Usage:\t%s [-c | -i input_file] [-f config_file]\n", argv[0], argv[0]);
				exit(2);
				}
			}

	// make sure we got an input file and no selector or selector and no input file.
	if (((fdInput == -1) && (!selector)) || ((fdInput != -1) && (selector)))
		goto usage;
		
	
	
	// Try to make /var/catapult the current directory.  This is so all
	// our system patches and other goodies will be found there instead of
	// in /var/selector.
	//
	if (chdir_failed = chdir("/var/catapult"))
		chdir_failed = errno;

	if (SunSega_InitGlobals(config_file, verbose) < 0)
		exit(1);

	if (chdir_failed)
		PLogmsg(LOGP_FLAW,
			"WARNING: not able to chdir to /var/catapult (err=%d)\n",
			chdir_failed);

	if (!selector) {
		/* now do the pipe cheeze */
		if (signal(SIGPIPE, sig_pipe) == SIG_ERR)
			PLogmsg(LOGP_FLAW,"signal error");
	
		if (pipe(fd1) < 0 || pipe(fd2) < 0)
			PLogmsg(LOGP_FLAW,"pipe error");
	
		if ( (pid = fork()) < 0)
			PLogmsg(LOGP_FLAW,"fork error");
		else if (pid > 0) {							/* parent */
//			kill(getpid(), SIGSTOP);	// gdb me
			// parent needs to use stdin/stdout hacks because of the included code in SunSerial.c
			close(fd1[0]);
			close(fd2[1]);
			close(fileno(stdin));
			close(fileno(stdout));
			if (fd2[0] != fileno(stdin)) {
				if (dup2(fd2[0], fileno(stdin)) != fileno(stdin))
					PLogmsg(LOGP_FLAW,"dup2 error to stdin");
				close(fd2[0]);
				}
			if (fd1[1] != fileno(stdout)) {
				if (dup2(fd1[1], fileno(stdout)) != fileno(stdout))
					PLogmsg(LOGP_FLAW,"dup2 error to stdout");
				close(fd1[1]);
				}
			
	//		n = read(fileno(stdin), ch, 6);
	//		n = write(fileno(stdout), "Cheeze", 6);
			set_fl(fileno(stdin), O_NDELAY);
			signal(SIGPIPE, pipe_handler);
			}
		else {									/* child */
//			kill(getpid(), SIGSTOP);	// gdb me
			// child gets all the stdin and stdout hacks to make it comm from the parent's pipes
			close(fd1[1]);
			close(fd2[0]);
			if (fd1[0] != fileno(stdin)) {
				if (dup2(fd1[0], fileno(stdin)) != fileno(stdin))
					PLogmsg(LOGP_FLAW,"dup2 error to stdin");
				close(fd1[0]);
				}
			if (fd2[1] != fileno(stdout)) {
				if (dup2(fd2[1], fileno(stdout)) != fileno(stdout))
					PLogmsg(LOGP_FLAW,"dup2 error to stdout");
				close(fd2[1]);
				}
	//		kill(getpid(),17);
	//		n = write(fileno(stdout), "Cheeze", 6);
			set_fl(fileno(stdin), O_NDELAY);
//			if (c = execl("/home/binky/topping/SunSega", "SunSega", "-f", "loading.conf", (char *) 0) < 0) {
			if (c = execl("/usr/local/etc/selector", "selector", "-t",  "netdata", "-s", "cat_sg08", (char *) 0) < 0) {
				c = errno;
				PLogmsg(LOGP_FLAW,"execl error");
				abort();
				}
			}
		}
	
	/* cheeze is ready, we should be connected to a SunSega now. */
	/* try opening a connection. */
	if (InitServerConnection())
		exit (1);

	/* pump over some cheeze */
	while ( (c = read(fdInput, gBuf, BUFFSIZE)) > 0)
		if (TWriteDataASync(aGame, c, gBuf))
			PLogmsg(LOGP_FLAW,"write error");

	if (c < 0)
		PLogmsg(LOGP_FLAW,"read error");

	while ((!TNetIdle(nil)) && TReadData(BUFFSIZE, gBuf, false))
		;
	/* close down the connection */
	exit (CloseServerConnection());
}


//
// Initialization stuff.
//
// Returns 0 on success, -1 on failure.
//
static int
SunSega_InitGlobals(char *config_file, int verbose)
{
	// Read the config file.
	//
	if (config_file && (Common_ReadConfigFile("SunSega", config_file) < 0))
		return (-1);

	gProduction = gConfig.isProduction;

	gLogFile = verbose ? stderr : fopen(gConfig.serverLogName, "a");
	if (gLogFile == NULL)
		gLogFile = fopen("log", "a");			// try current directory
	if (gLogFile == NULL)
		gLogFile = fopen("/tmp/log", "a");		// okay, try /tmp
	if (gLogFile == NULL)
		gLogFile = fopen("/dev/null", "a");		// fine, forget it
	if (gLogFile == NULL)
		Common_Abort();							// AIIIIIGH!!!

	gStatusFile = fopen(gConfig.statusLogName, "a");
	if (gStatusFile == NULL) {
		gStatusFile = gLogFile;
		PLogmsg(LOGP_FLAW, "Unable to open status log; using server log\n");
	}

	return (0);
}


static void
sig_pipe(int signo)
{
	printf("SIGPIPE caught\n");
	exit(1);
}


void
pr_exit(int status)
{
	if (WIFEXITED(status))
		printf("normal termination, exit status = %d\n",
				WEXITSTATUS(status));
	else if (WIFSIGNALED(status))
		printf("abnormal termination, signal number = %d%s\n",
				WTERMSIG(status),
#ifdef	WCOREDUMP
				WCOREDUMP(status) ? " (core file generated)" : "");
#else
				"");
#endif
	else if (WIFSTOPPED(status))
		printf("child stopped, signal number = %d\n",
				WSTOPSIG(status));
}

void
set_fl(int fd, int flags) /* flags are file status flags to turn on */
{
	int		val;

	if ( (val = fcntl(fd, F_GETFL, 0)) < 0)
		PLogmsg(LOGP_FLAW,"fcntl F_GETFL error");

	val |= flags;		/* turn on flags */

	if (fcntl(fd, F_SETFL, val) < 0)
		PLogmsg(LOGP_FLAW,"fcntl F_SETFL error");
}

void
pipe_handler()
{
	PLogmsg(LOGP_NOTICE, "Pipe closed out from underneath us, exiting\n");
	//abort();
	exit(0x0a);
	/*NOTREACHED*/
}


