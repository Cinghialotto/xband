/*
 * Copyright:	� 1995 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_ReceiveBoxLogs.c,v 1.7 1996/01/25 17:53:24 hufft Exp $
 * 
 * $Log: Server_ReceiveBoxLogs.c,v $
 * Revision 1.7  1996/01/25  17:53:24  hufft
 * added UDP based connections
 *
 * Revision 1.6  1995/09/13  14:16:12  ted
 * Fixed warnings.
 *
 * Revision 1.5  1995/07/07  20:52:59  fadden
 * Renamed Server_ReceiveBoxLogs to Server_snes_ReceiveBoxLogs.
 *
 * Revision 1.4  1995/05/28  20:19:15  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_ReceiveBoxLogs.c

	Contains:	Routines to handle box log info.

	Written by: Andy McFadden


*/
#include <stdio.h>
#include <malloc.h>
#include "Common.h"
#include "Common_Log.h"
#include "Common_PlatformID.h"
#include "Server_Comm.h"


//
// Right now, only the SNES does this.
//
// Format is message #, size (short), then "size" bytes.
//
int
Server_snes_ReceiveBoxLogs(ServerState *state)
{
	unsigned char opCode;
	unsigned short size;
	char *happyBuf = NULL;

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveBoxLogs\n");

	FPLogmsg(LOG_BOXHIST, LOGP_DBUG,
		"BOX LOG for '%s' (%s) (%ld,%ld)[%d]\n",
		state->loginData.userID.userName,
		state->boxPhoneNumber.phoneNumber,
		state->loginData.userID.box.box,
		state->loginData.userID.box.region,
		state->loginData.userID.userID);

	Server_TReadDataSync( state->session, sizeof(unsigned char), (Ptr)&opCode );
	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);
	if (opCode != msSendBoxLogs) {
		PLogmsg(LOGP_NOTICE, "ERROR: wanted msSendBoxLogs, got %d\n", opCode);
		return (kServerFuncAbort);
	}

	// First chunk is server connect log.
	//
	Server_TReadDataSync( state->session, sizeof(unsigned short), (Ptr)&size );
	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);
	if (size > 2048) {
		PLogmsg(LOGP_NOTICE,
			"ERROR: huge server connect log (%d bytes)\n", size);
		return (kServerFuncAbort);
	}
	if (size) {
		if ((happyBuf = (unsigned char *)malloc(size)) == NULL) {
			PLogmsg(LOGP_FLAW, "ERROR: out of memory (alloc %d)\n", size);
			return (kServerFuncAbort);
		}

		Server_TReadDataSync( state->session, size, (Ptr)happyBuf );
		if (Server_TCheckError(state->session) != noErr)
			return (kServerFuncAbort);

		FPLogmsg(LOG_BOXHIST, LOGP_DBUG, "Box Log Info (SERVER):\n");
		FLoghexdump(LOG_BOXHIST, happyBuf, size);

		free(happyBuf);
	}

	// Second chunk is peer connect log.
	//
	Server_TReadDataSync( state->session, sizeof(unsigned short), (Ptr)&size );
	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);
	if (size > 2048) {
		PLogmsg(LOGP_NOTICE, "ERROR: huge peer connect log (%d bytes)\n", size);
		return (kServerFuncAbort);
	}
	if (size) {
		if ((happyBuf = (unsigned char *)malloc(size)) == NULL) {
			PLogmsg(LOGP_FLAW, "ERROR: out of memory (alloc %d)\n", size);
			return (kServerFuncAbort);
		}

		Server_TReadDataSync( state->session, size, (Ptr)happyBuf );
		if (Server_TCheckError(state->session) != noErr)
			return (kServerFuncAbort);

		FPLogmsg(LOG_BOXHIST, LOGP_DBUG, "Box Log Info (PEER):\n");
		FLoghexdump(LOG_BOXHIST, happyBuf, size);

		free(happyBuf);
	}

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveBoxLogs done\n");
	return (kServerFuncOK);
}

