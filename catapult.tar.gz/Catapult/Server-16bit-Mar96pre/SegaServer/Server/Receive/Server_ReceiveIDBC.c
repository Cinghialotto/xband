/*
 * Copyright:	� 1995 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_ReceiveIDBC.c,v 1.8 1996/01/25 17:53:28 hufft Exp $
 *
 * $Log: Server_ReceiveIDBC.c,v $
 * Revision 1.8  1996/01/25  17:53:28  hufft
 * added UDP based connections
 *
 * Revision 1.7  1995/07/11  14:20:04  fadden
 * Get kSoundOptionsConst from SNES boxes.
 *
 * Revision 1.6  1995/07/07  20:53:59  fadden
 * Split SendRequestData and ReceiveRequestedData into platform-specific
 * functions.
 *
 * Revision 1.5  1995/06/01  15:09:53  fadden
 * Merge in from newbr.
 * -> Added some items for new restore stuff.
 *
 * Revision 1.4  1995/05/28  20:19:18  jhsia
 * switch to rcs keywords
 *
 * Revision 1.3  1995/05/11  05:50:37  fadden
 * Added a logmsg, Server_SendRequestData(), and Server_ReceiveRequestedData().
 *
 */

/*
	Server_ReceiveIDBC.c

	Contains:	Receive Interesting DataBase Constants

	Written by:	Andy McFadden
*/

#include <stdio.h>

#include "ServerCore.h"
#include "Server.h"
#include "Server_Comm.h"

#include "Messages.h"
#include "DBConstants.h"

#include "Common.h"
#include "Common_Log.h"


//
// Local prototypes
//
PRIVATE int Server_common_ReceiveRequestedData(ServerState *state);
PRIVATE int Server_common_SendRequestData(ServerState *state);



// ===========================================================================
//		IDBC stuff
// ===========================================================================

//
// SNES interesting DB constants message.
//
typedef struct snes_IDBC {
	long	phoneOptions;				// kPhoneOptionsConst
	long	bandwidthVersion;			// kBANDWIDTHVersion
	long	xbandNewsVersion;			// kXBANDNewsVersion
	unsigned char	waitTime;			// GetWaitTime()
	unsigned char	callingArea;		// GetCallingAreaOption()
	unsigned char	dialingPrefix;		// GetBoxPrefix()
	unsigned char	callWaitingOption;	// GetCallWaitingOption()
} snes_IDBC;

#define kMaxIDBCSize	128

//
// The SNES automatically snes up some useful info, so the server doesn't
// have to query the box.
//
int
Server_snes_ReceiveInterestingDBConstants(ServerState *state)
{
	unsigned char opCode;
	unsigned char numBytes;
	unsigned char goodStuff[kMaxIDBCSize];
	snes_IDBC *idbc;

	PLogmsg(LOGP_PROGRESS, "Server_snes_ReceiveInterestingDBConstants\n");

	Server_TReadDataSync(state->session, 1, (Ptr)&opCode);
	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	if (opCode != msSendInterestingDBConstants) {
		PLogmsg(LOGP_FLAW, "Wrong opCode.  Expected %d, got %d\n",
			msGameIDAndPatchVersion, opCode);
		return (kServerFuncAbort);
	}

	// First byte tells us how much more data there is.  For now we just
	// read it all in and ignore it.
	//
	Server_TReadDataSync(state->session, sizeof(unsigned char), (Ptr)&numBytes);
	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);
	if (numBytes > kMaxIDBCSize) {
		PLogmsg(LOGP_FLAW, "ERROR: IDBC numBytes too big (%d)\n", numBytes);
		return (kServerFuncAbort);
	}

	Server_TReadDataSync(state->session, numBytes, (Ptr)goodStuff);
	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);
	//Logmsg("InterestingDBConstants (%d bytes)\n", numBytes);

	idbc = (snes_IDBC *)goodStuff;
	state->niftyInfo.snes.phoneOptions = idbc->phoneOptions;
	state->niftyInfo.snes.bandwidthVersion = idbc->bandwidthVersion;
	state->niftyInfo.snes.xbandNewsVersion = idbc->xbandNewsVersion;
	state->niftyInfo.snes.waitTime = idbc->waitTime;
	state->niftyInfo.snes.callingArea = idbc->callingArea;
	state->niftyInfo.snes.dialingPrefix = idbc->dialingPrefix;
	state->niftyInfo.snes.callWaitingOption = idbc->callWaitingOption;

	PLogmsg(LOGP_DBUG, "IDBC: phoneOptions=0x%.8lx\n", idbc->phoneOptions);
	PLogmsg(LOGP_DBUG,
		"      bandwidthVersion=0x%.8lx, xbandNewsVersion=0x%.8lx\n",
		idbc->bandwidthVersion, idbc->xbandNewsVersion);
	PLogmsg(LOGP_DBUG,
		"      waitTime=%d, callingArea=%d, dialingPrefix=%d, cwOption=%d\n",
		idbc->waitTime, idbc->callingArea, idbc->dialingPrefix,
		idbc->callWaitingOption);

	PLogmsg(LOGP_PROGRESS, "Server_snes_ReceiveInterestingDBConstants done\n");
	return (kServerFuncOK);
}



// ===========================================================================
//		SendRequestData stuff
// ===========================================================================

//
// Genesis version is a subset of the SNES version.
//
int
Server_sega_SendRequestData(ServerState *state)
{
	Err err;

	PLogmsg(LOGP_PROGRESS, "Server_sega_SendRequestData\n");

	Server_SetTransportHold(state->session, true);
	err = Server_common_SendRequestData(state);
	Server_SetTransportHold(state->session, false);

	return (err);
}

//
// SNES version has some extras so we can restore all the fancy stuff.
//
int
Server_snes_SendRequestData(ServerState *state)
{
	Err err;
	DBID id;
	unsigned char opCode;

	PLogmsg(LOGP_PROGRESS, "Server_snes_SendRequestData\n");

	Server_SetTransportHold(state->session, true);

	// Sound options aren't in the IDBC, so request them now.
	//
	id = kSoundOptionsConst;
	opCode = msGetConstant;
	Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&id);

	err = Server_common_SendRequestData(state);
	Server_SetTransportHold(state->session, false);

	return (err);
}

//
// Request some values from the box.
//
// Kind of like IDBC, except that we have to request them explicitly.
//
// They're requested early in the connection.  The replies will arrive
// after the box has finished uploading all of its stuff.  Note that this
// should be sent AFTER we read the BoxType, so ServerCore can decide
// whether or not to call this routine at all.
//
// Okay for caller to set TransportHold (we can't wait for data to arrive
// here; it comes back much later).
//
PRIVATE int
Server_common_SendRequestData(ServerState *state)
{
	unsigned char opCode;
	DBID id;

	PLogmsg(LOGP_PROGRESS, "Server_common_SendRequestData\n");

	// Send request for kSpecialModeFlagsConst.
	//
	id = kSpecialModeFlagsConst;
	opCode = msGetConstant;
	Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&id);

	// Send request for hidden serials.
	//
	opCode = msGetHiddenSerials;
	Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr)&opCode);

	// Send request for kXBANDOptions1Const (for restore stuff)
	//
	id = kXBANDOptions1Const;
	opCode = msGetConstant;
	Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&id);

	// Check for errors & bail.
	//
	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_common_SendRequestData done\n");
	return (kServerFuncOK);
}



// ===========================================================================
//		ReceiveRequestedData stuff
// ===========================================================================

int
Server_sega_ReceiveRequestedData(ServerState *state)
{
	PLogmsg(LOGP_PROGRESS, "Server_sega_ReceiveRequestedData\n");

	return (Server_common_ReceiveRequestedData(state));
}

int
Server_snes_ReceiveRequestedData(ServerState *state)
{
	PLogmsg(LOGP_PROGRESS, "Server_snes_ReceiveRequestedData\n");

	// kSoundOptionsConst
	//
	Server_TReadDataSync( state->session, sizeof(long),
		(Ptr)&state->niftyInfo.snes.soundOptions );

	return (Server_common_ReceiveRequestedData(state));
}

//
// Receive the data that we requested in common_SendRequestData.
//
PRIVATE int
Server_common_ReceiveRequestedData(ServerState *state)
{
	unsigned char opCode;
	long val;
	char numHidden;

	PLogmsg(LOGP_PROGRESS, "Server_common_ReceiveRequestedData\n");

	// Receive kSpecialModeFlagsConst.
	//
	Server_TReadDataSync(state->session, sizeof(long), (Ptr)&val);
	if (val == -1)		// means it doesn't exist yet
		val = 0;
	state->niftyInfo.any.specialModeFlags = val;
	PLogmsg(LOGP_DBUG, "RRD: Got specialModeFlags 0x%.8lx\n",
		state->niftyInfo.any.specialModeFlags);

	// Receive hidden serials.
	//
	Server_TReadDataSync( state->session, 1, (Ptr)&opCode );
	if(opCode != msSendHiddenSerials) {
		PLogmsg(LOGP_FLAW,
			"ERROR: RRD: box didn't respond to msGetHiddenSerials with %d (got %d)\n",
			msSendHiddenSerials, opCode);
		return (kServerFuncAbort);
	}

	Server_TReadDataSync( state->session, 1, (Ptr)&numHidden );
	if (numHidden != 2) {
		PLogmsg(LOGP_FLAW,
			"ERROR: RRD: msSendHiddenSerials with numHidden=%d\n", numHidden);
		return (kServerFuncAbort);
	}

	Server_TReadDataSync( state->session, sizeof(BoxSerialNumber),
		(Ptr)&state->niftyInfo.any.hidden1 );
	Server_TReadDataSync( state->session, sizeof(BoxSerialNumber),
		(Ptr)&state->niftyInfo.any.hidden2 );

	// Receive kXBANDOptions1Const.
	//
	Server_TReadDataSync(state->session, sizeof(long), (Ptr)&val);
	if (val == -1)		// means it doesn't exist yet - impossible?
		val = 0;
	state->niftyInfo.any.xbandOptions1 = val;

	// Check for errors & bail.
	//
	if(Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_common_ReceiveRequestedData done\n");
	return (kServerFuncOK);
}

