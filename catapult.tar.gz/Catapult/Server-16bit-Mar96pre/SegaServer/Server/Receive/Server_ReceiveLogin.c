/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_ReceiveLogin.c,v 1.30 1996/01/25 17:53:29 hufft Exp $
 * 
 * $Log: Server_ReceiveLogin.c,v $
 * Revision 1.30  1996/01/25  17:53:29  hufft
 * added UDP based connections
 *
 * Revision 1.29  1995/11/13  17:17:32  jhsia
 * changed customer service phone number to be 408-777-1500
 *
 * Revision 1.28  1995/11/08  18:53:56  jhsia
 * Added PhoneXlate call.
 *
 * Revision 1.27  1995/10/07  15:04:29  roxon
 * Use "vNewMaxInBoxEntries" (8/10 - depending on paltformID) instead of
 * kMaxInBoxEntries (10).
 *
 * Revision 1.26  1995/09/17  12:25:38  roxon
 * Remove setlocale(0 and textdomain() calls. It is done in main().
 *
 * Revision 1.25  1995/09/13  14:16:14  ted
 * Fixed warnings.
 *
 * Revision 1.24  1995/08/11  16:26:09  fadden
 * Move all the logmsgs after the reads, and rearrange them so that the
 * userID gets printed first.  This makes scanning a connection from the
 * ASCII logs easier, since you don't have to back up for anything useful.
 *
 * Revision 1.23  1995/07/26  23:02:24  fadden
 * Added magnifyDebug stuff.
 *
 * Revision 1.22  1995/07/26  18:45:32  rich
 * Merged in fadden's 1.18 changes that I boneheadedly clobbered with version 1.19.
 *
 * Revision 1.21  1995/07/26  00:13:15  fadden
 * (fadden) Remove AIIIIGH check on 11768.
 *
 * Revision 1.20  1995/07/25  22:02:54  fadden
 * Lock out 11768 while we figure out what's fucked.
 *
 * Revision 1.19  1995/07/21  20:30:28  rich
 * Changed message i18n: uses new bindtextdomain, textdomain, setlocale now
 *
 * Revision 1.18  1995/07/17  18:43:15  fadden
 * LRA: change output format on box login flags and box serial number.
 *
 * Revision 1.17  1995/07/10  21:17:30  rich
 * Added code to Server_ReceiveBoxType() to recognize Japanese SNES box
 * and to call setlocale() and textdomain() to establish Japanese locale ("ja").
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.16  1995/06/19  20:52:04  fadden
 * Moved check on SNES simulator (again), into BoxIsSimulator.  Set value in
 * realHardwareIDtype after blowing away the hardwareIDtype.
 *
 * Revision 1.15  1995/06/03  19:48:36  fadden
 * ServerState now using struct HardwareID.  Added Server_IgnoreSimulatorHWID.
 * Rearranged stuff.
 *
 * Revision 1.14  1995/05/28  20:19:19  jhsia
 * switch to rcs keywords
 *
 */


/*
	File:		Server_ReceiveLogin.c

	Contains:	Server ReceiveLogin function

	Written by:	Dave Jevans


	Change History (most recent first):

		<43>	12/13/94	ATM		Redefined misc login flags to match system patch.
		<42>	12/12/94	ATM		Added Logmsg for split patch stuff.
		<41>	11/30/94	ATM		Print boxFlags as hex, for when the box guys add new ones.
		<40>	11/27/94	ATM		The box sends AcceptChallenges bit inverted; update log messages
									to match.
		<39>	11/19/94	HEC		Added fax machine detected login bit.
		<38>	11/17/94	KD		Updated dialog text (doug/kon).
		<37>	 11/7/94	ATM		Added def for kPlayingSinglePlayerGame.
		<36>	 11/3/94	ATM		Print contents of lastBoxState to log.
		<35>	 9/19/94	ATM		PLogmsg stuff.
		<34>	 8/27/94	ATM		Made "software version we don't understand" dialog happier,
									threw in a log message.
		<33>	 8/22/94	DJ		printing out more of the boxFlags
		<32>	 8/21/94	DJ		a new long flag in receivelogin
		<31>	 8/20/94	DJ		no serverUniqueID in userIdentification
		<30>	 8/18/94	DJ		tweaked a logsmsg msg
		<29>	 8/17/94	DJ		receiveloginversion2
		<28>	 8/13/94	DJ		boxtype calls forceend if unsupported rom version
		<27>	 8/12/94	DJ		supports multiple ROM versions
		<26>	 8/12/94	ATM		Converted to Logmsg.
		<25>	 8/10/94	BET		Added scriptID brokering vi phoneNumber structure.
		<24>	  8/8/94	DJ		SendDialog takes boolean whether to stick or disappear in 3 sec.
		<23>	  8/4/94	BET		Changed a field name.
		<22>	  8/2/94	DJ		fixed a printef
		<21>	 7/31/94	DJ		lastBoxState sent with login
		<20>	 7/27/94	DJ		receiving login validation token
		<19>	 7/20/94	DJ		added Server_Comm stuff
		<18>	 7/19/94	DJ		receiving serialnumbers of mail inbox so we can backup if box
									dies sometime
		<17>	 7/18/94	DJ		separated boxType from login msg
		<16>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		<15>	 7/15/94	DJ		nothing
		<14>	 7/14/94	DJ		added segaID and box state and OS state
		<13>	 7/12/94	DJ		using Server_TCheckError(state->session) instead of TCheckError
		<12>	  7/1/94	DJ		making server handle errors from the comm layer
		<11>	 6/30/94	DJ		boxsernum no longer sent at login (is part of userID)
		<10>	 6/29/94	BET		(Really DJ) Clean up after KON.
		 <9>	 6/15/94	DJ		simulating ANI with state->boxPhoneNumber
		 <8>	 6/11/94	DJ		trying to figure out where ANI fits in this hack-o server
		 <7>	  6/9/94	BET		Fix hairy compiles based on TransportSlayer.h
		 <6>	  6/5/94	DJ		reading # mails in box inbox at login time
		 <5>	  6/4/94	DJ		making everything take a ServerState instead of SessionRec
		 <4>	  6/1/94	DJ		phone numbers are now kPhoneNumberSize in length, not
									kPhoneNumberSize + 1
		 <3>	 5/31/94	DJ		printing userinfo
		 <2>	 5/27/94	DJ		updated to userIdentifier struct
	To Do:
*/

#include <memory.h>
#include "ServerCore.h"
#include "Server.h"

#include "Common.h"
#include "Common_ReadConf.h"
#include "Common_Phone.h"
#include "Common_Missing.h"

#include "Messages.h"
#include "UsrConfg.h"
#include "Server_Comm.h"
#include "ServerCore.h"
#include "BoxSer.h"

#include <stdio.h>
#include <locale.h>

//
// Local prototypes
//
PRIVATE int Server_IgnoreSimulatorHWID(ServerState *state);
PRIVATE Err Server_common_ReceiveLogin(ServerState *state);



//
// Receive the box type, and switch to the appropriate dispatcher table.
//
int
Server_ReceiveBoxType(ServerState *state)
{
unsigned char 	opCode;
char			msg[256];

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveBoxType\n");

	if(Server_TReadDataSync(state->session, 1, (Ptr)&opCode) != noErr)
		return(kServerFuncAbort);

	if(opCode != msBoxType){
		// fucked
		PLogmsg(LOGP_FLAW, "Wrong opCode.  Expected %d, got %d\n",
			msBoxType, opCode);
		return(kServerFuncAbort);
	}
	PLogmsg(LOGP_PROGRESS, "Got opCode, waiting for boxType\n");

	Server_TReadDataSync(state->session, sizeof(long), (Ptr)&state->boxOSState.boxType );

	if (Server_SwapMessageDispatcher(state, state->boxOSState.boxType) != kServerFuncOK)
	{
		sprintf(msg,
			gettext("Your Modem's software version (%.4s) is not compatible with the XBAND Network.  Please call XBAND Customer Support at 408-777-1500."),  /* DIALOG */
			(char *)&state->boxOSState.boxType);
		Server_SendLargeDialog(state, msg, true);
		PLogmsg(LOGP_NOTICE,
			"BAILING: told the box that it's ROM is too old (%.4s)\n",
			(char *)&state->boxOSState.boxType);
		return (kServerFuncForceEnd);
	}

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	state->validFlags |= kServerValidFlag_BoxType;

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveBoxType done\n");
	return(kServerFuncOK);
}


//
// Receive the Genesis login message.
//
int
Server_sega_ReceiveLogin(ServerState *state)
{
	Err		err;

	PLogmsg(LOGP_PROGRESS, "Server_sega_ReceiveLogin\n");

	if ((err = Server_common_ReceiveLogin(state)) != kNoError)
		return (err);

	// Box doesn't send these up, so init them.
	//
	state->loginData.rentalCardSerialNum = 0;
	state->loginData.hardwareID.hardwareIDtype = kHWID_NoHWID;

	PLogmsg(LOGP_PROGRESS, "Server_sega_ReceiveLogin done\n");
	return(kServerFuncOK);
}


//
// Receive the SNES login message.
//
// (this is temporarily being used for Intel as well)
//
int
Server_snes_ReceiveLogin(ServerState *state)
{
HardwareID		*hwid;
unsigned char	hwIDsize;
Err				err;

	PLogmsg(LOGP_PROGRESS, "Server_snes_ReceiveLogin\n");

	if ((err = Server_common_ReceiveLogin(state)) != kNoError)
		return (err);

	//dbStable = state->boxOSState.osFree >> 16;
	//Logmsg(" DB stable flag = %ld\n", dbStable);

	Server_TReadDataSync( state->session, sizeof(long),
		(Ptr)&state->loginData.rentalCardSerialNum);
	Logmsg("Rental card serial # = 0x%.8lx\n",
		state->loginData.rentalCardSerialNum);
	Server_TReadDataSync( state->session, sizeof(long),
		(Ptr)&state->loginData.rentalCardPrefix);
	if (state->loginData.rentalCardSerialNum || state->loginData.rentalCardPrefix)
	{
		Logmsg("Rental card prefix # = 0x%.8lx\n",
			state->loginData.rentalCardPrefix);
	}

	// HardwareID stuff.  This should be made more intelligent (right now
	// it'll get really upset if the hwid isn't a SNES Dallas type).
	//
	Server_TReadDataSync( state->session, sizeof(char),
		(Ptr)&hwIDsize);
	if (hwIDsize != sizeof(short) + sizeof(SnesHardwareID)) {
		PLogmsg(LOGP_FLAW, "ERROR: hwIDsize=%d, expected %d\n",
			hwIDsize, sizeof(short) + sizeof(SnesHardwareID));
		return (kServerFuncAbort);
	}
	hwid = &state->loginData.hardwareID;
	memset((char *)hwid, 0, sizeof(HardwareID));	// unused must be 0-filled
	Server_TReadDataSync( state->session, sizeof(char),
		(Ptr)&hwid->hardwareIDtype);
	PLogmsg(LOGP_DBUG, "HWID type=%d\n", hwid->hardwareIDtype);
	if (hwid->hardwareIDtype != kHWID_DallasTouch)
		PLogmsg(LOGP_FLAW, "My hardwareID is very strange!\n");	// non-fatal

	Server_TReadDataSync( state->session, sizeof(short),
		(Ptr)&hwid->hwid.snesHWID.snesHardwareIDerror);
	Server_TReadDataSync( state->session, sizeof(SnesHardwareID),
		(Ptr)&hwid->hwid.snesHWID.snesHardwareID);
	Common_LogHardwareID(hwid);

	Server_IgnoreSimulatorHWID(state);

	// Read the nasty flags.
	//
	Server_TReadDataSync( state->session, sizeof(long),
		(Ptr)&state->loginData.nastyFlags);
	Logmsg("Nasty flags: 0x%.8lx\n", state->loginData.nastyFlags);

	PLogmsg(LOGP_PROGRESS, "Server_snes_ReceiveLogin done\n");
	return(kServerFuncOK);
}


//
// Want to ignore hardwareID values from a simulator... otherwise everybody
// using one will end up getting restored to the same account.
//
// Returns true if it ignored the hwid (by changing the hardwareIDtype to
// kHWID_Simulator), false otherwise.
//
PRIVATE int
Server_IgnoreSimulatorHWID(ServerState *state)
{
	if (Server_BoxIsSimulator(state)) {
		Logmsg("NOTE: hwid indicates SNES simulator\n");
		// save a copy of the real type
		state->loginData.realHardwareIDtype =
			state->loginData.hardwareID.hardwareIDtype;
		// set the type to "no HWID"
		state->loginData.hardwareID.hardwareIDtype = kHWID_NoHWID;
		return (true);
	}

	return (false);
}


//
// Stuff common to Genesis and SNES.
//
PRIVATE Err
Server_common_ReceiveLogin(ServerState *state)
{
	long			totalFree, maxFree;
	register short	a;
	unsigned char 	opCode;

	if(Server_TReadDataSync(state->session, 1, (Ptr)&opCode) != noErr)
		return(kServerFuncAbort);

	if(opCode != msLogin){
		// fucked
		PLogmsg(LOGP_FLAW, "Wrong opCode.  Expected %d, got %d\n",
			msLogin, opCode);
		return(kServerFuncAbort);
	}

	Server_TReadDataSync(state->session, sizeof(long),
		(Ptr)&state->boxOSState.osFree );
	Server_TReadDataSync(state->session, sizeof(long),
		(Ptr)&state->boxOSState.dbFree );

	Server_TReadDataSync(state->session, sizeof(long),
        (Ptr)&state->boxOSState.boxFlags );

	Server_TReadDataSync(state->session, sizeof(long),
		(Ptr)&state->boxOSState.lastBoxState );

	Server_TReadDataSync(state->session, sizeof(phoneNumber),
		(Ptr)&state->boxPhoneNumber );
	state->boxPhoneNumber.phoneNumber[kPhoneNumberSize - 1] = 0;
	Common_PhoneXlateYonToHither(state, state->boxPhoneNumber.phoneNumber);

	Server_TReadDataSync( state->session, sizeof(userIdentification),
		(Ptr)(Ptr)&state->loginData.userID);
	state->loginData.userID.userName[kUserNameSize - 1] = 0;

	// Put the little fucker under a magnifying glass.
	//
	if (state->loginData.userID.box.box == gConfig.magnifyDebug) {
		PLogmsg(LOGP_FLAW, "***** MAGNIFY %d *****\n", gConfig.magnifyDebug);
		gConfig.logWriteThresh = 0;
		gConfig.logFlushThresh = 0;
		state->magnifyMode = true;
	}

	Server_TReadDataSync( state->session, sizeof(short),
		(Ptr)&state->loginData.numMailsInBox);

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	if ( state->platformID == kPlatformSJNES ) {
		ASSERT_MESG(state->loginData.numMailsInBox <= 8,
							"Fatal Box Error: numMailsInBox must be <= 8");
	} else {
	ASSERT_MESG(state->loginData.numMailsInBox <= kMaxInBoxEntries,
		"Fatal Box Error: numMailsInBox must be <= kMaxInBoxEntries");
	}

	for (a = 0; a < state->loginData.numMailsInBox; a++) {
		Server_TReadDataSync( state->session, sizeof(short),
			(Ptr)&state->loginData.mailSerialNumbers[a]);
	}

	Server_TReadDataSync( state->session, sizeof(long),
		(Ptr)&state->loginData.validationToken);

	state->validFlags |= kServerValidFlag_BoxPhoneNumber;
	state->validFlags |= kServerValidFlag_Login;

	//
	// Read is done, now print it out.
	//

  	Logmsg("UserID box serial number = (%ld,%ld)[%d]\n",
		state->loginData.userID.box.box, state->loginData.userID.box.region,
		state->loginData.userID.userID);
	Logmsg(" User name = '%s'\n", state->loginData.userID.userName);
	Logmsg(" Home town = %s\n", state->loginData.userID.userTown);
	Logmsg(" Box flags = %ld\n", state->boxOSState.boxFlags);
	Logmsg(" Validation token = %ld\n", state->loginData.validationToken);
	Logmsg(" Phone number = %s\n", state->boxPhoneNumber.phoneNumber);
	Logmsg(" Num mails in box = %ld\n", (long)state->loginData.numMailsInBox);
	for (a = 0; a < state->loginData.numMailsInBox; a++)
		Logmsg("    serialno: %ld\n", (long)state->loginData.mailSerialNumbers[a]);

	totalFree = state->boxOSState.osFree >> 16;
	maxFree = state->boxOSState.osFree & 0xffff;
	Logmsg(" OS total free / DB stable = %ld, max free memory = %ld.\n",
		totalFree, maxFree);

	totalFree = state->boxOSState.dbFree >> 16;
	maxFree = state->boxOSState.dbFree & 0xfffe;	// clear the last bit
	Logmsg(" DB total free memory = %ld, max free memory = %ld\n",
		totalFree, maxFree);


	/*
	kCurUserAcceptsChallenges		= 0x01,
	kCurUserMoved					= 0x02,
	kOSHeapTrashed					= 0x04,
	kDBHeapTrashed					= 0x08,
	kBoxIDTrashed					= 0x10,
	kQwertyKeyboard					= 0x20,		// NOT USED IN SEGA ROM 1.0
	kCallWaitingEnabled				= 0x40,		// NOT USED IN SEGA ROM 1.0

	kPatchWasSplit					= 0x80,		//      SEGA ROM 1.1
	kFAXMachineDetected				= 0x100		//      SEGA ROM 1.1
	*/

    Logmsg("Box login flags (0x%.8lx): '%.4s' ID-%s OS-%s DB-%s\n",
        state->boxOSState.boxFlags,
        (char *)&state->platformID,     // make ASCII stat gen easier
        (state->boxOSState.boxFlags & kBoxIDTrashed) ? "BAD" : "ok",
        (state->boxOSState.boxFlags & kOSHeapTrashed) ? "BAD" : "ok",
        (state->boxOSState.boxFlags & kDBHeapTrashed) ? "BAD" : "ok");

	//
	// Print out what the various other boxFlags mean.
	//
	if(state->boxOSState.boxFlags & kCurUserMoved)
		Logmsg(" Box is dialing 1-800 because it has moved\n");
	if(state->boxOSState.boxFlags & kCurUserAcceptsChallenges)
		Logmsg(" User does not accept challenges\n");
	else
		Logmsg(" User accepts challenges\n");
	if(state->boxOSState.boxFlags & kFAXMachineDetected)
		Logmsg(" FAX was detected on last master peer connect\n");
	if (state->boxOSState.boxFlags & kPatchWasSplit)
		Logmsg(" Split patch stuff was used\n");

	// Constants are from BoxSer.h, except for a few that were defined
	// after the ROM freeze.
	//

	Logmsg("lastBoxState 0x%.8lx:\n", state->boxOSState.lastBoxState);
	if (state->boxOSState.lastBoxState & kServerConnect)
		Logmsg("  kServerConnect\n");
	if (state->boxOSState.lastBoxState & kPeerConnect)
		Logmsg("  kPeerConnect\n");
	if (state->boxOSState.lastBoxState & kListeningForPeerConnection)
		Logmsg("  kListeningForPeerConnection\n");
	if (state->boxOSState.lastBoxState & kInitiatingGame)
		Logmsg("  kInitiatingGame\n");
	if (state->boxOSState.lastBoxState & kPlayingGame)
		Logmsg("  kPlayingGame\n");
	if (state->boxOSState.lastBoxState & kDuringLocalCallWaiting)
		Logmsg("  kDuringLocalCallWaiting\n");
	if (state->boxOSState.lastBoxState & kDuringRemoteCallWaiting)
		Logmsg("  kDuringRemoteCallWaiting\n");
	if (state->boxOSState.lastBoxState & 0x00000080)
		Logmsg("  (unused -- bug!)\n");
	if (state->boxOSState.lastBoxState & kUsedSmartCardForConnectState)
		Logmsg("  kUsedSmartCardForConnectState\n");
	if (state->boxOSState.lastBoxState & kSlaveTimedOut)
		Logmsg("  kSlaveTimedOut\n");
	if (state->boxOSState.lastBoxState & kPeerConnectFailed)
		Logmsg("  kPeerConnectFailed\n");
	if (state->boxOSState.lastBoxState & kPlayingSinglePlayerGame)
		Logmsg("  kPlayingSinglePlayerGame\n");

	return(kServerFuncOK);
}

