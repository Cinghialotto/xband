/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_ReceiveSystemVersion.c,v 1.5 1996/01/25 17:53:31 hufft Exp $
 *
 * $Log: Server_ReceiveSystemVersion.c,v $
 * Revision 1.5  1996/01/25  17:53:31  hufft
 * added UDP based connections
 *
 * Revision 1.4  1995/11/09  17:15:51  jhsia
 * Set the OS version if it's an 'sjne' box (no longer JAPAN_TESTING only).
 *
 * Revision 1.3  1995/10/26  03:40:27  jhsia
 * For JAPAN_TESTING, force the OS version to be 4
 *
 * Revision 1.2  1995/05/28  20:19:23  jhsia
 * switch to rcs keywords
 *
 */


/*
	File:		Server_ReceiveSystemVersion.c

	Contains:	Server get box's system version function

	Written by:	Dave Jevans


	Change History (most recent first):

		 <9>	 9/19/94	ATM		PLogmsg stuff.
		 <8>	 8/12/94	ATM		Converted to Logmsg.
		 <7>	 7/20/94	DJ		added Server_Comm stuff
		 <6>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		 <5>	 7/12/94	DJ		using Server_TCheckError(state->session) instead of TCheckError
		 <4>	  7/1/94	DJ		making server handle errors from the comm layer
		 <3>	  6/9/94	BET		Fix hairy compiles based on TransportSlayer.h
		 <2>	  6/4/94	DJ		making everything take a ServerState instead of SessionRec
	To Do:
*/

#include "ServerCore.h"
#include "Server.h"
#include "Messages.h"
#include "UsrConfg.h"
#include "Server_Comm.h"
#include <stdio.h>



int Server_ReceiveSystemVersion(ServerState *state)
{
unsigned char	opCode;

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveSystemVersion\n");

	if(Server_TReadDataSync(state->session, 1, (Ptr)&opCode ) != noErr)
		return(kServerFuncAbort);

	if(opCode != msSystemVersion){
		// fucked
		PLogmsg(LOGP_FLAW, "Wrong opCode.  Expected %d, got %d\n",
			msSystemVersion, opCode);
		return(kServerFuncAbort);
	}
	Server_TReadDataSync( state->session, 2, (Ptr)&state->systemVersionData.length );
	Server_TReadDataSync( state->session, 4, (Ptr)&state->systemVersionData.version );

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	state->validFlags |= kServerValidFlag_SystemVersion;

	// Hack to avoid pounding 'sjne' boxes with news.
	//
	if ((state->platformID == kPlatformSJNES) &&
		(state->systemVersionData.version < 4))
	{
		state->systemVersionData.version = 4;
		PLogmsg(LOGP_NOTICE, "WARNING: %.4s OS version set to 4\n",
			(char *)&state->platformID);
	}
	
	Logmsg("SystemVersion: length = %d, version = %ld\n",
		state->systemVersionData.length, state->systemVersionData.version);
	PLogmsg(LOGP_PROGRESS, "Server_ReceiveSystemVersion done\n");

	return(kServerFuncOK);
}

/*
void DoSendSystemVersionOpCode( void * notUsed )
{
messOut		sendDummy;
short		length;
long		versionVersion;

	sendDummy = msSystemVersion;
	SendNetDataASync( msOutgoingOpCodeSize, (Ptr)&sendDummy );
	length = sizeof( versionVersion );
	SendNetDataASync( 2, (Ptr)&length );
	versionVersion = 0;
	SendNetDataASync( 4, (Ptr)&versionVersion );
}
*/

