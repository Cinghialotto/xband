/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_ReceiveNGP.c,v 1.2 1995/05/28 20:19:21 jhsia Exp $
 *
 * $Log: Server_ReceiveNGP.c,v $
 * Revision 1.2  1995/05/28  20:19:21  jhsia
 * switch to rcs keywords
 *
 */


/*
	File:		Server_ReceiveNGP.c

	Contains:	Server receive NGP function

	Written by:	Dave Jevans


	Change History (most recent first):

		 <9>	 9/19/94	ATM		PLogmsg stuff.
		 <8>	 8/12/94	ATM		Converted to Logmsg.
		 <7>	 7/20/94	DJ		added Server_Comm stuff
		 <6>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		 <5>	  7/1/94	DJ		making server handle errors from the comm layer
		 <4>	  6/9/94	BET		Fix hairy compiles based on TransportSlayer.h
		 <3>	  6/4/94	DJ		making everything take a ServerState instead of SessionRec
		 <2>	  6/1/94	DJ		removed byte gobbler
		 <1>	 5/25/94	DJ		first checked in
	To Do:
*/

#include "ServerCore.h"
#include "Server.h"
#include "Messages.h"
#include "UsrConfg.h"
#include "Server_Comm.h"
#include <stdio.h>


int Server_ReceiveNGP(ServerState *state)
{
unsigned char 	opCode;

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveNGP\n");

	if(Server_TReadDataSync( state->session, 1, (Ptr)&opCode ) != noErr)
		return(kServerFuncAbort);

	if(opCode != msSendNGPVersion){
		// fucked
		PLogmsg(LOGP_FLAW, "Wrong opCode.  Expected %d, got %d\n",
			msSendNGPVersion, opCode);
		return(kServerFuncAbort);
	}

	if(Server_TReadDataSync( state->session, 4, (Ptr)&state->NGPVersion ) != noErr)
		return(kServerFuncAbort);

	state->validFlags |= kServerValidFlag_NGPVersion;

	Logmsg("NGP Version = %ld\n", state->NGPVersion);
	PLogmsg(LOGP_PROGRESS, "Server_ReceiveNGP done\n");

	return(kServerFuncOK);
}

/*
void DoSendNGPVersionOpCode( void * notUsed )
{
messOut	sendDummy;
long	NGPVersion;

	NGPVersion = GetNGPVersion();
	sendDummy = msSendNGPVersion;
	SendNetDataASync( msOutgoingOpCodeSize, (Ptr)&sendDummy );
	SendNetDataASync( 4, (Ptr)&NGPVersion );
}
*/

