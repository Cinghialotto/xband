/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_ReceiveSendQ.c,v 1.18 1995/11/29 21:29:55 chs Exp $
 *
 * $Log: Server_ReceiveSendQ.c,v $
 * Revision 1.18  1995/11/29  21:29:55  chs
 * Rename variable "index" to quiet warnings.
 *
 * Revision 1.17  1995/11/22  14:38:19  ansell
 * Made it so when we skip a mail messages due to bad compression we don't
 * leave a hole in the list of mail messages.
 *
 * Revision 1.16  1995/11/17  14:37:05  ansell
 * Don't free memory that was already free'd stupid!
 *
 * Revision 1.15  1995/11/15  16:17:06  ansell
 * Changed so that a mail message that we failed to expand doesn't end the
 * connection, but just sends the user a dialog saying that we couldn't
 * deliver that message and proceeds.
 *
 * Revision 1.14  1995/11/10  16:08:46  ansell
 * Initialized some memory.
 *
 * Revision 1.13  1995/11/07  23:50:43  ansell
 * Initialized a variable (not that it will fix my problem).
 *
 * Revision 1.12  1995/09/13  14:16:16  ted
 * Fixed warnings.
 *
 * Revision 1.11  1995/07/26  13:56:39  ansell
 * Initialize sendQ list to '0' after allocating in case send-up bails out.
 *
 * Revision 1.10  1995/07/12  17:32:25  ansell
 * Set oldMatchupRegurg to SendQ item to avoid multiple searches later on.
 *
 * Revision 1.9  1995/05/28  20:19:22  jhsia
 * switch to rcs keywords
 *
 */


/*
	File:		Server_ReceiveSendQ.c

	Contains:	Server receive whatever is in the box's send queue

	Written by:	Dave Jevans


	Change History (most recent first):

		<27>	10/13/94	DJ		Setting state->crashRecord to point to the crashrec if it comes
									in on the SendQ.
		<26>	 9/19/94	ATM		PLogmsg stuff.
		<25>	  9/3/94	ATM		Set a string to keep random chars out of log.
		<24>	 8/28/94	ATM		Mail update for segb.
		<23>	 8/26/94	ATM		Added bulletproofing to mail; long "to" and "title" line were
									hosing us.
		<22>	 8/25/94	ATM		Added some more logging stuff.
		<21>	 8/20/94	DJ		serverUniqueID is in playerinfo, not userIdentification
		<20>	 8/20/94	DJ		receiveaddressverifications2 handles addr verif only for the
									current user
		<19>	 8/12/94	ATM		Converted to Logmsg.
		<18>	  8/5/94	DJ		added kserverflagvalid_addrbook
		<17>	  8/5/94	DJ		all new addr book poo
		<16>	  8/4/94	DJ		no more SNDQElement
		<15>	  8/3/94	DJ		minor tweak to receiving addr book stuff
		<14>	  8/2/94	DJ		updated to latest mail sending scheme
		<13>	 7/20/94	DJ		added Server_Comm stuff
		<12>	 7/18/94	DJ		new addr book stuff
		<11>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		<10>	 7/14/94	DJ		receiving mail
		 <9>	  7/8/94	DJ		i don't remember
		 <8>	  7/6/94	DJ		added Server_ReceiveAddressBookValidationQueries
		 <7>	  7/3/94	DJ		error tolerant
		 <6>	  7/1/94	DJ		making server handle errors from the comm layer
		 <5>	 6/30/94	DJ		updated to new sendq format
		 <4>	  6/9/94	BET		Fix hairy compiles based on TransportSlayer.h
		 <3>	  6/4/94	DJ		making everything take a ServerState instead of SessionRec
		 <2>	  6/1/94	DJ		wasn't mallocing enuf mems!
		 <1>	 5/25/94	DJ		first checked in
	To Do:
*/

#include <stdio.h>
#include <memory.h>
#include <stdlib.h>
#include <strings.h>
#include "ServerState.h"
#include "Server.h"
#include "Server_Comm.h"
#include "Common.h"
#include "Common_PlatformID.h"
#include "MegaPack.h"
#include "Common_Missing.h"

#include "Messages.h"
#include "UsrConfg.h"

PRIVATE unsigned char Server_ReceiveVariable(ServerState *state);
PRIVATE Err Server_ReceiveNewsControl(ServerState *state);

int Server_ReceiveSendQ(ServerState *state)
{

unsigned char 	opCode;
long i;

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveSendQ\n");

	if(Server_TReadDataSync( state->session, 1, (Ptr)&opCode ) != noErr)
		return(kServerFuncAbort);

	if(opCode != msSendSendQElements){
		// fucked
		return(kServerFuncAbort);
	}
	
	if(Server_TReadDataSync( state->session, sizeof(short), (Ptr)&state->sendQData.count ) != noErr)
		return(kServerFuncAbort);
		
	Logmsg("SendQ receiving %ld items\n", (long)state->sendQData.count);
	
	if(state->sendQData.count < 1)
	{
		state->sendQData.items = NULL;
		return(kServerFuncOK);
	}

	state->sendQData.items = (QItem *)malloc(state->sendQData.count * sizeof(QItem));
	if(!state->sendQData.items){
		// majorly fucked... out of memory
		PLogmsg(LOGP_FLAW, "Out of memory.. fucked!\n");
		return(kServerFuncAbort);
	}

	// Initialize so if we bail reading sendQ we don't dump during cleanup
	memset(state->sendQData.items, 0, state->sendQData.count * sizeof(QItem));
	state->validFlags |= kServerValidFlag_SendQ;

	for(i = 0; i < state->sendQData.count; i++)
	{
		if(Server_TReadDataSync( state->session, sizeof(DBID), (Ptr)&state->sendQData.items[i].theID ) != noErr)
			return(kServerFuncAbort);
		if(Server_TReadDataSync( state->session, sizeof(long), (Ptr)&state->sendQData.items[i].size ) != noErr)
			return(kServerFuncAbort);
		state->sendQData.items[i].data = (unsigned char *)malloc(state->sendQData.items[i].size);
		if(!state->sendQData.items[i].data){
			// majorly fucked
			PLogmsg(LOGP_FLAW, "Out of memory reading a SendQ item\n");
			return(kServerFuncAbort);
		}
		
		if(Server_TReadDataSync(state->session, 
						state->sendQData.items[i].size, 
						(Ptr)state->sendQData.items[i].data ) != noErr)
			return(kServerFuncAbort);

		Logmsg("SendQ item %d: dbid %ld, size %ld\n", i,
			(long)state->sendQData.items[i].theID,
			state->sendQData.items[i].size);

		//
		// If the item was a CrashRecord, set state->crashRecord so Server_RestoreBox can work.
		//
		if(state->sendQData.items[i].theID == kRestartInfoType)
		{
			ASSERT_MESG(state->crashRecord == NULL, "Server_ReceiveSendQ received two crashRecords for a single connect!  This is impossible, so ServerState must not have been cleared in SunSega.");
			state->crashRecord = (BoxRestartInfo *)state->sendQData.items[i].data;
		}
		else if (state->sendQData.items[i].theID == kMatchupRegurgQElement)
		{
			ASSERT_MESG(state->oldMatchupRegurg == NULL, "Server_ReceiveSendQ received two matchupRegurg records for a single connect!  This is impossible, so ServerState must not have been cleared in SunSega.");
			if (state->sendQData.items[i].size != sizeof(MatchupRegurg))
			{
				Logmsg("Server_ReceiveSendQ: got %d bytes, expected %d\n",
					   state->sendQData.items[i].size, sizeof(MatchupRegurg));
			}
			else
			{
				state->oldMatchupRegurg = 
					(MatchupRegurg *)state->sendQData.items[i].data;
			}
		}
	}

	// Want to show StreamErrorReports early on to diagnose boxes that just
	// bail for no apparent reason, so put it in the log now.
	//
	Server_DumpStreamErrorReport(state);

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveSendQ done\n");

	return(kServerFuncOK);
}


//
// 8/19/94.
// This new version supports update addr book only for current user.
//
int Server_ReceiveAddressBookValidationQueries2(ServerState *state)
{
unsigned char 	opCode, length;
short 	i;

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveAddressBookValidationQueries\n");

	if(Server_TReadDataSync( state->session, 1, (Ptr)&opCode ) != noErr)
		return(kServerFuncAbort);

	if(opCode != msSendAddressesToVerify){
		// fucked
		return(kServerFuncAbort);
	}

	if(Server_TReadDataSync( state->session, sizeof(short), (Ptr)&state->addrValidationData.count ) != noErr)
		return(kServerFuncAbort);

	state->validFlags |= kServerValidFlag_AddressBook;

	Logmsg("Receiving %ld addr book items\n",
		(long)state->addrValidationData.count);

	if(state->addrValidationData.count < 1)
	{
		state->addrValidationData.items = NULL;
		return(kServerFuncOK);
	}

	state->addrValidationData.items = (AddrValidItem *)malloc(state->addrValidationData.count * sizeof(AddrValidItem));
	if(!state->addrValidationData.items){
		// majorly fucked... out of memory
		PLogmsg(LOGP_FLAW, "Out of memory.. fucked!\n");
		return(kServerFuncAbort);
	}

	for(i = 0; i < state->addrValidationData.count; i++)
	{
		state->addrValidationData.items[i].ownerUserID = state->loginData.userID.userID;

		if(Server_TReadDataSync( state->session, sizeof(unsigned char), (Ptr)&state->addrValidationData.items[i].serverUniqueID ) != noErr)
			return(kServerFuncAbort);

		if (state->addrValidationData.items[i].serverUniqueID == kUncorrelatedEntry)
		{
			if(Server_TReadDataSync( state->session, sizeof(BoxSerialNumber), (Ptr)&state->addrValidationData.items[i].userIdent.box ) != noErr)
				return(kServerFuncAbort);
			if(Server_TReadDataSync( state->session, sizeof(unsigned char), (Ptr)&state->addrValidationData.items[i].userIdent.userID ) != noErr)
				return(kServerFuncAbort);

			if(state->addrValidationData.items[i].userIdent.box.box == -1)
			{
				if(Server_TReadDataSync( state->session, sizeof(char), (Ptr)&length ) != noErr)
					return(kServerFuncAbort);
				if(Server_TReadDataSync( state->session, (long)length, (Ptr)state->addrValidationData.items[i].userIdent.userName ) != noErr)
					return(kServerFuncAbort);
	
				ASSERT_MESG(length <= kUserNameSize, "why is length bigger than the name field?  memory trasher!");

				if(length >= kUserNameSize)	// NULL terminate cuz box doesn't send the NULL
					length = kUserNameSize - 1;

				state->addrValidationData.items[i].userIdent.userName[length] = 0;
			}
		}
	}

	PLogmsg(LOGP_PROGRESS,
		"Server_ReceiveAddressBookValidationQueries done.  Read %ld items\n",
		(long)state->addrValidationData.count);

	return(kServerFuncOK);
}


#ifdef NOT_USED
int Server_ReceiveAddressBookValidationQueries(ServerState *state)
{
unsigned char 	opCode, length, ownerUserID;
short 	i, j;
short	numForThisUser;

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveAddressBookValidationQueries\n");

	if(Server_TReadDataSync( state->session, 1, (Ptr)&opCode ) != noErr)
		return(kServerFuncAbort);

	if(opCode != msSendAddressesToVerify){
		// fucked
		return(kServerFuncAbort);
	}

	if(Server_TReadDataSync( state->session, sizeof(short), (Ptr)&state->addrValidationData.count ) != noErr)
		return(kServerFuncAbort);

	state->validFlags |= kServerValidFlag_AddressBook;

	Logmsg("Receiving %ld addr book validation items\n",
		(long)state->addrValidationData.count);

	if(state->addrValidationData.count < 1)
	{
		state->addrValidationData.items = NULL;
		return(kServerFuncOK);
	}

	state->addrValidationData.items = (AddrValidItem *)malloc(state->addrValidationData.count * sizeof(AddrValidItem));
	if(!state->addrValidationData.items){
		// majorly fucked... out of memory
		PLogmsg(LOGP_FLAW, "Out of memory.. fucked!\n");
		return(kServerFuncAbort);
	}

	for(i = 0; i < state->addrValidationData.count; )
	{
		if(Server_TReadDataSync( state->session, sizeof(char), (Ptr)&ownerUserID ) != noErr)
			return(kServerFuncAbort);
		if(Server_TReadDataSync( state->session, sizeof(short), (Ptr)&numForThisUser ) != noErr)
			return(kServerFuncAbort);

		for(j = 0; j < numForThisUser; j++, i++)
		{
			state->addrValidationData.items[i].ownerUserID = ownerUserID;


			if(Server_TReadDataSync( state->session, sizeof(unsigned char), (Ptr)&state->addrValidationData.items[i].serverUniqueID ) != noErr)
				return(kServerFuncAbort);

			if (state->addrValidationData.items[i].serverUniqueID == kUncorrelatedEntry)
			{
				if(Server_TReadDataSync( state->session, sizeof(BoxSerialNumber), (Ptr)&state->addrValidationData.items[i].userIdent.box ) != noErr)
					return(kServerFuncAbort);
				if(Server_TReadDataSync( state->session, sizeof(unsigned char), (Ptr)&state->addrValidationData.items[i].userIdent.userID ) != noErr)
					return(kServerFuncAbort);

				if(state->addrValidationData.items[i].userIdent.box.box == -1)
				{
					if(Server_TReadDataSync( state->session, sizeof(char), (Ptr)&length ) != noErr)
						return(kServerFuncAbort);
					if(Server_TReadDataSync( state->session, (long)length, (Ptr)state->addrValidationData.items[i].userIdent.userName ) != noErr)
						return(kServerFuncAbort);
		
					ASSERT_MESG(length <= kUserNameSize, "why is length bigger than the name field?  memory trasher!");

					if(length >= kUserNameSize)	// NULL terminate cuz box doesn't send the NULL
						length = kUserNameSize - 1;

					state->addrValidationData.items[i].userIdent.userName[length] = 0;
				}
			}
		}
	}

	PLogmsg(LOGP_PROGRESS,
		"Server_ReceiveAddressBookValidationQueries done.  Read %ld items\n",
		(long)state->addrValidationData.count);

	return(kServerFuncOK);
}
#endif


//
// KON's a fucker.
//
// Some number of news control packets will come up immediately before the
// mail; catch and interpret them.
//
// Returns 0 on failure.  Should return msSendOutgoingMail on success.
//
// So far this only applies to 'snes'.  'segb' will get the mail packet
// immediately and just return.
//
PRIVATE unsigned char
Server_ReceiveVariable(ServerState *state)
{
	unsigned char opCode;

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveVariable\n");

	do {
		if (Server_TReadDataSync( state->session, 1, (Ptr)&opCode ) != noErr)
			return (0);

		switch (opCode) {
		case msDoSendNewsControls:
			if (Server_ReceiveNewsControl(state) != kNoError)
				return (0);
			break;
		case msSendOutgoingMail:
			break;
		default:
			PLogmsg(LOGP_NOTICE,
				"WARNING: unexpected opCode in Variable (%d)\n", opCode);
			return (opCode);
		}
	} while (opCode != msSendOutgoingMail);

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveVariable done\n");
	return (opCode);
}


//
// Receive the news control info.
//
PRIVATE Err
Server_ReceiveNewsControl(ServerState *state)
{
	unsigned char user;
	short count;
	char paperNum;
	char newsSettings[512];

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveNewsControl\n");

	if (Server_TReadDataSync( state->session, sizeof(unsigned char),
		(Ptr)&user ) != noErr)
	{
		return(kServerFuncAbort);
	}
	if (Server_TReadDataSync( state->session, sizeof(char),
		(Ptr)&paperNum ) != noErr)
	{
		return(kServerFuncAbort);
	}
	if (Server_TReadDataSync( state->session, sizeof(short),
		(Ptr)&count ) != noErr)
	{
		return(kServerFuncAbort);
	}
	PLogmsg(LOGP_DBUG, "News Control: user %d, paperNum %d, count %d\n",
		user, paperNum, count);
	if (Server_TReadDataSync( state->session, count * sizeof(short),
		(Ptr)newsSettings ) != noErr)
	{
		return(kServerFuncAbort);
	}
	Loghexdump(newsSettings, count * sizeof(short));

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveNewsControl done\n");
	return (kNoError);
}


//
// Receive mail.
//
// Invokes Server_ReceiveVariable.
//
int Server_ReceiveMail(ServerState *state)
{
unsigned char 	opCode;
short			i, indx, toSize, titleSize, messageSize;
Mail			m;
char			tmpBuf[128];		// self-defense measure
int				err, badMessages = 0;
char			*tmpMessage = NULL;

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveMail\n");

	opCode = Server_ReceiveVariable(state);
	if (opCode != msSendOutgoingMail) {
		// fucked
		Logmsg("Wrong opCode after variable; expected %d, got %d\n",
			msSendOutgoingMail, opCode);
		return(kServerFuncAbort);
	}

	if (Server_TReadDataSync( state->session, sizeof(short),
		(Ptr)&state->incomingMail.count ) != noErr)
	{
		return(kServerFuncAbort);
	}

	state->validFlags |= kServerValidFlag_IncomingMail;

	if (state->incomingMail.count < 1)
	{
		state->incomingMail.mailItems = NULL;
		return(kServerFuncOK);
	}

	state->incomingMail.mailItems =
		(MailItem *)malloc(state->incomingMail.count * sizeof(MailItem));
	if (!state->incomingMail.mailItems) {
		PLogmsg(LOGP_FLAW, "out of mems in reading mail\n");
		return(kServerFuncAbort);
	}

	for (i = 0; i < state->incomingMail.count; i++)
		state->incomingMail.mailItems[i].mail = NULL;


	for (i = 0, indx = 0; i < state->incomingMail.count; i++) {
		memset(&m, 0, sizeof(Mail));
		m.from.box.box = -1;
		m.from.box.region = -1;
		if (Server_TReadDataSync( state->session,
									sizeof(unsigned char),
									(Ptr)&m.from.userID) != noErr)
			return(kServerFuncAbort);
		Logmsg("Mail from boxid = %d\n", m.from.userID);

		if (Server_TReadDataSync( state->session,
									sizeof(BoxSerialNumber),
									(Ptr)&m.to.box) != noErr)
			return(kServerFuncAbort);

		if (Server_TReadDataSync( state->session,
									sizeof(unsigned char),
									(Ptr)&m.to.userID) != noErr)
			return(kServerFuncAbort);

		if (Server_TReadDataSync( state->session,
									sizeof(short),
									(Ptr)&toSize) != noErr)
			return(kServerFuncAbort);

		if (toSize > 128) {
			PLogmsg(LOGP_FLAW, "ERROR: Mail toSize = %ld\n", (long)toSize);
			return (kServerFuncAbort);
		}
		if (Server_TReadDataSync( state->session,
									(long)toSize,
									(Ptr)tmpBuf /*(Ptr)&m.to.userName*/) != noErr)
			return(kServerFuncAbort);
		strncpy(m.to.userName, tmpBuf, kUserNameSize);
		m.to.userName[kUserNameSize-1] = '\0';
		strcpy(m.to.userTown, "(not set for mail)");	// for log file

		if (Server_TReadDataSync( state->session,
									sizeof(short),
									(Ptr)&titleSize) != noErr)
			return(kServerFuncAbort);

		// Don't want to lose the entire connection just because the title
		// size is longer than anticipated.  Read it all in then truncate it.
		//
		if (titleSize > 128) {
			PLogmsg(LOGP_FLAW, "ERROR: Mail titleSize = %ld\n", (long)titleSize);
			return (kServerFuncAbort);
		}
		if (Server_TReadDataSync( state->session,
									(long)titleSize,
									(Ptr)tmpBuf /*&m.title*/) != noErr)
			return(kServerFuncAbort);
		strncpy(m.title, tmpBuf, kTitleSize);
		m.title[kTitleSize-1] = '\0';

		err=Server_ReceiveOptCompressedString(state, &messageSize, &tmpMessage);
		if (err != kServerFuncOK)
		{
			char buf[256];

			sprintf(buf, 
				"Your XMail to \"%s\" titled \"%s\" could not be delivered.\n",
				m.to.userName, m.title);
			Server_SendDialog(state, buf, true);
			badMessages++;
			continue;
		}

		state->incomingMail.mailItems[indx].size = 
			sizeof(Mail) + messageSize -1;

		state->incomingMail.mailItems[indx].mail =
			(Mail *)malloc((long)state->incomingMail.mailItems[indx].size);
		if (!state->incomingMail.mailItems[indx].mail) {
			PLogmsg(LOGP_FLAW, "out of mem reading mail\n");
			return (kServerFuncAbort);
		}

		// Copy the boxser, usernum, and title.
		//
		*state->incomingMail.mailItems[indx].mail = m;

		// Now copy the message body in, and free the temporary string
		// returned by OptCompress.
		//
		strcpy(state->incomingMail.mailItems[indx].mail->message, tmpMessage);
		free(tmpMessage);
		indx++;
	}
	state->incomingMail.count -= badMessages;

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveMail done; received %ld items\n",
		(long)state->incomingMail.count);
	return(kServerFuncOK);
}

