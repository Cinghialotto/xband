/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_ReceiveDebitCard.c,v 1.8 1996/02/02 15:57:40 felix Exp $
 *
 * $Log: Server_ReceiveDebitCard.c,v $
 * Revision 1.8  1996/02/02  15:57:40  felix
 * Assigned card type to byte four of cardPrefix, as it was supposed to be
 * all along.
 *
 * Revision 1.7  1996/01/25  17:53:26  hufft
 * added UDP based connections
 *
 * Revision 1.6  1996/01/17  15:49:56  felix
 * Right shift of card serial number.
 *
 * Revision 1.5  1996/01/05  13:46:29  felix
 * Print debit card serial number in decimal
 *
 * Revision 1.4  1995/05/28  20:19:16  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_ReceiveDebitCard.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		<10>	 9/19/94	ATM		PLogmsg stuff.
		 <9>	 8/26/94	ATM		Added SEG8 versions for new as-yet-undefined XBANDCard struct.
		 <8>	 8/16/94	DJ		added receivecreditdebitinfointostruct
		 <7>	 8/12/94	ATM		Converted to Logmsg.
		 <6>	  8/2/94	DJ		free token is now in debitcardinfo not a separate lon
		 <5>	 7/29/94	DJ		more printf info
		 <4>	 7/27/94	DJ		CreditToken is now a long
		 <3>	 7/20/94	DJ		added Server_Comm stuff
		 <2>	 7/18/94	DJ		receiveCreditDebitInfo
		 <1>	 7/17/94	DJ		first checked in

	To Do:
*/

#include "ServerCore.h"
#include "Server.h"
#include "Messages.h"
#include "Server_Comm.h"
#include <stdio.h>

#include "SmartCard.h"


int Server_ReceiveCreditDebitInfo(ServerState *state)
{
int err;

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveCreditDebitInfo\n");

	err = Server_ReceiveCreditDebitInfoIntoStruct(state, &state->creditDebitInfo);

	if(err == kServerFuncOK)
	{
		state->validFlags |= kServerValidFlag_CreditDebitInfo;
	} else {
		Logmsg("RCDIIS returned %d\n", err);
	}
	PLogmsg(LOGP_PROGRESS, "Server_ReceiveCreditDebitInfo done\n");
	return(err);
}

//
// helper routine for Server_ReceiveCreditDebitInfo and Server_SendDebitSmartcard
//
int Server_ReceiveCreditDebitInfoIntoStruct(ServerState *state, CreditDebitInfo *creditDebitInfo)
{
unsigned char 	opCode;

	Server_TReadDataSync( state->session, sizeof(unsigned char), (Ptr)&opCode );
	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	if(opCode != msSendCreditDebitInfo){
		PLogmsg(LOGP_FLAW, "Wrong opCode.  Expected %d, got %d\n",
			msSendCreditDebitInfo, opCode);
		return(kServerFuncAbort);
	}

	Server_TReadDataSync( state->session, sizeof(unsigned char), (Ptr)&creditDebitInfo->usingType );

	switch(creditDebitInfo->usingType)
	{
		case kUsingCreditToken:
			Server_TReadDataSync( state->session, sizeof(XBANDCard), (Ptr)&creditDebitInfo->debitCardInfo );
			Logmsg("Credit Token %ld\n", (long)creditDebitInfo->debitCardInfo.token);
			break;
		case kUsingDebitCard:
			Server_TReadDataSync( state->session, sizeof(XBANDCard),
				(Ptr)&creditDebitInfo->debitCardInfo );

			// Shift serialNumber right 8 bits to get rid of CRC.
			creditDebitInfo->debitCardInfo.serialNumber >>= 8;

			// Make creditDebitInfo->debitCardInfo.type what it's
			// supposed to be (Byte 4 from the card)
			creditDebitInfo->debitCardInfo.type = 
				creditDebitInfo->debitCardInfo.cardPrefix & 0x000000FF;

			Logmsg("SmartCard: token=0x%.8lx, type=%d, rechargesLeft=%d\n",
				creditDebitInfo->debitCardInfo.token,
				creditDebitInfo->debitCardInfo.type,
				creditDebitInfo->debitCardInfo.rechargesLeft);
			Logmsg("           creditsLeft=%d, problem=%d, pad=%d\n",
				creditDebitInfo->debitCardInfo.creditsLeft,
				creditDebitInfo->debitCardInfo.problem,
				creditDebitInfo->debitCardInfo.pad[0]);
			Logmsg("           serialNumber=0x%.8lx (%ld), cardPrefix= 0x%.8lx (%d), reserved=%d\n",
				creditDebitInfo->debitCardInfo.serialNumber,
				creditDebitInfo->debitCardInfo.serialNumber,
				creditDebitInfo->debitCardInfo.cardPrefix,
				creditDebitInfo->debitCardInfo.cardPrefix,
				creditDebitInfo->debitCardInfo.reserved);
			break;
		
		case kUsingCreditCard:
			Logmsg("Using credit card account\n");
			break;
		
		default:
			PLogmsg(LOGP_FLAW, "Unknown usingType #%ld!  Kill the connection.\n", creditDebitInfo->usingType);
			return(kServerFuncAbort);
			break;
	}

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	return(kServerFuncOK);
}

