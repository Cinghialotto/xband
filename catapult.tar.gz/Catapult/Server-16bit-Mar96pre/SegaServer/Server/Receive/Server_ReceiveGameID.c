/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_ReceiveGameID.c,v 1.16 1996/01/25 17:53:27 hufft Exp $
 *
 * $Log: Server_ReceiveGameID.c,v $
 * Revision 1.16  1996/01/25  17:53:27  hufft
 * added UDP based connections
 *
 * Revision 1.15  1995/09/26  10:33:36  ansell
 * Added special case handling for the possibility of a Sega box with it's
 * OS version set to 3, but with an actual version much higher (when they
 * loose their DB) getting out of sync with the server's data stream.
 *
 * Revision 1.14  1995/09/13  14:16:13  ted
 * Fixed warnings.
 *
 * Revision 1.13  1995/08/17  14:53:25  fadden
 * Added byte-swapping on localGameError and errorRecovers in both gameResults
 * and gameErrorResults.  Removed sn00 compatibility routine.
 *
 * Revision 1.12  1995/08/16  17:24:45  ansell
 * Added code so that after patch 92 sega will receive wins/losses info from
 * the box and set it into state struct like snes does already.
 *
 * Revision 1.11  1995/08/16  13:05:49  ansell
 * Set the matchWins/matchLosses in the server state struct when sent up.
 *
 * Revision 1.10  1995/07/31  21:29:45  fadden
 * Tweaked a logmsg.
 *
 * Revision 1.9  1995/07/17  18:41:59  fadden
 * LRA: #ifdefed out neterr printing code.  Removed some crufty stuff.
 *
 * Revision 1.8  1995/07/10  21:14:25  rich
 * Wrapped server dialog string with gettext() for message catalog lookup.
 *
 * Revision 1.7  1995/06/27  21:52:55  fadden
 * Emergency fix for boxes with hosed SNES game results.
 *
 * Revision 1.6  1995/05/28  20:19:17  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_ReceiveGameID.c

	Contains:	Server get gameID function

	Written by:	Dave Jevans


	Change History (most recent first):

		<40>	11/11/94	ATM		Screen & display server-specific errors separately.
		<39>	 11/1/94	ATM		Added unused1 and unused2 to 800 error printing.
		<38>	10/31/94	ATM		Print X.25 unused2 as ctsTimeouts.
		<37>	10/24/94	ATM		#ifdefed out old neterr stuff.  Print X.25 unused1 as
									usedAltPOP.
		<36>	10/20/94	ATM		Make printing of gameID meaningful.
		<35>	10/20/94	ATM		Print message to log and dump a few bytes when gameResult is
									whacked.
		<34>	10/19/94	ATM		Moved DumpGameResults to Server_GameSpecific.
		<33>	10/19/94	ATM		Don't print the net error records if it looks like a new box
									(box serial # trashed).
		<32>	10/17/94	ATM		Moved game-specific stuff into GameSpecific.c.  Added call to
									Server_DumpGameResult.
		<31>	10/14/94	ATM		Added NHLHockey stuff.
		<30>	10/12/94	ATM		MPW bit me.
		<29>	10/12/94	ATM		Removed recoveryCount.
		<28>	10/11/94	ATM		Use NewGameResult to show errors.
		<27>	10/10/94	ATM		Rearrange definition of GameResult.
		<26>	 10/9/94	ATM		Make it even prettier.
		<25>	 10/8/94	ATM		Pretty-print MK game results.
		<24>	 9/24/94	ATM		Adjust calculation so we don't print four bytes past end of
									GameResult struct.
		<23>	 9/19/94	ATM		PLogmsg stuff.  Added some new messages for DJ's tool.
		<22>	 9/16/94	ATM		Made net errors log to LOG_NETERR.
		<21>	  9/3/94	ATM		Spiffed up the game results a bit.
		<20>	  9/1/94	ATM		Send game result stuff to LOG_GAMERESULT.
		<19>	 8/25/94	BET		Add support for multiple NetErrorRecord types for both X25 and
									800 services.
		<18>	 8/24/94	BET		Add packetRetransError field to log.
		<17>	 8/24/94	ATM		Moved stuff into DumpGameResults(), and now dump game error
									results as well.
		<16>	 8/23/94	ATM		Splat.
		<15>	 8/23/94	ATM		Added debugging stuff for receiving game results.
		<14>	 8/19/94	BET		Fix Server_ReceiveGameResults to recieve the gameResult based on
									the size field.
		<13>	 8/18/94	BET		Add BoxNet dump.
		<12>	 8/17/94	ATM		Added NBA Jam rev 2 to internal list.
		<11>	 8/13/94	BET		Add Server_RecieveNetErrors
		<10>	 8/12/94	ATM		Converted to Logmsg.
		 <9>	  8/4/94	DJ		Server_ReceiveGameErrorResults
		 <8>	 7/20/94	DJ		added Server_Comm stuff
		 <7>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		 <6>	 7/12/94	DJ		using Server_TCheckError(state->session) instead of TCheckError
		 <5>	  7/1/94	DJ		making server handle errors from the comm layer
		 <4>	 6/11/94	DJ		printf of which game is being played
		 <3>	  6/9/94	BET		Fix hairy compiles based on TransportSlayer.h
		 <2>	  6/4/94	DJ		making everything take a ServerState instead of SessionRec
	To Do:
*/

#include <stdio.h>
#include <malloc.h>
#include "ServerCore.h"
#include "Server.h"
#include "Messages.h"
#include "Server_Comm.h"
#include "Common.h"
#include "GameDB.h"


PRIVATE int Server_common_ReceiveGameResults(ServerState *state, int *none);
PRIVATE void Server_LogNetErrors(ServerState *state, int has800, int hasX25);
#ifdef UNUSED
PRIVATE int Server_AreNetErrorsOkay(NetErrorRecord *ner);
PRIVATE int Server_PrintServerNetErrors(NetErrorRecord *ner, char *msg);
#endif


// ===========================================================================
//		GameID
// ===========================================================================

int Server_ReceiveGameID(ServerState *state)
{
unsigned char opCode;

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveGameID\n");

	Server_TReadDataSync( state->session, 1, (Ptr)&opCode );
	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	if(opCode != msGameIDAndPatchVersion){
		// fucked
		PLogmsg(LOGP_FLAW, "Wrong opCode.  Expected %d, got %d\n",
			msGameIDAndPatchVersion, opCode);
		return(kServerFuncAbort);
	}

	Server_TReadDataSync( state->session, sizeof(long), (Ptr)&state->gameIDData.gameID );
	Server_TReadDataSync( state->session, sizeof(long), (Ptr)&state->gameIDData.version );

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	state->validFlags |= kServerValidFlag_GameID;

	ASSERT(state->validFlags & kServerValidFlag_platformID);
	Logmsg("gameID = %.4s-0x%.8lx (%s), version = %ld\n",
		(char *)&state->platformID, state->gameIDData.gameID,
		Common_GameName(state->platformID, state->gameIDData.gameID),
		state->gameIDData.version);
	
	PLogmsg(LOGP_PROGRESS, "Server_ReceiveGameID done\n");
	return(kServerFuncOK);
}



// ===========================================================================
//		GameResults and GameErrorResults
// ===========================================================================

//
// Common routine; does most of the work for all platforms.
//
PRIVATE int
Server_common_ReceiveGameResults(ServerState *state, int *none)
{
unsigned char	opCode;
unsigned long	size;
GameResult		*gameResults;

	PLogmsg(LOGP_PROGRESS, "Server_common_ReceiveGameResults\n");
	*none = false;
	state->gameResult = nil;
	
	Server_TReadDataSync( state->session, 1, (Ptr)&opCode );
	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	if(opCode == msSendNoGameResults)
	{
		PLogmsg(LOGP_PROGRESS, "No Game Results to receive\n");
		*none = true;
		return(kServerFuncOK);
	}

	if(opCode != msSendGameResults){
		// fucked
		PLogmsg(LOGP_FLAW, "Wrong opCode.  Expected %ld or %ld, got %ld\n", 
							(long) msSendGameResults, 
							(long) msSendNoGameResults, 
							(long) opCode);
		return(kServerFuncAbort);
	}
	
	// How big is it?  Expect it to be at least as large as a GameResult
	// struct, but no larger than 1K.
	//
	Server_TReadDataSync( state->session, sizeof(size), (Ptr)&size );
	if (size > 1024) {
		PLogmsg(LOGP_NOTICE,
			"ERROR: game result size too huge (%d bytes, want about %d)\n",
			size, sizeof(GameResult));

		// Try to clear them out; dunno if it'll work.
		//
		Server_SendClearMiscQueues(state);
		Server_SendDialog(state, gettext("The results from your game were trashed.  Please send mail to \"XBAND\" with the name of the game."), true);	/*DIALOG*/
		return (kServerFuncAbort);
	}
	if (size < 16) {
		// Magic nasty SNES stuff.
		//
		// Happens when the game patch guys put 0 in the length field.  This
		// causes the box to upload absolutely nothing, which means the 4
		// bytes we just read for the "size" field is actually the totalWins
		// value we want to read after we return.
		//
		// No pointer or valid flag set yet, so just return, and the hosed
		// results will be ignored.
		//
		PLogmsg(LOGP_NOTICE, "HEY: Trying to fix SNES hosage\n");
		return (-950627);
	}
	
	gameResults = (GameResult *)malloc(size);
	
	if (!gameResults) {
		PLogmsg(LOGP_FLAW, "Malloc failed in game results, size=%ld\n", size);
		// show a nice block for JoeBritt
		gameResults = (GameResult *)malloc(32);
		gameResults->size = size;
		size = 32;
		Server_TReadDataSync( state->session, size-sizeof(gameResults->size),
			(Ptr)&gameResults->gameID );
		Loghexdump((unsigned char *)gameResults, 32);
		return(kServerFuncAbort);
	}

	gameResults->size = size;
	Server_TReadDataSync( state->session, size-sizeof(gameResults->size), (Ptr)&gameResults->gameID );

	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);
	
	if (size < sizeof(GameResult)) {
		PLogmsg(LOGP_NOTICE,
			"ERROR: game results too small (%d bytes, want at least %d)\n",
			size, sizeof(GameResult));
		// Let the connection continue, but act like we didn't get any.
	} else {
		state->gameResult = gameResults;
		state->validFlags |= kServerValidFlag_GameResults;
	}

	// Fix to 'sn07' SNES boxes.  The shorts added to the gameReserved
	// section didn't get swapped.
	//
	if (state->platformID == kPlatformSNES &&
		state->validFlags & kServerValidFlag_GameResults)
	{
		NewGameResult *ngr = (NewGameResult *)state->gameResult;

		ngr->localGameError = FLIP_SHORT(ngr->localGameError);
		ngr->errorRecovers = FLIP_SHORT(ngr->errorRecovers);
	}

	//DumpGameResults(state, gameResults, 0);

	PLogmsg(LOGP_PROGRESS, "Server_common_ReceiveGameResults done\n");
	return(kServerFuncOK);
}

int
Server_sega_ReceiveGameResults(ServerState *state)
{
	int err, none;

	err = Server_common_ReceiveGameResults(state, &none);
	if (err != kServerFuncOK)
		return (err);
	if (none)
		return (kServerFuncOK);

	ASSERT(state->validFlags & kServerValidFlag_SystemVersion);

	// Does the box have the patch that causes it to send up
	// the total wins/losses during a matchup?  If so, snarf
	// them and put them in the state struct for later.
	//
	if (state->systemVersionData.version > 92)
	{
		Server_TReadDataSync(state->session, sizeof(long), 
			(Ptr)&state->matchWins);
		Server_TReadDataSync(state->session, sizeof(long), 
			(Ptr)&state->matchLosses);

		state->validFlags |= kServerValidFlag_WinsLosses;

		PLogmsg(LOGP_DBUG, "Got total win/loss %ld/%ld\n", 
			state->matchWins, state->matchLosses);
	}
	return (kServerFuncOK);
}

#ifdef NOT_NEEDED
//
// Backward compatibility for 'sn00'.
//
int
Server_sn00_ReceiveGameResults(ServerState *state)
{
	int none;

	return (Server_common_ReceiveGameResults(state, &none));
}
#endif

//
// Starts out like 'sega', but ends up reading two additional longs.
//
int
Server_snes_ReceiveGameResults(ServerState *state)
{
	int err, none;

	err = Server_common_ReceiveGameResults(state, &none);
	if (err == -950627)
		goto fix_damage;
	if (err != kServerFuncOK)
		return (err);
	if (none)
		return (kServerFuncOK);

	Server_TReadDataSync(state->session, sizeof(long), 
		(Ptr)&state->matchWins);
fix_damage:
	Server_TReadDataSync(state->session, sizeof(long), 
		(Ptr)&state->matchLosses);

	state->validFlags |= kServerValidFlag_WinsLosses;

	PLogmsg(LOGP_DBUG, "Got total win/loss %ld/%ld\n", 
		state->matchWins, state->matchLosses);
	return (kServerFuncOK);
}


//
// Game error results look like GameResults, but they have a fixed size.
//
int Server_ReceiveGameErrorResults(ServerState *state)
{
unsigned char opCode, junk[7];

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveGameErrorResults\n");

	Server_TReadDataSync( state->session, 1, (Ptr)&opCode );
	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	// This code exists to fix a specific problem - Sega boxes
	// that have lost their database but not their system patch
	// will have version 3 but the gameresult parsing code will
	// not read the 8 bytes of total win/loss from them, which
	// they sent up. So if the box has no DB, but an OS patch
	// and valid game results, we'll detect it by the first zero
	// coming up (high byte of total wins!) and chew the next seven
	// bytes as well. The byte after that will be the real opcode
	// specifying whether or not game error results exist.
	//
	// Thanks to Josh for making the server code a pile of spaghetti !!
	//
	if (opCode == 0 && state->platformID == kPlatformGenesis &&
		state->systemVersionData.version == 3)
	{
		PLogmsg(LOGP_NOTICE, "HEY: Trying to fix Sega v.3 hosage\n");
		Server_TReadDataSync(state->session, 7, (Ptr)&junk);
		Server_TReadDataSync( state->session, 1, (Ptr)&opCode );
		if(Server_TCheckError(state->session) != noErr)
			return(kServerFuncAbort);
	}

	if(opCode == msSendNoGameErrorResults )
	{
		//Logmsg("No Game Error Results to receive\n");
		return(kServerFuncOK);
	}

	if(opCode != msSendGameErrorResults){
		// fucked
		PLogmsg(LOGP_FLAW, "Wrong opCode.  Expected %ld or %ld, got %ld\n", 
							(long) msSendGameErrorResults, 
							(long) msSendNoGameErrorResults, 
							(long) opCode);
		return(kServerFuncAbort);
	}
	
	Server_TReadDataSync( state->session, sizeof(GameResult), (Ptr)&state->gameErrorResult );

	if (state->gameErrorResult.size != sizeof(GameResult)) {
		PLogmsg(LOGP_NOTICE,
			"WARNING: game error result size field hosed (%d, should be %d)\n",
			state->gameErrorResult.size, sizeof(GameResult));

		// This currently causes the binlogs to fail, but the server connect
		// should be fine.  Continue with the server connect, but pretend
		// like we didn't get any game error results.

	} else {
		state->validFlags |= kServerValidFlag_GameErrorResults;
	}

	// Fix to 'sn07' SNES boxes.  The shorts added to the gameReserved
	// section didn't get swapped.
	//
	if (state->platformID == kPlatformSNES &&
		state->validFlags & kServerValidFlag_GameErrorResults)
	{
		NewGameResult *ngr = (NewGameResult *)&state->gameErrorResult;

		ngr->localGameError = FLIP_SHORT(ngr->localGameError);
		ngr->errorRecovers = FLIP_SHORT(ngr->errorRecovers);
	}

	//DumpGameResults(state, &state->gameErrorResult, 1);

	PLogmsg(LOGP_PROGRESS, "Server_ReceiveGameErrorResults done\n");
	return(kServerFuncOK);
}


// ===========================================================================
//		NetErrorRecords
// ===========================================================================

int Server_snes_ReceiveNetErrors(ServerState *state)
{
unsigned char opCode;
int has800=0, hasX25=0;

	PLogmsg(LOGP_PROGRESS, "Server_snes_ReceiveNetErrors\n");

	// Read the 800 net errors, if any.
	//
	Server_TReadDataSync( state->session, 1, (Ptr)&opCode );
	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	if (opCode == msNoNetErrors) {
		Logmsg("No Net Errors to receive\n");

	} else if (opCode != msSendNetErrors) {
		// fucked
		PLogmsg(LOGP_FLAW, "Wrong opCode.  Expected %ld or %ld, got %ld\n", 
							(long) msSendNetErrors, 
							(long) msNoNetErrors, 
							(long) opCode);
		return(kServerFuncAbort);

	} else {
		Server_TReadDataSync( state->session, sizeof(NetErrorRecord), (Ptr)&state->boxNetErrors800 );
		state->validFlags |= kServerValidFlag_NetErrors800;
	
		has800 = 1;
	}


	// Read the X.25 net errors, if any.
	//
	Server_TReadDataSync( state->session, 1, (Ptr)&opCode );
	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	if (opCode == msNoNetErrors) {
		Logmsg("No X25 Net Errors to receive\n");

	} else if (opCode != msSendNetErrors) {
		// fucked
		PLogmsg(LOGP_FLAW, "Wrong opCode.  Expected %ld or %ld, got %ld\n", 
							(long) msSendNetErrors, 
							(long) msNoNetErrors, 
							(long) opCode);
		return(kServerFuncAbort);

	} else {
		Server_TReadDataSync( state->session, sizeof(NetErrorRecord), (Ptr)&state->boxNetErrorsX25 );
		state->validFlags |= kServerValidFlag_NetErrorsX25;

		hasX25 = 1;
	}

	Server_LogNetErrors(state, has800, hasX25);
	
	PLogmsg(LOGP_PROGRESS, "Server_snes_ReceiveNetErrors done\n");
	return(kServerFuncOK);
}


int Server_sega_ReceiveNetErrors(ServerState *state)
{
unsigned char opCode;
int has800=0, hasX25=0;

	PLogmsg(LOGP_PROGRESS, "Server_sega_ReceiveNetErrors\n");

	// Read the 800 net errors, if any.
	//
	Server_TReadDataSync( state->session, 1, (Ptr)&opCode );
	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	if (opCode == msNoNetErrors) {
		Logmsg("No Net Errors to receive\n");

	} else if (opCode != msSendNetErrors) {
		// fucked
		PLogmsg(LOGP_FLAW, "Wrong opCode.  Expected %ld or %ld, got %ld\n", 
							(long) msSendNetErrors, 
							(long) msNoNetErrors, 
							(long) opCode);
		return(kServerFuncAbort);

	} else {
		Server_TReadDataSync( state->session, sizeof(segb_NetErrorRecord), (Ptr)&state->boxNetErrors800 );
		state->validFlags |= kServerValidFlag_NetErrors800;
	
		has800 = 1;
	}


	// Read the X.25 net errors, if any.
	//
	Server_TReadDataSync( state->session, 1, (Ptr)&opCode );
	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	if (opCode == msNoNetErrors) {
		Logmsg("No X25 Net Errors to receive\n");

	} else if (opCode != msSendNetErrors) {
		// fucked
		PLogmsg(LOGP_FLAW, "Wrong opCode.  Expected %ld or %ld, got %ld\n", 
							(long) msSendNetErrors, 
							(long) msNoNetErrors, 
							(long) opCode);
		return(kServerFuncAbort);

	} else {
		Server_TReadDataSync( state->session, sizeof(segb_NetErrorRecord), (Ptr)&state->boxNetErrorsX25 );
		state->validFlags |= kServerValidFlag_NetErrorsX25;

		hasX25 = 1;
	}

	Server_LogNetErrors(state, has800, hasX25);
	
	PLogmsg(LOGP_PROGRESS, "Server_sega_ReceiveNetErrors done\n");
	return(kServerFuncOK);
}



//
// Someday we can blow this away; PrintNetErrors is what we really want.
// This is just a raw dump of what we got.
//
PRIVATE void
Server_LogNetErrors(ServerState *state, int has800, int hasX25)
{
#ifdef DO_LOG_NETERRS
	if (has800) {
		if (state->boxOSState.boxFlags & kBoxIDTrashed) {
			Logmsg("BoxID trashed, probably brand new, not showing net errs.\n");
		} else {
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: serverConnects = %d\n", state->boxNetErrors800.serverConnects);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: peerConnects = %d\n", state->boxNetErrors800.peerConnects);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: framingError = %d\n", state->boxNetErrors800.framingError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: overrunError = %d\n", state->boxNetErrors800.overrunError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: packetError = %d\n", state->boxNetErrors800.packetError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: callWaitingInterrupt = %d\n", state->boxNetErrors800.callWaitingInterrupt);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: noDialtoneError = %d\n", state->boxNetErrors800.noDialtoneError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: serverBusyError = %d\n", state->boxNetErrors800.serverBusyError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: peerBusyError = %d\n", state->boxNetErrors800.peerBusyError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: serverDisconnectError = %d\n", state->boxNetErrors800.serverDisconnectError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: peerDisconnectError = %d\n", state->boxNetErrors800.peerDisconnectError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: serverAbortError = %d\n", state->boxNetErrors800.serverAbortError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: peerAbortError = %d\n", state->boxNetErrors800.peerAbortError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: serverNoAnswerError = %d\n", state->boxNetErrors800.serverNoAnswerError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: peerNoAnswerError = %d\n", state->boxNetErrors800.peerNoAnswerError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: serverHandshakeError = %d\n", state->boxNetErrors800.serverHandshakeError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: peerHandshakeError = %d\n", state->boxNetErrors800.peerHandshakeError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: serverX25NoServiceError = %d\n", state->boxNetErrors800.serverX25NoServiceError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: callWaitingError = %d\n", state->boxNetErrors800.callWaitingError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: remoteCallWaitingError = %d\n", state->boxNetErrors800.remoteCallWaitingError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: scriptLoginError = %d\n", state->boxNetErrors800.scriptLoginError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: packetRetransError = %d\n", state->boxNetErrors800.packetRetransError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: usedAltPOP = %d\n", state->boxNetErrors800.usedAltPOPNumber);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: ctsTimeouts = %d\n", state->boxNetErrors800.ctsTimeouts);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net 800: spinloopTimeouts = %d\n", state->boxNetErrors800.ctsTimeouts);

			if (Server_AreNetErrorsOkay(&state->boxNetErrors800)) {
				Server_PrintServerNetErrors(&state->boxNetErrors800, "800");
			}
		}
	}


	if (hasX25) {
		if (state->boxOSState.boxFlags & kBoxIDTrashed) {
			Logmsg("BoxID trashed, probably brand new, not showing net errs.\n");
		} else {
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: serverConnects = %d\n", state->boxNetErrorsX25.serverConnects);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: peerConnects = %d\n", state->boxNetErrorsX25.peerConnects);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: framingError = %d\n", state->boxNetErrorsX25.framingError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: overrunError = %d\n", state->boxNetErrorsX25.overrunError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: packetError = %d\n", state->boxNetErrorsX25.packetError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: callWaitingInterrupt = %d\n", state->boxNetErrorsX25.callWaitingInterrupt);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: noDialtoneError = %d\n", state->boxNetErrorsX25.noDialtoneError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: serverBusyError = %d\n", state->boxNetErrorsX25.serverBusyError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: peerBusyError = %d\n", state->boxNetErrorsX25.peerBusyError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: serverDisconnectError = %d\n", state->boxNetErrorsX25.serverDisconnectError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: peerDisconnectError = %d\n", state->boxNetErrorsX25.peerDisconnectError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: serverAbortError = %d\n", state->boxNetErrorsX25.serverAbortError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: peerAbortError = %d\n", state->boxNetErrorsX25.peerAbortError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: serverNoAnswerError = %d\n", state->boxNetErrorsX25.serverNoAnswerError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: peerNoAnswerError = %d\n", state->boxNetErrorsX25.peerNoAnswerError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: serverHandshakeError = %d\n", state->boxNetErrorsX25.serverHandshakeError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: peerHandshakeError = %d\n", state->boxNetErrorsX25.peerHandshakeError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: serverX25NoServiceError = %d\n", state->boxNetErrorsX25.serverX25NoServiceError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: callWaitingError = %d\n", state->boxNetErrorsX25.callWaitingError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: remoteCallWaitingError = %d\n", state->boxNetErrorsX25.remoteCallWaitingError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: scriptLoginError = %d\n", state->boxNetErrorsX25.scriptLoginError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: packetRetransError = %d\n", state->boxNetErrorsX25.packetRetransError);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: usedAltPOP = %d\n", state->boxNetErrorsX25.usedAltPOPNumber);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: ctsTimeouts = %d\n", state->boxNetErrorsX25.ctsTimeouts);
			FPLogmsg(LOG_NETERR, LOGP_DBUG, "	Box net X25: spinloopTimeouts = %d\n", state->boxNetErrorsX25.spinloopTimeouts);

			if (Server_AreNetErrorsOkay(&state->boxNetErrorsX25)) {
				Server_PrintServerNetErrors(&state->boxNetErrorsX25, "X25");
			}
		}
	}
#endif	/*DO_LOG_NETERRS*/
}


#define NE_NUM_FIELDS	25

#ifdef UNUSED
// Try to screen out fucked-up stats.  This is sort of painful.
//
// If any of the values is >= 127, or they're all the same value, we've
// got a garbaged box or an initialized box, and should throw all the
// results away.
//
// packetError can be fairly large if CompuServe is hosed, so we don't
// try to check it.  Instead we set it equal to peerConnects so that
// the "are they all the same?" check will work.
//
// Returns TRUE if they're good, FALSE if they're not.
//
// (NOTE: this shouldn't be necessary on the SNES... if SNES we should
// always return "ok".)
//
PRIVATE int
Server_AreNetErrorsOkay(NetErrorRecord *ner)
{
	unsigned short contents[NE_NUM_FIELDS];
	int i;
	unsigned short val;

	contents[0] = ner->serverConnects;
	contents[1] = ner->peerConnects;
	contents[2] = ner->framingError;
	contents[3] = ner->overrunError;
	contents[4] = ner->peerConnects;	/*ner->packetError*/
	contents[5] = ner->callWaitingInterrupt;
	contents[6] = ner->noDialtoneError;
	contents[7] = ner->serverBusyError;
	contents[8] = ner->peerBusyError;
	contents[9] = ner->serverDisconnectError;
	contents[10] = ner->peerDisconnectError;
	contents[11] = ner->serverAbortError;
	contents[12] = ner->peerAbortError;
	contents[13] = ner->serverNoAnswerError;
	contents[14] = ner->peerNoAnswerError;
	contents[15] = ner->serverHandshakeError;
	contents[16] = ner->peerHandshakeError;
	contents[17] = ner->serverX25NoServiceError;
	contents[18] = ner->callWaitingError;
	contents[19] = ner->remoteCallWaitingError;
	contents[20] = ner->scriptLoginError;
	contents[21] = ner->packetRetransError;
	contents[22] = ner->usedAltPOPNumber;
	contents[23] = ner->ctsTimeouts;
	contents[24] = ner->spinloopTimeouts;
	if (NE_NUM_FIELDS != 25) {
		// This is to make sure that, if NE_NUM_FIELDS changes, the
		// appropriate stuff is added above.
		//
		PLogmsg(LOGP_FLAW, "ERROR: NE_NUM_FIELDS not what was expected!\n");
		Common_Abort();
	}

	for (i = 0; i < NE_NUM_FIELDS; i++) {
		if (contents[i] >= 127)
			return (false);
	}
	val = contents[0];
	for (i = 1; i < NE_NUM_FIELDS; i++) {
		if (contents[i] != val)
			break;
	}
	if (i == NE_NUM_FIELDS)
		return (false);		// most often, all values are zero

	return (true);
}
#endif UNUSED

#ifdef UNUSED
//
// Print the server net errors of the variety requested.  They should already
// have been screened with Server_AreNetErrorsOkay.
//
// Someday we'll want to do these only (plus the peer ones over in
// Server_GameResults.c); for now we want to make sure we don't lose anything.
// Anything not printed here had better be printed over in the peer stuff!
//
// "msg" should be "800" or "X25".
//
PRIVATE int
Server_PrintServerNetErrors(NetErrorRecord *ner, char *msg)
{
#ifdef DO_LOG_NETERRS
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: serverConnects = %d\n", msg, ner->serverConnects);
	//FPLogmsg(LOG_NETERR, LOGP_DBUG,
	//	"SrvErr%s: peerConnects = %d\n", msg, ner->peerConnects);
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: framingError = %d\n", msg, ner->framingError);
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: overrunError = %d\n", msg, ner->overrunError);
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: packetError = %d\n", msg, ner->packetError);
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: callWaitingInterrupt = %d\n", msg, ner->callWaitingInterrupt);
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: noDialtoneError = %d\n", msg, ner->noDialtoneError);
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: serverBusyError = %d\n", msg, ner->serverBusyError);
	//FPLogmsg(LOG_NETERR, LOGP_DBUG,
	//	"SrvErr%s: peerBusyError = %d\n", msg, ner->peerBusyError);
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: serverDisconnectError = %d\n", msg, ner->serverDisconnectError);
	//FPLogmsg(LOG_NETERR, LOGP_DBUG,
	//	"SrvErr%s: peerDisconnectError = %d\n", msg, ner->peerDisconnectError);
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: serverAbortError = %d\n", msg, ner->serverAbortError);
	//FPLogmsg(LOG_NETERR, LOGP_DBUG,
	//	"SrvErr%s: peerAbortError = %d\n", msg, ner->peerAbortError);
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: serverNoAnswerError = %d\n", msg, ner->serverNoAnswerError);
	//FPLogmsg(LOG_NETERR, LOGP_DBUG,
	//	"SrvErr%s: peerNoAnswerError = %d\n", msg, ner->peerNoAnswerError);
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: serverHandshakeError = %d\n", msg, ner->serverHandshakeError);
	//FPLogmsg(LOG_NETERR, LOGP_DBUG,
	//	"SrvErr%s: peerHandshakeError = %d\n", msg, ner->peerHandshakeError);
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: serverX25NoServiceError = %d\n", msg, ner->serverX25NoServiceError);
	//FPLogmsg(LOG_NETERR, LOGP_DBUG,
	//	"SrvErr%s: callWaitingError = %d\n", msg, ner->callWaitingError);
	//FPLogmsg(LOG_NETERR, LOGP_DBUG,
	//	"SrvErr%s: remoteCallWaitingError = %d\n", msg, ner->remoteCallWaitingError);
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: scriptLoginError = %d\n", msg, ner->scriptLoginError);
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: packetRetransError = %d\n", msg, ner->packetRetransError);
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: usedAltPOP = %d\n", msg, ner->usedAltPOPNumber);
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: ctsTimeouts = %d\n", msg, ner->ctsTimeouts);
	FPLogmsg(LOG_NETERR, LOGP_DBUG,
		"SrvErr%s: spinloopTimeouts = %d\n", msg, ner->spinloopTimeouts);
#endif	/*DO_LOG_NETERRS*/

	return (0);
}
#endif UNUSED

