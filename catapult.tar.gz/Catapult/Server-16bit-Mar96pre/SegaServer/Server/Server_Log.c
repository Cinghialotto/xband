/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Log.c,v 1.45 1995/11/17 22:02:57 felix Exp $
 *
 * $Log: Server_Log.c,v $
 * Revision 1.45  1995/11/17  22:02:57  felix
 * Added WriteSmartCardInfo
 *
 * Revision 1.44  1995/11/12  20:42:30  davej
 * Added new kBlogBillEcp and retrofitted kBlogBillPromo.
 *
 * Revision 1.43  1995/11/02  13:11:44  chs
 * Use the new flag in the lastMatchup info to distinguish slaves timing-out
 * from peer-connect failures.
 *
 * Revision 1.42  1995/10/30  16:46:10  steveb
 * Environment variables read are now XBAND_ANI and XBAND_X25_ADDRESS.
 *
 * Revision 1.41  1995/10/27  19:43:36  steveb
 * Just did some long needed housecleaning.  No new code.
 *
 * Revision 1.40  1995/10/23  18:20:46  davej
 * Backed out previous changes for ECP DB fields.
 *
 * Revision 1.39  1995/10/23  17:06:49  davej
 * Added support for new billing type kBlogBillEcp and retrofitted
 * kBlogBillPromo.
 *
 * Revision 1.38  1995/10/16  14:29:39  sriram
 * Cleaned up old tourney stuff. Modifications for new tourney format.
 *
 * Revision 1.37  1995/10/12  19:44:14  felix
 * WriteMatchupRegurg now uses server->origLastMatchup rather than account->... so
 * the last player played is correct.
 *
 * Revision 1.36  1995/09/29  19:00:07  felix
 * Temporary change to stop SunSega from dumping core
 *
 * Revision 1.35  1995/09/29  16:02:56  felix
 * There were two instances of PORTAL_X25_ADDRESS, now both changed
 *
 * Revision 1.34  1995/09/29  15:54:44  felix
 * *** empty log message ***
 *
 * Revision 1.33  1995/09/29  15:47:29  felix
 * Changed PORTAL_X25_ADDRESS to PORTAL_ANI to determine 800 vs X25 connects
 *
 * Revision 1.32  1995/09/13  14:24:32  ted
 * Fixed warnings.
 *
 * Revision 1.31  1995/08/29  14:46:36  felix
 * Added WriteGenericSendQ for box debugging purposes
 *
 * Revision 1.30  1995/08/03  17:43:09  felix
 * added WriteMatchupRegurg
 *
 * Revision 1.29  1995/07/17  18:37:55  fadden
 * Changed a whole bunch of logmsgs from LOGP_DBUG to LOGP_DETAIL.
 *
 * Revision 1.28  1995/07/17  17:24:13  ted
 * Added WritePeerTime.
 *
 * Revision 1.27  1995/06/28  19:11:55  felix
 * Changed WriteBoxType to send boxType on _every_ connection.
 *
 * Revision 1.26  1995/06/26  13:25:32  felix
 * Added WriteBoxType
 *
 * Revision 1.25  1995/06/08  11:10:06  ted
 * Output new kTagLocalTime based on box's time zone.
 *
 * Revision 1.24  1995/05/26  23:46:30  jhsia
 * switch to rcs keywords
 *
 */


/*
	File:		Server_Log.c

	Contains:	Logging and some debugging stuff

	Written by: Andy McFadden


	Change History (most recent first):
		<25>	03/01/95	SLS	Adding totally new BinLog stuff
		<24>	12/14/94	SR		minor fix to convert phone numbers correctly
		<23>	12/14/94	SR		Miscellaneous additions/mods to binlog; bumped version to 2.
		<22>	11/16/94	SR		fixed stupid derefernce through nil pointer
		<21>	11/15/94	SR		Binary log - first pass.
		<20>	 9/18/94	ATM 	THIS FILE IS NOW OBSOLETE.	See Common_Log.c.
		<19>	 9/16/94	ATM 	Don't show pid for rpclog stuff, either.
		<18>	 9/16/94	ATM 	Don't print pid on statuslog.
		<17>	 9/16/94	ATM 	Added LOG_NETERR.
		<16>	 9/11/94	ATM 	Moved gProduction in here too.
		<15>	 9/11/94	ATM 	Shuffled things around slightly to make it easier to use this
									file everywhere.
		<14>	  9/7/94	ATM 	Added LOG_RPC.
		<13>	  9/6/94	ATM 	Added LOG_MATCHING.
		<12>	  9/3/94	ATM 	Changed LOG_DEBUG to LOG_DBUG.
		<11>	  9/1/94	ATM 	Initialize charbuf in FLoghexdump.
		<10>	  9/1/94	ATM 	Rearranged all the logging stuff (again).
		 <9>	 8/20/94	BET 	Oops, ascii comparison needed to be >= & <=
		 <8>	 8/20/94	BET 	Add ascii dump to Loghexdump.
		 <7>	 8/17/94	ATM 	Tweak.
		 <6>	 8/17/94	ATM 	Added Crasmsg stuff, per request.
		 <5>	 8/17/94	ATM 	Made gProduction a bit more blatant.
		 <4>	 8/17/94	ATM 	Added Loghexdump.
		 <3>	 8/15/94	ATM 	Now handle lines with no terminating '\n' in a clean way.
		 <2>	 8/13/94	ATM 	Fixed gLogFile stuff for Mac server.
		 <1>	 8/13/94	ATM 	first checked in

	To Do:
*/
#include <stdlib.h>
#include <memory.h>
#include <stdio.h>
#include <errno.h>
#include <signal.h>
#include <sys/file.h>
#include <fcntl.h>
#include <unistd.h>
#include <strings.h>
#include <sys/param.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include "Server_Log.h"
#include "Common_Log.h"
#include "Challnge.h"
#include "Matching.h"
#include "Common_ReadConf.h"
#include "Common_PacketTrace.h"
#include "Common_LogTools.h"
#include "Common_Missing.h"
#include "Server_Tournament.h"

/*=====================*/
/*  PRIVATE PROTOTYPES */
/*=====================*/

static int		Server_BillingType(cat_fld_bill_type_t);
static LogRecord *	FieldAppend(LogRecord *, FieldTag, char *, int);
static LogRecord *	CreateBinlogRecord(BlogLoginInfo *, ServerState *);
static Boolean 		WriteBlogRecord(char *, int, ServerState *, LogRecord *);
static LogRecord *	WriteConnCarrier(LogRecord *, ServerState *, BlogLoginInfo *);
static LogRecord *	WriteConnType(LogRecord *, ServerState *, BlogLoginInfo *);
static LogRecord *	WriteCrashRecord(LogRecord *, ServerState *, BlogLoginInfo *);
static LogRecord *	WriteGameResultsGeneric(LogRecord *, FieldTag, ServerState *, NewGameResult *);
static LogRecord *	WriteMatchupRegurg(LogRecord *, ServerState *, BlogLoginInfo *);
static LogRecord *	WriteTourneyResult(LogRecord *, ServerState *, BlogLoginInfo *);
static LogRecord *  WriteSmartCardInfo(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo);
static LogRecord *	WriteGameResults(LogRecord *, ServerState *, BlogLoginInfo *);
static LogRecord *	WriteGameErrorResults(LogRecord *, ServerState *, BlogLoginInfo *);
static LogRecord *	Write800NetErrors(LogRecord *, ServerState *, BlogLoginInfo *);
static LogRecord *	WriteX25NetErrors(LogRecord *, ServerState *, BlogLoginInfo *);
static LogRecord *	WriteStreamErrorReport(LogRecord *, ServerState *, BlogLoginInfo *);
static LogRecord *	WriteGameSendQErrors(LogRecord *, ServerState *, BlogLoginInfo *);
static LogRecord *	WriteBoxSendQErrors(LogRecord *, ServerState *, BlogLoginInfo *);
static LogRecord *	WriteLocalTime(LogRecord *, ServerState *, BlogLoginInfo *);
static LogRecord *	WriteBoxType(LogRecord *, ServerState *, BlogLoginInfo *);
static LogRecord *	WritePeerTime(LogRecord *, ServerState *, BlogLoginInfo *);
static LogRecord *	WriteGenericSendQ(LogRecord *, ServerState *, BlogLoginInfo *);

#ifdef UNUSED
static LogRecord *	WritePacketTrace(LogRecord *, ServerState *, BlogLoginInfo *);
#endif

/*-----------------------------------------------------------------------------*/

static int
Server_BillingType(cat_fld_bill_type_t catType)
{
  int logType;
  
  switch(catType) {
  case CAT_ACCT_BILL_UNDEFINED :
    logType = kBlogBillUndefined;
    break;
  case CAT_ACCT_BILL_PREPAID :
    logType = kBlogBillPrepaid;
    break;
  case CAT_ACCT_BILL_INVOICE :
    logType = kBlogBillInvoice;
    break;
  case CAT_ACCT_BILL_DEBIT :
    logType = kBlogBillDebit;
    break;
  case CAT_ACCT_BILL_VISA :
    logType = kBlogBillVisa;
    break;
  case CAT_ACCT_BILL_MCARD :
    logType = kBlogBillMcard;
    break;
  case CAT_ACCT_BILL_AMEX :
    logType = kBlogBillAmex;
    break;
  case CAT_ACCT_BILL_SMARTC :
    logType = kBlogBillSmartc;
    break;
  case CAT_ACCT_BILL_SUBORD :
    logType = kBlogBillSubord;
    break;
  case CAT_ACCT_BILL_BETA :
    logType = kBlogBillBeta;
    break;
  case CAT_ACCT_BILL_INTERNAL :
    logType = kBlogBillInternal;
    break;
  case CAT_ACCT_BILL_GUEST :
    logType = kBlogBillGuest;
    break;
  case CAT_ACCT_BILL_PROMO :
    logType = kBlogBillPromo;
    break;
  case CAT_ACCT_BILL_ECP :
    logType = kBlogBillEcp;
    break;
  default:
    logType = kBlogBillUndefined;
    PLogmsg(LOGP_FLAW,
	    "Server_BillingType: Unknown billing type\n");
    break;
  }
  
  return(logType);
}

/*-----------------------------------------------------------------------------*/

Boolean
Server_WriteNewBinaryLog(ServerState *state, unsigned char exitStatus)
{
  int 		mask;
  BlogLoginInfo	loginInfo;
  char		hostname[MAXHOSTNAMELEN];
  struct hostent	*pHostEntry;
  LogRecord	*theRecord;
  
  if (!gConfig.isBinLogOn && !gConfig.isBinLogPipeOn)
    return(true);
  
  PLogmsg(LOGP_PROGRESS, "Server_WriteNewBinaryLog\n");
  
  mask = Common_MaskSignals();
  
  if (state == NULL)
    {
      PLogmsg(LOGP_FLAW,"Server_WriteNewBinaryLog: NULL ServerState - unable to log\n");
      Common_UnmaskSignals(mask);
      return(false);
    }
  
  memset((char *)&loginInfo, 0, sizeof(BlogLoginInfo));
  
  gethostname(hostname, MAXHOSTNAMELEN);
  pHostEntry = gethostbyname((char *)hostname);
  memcpy((char *)&loginInfo.hostAddr, (char *)pHostEntry->h_addr_list[0], 4);
  
  if (state->validFlags & kServerValidFlag_TimeOfThisConnect)
    {
      loginInfo.startTime = state->timeOfThisConnect;
      loginInfo.duration	 = time(0) - state->timeOfThisConnect;
    }
  else
    {
      loginInfo.startTime = time(0);	/* if nothing, record this time */
      loginInfo.duration	 = 0;	/* can we do better ? */
    }
  
  loginInfo.exitStatus = exitStatus;
  loginInfo.version = kLogVersionNumber;
  
  if (state->account && (state->validFlags & kServerValidFlag_Account)) 
    {
      /* We were able to find/create/restore the account info for this login.*/
      loginInfo.boxInfo.serialNum	= state->account->boxAccount.box;
      loginInfo.boxInfo.userNum 	= state->account->playerAccount.player;
      strcpy(loginInfo.nameStr, state->account->playerAccount.userName);
      strcpy(loginInfo.callingNumber, state->account->boxAccount.gamePhone.phoneNumber);
      
      if (state->playerCreated == true)
	loginInfo.flags.accountCreation = kBlogPlayerCreated;
      else if (state->accountCreated == true)
	loginInfo.flags.accountCreation = kBlogAccountCreated;
      
      loginInfo.billingType = 
	Server_BillingType(state->account->userAccount.billingType);
      
      loginInfo.flags.validAccount = 1;
      loginInfo.flags.validLogin   = 1;
    }
  else if (state->validFlags & kServerValidFlag_Login)
    {
      /* Account info was not valid. So, atleast save the info 
	 that the box sent us during log-in. */
      loginInfo.boxInfo.serialNum  = state->loginData.userID.box;
      loginInfo.boxInfo.userNum	= state->loginData.userID.userID;
      strcpy(loginInfo.nameStr, state->loginData.userID.userName);
	  strcpy(loginInfo.callingNumber,state->boxPhoneNumber.phoneNumber);
      loginInfo.flags.validLogin = 1;
    }
  
  loginInfo.connid = state->connid;

  if (getenv("XBAND_ANI") == NULL)
    loginInfo.flags.x25Conn = 1;
  
  /*  // The optional records begin here. Set bit fields
      // to indicate that an optional record is indeed being written. */
  if (state->crashRecord)
    loginInfo.flags.crashRecord = 1;
  
  if (state->validFlags & kServerValidFlag_GameResults)
    loginInfo.flags.gameResults = 1;
  
  if (state->validFlags & kServerValidFlag_GameErrorResults)
    loginInfo.flags.gameErrorResults = 1;
  
  if (state->validFlags & kServerValidFlag_NetErrors800)
    loginInfo.flags.netErrors800 = 1;
  
  if (state->validFlags & kServerValidFlag_NetErrorsX25)
    loginInfo.flags.netErrorsX25 = 1;
  
  if (state->gameErrorDBIDData)
    loginInfo.flags.gameSendQErrors = 1;
  
  if (state->SQSHead)
    loginInfo.flags.boxSendQErrors = 1;
 
  if (state->account && !(state->account->boxAccount.restrictArea & kRestrictArea_dialLocalPreferred))
    loginInfo.flags.challengeArea = 1;
  
#ifdef PACKET_TRACE
  loginInfo.flags.packetTrace = 1;
#endif
  
  if (state->validFlags & kServerValidFlag_ChallengeOrCompete)
    {
      if(state->challengeData.userID.box.box == kDownloadOnlyMailSerialNumber)
	loginInfo.flags.mailOrGame = kBlogMail;
      else
	{
	  loginInfo.flags.mailOrGame = kBlogGame;
	  
	  if (state->challengeData.userID.box.box == kFindNetworkOpponentSerialNumber)
	    loginInfo.flags.autoOrChall = kBlogAutomatch;
	  else
	    loginInfo.flags.autoOrChall = kBlogChallenge;
	  
	  if (state->matchup)
	    {
	      if (state->matchup->result == kMatchDial)
		loginInfo.flags.dialOrWait = kBlogDial;
	      else
		loginInfo.flags.dialOrWait = kBlogWait;
	    }
	}
    }
  
  if (state->streamErrorReport)
    loginInfo.flags.streamError = 1;
  
  if (state->tourneyData) 
    loginInfo.flags.tournament = 1;
  
  if (state->gameErrorDBIDData)
    loginInfo.flags.gameSendQErrors = 1;
  
  if (state->SQSHead)
    loginInfo.flags.boxSendQErrors = 1;
  
  if ((theRecord = CreateBinlogRecord(&loginInfo, state)) == 0)
    PLogmsg(LOGP_FLAW, "Server_WriteNewBinaryLog: CreateBlogRec returned false\n");
  else
    {
      if (gConfig.isBinLogOn)
	{
	  if (WriteBlogRecord(gConfig.serverBinLogName,  O_CREAT+O_WRONLY+O_APPEND, 
		  state, theRecord) == 0)
	      PLogmsg(LOGP_FLAW, "Server_WriteNewBinaryLog: WriteBlogRecord returned false\n");
	}
	  if (gConfig.isBinLogPipeOn) {
		if (WriteBlogRecord(gConfig.serverBinLogPipeName, 
			O_WRONLY+O_APPEND+O_NDELAY, state, theRecord) == 0)
			PLogmsg(LOGP_FLAW, "Server_WriteNewBinaryLog: WriteBlogRecord returned false\n");
	  }
      free (theRecord);
    }
  
  Common_UnmaskSignals(mask);
  return(true);
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
FieldAppend(LogRecord *theRecord, FieldTag theTag, char *theData, int dataSize)
{
  LogField *pField;
  int  realSize = dataSize;

  dataSize = (dataSize + 3) & ~3;
  if (!theRecord)
    {
      PLogmsg(LOGP_FLAW, "FieldAppend:  Got passed null record while at tag %d\n",theTag);
      return NULL;
    }
      
  PLogmsg(LOGP_PROGRESS, "FieldAppend:  Adding tag %s\n",GetTagNameByNumber(theTag));

  theRecord = realloc(theRecord, theRecord->size + sizeof(LogField) + dataSize);
  pField = (LogField *)((char *)theRecord + theRecord->size);
  pField->tag = theTag;
  pField->size = sizeof(LogField) + dataSize;
  memcpy((char *)&pField->data, theData, realSize);
  theRecord->size += pField->size;
  
  return theRecord;
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
CreateBinlogRecord(BlogLoginInfo *loginInfo, ServerState *state)
{
  LogRecord	*theRecord;
  char		testChar;
  
  PLogmsg(LOGP_PROGRESS, "Creating Binlog Record\n");
  PLogmsg(LOGP_DBUG, "%s\n", "Generating: BlogLoginInfo");


  theRecord = malloc(sizeof(LogRecord));
  if (theRecord == NULL)
    {
      PLogmsg(LOGP_FLAW, "CreateBinlogRecord:  cannot allocate record header: %d\n",errno);
      return NULL;
    }
  theRecord->size = sizeof(LogRecord);

  if (theRecord == NULL)
    {
      PLogmsg(LOGP_FLAW, "WriteBlogRecord: cannot allocate mems: %d\n", errno);
      return NULL;
    }
  
  theRecord = FieldAppend(theRecord, kTagLoginInfo, (char *)loginInfo, sizeof(BlogLoginInfo));
  if (!theRecord)
    {
      PLogmsg(LOGP_FLAW, "CreateBinlogRecord:  cannot allocate record header: %d\n",errno);
      return NULL;
    }

  theRecord = WriteConnCarrier(theRecord, state, loginInfo);

  theRecord = WriteLocalTime(theRecord, state, loginInfo);

  theRecord = WriteBoxType(theRecord, state, loginInfo);

  theRecord = WritePeerTime(theRecord, state, loginInfo);

  theRecord = WriteMatchupRegurg(theRecord, state, loginInfo);

  if (state->validFlags & kServerValidFlag_TourneyResult)
      theRecord = WriteTourneyResult(theRecord, state, loginInfo);

  theRecord = WriteSmartCardInfo(theRecord, state, loginInfo);

  theRecord = WriteGenericSendQ(theRecord, state, loginInfo);

  if (state->validFlags & kServerValidFlag_ChallengeOrCompete)
    theRecord = WriteConnType(theRecord, state, loginInfo);

  if (state->crashRecord)
    theRecord = WriteCrashRecord(theRecord, state, loginInfo);

  if (state->validFlags & kServerValidFlag_GameResults)
    theRecord = WriteGameResults(theRecord, state, loginInfo);
  
  if (state->validFlags & kServerValidFlag_GameErrorResults)
    theRecord = WriteGameErrorResults(theRecord, state, loginInfo);
  	
  if (state->validFlags & kServerValidFlag_NetErrors800)
    theRecord = Write800NetErrors(theRecord, state, loginInfo);
  
  if (state->validFlags & kServerValidFlag_NetErrorsX25)
    theRecord = WriteX25NetErrors(theRecord, state, loginInfo);

  if (state->streamErrorReport)
    theRecord = WriteStreamErrorReport(theRecord, state, loginInfo);

  if (state->gameErrorDBIDData)
    theRecord = WriteGameSendQErrors(theRecord, state, loginInfo);

  if (state->SQSHead)
    theRecord = WriteBoxSendQErrors(theRecord, state, loginInfo);

#ifdef PACKET_TRACE

  theRecord = WritePacketTrace(theRecord, state, loginInfo);

#endif

  /*	// test that the end of the block is not bus error territory before
	// entering critical section
	// HACK ALERT: read the number and write it back out so the optimizer
	// doesn't try to remove the expression as an unused local variable. */
  
  if (!theRecord) return NULL;

  testChar = *((char *)theRecord + theRecord->size);
  *((char *)theRecord + theRecord->size) = testChar;

  return theRecord;
}

/*-----------------------------------------------------------------------------*/

 /**
  ** 1/4/95 7:25:44 PM (BET): start out by building an in-memory copy of the blog
  ** record.	Then test that the routines did as they were supposed to by trying to read
  ** the last longword at the end of the data.  It should read fine but if we hoark we
  ** want to catch it before dropping into the flock section.
  **/

static Boolean
WriteBlogRecord(char *logname, int type, ServerState *state, LogRecord *theRecord)
{
  int 				fd;
  FILE				*fp;
  BlogFileHeader	fileHeader;
  long				marker;
  
  fd = open(logname, type, 0666);
  if (fd == -1)
    {
      PLogmsg(LOGP_FLAW,"Server_WriteNewBinaryLog: cannot open binary log file \"%s\":%d\n",logname, errno);
      return(false);
    }
  
  fp = fdopen(fd, "a");
  if (fp == NULL)
    {
      PLogmsg(LOGP_FLAW,"Server_WriteNewBinaryLog: cannot open binary log file \"%s\":%d\n",logname, errno);
      return(false);
    }
  
  if (flock(fileno(fp), LOCK_EX) < 0)
    {
      PLogmsg(LOGP_FLAW, "Server_WriteNewBinaryLog: Unable to get lock \n");
      return(false);
    }
  
  /* seek to the end of the file*/
  fseek(fp, 0, 2);
  
  /* if this is a new log file, write the file header.*/
  
  if (ftell(fp) == 0)
    {
      PLogmsg(LOGP_NOTICE, "New binlog: writing header info\n");
      fileHeader.identifier = kLogConnStartMarker;
      fileHeader.version	= kLogVersionNumber;
      fileHeader.createTime = time(0);
      fwrite(&fileHeader, sizeof(BlogFileHeader), 1, fp);
    }
  
  /* connection marker to reliably detect connection start */
  marker = kLogConnStartMarker;
  PLogmsg(LOGP_DETAIL, "%s\n", "Writing binlog: start marker");
  fwrite(&marker, sizeof(long), 1, fp);
  
  fwrite(theRecord, theRecord->size, 1, fp);
  
  /* connection marker to reliably detect connection end */
  marker = kLogConnEndMarker;
  PLogmsg(LOGP_DETAIL, "%s\n", "Writing binlog: end marker");
  fwrite(&marker, sizeof(long), 1, fp);
  
  fflush(fp);
  
  if (flock(fileno(fp), LOCK_UN) < 0)
    {
      PLogmsg(LOGP_FLAW, "Server_WriteNewBinaryLog: Unable to release lock \n");
      return(false);
    }
  
  fclose(fp);

  return (true);
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
WriteConnCarrier(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
  BlogPopInfo pop;
  char *pTemp;

  if (!loginInfo->flags.x25Conn) return theRecord;

  memset((char *)&pop, 0, sizeof(BlogPopInfo));
  if ((pTemp = getenv("XBAND_X25_ADDRESS")) != NULL)
    strncpy(pop.x25Addr, pTemp, kX25AddressSize);
  if (state && state->account)
    {
      strcpy(pop.main,state->account->boxAccount.popPhone.phoneNumber);
      strcpy(pop.alt,state->account->boxAccount.altPopPhone.phoneNumber);
    }
  theRecord = FieldAppend(theRecord, kTagPopInfo, (char *)&pop, sizeof(BlogPopInfo));
  return theRecord;
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
WritePeerTime(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
  BlogPeerTime peerTime;

  if (state && state->account && (state->peerConnects != 0))
    {
    	peerTime.connects = state->peerConnects;
    	peerTime.seconds = state->peerSeconds;
		theRecord = FieldAppend(theRecord, kTagPeerTime, (char *)&peerTime, sizeof(BlogPeerTime));
    }
  return theRecord;
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
WriteLocalTime(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
  BlogLocalTime clock;

  memset((char *)&clock, 0, sizeof(BlogLocalTime));
  if (state && state->account)
    {
    	clock.time = state->localConnectTime;
    }
  theRecord = FieldAppend(theRecord, kTagLocalTime, (char *)&clock, sizeof(BlogLocalTime));
  return theRecord;
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
WriteConnType(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
  BlogOpponentInfo	opponent;
  BlogCookieInfo	wait;
  BlogCarrierCode	carriercode;
 
  if (loginInfo->flags.mailOrGame == kBlogGame)
    {
      /*
       * This is a game request. Write the following:
       * 1. requested game ID
       * 2. automatch or challenge request with corresponding info.
       * 2. Whether the user was asked to dial or wait
       *	  and the corresponding info.
       */
      
      theRecord = FieldAppend(theRecord, kTagGameID, (char *)&state->gameIDData, sizeof(GameIDData));
      if (loginInfo->flags.dialOrWait == kBlogDial)
	{
	  memset((char *)&opponent, 0, sizeof(BlogOpponentInfo));
	  if (state->matchup)
	    {
	      opponent.boxInfo.serialNum = state->matchup->oppBoxSerialNumber;
	      opponent.boxInfo.userNum = state->matchup->oppPlayer;
	      strcpy(opponent.phone,state->matchup->oppOrigPhoneNumber.phoneNumber);
	      opponent.cookie = state->matchup->oppMagicCookie;
	      opponent.toll = state->matchup->oppTollCall;
	      opponent.sprint = state->matchup->sprint;
	      opponent.mci = state->matchup->mci;
	      opponent.billslave = state->matchup->billslave;
	      opponent.billmaster = state->matchup->billmaster;
		  opponent.xbnslave = state->matchup->xbnslave;
		  opponent.xbnmaster = state->matchup->xbnmaster;
	    }
	  theRecord = FieldAppend(theRecord,kTagOpponent, (char *)&opponent, sizeof(BlogOpponentInfo));
	  if (opponent.mci || opponent.sprint)
	  {
		strcpy(carriercode.id,state->carriercode);
		strcpy(carriercode.d800,state->carrierphone);
		theRecord = FieldAppend(theRecord,kTagCarrierCode, (char *)&carriercode, sizeof(BlogCarrierCode));
	  }
	}
      else if (loginInfo->flags.dialOrWait == kBlogWait)
	{
	  memset((char *)&wait, 0, sizeof(BlogCookieInfo));
	  wait.cookie = state->matchup->magicCookie;
	  theRecord = FieldAppend(theRecord, kTagCookie, (char *)&wait, sizeof(BlogCookieInfo));
	}
    }
  return theRecord;
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
WriteCrashRecord(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
  struct BoxRestartInfo crashRecord;
  struct BoxRestartInfo *crashRecordPtr;
  
  if (loginInfo->flags.crashRecord)
    {
      if (state->crashRecord)
	crashRecordPtr = state->crashRecord;
    else
      {
	memset((char *)&crashRecord, 0, sizeof(struct BoxRestartInfo));
	crashRecordPtr = &crashRecord;
      }
      
      PLogmsg(LOGP_DETAIL, "%s\n", "Writing binlog: BoxRestartInfo");
      theRecord = FieldAppend(theRecord, kTagCrashRecord, (char *)crashRecordPtr, sizeof(struct BoxRestartInfo));
    }
  return theRecord;
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
WriteGameResultsGeneric(LogRecord *theRecord, FieldTag theTag, ServerState *state, NewGameResult *pGameResult)
{
  NewGameResult	oGameResult;
  if (theRecord == NULL ) return theRecord;

  if (pGameResult == NULL)
    {
      memset((char *)&oGameResult, 0, sizeof(NewGameResult));
      oGameResult.size = sizeof(unsigned long);
      pGameResult = &oGameResult;
    }

  PLogmsg(LOGP_DETAIL, "%s\n", "Writing binlog: NewGameResult");
  return FieldAppend(theRecord, theTag, (char *)pGameResult, pGameResult->size);
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
WriteGameResults(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
  if (loginInfo->flags.gameResults)
    {
      if (state->gameResult)
	{
	  theRecord = FieldAppend(theRecord, kTagCreditChange, (char *)&state->creditChangeFlags, sizeof(unsigned long));
	  theRecord = WriteGameResultsGeneric(theRecord, kTagGameResults, state, (NewGameResult *)state->gameResult);
	}
      else
	theRecord = WriteGameResultsGeneric(theRecord, kTagGameResults, state, NULL );
    }
  return theRecord;
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
WriteGameErrorResults(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
  if (loginInfo->flags.gameErrorResults)
    {
      theRecord = WriteGameResultsGeneric(theRecord, kTagGameErrorResults, state,
					  (NewGameResult *)&(state->gameErrorResult));
    }
  return theRecord;
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
Write800NetErrors(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
  if (loginInfo->flags.netErrors800)
    {
      PLogmsg(LOGP_DETAIL, "%s\n", "Writing binlog: NetErrorRecord");
      theRecord = FieldAppend(theRecord, kTagNetError800, (char *)&(state->boxNetErrors800), sizeof(NetErrorRecord));
    }
  return theRecord;
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
WriteX25NetErrors(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
  if (loginInfo->flags.netErrorsX25)
    {
      PLogmsg(LOGP_DETAIL, "%s\n", "Writing binlog: NetErrorRecord");
      theRecord = FieldAppend(theRecord, kTagNetErrorX25, (char *) &(state->boxNetErrorsX25), sizeof(NetErrorRecord));
    }
  return theRecord;
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
WriteStreamErrorReport(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
  StreamErrorReport	error;
  StreamErrorReport	*pError;

  if (loginInfo->flags.streamError)
    {
      if (state->streamErrorReport)
	pError = (StreamErrorReport *)state->streamErrorReport;
      else
	{
	  memset((char *)&error, 0, sizeof(StreamErrorReport));
	  pError = &error;
	}
      PLogmsg(LOGP_DETAIL, "%s\n", "Writing binlog: StreamErrorReport");
      theRecord = FieldAppend(theRecord, kTagStreamError, (char *)pError, sizeof(StreamErrorReport));
    }
  return theRecord;
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
WriteGameSendQErrors(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
  if (loginInfo->flags.gameSendQErrors && state->gameErrorDBIDData)
      theRecord = FieldAppend(theRecord, kTagSendQErrors, (char *)&state->gameErrorDBIDData, state->gameErrorDBIDSize);
  return theRecord;
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
WriteBoxSendQErrors(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
  SQSaveTuple	*sqs = state->SQSHead;
  short		id;
  int		size;
  struct _SQSBuffer
    {
      short	id;
      char	data[16384];
    } SQSBuffer;
    

  if (loginInfo->flags.boxSendQErrors && sqs)
    {
      while (sqs)
	{
	  size = sqs->size + sizeof(size);
	  SQSBuffer.id = sqs->id;
	  size += sizeof(id);
	  if (size & 1) size +=1;
	  memcpy(&SQSBuffer.data, sqs->data, sqs->size);
	  
	  theRecord = FieldAppend(theRecord, kTagBoxSendQError, (char *)&SQSBuffer, size);
	  sqs = sqs->next;
	}

    }
  return theRecord;
}

/*-----------------------------------------------------------------------------*/

#ifdef UNUSED
static LogRecord *
WritePacketTrace(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
#if 0
  PacketBuffer *packetBuffer,*CreatePacketTraceBlock();

  packetBuffer = CreatePacketTraceBlock();

  PLogmsg(LOGP_DETAIL, "%s\n", "Writing binlog: Packet Trace Buffer");
  theRecord = FieldAppend(theRecord, kTagPacketTrace, (char *)packetBuffer, sizeof(PacketBuffer) + packetBuffer->totalSize);
#endif
  return theRecord;
}
#endif UNUSED

/*-----------------------------------------------------------------------------*/

static LogRecord *
WriteBoxType(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
BlogBoxTypeInfo boxtype;
 
if (state->boxType) {

	memset((char *)&boxtype, 0, sizeof(BlogBoxTypeInfo));
		boxtype.boxType = state->boxType;

	PLogmsg(LOGP_DETAIL, "%s %.8x\n", // why are we doing it like this?
		"Writing binlog: BoxType", boxtype.boxType);
	theRecord = FieldAppend(theRecord, kTagBoxType, (char *)&boxtype, 
		sizeof(BlogBoxTypeInfo));

	}

    return theRecord;

}

/*-----------------------------------------------------------------------------*/

static LogRecord *
WriteMatchupRegurg(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
BlogMatchupRegurg blogMatchupRegurg;

 if (state->oldMatchupRegurg) {

 blogMatchupRegurg.master = state->oldMatchupRegurg->master;
 blogMatchupRegurg.when = state->oldMatchupRegurg->when;
 blogMatchupRegurg.magicCookie = state->oldMatchupRegurg->magicCookie;
 blogMatchupRegurg.gamePatchVer = state->oldMatchupRegurg->gamePatchVer;
 blogMatchupRegurg.gameID = state->oldMatchupRegurg->gameID;

 if (state->origLastMatchup &&
     state->origLastMatchup->flags & kLM_weWereMatched)
 {
  blogMatchupRegurg.oppBoxSerialNumber.box = 
	state->origLastMatchup->prevOpponent.oppBoxSerialNumber.box;
  blogMatchupRegurg.oppBoxSerialNumber.region =
	state->origLastMatchup->prevOpponent.oppBoxSerialNumber.region;
 } else {
  blogMatchupRegurg.oppBoxSerialNumber.box = 0;
  blogMatchupRegurg.oppBoxSerialNumber.region = 0;
 }

 theRecord = FieldAppend(theRecord, kTagMatchupRegurg, 
   (char *)&blogMatchupRegurg, sizeof(BlogMatchupRegurg));
 }

 return theRecord;

}

/*-----------------------------------------------------------------------------*/

static LogRecord *
WriteGenericSendQ(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
QItem *item;
int itemNumber;
FILE *fp;
char line[81];

 fp = fopen("/opt/catapult/conf/sendQ.conf","r");

 if (!fp) return theRecord;

 while (fgets(line,80,fp))
   if ( (*line!='#') && (itemNumber = atoi(line)) )
     if ((item = Server_FindSendQItem(state, itemNumber)))
       theRecord = FieldAppend(theRecord, kTagGenericSendQ, 
                               (char *) item, item->size);

 return theRecord;
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
WriteTourneyResult(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
    BlogTourneyResult	tourneyResult;

    if (state->tourneyResult) {
	// NOTE:
	// TourneyResult and BlogTourneyResult are identical 
	// definitions for now.
	tourneyResult.flags = state->tourneyResult->flags;

	theRecord = FieldAppend(theRecord, kTagTourneyResult, 
   			(char *)state->tourneyResult, sizeof(BlogTourneyResult));
    }

    return(theRecord);
}

/*-----------------------------------------------------------------------------*/

static LogRecord *
WriteSmartCardInfo(LogRecord *theRecord, ServerState *state, BlogLoginInfo *loginInfo)
{
    BlogSmartCardInfo	blogSmartCardInfo;

    if (gConfig.useDebitCardOnly && 
       ((state->currentCard) && (state->prevCard))) {

		memset((char *)&blogSmartCardInfo, 0, sizeof(BlogSmartCardInfo));

		blogSmartCardInfo.currentOrigCardCredits =
			 state->creditDebitInfo.debitCardInfo.creditsLeft;

		blogSmartCardInfo.currentCard.serialNumber = 
			state->currentCard->serialNumber;
		blogSmartCardInfo.currentCard.formerBalance = 
			state->currentCard->formerBalance;
		blogSmartCardInfo.currentCard.actualBalance =
			state->currentCard->actualBalance;
		blogSmartCardInfo.currentCard.timeFirstUsed =
			state->currentCard->timeFirstUsed;
		blogSmartCardInfo.currentCard.timeLastUsed =
			state->currentCard->timeLastUsed;
		blogSmartCardInfo.currentCard.timeExpired =
			state->currentCard->timeExpired;

		blogSmartCardInfo.prevCard.serialNumber = 
			state->prevCard->serialNumber;
		blogSmartCardInfo.prevCard.formerBalance = 
			state->prevCard->formerBalance;
		blogSmartCardInfo.prevCard.actualBalance =
			state->prevCard->actualBalance;
		blogSmartCardInfo.prevCard.timeFirstUsed =
			state->prevCard->timeFirstUsed;
		blogSmartCardInfo.prevCard.timeLastUsed =
			state->prevCard->timeLastUsed;
		blogSmartCardInfo.prevCard.timeExpired =
			state->prevCard->timeExpired;

	theRecord = FieldAppend(theRecord, kTagSmartCardInfo, 
   		(char *)&blogSmartCardInfo, sizeof(BlogSmartCardInfo));
    }

    return(theRecord);
}
