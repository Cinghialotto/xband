/*
 *
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_SendAddressBook.c,v 1.2 1995/05/27 00:58:05 jhsia Exp $
 *
 * $Log: Server_SendAddressBook.c,v $
 * Revision 1.2  1995/05/27  00:58:05  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_SendAddressBook.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		 <6>	10/25/94	DJ		This file is obsolete.  Please delete it from the project.

	To Do:
*/

/*

	This file obsolete.  Look at Server_AddressBook.c.

*/

