/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_SendRanking.c,v 1.12 1996/02/13 20:30:47 fadden Exp $
 *
 * $Log: Server_SendRanking.c,v $
 * Revision 1.12  1996/02/13  20:30:47  fadden
 * Declare some read-only tables and their pointers as "const".
 *
 * Revision 1.11  1996/01/25  17:54:43  hufft
 * added UDP based connections
 *
 * Revision 1.10  1995/09/13  14:18:42  ted
 * Fixed warnings.
 *
 * Revision 1.9  1995/07/10  21:21:06  rich
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.8  1995/07/07  20:56:08  fadden
 * Added SetTransportHold calls to four routines.
 *
 * Revision 1.7  1995/06/01  15:10:36  fadden
 * Merge in from newbr.
 * -> Take platformID into account when looking up rank charts.
 *
 * Revision 1.6  1995/05/27  00:58:16  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_SendRanking.c

	Contains:	Server send ranking function

	Written by:	Dave Jevans


	Change History (most recent first):

		<49>	12/13/94	ATM		Send xpoints down as an *unsigned* long.
		<48>	11/26/94	ATM		Use Common_GetCanonicalGameID when deciding whether or not to
									send game results down.
		<47>	11/16/94	ATM		Whoops, missed one.
		<46>	11/16/94	ATM		Don't send the KONrating down anymore.
		<45>	11/12/94	ATM		Invert logic on test.
		<44>	11/11/94	ATM		If the box was restored, we already sent all the ranks down.
		<43>	 11/8/94	ATM		Fixed SendAllRankings.
		<42>	 11/7/94	ATM		Made it compile.
		<41>	 11/7/94	ATM		Added Server_SendAllRankings.  Not tested (build broken).
		<40>	10/14/94	ATM		Need to use a separate range of DBIDs for each player.  (This
									should be replaced.)
		<39>	 10/2/94	ATM		Revised secret rank sequence for rating.
		<37>	 10/1/94	ATM		Moved call to UpdateGameResults out.  Adapted code to new rating
									system.
		<36>	 9/29/94	ATM		Make it count up to numRankingInfo.
		<35>	 9/25/94	ATM		Changed RankingInfo for Kon's new stuff.
		<34>	 9/22/94	ATM		Moved call to DataBase_UpdateRanking in here from ValidateLogin.
		<33>	 9/19/94	ATM		PLogmsg stuff.
		<32>	 9/12/94	ATM		Changed GameInfo stuff to Common_.  Added FreeGameInfo calls.
		<31>	  9/7/94	ATM		At highest level, was still sending previous "next rank" string.
		<30>	  9/4/94	ATM		Now use GameInfo stuff.  Removed cruft.
		<29>	  9/2/94	ATM		Minor fix.
		<28>	  9/1/94	ATM		Changed ranking strings; hope they fit on the screen now.
		<27>	 8/27/94	ATM		Joe changed his mind, '\n's are gone.
		<26>	 8/27/94	ATM		Prepended '\n's to all the ranking strings.
		<25>	 8/23/94	ATM		Changed XBAND Points to be wins.
		<24>	 8/23/94	ATM		Increased the size of a buffer.
		<23>	 8/23/94	ATM		Previous terribly important test case didn't work.
		<22>	 8/23/94	ATM		Changed rankings to work on wins (scale these vs opponent
									strength someday).
		<21>	 8/20/94	ATM		Added a new test case.
		<20>	 8/20/94	ATM		Changed secret rankings, logging.
		<19>	 8/19/94	DJ		make compile on mac
		<18>	 8/19/94	ATM		Rewrote Server_SendRanking.
		<17>	 8/18/94	BET		Fix said ranking jizz.
		<16>	 8/17/94	BET		Add sekrit ranking jizz.
		<15>	 8/12/94	ATM		Converted to Logmsg.
		<14>	  8/4/94	DJ		updated to newest rankings weirdness
		<13>	  8/2/94	DJ		commented out rankings until i update to newest stuff from Joe
		<12>	 7/26/94	DJ		sending rankings starting with dbid 1
		<11>	 7/26/94	DJ		sending 2 rankings
		<10>	 7/25/94	DJ		send 2 rankings
		 <9>	 7/20/94	DJ		added Server_Comm stuff
		 <8>	 7/19/94	DJ		tyring a dbid of 1
		 <7>	 7/19/94	DJ		sending dbid of the ranking (one per game)
		 <6>	 7/18/94	DJ		drive Ranking mgr
		 <5>	 7/12/94	DJ		using Server_TCheckError instead of TCheckError
		 <4>	  7/8/94	DJ		update to rankingmgr.h
		 <3>	  7/2/94	DJ		send real rankings
		 <2>	  6/5/94	DJ		nothing
		 <1>	 5/25/94	DJ		first checked in
	To Do:
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>

#include "ServerCore.h"
#include "Server.h"
#include "ServerDataBase.h"
#include "Server_Rankings.h"

#include "Common.h"
#include "Common_PlatformID.h"

#include "Messages.h"
#include "GameDB.h"
#include "RankingMgr.h"
#include "Server_Comm.h"
#include "DBTypes.h"
//#include "SegaIn.h"


//
// Local prototypes
//
PRIVATE RankingType *Server_BuildRanking(long boxType, RankingInfo *rankingInfo, unsigned short *bodySize, DBID *idp, char player);


#define kNumRankStrings	5			// #of strings to send for basic ranking
#define kSecretChunk	(64*4)		// call it 64 bytes for every secret rank



// Given the player's current standings, generate the ranking data.
// Returns a pointer to newly malloc()ed memory, which must be freed
// by the caller.
//
// Returns NULL if unable to complete the request.
//
PRIVATE RankingType *
Server_BuildRanking(long boxType, RankingInfo *rankingInfo, unsigned short *bodySize, DBID *idp, char player)
{
	RankingType *rankings, metric;
	const GameInfo *gameInfo;
	long numGames, gameID, platformID;
	int i, gm, rk, nextrk;
	char numBuf1[11], numBuf2[11], strBuf[64];
	const char *vector[kNumRankStrings];
	unsigned char *ucp, *metric1, *metric2;
	unsigned short *usp;
	unsigned short size;
	unsigned short upButton, downButton, leftButton, rightButton;

	if ((gameInfo = Common_GetGameInfo(&numGames)) == NULL) {
		PLogmsg(LOGP_FLAW, "WHOA: couldn't get GameInfo; Very Bad\n");
		return (NULL);
	}

	// Get the controller values for up/down/left/right.
	//
	Common_ButtonDefs(boxType, &upButton, &downButton, &leftButton,
		&rightButton);
	platformID = Common_BoxTypeToPlatformID(boxType);

	gameID = rankingInfo->gameID;		// ID to search for; affected by aliases

	for (gm = 0; gm < numGames; gm++) {
		if (gameInfo[gm].gameID == gameID &&
			gameInfo[gm].platformID == platformID)
		{
			if (gameInfo[gm].alias != 0) {
				// found an alias; change gameID and start over
				gameID = gameInfo[gm].alias;
				gm = -1;
				continue;
			}

			// found the game, find the right rank
			rk = GetCurrentLevel(rankingInfo);
			nextrk = rk + 1;
			if (rk >= gameInfo[gm].numRanks) {			// level is off scale
				rk = gameInfo[gm].numRanks - 1;			//  (congratulations)
				nextrk = rk;
			}
			if (nextrk >= gameInfo[gm].numRanks) {		// rk hit max, so we
				nextrk = gameInfo[gm].numRanks - 1;		//  got max + 1
			}

			break;
		}
	}
	if (gm == numGames) {
		PLogmsg(LOGP_FLAW, "Unable to find rank chart for %.4s-0x%.8lx\n",
			(char *)&platformID, rankingInfo->gameID);
		goto bail;
	}

	// XBAND Points
	sprintf(numBuf1, "%lu", rankingInfo->totalXBandPoints);

	// Points Needed
	if (rk == nextrk)
		strcpy(numBuf2, "---");		// can't go no higher
	else
		sprintf(numBuf2, "%lu",
			GetNextLevelPoints(rankingInfo) - rankingInfo->totalXBandPoints);

	vector[0] = gameInfo[gm].gameName;
	vector[1] = gameInfo[gm].ranks[rk].rankName;
	vector[2] = numBuf1;
	if (rk == nextrk)
		vector[3] = "---";			// that's all, folks!
	else
		vector[3] = gameInfo[gm].ranks[nextrk].rankName;
	vector[4] = numBuf2;

	Logmsg("Constructing rank for 0x%.8lx: %s %s %s %s %s\n",
		rankingInfo->gameID,
		vector[0], vector[1], vector[2], vector[3], vector[4]);

	size = 0;
	for(i = 0; i < kNumRankStrings; i++)
		size += strlen(vector[i]) + 1;
	//size += sizeof(RankingType) - 1;
	// sizeof won't work; it's a 7 byte structure, but sizeof tells us
	// that it's 8 to keep things happy
	metric1 = (unsigned char *)&metric;
	metric2 = (unsigned char *)&(metric.rankData[0]);
	size += (metric2 - metric1);

	rankings = (RankingType *)malloc((long)size + kSecretChunk);

	rankings->gameID = 			gameID;		// use aliased gameID here
	rankings->userID = 			player;

	PackStrings(rankings->rankData, kNumRankStrings, (char **)vector);

	// Set up the secret rankings.  Right now, every game gets two.  All
	// of this stuff has to fit within kSecretChunk bytes.
	//
#ifdef SEND_KON_RATS
	rankings->numHiddenStats = 3;
#else
	rankings->numHiddenStats = 2;
#endif

	// first secret rank: total points
	size += (size & 1);		// 16-bit word-align
	ucp = (unsigned char *)rankings;
	ucp += size;

	*ucp++ = 2, size++;		// make it a two-key sequence
	*ucp++ = 0, size++;		// pad
	usp = (unsigned short *) ucp;
	*usp++ = upButton, size += 2;
	*usp++ = upButton, size += 2;
	ucp = (unsigned char *) usp;
	sprintf(strBuf, gettext("Total points for: %ld, against: %ld"),
		rankingInfo->pointsFor, rankingInfo->pointsAgainst);
	strcpy((char *)ucp, strBuf);
	ucp += strlen(strBuf) +1, size += strlen(strBuf) +1;
	size += (size & 1);		// 16-bit word-align

	// second secret rank: win/loss, and my opinion
	size += (size & 1);		// 16-bit word-align
	ucp = (unsigned char *)rankings;
	ucp += size;

	*ucp++ = 2, size++;		// make it a two-key sequence
	*ucp++ = 0, size++;		// pad
	usp = (unsigned short *) ucp;
	*usp++ = upButton, size += 2;
	*usp++ = downButton, size += 2;
	ucp = (unsigned char *) usp;
	sprintf(strBuf, gettext("Total wins: %.1f, losses: %.1f"),
		(float)rankingInfo->totalWinsTimesTwo/2.0,
		(float)rankingInfo->totalLossesTimesTwo/2.0);
	if (rankingInfo->totalWinsTimesTwo > rankingInfo->totalLossesTimesTwo)
		strcat(strBuf, gettext(" (you rewl)"));
	else
		strcat(strBuf, gettext(" (practice!)"));
	strcpy((char *)ucp, strBuf);
	ucp += strlen(strBuf) +1, size += strlen(strBuf) +1;
	size += (size & 1);		// 16-bit word-align

#ifdef SEND_KON_RATS
	// third secret rank: KON-o-matic rating
	size += (size & 1);		// 16-bit word-align
	ucp = (unsigned char *)rankings;
	ucp += size;

	*ucp++ = 6, size++;		// five-key sequence
	*ucp++ = 0, size++;		// pad
	usp = (unsigned short *) ucp;
	*usp++ = downButton, size += 2;
	*usp++ = downButton, size += 2;
	*usp++ = downButton, size += 2;
	*usp++ = upButton, size += 2;
	*usp++ = downButton, size += 2;
	*usp++ = downButton, size += 2;
	ucp = (unsigned char *) usp;
	sprintf(strBuf, "Num played: %ld, rating: %ld",
		rankingInfo->numOpponentsPlayed, rankingInfo->rating);
	strcpy((char *)ucp, strBuf);
	ucp += strlen(strBuf) +1, size += strlen(strBuf) +1;
	size += (size & 1);		// 16-bit word-align
#endif

#ifdef FUBAR
	// fourth secret rank: only for NBA Jam
	if (rankings->numHiddenStats > 2) {
		size += (size & 1);		// 16-bit word-align
		ucp = (unsigned char *)rankings;
		ucp += size;

		*ucp++ = 7, size++;		// try 7 keys; max is 16
		*ucp++ = 0, size++;		// pad
		usp = (unsigned short *) ucp;
		//*usp++ = downButton, size += 2;
		*usp++ = downButton | leftButton, size += 2;	// hey, diagonals work!
		*usp++ = downButton, size += 2;
		*usp++ = downButton, size += 2;
		*usp++ = downButton, size += 2;
		*usp++ = downButton, size += 2;
		*usp++ = downButton, size += 2;
		*usp++ = upButton, size += 2;
		ucp = (unsigned char *) usp;
		strcpy(strBuf, "Dave, Brian, & Andy2 were here");
		strcpy((char *)ucp, strBuf);
		ucp += strlen(strBuf) +1, size += strlen(strBuf) +1;
		size += (size & 1);		// 16-bit word-align
	}
#endif

	// All done!
	*bodySize = size;
	*idp = gameInfo[gm].rankID;
	Common_FreeGameInfo(gameInfo);
	return (rankings);

bail:
	Common_FreeGameInfo(gameInfo);
	return (NULL);
}


// Send the player's rankings for games that need to be updated.
//
// Two reasons for using the "dirty" bit: the guy could have had his stats
// modified after an evil reset, or he could have logged in with a different
// player right after playing a game.  In either event, we would not have
// sent the stats down on the connect where they were updated.
//
// 950408: this could be called a second time from StartGamePlay... on the
// SNES, we want to send down a copy of the rankings the first time the
// game is *requested* so that the automatic score update stuff will work
// for the first game.
//
int Server_SendRanking(ServerState *state)
{
RankingType	*rankings;
RankingInfo *rankingInfo;
messOut		opCode;
DBID		id;
unsigned short		bodySize;
int i;

	PLogmsg(LOGP_PROGRESS, "Server_SendRanking\n");

	ASSERT(state->validFlags & kServerValidFlag_Account);
	if (!state->validFlags & kServerValidFlag_Account)
		return (kFucked);

	// (this no longer matters, because we go by dirty bits only)
	//if (!(state->validFlags & kServerValidFlag_GameResults)) {
	//	Logmsg("No game results, not sending stats.\n");
	//	return (kNoError);
	//}

	// Send down the ranking string for games marked "dirty".
	//
	// BRAIN DAMAGE: this should be a list, not a fixed-size array
	//
	for (i = 0; i < state->account->playerAccount.numRankingInfo; i++) {
		rankingInfo = &(state->account->playerAccount.rankingInfo[i]);

		// If this slot isn't used (gameID==0) or the dirty bit isn't set,
		// skip this entry.
		//
		if (!rankingInfo->gameID)
			continue;
		if (!(rankingInfo->detail.rankingFlags & kRankingDirty))
			continue;

		// Build the ranking string.
		//
		rankings = Server_BuildRanking(state->boxOSState.boxType,
			rankingInfo, &bodySize, &id, state->loginData.userID.userID);
		if (rankings == NULL)
			continue;
		id += state->loginData.userID.userID * 64;	// 0-63, 64-127, ...

		// Ship it!
		//
		opCode = msReceiveRanking;
		Server_SetTransportHold(state->session, true);
		Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
		Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&id);
		Server_TWriteDataSync(state->session, sizeof(unsigned short), (Ptr)&bodySize);
		Server_TWriteDataSync(state->session, (long)bodySize, (Ptr)rankings);
		Server_SetTransportHold(state->session, false);

		Logmsg("  Sent rankings for 0x%.8lx (%ld bytes, DBID=%ld)\n",
			rankings->gameID, (long)bodySize, (long)id);

		// Clear the dirty bit, set the account modified bit.
		//
		rankingInfo->detail.rankingFlags &= ~kRankingDirty;
		state->account->playerModified |= kPA_ranking;
		free(rankings);
	}


	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);
	PLogmsg(LOGP_PROGRESS, "Server_SendRanking done\n");

	return(kServerFuncOK);
}


//
// Send a player's rankings for every game he has played.  Used by
// box restore.
//
// Would be nice to just mark them as "dirty", but then they wouldn't
// get restored immediately on the other three accounts.  Explaining that
// to the customers would be annoying.
//
int Server_SendAllRankings(ServerState *state, Account *updateAccount)
{
RankingType	*rankings;
RankingInfo *rankingInfo;
messOut		opCode;
DBID		id;
unsigned short		bodySize;
int i;

	PLogmsg(LOGP_PROGRESS, "Server_SendAllRankings\n");

	// Send down the ranking string for every game he has ever played.
	//
	// BRAIN DAMAGE: this should be a list, not a fixed-size array
	//
	for (i = 0; i < updateAccount->playerAccount.numRankingInfo; i++) {
		rankingInfo = &(updateAccount->playerAccount.rankingInfo[i]);

		if (!rankingInfo->gameID)
			continue;

		rankings = Server_BuildRanking(state->boxOSState.boxType,
			rankingInfo, &bodySize, &id, updateAccount->playerAccount.player);
		if (rankings == NULL)
			continue;
		id += updateAccount->playerAccount.player * 64;	// 0-63, 64-127, ...

		opCode = msReceiveRanking;
		Server_SetTransportHold(state->session, true);
		Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
		Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&id);
		Server_TWriteDataSync(state->session, sizeof(unsigned short), (Ptr)&bodySize);
		Server_TWriteDataSync(state->session, (long)bodySize, (Ptr)rankings);
		Server_SetTransportHold(state->session, false);

		Logmsg("  Sent plyr %d's rankings for 0x%.8lx (%ld bytes, DBID=%ld)\n",
			updateAccount->playerAccount.player, rankings->gameID,
			(long)bodySize, (long)id);
		free(rankings);
	}


	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);
	PLogmsg(LOGP_PROGRESS, "Server_SendAllRankings done\n");

	return(kServerFuncOK);
}



int Server_SendDBConstants(ServerState *state, long numConsts, DBID *ids, long *constants)
{
messOut		opCode;

	PLogmsg(LOGP_PROGRESS, "Server_SendDBConstants\n");

	opCode = msSetConstants;
	Server_SetTransportHold(state->session, true);
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&numConsts);
	Server_TWriteDataSync(state->session, sizeof(DBID) * numConsts, (Ptr)ids);
	Server_TWriteDataSync(state->session, sizeof(long) * numConsts, (Ptr)constants);
	Server_SetTransportHold(state->session, false);

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_SendDBConstants done\n");

	return(kServerFuncOK);
}


int Server_SendAddItemToDB(ServerState *state, DBType theType, DBID theID, long length, void *data)
{
messOut		opCode;

	PLogmsg(LOGP_PROGRESS, "Server_SendAddItemToDB\n");

	opCode = msAddItemToDB;
	Server_SetTransportHold(state->session, true);
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr)&theType);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&theID);
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&length);
	Server_TWriteDataSync(state->session, length, (Ptr)data);
	Server_SetTransportHold(state->session, false);

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_SendAddItemToDB done\n");

	return(kServerFuncOK);
}


/*

	7/17/94
	
	These have yet to be used/tested:
	
	DoDeleteRanking
	DoGetNumRankings
	DoGetFirstRankingID
	DoGetNextRankingID
	DoGetRankingData
	
	-dj
*/

//
// No, that doesn't make me at all nervous.
//
// ++ATM 950408
//

