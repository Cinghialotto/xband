/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_EndCommunication.c,v 1.6 1996/01/25 17:54:33 hufft Exp $
 *
 * $Log: Server_EndCommunication.c,v $
 * Revision 1.6  1996/01/25  17:54:33  hufft
 * added UDP based connections
 *
 * Revision 1.5  1995/09/13  14:18:35  ted
 * Fixed warnings.
 *
 * Revision 1.4  1995/06/19  20:52:55  fadden
 * Removed attempt at reducing SIGHUPs by adding call to GetHiddenSerials.
 *
 * Revision 1.3  1995/05/27  00:58:02  jhsia
 * switch to rcs keywords
 *
 */


/*
	File:		Server_EndCommunication.c

	Contains:	Server end communication function

	Written by:	Dave Jevans


	Change History (most recent first):

		<13>	 9/19/94	ATM		PLogmsg stuff.
		<12>	 8/13/94	DJ		added forceendcomm (but it isn't used)
		<11>	 8/12/94	ATM		Converted to Logmsg.
		<10>	 7/29/94	DJ		added validation token and problem token
		 <9>	 7/20/94	DJ		added Server_Comm stuff
		 <8>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		 <7>	 7/12/94	DJ		using Server_TCheckError instead of TCheckError
		 <6>	  7/2/94	DJ		removed unused variable
		 <5>	  7/1/94	DJ		making server handle errors from the comm layer
		 <4>	  6/9/94	BET		Fix hairy compiles based on TransportSlayer.h
		 <3>	  6/5/94	DJ		making everything take a ServerState instead of SessionRec and
									added Server_DebugService
		 <2>	 5/29/94	DJ		sync writing instead of async
		 <1>	 5/25/94	DJ		first checked in
	To Do:
*/

#include "ServerCore.h"
#include "Server.h"
#include "Messages.h"
#include "Server_Comm.h"
#include <stdio.h>

#ifdef NICE_TRY
extern long gHangupOkay;
#endif

//
// Send an msEndOfStream to the box, and wait for it to reply in kind.
//
int Server_EndCommunication(ServerState *state)
{
unsigned char	opCode;
#ifdef NICE_TRY
Err				err;
BoxSerialNumber	s1, s2;
#endif

	PLogmsg(LOGP_PROGRESS, "Server_EndCommunication\n");

	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);


#ifdef NICE_TRY
	// THEORY: the X.25 hangup is arriving out of band, before the box's
	// msEndOfStream can arrive.
	//
	// As an attempted solution, we synchronize box and server, then declare
	// that we're hanging up at an acceptable time.
	//
	err = Server_GetHiddenSerials(state, &s1, &s2);
	if(err != kServerFuncOK)
		return(err);
	gHangupOkay = 1;
#endif


	// Send the end of stream message.
	//
	opCode = msEndOfStream;
	Server_TWriteDataSync(state->session, 1, (Ptr)&opCode );
	Server_TReadDataSync( state->session, 1, (Ptr)&opCode );

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	if(opCode != msEndOfStream)
	{
		//
		// Even though this is end of service, I'll return an abort just for fun.
		//
		PLogmsg(LOGP_FLAW, "Error: Box didn't respond to msEndOfStream with its own msEndOfStream\n");
		return(kServerFuncAbort);
	}

	PLogmsg(LOGP_PROGRESS, "Server_EndCommunication done\n");

	return(kServerFuncOK);
}

//
// Same as Server_EndCommunication, except doesn't wait for the box to respond with own
// msEndOfStream.
//
// Unused 8/13/94
//
int Server_ForceEndCommunication(ServerState *state)
{
unsigned char opCode;

	PLogmsg(LOGP_PROGRESS, "Server_ForceEndCommunication\n");

	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);


	opCode = msEndOfStream;
	Server_TWriteDataSync(state->session, 1, (Ptr)&opCode );

	PLogmsg(LOGP_PROGRESS, "Server_ForceEndCommunication done\n");

	return(kServerFuncOK);
}

//
// Send a new problem token
//
int Server_SendProblemToken(ServerState *state)
{
unsigned long token;
unsigned char opCode;

	PLogmsg(LOGP_PROGRESS, "Server_SendProblemToken\n");

	token = 23;
	opCode = msReceiveProblemToken;
	Server_TWriteDataSync(state->session, 1, (Ptr)&opCode );
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&token );

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_SendProblemToken done\n");

	return(kServerFuncOK);
}

//
// Send a new validation token
//
int Server_SendValidationToken(ServerState *state)
{
unsigned long token;
unsigned char opCode;

	PLogmsg(LOGP_PROGRESS, "Server_SendValidationToken\n");

	token = 987654321;
	opCode = msReceiveValidationToken;
	Server_TWriteDataSync(state->session, 1, (Ptr)&opCode );
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&token );

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_SendValidationToken done\n");

	return(kServerFuncOK);
}

