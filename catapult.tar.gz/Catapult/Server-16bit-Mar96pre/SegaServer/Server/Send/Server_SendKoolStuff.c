/*
 * Catapult Entertainment, Inc.
 *
 * $Id: Server_SendKoolStuff.c,v 1.24 1996/01/25 17:54:38 hufft Exp $
 *
 * $Log: Server_SendKoolStuff.c,v $
 * Revision 1.24  1996/01/25  17:54:38  hufft
 * added UDP based connections
 *
 * Revision 1.23  1995/11/08  18:56:53  jhsia
 * For JAPAN_TESTING, give it a really fast countdown to check the
 * translation.
 *
 * Revision 1.22  1995/10/26  03:50:34  jhsia
 * added gDebugNewsPlain and gDebugNewsEnc to measure compression performance.
 *
 * Revision 1.21  1995/10/05  17:42:16  sriram
 * Bad return args for snes news.
 *
 * Revision 1.20  1995/10/02  15:05:29  sriram
 * Better error returns for Server_UpdateBoxDocument(). Changed some
 * contanst to match the news server RPC interface.
 *
 * Revision 1.19  1995/09/13  14:18:38  ted
 * Fixed warnings.
 *
 * Revision 1.18  1995/09/11  15:39:10  chs
 * Also resend news if the box's DB is invalid.
 *
 * Revision 1.17  1995/09/11  11:26:21  sriram
 * Aliases sj01 to sn07 as a valid platform for news.
 *
 * Revision 1.16  1995/07/10  21:19:15  rich
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.15  1995/06/29  17:54:53  sriram
 * Changed some log messages.
 *
 * Revision 1.14  1995/06/26  16:06:26  sriram
 * Integration of SNES news - round 1.
 *
 * Revision 1.13  1995/06/11  18:36:15  fadden
 * Changed SNES countdown from 10 seconds to 30.
 *
 * Revision 1.12  1995/05/26  21:34:04  sriram
 * Force news to be donloaded to box if the box is being restored.
 *
 * Revision 1.11  1995/05/24  14:14:24  chs
 * Made a copy of DataBase_FreeDbItem() here.
 *
 * Revision 1.10  1995/05/19  18:50:17  sriram
 * Modifiled default page strings. DOwnload default document only if the
 * box is being restored or if this box is logging in for the first time.
 *
 * Revision 1.9  1995/05/17  23:51:17  sriram
 * Talk to the news server (as opposed to rpc.segad) to get news pages. Left
 * old news stuff intact and created a toggle in server.conf to revert back to
 * old news if needed.
 *
 * Revision 1.8  1995/05/11  05:52:43  fadden
 * Convert SNES stuff to use new "is the news up to date?" stuff.  Added note
 * about clearing the SNES news controls.
 * Added stub for Intel news (for abandonShip... yuck).
 *
 */

/*
	File:		Server_DownloadKoolStuff.c

	Contains:	Server Download kool stuff function

	Written by:	Dave Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<51>	 11/9/94	DJ		Renamed some DB routines to DataBaseUtil_ and also to WrapperDB_
									(for Oracle).
		<50>	 11/7/94	SR		added dbitems to news pages
		<49>	 11/4/94	ATM		Show how big news is in bytes.
		<48>	10/19/94	DJ		Setting the box timeout to 30 sec not 15 sec.
		<47>	10/18/94	ATM		Turned BOX_FIXED back on again, because I enjoy toggling it so
									much.
		<46>	10/18/94	ATM		Made it send news every time once again.
		<45>	10/18/94	ATM		Send a logmsg if we're sending news (or not).
		<44>	10/13/94	ATM		Include BOX_FIXED again, just to see.
		<43>	10/11/94	ATM		Removed BOX_FIXED after #of SIGHUPs jumped.
		<42>	10/10/94	DJ		turned off setting kCallWaitingConst
		<41>	10/10/94	DJ		Send nonews if 800 connect.
		<40>	10/10/94	ATM		Defined BOX_FIXED, so news isn't downloaded every time.
		<39>	 9/26/94	ATM		Converted debugN to debug[N].
		<38>	 9/22/94	ATM		Whoops, box isn't getting patched yet to handle no news.
		<37>	 9/22/94	ATM		Don't resend news unless it's more recent than what the box has.
		<36>	 9/19/94	ATM		PLogmsg stuff.
		<35>	 8/31/94	ATM		Sanity-check numPages in dlKoolStuff.
		<34>	 8/24/94	DJ		added sends of DBConsts for ted.  These should be moved to
									Brian's tool.
		<33>	 8/20/94	DJ		added an abort for Brian to test Transport bug
		<32>	 8/15/94	DJ		turned on send of news validate if no news, cuz it is a kon bug.
		<31>	 8/15/94	DJ		added send of news validate (but commented out until we are
									smart enuf to know if we've ever sent news to it).
		<30>	 8/12/94	ATM		Converted to Logmsg.
		<29>	 8/10/94	DJ		countdown starts at 30 instead of 120 now.
		<28>	  8/8/94	DJ		sends news everytime now
		<27>	  8/2/94	DJ		including DBConstants.h
		<26>	  8/2/94	DJ		bracketing with Server_SetTransportHold
		<25>	 7/31/94	DJ		changed the times in countdown
		<24>	 7/29/94	DJ		setting the news countdown kNewsCountdownConst
		<23>	 7/27/94	DJ		sending it again
		<22>	 7/26/94	DJ		aaaaaah news!
		<21>	 7/25/94	DJ		commented out kTest dialog
		<20>	 7/20/94	DJ		no ServerState passed to dbase routines
		<19>	 7/18/94	DJ		send 1st kind of news only once
		<18>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		<17>	  7/8/94	DJ		send both types of news
		<16>	  7/7/94	DJ		removed unsavory dialog
		<15>	  7/2/94	DJ		rankings
		<14>	  7/1/94	DJ		making server handle errors from the comm layer
		<13>	 6/30/94	DJ		turned news on for teddis
		<12>	 6/30/94	DJ		better news
		<11>	  6/5/94	DJ		don't send a test image
		<10>	  6/5/94	DJ		making everything take a ServerState instead of SessionRec and
									added Server_DebugService
		 <9>	  6/3/94	DJ		more news goo
		 <8>	  6/2/94	BET		send news
		 <7>	  6/1/94	DJ		text color and sending news
		 <6>	  6/1/94	BET		text color
		 <5>	  6/1/94	DJ		poo
		 <4>	 5/31/94	DJ		don't send image cuz Zeus is wrong today
		 <3>	 5/29/94	DJ		sync writing instead of async
		 <2>	 5/29/94	DJ		added dbase lookup of koolstuff msg
		 <2>	 5/25/94	DJ		bug
		 <1>	 5/25/94	DJ		first checked in
	To Do:
*/

#include <rpc/rpc.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <memory.h>

#include "ServerCore.h"
#include "Server.h"
#include "Messages.h"
#include "ServerDataBase.h"
#include "Server_Comm.h"

#include "DBTypes.h"
#include "DBConstants.h"

#include "SvrNews_Interface.h"
#include "Common_ReadConf.h"
#include "Common_Missing.h"

// SNES News stuff in in NewsFile.h
#include "NewsFile.h"

// quick check to see how effective different compression methods are
long gDebugNewsPlain, gDebugNewsEnc;

void 	DataBase_FreeDbItem(ServerDbItem *);
int 	Server_SendDbItem(ServerState *state, ServerDbItem *dbobj);
void    *SvrNews_OpenConnection();
GetDocumentResult
	*SvrNews_GetDocument(void*, GetDocumentArgs*);
int 	Server_SendDbItem(ServerState *state, ServerDbItem *dbobj);
int     Server_DownloadDocument(ServerState*, int, void*, int, int*);
int     Server_UpdateBoxDocument(ServerState*, int, void*, int, int*);

int     Server_sega_SendDocument(ServerState*, RpcNewsDocument*, int, int*);
int 	Server_sega_SendDefaultDocument(ServerState*, int);

int	Server_snes_SendNewsPage(ServerState*, DBType, SnesPageData*, int, int*);
int 	Server_snes_SendDocument(ServerState*, RpcNewsDocument*, int, int*);


/*
 * Copied this here from DataBase_News.c so we
 * don't have to link in half the ServerDatabase objects.
 *   chs 05/16/95
 */
void
DataBase_FreeDbItem(ServerDbItem * dbobj)
{
    free(dbobj->data);
    free(dbobj);
}


//
// Send a DBItem down to a box.  Used for fun news stuff.
//
int 
Server_SendDbItem(ServerState *state, ServerDbItem *dbobj)
{
    	messOut 	opCode;
    	Err		err;

        PLogmsg(LOGP_PROGRESS, "Server_SendDbItem\n");
        if(Server_DebugService(state) != kServerFuncOK)
                return(kServerFuncAbort);

        ASSERT(state);
        ASSERT(dbobj);
        if(!dbobj)
                return(kServerFuncOK);

        opCode = msAddItemToDB;
        Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
        Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr)&dbobj->type);
        Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&dbobj->id);
        Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&dbobj->length);
        Server_TWriteDataSync(state->session, dbobj->length, (Ptr)dbobj->data);

        if((err = Server_TCheckError(state->session)) != noErr)
        {
                PLogmsg(LOGP_NOTICE, "Server_TCheckError == %ld\n", err);
                return(kServerFuncAbort);
        }

        return(kServerFuncOK);
}


int
Server_sega_SendDefaultDocument(
    ServerState 	*state,
    int                 channel		// bandwidth or xband
)
{
    static NewsPage	*xbPage;
    static int		xbPageLength;
    static NewsPage	*bwPage;
    static int		bwPageLength;
    char		*pageStrings[10];
    int			numPageStrings;
    int			pageStringsLength;
    int			i;
    int			err;
    ServerNewsPage      snpage;

    if (xbPage == NULL) {
    pageStrings[0] = gettext("temporarily unavailable"); // HEADt
	pageStrings[1] = gettext("Special");         // TAGLt
	pageStrings[2] = gettext("Sorry, the latest edition of XBAND News cannot be delivered at this time. \nGo ahead and play a game, read your mail, \nand check back later.\nThanks!");
	pageStrings[3] = gettext("Page 1 of 1");         // PGNMt

	numPageStrings = 4;
	pageStringsLength = 0;
	for(i = 0; i < numPageStrings; i++) 
	    pageStringsLength += strlen(pageStrings[i]) + 1;  // include NULL

	xbPageLength = sizeof(NewsPage) + pageStringsLength - 1;
	xbPage = (NewsPage *)malloc(xbPageLength);
	ASSERT(xbPage);

	PackStrings(xbPage->text, numPageStrings, pageStrings);
	
	xbPage->newsFormID 		= 17;
        xbPage->animation1 		= 0;
        xbPage->backgroundSoundFX 	= 1;
        xbPage->bitmapID 		= 0;
        xbPage->headlineFontID 		= 4;
        xbPage->taglineFontID 		= 6;
        xbPage->dateFontID 		= 0;
        xbPage->pageNumFontID 		= 6;
        xbPage->body1FontID 		= 0;
        xbPage->body2FontID 		= 0;
        xbPage->bitmapXpos 		= 0;
        xbPage->bitmapYpos 		= 0;
        xbPage->pageNum 		= -127;
        xbPage->pageFlags 		= 27;
        xbPage->colorFlags 		= 0;
        xbPage->headlineColor0 		= 2;
        xbPage->headlineColor1 		= 0;
        xbPage->headlineColor2 		= 0;
        xbPage->headlineDrawFlags 	= 1;
        xbPage->taglineColor0 		= 0;
        xbPage->taglineColor1 		= 15;
        xbPage->taglineColor2 		= 14;
        xbPage->taglineNotUsed 		= 1;
        xbPage->pageNumColor0 		= 0;
        xbPage->pageNumColor1 		= 3;
        xbPage->pageNumColor2 		= 2;
        xbPage->pageNumNotUsed1 	= 1;
        xbPage->dateColor0 		= 0;
        xbPage->dateColor1 		= 0;
        xbPage->dateColor2 		= 0;
        xbPage->dateNotUsed 		= 0;
        xbPage->body1Color0 		= 0;
        xbPage->body1Color1 		= 13;
        xbPage->body1Color2 		= 12;
        xbPage->body1DrawFlags 		= 1;
        xbPage->body2Color0 		= 0;
        xbPage->body2Color1 		= 0;
        xbPage->body2Color2 		= 0;
        xbPage->body2DrawFlags 		= 0;
    }

    if (bwPage == NULL) {
    pageStrings[0] = gettext("temporarily unavailable"); // HEADt
	pageStrings[1] = gettext("Special");         // TAGLt
	pageStrings[2] = gettext("XBAND is unable to deliver the latest edition of BANDWIDTH at this time. Go ahead and \nplay a game, read your mail, and check back later. Thanks.\n\n\n");
	pageStrings[3] = gettext("\n\n \n\n\n\n");       // BOD2t
	pageStrings[4] = gettext("Special");         // Special
	pageStrings[5] = gettext("Page 1 of 1");         // PGNMt
	numPageStrings = 6;

	pageStringsLength = 0;
	for(i = 0; i < numPageStrings; i++) 
	    pageStringsLength += strlen(pageStrings[i]) + 1;  // include NULL

	bwPageLength = sizeof(NewsPage) + pageStringsLength - 1;
	bwPage = (NewsPage *)malloc(bwPageLength);
	ASSERT(bwPage);

	PackStrings(bwPage->text, numPageStrings, pageStrings);
	
	bwPage->newsFormID 		= 3;
        bwPage->animation1 		= 129;
        bwPage->backgroundSoundFX 	= 255;
        bwPage->bitmapID 		= 0;
        bwPage->headlineFontID 		= 4;
        bwPage->taglineFontID 		= 6;
        bwPage->dateFontID 		= 6;
        bwPage->pageNumFontID 		= 6;
        bwPage->body1FontID 		= 1;
        bwPage->body2FontID 		= 1;
        bwPage->bitmapXpos 		= 0;
        bwPage->bitmapYpos 		= 0;
        bwPage->pageNum 		= -127;
        bwPage->pageFlags 		= 63;
        bwPage->colorFlags 		= 22;
        bwPage->headlineColor0 		= 2;
        bwPage->headlineColor1 		= 0;
        bwPage->headlineColor2 		= 0;
        bwPage->headlineDrawFlags 	= 0;
        bwPage->taglineColor0 		= 0;
        bwPage->taglineColor1 		= 11;
        bwPage->taglineColor2 		= 10;
        bwPage->taglineNotUsed 		= 1;
        bwPage->pageNumColor0 		= 0;
        bwPage->pageNumColor1 		= 3;
        bwPage->pageNumColor2 		= 2;
        bwPage->pageNumNotUsed1 	= 1;
        bwPage->dateColor0 		= 0;
        bwPage->dateColor1 		= 11;
        bwPage->dateColor2 		= 10;
        bwPage->dateNotUsed 		= 1;
        bwPage->body1Color0 		= 0;
        bwPage->body1Color1 		= 15;
        bwPage->body1Color2 		= 14;
        bwPage->body1DrawFlags 		= 0;
        bwPage->body2Color0 		= 0;
        bwPage->body2Color1 		= 3;
        bwPage->body2Color2 		= 2;
        bwPage->body2DrawFlags 		= 1;
    }

    if (channel == kXBandNewsChannel) {
	snpage.type   = kOtherNews;
	snpage.length = xbPageLength;
	snpage.page   = xbPage;
	err = Server_SendFirstNewsPage(state, &snpage);
    } else if (channel == kBandwidthChannel) {
	snpage.type   = kDailyNews;
	snpage.length = bwPageLength;
	snpage.page   = bwPage;
	err = Server_SendFirstNewsPage(state, &snpage);
    } else {
	PLogmsg(LOGP_NOTICE,
	    "News: Unknown channel %d - unable to send default page\n", channel);
        err = kServerFuncOK;
    }

    return(err);
}
    


int
Server_sega_SendDocument(
    ServerState 	*state,
    RpcNewsDocument	*doc,
    int			channel,	// kXBandNewsChannel or kBandwidthChannel
    int         	*numBytes
)
{
    int			i;
    ServerDbItem	dbobj;
    ServerNewsPage	snpage;
    int			err;

    *numBytes = 0;

    if (channel == kXBandNewsChannel)
        snpage.type = kOtherNews;   
    else if (channel == kBandwidthChannel)
	snpage.type = kDailyNews;
    else {
	PLogmsg(LOGP_NOTICE,
	    "News: Unknown channel %d - unable to download document\n", channel);
	return(kServerFuncOK);
    }

    for (i = 0; i < doc->items.items_len; i++) {
 	// TODO:
 	//    Massaging RpcNewsItem into a ServerDbItem.
 	//    Make Server_SendDbItem() take a RpcNewsItem directly
 	//    once we get rid of old news.
 	dbobj.type      = doc->items.items_val[i].type;
 	dbobj.id        = doc->items.items_val[i].id;
 	dbobj.length    = doc->items.items_val[i].data.data_len;
 	dbobj.data      = doc->items.items_val[i].data.data_val;

 	err = Server_SendDbItem(state, &dbobj);
 	if (err != kServerFuncOK)
     	    return(kServerFuncAbort);

 	(*numBytes) += dbobj.length;
    }

    for (i = 0; i < doc->pages.pages_len; i++) {
	// Massage RpcNewsPage into a ServerNewsPage
	snpage.length = doc->pages.pages_val[i].data.data_len;
	snpage.page   = (NewsPage *)doc->pages.pages_val[i].data.data_val;

	// the first page is sent with a special bit on to
	// indicate to the box that it must wipe out the
	// news pages of this type ie. bandwidth or xband
	if (i == 0)
    	    err = Server_SendFirstNewsPage(state, &snpage);
	else
    	    err = Server_SendNewsPage(state, &snpage);
	if (err != kServerFuncOK)
    	    return(kServerFuncAbort);

	(*numBytes) += snpage.length;
    }

    return(kServerFuncOK);
}


int
Server_snes_SendDocument(
    ServerState         *state,
    RpcNewsDocument     *doc,
    int                 channel,        // kXBandNewsChannel or kBandwidthChannel
    int                 *numDocBytes	// number of bytes of data sent to the 
					// box for this document.
)
{
    int        	 pageNum;
    int		 itemNum;
    int        	 err;
    DBType	 dbType;
    SnesPageData *snesPage;
    int		 numPageBytes;
    ServerDbItem dbobj;

    *numDocBytes = 0;

    if (channel == kXBandNewsChannel)
        dbType = kOtherNews;
    else if (channel == kBandwidthChannel)
        dbType = kBandwidthNews;
    else {
        PLogmsg(LOGP_NOTICE,
            "Server_snes_SendDocument: unknown channel %d - not sending news\n", channel);
        return(kServerFuncOK);
    }


    for (itemNum = 0; itemNum < doc->items.items_len; itemNum++) {
        // TODO:
        //    Massaging RpcNewsItem into a ServerDbItem.
        //    Make Server_SendDbItem() take a RpcNewsItem directly
        //    once we get rid of old news.
        dbobj.type      = doc->items.items_val[itemNum].type;
        dbobj.id        = doc->items.items_val[itemNum].id;
        dbobj.length    = doc->items.items_val[itemNum].data.data_len;
        dbobj.data      = doc->items.items_val[itemNum].data.data_val;

        err = Server_SendDbItem(state, &dbobj);
        if (err != kServerFuncOK)
            return(kServerFuncAbort);
 
        (*numDocBytes) += dbobj.length;
    }


    for (pageNum = 0; pageNum < doc->pages.pages_len; pageNum++) {
	snesPage = (SnesPageData *)doc->pages.pages_val[pageNum].data.data_val;
	numPageBytes = 0;
	err = Server_snes_SendNewsPage(state, dbType, snesPage, 
			pageNum, &numPageBytes);
	if (err != kServerFuncOK)
	    return(kServerFuncAbort);

	(*numDocBytes) += numPageBytes;
    }

    return(kServerFuncOK);
}



// Server_UpdateBoxDocument:
//	1. Get the document from the news server.
//	2. Validate the document.
//	3. Download the document to the box, if the box is out of date.
//	Note: 1. the news implementation does not terminate the box 
//		 connection upon any error. The connection will be aborted 
//		 only if the error is unrecoverable. This allows for a 
//		 somewhat more graceful handling of news errors.
//	      2. The number of bytes of news data (pages + items) downloaded to 
//		 the box is returned in numBytes.
//	Returns a status bit flag with the following values ORed as necessary:
//	    kSvrNewsRealSent		- box was sent the real news
//	    kSvrNewsServerGetFailed	- unable to get the news from server
//	    kSvrNewsBoxSendFailed	- unable to send news to box
//	    kSvrNewsUnknownPlatform	- invalid platformID
//	    kSvrNewsBoxUptoDate		- box has the latest news
//	    kSvrNewsGenericSent		- box was sent the generic news
//
int
Server_UpdateBoxDocument(
    ServerState	*state,
    int		channel,		// kXBandNewsChannel or kBandwidthChannel
    void	*newsServer,		// handle to the news server
    int		documentID,		// usually set to the default
    int		*numBytes		// number of bytes of page data 
					// downloaded to box
)
{
    GetDocumentResult   *result;
    GetDocumentArgs     args;
    BoxAccount		*boxAccount;
    int			err;
    int			status;

    PLogmsg(LOGP_PROGRESS, "Server_UpdateBoxDocument\n");


    ASSERT(state);
    boxAccount = &(state->account->boxAccount);

    if ((channel != kXBandNewsChannel) && (channel != kBandwidthChannel)) {
	PLogmsg(LOGP_NOTICE, 
	    "News: Unknown channel %d - assuming kBandwidthChannel\n", channel);
	channel = kBandwidthChannel; 
    }

    // If the box is being restored, set lastArticleRead to 0 which forces 
    // the current news document to be sent to the box.
    if (state->boxRestored == true || !Server_DBIsValid(state)) {
	boxAccount->newsChannels[channel].lastArticleRead = 0;
	state->account->boxModified |= kBA_newsChannels;
    }

    *numBytes = 0;
			
    memset(&args, 0, sizeof(GetDocumentArgs));
    // The database's definitions of news channels and the news server's
    // definitions differ. Therefore do this ugly mapping for now.
    // They should be made the same when we rearrange the NewsChannels
    // stuff in the database.
    if (channel == kXBandNewsChannel)
        args.channel = kChannelXbandNews;
    else
        args.channel = kChannelBandWidth;
    args.platformID = state->boxOSState.boxType;
    args.timeStamp  = boxAccount->newsChannels[channel].lastArticleRead;
    args.documentID = documentID;
    args.boxID      = state->account->boxAccount.box.box;

    status = 0;

    ASSERT(newsServer);
    result = SvrNews_GetDocument(newsServer, &args);
    if (result == NULL) {
	PLogmsg(LOGP_FLAW, "News: Unable to connect to the news server\n");
	status |= kSvrNewsServerGetFailed;
    } else {
	if (result->status == kRpcNewsSuccess) {
	    // This document in the box is out of date and 
	    // therefore we must download the new document.
	    RpcNewsDocument	*doc;

	    PLogmsg(LOGP_PROGRESS, "Server_UpdateBoxDocument:kRpcNewsSuccess\n");

	    doc = result->GetDocumentResult_u.document;

	    switch(state->boxOSState.boxType) {
		case kBoxType_segb:
		    err = Server_sega_SendDocument(state, doc, channel, numBytes);
		    if (err != kServerFuncOK) {
			status |= kSvrNewsBoxSendFailed;
		    	return(status);
		    }
		    status |= kSvrNewsRealSent;
		    break;

		case kBoxType_sn07:
		case kBoxType_sj01:
		    err = Server_snes_SendDocument(state, doc, channel, numBytes);
		    if (err != kServerFuncOK) {
			status |= kSvrNewsBoxSendFailed;
		    	return(status);
		    }
		    status |= kSvrNewsRealSent;
		    break;

		default:
		    PLogmsg(LOGP_FLAW, 
		    	"Server_UpdateBoxDocument: unknown platform %.4s\n",
		    	&state->boxOSState.boxType);
		    status |= kSvrNewsUnknownPlatform;
		    return(status);
	    }


	    // Box document has been updated. Therefore store the document
	    // update version in the account struct.
	    if (boxAccount->numNewsChannels < (channel + 1))
		boxAccount->numNewsChannels = channel + 1;
	    boxAccount->newsChannels[channel].lastArticleRead = doc->lastModified;
	    state->account->boxModified |= kBA_newsChannels;

	} else if (result->status == kRpcNewsOldDocument) {
	    PLogmsg(LOGP_PROGRESS, 
		"Server_UpdateBoxDocument:kRpcNewsOldDocument\n");
	    Logmsg("News: [Box: %d] [Server: %d] box has the latest news\n",
		boxAccount->newsChannels[channel].lastArticleRead, 
		result->GetDocumentResult_u.lastModified);

	    status |= kSvrNewsBoxUptoDate;
	
	} else {
	    // we were able to connect to the news server, but couldnt 
	    // get a document for some reason.
	    PLogmsg(LOGP_PROGRESS, 
		"Server_UpdateBoxDocument:ERROR\n");
	    PLogmsg(LOGP_FLAW, "News: unable to get document from news server\n");

	    status |= kSvrNewsServerGetFailed;
	}

	// Calling the RPC library to free up the returned struct.
	clnt_freeres((CLIENT *)newsServer, xdr_GetDocumentResult, result);
    } 

    if (status & kSvrNewsServerGetFailed) {
	switch(state->boxOSState.boxType) {
	    case kBoxType_segb:
	        // If the box has no news (brand new box or box is being 
	        // restored from a mind-wipe), download the default news pages.
	        if ((state->boxRestored == true) || 
					(state->accountCreated == true)) {
	            err = Server_sega_SendDefaultDocument(state, channel);
		    if (err != kServerFuncOK) {
			status |= kSvrNewsBoxSendFailed;
		    	return(status);
		    }
		    status |= kSvrNewsGenericSent;
		}
	    	break;

	    case kBoxType_sn07:
		// TODO: We should send default news for SNES as well.
		break;

	    default:
		break;
	}
    }

    return(status);
}

/*
	This can use the info in ServerState to do lookups to send 
	targetted information such as:
		ranking specicific mail
		game specific info (eg. realtime NBA scores and stats)
		ads
	
*/
int Server_sega_DownloadKoolStuff(ServerState *state)
{
OSErr				err;
DBID				id;
long				countdown;
Boolean				sentNews = false;
long				newsLength = 0;
void        		*newsServer;
int         		numBytes;  

	PLogmsg(LOGP_PROGRESS, "Server_sega_DownloadKoolStuff\n");
	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);

	ASSERT(state->validFlags & kServerValidFlag_Login);


	if(state->connect800 == true)
	{
		// We need to send *something* for news if first time 
		// you are connecting (or you just crashed).
		//
		if((state->loginData.userID.box.box == -1 && 
			state->loginData.userID.box.region == -1) ||
		    (state->boxOSState.boxFlags & kOSHeapTrashed) ||
			(state->boxOSState.boxFlags & kDBHeapTrashed) ||
			(state->boxOSState.boxFlags & kBoxIDTrashed))
		{
		//
		// Hmmm.  It appears to work OK if I send nothing (not even NoNews!).
		//
		}
		else
		{
			// must have just hit "new number", so don't send any news.
			Server_SendNoNewsPage(state, kDailyNews);	// Box doesn't care about the pagetype, so anything will do.
		}

		// We check for this here, because (a) it's the first thing to happen
		// after ValidateLogin, and (b) we MUST send some news to a new box or
		// it will freak out.
		//
		// This should always be true if connect800 is true.
		//
		if (state->abandonShip) {
		
			//
			// This thing should really download the minimal patch that fixes the Transport Layer
			// so that if the connection drops during OS patch download, it doesn't fuck up.
			//
			
			Logmsg("Abandon ship!\n");
			return (kServerFuncEnd);
		}
	}


	ASSERT(state->validFlags & kServerValidFlag_Account);

	// If the box looks like it got trashed, send them a new copy of the news.
	//
	if ((state->boxOSState.boxFlags & kOSHeapTrashed) ||
		(state->boxOSState.boxFlags & kDBHeapTrashed) ||
		(state->boxOSState.boxFlags & kBoxIDTrashed))
	{
		state->account->boxAccount.debug[2] = 0;
		state->account->boxModified |= kBA_debug;
	}


//
/////////////////////////////////////////
//
// BRAIN DAMAGE.
// Set some DBConstants for ted.  These should be done by Topping's tool.
//
//	id = kListenCallWaitingTimeConst;
//	countdown = 5;
//	if(Server_SendDBConstants(state, 1, &id, &countdown) != kServerFuncOK)
//		return(kServerFuncAbort);
//
// disabled 10/10/94  dj
//
//
/////////////////////////////////////////
//

	id = kDBTransportTickleConst;
//	countdown = 5;	/* 15 seconds */
	countdown = 10;	/* 30 seconds. see if it helps the nonews SIGHUP problem.  10/19/94 */
	if(Server_SendDBConstants(state, 1, &id, &countdown) != kServerFuncOK)
		return(kServerFuncAbort);


	Server_SetTransportHold(state->session, true);

	// At this point we know:
	//	- if they need news
	//	- if they need a system patch
	//	- if they need a game patch
	// This should allow us to get a fairly accurate estimate.
	//
	id = kNewsCountdownConst;
	countdown = 60L << 16;	// ticks per count
	countdown |= 30;		// the count value (30 sec)
	if(Server_SendDBConstants(state, 1, &id, &countdown) != kServerFuncOK)
		return(kServerFuncAbort);

        sentNews = false;
        numBytes = 0;   

        newsServer = SvrNews_OpenConnection();
        if (newsServer != NULL) {    

            err = Server_UpdateBoxDocument(state, kBandwidthChannel, 
				newsServer, kDefaultDocumentID, &numBytes);
            if (err & kSvrNewsBoxSendFailed)
        	return(kServerFuncAbort);
            newsLength = numBytes;    

            err = Server_UpdateBoxDocument(state, kXBandNewsChannel, 
				newsServer, kDefaultDocumentID, &numBytes);
            if (err & kSvrNewsBoxSendFailed)
        	return(kServerFuncAbort);
            newsLength += numBytes;
 
            // newsLength bytes have actually been downloaded to the box.
            if (newsLength > 0)
        	sentNews = true;

	} else {
	    PLogmsg(LOGP_FLAW,
        	"News: Unable to open connection to the news server\n");
 
            // If the box has no news (brand new box or box is being
            // restored from a mind-wipe), download the default news pages
            // to keep the box happy.
	    if ((state->boxRestored == true) || (state->accountCreated == true)) {
		err = Server_sega_SendDefaultDocument(state, kXBandNewsChannel);
		if (err != kServerFuncOK)
		    return(kServerFuncAbort);

		err = Server_sega_SendDefaultDocument(state, kBandwidthChannel);
		if (err != kServerFuncOK)
		    return(kServerFuncAbort);
	    }
	}
 
	if (sentNews) {
		// Set debug[2] to the date we last sent news, so we 
		// can avoid sending it again if it hasn't changed.
		//
		state->account->boxAccount.debug[2] = time(0);
		state->account->boxModified |= kBA_debug;
		Logmsg("Total size of news %ld bytes\n", newsLength);
	} else {
		// Box doesn't care about the pagetype, so anything will do.
		Server_SendNoNewsPage(state, kDailyNews);	
	}


	//
	// If you want to speed up the countdown, you can change the ticks 
	// per count. The count value cannot be changed after the timer starts.
	//
	// 95/01/23: Why is this here?  We just did it up above, and according
	// to the comments we can't change it after it starts counting.  --ATM
	//
	// ticks per count (you would change this to change tick speed)
	countdown = 60L << 16;	
	// the count value (ignored after timer is started)
	countdown |= 120;		
	if(Server_SendDBConstants(state, 1, &id, &countdown) != kServerFuncOK)
		return(kServerFuncAbort);

	Server_SetTransportHold(state->session, false);


	// We check for this here, because (a) it's the first thing to happen
	// after ValidateLogin, and (b) we MUST send some news to a new box or
	// it will freak out.
	//
	// NOTE: somebody made another copy of this up above, so now it's in
	// two places.  Whatever.  --ATM 950206
	//
	if (state->abandonShip) {
		Logmsg("Abandon ship2!\n");
		return (kServerFuncEnd);
	}

	PLogmsg(LOGP_PROGRESS, "Server_sega_DownloadKoolStuff done\n");
	return (kServerFuncOK);
}


//
// SNES news and goodies.
//
// The "must send news" nightmare should be avoidable for SNES.
//
int Server_snes_DownloadKoolStuff(ServerState *state)
{
	struct stat	sb;
	DBID		id;
	long		countdown;
	char		fname[32];
	PreformedMessage *hackNews = NULL;
	int		err;
	int		sentNews;
	long		when;
	unsigned long 	stable;
	int		numBytes;
	void		*newsServer;
	int		newsLength;
	NewsChannel 	*newsChannels; 


	PLogmsg(LOGP_PROGRESS, "Server_snes_DownloadKoolStuff\n");
	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);

	// This is still necessary only because ValidateLogin is being stupid.
	//
	if (state->abandonShip) {
		Logmsg("Abandon ship (snes)!\n");
		return (kServerFuncEnd);
	}

	ASSERT(state->validFlags & kServerValidFlag_Login);
	newsChannels = state->account->boxAccount.newsChannels;

	// Set the countdown timer.  Don't know why we're doing this now.
	//
	id = kNewsCountdownConst;
	countdown = 60L << 16;	// ticks per count
#ifdef JAPAN_TESTING
	countdown |= 1;
#else
	countdown |= 30;		// the count value (30 sec)
#endif
	if (Server_SendDBConstants(state, 1, &id, &countdown) != kServerFuncOK)
		return(kServerFuncAbort);


	// If the box looks like it got trashed, send them a new copy of the news.
	//
	// The box doesn't have the news if:
	//	- the DB got wiped, OR
	//	- the OS got wiped AND the news is wiped when the OS is lost (under
	//	  SNES you don't lose the DB every time you lose the OS, but it
	//	  may wipe the news when the OS goes).
	//
	// The version numbers will be reset to zero if the DB wipes, but they
	// will NOT be reset if the OS gets wiped or (more importantly) if the
	// box decides to purge the news to get more room.  These aren't set by
	// anything except the server.
	//
	stable = state->boxOSState.osFree >> 16;	// see if DB is stable
	if (!stable || !state->systemVersionData.version) {
		PLogmsg(LOGP_DBUG,
			"OS or DB got trashed, zeroing local news versions\n");
		state->niftyInfo.snes.bandwidthVersion = 0L;
		state->niftyInfo.snes.xbandNewsVersion = 0L;
		newsChannels[kBandwidthChannel].lastArticleRead = 0;
		newsChannels[kXBandNewsChannel].lastArticleRead = 0;
	        state->account->boxModified |= kBA_newsChannels;
	}


	//
	// IMPORTANT: once we figure out how to deal with news controls, we
	// want to send the ClearMiscQueues commands that clears them BEFORE
	// we send down the news.
	//
	// We tried to do this in the usual ClearMiscQueues stuff, but the
	// news controls get locked in when the page is displayed... if the
	// user was looking at a page with controls on it when the server
	// connect ends, the controls will be set again immediately when the
	// news page gets redisplayed after the server connect.
	//
	// Anyway.  Clear them here, before we send the news.
	//

	if (gConfig.useOldNews == true) {

	    // Send the news.
	    //
	    // (This is a quick hack until we get the "real" news working.)
	    //
	    sentNews = 0;
	    when = -1;

	    sprintf(fname, "%.4s/HackNews", (char *)&state->boxOSState.boxType);// 32 char limit
	    if (stat(fname, &sb) >= 0) {
		when = sb.st_mtime;
	    } else {
		Logmsg("News stat failed (%d), will try to send news anyway.\n", errno);
	    }

	    if (when != -1 &&
		(state->niftyInfo.snes.bandwidthVersion >= when) &&
		(state->niftyInfo.snes.xbandNewsVersion >= when))
	    {
		// "when" is valid, and more recent than either version number.
		// Looks like they already have the news.
		//
		Logmsg("Box already has the news (0x%.8lx - 0x%.8lx/0x%.8lx).\n",
			when, state->niftyInfo.snes.bandwidthVersion,
			state->niftyInfo.snes.xbandNewsVersion);
		err = kServerFuncOK;
		goto skipnews;
	    } else {

		hackNews = PreformedMessage_ReadFromFile(fname);
		if (hackNews != NULL) {
			Logmsg("Sending hack newsfile %s\n", fname);
			err = Server_SendPreformedMessage(state, hackNews);
			PreformedMessage_Dispose(hackNews);
		} else {
			Logmsg("No hack newsfile found\n");
			err = kServerFuncOK;
		}
		sentNews++;
	    }

skipnews:
	    if (!sentNews) {
		// Sent the "yes, we have no news" message.  Box doesn't care
		// about the pagetype, so anything will do.
		//
		Server_SendNoNewsPage(state, kDailyNews);

	    } else {
		DBID	twoid[2];
		long	twoval[2];

		// Set the news version constants (uploaded with the IDBC stuff).
		// For now just use the current timestamp.
		//
		twoid[0] = kBANDWIDTHVersion;
		twoid[1] = kXBANDNewsVersion;
		twoval[0] = time(0);
		twoval[1] = time(0);
		if (Server_SendDBConstants(state, 2, twoid, twoval) != kServerFuncOK)
			return (kServerFuncAbort);
	    }
	} else {

	// Check to see if the box's notion of what news version it has 
	// matches that of the server. If an inconsistency is detected, reset 
	// the news versions (which will force the documents to be 
	// downloaded again).
	if (state->niftyInfo.snes.bandwidthVersion != 
		newsChannels[kBandwidthChannel].lastArticleRead) {
	    
            PLogmsg(LOGP_NOTICE,
		"SnesNews: BW box/server out of sync - [box %d][server %d]\n",
		state->niftyInfo.snes.bandwidthVersion,
		newsChannels[kBandwidthChannel].lastArticleRead);
	    state->niftyInfo.snes.bandwidthVersion 	    = 0;
	    newsChannels[kBandwidthChannel].lastArticleRead = 0;
	    state->account->boxModified |= kBA_newsChannels;
	}

	if (state->niftyInfo.snes.xbandNewsVersion != 
		newsChannels[kXBandNewsChannel].lastArticleRead) {

            PLogmsg(LOGP_NOTICE,
		"SnesNews: XB box/server out of sync - [box %d] [server %d]\n",
		state->niftyInfo.snes.xbandNewsVersion,
		newsChannels[kXBandNewsChannel].lastArticleRead);
	    state->niftyInfo.snes.xbandNewsVersion	    = 0;
	    newsChannels[kXBandNewsChannel].lastArticleRead = 0;
	    state->account->boxModified |= kBA_newsChannels;
	}

	sentNews = false;
	err	 = kServerFuncOK;

	newsServer = SvrNews_OpenConnection();
        if (newsServer != NULL) {
	    gDebugNewsPlain = gDebugNewsEnc = 0;
 
	    numBytes = 0;
	    err = Server_UpdateBoxDocument(state, kBandwidthChannel,
        		newsServer, kDefaultDocumentID, &numBytes);
            if (err & kSvrNewsBoxSendFailed)
                return(kServerFuncAbort);
            newsLength = numBytes;
 
	    numBytes = 0;
            err = Server_UpdateBoxDocument(state, kXBandNewsChannel,
                    newsServer, kDefaultDocumentID, &numBytes);
            if (err & kSvrNewsBoxSendFailed)
                return(kServerFuncAbort);
            newsLength += numBytes;

            // newsLength bytes have actually been downloaded to the box.
            if (newsLength > 0) {
                sentNews = true;
		Logmsg("Total size of news %ld bytes\n", newsLength);
		Logmsg("Size before=%ld, size after=%ld, %.2f%% reduction\n",
		    gDebugNewsPlain, gDebugNewsEnc,
		    (((double)gDebugNewsPlain - (double)gDebugNewsEnc) /
			(double)gDebugNewsPlain) * 100.0);
	    }
        } else {
            PLogmsg(LOGP_FLAW,
                    "News: Unable to open connection to the news server\n");
        }    

	if (sentNews == false) {
	    err = Server_SendNoNewsPage(state, kBandwidthNews);
	    if (err != kServerFuncOK)
		return(kServerFuncAbort);
	} else {
	    DBID	idset[2];
	    long	values[2];

	    // Set the news version constants (uploaded with the IDBC stuff).
	    idset[0] = kBANDWIDTHVersion;
	    idset[1] = kXBANDNewsVersion;
	    values[0] = newsChannels[kBandwidthChannel].lastArticleRead;
	    values[1] = newsChannels[kXBandNewsChannel].lastArticleRead;
	    if (Server_SendDBConstants(state, 2, idset, values) != kServerFuncOK)
	        return (kServerFuncAbort);
	}

	}	// gConfig.useOldNews

	PLogmsg(LOGP_PROGRESS, "Server_snes_DownloadKoolStuff done\n");
	return (kServerFuncOK);
}


//
// Intel news.  This is here solely to support state->abandonShip. :-(
//
int Server_intl_DownloadKoolStuff(ServerState *state)
{
	PLogmsg(LOGP_PROGRESS, "Server_intl_DownloadKoolStuff\n");
	if (Server_DebugService(state) != kServerFuncOK)
		return (kServerFuncAbort);

	// This is still necessary only because ValidateLogin is being stupid.
	//
	if (state->abandonShip) {
		Logmsg("Abandon ship (intl)!\n");
		return (kServerFuncEnd);
	}

	return (kServerFuncOK);
}


