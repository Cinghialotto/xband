/*
 *  Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 *	$Id: Server_SendAccountInfo.c,v 1.27 1996/02/27 23:10:40 roxon Exp $
 *
 *	$Log: Server_SendAccountInfo.c,v $
 * Revision 1.27  1996/02/27  23:10:40  roxon
 * Re-org Stats screen display for SJNE. Use 24 hour time for SJNE.
 *
 * Revision 1.26  1996/02/22  10:09:35  ted
 * Move code that downloads long distance toggle state above possible return
 * from tlayer error.
 *
 * Revision 1.25  1996/01/25  17:54:34  hufft
 * added UDP based connections
 *
 * Revision 1.24  1995/11/10  13:20:38  felix
 * The way things was, "freeMonth" could be used without being initialized in
 * Server_snes_SendCreditInfo().  Not anymore.
 *
 * Revision 1.23  1995/11/08  18:55:45  jhsia
 * Only call Server_snes_SendNewRestrictions for SNES, not SJNE.
 *
 * Revision 1.22  1995/10/27  19:43:58  steveb
 * Just did some long needed housecleaning.  No new code.
 *
 * Revision 1.21  1995/10/24  16:57:59  ted
 * Don't clear CSUpdatedRestrictions flag here -- do it in Server_UpdateDataBaseAccount.
 *
 * Revision 1.20  1995/10/03  16:56:08  ted
 * Support for displaying Est. XBN Usage on Acct Screens.
 *
 * Revision 1.19  1995/09/13  14:18:36  ted
 * Fixed warnings.
 *
 * Revision 1.18  1995/08/24  11:29:52  ted
 * Observe new kBoxFlag_DisableXBN flag.
 *
 * Revision 1.17  1995/07/19  13:03:00  ted
 * Display "Pending Credit" in challenge area fields if creditapproved flag
 * is not set for XBN.
 *
 * Revision 1.16  1995/07/10  21:18:49  rich
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.15  1995/06/15  17:06:49  ted
 * Added VIP string to restrictions if appropriate. Upated SNES restrictions.
 *
 * Revision 1.14  1995/06/08  11:14:48  ted
 * Display "Nationwide" restictions in Sega account screen.
 *
 * Revision 1.13  1995/05/27  00:58:03  jhsia
 * switch to rcs keywords
 *
 * Revision 1.12  1995/05/25  22:47:06  davej
 * Added support for new billing plans.  Changes to Server_sega_SendCreditInfo
 * and Server_snes_SendCreditInfo to support free first month policy and
 * use_credit_counting server.conf option.
 *
 *
 *
 */

#include <stdio.h>
#include <string.h>

#include "ServerCore.h"
#include "Server.h"
#include "ServerDataBase.h"
#include "Common_Missing.h"
#include "DBConstants.h"
#include "DBTypes.h"
#include "StringDB.h"
#include "Messages.h"
#include "Common_ReadConf.h"
#include "Server_Comm.h"
#include "Options.h"
#include <time.h>

static void Server_BuildRestrictions(struct Restriction *restrict, char *days, char *result);
int Server_sega_SendRestrictions(ServerState *state);
int Server_snes_SendRestrictions(ServerState *state);
int Server_sega_SendCreditInfo(ServerState *state);
int Server_snes_SendCreditInfo(ServerState *state);
PRIVATE int Server_snes_SendWriteableString(ServerState *state, char *msg, DBID idx);
PRIVATE int Server_snes_SendNewRestrictions(ServerState *state);
PRIVATE int Server_sjne_SendNewRestrictions(ServerState *state);

//
// ATM 950221: I separated these into "sega" and "snes" now because I
// need to do a minor change and my crystal balls tell me that more severe
// changes are just around the corner.
//


//
// Send down the data used on the Genesis "account info" screen.
//
// This includes the restrictions and the credit info.
//
int
Server_sega_SendAccountInfo(ServerState *state)
{
int			result;

	result = Server_sega_SendRestrictions(state);
	if(result != kServerFuncOK)
		return(result);
		
	result = Server_sega_SendCreditInfo(state);
	return(result);
}

//
// Send down the data used on the SNES "account info" screen.
//
// This includes the restrictions and the credit info.
//
int
Server_snes_SendAccountInfo(ServerState *state)
{
int			result;

	result = Server_snes_SendRestrictions(state);
	if (result != kServerFuncOK)
		return (result);
		
	result = Server_snes_SendCreditInfo(state);
	return (result);
}

int Server_sega_SendRestrictions(ServerState *state)
{
messOut				opCode;
sega_RestrictionsRecord	restr;

	PLogmsg(LOGP_PROGRESS, "Server_sega_SendRestrictions\n");
	ASSERT(state->validFlags & kServerValidFlag_Account);

	//
	// Only send restrictions if new account, box restored, or customer
	// service updated them.  Also update them if he's got "special" flags,
	// since we could be turning long distance on and off by hand.
	//
	if (!state->accountCreated && !state->boxRestored &&
		!(state->account->boxAccount.csUpdatedFlags & kCSUpdatedFlag_UpdatedRestrictions) &&
		!Server_GetSpecialPhone(state))
	{
		Logmsg("Server_sega_SendRestrictions... no need to send them.\n");
		PLogmsg(LOGP_PROGRESS, "Server_sega_SendRestrictions done\n");
		return (kServerFuncOK);
	}
	else
		Logmsg("Server_sega_SendRestrictions... sending the restrictions.\n");
	
	opCode = msReceiveRestrictions;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);

	if ((state->account->boxAccount.boxFlags & kBoxFlag_FreeXBN))
	{
		strcpy(restr.playField, gettext("Free Nationwide"));
	}
	else if ((state->account->boxAccount.boxFlags & kBoxFlag_VIP) ||
		(Server_GetSpecialPhone(state) & kSpecialVIPTester))
	{
		strcpy(restr.playField, gettext("Free Nationwide (VIP)"));
	}
	else if (Server_GetSpecialPhone(state) & kSpecialLongDistance)
	{
		// Long distance, courtesy the SpecialPhone file.
		// Note caps difference.
		strcpy(restr.playField, gettext("Long distance"));	// note caps difference
	}
	else if ((state->account->boxAccount.restrictArea & kRestrictArea_dialLongDistance) ||
			 (state->account->boxAccount.restrictArea & kRestrictArea_temporaryDialLongDistance))
	{
		strcpy(restr.playField, gettext("Long Distance"));
	}
	else if (state->account->boxAccount.restrictArea & kRestrictArea_playerListDialLongDistance)
	{
		strcpy(restr.playField, gettext("LD Player List"));
	}
	else if (state->account->boxAccount.restrictArea & kRestrictArea_XBNLongDistance)
	{
		if (state->account->boxAccount.boxFlags & kBoxFlag_DisableXBN)
			strcpy(restr.playField, gettext("NW (Disabled)"));
		else if (state->account->boxAccount.boxFlags & kBoxFlag_CreditApproved)
			strcpy(restr.playField, gettext("Nationwide"));
		else
			strcpy(restr.playField, gettext("NW (Pending Credit)"));
	}
	else if (state->account->boxAccount.restrictArea & kRestrictArea_XBNPlayerListLongDistance)
	{
		if (state->account->boxAccount.boxFlags & kBoxFlag_DisableXBN)
			strcpy(restr.playField, gettext("NW PL (Disabled)"));
		else if (state->account->boxAccount.boxFlags & kBoxFlag_CreditApproved)
			strcpy(restr.playField, gettext("Nationwide Player List"));
		else
			strcpy(restr.playField, gettext("NW PL (Pending Credit)"));
	}
	else if (Server_GetSpecialPhone(state) & kSpecialLongDistance)
	{
		strcpy(restr.playField, gettext("Long distance"));	// note caps difference
	}
	else
	{
		strcpy(restr.playField, gettext("Local"));
	}
	Logmsg("Playfield is '%s'\n", restr.playField);


	Server_BuildRestrictions(&state->account->boxAccount.restrictInfo[0], gettext("Sun - Thu"), restr.hours1);
	Server_BuildRestrictions(&state->account->boxAccount.restrictInfo[1], gettext("Fri - Sat"), restr.hours2);

	Server_TWriteDataSync(state->session, sizeof(sega_RestrictionsRecord), (Ptr)&restr);

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_sega_SendRestrictions done\n");
	return(kServerFuncOK);
}


int Server_snes_SendRestrictions(ServerState *state)
{
	DBID				id;
	long				lconst = 0;
	char				strbuf[64];

	PLogmsg(LOGP_PROGRESS, "Server_snes_SendRestrictions\n");
	ASSERT(state->validFlags & kServerValidFlag_Account);

	//
	// Only send restrictions if new account, box restored, or customer
	// service updated them.  Also update them if he's got "special" flags,
	// since we could be turning long distance on and off by hand.
	//
	if (!state->accountCreated && !state->boxRestored &&
		!(state->account->boxAccount.csUpdatedFlags & kCSUpdatedFlag_UpdatedRestrictions) &&
		!Server_GetSpecialPhone(state))
	{
		Logmsg("No need to send restrictions (snes).\n");
		PLogmsg(LOGP_PROGRESS, "Server_snes_SendRestrictions done\n");
		return (kServerFuncOK);
	}
	else
		Logmsg("Server_snes_SendRestrictions... sending the restrictions.\n");

	// default is local
	lconst = kLocalOption;

	if ((state->account->boxAccount.boxFlags & kBoxFlag_FreeXBN))
	{
		Server_SendWritableString(state, "Free Nationwide", kChallengeAreaData);
		lconst = kLongDistanceOption;
	}
	else if ((state->account->boxAccount.boxFlags & kBoxFlag_VIP) ||
		(Server_GetSpecialPhone(state) & kSpecialVIPTester))
	{
		Server_SendWritableString(state, "Free Nationwide (VIP)", kChallengeAreaData);
		lconst = kLongDistanceOption;
	}
	else if (Server_GetSpecialPhone(state) & kSpecialLongDistance)
	{
		// Long distance, courtesy the SpecialPhone file.
		// Note caps difference.
		Server_SendWritableString(state, gettext("Long distance"), kChallengeAreaData);
		lconst = kLongDistanceOption;
	}
	else if ((state->account->boxAccount.restrictArea & kRestrictArea_dialLongDistance) ||
			 (state->account->boxAccount.restrictArea & kRestrictArea_temporaryDialLongDistance))
	{
		Server_SendWritableString(state, gettext("Long Distance"), kChallengeAreaData);
		lconst = kLongDistanceOption;
	}
	else if (state->account->boxAccount.restrictArea & kRestrictArea_playerListDialLongDistance)
	{
		Server_SendWritableString(state, gettext("LD Player List"), kChallengeAreaData);
		// Challange area doesn't affect player-list matches, so there's
		// no reason to let the user mess with it.
	}
	else if (state->account->boxAccount.restrictArea & kRestrictArea_XBNLongDistance)
	{
		if (state->account->boxAccount.boxFlags & kBoxFlag_DisableXBN) {
			Server_SendWritableString(state, gettext("NW (Disabled)"), kChallengeAreaData);
		}
		else if (state->account->boxAccount.boxFlags & kBoxFlag_CreditApproved)
		{
			Server_SendWritableString(state, gettext("Nationwide"), kChallengeAreaData);
			lconst = kLongDistanceOption;
		}
		else
		{
			Server_SendWritableString(state, gettext("NW (Pending Credit)"), kChallengeAreaData);
		}
	}
	else if (state->account->boxAccount.restrictArea & kRestrictArea_XBNPlayerListLongDistance)
	{
		if (state->account->boxAccount.boxFlags & kBoxFlag_DisableXBN) {
			Server_SendWritableString(state, gettext("NW PL (Disabled)"), kChallengeAreaData);
		}
		else if (state->account->boxAccount.boxFlags & kBoxFlag_CreditApproved)
		{
			Server_SendWritableString(state, gettext("Nationwide Player List"), kChallengeAreaData);
			lconst = kLongDistanceOption;
		}
		else
		{
			Server_SendWritableString(state, gettext("NW PL (Pending Credit)"), kChallengeAreaData);
		}
	}
	else
	{
		Server_SendWritableString(state, gettext("Local"), kChallengeAreaData);
	}
	// Send down a DB constant that affects whether or not the user is
	// allowed to choose between local and long distance calling.
	//
	id = kBoxGlobalCallingAreaOptionsConst;
	if (Server_SendDBConstants(state, 1, &id, &lconst) != kServerFuncOK)
		return (kServerFuncAbort);
	Logmsg("Playfield set, ldist option=%d\n", lconst);

	Server_BuildRestrictions(&state->account->boxAccount.restrictInfo[0],
		gettext("Sun - Thu"), strbuf);
	Server_SendWritableString(state, strbuf, kHoursOfPlay1);

	Server_BuildRestrictions(&state->account->boxAccount.restrictInfo[1],
		gettext("Fri - Sat"), strbuf);
	Server_SendWritableString(state, strbuf, kHoursOfPlay2);

	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_snes_SendRestrictions done\n");
	return(kServerFuncOK);
}


int Server_sega_SendCreditInfo(ServerState *state)
{
messOut			opCode;
CreditRecord		credits;
int			freeMonth;	// Ret from Server_IsFreeMonth()

	PLogmsg(LOGP_PROGRESS, "Server_sega_SendCreditInfo\n");
	ASSERT(state->validFlags & kServerValidFlag_Account);

	opCode = msReceiveCredit;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);

	//
	// In patch 40 the box learned how to display "unlimited" when sent -1 as the number credits remaining.
	// 11/15/94 dj
	//

	//
	// New (6/1/95) billing plans: give 'em "unlimited" in initial "free month"
	//
	// Calculate credits left in account
	//
	if ((state->account->boxAccount.maxCredits == kUnlimitedXBandCredits)
	    || (freeMonth = Server_IsFreeMonth(state->account)))
		credits.accountCredits = (short)kUnlimitedXBandCredits;
	else
		credits.accountCredits = state->account->boxAccount.maxCredits
			- state->account->boxAccount.usedCredits;

	//
	// Now calculate credits used
	//
	if ((freeMonth) || (state->account->boxAccount.maxCredits != kUnlimitedXBandCredits))
		credits.usedCredits = state->account->boxAccount.usedCredits
			- state->account->boxAccount.startCredits;
	else
		credits.usedCredits = state->account->boxAccount.usedCredits;

#ifdef OLD_STUFF
	if(state->account->boxAccount.maxCredits >= kAllYouCanEatCredits)
	{
		//
		// This is a big BRAIN DAMAGE hack that should be removed by Jan 1, 95.
		// This basically allows anyone who has a spending cap over the basic $7.95 plan to keep on playing
		// past their limit.  This is because we're going to give them "all you can eat" until Jan 95
		// because Compuserve is giving us the connect time at a flat rate till then.  Yahoo!  More traffic!
		// See also Server_CheckAccountCredits.c
		// 11/15/94/dj
		//

		if(state->account->boxAccount.usedCredits >= kAllYouCanEatCredits)
			credits.accountCredits = (short)kUnlimitedXBandCredits;
	}
#endif /*OLD_STUFF*/
	

	if (credits.usedCredits < 0) {
		// Because of refunds or gifts they're below zero, so just set it to
		// zero.  No need to adjust credits.accountCredits, since it already
		// has the full measure of usedCredits included.
		//
		credits.usedCredits = 0;
	}


	Logmsg("Server_sega_SendCreditInfo: accountCredits = %ld, usedCredits = %ld\n",
		credits.accountCredits, credits.usedCredits);

	Server_TWriteDataSync(state->session, sizeof(CreditRecord), (Ptr)&credits);

	//
	// Ted (8/25/95) - Override "XBAND Credits Remaining" for "Nationwide Usage"
	// Revert if not a Nationwide player. This means deleting the overriden db items
	// every time through here, but at least there is no box/server inconsistency.
	//
	if (state->account->boxAccount.restrictArea & kRestrictArea_XBNMask)
	{
		// override db items
		char buf[512];
		char monthstr[128];
		unsigned long length;
		DBType type;
		DBID id;
		struct tm tm;
		char descdata[] = {
			0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x01, 0x00,
			0x00, 0x00, 0x0D, 0x0C, 0x00, 0x00, 0x00, 0x01, 0x77
		};

		length = sizeof(descdata);
		type = kObjectDesc;
		id = 55;
		opCode = msAddItemToDB;
		Server_SetTransportHold(state->session, true);
		Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode);
		Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &type);
		Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &id);
		Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length);
		Server_TWriteDataSync(state->session, length, (Ptr) descdata);
		Server_SetTransportHold(state->session, false);

		// format the usage string
		tm.tm_mon = state->account->boxAccount.xbnUsage.current.month;
		strftime(monthstr, sizeof(monthstr), "%B", &tm);
		sprintf(buf,gettext("Est. Nationwide minutes for %s: %ld"),
			monthstr,state->account->boxAccount.xbnUsage.current.minutes);

		Server_SendXYString(state, buf, kStringType, 119);
	}
	else
	{
		// delete db items
		Server_DeleteDBItem(state, kStringType, 119);
		Server_DeleteDBItem(state, kObjectDesc, 55);
	}

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_sega_SendCreditInfo done\n");

	return(kServerFuncOK);
}

int Server_snes_SendCreditInfo(ServerState *state)
{
//CreditRecord		credits;
char				strbuf[64];
long				val;
int				freeMonth;	// Ret from Server_IsFreeMonth()

	PLogmsg(LOGP_PROGRESS, "Server_snes_SendCreditInfo\n");
	ASSERT(state->validFlags & kServerValidFlag_Account);

	//
	// New (6/1/95) billing plans: give 'em "unlimited" in initial "free month"
	//
	// Calculate credits left in account
	//

	freeMonth = Server_IsFreeMonth(state->account);

	if ((state->account->boxAccount.maxCredits == kUnlimitedXBandCredits)
	    || freeMonth)
		strcpy(strbuf, gettext("Unlimited"));
	else
		sprintf(strbuf, "%ld", state->account->boxAccount.maxCredits - state->account->boxAccount.usedCredits);
	Server_SendWritableString(state, strbuf, kAccountCreditsData);

	//
	// Now calculate credits used
	//
	if ((freeMonth) || (state->account->boxAccount.maxCredits != kUnlimitedXBandCredits))
		val = state->account->boxAccount.usedCredits - state->account->boxAccount.startCredits;
	else
		val = state->account->boxAccount.usedCredits;

	if (val < 0) {
		// Because of refunds or gifts they're below zero, so just set it to
		// zero.  No need to adjust credits.accountCredits, since it already
		// has the full measure of usedCredits included.
		//
		val = 0;
	}
	sprintf(strbuf, "%ld", val);
	Server_SendWritableString(state, strbuf, kCreditsUsedData);
	
	// Send down a new Account Info screen for XBN stuff.  Not needed
	// for Japan.
	//
	if (state->platformID == kPlatformSNES)
		Server_snes_SendNewRestrictions(state);
	else if ( LOCALE_PHONE_JA() )				// Japan needs another one
		Server_sjne_SendNewRestrictions(state);

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_snes_SendCreditInfo done\n");
	return(kServerFuncOK);
}


//
// Build the restriction strings.
//
// Result is placed into "result".
//
static void Server_BuildRestrictions(Restriction *restrict, char *days, char *result)
{
char starthalf[4], endhalf[4];
short start, end;

	start = restrict->start;
	end = restrict->end;

	if(start == kRestrictionTime_PlayAnytime
	&& end == kRestrictionTime_PlayAnytime)
		sprintf(result, gettext("%s  Anytime"), days);
	else
	if(start == kRestrictionTime_PlayNever
	&& end == kRestrictionTime_PlayNever)
		sprintf(result, gettext("%s  Never"), days);
	else
	{
		// 1 tick per minute.
		//
		long starthour, startmin;
		long endhour, endmin;
		
		if(start < 0)
		{
			Logmsg("Server_BuildRestrictions: %ld is an invalid start restriction time.\n", (long)start);
			start = 0;
		}
		if(start > 60*24)
		{
			Logmsg("Server_BuildRestrictions: %ld is an invalid start restriction time.\n", (long)start);
			start = 60*24;
		}

		if(end < 0)
		{
			Logmsg("Server_BuildRestrictions: %ld is an invalid end restriction time.\n", (long)end);
			end = 0;
		}
		if(end > 60*24)
		{
			Logmsg("Server_BuildRestrictions: %ld is an invalid end restriction time.\n", (long)end);
			end = 60*24;
		}
		
		starthour 	= start / 60;
		startmin 	= start % 60;
		endhour 	= end / 60;
		endmin 		= end % 60;

	  if ( !LOCALE_PHONE_JA() ) {
		if(starthour < 12)
			strcpy(starthalf, gettext("am"));
		else
			strcpy(starthalf, gettext("pm"));
		if(endhour < 12)
			strcpy(endhalf, gettext("am"));
		else
			strcpy(endhalf, gettext("pm"));

		if(starthour > 12)		// don't display 24 hour time.
			starthour -= 12;
		if(endhour > 12)
			endhour -= 12;

		if(starthour == 0)
			starthour = 12;
		if(endhour == 0)
			endhour = 12;
	  }

		if ( LOCALE_PHONE_JA() )
			sprintf(result, "%s  %02ld:%02ld - %02ld:%02ld",
								days, starthour, startmin, endhour, endmin);
		else
			sprintf(result, "%s  %ld:%02ld %s - %ld:%02ld %s", days, starthour, startmin, starthalf, endhour, endmin, endhalf);
	}
}


//
// Send down a new REST resource for SNES iff we're subscribed to XBN.
//
PRIVATE int Server_snes_SendNewRestrictions(ServerState *state)
{
	struct tm tm;
	char min[128];
	char mon[128];
	int structSize;
	short theSize;
	unsigned char opCode;

#ifdef STOCK_REST
	snes_RestrictionsRecord resRec = {
		{ 3, 4, 30, 23 }, 0, 14
	};
	StringRecord strRecs[14] = {
		{156,129,0x6c,93},		// card data, not used (must be first!)
		{ 76,  0,0x2a,80},		// account info
		{ 10, 22,0x1c,81},		// challange area
		{ 94, 22,0x6c,82},		// challenge area data
		{ 10, 40,0x1c,83},		// hours of play
		{ 94, 39,0x6c,84},		// hours of play data 1
		{ 94, 55,0x6c,85},		// hours of play data 2
		{ 90, 70,0x2a,86},		// credits
		{ 10, 90,0x2a,87},		// credit used this month
		{174, 89,0x6c,88},		// credit used data
		{ 33,110,0x1a,89},		// xband credits remaining
		{ 12,130,0x1c,90},		// account
		{ 62,129,0x6c,91},		// account credits data
		{126,130,0x1c,92}		// card
	};
#else
	snes_RestrictionsRecord resRec = {
		{ 3, 4, 30, 23 }, 0, 19
	};
	StringRecord strRecs[19] = {
		{156,129,0x6c,93},		// card data, not used (must be first!)
		{ 72,  0,0x2a,80},		// account info

		{ 10, 19,0x1c,81},		// challange area
		{ 94, 18,0x6c,82},		// challenge area data
		
		{ 10, 33,0x1c,83},		// hours of play
		{ 94, 32,0x6c,84},		// hours of play data 1
		{ 94, 45,0x6c,85},		// hours of play data 2
		
		{ 10, 58,0x1a,kEstimatedXBNUsage},		// Estimated XBAND Nationwide Minutes Used
		{ 15, 72,0x1c,kPrevXBNMonth},			// Month
		{ 76, 71,0x6c,kPrevXBNMonthData},		// minutes
		{115, 72,0x1c,kThisXBNMonth},			// Month
		{180, 71,0x6c,kThisXBNMonthData},		// minutes
		
		{ 82, 85,0x2a,86},		// credits

		{ 10,103,0x1c,87},		// credits used this month
		{174,102,0x6c,88},		// credits used data

		{ 33,116,0x1a,89},		// xband credits remaining
	
		{ 12,130,0x1c,90},		// account
		{ 62,129,0x6c,91},		// account credits data

		{126,130,0x1c,92}		// card
	};

// The following are directly tied to the above data structure. If you move things
// around, be sure to update the following indicies...
#define kPrevMonIndex 	8		// index into strRecs array
#define kPrevMinIndex	9		// index into strRecs array
#define kThisMonIndex	10		// index into strRecs array
#define kThisMinIndex	11		// index into strRecs array
// This is just font/color/positioning stuff which isn't as critical to above.
#define kOffsetPixels	4
#define kREDTEXT		0x6e	// font/color id for red thin9
#define kBLUETEXT		0x6a	// font/color id for red thin9

#endif
	PLogmsg(LOGP_PROGRESS, "Server_snes_SendNewRestrictions\n");

	if (!(state->account->boxAccount.restrictArea & kRestrictArea_XBNMask))
	{
		// revert to box rom version
		Server_SetTransportHold(state->session, true);
		Server_DeleteDBItem(state, kRestrictionsDBType, 0);
		Server_DeleteDBItem(state, kWriteableString, kEstimatedXBNUsage);
		Server_DeleteDBItem(state, kWriteableString, kPrevXBNMonth);
		Server_DeleteDBItem(state, kWriteableString, kPrevXBNMonthData);
		Server_DeleteDBItem(state, kWriteableString, kThisXBNMonth);
		Server_DeleteDBItem(state, kWriteableString, kThisXBNMonthData);
		Server_SetTransportHold(state->session, false);
		return (kServerFuncOK);
	}
	
	// Now send down the writeable strings that make up the message.
	//
	Server_snes_SendWriteableString(state, "Est. XBAND Nationwide Minutes Used",
		kEstimatedXBNUsage);
	
	//
	// Previous Month
	//
	tm.tm_mon = state->account->boxAccount.xbnUsage.previous.month;
	strftime(mon, sizeof(mon), "%B:", &tm);
	strRecs[kPrevMinIndex].xPos = strRecs[kPrevMonIndex].xPos +
		snes_MeasureTextBold9Width(mon) + kOffsetPixels;
	if (state->account->boxAccount.xbnUsage.previous.year < 95)
		strcpy(min,gettext("N/A"));
	else
		sprintf(min,"%d", state->account->boxAccount.xbnUsage.previous.minutes);
	if (state->account->boxAccount.xbnUsage.previous.minutes >=
	state->account->boxAccount.xbnUsage.monthlycap)
		strRecs[kPrevMinIndex].fontIDandcolorPack = kBLUETEXT;
	else if (state->account->boxAccount.xbnUsage.previous.minutes >=
	(gConfig.defaultXNPrecapThresh * state->account->boxAccount.xbnUsage.monthlycap))
		strRecs[kPrevMinIndex].fontIDandcolorPack = kREDTEXT;
	Server_snes_SendWriteableString(state, mon, kPrevXBNMonth);
	Server_snes_SendWriteableString(state, min, kPrevXBNMonthData);
	
	//
	// Current Month
	//
	tm.tm_mon = state->account->boxAccount.xbnUsage.current.month;
	strftime(mon, sizeof(mon), "%B:", &tm);
	strRecs[kThisMinIndex].xPos = strRecs[kThisMonIndex].xPos +
		snes_MeasureTextBold9Width(mon) + kOffsetPixels;
	if (state->account->boxAccount.xbnUsage.current.year < 95)
		strcpy(min,gettext("N/A"));
	else
		sprintf(min,"%d", state->account->boxAccount.xbnUsage.current.minutes);
	if (state->account->boxAccount.xbnUsage.current.minutes >
	state->account->boxAccount.xbnUsage.monthlycap)
		strRecs[kThisMinIndex].fontIDandcolorPack = kBLUETEXT;
	else if (state->account->boxAccount.xbnUsage.current.minutes >
	(gConfig.defaultXNPrecapThresh * state->account->boxAccount.xbnUsage.monthlycap))
		strRecs[kThisMinIndex].fontIDandcolorPack = kREDTEXT;
	Server_snes_SendWriteableString(state, mon, kThisXBNMonth);
	Server_snes_SendWriteableString(state, min, kThisXBNMonthData);

	//
	// Override box with new REST resource
	//
	opCode = msReceiveRestrictions;
	if(Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode) != noErr)
		return(kServerFuncAbort);

	structSize = ((unsigned char *)&resRec.text) - ((unsigned char *)&resRec);
	theSize = structSize + sizeof(strRecs);

	if(Server_TWriteDataSync(state->session, sizeof(short), (Ptr) &theSize) != noErr)
		return(kServerFuncAbort);

	//Loghexdump((char *)&resRec, structSize);
	if(Server_TWriteDataSync(state->session, structSize, (Ptr) &resRec) != noErr)
		return(kServerFuncAbort);
	
	//Loghexdump((char *)&strRecs, sizeof(strRecs));
	if(Server_TWriteDataSync(state->session, sizeof(strRecs), (Ptr) &strRecs) != noErr)
		return(kServerFuncAbort);

	return (kServerFuncOK);
}

//
// Send down a new REST resource for SJNES iff we're subscribed to XBN.
//
PRIVATE int Server_sjne_SendNewRestrictions(ServerState *state)
{
	struct tm tm;
	char min[128];
	char mon[128];
	int structSize;
	short theSize;
	unsigned char opCode;
	char	strbuf[128];

#ifdef STOCK_REST
	sjne_RestrictionsRecord resRec = {
		{ 3, 4, 30, 23 }, 0, 14
	};
	StringRecord strRecs[14] = {
		{156,129,0x6c,93},		// card data, not used (must be first!)
		{ 76,  0,0x2a,80},		// account info
		{ 10, 22,0x1c,81},		// challange area
		{ 94, 22,0x6c,82},		// challenge area data
		{ 10, 40,0x1c,83},		// hours of play
		{ 104, 39,0x6c,84},		// hours of play data 1
		{ 94, 55,0x6c,85},		// hours of play data 2
		{ 90, 70,0x2a,86},		// credits
		{ 10, 90,0x2a,87},		// credit used this month
		{174, 89,0x6c,88},		// credit used data
		{ 33,110,0x1a,89},		// xband credits remaining
		{ 12,130,0x1c,90},		// account
		{ 62,129,0x6c,91},		// account credits data
		{126,130,0x1c,92}		// card
	};
#else
	snes_RestrictionsRecord resRec = {
		{ 3, 4, 30, 23 }, 0, 10
	};
	StringRecord strRecs[10] = {
		{156,129,0x6c,93},		// card data, not used (must be first!)
		{ 72,  0,0x1c,80},		// account info

		{ 10, 27,0x2a,81},		// challange area
		{ 94, 27,0x1c,82},		// challenge area data
		
		{ 10, 51,0x2a,83},		// hours of play
		{ 94, 51,0x1c,84},		// hours of play data 1
		{ 94, 71,0x1c,85},		// hours of play data 2
		
		{ 68,100,0x1c,86},		// credits

		{ 10,128,0x2a,89},		// xband credits remaining
		{120,130,0x1c,93}		// smart credits data
	};

#endif
	PLogmsg(LOGP_PROGRESS, "Server_sjne_SendNewRestrictions\n");

	if ((state->account->boxAccount.boxFlags & kBoxFlag_FreeXBN))
	{
		Server_SendWritableString(state, "Free Nationwide", kChallengeAreaData);
	}
	else if ((state->account->boxAccount.boxFlags & kBoxFlag_VIP) ||
		(Server_GetSpecialPhone(state) & kSpecialVIPTester))
	{
		Server_SendWritableString(state, "Free Nationwide (VIP)", kChallengeAreaData);
	}
	else if (Server_GetSpecialPhone(state) & kSpecialLongDistance)
	{
		// Long distance, courtesy the SpecialPhone file.
		// Note caps difference.
		Server_SendWritableString(state, gettext("Long distance"), kChallengeAreaData);
	}
	else if ((state->account->boxAccount.restrictArea & kRestrictArea_dialLongDistance) ||
			 (state->account->boxAccount.restrictArea & kRestrictArea_temporaryDialLongDistance))
	{
		Server_SendWritableString(state, gettext("Long Distance"), kChallengeAreaData);
	}
	else if (state->account->boxAccount.restrictArea & kRestrictArea_playerListDialLongDistance)
	{
		Server_SendWritableString(state, gettext("LD Player List"), kChallengeAreaData);
		// Challange area doesn't affect player-list matches, so there's
		// no reason to let the user mess with it.
	}
	else if (state->account->boxAccount.restrictArea & kRestrictArea_XBNLongDistance)
	{
		if (state->account->boxAccount.boxFlags & kBoxFlag_DisableXBN) {
			Server_SendWritableString(state, gettext("NW (Disabled)"), kChallengeAreaData);
		}
		else if (state->account->boxAccount.boxFlags & kBoxFlag_CreditApproved)
		{
			Server_SendWritableString(state, gettext("Nationwide"), kChallengeAreaData);
		}
		else
		{
			Server_SendWritableString(state, gettext("NW (Pending Credit)"), kChallengeAreaData);
		}
	}
	else if (state->account->boxAccount.restrictArea & kRestrictArea_XBNPlayerListLongDistance)
	{
		if (state->account->boxAccount.boxFlags & kBoxFlag_DisableXBN) {
			Server_SendWritableString(state, gettext("NW PL (Disabled)"), kChallengeAreaData);
		}
		else if (state->account->boxAccount.boxFlags & kBoxFlag_CreditApproved)
		{
			Server_SendWritableString(state, gettext("Nationwide Player List"), kChallengeAreaData);
		}
		else
		{
			Server_SendWritableString(state, gettext("NW PL (Pending Credit)"), kChallengeAreaData);
		}
	}
	else
	{
		Server_SendWritableString(state, gettext("Local"), kChallengeAreaData);
	}

	Server_BuildRestrictions(&state->account->boxAccount.restrictInfo[0],
			gettext("Sun - Thu"), strbuf);
	Server_SendWritableString(state, strbuf, kHoursOfPlay1);

	Server_BuildRestrictions(&state->account->boxAccount.restrictInfo[1],
			gettext("Fri - Sat"), strbuf);
	Server_SendWritableString(state, strbuf, kHoursOfPlay2);

	//
	// Override box with new REST resource
	//
	opCode = msReceiveRestrictions;
	if(Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode) != noErr)
		return(kServerFuncAbort);

	structSize = ((unsigned char *)&resRec.text) - ((unsigned char *)&resRec);
	theSize = structSize + sizeof(strRecs);

	if(Server_TWriteDataSync(state->session, sizeof(short), (Ptr) &theSize) != noErr)
		return(kServerFuncAbort);

	//Loghexdump((char *)&resRec, structSize);
	if(Server_TWriteDataSync(state->session, structSize, (Ptr) &resRec) != noErr)
		return(kServerFuncAbort);
	
	//Loghexdump((char *)&strRecs, sizeof(strRecs));
	if(Server_TWriteDataSync(state->session, sizeof(strRecs), (Ptr) &strRecs) != noErr)
		return(kServerFuncAbort);

	return (kServerFuncOK);
}

//
// A routine that appears to be identical to Server_SendWritableString(),
// except that it doesn't use transport hold calls and is therefore less
// efficient.
//
PRIVATE int Server_snes_SendWriteableString(ServerState *state, char *msg,
	DBID idx)
{
	unsigned char 	opCode;
	long			length;

	PLogmsg(LOGP_PROGRESS, "Server_snes_TestWriteableString('%s', %d)\n",
		msg, idx);

	opCode = msReceiveWriteableString;
	if(Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode) != noErr)
		return(kServerFuncAbort);

	if(Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &idx) != noErr)
		return(kServerFuncAbort);

	length = strlen( msg ) + 1;
	if(Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length) != noErr)
		return(kServerFuncAbort);

	if(Server_TWriteDataSync(state->session, length, (Ptr) msg) != noErr)
		return(kServerFuncAbort);

	return (kServerFuncOK);
}


