/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_SendMail.c,v 1.20 1996/03/05 15:55:20 fadden Exp $
 *
 * $Log: Server_SendMail.c,v $
 * Revision 1.20  1996/03/05  15:55:20  fadden
 * Show uncompressed form of message before sending it down to box.
 *
 * Revision 1.19  1996/02/02  15:43:23  chs
 * use gConfig.catapultTown everywhere.
 *
 * Revision 1.18  1996/01/25  17:54:40  hufft
 * added UDP based connections
 *
 * Revision 1.17  1995/10/07  15:05:46  roxon
 * Use "vNewMaxInBoxEntries" (8/10 - depending on paltformID) instead of
 * kMaxInBoxEntries (10).
 *
 * Revision 1.16  1995/09/13  14:18:39  ted
 * Fixed warnings.
 *
 * Revision 1.15  1995/07/10  21:19:39  rich
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.14  1995/06/26  15:59:48  fadden
 * Changed dialog text from "new messages" to "more messages" for Joey.  (Occurs
 * when not all mail could be sent down from the server because of the #of
 * messages already on the box.)
 *
 * Revision 1.13  1995/06/08  11:15:09  ted
 * Observe kBoxFlag_VIP.
 *
 * Revision 1.12  1995/05/27  00:58:10  jhsia
 * switch to rcs keywords
 *
 */

// If this is defined, we use "VipMail" instead of "BetaMail".
//
#define VIPMAIL


/*
	File:		Server_SendMail.c

	Contains:	Server send mail function

	Written by:	Dave Jevans


	Change History (most recent first):

		<34>	12/11/94	ATM		Change mail address "stadler" to "vip".
		<33>	 12/7/94	ATM		Add vipMail kluge.
		<32>	11/17/94	KD		Updated dialog text (doug/kon).
		<31>	11/17/94	KD		Updated dialog box wording (doug/kon).
		<30>	11/15/94	HEC		Made Server_SendMailBody public.
		<29>	 11/9/94	DJ		Adding some more mail routines to WrapperDB
		<28>	 11/9/94	DJ		Renamed some DB routines to DataBaseUtil_ and also to WrapperDB_
									(for Oracle).
		<27>	 11/4/94	DJ		Broadcast mail now goes thru the newsChannels struct.
		<26>	10/20/94	DJ		Added "dialog" in caps comment on same line as server dialogs
									(useful for greping).
		<25>	10/17/94	DJ		Filtering mail to box if BoxFlag_FilterMail is true
		<24>	 9/19/94	ATM		PLogmsg stuff.
		<23>	  9/2/94	DJ		tracking mail serial numbers in playerAccount->mailInBox[]
		<22>	 8/29/94	ATM		Fixed one of them thar plural dialogs.
		<21>	 8/28/94	ATM		Make tired company president happy by handling mono/plural stuff
									in mail dialogs.
		<20>	 8/22/94	DJ		groomed dialog text
		<19>	 8/17/94	DJ		send "no new  mail" only for a mail only connect
		<18>	 8/15/94	DJ		sticky dialogs for mail only connect
		<17>	 8/12/94	DJ		updated to new userIdentification
		<16>	 8/12/94	ATM		Converted to Logmsg.
		<15>	  8/8/94	DJ		SendDialog takes boolean whether to stick or disappear in 3 sec.
		<14>	  8/3/94	DJ		jizzle jozzle
		<13>	  8/3/94	DJ		new mail sending (cuz Kon's new mail shit wasn't compatible with
									x-platform)
		<12>	  8/2/94	DJ		update to latest mail sending scheme (added SendMailBody
		<11>	 7/20/94	DJ		added Server_Comm stuff
		<10>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		 <9>	 7/15/94	DJ		send dialogs telling box how much mail was downloaded, how much
									left on server, etc
		 <8>	 7/12/94	DJ		using Server_TCheckError instead of TCheckError
		 <7>	  7/1/94	DJ		making server handle errors from the comm layer
		 <6>	 6/30/94	DJ		added broadcast mail
		 <5>	  6/9/94	BET		Fix hairy compiles based on TransportSlayer.h
		 <4>	  6/5/94	DJ		check numMailsInBox and don't send box more than will fit in his
									inbox (kMaxNumMails)
		 <3>	  6/5/94	DJ		making everything take a ServerState instead of SessionRec and
									added Server_DebugService
		 <2>	 5/31/94	DJ		send mail to box
		 <1>	 5/25/94	DJ		first checked in
	To Do:
*/

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <malloc.h>

#include "ServerCore.h"
#include "Server.h"
#include "ServerDataBase.h"
#include "Server_Comm.h"
#include "Common_Missing.h"
#include "Common_ReadConf.h"
#include "MegaPack.h"
#include "Messages.h"
#include "Mail.h"
#include "Challnge.h"
#include "FilterHandle.h"

Mail *Server_GetVIPBMail(ServerState *state, time_t lastWhen, time_t *currentWhen);

// kMaxInBoxEntries is 10. However, it should be 8 for sjne (Japanese box).
#define vNewMaxInBoxEntries ((state->platformID == kPlatformSJNES)?8:10)
//

//
// 7/1/94 A prob with Server_SendMail is that if mail fails while sending the broadcast mail,
// the dbase has already marked it as sent (the user account keeps a timestamp of the
// last broadcast mail sent).  Oh well.  Bummer.
//
int Server_SendMail(ServerState *state)
{
short	numMails, numBroadcastMails, numTotalMails, i, numLeftOnServer, inBox;
messOut	opCode;
Mail	*mail, *vipMail = NULL;
char	msg[200];
Boolean	stickyDialog;
unsigned long lastTimeStamp;


	PLogmsg(LOGP_PROGRESS, "Server_SendMail\n");

	// Make dialog stick on screen if mail only connect.
	//
	if(state->challengeData.userID.box.box == kDownloadOnlyMailSerialNumber)
		stickyDialog = true;
	else
		stickyDialog = false;


	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);

	//
	// Update the player account with serial num of mails on the box.
	//
	for(inBox = 0; inBox < vNewMaxInBoxEntries; inBox++)
		state->account->playerAccount.mailInBox[inBox] = 0;
	for(inBox = 0; inBox < state->loginData.numMailsInBox; inBox++)
		state->account->playerAccount.mailInBox[inBox] = state->loginData.mailSerialNumbers[inBox];
       state->account->playerModified |= kPA_mailInBox;




	//
	// If this is a Kiosk box, don't send mail to it.  Rather, ensure that these messages are there.
	//
	if(state->account->boxAccount.boxFlags & kBoxFlag_KioskBox)
	{
		Mail *kmails[3], *mm;
		short numk = 0;
	        userIdentification catapult = {         // from address
                        {-1, -1}, 0, 0, kXBANDPlayerIcon, "", "XBAND Kontrol" };

		strcpy(catapult.userTown, gConfig.catapultTown);

		//
		// Compose Message #1 if its not there.
		//
		for(inBox = 0; inBox < state->loginData.numMailsInBox; inBox++)
			if(state->account->playerAccount.mailInBox[inBox] == 1234)
				break;
		if(inBox == state->loginData.numMailsInBox)
		{
			mm = (Mail *)calloc(sizeof(Mail) + 512, 1);
			ASSERT(mm);
			
			strcpy(mm->message, gettext("Welcome  to the XBAND Network.  Check us out and tell your friends.  You're done practicing.  NOW you're playing for real!"));

			mm->date = Server_GetSegaDate();
			strcpy(mm->title, gettext("Welcome"));
			mm->to.box = state->loginData.userID.box;
			mm->to.userID = state->loginData.userID.userID;
			mm->from = catapult;
			mm->serialNumber = 1234;

			kmails[numk++] = mm;
			Logmsg("Message 1234 not there\n");
		}

		// Compose Message #2 if its not there.
		//
		for(inBox = 0; inBox < state->loginData.numMailsInBox; inBox++)
			if(state->account->playerAccount.mailInBox[inBox] == 1235)
				break;
		if(inBox == state->loginData.numMailsInBox)
		{
			mm = (Mail *)calloc(sizeof(Mail) + 512, 1);
			ASSERT(mm);
			
			strcpy(mm->message, gettext("Currently NBA JAM, Mortal Kombat, Mortal Kombat II, Madden '95, and NHL '95 are supported on XBAND.  Check XBAND News for the latest list."));

			mm->date = Server_GetSegaDate();
			strcpy(mm->title, gettext("Games Supported"));
			mm->to.box = state->loginData.userID.box;
			mm->to.userID = state->loginData.userID.userID;
			mm->from = catapult;
			mm->serialNumber = 1235;

			kmails[numk++] = mm;
			Logmsg("Message 1235 not there\n");
		}

		// Compose Message #3 if its not there.
		//
		for(inBox = 0; inBox < state->loginData.numMailsInBox; inBox++)
			if(state->account->playerAccount.mailInBox[inBox] == 1236)
				break;
		if(inBox == state->loginData.numMailsInBox)
		{
			mm = (Mail *)calloc(sizeof(Mail) + 512, 1);
			ASSERT(mm);
			
			strcpy(mm->message, gettext("After playing someone, press UP, UP, DOWN at the \"Play again?\" screen.  Both players have to do it.  Try it, you'll like it."));

			mm->date = Server_GetSegaDate();
			strcpy(mm->title, gettext("Try This!"));
			mm->to.box = state->loginData.userID.box;
			mm->to.userID = state->loginData.userID.userID;
			mm->from = catapult;
			mm->serialNumber = 1236;

			kmails[numk++] = mm;
			Logmsg("Message 1236 not there\n");
		}


		if(numk > 0)
		{

			opCode = msReceiveMail;
			Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);

			Server_TWriteDataSync(state->session, sizeof(short), (Ptr)&numk);

			for(i = 0; i < numk; i++)
			{
				Logmsg("Sending Kiosk message %ld\n", kmails[i]->serialNumber);

				Server_SendMailBody(state, kmails[i]);
				if(Server_TCheckError(state->session) != noErr)
					return(kServerFuncAbort);

				free(kmails[i]);
				kmails[i] = NULL;
			}

			Server_SendDialog(state, gettext("You have new mail."), stickyDialog);
		}
		else
		{
			if(state->challengeData.userID.box.box == kDownloadOnlyMailSerialNumber)
				Server_SendDialog(state, gettext("You have no new mail."), stickyDialog);	/* DIALOG */
		}



		return(kServerFuncOK);
	}



#ifdef VIPMAIL
# define VIP_MAIL_NAME	"VipMail"
	//
	// If he's a VIP, look for a special VIP-only broadcast mail message.
	//
	if ((Server_GetSpecialPhone(state) & kSpecialVIPTester) ||
	(state->account->boxAccount.boxFlags & kBoxFlag_VIP))
	{
		vipMail = Server_GetVIPBMail(state,
			state->account->boxAccount.newsChannels[kVIPBMailChannel].lastArticleRead,
			&lastTimeStamp);

		if (vipMail != NULL) {
			Logmsg("Found a new VIP-only mail message\n");
			// "allocate" the news channel if not already done.
			//
			if (state->account->boxAccount.numNewsChannels < kVIPBMailChannel+1)
				state->account->boxAccount.numNewsChannels = kVIPBMailChannel+1;

			// Update the mod date.
			//
			state->account->boxAccount.newsChannels[kVIPBMailChannel].lastArticleRead = lastTimeStamp;
			state->account->boxModified |= kBA_newsChannels;
		}
	}
#else
# define VIP_MAIL_NAME	"BetaMail"
	//
	// If he's a Beta tester, look for a special Beta-only broadcast mail
	// message.  We sort of hijack the VIP mail thing.  Should be okay,
	// just don't expect to use both at once.
	//
	if (state->loginData.userID.box.box < 3000) {
		vipMail = Server_GetVIPBMail(state,
			state->account->boxAccount.newsChannels[kVIPBMailChannel].lastArticleRead,
			&lastTimeStamp);

		if (vipMail != NULL) {
			Logmsg("Found a new Beta-only mail message\n");
			// "allocate" the news channel if not already done.
			//
			if (state->account->boxAccount.numNewsChannels < kVIPBMailChannel+1)
				state->account->boxAccount.numNewsChannels = kVIPBMailChannel+1;

			// Update the mod date.
			//
			state->account->boxAccount.newsChannels[kVIPBMailChannel].lastArticleRead = lastTimeStamp;
			state->account->boxModified |= kBA_newsChannels;
		}
	}
#endif


	// check if there is generic mail to send to everyone.
	//
	numBroadcastMails = DataBase_GetNumBroadcastMail(state->account->boxAccount.newsChannels[kBroadcastMailChannel].lastArticleRead);
	//
	// adjust numMails so that there are never more than vNewMaxInBoxEntries mails in box's inbox.
	//
	// NOTE 941207: we throw away the result below 10 lines later.  Hmm.
	//
	numLeftOnServer = 0;
	i = state->loginData.numMailsInBox + numBroadcastMails + (vipMail != NULL);
	if(i > vNewMaxInBoxEntries)
	{
		i -= vNewMaxInBoxEntries;
		numBroadcastMails -= i;
		numLeftOnServer += i;
	}
	
	// check if there is mail in this user's input queue.
	//
	numMails = WrapperDB_GetNumIncomingMail(&state->loginData.userID);
	//
	// adjust numMails so that there are never more than vNewMaxInBoxEntries mails in box's inbox.
	//
	i = state->loginData.numMailsInBox + numBroadcastMails + numMails + (vipMail != NULL);
	if(i > vNewMaxInBoxEntries)
	{
		i -= vNewMaxInBoxEntries;
		numMails -= i;
		numLeftOnServer += i;
	}
	
	numTotalMails = numMails + numBroadcastMails + (vipMail != NULL);
	if(numTotalMails > 0)
	{
		Server_SetTransportHold(state->session, true);

		opCode = msReceiveMail;
		Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);

		Server_TWriteDataSync(state->session, sizeof(short), (Ptr)&numTotalMails);

		for(i = 0; i < numBroadcastMails; i++)
		{
			if(state->account->boxAccount.numNewsChannels < kBroadcastMailChannel+1)
				lastTimeStamp = 0;
			else
				lastTimeStamp = state->account->boxAccount.newsChannels[kBroadcastMailChannel].lastArticleRead;
			mail = DataBase_GetBroadcastMail(&lastTimeStamp, i);
			
			Server_SendMailBody(state, mail);
			if(Server_TCheckError(state->session) != noErr)
				return(kServerFuncAbort);

			// add a record of it into the playerAccount.
			// Do we need some kind of differentiator for broadcast mail serial numbers?
			state->account->playerAccount.mailInBox[inBox++] = mail->serialNumber;
			state->account->playerModified |= kPA_mailInBox;
		}
		//
		// Update the appropriate news channel to show that we've read this bcast mail.  We must
		// do it this way in case several bcast mails have the same date.  Don't want to update the
		// lastArticleRead until sent all the articles (because this is really just the date of the
		// last article sent to the box.
		//
		if(numBroadcastMails)
		{
			// Note: ** POSSIBLE BUG.  Nobody is allocating the newsChannels array.  In fact,
			// it is statically declared in ServerDataBase.h to be [4].  As long as we
			// only ever have 4 news channels, it'll work.... DANGER TO NEWS AND BCAST MAIL!  dj 11/3/94
			//
			// Note #2: we used the news channel up above... it's a bit late
			// to be allocating it here.  ++ATM 941207
			//
			if(state->account->boxAccount.numNewsChannels < kBroadcastMailChannel+1)
				state->account->boxAccount.numNewsChannels = kBroadcastMailChannel+1;
			state->account->boxAccount.newsChannels[kBroadcastMailChannel].lastArticleRead = lastTimeStamp;
			state->account->boxModified |= kBA_newsChannels;
		}

		if (vipMail != NULL) {
			Server_SendMailBody(state, vipMail);
			if (Server_TCheckError(state->session) != noErr)
				return (kServerFuncAbort);
		}

		for(i = 0; i < numMails; i++)
		{
			mail = WrapperDB_GetIncomingMail(&state->loginData.userID, i);

			if(state->account->boxAccount.boxFlags & kBoxFlag_FilterMail)
			{
				if(FilterTextObscene(mail->message))
					Logmsg("Mail to this box has been filtered for Profanity.\n");
				if(FilterTextObscene(mail->title))
					Logmsg("Mail to this box has been filtered for profanity.\n");
			}

			Server_SendMailBody(state, mail);
			if(Server_TCheckError(state->session) != noErr)
				return(kServerFuncAbort);

			// add a record of it into the playerAccount.
			state->account->playerAccount.mailInBox[inBox++] = mail->serialNumber;
			state->account->playerModified |= kPA_mailInBox;

			WrapperDB_MarkMailAsSent(&state->loginData.userID, i);
		}

		if(numLeftOnServer)
		{
			if (numTotalMails == 1)
				strcpy(msg, gettext("One new mail message has been added to your mailbox."));	/* DIALOG */
			else
				sprintf(msg, gettext("%ld new mail messages have been added to your mailbox."),	/* DIALOG */
					(long)numTotalMails);

			if (numLeftOnServer == 1)
				strcat(msg, gettext("You have one more message, but your mailbox is full.  Please delete some messages."));	/* DIALOG */
			else
				sprintf(msg+strlen(msg), gettext("You have %ld more messages, but your mailbox is full.  Please delete some messages."),	/* DIALOG */
				(long)numLeftOnServer);
			Server_SendLargeDialog(state, msg, stickyDialog);
		}
		else
		{
			if (numTotalMails == 1)
				strcpy(msg, gettext("One new mail message has been added to your mailbox."));	/* DIALOG */
			else
				sprintf(msg, gettext("%ld new mail messages have been added to your mailbox."),	/* DIALOG */
					(long)numTotalMails);
			Server_SendDialog(state, msg, stickyDialog);
		}
		
		Server_SetTransportHold(state->session, false);

	} else
	{
		if(numLeftOnServer)
		{
			if (numLeftOnServer == 1)
				strcat(msg, gettext("You have one more message, but your mailbox is full.  Please delete some messages."));	/* DIALOG */
			else
				sprintf(msg, gettext("You have %ld more messages, but your mailbox is full.  Please delete some messages."),	/* DIALOG */
				(long)numLeftOnServer);
			Server_SendLargeDialog(state, msg, stickyDialog);
		}
		else
		{
			if(state->challengeData.userID.box.box == kDownloadOnlyMailSerialNumber)
				Server_SendDialog(state, gettext("You have no new mail."), stickyDialog);	/* DIALOG */
		}
	}
	
	// CAREFUL: make sure we don't actually nuke the mail until after the
	// connection has completed successfully.
	//
	WrapperDB_RemoveSentMail(&state->loginData.userID);

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	return(kServerFuncOK);
}

// The reason to undef it - it is defined as "state->platform ..."
//
#undef vNewMaxInBoxEntries


// Give me 30 seconds to install the files and allow for clock skew.
//
#define VIP_TIME_DRIFT	30

//
// Retrieve the VIP mail message if it exists and is newer than lastWhen.
// Stuffs the timestamp of the message into currentWhen.
//
// If the message isn't found, is hosed, or is too old, NULL is returned.
// Otherwise, a pointer to a static mail message is returned.
//
// In case it isn't obvious, this is a quick hack, and should be replaced
// with a full "targeted broadcast mail" thing.
//
Mail *
Server_GetVIPBMail(ServerState *state, time_t lastWhen, time_t *currentWhen)
{
	userIdentification catapult = {{-1, -1}, 0, 0, kXBANDPlayerIcon, "", "vip@catapent.com"};
	static union {
		Mail m;
		char oversized[sizeof(Mail) + 512];
	} fakem;
	FILE *fp;
	struct stat sb;
	char linebuf[512];
	int ste;

	strcpy(catapult.userTown, gConfig.catapultTown);

	PLogmsg(LOGP_PROGRESS, "Server_GetVIPBMail\n");
	*currentWhen = 0;

	// See if it exists and is new.  Observe a two-second delay in case
	// we catch it right as they're writing to the file.  Shouldn't matter
	// since the file is so small, but it doesn't hurt to look.
	//
	if ((fp = fopen(VIP_MAIL_NAME, "r")) == NULL)
		return (NULL);
	if (fstat(fileno(fp), &sb) < 0) {
		PLogmsg(LOGP_FLAW, "fstat on Vip/BetaMail failed, errno=%d\n", errno);
		return (NULL);
	}
	if (sb.st_mtime < lastWhen + 2) {
		fclose(fp);
		return (NULL);
	}
	*currentWhen = sb.st_mtime + VIP_TIME_DRIFT;

	fakem.m.from = catapult;
	fakem.m.date = Server_GetSegaDate();

	// Read it in.
	//
	ste = 0;
	while (1) {
        fgets(linebuf, 512, fp);
        if (feof(fp) || ferror(fp)) break;

        if (linebuf[strlen(linebuf)-1] == '\n')
            linebuf[strlen(linebuf)-1] = '\0';
        if (linebuf[0] == '\0' || linebuf[0] == '#') continue;

		switch (ste) {
		case 0:
			strncpy(fakem.m.title, linebuf, kTitleSize-1);
			fakem.m.title[kTitleSize-1] = '\0';
			break;
		case 1:
			strncpy(fakem.m.message, linebuf, 511);
			fakem.m.message[511] = '\0';
			break;
		default:
			PLogmsg(LOGP_FLAW, "Bogus state in GetVIPBMail\n");
			fclose(fp);
			return (NULL);
		}

		if (++ste >= 2)
			break;
	}
	fclose(fp);
	if (ste != 2) {
		PLogmsg(LOGP_NOTICE, "Vip/BetaMail file incomplete, ignoring\n");
		return (NULL);
	}
	Logmsg("Found recent Vip/BetaMail:\n");
	Logmsg("  Subject: '%s'\n", fakem.m.title);
	Logmsg("  Message: '%s'\n", fakem.m.message);

	return(&fakem.m);
}


int Server_SendMailBody(ServerState *state, Mail *mail)
{
short			mailSize;
unsigned char	length;

	PLogmsg(LOGP_PROGRESS, "Server_SendMailBody\n");

	mailSize = (short)DataBaseUtil_SizeofMail(mail);

	Server_TWriteDataSync(state->session, sizeof(short), (Ptr)&mailSize);

	Server_SendUserIdentification(state, &mail->from);

	// don't have to send the 'to' userIdentification
	
	Server_TWriteDataSync(state->session, sizeof(short), (Ptr)&mail->serialNumber);
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&mail->date);

	length = strlen(mail->title) + 1;
	Server_TWriteDataSync(state->session, sizeof(unsigned char), (Ptr)&length);
	Server_TWriteDataSync(state->session, (long)length, (Ptr)&mail->title);

	PLogmsg(LOGP_DETAIL, "Sending mail to box, msg='%s'\n", mail->message);

	return (Server_SendOptCompressedString(state, mail->message));
}


static int Server_segb_SendUserIdentification(ServerState *state, userIdentification *userID);
static int Server_any_SendUserIdentification(ServerState *state, userIdentification *userID);

int Server_SendUserIdentification(ServerState *state, userIdentification *userID)
{
	SubDispatcher subdisp[] = {
		{ kBoxType_segb,	0xffffffff,	Server_segb_SendUserIdentification },
		{ kBoxType_Any,		0,			Server_any_SendUserIdentification },
		{ 0,				0,			NULL },		// the bug stops here
	};

	// 'segb' ROMs need the older userIdentification function; all others
	// use the newer one (which includes hue shift values for the icon).
	//
	return ( (Common_SubDispatch(state->boxOSState.boxType, subdisp))(state, userID) );
}

static int
Server_segb_SendUserIdentification(ServerState *state, userIdentification *userID)
{
	unsigned char length;

	Server_TWriteDataSync(state->session, sizeof(BoxSerialNumber), (Ptr)&userID->box);
	Server_TWriteDataSync(state->session, sizeof(unsigned char), (Ptr)&userID->userID);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&userID->ROMIconID);

	length = strlen(userID->userTown) + 1;
	Server_TWriteDataSync(state->session, sizeof(unsigned char), (Ptr)&length);
	Server_TWriteDataSync(state->session, (long)length, (Ptr)userID->userTown);

	length = strlen(userID->userName) + 1;
	Server_TWriteDataSync(state->session, sizeof(unsigned char), (Ptr)&length);
	Server_TWriteDataSync(state->session, (long)length, (Ptr)userID->userName);

	return(kServerFuncOK);
}

//
// Difference between this and the segb routine is the addition of the
// colorTableID byte.
//
static int
Server_any_SendUserIdentification(ServerState *state, userIdentification *userID)
{
	unsigned char length;

	Server_TWriteDataSync(state->session, sizeof(BoxSerialNumber), (Ptr)&userID->box);
	Server_TWriteDataSync(state->session, sizeof(unsigned char), (Ptr)&userID->userID);
	Server_TWriteDataSync(state->session, sizeof(unsigned char), (Ptr)&userID->colorTableID);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&userID->ROMIconID);

	length = strlen(userID->userTown) + 1;
	Server_TWriteDataSync(state->session, sizeof(unsigned char), (Ptr)&length);
	Server_TWriteDataSync(state->session, (long)length, (Ptr)userID->userTown);

	length = strlen(userID->userName) + 1;
	Server_TWriteDataSync(state->session, sizeof(unsigned char), (Ptr)&length);
	Server_TWriteDataSync(state->session, (long)length, (Ptr)userID->userName);

	return(kServerFuncOK);
}

