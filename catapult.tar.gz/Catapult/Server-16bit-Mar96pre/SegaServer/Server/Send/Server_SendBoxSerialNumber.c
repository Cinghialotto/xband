/*
 *
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_SendBoxSerialNumber.c,v 1.3 1996/01/25 17:54:36 hufft Exp $
 *
 * $Log: Server_SendBoxSerialNumber.c,v $
 * Revision 1.3  1996/01/25  17:54:36  hufft
 * added UDP based connections
 *
 * Revision 1.2  1995/05/27  00:58:06  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_SendBoxSerialNumber.c

	Contains:	xxx put contents here xxx

	Written by:	David Jevans


	Change History (most recent first):

		<11>	10/21/94	ATM		Print the previous serial numbers too.
		<10>	10/21/94	ATM		Print box serial numbers and home town when we set them.
		 <9>	 9/19/94	ATM		PLogmsg stuff.
		 <8>	 8/12/94	ATM		Converted to Logmsg.
		 <7>	 7/20/94	DJ		added Server_Comm stuff
		 <6>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		 <5>	 7/12/94	DJ		sending new boxserialnumber format
		 <4>	  7/1/94	DJ		making server handle errors from the comm layer
		 <3>	  6/9/94	BET		Fix hairy compiles based on TransportSlayer.h
		 <2>	  6/5/94	DJ		making everything take a ServerState instead of SessionRec and
									added Server_DebugService
		 <1>	 5/31/94	DJ		first checked in

	To Do:
*/


#include "ServerCore.h"
#include "Server.h"
#include "ServerState.h"
#include "Messages.h"
#include "Server_Comm.h"
#include <stdio.h>


//
// sends a new serial number to the box.  this is used only once when the box initially registers
// with Catapult.  We could add all sorts of wiggy hardcore security by disabling the
// handler for this message.  We could only run it if we downloaded it first.  Very nice!
//
int Server_SendNewBoxSerialNumber(ServerState *state, BoxSerialNumber *boxSerialNumber)
{
messOut	opCode;

	PLogmsg(LOGP_PROGRESS, "Server_SendNewBoxSerialNumber\n");
	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);

	opCode = msSetBoxSerialNumber;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(BoxSerialNumber), (Ptr)boxSerialNumber);

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	Logmsg("SET box serial number to (%ld,%ld) (currently (%ld,%ld))\n",
		boxSerialNumber->box, boxSerialNumber->region,
		state->loginData.userID.box.box, state->loginData.userID.box.region);
	PLogmsg(LOGP_PROGRESS, "Server_SendNewBoxSerialNumber done\n");

	return(kServerFuncOK);
}

int Server_SendNewBoxHometown(ServerState *state, Hometown town)
{
messOut	opCode;

	PLogmsg(LOGP_PROGRESS, "Server_SendNewBoxHometown\n");
	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);

	opCode = msSetBoxHometown;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(Hometown), (Ptr)town);

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	Logmsg("SET box hometown to (%s)\n", town);
	PLogmsg(LOGP_PROGRESS, "Server_SendNewBoxHometown done\n");

	return(kServerFuncOK);
}

int Server_SendNewCurrentUserName(ServerState *state, UserName name)
{
messOut	opCode;

	PLogmsg(LOGP_PROGRESS, "Server_SendNewCurrentUserName\n");
	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);

	opCode = msSetCurrentUserName;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(UserName), (Ptr)name);

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_SendNewCurrentUserName done\n");

	return(kServerFuncOK);
}


