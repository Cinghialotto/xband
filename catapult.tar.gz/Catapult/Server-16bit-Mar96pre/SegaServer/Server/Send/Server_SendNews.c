/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_SendNews.c,v 1.6 1996/01/25 17:54:41 hufft Exp $
 *
 * $Log: Server_SendNews.c,v $
 * Revision 1.6  1996/01/25  17:54:41  hufft
 * added UDP based connections
 *
 * Revision 1.5  1995/10/26  03:51:09  jhsia
 * Added gDebugNewsPlain and gDebugNewsEnc to measure compression performance.
 *
 * Revision 1.4  1995/09/13  14:18:40  ted
 * Fixed warnings.
 *
 * Revision 1.3  1995/06/26  16:06:28  sriram
 * Integration of SNES news - round 1.
 *
 * Revision 1.2  1995/05/27  00:58:13  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_SendNews.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		<12>	 9/19/94	ATM		PLogmsg stuff.
		<11>	 8/12/94	ATM		Converted to Logmsg.
		<10>	 7/20/94	DJ		added Server_Comm stuff
		 <9>	 7/18/94	DJ		doesn't resend dailynews
		 <8>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		 <7>	 7/12/94	DJ		using Server_TCheckError instead of TCheckError
		 <6>	  7/1/94	DJ		making server handle errors from the comm layer
		 <5>	 6/30/94	DJ		new news
		 <4>	 6/28/94	DJ		added newsfalgs byte
		 <3>	  6/9/94	BET		Fix hairy compiles based on TransportSlayer.h
		 <2>	  6/5/94	DJ		making everything take a ServerState instead of SessionRec and
									added Server_DebugService
		 <1>	  6/2/94	DJ		first checked in

	To Do:
*/

#include <sys/types.h>
#include <malloc.h>
#include <memory.h>

#include "ServerCore.h"
#include "Server.h"
#include "ServerDataBase.h"
#include "Server_Comm.h"
#include "Common_Missing.h"

#include "Messages.h"
#include "News.h"
// SNES News stuff in in NewsFile.h
#include "NewsFile.h"	
#include "MegaPack.h"

#include <stdio.h>

int Server_snes_SendNewsPage(ServerState*, DBType, SnesPageData*, int, int *);

extern long gDebugNewsPlain, gDebugNewsEnc;

//
// Tells the box to empty out its daily news and then sends the 
// first page of the new news.
//
int Server_SendFirstNewsPage(ServerState *state, ServerNewsPage *page)
{
messOut			opCode;
unsigned char 	newsFlags;
Err				err;

	PLogmsg(LOGP_PROGRESS, "Server_SendFirstNewsPage\n");
	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);

	ASSERT(state);
	ASSERT(page);
	if(!page)
		return(kServerFuncOK);

	opCode = msNewsHeader;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr)&page->type);

	newsFlags = kNewDaysNewsFlag;
	Server_TWriteDataSync(state->session, sizeof(char), (Ptr)&newsFlags);

	if((err = Server_TCheckError(state->session)) != noErr)
	{
		PLogmsg(LOGP_NOTICE, "Server_TCheckError == %ld\n", err);
		return(kServerFuncAbort);
	}

	return(Server_SendNewsPage(state, page));
}

int Server_SendNoNewsPage(ServerState *state, DBType pagetype)
{
    	messOut		opCode;
    	unsigned char	newsFlags;
    	Err		err;

	PLogmsg(LOGP_PROGRESS, "Server_SendNoNewsPage\n");
	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);

	ASSERT(state);

	opCode = msNewsHeader;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr)&pagetype);

	newsFlags = 0;	// no new news
	Server_TWriteDataSync(state->session, sizeof(char), (Ptr)&newsFlags);

	if((err = Server_TCheckError(state->session)) != noErr)
	{
		PLogmsg(LOGP_NOTICE, "Server_TCheckError == %ld\n", err);
		return(kServerFuncAbort);
	}

	return(kServerFuncOK);
}

int Server_SendNewsPage(ServerState *state, ServerNewsPage *page)
{
messOut	opCode;
Err		err;

	PLogmsg(LOGP_PROGRESS, "Server_SendNewsPage\n");
	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);

	ASSERT(state);
	ASSERT(page);
	if(!page)
		return(kServerFuncOK);

	opCode = msNewsPage;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr)&page->type);
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&page->length);
	Server_TWriteDataSync(state->session, page->length, (Ptr)page->page);

	if((err = Server_TCheckError(state->session)) != noErr)
	{
		PLogmsg(LOGP_NOTICE, "Server_TCheckError == %ld\n", err);
		return(kServerFuncAbort);
	}

	return(kServerFuncOK);
}


int
Server_snes_SendNewsPage(
    ServerState		*state,
    DBType		dbType,		// bandwidth or xband news
    SnesPageData	*page,
    int			pageNum,
    int			*numPageBytes	// number of bytes of data sent to box
)
{
    static u_char	*buf = NULL;
    static int		bufSize = 0;

    messOut		opCode;
    unsigned char	newsFlags;
    Err			err;
    u_char		*pageData;
    long		newSize;	// post-compression size


    PLogmsg(LOGP_PROGRESS, "Server_snes_SendNewsPage\n");

    if(Server_DebugService(state) != kServerFuncOK)
	return(kServerFuncAbort);

    ASSERT(state);
    ASSERT(page);
    if (!page)
	return(kServerFuncOK);

    if (pageNum == 0) {
	// This is the first page; clear the existing news document 
	// since we are downloading a news document to the box.

        opCode = msNewsHeader;
        Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
        Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr)&dbType);

        newsFlags = kNewDaysNewsFlag;
        Server_TWriteDataSync(state->session, sizeof(char), (Ptr)&newsFlags);

        if((err = Server_TCheckError(state->session)) != noErr) {
	    PLogmsg(LOGP_NOTICE, "Server_TCheckError == %ld\n", err);
	    return(kServerFuncAbort);
        }
    }

    *numPageBytes = 0;

    opCode = msNewsPage;
    Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
    Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr)&dbType);

    Server_TWriteDataSync(state->session, sizeof(long), 
	(Ptr)&page->pageInfoLength);
    Server_TWriteDataSync(state->session, page->pageInfoLength,
	(Ptr)page->buf + page->headerLength);
    (*numPageBytes) += page->pageInfoLength;

    // The compression options are guaranteed to not generate
    // data that exceed 2X the size of the buffer passed in.
    // Six bytes at the front of the buffer are used to store
    // compression info.
    if (bufSize < (2 * page->pageDataLength + 6)) {
	if (buf != NULL)
	    free(buf);

	bufSize = 2 * page->pageDataLength + 6;
	buf = (u_char *)malloc(bufSize);
	ASSERT(buf);
    }

    //
    // Fadden sez' the following is worth a try but CPU intensive.
    // Skipping it, until compression really becomes an issue. SR 6/8/95.
    //
    //    newSize = Compress(pageData, buf, page->pageDataLength, 
    //			kMPtryNone|kMPtryLzb|kMPincludeCRC|kMPuseRLE
    //			|kMPuseStaticDict|kMPuseAdaptiveDict|kMPuseBothDict
    //			|kMPvaryAdaptiveBitl);
    //

    pageData = (u_char *)(page->buf + page->headerLength + page->pageInfoLength);
    newSize  = Compress(pageData, buf, page->pageDataLength, kMPmodeNews);
    if (newSize == -1) {
        // If compression fails, send uncompressed data to the box.
	// clear the first six bytes and insert the length of the data
	// in the middle (in big-endian order).
	// (could also call Compress with kMPtryNone and let it do the work)

	memset(buf, 0, 6);
	buf[2] = (page->pageDataLength >> 8) & 0xff;
	buf[3] = page->pageDataLength & 0xff;

	memcpy(buf+6, pageData, page->pageDataLength);
	newSize = page->pageDataLength + 6;

 	PLogmsg(LOGP_NOTICE, 
	    "Server_snes_SendNewsPage: Compression failed - sending raw data\n");
    } else {
        PLogmsg(LOGP_PROGRESS, 
	    "Server_snes_SendNewsPage: Compression [old %d] [new %d]\n", 
	    page->pageDataLength, newSize);
    }

    gDebugNewsPlain += page->pageDataLength;
    gDebugNewsEnc += newSize;

    Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&newSize);
    Server_TWriteDataSync(state->session, newSize, (Ptr)buf);
    (*numPageBytes) += newSize;

    if((err = Server_TCheckError(state->session)) != noErr) {
	PLogmsg(LOGP_NOTICE, "Server_TCheckError == %ld\n", err);
	return(kServerFuncAbort);
    }

    return(kServerFuncOK);
}

