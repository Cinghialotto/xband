/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_SendOpponent.c,v 1.27 1996/01/25 17:54:42 hufft Exp $
 *
 * $Log: Server_SendOpponent.c,v $
 * Revision 1.27  1996/01/25  17:54:42  hufft
 * added UDP based connections
 *
 * Revision 1.26  1995/11/08  18:58:24  jhsia
 * Added PhoneXlate calls (fadden)
 *
 * Revision 1.25  1995/10/30  17:57:09  jhsia
 * Change the font used to display "10 points" in the versus screen to
 * use font #9 on "sjne" (fadden)
 *
 * Revision 1.24  1995/10/16  14:34:32  sriram
 * Added tourney bit to regurg info.
 *
 * Revision 1.23  1995/09/20  14:29:05  ansell
 * Added gettext() around a couple messages.
 *
 * Revision 1.22  1995/09/13  14:18:41  ted
 * Fixed warnings.
 *
 * Revision 1.21  1995/09/05  17:24:35  ansell
 * If the player is XBN callable he will be told that the incomming call may
 * come in via XBAND Nationwide.
 *
 * Revision 1.20  1995/08/16  18:08:14  fadden
 * Set regurg.flags.
 *
 * Revision 1.19  1995/07/24  17:00:01  rich
 * Changed Server_SendGameOverString() to use gettext() messages.
 *
 * Revision 1.18  1995/07/12  17:33:34  ansell
 * Renamed matchupRegurg to newMatchupRegurg.
 *
 * Revision 1.17  1995/07/10  21:20:30  rich
 * Added Japanese SNES platform (kPlatformSJNES).
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.16  1995/07/07  20:55:45  fadden
 * Added SetTransportHold calls to four routines.
 *
 * Revision 1.15  1995/06/19  20:54:56  fadden
 * Added Server_SendRankingEnable and Server_SendRankingDisable, and a note
 * about their use.
 *
 * Revision 1.14  1995/06/01  22:33:41  fadden
 * Move regurg construction into Server_BuildRegurg().
 *
 * Revision 1.13  1995/06/01  16:34:39  fadden
 * Set regurg.gamePatchVer to state->gameIDData.version.
 *
 * Revision 1.12  1995/06/01  16:19:14  fadden
 * On the SNES, set kUpdateRankingsConst to an appropriate value.
 *
 * Revision 1.11  1995/05/27  00:58:14  jhsia
 * switch to rcs keywords
 *
 */


/*
	File:		Server_SendOpponent.c

	Contains:	Server send opponent functions

	Written by:	Dave Jevans


	Change History (most recent first):

		<31>	11/17/94	ATM		Change roundoff from 3599 to 1800.
		<30>	11/12/94	DJ		Changed the "Having fun yet" dialog.
		<29>	11/10/94	ATM		Send master's worth string to kOppGameValueString.
		<28>	 11/9/94	HEC		Round up timeout value when displaying minutes to wait dialog.
		<27>	 11/9/94	ATM		Reorganized things a bit to support changes to the way Worth
									strings are sent.
		<26>	10/20/94	DJ		Added dialog (in caps) comment on same         line as server
									dialogs.  Very useful for         greping.
		<25>	 10/6/94	ATM		Made "10 minutes" dialog show the actual time.
		<24>	 10/2/94	ATM		Changed "hear" to "y'hear" in end-of-game string.  Moved calls
									to SendWorthString to StartGamePlay.
		<23>	 9/19/94	ATM		PLogmsg stuff.
		<22>	 9/16/94	ATM		Make the thank-you strings slightly less silly.
		<21>	  9/2/94	DJ		changed a dialog
		<20>	 8/29/94	ATM		Send a variety of thank-you strings.
		<19>	 8/22/94	DJ		groomed dialog text
		<18>	 8/22/94	DJ		random worth strings
		<17>	 8/22/94	DJ		got burned by Octal when setting the first char of the worth
									strings to 0x3.
		<16>	 8/21/94	DJ		fontid is 3 for worthstrings
		<15>	 8/20/94	BET		Add Server_SendOpponentNameString
		<14>	 8/19/94	DJ		added Server_SendWorthString
		<13>	 8/17/94	DJ		moved routines between files
		<12>	 8/12/94	ATM		Converted to Logmsg.
		<11>	 7/20/94	DJ		added Server_Comm stuff
		<10>	 7/18/94	DJ		magicCookie (ie. opponentVerificationTag)
		 <9>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		 <8>	 7/12/94	DJ		using Server_TCheckError instead of TCheckError
		 <7>	  7/8/94	DJ		send sizeof(phoneNumber)
		 <6>	  7/1/94	DJ		making server handle errors from the comm layer
		 <5>	  6/9/94	BET		Fix hairy compiles based on TransportSlayer.h
		 <4>	  6/5/94	DJ		making everything take a ServerState instead of SessionRec and
									added Server_DebugService
		 <3>	 5/29/94	DJ		sync writing instead of async
		 <2>	 5/27/94	DJ		made it send messages to box
		 <1>	 5/25/94	DJ		first checked in
	To Do:
*/

#include <stdio.h>
#include <memory.h>
#include <sys/types.h>
#include <sys/time.h>

#include "ServerCore.h"
#include "Server.h"
#include "Server_Comm.h"
#include "DataBase_Match.h"

#include "Common.h"
#include "Common_Missing.h"

#include "Messages.h"
#include "StringDB.h"
#include "DBTypes.h"
#include "DBConstants.h"


//
// Local prototypes.
//
PRIVATE Err Server_BuildRegurg(ServerState *state, int master, long when, long magicCookie, long randomVal);
//
PRIVATE int Server_snes_SendRankingEnable(ServerState *state);
PRIVATE int Server_no_SendRankingEnable(ServerState *state);
PRIVATE int Server_snes_SendRankingDisable(ServerState *state);
PRIVATE int Server_no_SendRankingDisable(ServerState *state);
//
PRIVATE int Server_sega_SendWaitForOpponent(ServerState *state, long magicCookie, long randomVal);
PRIVATE int Server_snes_SendWaitForOpponent(ServerState *state, long magicCookie, long randomVal);
PRIVATE int Server_sega_SendOpponentPhoneNumber(ServerState *state, const phoneNumber *opponentPhoneNumber, long magicCookie, long randomVal);
PRIVATE int Server_snes_SendOpponentPhoneNumber(ServerState *state, const phoneNumber *opponentPhoneNumber, long magicCookie, long randomVal);
PRIVATE int Server_sega_SendLongOpponentPhoneNumber(ServerState *state, const char *opponentPhoneNumber, long magicCookie, long randomVal);
PRIVATE int Server_snes_SendLongOpponentPhoneNumber(ServerState *state, const char *opponentPhoneNumber, long magicCookie, long randomVal);



// ===========================================================================
//		Useful routines (versus-related stuff)
// ===========================================================================

//
// This gets called for either master or slave connects.  Someday soon it
// will only be called by the master.
//
// This sends the "worth" string, which is how many points a victory is
// worth to the master and the slave.  Originally each side got one string
// and exchanged them; now the master gets both, keeps its own, and sends
// one to the slave (the one the slave sends to it is ignored).
//
// "slaveString" is eventually sent by the master to the slave (or, for now,
// from a slave to the master).  masterString is what gets displayed on the
// master's box.  It may be NULL when sending stuff to a slave.
//
#define kWorthBufSize 48

Err Server_SendWorthString(ServerState *state, char *slaveString, char *masterString)
{
	char	*worth, worthBuf[kWorthBufSize];
	char	font;

	PLogmsg(LOGP_PROGRESS, "Server_SendWorthString\n");
	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);

	if (strlen(slaveString) > kWorthBufSize ||
		(masterString != NULL && strlen(masterString) > kWorthBufSize))
	{
		PLogmsg(LOGP_FLAW, "Worth string too long!  '%s' '%s'\n",
			slaveString, (masterString != NULL) ? masterString : gettext("(none)"));
		return (kServerFuncAbort);
	}

	if (state->platformID == kPlatformSJNES)
		font = 9;		// font #9 (skinny)
	else
		font = 3;		// font #3

	worthBuf[0] = font;
	strcpy(worthBuf+1, slaveString);
	Server_SendWritableString(state, worthBuf, kLocalGameValueString);
	// strip linefeeds to make the log prettier
	for (worth = worthBuf; *worth; worth++)
		if (*worth == '\n')
			*worth = '|';
	Logmsg("Sent '%s' as slave worth string.\n", worthBuf+1);

	if (masterString != NULL) {
		worthBuf[0] = font;		// font #3
		strcpy(worthBuf+1, masterString);
		Server_SendWritableString(state, worthBuf, kOppGameValueString);
		// strip linefeeds to make the log prettier
		for (worth = worthBuf; *worth; worth++)
			if (*worth == '\n')
				*worth = '|';
		Logmsg("Sent '%s' as master worth string.\n", worthBuf+1);
	}

	PLogmsg(LOGP_PROGRESS, "Server_SendWorthString done\n");
	return (kNoError);
}

//
// Replace a writeable string.
//
Err Server_SendWritableString(ServerState *state, char *string, DBID theID)
{
	unsigned char 	opCode;
	long			length;

	PLogmsg(LOGP_DBUG, "SendWritableString (%d) '%s'\n", theID, string);

	opCode = msReceiveWriteableString;
	length = strlen( string ) + 1;
	Server_SetTransportHold(state->session, true);
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length);
	Server_TWriteDataSync(state->session, length, (Ptr) string);
	Server_SetTransportHold(state->session, false);

	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	return (kNoError);
}


//
// Send the "Y'all come back now, y'hear?" string.
//
int Server_SendGameOverString(ServerState *state)
{
char			*endstr;
char			*endstrings[30];
int				stringcount = 0;

	PLogmsg(LOGP_PROGRESS, "Server_SendWorthString\n");
	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);

	endstrings[stringcount++] = gettext("Thank you for playing XBAND!");
//	endstrings[stringcount++] = gettext("Happy Holidays from XBAND!");
//	endstrings[stringcount++] = gettext("Y'all come back now, ya' hear!");
//	endstrings[stringcount++] = gettext("Having fun yet?  Play another round!");
	endstrings[stringcount++] = gettext("Play XBAND and test your might against the best players in the country!");

	endstr = endstrings[random() % stringcount];
	Logmsg("Sending end game string '%s'\n", endstr);

	return (Server_SendWritableString(state, endstr, kThankYouStringID));
}


int Server_SendOpponentNameString(ServerState *state, char *opponentName)
{
unsigned char 	opCode;
long			length;
DBID			theID;

	PLogmsg(LOGP_PROGRESS, "Server_SendOpponentNameString\n");
	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);


	opCode = msReceiveWriteableString;
	theID = kOpponentName;
	length = strlen( opponentName ) + 1;
	Logmsg("Server_SendOpponentNameString: name is %s\n", opponentName);

	Server_SetTransportHold(state->session, true);
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length);
	Server_TWriteDataSync(state->session, length, (Ptr) opponentName);
	Server_SetTransportHold(state->session, false);

	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_SendOpponentNameString done\n");

	return(kServerFuncOK);
}



// ===========================================================================
//		Mustard in milk
// ===========================================================================

//
// Construct a regurg, and point state->newMatchupRegurg at it.  Uses a static
// local regurg struct.
//
PRIVATE Err
Server_BuildRegurg(ServerState *state, int master, long when, long magicCookie,
	long randomVal)
{
	static MatchupRegurg regurg;		// should move entirely into state

	PLogmsg(LOGP_PROGRESS, "Server_BuildRegurg\n");

	memset(&regurg, 0, sizeof(regurg));
	regurg.version = kMatchupRegurgVersion;
	regurg.flags = regurg.pad = 0;
	regurg.gamePatchVer = state->gameIDData.version;
	regurg.gameID = state->gameIDData.gameID;

	regurg.master = master;
	regurg.when = when;
	regurg.magicCookie = magicCookie;
	regurg.randomVal = randomVal;

	if (state->matchup != NULL && state->matchup->mci)
		regurg.flags |= kRegurgFlagUsedXBN;

	//
	// TourneyStuff:
	// Mark this match as a tourney match so that we can recognize 
	// game results from this match as being "special" when they 
	// are uploaded later.
	if (state->tourneyData)
		regurg.flags |= kRegurgFlagUsedTourney;


	state->newMatchupRegurg = &regurg;

	return (kNoError);
}


//
// Send regurgitation material.  Right now it's just the matchup regurg stuff.
//
// This needs to come after the box's SendQ is cleared.
//
// Right now it pulls things out of state->newMatchupRegurg, because I wanted
// to be able to put random collections of things in here.  Right now this
// only gets called if the guy tries to play a game (brain damage).
//
int
Server_SendRegurg(ServerState *state)
{
	unsigned char	opCode;
	DBType			theType;
	DBID			theID;
	long			length;

	PLogmsg(LOGP_PROGRESS, "Server_SendRegurg\n");
	if (Server_DebugService(state) != kServerFuncOK)
		return (kServerFuncAbort);

	if (state->newMatchupRegurg != NULL) {
		Logmsg("SendRegurg: sending MatchupRegurg\n");

		opCode = msAddItemToDB;
		theType = kSendQType;
		theID = kMatchupRegurgQElement;
		length = sizeof(MatchupRegurg);

		Server_SetTransportHold(state->session, true);
		Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr)&opCode);
		Server_TWriteDataSync(state->session, sizeof(theType), (Ptr)&theType);
		Server_TWriteDataSync(state->session, sizeof(theID), (Ptr)&theID);
		Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&length);
		Server_TWriteDataSync(state->session, sizeof(MatchupRegurg),
			(Ptr)state->newMatchupRegurg);
		Server_SetTransportHold(state->session, false);

		if (Server_TCheckError(state->session) != noErr)
			return(kServerFuncAbort);
	}

	PLogmsg(LOGP_PROGRESS, "Server_SendRegurg done\n");
	return (kServerFuncOK);
}



// ===========================================================================
//		Automatic ranking update stuff
// ===========================================================================

//
// Note on automatic ranking stuff:
//
// We know if the master is going to play an auto-match or specific-match
// game, but we don't know what the slave is going to do.  If the slave
// requests an auto-match there's no way of knowing if his opponent will be
// another auto-match guy or a specific challenger.
//
// It turns out that we don't really need to worry about this, because
// the master will know, and will send "no points" to both sides if the
// game isn't worth anything.  So the slave will try to update his score,
// and will end up adding zero XBAND Points.
//
// The box only tracks win/loss in the player list, which we do for player
// list challenges anyway.
//
// The "right" way to do this is to have the master determine whether or
// not both sides to the updating (via the peer data exchange), but it's
// a bit late for that, and it looks like we can get away without having
// to do any patching on the box.
//
// Unfortunately, if we decide to do something evil in the matcher like
// make a specific-match person revert to auto-match after a few minutes,
// the bit will be set incorrectly.  In this case the update won't happen
// until the guy calls into the server again.  (This could be solved by
// just setting the "update stats" bit set on the slave side every time,
// which might not be a bad idea in general.)
//
// ++ATM 950615
//

//
// Enable automatic ranking updates on snes.
//
int
Server_SendRankingEnable(ServerState *state)
{
	SubDispatcher subDisp[] = {
		{ kPlatformSNES,	kPlatformSNESMask,		Server_snes_SendRankingEnable },
		{ kPlatformSJNES,	kPlatformSJNESMask,		Server_snes_SendRankingEnable },
		{ kPlatformGenesis,	kPlatformGenesisMask,	Server_no_SendRankingEnable },
		{ kPlatformIntel,	kPlatformIntelMask,		Server_no_SendRankingEnable },
		{ 0,				0,						NULL },		// RONK RONK!!!
	};

	return ( (Common_SubDispatch(state->boxOSState.boxType, subDisp))(state) );
}

PRIVATE int
Server_snes_SendRankingEnable(ServerState *state)
{
	DBID	id = kUpdateRankingsConst;
	long	val = 1;

	PLogmsg(LOGP_PROGRESS, "Server_snes_SendRankingEnable\n");

	PLogmsg(LOGP_DBUG, "SendRegisterPlayer: snes auto-rank update on\n");
	if (Server_SendDBConstants(state, 1, &id, &val) != kServerFuncOK)
		return (kServerFuncAbort);
	return (kServerFuncOK);
}

PRIVATE int
Server_no_SendRankingEnable(ServerState *state)
{
	return (kServerFuncOK);
}


//
// Disable automatic ranking updates on snes.
//
int
Server_SendRankingDisable(ServerState *state)
{
	SubDispatcher subDisp[] = {
		{ kPlatformSNES,	kPlatformSNESMask,		Server_snes_SendRankingDisable },
		{ kPlatformSJNES,	kPlatformSJNESMask,		Server_snes_SendRankingDisable },
		{ kPlatformGenesis,	kPlatformGenesisMask,	Server_no_SendRankingDisable },
		{ kPlatformIntel,	kPlatformIntelMask,		Server_no_SendRankingDisable },
		{ 0,				0,						NULL },		// honk?
	};

	return ( (Common_SubDispatch(state->boxOSState.boxType, subDisp))(state) );
}

PRIVATE int
Server_snes_SendRankingDisable(ServerState *state)
{
	DBID	id = kUpdateRankingsConst;
	long	val = 0;

	PLogmsg(LOGP_DBUG, "SendRegisterPlayer: snes auto-rank update off\n");
	if (Server_SendDBConstants(state, 1, &id, &val) != kServerFuncOK)
		return (kServerFuncAbort);
	return (kServerFuncOK);
}

PRIVATE int
Server_no_SendRankingDisable(ServerState *state)
{
	return (kServerFuncOK);
}



// ===========================================================================
//		Tell the box to wait or dial
// ===========================================================================

//
// This is called before Server_SendRegisterPlayer or
// Server_SendRegisterChallengePlayer.  This message sets the opponent
// verification cookie and a nice random value.
//
int
Server_SendWaitForOpponent(ServerState *state, long magicCookie, long randomVal)
{
	SubDispatcher subDisp[] = {
		{ kPlatformGenesis,	kPlatformGenesisMask,	Server_sega_SendWaitForOpponent },
		{ kPlatformSNES,	kPlatformSNESMask,		Server_snes_SendWaitForOpponent },
		{ kPlatformSJNES,	kPlatformSJNESMask,		Server_snes_SendWaitForOpponent },
		{ kPlatformIntel,	kPlatformIntelMask,		Server_snes_SendWaitForOpponent },
		{ 0,				0,						NULL },		// zonk
	};

	PLogmsg(LOGP_PROGRESS, "Server_SendWaitForOpponent\n");

	if ( (Common_SubDispatch(state->boxOSState.boxType, subDisp))(state,
		magicCookie, randomVal) != kServerFuncOK )
	{
		return (kServerFuncAbort);
	}
	PLogmsg(LOGP_PROGRESS, "Server_SendWaitForOpponent part2\n");

	// Set up regurg as slave.
	//
	Server_BuildRegurg(state, 0, time(0), magicCookie, randomVal);
	Server_SendRegurg(state);

	PLogmsg(LOGP_PROGRESS, "Server_SendWaitForOpponent done\n");
	return(kServerFuncOK);
}

//
// Send WaitForOpponent to a Genesis.  The random value is ignored.
//
PRIVATE int
Server_sega_SendWaitForOpponent(ServerState *state, long magicCookie, long randomVal)
{
	unsigned char 	opCode;

	PLogmsg(LOGP_PROGRESS, "Server_SendWaitForOpponent\n");
	if (Server_DebugService(state) != kServerFuncOK)
		return (kServerFuncAbort);

	opCode = msWaitForOpponent;
	if (Server_TWriteDataSync(state->session, 1, (Ptr)&opCode) != noErr)
		return (kServerFuncAbort);
	if (Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&magicCookie) != noErr)
		return (kServerFuncAbort);

	return (kServerFuncOK);
}

//
// Send WaitForOpponent to a SNES.
//
PRIVATE int
Server_snes_SendWaitForOpponent(ServerState *state, long magicCookie, long randomVal)
{
	unsigned char 	opCode;

	PLogmsg(LOGP_PROGRESS, "Server_SendWaitForOpponent\n");
	if (Server_DebugService(state) != kServerFuncOK)
		return (kServerFuncAbort);

	opCode = msWaitForOpponent;
	if (Server_TWriteDataSync(state->session, 1, (Ptr)&opCode) != noErr)
		return (kServerFuncAbort);
	if (Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&magicCookie) != noErr)
		return (kServerFuncAbort);

	if (Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&randomVal) != noErr)
		return (kServerFuncAbort);

	return (kServerFuncOK);
}


//
// This routine makes the box do a NetRegister with the timeout value.
//
int Server_SendRegisterPlayer(ServerState *state, long timeoutValue, char *gameName, long xbnable)
{
unsigned char 	opCode;
int				err;
char			boggle[1000];

	PLogmsg(LOGP_PROGRESS, "Server_SendRegisterPlayer\n");

	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);

	opCode = msRegisterPlayer;
	if(Server_TWriteDataSync(state->session, 1, (Ptr)&opCode) != noErr)
		return(kServerFuncAbort);

	if(Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&timeoutValue) != noErr)
		return(kServerFuncAbort);

	// Enable automatic ranking updates on snes.
	//
	Server_SendRankingEnable(state);

	// BRAIN DAMAGE.  this should tell you how long the wait is.  Is set to 10 mins now.
	//
	// I18N Appears:  When player is registered to play a Challenge 
	//           match.  XBAND is searching for an opponent.
	// Solution: Wait for the specified number of minutes.  
	//           Either an opponent will dial you, or the modem will 
	//           notify you that XBAND could not find you an opponent, 
	//           and to try Challenging again.
	sprintf(boggle, gettext("We are searching for a worthy %s opponent for you.  We should find one within %d minutes.  %sPlease be patient..."),
		gameName[0] ? gameName : gettext("this game"), 
		(timeoutValue+1800) / 3600, 
		xbnable ? gettext("It may come in via XBAND Nationwide.  ") : ""); 

	err = Server_SendLargeDialog(state, boggle, true);

	PLogmsg(LOGP_PROGRESS, "Server_SendRegisterPlayer done\n");
	return (err);
}

//
// This routine makes the box do a NetRegister with the timeout value.
//
int Server_SendRegisterChallengePlayer(ServerState *state, long timeoutValue, char *gameName, char *challengeName, long xbnable)
{
unsigned char 	opCode;
int				err;
char			boggle[1000];

	PLogmsg(LOGP_PROGRESS, "Server_SendRegisterChallengePlayer\n");

	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);

	opCode = msRegisterPlayer;
	if(Server_TWriteDataSync(state->session, 1, (Ptr)&opCode) != noErr)
		return(kServerFuncAbort);

	if(Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&timeoutValue) != noErr)
		return(kServerFuncAbort);

	// Disable automatic ranking updates on snes.
	//
	Server_SendRankingDisable(state);

	// I18N Appears:  When player does a Player List match against a 
	//           specific player.  If that player conects to XBAND with that 
	//           game, that player will connect to you.
	// Solution: Wait for that player to dail you, or for the 
	//           modem to notify you that the player was not available.
	//
	sprintf(boggle, gettext("You are registered to play %s in a game of %s.  %sHang out until %s shows up."),	/* DIALOG */
		challengeName,
		gameName[0] ? gameName : gettext("this game"), /* DIALOG */
		xbnable ? gettext("It may come in via XBAND Nationwide.  ") : "",
		challengeName);

	err = Server_SendLargeDialog(state, boggle, true);

	PLogmsg(LOGP_PROGRESS, "Server_SendRegisterChallengePlayer done\n");
	return (err);
}


//
// On the box, in messages.c, the receiving routine calls NetRegister.
//
int
Server_SendOpponentPhoneNumber(ServerState *state, const phoneNumber *opponentPhoneNumber, long magicCookie, long randomVal)
{
	SubDispatcher subDisp[] = {
		{ kPlatformGenesis,	kPlatformGenesisMask,	Server_sega_SendOpponentPhoneNumber },
		{ kPlatformSNES,	kPlatformSNESMask,		Server_snes_SendOpponentPhoneNumber },
		{ kPlatformSJNES,	kPlatformSJNESMask,		Server_snes_SendOpponentPhoneNumber },
		{ kPlatformIntel,	kPlatformIntelMask,		Server_snes_SendOpponentPhoneNumber },
		{ 0,				0,						NULL },		// vonk
	};

	PLogmsg(LOGP_PROGRESS, "Server_SendOpponentPhoneNumber\n");

	if ( (Common_SubDispatch(state->boxOSState.boxType, subDisp))(state,
		opponentPhoneNumber, magicCookie, randomVal) != kServerFuncOK )
	{
		return (kServerFuncAbort);
	}
	PLogmsg(LOGP_PROGRESS, "Server_SendOpponentPhoneNumber part2\n");

	// Set up regurg as master.
	//
	Server_BuildRegurg(state, 1, time(0), magicCookie, randomVal);
	Server_SendRegurg(state);

	PLogmsg(LOGP_PROGRESS, "Server_SendOpponentPhoneNumber done\n");
	return (kServerFuncOK);
}

//
// Send a short opponent phone number to a Genesis.  randomVal is ignored.
//
PRIVATE int
Server_sega_SendOpponentPhoneNumber(ServerState *state, const phoneNumber *opponentPhoneNumber, long magicCookie, long randomVal)
{
unsigned char	opCode;
phoneNumber		oppPhoneCopy;

	if (Server_DebugService(state) != kServerFuncOK)
		return (kServerFuncAbort);

	oppPhoneCopy = *opponentPhoneNumber;
	opCode = msOpponentPhoneNumber;
	Server_TWriteDataSync(state->session, 1, (Ptr)&opCode);
	// For backward compatiblity, pump the length with the original phone
	// string size.
	oppPhoneCopy.length = kPhoneNumberSize;
	Server_TWriteDataSync( state->session, sizeof(phoneNumber), (Ptr)&oppPhoneCopy );
	Server_TWriteDataSync( state->session, sizeof(long), (Ptr)&magicCookie );

	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	return (kServerFuncOK);
}

//
// Send a short opponent phone number to a SNES.
//
PRIVATE int
Server_snes_SendOpponentPhoneNumber(ServerState *state, const phoneNumber *opponentPhoneNumber, long magicCookie, long randomVal)
{
unsigned char 	opCode;
phoneNumber		oppPhoneCopy;

	if (Server_DebugService(state) != kServerFuncOK)
		return (kServerFuncAbort);

	oppPhoneCopy = *opponentPhoneNumber;
	opCode = msOpponentPhoneNumber;
	Server_TWriteDataSync(state->session, 1, (Ptr)&opCode);
	// For backward compatiblity, pump the length with the original phone
	// string size.
	oppPhoneCopy.length = kPhoneNumberSize;
	Server_TWriteDataSync( state->session, sizeof(phoneNumber), (Ptr)&oppPhoneCopy );
	Server_TWriteDataSync( state->session, sizeof(long), (Ptr)&magicCookie );

	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	if (Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&randomVal) != noErr)
		return (kServerFuncAbort);

	return (kServerFuncOK);
}


//
// On the box, in messages.c, the receiving routine calls NetRegister.
//
int
Server_SendLongOpponentPhoneNumber(ServerState *state, const char *opponentPhoneNumber, long magicCookie, long randomVal)
{
	SubDispatcher subDisp[] = {
		{ kPlatformGenesis,	kPlatformGenesisMask,	Server_sega_SendLongOpponentPhoneNumber },
		{ kPlatformSNES,	kPlatformSNESMask,		Server_snes_SendLongOpponentPhoneNumber },
		{ kPlatformSJNES,	kPlatformSJNESMask,		Server_snes_SendLongOpponentPhoneNumber },
		{ kPlatformIntel,	kPlatformIntelMask,		Server_snes_SendLongOpponentPhoneNumber },
		{ 0,				0,						NULL },		// donk
	};

	PLogmsg(LOGP_PROGRESS, "Server_SendLongOpponentPhoneNumber\n");
	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);

	opponentPhoneNumber = Common_PhoneXlateOpponentNum(state,
		state->boxPhoneNumber.phoneNumber, (char *)opponentPhoneNumber);
	if (opponentPhoneNumber == NULL) {
		// This should only happen if they would have dialed a foreign
		// country, but that feature was turned off in Common_Phone.c.
		//
		Server_SendDialog(state,
			"There was a problem dialing your opponent.  Please register with XBAND again.",	/*DIALOG*/
			true);
		return (kServerFuncOK);		// let it run its course
	}

	if ( (Common_SubDispatch(state->boxOSState.boxType, subDisp))(state,
		opponentPhoneNumber, magicCookie, randomVal) != kServerFuncOK )
	{
		return (kServerFuncAbort);
	}
	PLogmsg(LOGP_PROGRESS, "Server_SendLongOpponentPhoneNumber part2\n");

	// Set up regurg as master.
	//
	Server_BuildRegurg(state, 1, time(0), magicCookie, randomVal);
	Server_SendRegurg(state);

	PLogmsg(LOGP_PROGRESS, "Server_SendLongOpponentPhoneNumber done\n");
	return (kServerFuncOK);
}

//
// Send a long opponent phone number to a Genesis.  randomVal is ignored.
//
PRIVATE int
Server_sega_SendLongOpponentPhoneNumber(ServerState *state, const char *opponentPhoneNumber, long magicCookie, long randomVal)
{
	unsigned char 	opCode;

	opCode = msOpponentPhoneNumber;
	Server_TWriteDataSync(state->session, 1, (Ptr)&opCode);
	
	// send dummy DBID -- this isn't used for calling opponents
	//
	opCode = 0;
	Server_TWriteDataSync(state->session, 1, (Ptr)&opCode);

	// send phone number length and long phone number
	//
	opCode = strlen(opponentPhoneNumber) + 1;
	Server_TWriteDataSync(state->session, 1, (Ptr)&opCode);
	Server_TWriteDataSync( state->session, opCode, (Ptr)opponentPhoneNumber );

	Server_TWriteDataSync( state->session, sizeof(long), (Ptr)&magicCookie );

	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	return (kServerFuncOK);
}

//
// Send a long opponent phone number to a SNES.
//
PRIVATE int
Server_snes_SendLongOpponentPhoneNumber(ServerState *state, const char *opponentPhoneNumber, long magicCookie, long randomVal)
{
	unsigned char 	opCode;

	opCode = msOpponentPhoneNumber;
	Server_TWriteDataSync(state->session, 1, (Ptr)&opCode);
	
	// send dummy DBID -- this isn't used for calling opponents
	//
	opCode = 0;
	Server_TWriteDataSync(state->session, 1, (Ptr)&opCode);

	// send phone number length and long phone number
	//
	opCode = strlen(opponentPhoneNumber) + 1;
	Server_SetTransportHold(state->session, true);
	Server_TWriteDataSync(state->session, 1, (Ptr)&opCode);
	Server_TWriteDataSync( state->session, opCode, (Ptr)opponentPhoneNumber );
	Server_TWriteDataSync( state->session, sizeof(long), (Ptr)&magicCookie );
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&randomVal);
	Server_SetTransportHold(state->session, false);

	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	return (kServerFuncOK);
}

