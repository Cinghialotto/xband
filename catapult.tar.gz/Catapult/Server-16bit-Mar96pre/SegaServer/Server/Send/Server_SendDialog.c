/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_SendDialog.c,v 1.7 1996/01/25 17:54:37 hufft Exp $
 *
 * $Log: Server_SendDialog.c,v $
 * Revision 1.7  1996/01/25  17:54:37  hufft
 * added UDP based connections
 *
 * Revision 1.6  1995/10/26  03:49:29  jhsia
 * Send all dialogs on kPlatformSJNES through SendLargeDialog instead of
 * SendDialog.
 *
 * Revision 1.5  1995/07/07  20:54:24  fadden
 * Added Server_SetTransportHold calls in one routine.
 *
 * Revision 1.4  1995/05/27  00:58:08  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_SendDialog.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		<18>	 11/8/94	ATM		Propagate some SendDialog changes into SendLargeDialog.
		<17>	10/22/94	ATM		Send dialog messages to the log file.
		<16>	10/18/94	ATM		Added kServerDialogStickyForeverTime for sticky dialogs on
									mail-only connects.
		<15>	10/17/94	DJ		unsetting STICKYDIALOGS
		<14>	 9/26/94	ATM		Make "sticky" mean "stay up for 1 minute" instead of "stay up
									forever".
		<13>	 9/26/94	ATM		Converted debugN to debug[N].
		<12>	 9/20/94	DJ		made non-sticky if testing all POPs too.,
		<11>	 9/19/94	ATM		PLogmsg stuff.
		<10>	 8/22/94	DJ		kDDASAFP works now
		 <9>	 8/18/94	DJ		don't send sticky dialogs when in redial test mode
		 <8>	 8/17/94	DJ		sticky and kDDASAFP
		 <8>	 8/17/94	DJ		sticky always, and use kDDASAFP
		 <7>	 8/12/94	ATM		Converted to Logmsg.
		 <6>	  8/8/94	DJ		SendDialog takes boolean whether to stick or disappear in 3 sec.
		 <5>	 7/25/94	BET		Add gLogFile changes to printf strings.
		 <4>	 7/20/94	DJ		added Server_Comm stuff
		 <3>	 7/15/94	DJ		added large dialog
		 <2>	 7/12/94	DJ		using Server_TCheckError instead of TCheckError
		 <1>	  7/4/94	DJ		first checked in

	To Do:
*/


#include "ServerCore.h"
#include "Server.h"
#include "ServerDataBase.h"

#include "Challnge.h"
#include "Messages.h"
#include "DialogMgr.h"
#include "DeferredDialogMgr.h"
#include "Server_Comm.h"

#include <string.h>
#include <stdio.h>


#define kServerDialogMinTime	120	/* 2 seconds */
#define kServerDialogMaxTime	300	/* 5 seconds */
#define kServerDialogStickyMaxTime	(60*60)		/* 1 minute */
#define kServerDialogStickyForeverTime	0

#define kDDaASAFP	(kDDMainEventLoop|kDDServerConnect|kDDServerConnectDoneImmediate)

//
// Send a dialog down to the box.
//
// Always uses kDDASAFP (which specifies the box states when the dialog
// will be shown).
//
int Server_SendDialog(ServerState *state, char *str, Boolean sticky)
{
short	minTime, maxTime, dialogStick;

	//dialogStick = kDDASAFP;
	dialogStick = kDDaASAFP;

	// Japanese dialogs tend to be huge.  The disadvantage of Large dialogs
	// is that they can end up being deferred if there isn't enough VRAM.
	// We may want to add a heuristic that uses the standard dialog call
	// if the message will fit on one or two lines.
	//
	if (state->platformID == kPlatformSJNES)
		return (Server_SendLargeDialog(state, str, sticky));

	if ((state->validFlags & kServerValidFlag_Account) &&
		(state->account->playerAccount.debug[0] > 0 || state->account->playerAccount.debug[1] > 0))
	{
		// Redial hack.
		//
		sticky = false;
	}

	// minTime is always the same.  maxTime is one of:
	//
	//	5 seconds for non-sticky dialogs
	//	1 minute for sticky dialogs during a matchup request
	//	forever for sticky dialogs during a mail-only connect
	//
	minTime = kServerDialogMinTime;
	if (sticky) {
		if (state->challengeData.userID.box.box == kDownloadOnlyMailSerialNumber)
			maxTime = kServerDialogStickyForeverTime;
		else
			maxTime = kServerDialogStickyMaxTime;

	} else {
		maxTime = kServerDialogMaxTime;
	}

	Logmsg("Dialog: %d/%d '%s'\n", minTime, maxTime, str);

	return (Server_SendQDefDialog(state, dialogStick, str, (DBID)kMediumDialog,
		minTime, maxTime));
}


//
// Post a large dialog.  Always uses kDDASAFP.
//
int Server_SendLargeDialog(ServerState *state, char *str, Boolean sticky)
{
short	minTime, maxTime, dialogStick;

	//dialogStick = kDDASAFP;
	dialogStick = kDDaASAFP;

	if ((state->validFlags & kServerValidFlag_Account) &&
		(state->account->playerAccount.debug[0] > 0 || state->account->playerAccount.debug[1] > 0))
	{
		// Redial hack.
		//
		sticky = false;
	}

	minTime = kServerDialogMinTime;
	if (sticky) {
		if (state->challengeData.userID.box.box == kDownloadOnlyMailSerialNumber)
			maxTime = kServerDialogStickyForeverTime;
		else
			maxTime = kServerDialogStickyMaxTime;

	} else {
		maxTime = kServerDialogMaxTime;
	}

	Logmsg("LargeDialog: %d/%d '%s'\n", minTime, maxTime, str);

	return (Server_SendQDefDialog(state, dialogStick, str, (DBID)kLargeDialog,
		minTime, maxTime));
}

//
// Send the dialog to the box.
//
int
Server_SendQDefDialog(ServerState *state, short when, char *cString, DBID templat, short minTime, short maxTime)
{
long	length;
messOut	opCode;

	PLogmsg(LOGP_PROGRESS, "Server_SendQDefDialog\n");

	Server_SetTransportHold(state->session, true);
	opCode = msQDefDialog;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);

	length = strlen(cString) + 1;
	Server_TWriteDataSync(state->session, sizeof(short), (Ptr)&when);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&templat);
	Server_TWriteDataSync(state->session, sizeof(short), (Ptr)&minTime);
	Server_TWriteDataSync(state->session, sizeof(short), (Ptr)&maxTime);
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&length);
	Server_TWriteDataSync(state->session, length, (Ptr)cString);
	Server_SetTransportHold(state->session,false);
	
	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_SendQDefDialog done\n");

	return(kServerFuncOK);
}

