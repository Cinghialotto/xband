/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_WrapperDB.rpc.c,v 1.12 1995/10/27 19:43:45 steveb Exp $
 *
 * $Log: Server_WrapperDB.rpc.c,v $
 * Revision 1.12  1995/10/27  19:43:45  steveb
 * Just did some long needed housecleaning.  No new code.
 *
 * Revision 1.11  1995/09/27  15:50:24  chs
 * Changed FindAccessCode to FindUCAInfo.
 *
 * Revision 1.10  1995/09/13  14:24:57  ted
 * Fixed warnings.
 *
 * Revision 1.9  1995/07/26  13:56:21  ansell
 * Added wrapper function WrapperDB_FindPlayerInfoChanges().
 *
 * Revision 1.8  1995/06/19  20:29:44  fadden
 * Added WrapperDB_NewFindAccount, tweaked WrapperDB_FindAccountBySerial.
 *
 * Revision 1.7  1995/06/01  15:09:00  fadden
 * Merge in from newbr.
 * -> Changes to calls involving lookups by phone.
 *
 * Revision 1.6  1995/05/26  23:47:24  jhsia
 * switch to rcs keywords
 *
 * Revision 1.5.2.2  1995/05/24  01:18:31  fadden
 * Added WrapperDB_CreateNewAccount (a UCA call).
 *
 * Revision 1.5.2.1  1995/05/22  03:27:05  fadden
 * Added FindSerialByPhone and FindAccountBySerial for new restore stuff
 * (trivial routines), and ifdefed out:
 * WrapperDB_FindAccountByGamePhoneAndPlayerNum
 * WrapperDB_FindReplacementAccountByGamePhoneAndPlayerNum
 * (55-character function names?  Good riddance...)
 *
 */

/*
 * Server_WrapperDB.c and clientstubs.c are the only files who should 
 * define this.
 */
#define REAL_CLIENT_RPC

#include "ServerDataBase.h"
#include "ServerDataBase_priv.h"

Err WrapperDB_FindUserIdentification(const userIdentification *userID, 
   userIdentification *updatedUserID)
{
   return DataBase_FindUserIdentification(userID,updatedUserID);
}

ServerPlayerInfo **
WrapperDB_FindPlayerInfoChanges(const userIdentification *userIDList, 
   const userIdentification *userID, const long lastCheck)
{
	return(Database_FindPlayerInfoChanges(userIDList, userID, lastCheck));
}

ServerPlayerInfo *WrapperDB_FindPlayerInfo(const userIdentification *playerID, 
   const userIdentification *userID)
{
   return Database_FindPlayerInfo(playerID, userID);
}

Account *WrapperDB_GetAccount(const userIdentification *userID)
{
   return DataBase_GetAccount(userID);
}

Err WrapperDB_UpdateAccount(const Account *account)
{
   return DataBase_UpdateAccount(account);
}

#ifdef NOT_USED
Err WrapperDB_FindAccountByGamePhoneAndPlayerNum(phoneNumber *newBoxPhoneNumber, 
   unsigned char playerNum, long platformID, Account **account)
{
   return Database_FindAccountByGamePhoneAndPlayerNum(newBoxPhoneNumber,
      playerNum, platformID, account);
}
#endif	/*NOT_USED*/


#ifdef NOT_USED
Err WrapperDB_FindReplacementAccountByGamePhoneAndPlayerNum(phoneNumber *newBoxPhoneNumber, 
   unsigned char playerNum, long platformID, Account **account)
{
   return Database_FindReplacementAccountByGamePhoneAndPlayerNum(
	newBoxPhoneNumber, playerNum, platformID, account);
}
#endif	/*NOT_USED*/

Err WrapperDB_FindAccount(const userIdentification *userID, Account **account)
{
   return Database_FindAccount(userID, account);
}

Err WrapperDB_NewFindAccount(const userIdentification *userID, Account **account)
{
	return (Database_NewFindAccount(userID, account));
}

Err WrapperDB_FindSerialByPhone(const phoneNumber *phoneNum, long mode, long platformID, BoxSerialNumber *boxp)
{
	return (Database_FindSerialByPhone(phoneNum, mode, platformID, boxp));
}

Err WrapperDB_FindSerialByHWID(const HardwareID *hwid, long platformID, BoxSerialNumber *boxp)
{
	return (Database_FindSerialByHWID(hwid, platformID, boxp));
}

Err WrapperDB_FindAccountBySerial(BoxSerialNumber *boxp, char playerNum, long *statusFlagp, Account **accountp)
{
	return (Database_FindAccountBySerial(boxp, playerNum, statusFlagp, accountp));
}


Err WrapperDB_CreatePlayerAccount(userIdentification *userID, long platformID,
	long *result, Account **account)
{
   return Database_CreatePlayerAccount(userID, platformID, result, account);
}

Err WrapperDB_CreateBoxAndPlayerAccount(userIdentification *userID, 
   phoneNumber *boxPhoneNumber, long platformID, long *result, Account **account)
{
	return Database_CreateBoxAndPlayerAccount(userID, boxPhoneNumber,
		platformID, result, account);
}

void WrapperDB_GenerateUniqueBoxSerialNumber(BoxSerialNumber *boxSerialNumber)
{
   Database_GenerateUniqueBoxSerialNumber(boxSerialNumber);
}

Err WrapperDB_FindUCAInfoByCSID(int csid, UCAInfo **ucainfo)
{
	return DataBase_FindUCAInfoByCSID(csid, ucainfo);
}

//
// This is a stub for the real Oracle routine which shouldn't have to do an account lookup,
// since we pass the account in to it.  For now we will be stoopid and call Database_UpdateUserHandle
// which has to search for the account.  Dumb!
//
Err WrapperDB_NewUpdateUserHandle(userIdentification *userID, long platformID, Account *account, 
   long *result)
{
   return Database_UpdateUserHandle(userID, platformID, result);
}

Err WrapperDB_AddMailToIncoming(const Mail *mail)
{
   return DataBase_AddMailToIncoming(mail);
}

long WrapperDB_GetNumIncomingMail(const userIdentification *userID)
{
   return DataBase_GetNumIncomingMail(userID);
}

Mail *WrapperDB_GetIncomingMail(const userIdentification *userID, long mailIndex)
{
   return DataBase_GetIncomingMail(userID, mailIndex);
}

void WrapperDB_MarkMailAsSent(const userIdentification *userID, long mailIndex)
{
   DataBase_MarkMailAsSent(userID, mailIndex);
}

void WrapperDB_RemoveSentMail( const userIdentification *userID)
{
   DataBase_RemoveSentMail(userID);
}

Err WrapperDB_Initialize(void)
{
   return ServerDataBase_Initialize();
}

Err WrapperDB_Shutdown(void)
{
   return(ServerDataBase_Shutdown());
}

void WrapperDB_SaveToDisk(void)
{
   return(ServerDataBase_SaveToDisk());
}


Err WrapperDB_NonUCACreateNewAccount(unsigned int csid, phoneNumber *boxPhone, long platformID, char *prodstr, long billingType, Account **account)
{
	return (Database_NonUCACreateNewAccount(csid, boxPhone, platformID, prodstr,
		billingType, account));
}

