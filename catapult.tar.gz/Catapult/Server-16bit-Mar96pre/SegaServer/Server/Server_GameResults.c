/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_GameResults.c,v 1.117 1996/02/13 20:26:39 fadden Exp $
 *
 * $Log: Server_GameResults.c,v $
 * Revision 1.117  1996/02/13  20:26:39  fadden
 * Declare some read-only tables as "const".
 *
 * Revision 1.116  1996/02/08  13:24:06  steveb
 * Changed the log level of the game results spooge from LOGP_DBUG to LOGP_INFO
 * so they'll get printed at level 30.
 *
 * Revision 1.115  1996/02/05  16:10:34  fadden
 * Fixed bogus delete in Server_ResetXBNFreebieCount, added back in 1.51.
 *
 * Revision 1.114  1996/01/18  20:09:41  felix
 * Terminate connection if we just ate the last smartCard credit
 *
 * Revision 1.113  1996/01/09  20:01:35  ansell
 * Added index for SJNE game Super Fire ProWrestling X.
 *
 * Revision 1.112  1996/01/05  18:17:25  ansell
 * Changed Super Mario Kart gameID to the real one.
 *
 * Revision 1.111  1996/01/03  11:15:18  chs
 * In Server_ForgetOpponent(), get the gameID from the regurg,
 * not the game result.  The gameID in the latter will be 0 if
 * the game died before making it into the game patch.
 *
 * Revision 1.110  1995/12/20  19:07:40  ansell
 * Added index for new SNES game Kirby's Avalanche.
 *
 * Revision 1.109  1995/12/20  15:51:01  fadden
 * Don't print the rank stat logmsg for player-list matches.
 *
 * Revision 1.108  1995/12/18  14:52:44  fadden
 * Added a line of statistics for KON.
 *
 * Revision 1.107  1995/12/11  17:58:17  ansell
 * Added new Sega game "Mortal Kombat 3".
 *
 * Revision 1.106  1995/12/06  23:00:32  ansell
 * Added SJNE game Puyopuyo and removed games not supported on japanese server.
 *
 * Revision 1.105  1995/12/04  16:37:38  chs
 * Added support for specific-match (currently single-elimination) tourneys.
 *
 * Revision 1.104  1995/11/21  14:22:08  chs
 * Only allow a failed automatch tourney game to be played again
 * if it didn't result in a sufficient-win or -loss.
 *
 * Revision 1.103  1995/11/17  13:29:08  fadden
 * Don't check for hosedPoints if gameID==0x00000000.
 *
 * Revision 1.102  1995/11/16  17:11:43  ansell
 * Added index for SNES game "Mortal Kombat 3".
 *
 * Revision 1.101  1995/11/06  02:46:07  felix
 * check for mail-only connect: no debit if gConfig.debitMailConnectNow set.
 *
 * Revision 1.100  1995/10/30  15:18:27  chs
 * Check for NULL return value from RPC_MatchingControl().
 *
 * Revision 1.99  1995/10/27  19:43:34  steveb
 * Just did some long needed housecleaning.  No new code.
 *
 * Revision 1.98  1995/10/25  16:12:50  chs
 * Clear the opponent history for a tourney match if there is a game error.
 *
 * Revision 1.97  1995/10/16  14:29:35  sriram
 * Cleaned up old tourney stuff. Modifications for new tourney format.
 *
 * Revision 1.96  1995/10/09  18:28:16  ansell
 * Added index for SJNE Super Street Fighter II.
 *
 * Revision 1.95  1995/10/05  03:12:50  ansell
 * Added index for new Sega game NHL '96.
 *
 * Revision 1.94  1995/10/04  23:14:54  ansell
 * Why was I checking for <0 on unsigned values?  Duh!
 *
 * Revision 1.93  1995/10/04  15:37:08  ansell
 * If we couldn't get gameInfo, don't try to use it (forgot an "else"...duh!)
 *
 * Revision 1.92  1995/10/03  17:06:48  ansell
 * Added new SNES game Doom.
 *
 * Revision 1.91  1995/10/02  17:36:42  ansell
 * Added list of indices for SJNES which is currently just a clone of the list
 * for SNES.
 *
 * Revision 1.90  1995/10/02  14:55:43  ansell
 * Added new Sega game Madden '96.
 *
 * Revision 1.89  1995/09/28  17:20:53  ansell
 * Moved points for/against checking to better location and added checks for
 * negative values as well.
 *
 * Revision 1.88  1995/09/28  15:58:10  ansell
 * Added check for possibility of game results sending up rediculous values for
 * scores.
 *
 * Revision 1.87  1995/09/27  00:56:32  ansell
 * Added index for NHL '96.
 *
 * Revision 1.86  1995/09/26  10:37:19  ansell
 * Added rankings index for Madden '96.
 *
 * Revision 1.85  1995/09/25  00:53:40  fadden
 * Activated CompleteEnough stuff.  Pass an extra argument to all "fucker
 * mail" routines and the "fucker result" handler, so they don't send
 * mail or add credits when the CompleteEnough stuff is going to handle it.
 *
 * Revision 1.84  1995/09/20  00:00:23  fadden
 * Shuffled credit and fucker checks to accommodate CompleteEnough stuff.
 * Left the CompleteEnough check itself #ifdefed out due to complications.
 *
 * Revision 1.83  1995/09/16  17:12:37  fadden
 * Minor tweak to test code.
 *
 * Revision 1.82  1995/09/13  16:59:31  fadden
 * Added an alias for Genesis Weapon Lord.
 *
 * Revision 1.81  1995/09/13  14:33:51  fadden
 * Added annotation to SNES Weapon Lord (now two versions).
 *
 * Revision 1.80  1995/09/13  14:24:27  ted
 * Fixed warnings.
 *
 * Revision 1.79  1995/09/10  23:51:54  fadden
 * Don't bother with CompleteEnough for gameID=0x00000000.
 *
 * Revision 1.78  1995/09/10  22:32:23  fadden
 * Added call to CompleteEnough for initial testing.
 *
 * Revision 1.77  1995/08/28  16:33:29  fadden
 * Changed logmsg to DETAIL.
 *
 * Revision 1.76  1995/08/28  15:46:57  fadden
 * Don't update dailyTotalGames for player-list matches.
 *
 * Revision 1.75  1995/08/27  18:52:23  fadden
 * Added snes Killer Instinct.
 *
 * Revision 1.74  1995/08/25  17:40:07  fadden
 * Added Server_AnalyzeWin, changed code to use WinAnalysis struct.  Minor
 * changes to RA and GR logmsgs.
 *
 * Revision 1.73  1995/08/21  22:32:59  ansell
 * Changed a parameter from a Boolean to a long so it would hold the actual
 * value being sent (duh!).
 *
 * Revision 1.72  1995/08/16  18:07:45  fadden
 * Display XBN flag in matchupRegurg dump.
 *
 * Revision 1.71  1995/08/16  17:23:49  ansell
 * Fixed so that it properly checks valid flags for wins/losses.
 *
 * Revision 1.70  1995/08/16  16:56:14  fadden
 * Added Ken Griffey Baseball.  Removed unneeded alias for NBA JAM from ix tab.
 *
 * Revision 1.69  1995/08/16  13:05:08  ansell
 * If we received win/loss info from the box (only snes now) then use that to
 * update the address book rather than the game results.
 *
 * Revision 1.68  1995/08/11  14:51:08  fadden
 * Initialize and maintain dailyTotalGames and dailyCordPulls.
 *
 * Revision 1.67  1995/08/10  14:22:30  fadden
 * Tweaked a logmsg.
 *
 * Revision 1.66  1995/08/10  12:03:31  fadden
 * Added gameID for final Primal Rage.
 *
 * Revision 1.65  1995/08/08  16:42:59  steveb
 * Deleted a line which referred to a no longer existing DB field.
 *
 * Revision 1.64  1995/08/08  13:47:45  rich
 * Concatenated two gettext() strings into one.
 *
 * Revision 1.63  1995/08/07  21:44:15  fadden
 * Added calls to cord pull checks.
 *
 * Revision 1.62  1995/08/07  14:45:22  fadden
 * Moved all the fucker checks out to Server_Justice.c.  Declared private
 * local routines as such.
 *
 * Revision 1.61  1995/08/03  12:29:26  fadden
 * Implemented one-sided reset enforcement (doesn't send mail or add a loss to
 * the guy who hit reset).  Replaced some score checks with PossiblyLosing
 * calls.
 *
 * Revision 1.60  1995/07/31  21:20:49  fadden
 * Added Ballz, snes Weapon Lord, and snes NBA Live '95.
 *
 * Revision 1.59  1995/07/17  19:15:34  fadden
 * LRA: Fixed a couple more logmsgs, removed all the peer net err stuff.
 *
 * Revision 1.58  1995/07/17  18:36:35  fadden
 * LRA: changed a logmsg to LOGP_DETAIL.
 *
 * Revision 1.57  1995/07/12  18:16:41  fadden
 * Added sega Rampart, sega Micro Machines, snes Super Mario Kart, and snes
 * FIFA International Soccer.
 *
 * Revision 1.56  1995/07/12  17:30:28  ansell
 * Prepended magic cookie to "Game Result" type logs messages.
 *
 * Revision 1.55  1995/07/10  20:59:32  rich
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.54  1995/07/10  10:33:59  ted
 * Moved proto of Server_ResetXBNFreebieCount to Server.h.
 *
 * Revision 1.53  1995/07/04  22:51:19  fadden
 * Added Primal Rage (beta).
 *
 * Revision 1.52  1995/06/22  23:06:34  fadden
 * Added Weapon Lord (final), made the beta version an alias to it.
 *
 * Revision 1.51  1995/06/19  17:38:18  ted
 * Added Server_ResetXBNFreebieCount to clear count upon successfull game.
 *
 * Revision 1.50  1995/06/05  23:30:44  chs
 * Count successfully completed challenges for the EB/BB promos.
 * Data stored in the opaquestore.
 *
 * Revision 1.49  1995/06/02  15:29:27  fadden
 * Changed the regurg format yet again, using dash's suggestions.
 *
 * Revision 1.48  1995/06/01  22:32:39  fadden
 * Change to Regurg log format: include platformID/gameID, don't include long
 * date format (just hex).
 *
 * Revision 1.47  1995/06/01  16:32:25  fadden
 * Print MatchupRegurg->gamePatchVer.
 *
 * Revision 1.46  1995/05/24  00:20:13  fadden
 * Changed "> kMaxRankingInfo" to ">= kMaxRankingInfo".
 *
 * Revision 1.45  1995/05/22  17:45:10  fadden
 * Added -413, -415, -416, and -429 to errors that fall into "(misc)" category.
 *
 * Revision 1.44  1995/05/21  22:58:44  fadden
 * Added FIFA Soccer '95.
 *
 * Revision 1.43  1995/05/18  07:34:22  fadden
 * Added Weapon Lord (beta).
 *
 * Revision 1.42  1995/05/16  23:22:11  fadden
 * Combine twisty "nope, credit not deducted" messages into new function
 * Server_PrintNoCreditDeduct.  Treat gameResult->gameError!=0 as a game error
 * instead of a peer error.  Put -432 and -434 into "misc" instead of "game".
 *
 * Revision 1.41  1995/05/16  06:13:30  fadden
 * Add description of how call waiting stuff is reported.
 *
 * Revision 1.40  1995/05/15  18:56:26  chs
 * For topten purposes, a rankinginfo "day" is now from noon to noon
 * instead of midnite to midnite.
 *
 */

/*
	File:		Server_GameResults.c

	Written by:	David Jevans

	Change History (most recent first):

		<41>	12/13/94	ATM		Fixed bug in daily result updating.
		<40>	12/13/94	ATM		Implemented FuckerResults.  Made xpoints unsigned, don't let it
									roll over.
		<39>	12/11/94	ATM		Re-enabled call waiting checks.  Disabled "reset while waiting
									for call" stuff.
		<38>	 12/6/94	ATM		Add case for mail-only connect.
		<37>	 12/6/94	HEC		Tweaked fax mail text.
		<36>	 12/6/94	ATM		Updated credit stuff.  Mostly just treat specific-match connects
									the same as auto-match connects.
		<35>	 12/2/94	HEC		Added Server_CheckForFAX.
		<34>	 12/2/94	ATM		Tweaked the test stuff.
		<33>	11/26/94	ATM		Added calls to Common_GetCanonicalGameID.  New ranking structs
									are now always created with the canonical ID.
		<32>	11/26/94	ATM		Disable call waiting stuff; looks like slave hits "continue" but
									still gets -432 back.
		<31>	11/23/94	ATM		Added FuckerMail for call waiting stuff.  Added some stuff to
									generate fake results.
		<30>	11/17/94	ATM		Tweak reset mail message.
		<29>	11/16/94	ATM		Store Madden '95 results.
		<28>	11/14/94	ATM		Shuffled stuff around for call waiting.
		<27>	11/14/94	ATM		Show gameResult->connectPhase.
		<26>	11/13/94	ATM		Fixed logmsgs in peer error stuff.
		<25>	 11/9/94	DJ		Renamed some DB routines to DataBaseUtil_ and also to WrapperDB_
									(for Oracle).
		<24>	 11/9/94	ATM		Fixed a logmsg.
		<23>	 11/8/94	ATM		Added calls to Server_UpdateAddrBookAfterGame.
		<21>	 11/8/94	ATM		Added check for evil call-waiting.  Deduct a credit if you hit
									reset while waiting.
		<20>	 11/7/94	ATM		Fixed a bug in error reporting.
		<19>	 11/6/94	ATM		Add check for hitting reset while on queue and re-entering later
									on.  Reorganized routines slightly.
		<18>	 11/6/94	ATM		Cut & pasted 800 # stuff in.
		<17>	 11/5/94	ATM		Check against kMaxPreviousOpponent was off.
		<16>	 11/4/94	ATM		Update "daily" fields.
		<15>	 11/2/94	ATM		Initial pass at recrediting stuff.
		<14>	10/31/94	ATM		Tweaked peer connect error reporting.
		<12>	10/29/94	ATM		Tweaked.
		<11>	10/29/94	ATM		Send fuckerMail with the name of the fucker who reset, not
									current fucker.
		<10>	10/28/94	ATM		Start sending mail when reset detected.
		 <9>	10/24/94	ATM		Handle different return values from CheckReset (clean, maybe,
									evil).
		 <8>	10/20/94	DJ		Moved Server_UpdateGameResults from ServerCore.c
		 <7>	10/20/94	ATM		Added MKII to game result index.
		 <6>	10/20/94	ATM		Added lastMatchup.oppUserName to a couple more places.
		 <5>	10/20/94	ATM		Fix username in mail to resettee.
		 <4>	10/19/94	ATM		Print oppUserName from LastMatchup.  Added draft version of mail
									message to send when someone does an evil reset.
		 <3>	10/18/94	ATM		Changed some logmsgs around.
		 <2>	10/17/94	ATM		Added HaveValidGameResults, CheckForReset.  Make calls into
									GameSpecific stuff.
		 <1>	10/17/94	ATM		Moved here from DataBase_GameResults.c.
		<35>	10/17/94	ATM		Removed some logmsgs for provisional stuff.
		<34>	10/14/94	ATM		Fiddle faddle.
		<33>	10/14/94	ATM		Changed a printf.
		<32>	10/14/94	ATM		Something.
		<31>	10/14/94	ATM		Implemented scoring based on all rounds of MK match.  Twiddled
									some logmsgs.
		<30>	10/11/94	ATM		Use NewGameResult to show errors.
		<29>	10/10/94	ATM		Added yet more logging stuff.
		<28>	10/10/94	ATM		Show last opponent even if game ended in error.
		<27>	 10/9/94	ATM		Now pass in game errors as well.  Added some more stuff.
		<26>	 10/8/94	ATM		Improved result printing.
		<25>	 10/7/94	ATM		Updated for new LastMatchup and PreviousOpponent structs.
		<24>	 10/6/94	ATM		Minor tweaks.
		<23>	 10/5/94	ATM		Added "player" to PlayerAccount and LastMatched.  Moved
									LastMatched into BoxAccount.  Added #define CLIENTRPC.  Handle
									case where current player != last player.
		<22>	 10/4/94	ATM		Added gameID to ranking logmsg.
		<21>	 10/3/94	ATM		The "promoted" message didn't work.
		<20>	 10/3/94	ATM		Print the value of wasSpecific.
		<19>	 10/2/94	ATM		Catch some uninitialized stuff.  Don't give credit for
									specific-challenge matches.
		<18>	 10/1/94	ATM		Fix problem with oppRankingInfo.  Add more log messages.
		<17>	 10/1/94	ATM		Reorganize game result handling around new rating stuff.
		<16>	 9/30/94	ATM		Added NHL '95 to kludgy crap.
		<15>	 9/29/94	ATM		Add NHL '94.  Update numRankingInfo if we try to record a rank
									past it.
		<14>	 9/25/94	ATM		Changed RankingInfo for Kon's new stuff.  Don't yet call the
									rating stuff.
		<13>	 9/19/94	ATM		PLogmsg stuff.
		<12>	 9/16/94	ATM		boxFlags->boxModified, playerFlags->playerModified,
									acceptChallenges->playerFlags.
		<11>	  9/3/94	ATM		Handle "xpoints" field.
		<10>	  9/2/94	ATM		Neglected to set kPA_ranking.
		 <9>	  9/2/94	ATM		Fix aforementioned tie crediting.
		 <8>	 8/31/94	ATM		Credit 1 win and 1 loss for a tie.
		 <7>	 8/28/94	ATM		Don't update game rankings if there's an error result.  (This
									may change...)
		 <6>	 8/19/94	ATM		Removed a FreeAccount call.
		 <5>	 8/19/94	ATM		De-RPCed UpdateRanking.
		 <4>	 8/19/94	ATM		Implemented DataBase_UpdateRanking.
		 <3>	  7/2/94	DJ		GameResult struct
		 <2>	 5/29/94	DJ		tweaked api
		 <1>	 5/27/94	DJ		first checked in

	To Do:
*/

#include <stdio.h>
#include <time.h>
#include <memory.h>
#include <sys/time.h>
#include <malloc.h>
#include <strings.h>

#include "Common_ReadConf.h"
#include "Common_PlatformID.h"
#include "Common_OpaqueStore.h"
#include "Common_Missing.h"

#include "Server.h"
#include "ServerDataBase.h"
#include "Server_Tournament.h"
#include "Server_GameSpecific.h"
#include "Server_Rankings.h"
#include "OpaqueStoreKeys.h"
#include "DataBase_Match.h"
#include "Server_Comm.h"

#include "BoxSer.h"

//
// Local prototypes.
//
PRIVATE Err Server_ExamineGameResults(ServerState *state);
PRIVATE Err Server_UpdateRankingInfo(Account *account,NewGameResult *gameResult,
	NewGameResult *gameErrorResult, RankingInfo *myRankInfo, int dailyPtr,
	long updateAddr);
PRIVATE Err Server_HaveValidGameResults(ServerState *state,
	const NewGameResult *gameResult, const NewGameResult *gameErrorResult);
PRIVATE int Server_DumpMatchupRegurg(ServerState *state);
PRIVATE int Server_IsSameDay(time_t date1, time_t date2);
PRIVATE void Server_PrintNoCreditDeduct(ServerState *state,
	NewGameResult *gameResult, NewGameResult *gameErrorResult, char *type);
// TourneyLite
PRIVATE void Server_CountCompletedChallenges(ServerState *);
PRIVATE void Server_SetTourneyErrorResult(TourneyResult*, long);
PRIVATE Err Server_ForgetOpponent(ServerState *, const BoxSerialNumber *,
				   const long);


//#define TESTING_GAME_RESULTS
#ifdef TESTING_GAME_RESULTS
PRIVATE int CreateFakeGameResults(ServerState *state,
	NewGameResult **gameResult, NewGameResult **gameErrorResult, int set);
PRIVATE int TestWorthString(void);
#endif


#define MY_MAX_MAIL_MESG_SIZE	512


//
// Update game results.  
//
int
Server_UpdateGameResults(ServerState *state)
{
	GameResult *gameResult, *gameErrorResult;

	//
	// If we've got game results, update their rating.
	//
	ASSERT(state->validFlags & kServerValidFlag_Account);
	if (!(state->validFlags & kServerValidFlag_Account)) {
		PLogmsg(LOGP_FLAW, "Managed to get to UpdateGameResults w/o Account.\n");
		return (kServerFuncEnd);
	}

	if (state->validFlags & kServerValidFlag_GameResults)
		gameResult = state->gameResult;
	else
		gameResult = NULL;
	if (state->validFlags & kServerValidFlag_GameErrorResults)
		gameErrorResult = &state->gameErrorResult;
	else
		gameErrorResult = NULL;

#ifdef DO_LOG_NETERRS
	if ((gameResult != NULL || gameErrorResult != NULL) &&
		(state->validFlags & kServerValidFlag_NetErrorsX25))
	{
		int pc, busy, disconnect, abort, noans, handshake, cw, rcw, cts;
		char ms;

		pc = (int) state->boxNetErrorsX25.peerConnects;
		busy = (int) state->boxNetErrorsX25.peerBusyError;
		disconnect = (int) state->boxNetErrorsX25.peerDisconnectError;
		abort = (int) state->boxNetErrorsX25.peerAbortError;
		noans = (int) state->boxNetErrorsX25.peerNoAnswerError;
		handshake = (int) state->boxNetErrorsX25.peerHandshakeError;
		cw = (int) state->boxNetErrorsX25.callWaitingError;
		rcw = (int) state->boxNetErrorsX25.remoteCallWaitingError;
		cts = (int) state->boxNetErrorsX25.ctsTimeouts;

		if (pc == busy &&
			busy == disconnect &&
			disconnect == abort &&
			abort == noans &&
			noans == handshake &&
			handshake == cw &&
			cw == rcw &&
			rcw == cts)
		{
			if (!busy)
				Logmsg("PEER: all values are zero\n");
			else
				Logmsg("PEER: all values are equal, probably initialized box\n");
		} else {
			if (pc >= 127 ||
				busy >= 127 ||
				disconnect >= 127 ||
				abort >= 127 ||
				noans >= 127 ||
				handshake >= 127 ||
				cw >= 127 ||
				rcw >= 127 ||
				cts >= 127)
			{
				Logmsg("PEER: one or more values is greater >= 127, probably new box\n");
			} else {
				if (Server_BoxWasMaster(state))
					ms = 'M';
				else
					ms = 'S';
				Logmsg("PEER: X25 %cPeerConnects = %d\n", ms, pc);
				Logmsg("PEER: X25 %cPeerBusyError = %d\n", ms, busy);
				Logmsg("PEER: X25 %cPeerDisconnectError = %d\n", ms, disconnect);
				Logmsg("PEER: X25 %cPeerAbortError = %d\n", ms, abort);
				Logmsg("PEER: X25 %cPeerNoansError = %d\n", ms, noans);
				Logmsg("PEER: X25 %cPeerHandshakeError = %d\n", ms, handshake);
				Logmsg("PEER: X25 %cCallWaitingError = %d\n", ms, cw);
				Logmsg("PEER: X25 %cRemoteCallWaitingError = %d\n", ms, rcw);
				Logmsg("PEER: X25 %cCtsTimeouts = %d\n", ms, cts);
			}
		}
	}

	// Some stuff changed, so this is now necessary.
	//
	if ((gameResult != NULL || gameErrorResult != NULL) &&
		(state->validFlags & kServerValidFlag_NetErrors800))
	{
		int pc, busy, disconnect, abort, noans, handshake, cw, rcw, cts;
		char ms;

		pc = (int) state->boxNetErrors800.peerConnects;
		busy = (int) state->boxNetErrors800.peerBusyError;
		disconnect = (int) state->boxNetErrors800.peerDisconnectError;
		abort = (int) state->boxNetErrors800.peerAbortError;
		noans = (int) state->boxNetErrors800.peerNoAnswerError;
		handshake = (int) state->boxNetErrors800.peerHandshakeError;
		cw = (int) state->boxNetErrors800.callWaitingError;
		rcw = (int) state->boxNetErrors800.remoteCallWaitingError;
		cts = (int) state->boxNetErrors800.ctsTimeouts;

		if (pc == busy &&
			busy == disconnect &&
			disconnect == abort &&
			abort == noans &&
			noans == handshake &&
			handshake == cw &&
			cw == rcw &&
			rcw == cts)
		{
			if (!busy)
				Logmsg("PEER: all values are zero\n");
			else
				Logmsg("PEER: all values are equal, probably initialized box\n");
		} else {
			if (pc >= 127 ||
				busy >= 127 ||
				disconnect >= 127 ||
				abort >= 127 ||
				noans >= 127 ||
				handshake >= 127 ||
				cw >= 127 ||
				rcw >= 127 ||
				cts >= 127)
			{
				Logmsg("PEER: one or more values is greater >= 127, probably new box\n");
			} else {
				if (Server_BoxWasMaster(state))
					ms = 'M';
				else
					ms = 'S';
				Logmsg("PEER: 800 %cPeerConnects = %d\n", ms, pc);
				Logmsg("PEER: 800 %cPeerBusyError = %d\n", ms, busy);
				Logmsg("PEER: 800 %cPeerDisconnectError = %d\n", ms, disconnect);
				Logmsg("PEER: 800 %cPeerAbortError = %d\n", ms, abort);
				Logmsg("PEER: 800 %cPeerNoansError = %d\n", ms, noans);
				Logmsg("PEER: 800 %cPeerHandshakeError = %d\n", ms, handshake);
				Logmsg("PEER: 800 %cCallWaitingError = %d\n", ms, cw);
				Logmsg("PEER: 800 %cRemoteCallWaitingError = %d\n", ms, rcw);
				Logmsg("PEER: 800 %cCtsTimeouts = %d\n", ms, cts);
			}
		}
	}
#endif	/*DO_LOG_NETERRS*/

	Server_CheckForFAX(state, gameResult, gameErrorResult);
		
	Server_ExamineGameResults(state);

#define LAST_CREDIT_NO_SERVICE
#ifdef LAST_CREDIT_NO_SERVICE
	if (gConfig.useDebitCardOnly &&
	state->prevCard == state->currentCard &&
    state->creditDebitInfo.currentCredits <= 0) {

	// The last credits on this card were used for the previous connect, so
	// we should debit the card and not provide any further service on this
	// connection.

		unsigned char opCode;
		long  controlFlags;
		short creditDelta = state->creditDebitInfo.debitCardInfo.creditsLeft;

		PLogmsg(LOGP_PROGRESS, "Server_UpdateGameResults: Eating last credit and ending connection\n");

		if (creditDelta > gConfig.maxSmartCardDebits) {
    		PLogmsg(LOGP_PROGRESS, "Server_UpdateGameResults: STRANGE! debit exceeds maximum -- trimming from %d to %d\n", creditDelta, gConfig.maxSmartCardDebits);
    		creditDelta = gConfig.maxSmartCardDebits;
		}

		// Send debit message to the card.

		PLogmsg(LOGP_PROGRESS, "Server_UpdateGameResults: Sending card debit message for % d credits\n", creditDelta);

		Server_SendDebitSmartcard(state, creditDelta);

		// Clear game res from the box, since they've been analyzed.

		opCode = msServerMiscControl;
		Server_TWriteDataSync(state->session,sizeof(messOut),(Ptr)&opCode);
		controlFlags = kClearGameResultsFlag;
		Server_TWriteDataSync(state->session,sizeof(long),(Ptr)&controlFlags);

		// Set flags so smartCard database is updated

		state->commitSmartCardChanges = true;

		return (kServerFuncEnd);

	}
#endif /*  LAST_CREDIT_NO_SERVICE */

	return (kServerFuncOK);
}



PRIVATE void
Server_CountCompletedChallenges(ServerState *state)
{
    OpaqueStore *os = &state->account->playerAccount.opaqueStore;
    OpaqueStoreValue osval;
    Err err;
    u_int ossize = -1;
    int count = -1;

    err = OpqStore_GetValueSize(os, kChallengeCountKey, &ossize);
    if (err == kOpqNoError) {
	/* make sure the old value was the right size */
	if (ossize != sizeof(int)) {
	    Logmsg("wrong EBBB opaque size\n");
	    return;
	}

	/* get the old value */
	osval.buf = (char *)&count;
	osval.numMaxBytes = osval.numBytes = sizeof(int);
	err = OpqStore_GetKeyValue(os, kChallengeCountKey, &osval);
	if (err != kOpqNoError) {
	    Logmsg("couldn't get EBBB opaque value: %d\n", err);
	    return;
	}

	/* set the incremented value */
	count++;
	err = OpqStore_SetKeyValue(os, kChallengeCountKey, &osval);
		if (err != kOpqNoError) {
			Logmsg("couldn't set EBBB opaque value: %d\n", err);
		}
    }
    else {
		/* create new entry */
		count = 1;
		osval.buf = (char *)&count;
		osval.numMaxBytes = osval.numBytes = sizeof(int);
		err = OpqStore_NewKeyValue(os, kChallengeCountKey, &osval);
		if (err != kOpqNoError) {
			Logmsg("couldn't set new EBBB opaque value: %d\n", err);
		}
    }
    state->account->playerModified |= kPA_opaqueStore;
}

// Temporary for SNES: when a successfull game has been played,
// reset potential freebie XBN match.

void Server_ResetXBNFreebieCount(ServerState *state)
{
	unsigned int size;

	PLogmsg(LOGP_PROGRESS, "Server_ResetXBNFreebieCount\n");

	// ignore if already gone, just delete the sucker.
	// [ this made real errors harder to find in the log... so I fixed it
	//   in my copious spare time. ++ATM ]

	if (OpqStore_GetValueSize(&state->account->playerAccount.opaqueStore,
		kXBNFreebieCountKey, &size) != kOpqUnknownKey)
	{
		PLogmsg(LOGP_DETAIL, "Deleting kXBNFreebieCountKey opaque store\n");
		OpqStore_DeleteKeyValue(&state->account->playerAccount.opaqueStore,
			kXBNFreebieCountKey);
		state->account->playerModified |= kPA_opaqueStore;
	}
}


PRIVATE void
Server_SetTourneyErrorResult(
    TourneyResult	*result,
    long		status
)
{
    if (status == kNoError)
	return;

    switch(status) {
	case kResetMaybe:
		result->flags |= kTourneyResetMaybe;
		break;

	case kResetDefinite:
		result->flags |= kTourneyResetDefinite;
		break;

	case kCordPullFucker:
		result->flags |= kTourneyCordPullFucker;
		break;

	case kCallWaitingHoser:
		result->flags |= kTourneyCallWaitingHoser;
		break;

	case kCallWaitingFucker:
		result->flags |= kTourneyCallWaitingFucker;
		break;

	case kNotEnoughCompletedTie:
		result->flags |= kTourneyNotEnoughCompletedTie;
		break;

	case kEnoughCompletedTie:
		result->flags |= kTourneyEnoughCompletedTie;
		break;

	case kEnoughCompletedLocalWinner:
		result->flags |= kTourneyEnoughCompletedLocalWinner;
		break;

	case kEnoughCompletedRemoteWinner:
		result->flags |= kTourneyEnoughCompletedRemoteWinner;
		break;

	default:
		result->flags |= kTourneyUnknownError;
		break;
    }
}


PRIVATE Err
Server_ForgetOpponent(ServerState *state, const BoxSerialNumber *box,
		      const long gameID)
{
	MatchControl mc;
	MatchControl_ForgetBoxOpponentHistory *forget = (void *)&mc;
	MatchControlResult_Status *res;

	Logmsg("Telling matcher %lx to forget I played (%ld,%ld)\n", gameID,
	       box->box, box->region);

	forget->type = kMatchCtl_ForgetBoxOpponentHistory;
	forget->box1 = state->loginData.userID.box;
	forget->box2 = *box;

	res = (MatchControlResult_Status *)
	    RPC_MatchingControl(&mc, state->platformID, gameID);
	if (!res) {
	    PLogmsg(LOGP_FLAW, "ERROR: RPC_MatchingControl in Server_ForgetOpponent returned NULL\n");
	    return kFucked;
	}

	if (res->result != kNoError) {
	    PLogmsg(LOGP_NOTICE, "kMatchCtl_ForgetBoxOpponentHistory -> %d\n",
		    res->result);
	}

	return (res->result);
}

//
// Update PlayerAccount->rankingInfo.
//
// Also handles recrediting for failed games and resets, so this needs to
// be called before kServerSendAccountInfo or the user will be confused.
// 2/8/95 Ted: all returns now jump to "done" with "err" set. Default err is kNoError.
// This was so we can reliably call Server_InvalidTourneyResults and prevent
// future accidents from people updating the code.
//
PRIVATE Err
Server_ExamineGameResults(ServerState *state)
{
	NewGameResult *gameResult, *gameErrorResult;
	RankingInfo *myRankInfo;
	Account *account, *updateAccount = NULL;
	Err have_valid, ce_result;
	long gameID;
	int dailyPtr;
	char msgbuf[512];
	Err err = kNoError;

	PLogmsg(LOGP_PROGRESS, "Server_ExamineGameResults\n");

#ifdef TESTING_GAME_RESULTS
	CreateFakeGameResults(state, &gameResult, &gameErrorResult, 0);
	TestWorthString();
#endif /*TESTING_GAME_RESULTS*/

	Server_DumpMatchupRegurg(state);

	if (state->validFlags & kServerValidFlag_GameResults) {
		gameResult = (NewGameResult *) state->gameResult;
		Server_DumpGameResult(state, gameResult, 0);
	} else {
		gameResult = NULL;
		Logmsg("No Game Results to receive\n");
	}
	if (state->validFlags & kServerValidFlag_GameErrorResults) {
		gameErrorResult = (NewGameResult *) &state->gameErrorResult;
		Server_DumpGameResult(state, gameErrorResult, 1);
	} else {
		gameErrorResult = NULL;
		Logmsg("No Game Error Results to receive\n");
	}

	account = state->account;

	// Sanity check for dash's sanity.  If we get a regurg, we should
	// probably be getting game results.  If we were the master, we should
	// DEFINITELY be getting game results.
	//
	if (gameResult == NULL && gameErrorResult == NULL && 
		state->oldMatchupRegurg)
	{

		if (state->oldMatchupRegurg->version != kMatchupRegurgVersion) 
		{
			Logmsg("Regurg check: got version %d, current is %d\n",
				state->oldMatchupRegurg->version, kMatchupRegurgVersion);
		}
		else if (state->oldMatchupRegurg->master)
		{
			PLogmsg(LOGP_NOTICE, "GLITCH: no game res for master on '%.4s'\n",
				(char *)&state->platformID);
		}
	}

	// Check for errors and other reasons why we wouldn't want to score
	// this game.  Reset and cord pull detection happens here too.
	//
	have_valid = Server_HaveValidGameResults(state, gameResult, gameErrorResult);

	// Try to refine have_valid by looking for call waiting events.  Don't
	// remember why this isn't done inside HaveValidGameResults.
	//
	// CheckCallWaiting will return something other than kNoError if he
	// elected not to continue.  We don't want to consider the completeEnough
	// stuff in this case; if he didn't continue, he doesn't deserve a win.
	// (Hmm, he may deserve a loss... ugh.)
	//
	if (have_valid == kFucked) {
		long result;

		result = Server_CheckCallWaiting(state, gameErrorResult);
		if (result != kNoError)
			have_valid = result;
	}

	//
	//TourneyStuff:
	//	Check if these game results are tourney results.
	//	Store two orthogonal components of tourney results:
	//	1. Was there a reset, cord-pull or call-waiting disconnect ?
	//	2. The outcome of the "winning sufficiently" heuristics for
	//	   this game.
	//
	if (state->oldMatchupRegurg && 
		(state->oldMatchupRegurg->flags & kRegurgFlagUsedTourney)) {

		/* for single-elimination tourney */
		Server_TourneyProcessGameResults(account, state->oldMatchupRegurg,
										 gameResult, gameErrorResult);

	    state->tourneyResult = (TourneyResult *)malloc(sizeof(TourneyResult));
	    state->tourneyResult->flags = 0;

	    if (have_valid != kNoError) {
	        Server_SetTourneyErrorResult(state->tourneyResult, have_valid);
	    
	        if (gameErrorResult != NULL) {
	    	    long	winEnough;

	            winEnough = Server_CompleteEnough(state, gameErrorResult);
	    	    Server_SetTourneyErrorResult(state->tourneyResult, winEnough);

				if (winEnough != kEnoughCompletedLocalWinner &&
					winEnough != kEnoughCompletedRemoteWinner)
				{
					Server_ForgetOpponent(state, &state->origLastMatchup->prevOpponent.oppBoxSerialNumber, state->oldMatchupRegurg->gameID);
				}
	        }
	    }

	    // this indicates to the binlog processing routines that we made 
	    // it past this point (ie: valid state->tourneyResult) in case of 
	    // a sighup.
	    state->validFlags |= kServerValidFlag_TourneyResult;
	}
	Server_TourneySendAutoMail(state);


	// Get the result from the CompleteEnough check (which determines
	// whether or not the game was close enough to being complete that it
	// should be treated as a finished game).
	//
	// There are two interesting cases:
	//	- I was close to winning.  I should get the win, have a credit
	//	  deducted, and get a nice mail message.
	//	- I was evil (reset, call waiting, cord pull), but the other guy
	//	  is going to get the win anyway via CompleteEnough.  So while I
	//	  want to continue with the usual fucker-processing, I don't want
	//	  to notify my opponent of my transgressions, or give him a win.
	//
	// This *requires* that the CompleteEnough routines be symmetric.
	// Note we don't currently assign the loss, so by pulling the cord
	// at the right moment you can guarantee that the winner gets the win
	// and the loser gets a free game.  Easy enough to fix later.
	//
	// There are some exceptional cases (surprise, surprise):
	//	- Don't do CompleteEnough checking on specific-match games.  The
	//	  win doesn't count anyway.  Only advantage to doing so is that we'd
	//	  be able to deduct a credit where we otherwise couldn't.
	//	- If he hit reset for any reason, don't assign a win.  It should
	//	  never be necessary to hit reset unless the game patch is
	//	  defective.
	//	- If he chose not to continue after call waiting, don't assign
	//	  a win, even if he was winning.
	//
	// In general, we NEVER want to override call waiting, reset, or cord
	// pull detection, though we may want to not notify the opponent.  We
	// also need to make sure this doesn't fire after a successul game!
	//
	// (Interesting side note: if BOTH players say "don't continue" after
	// call waiting, it's possible that the evil call waiting stuff will
	// assign a loss to the loser, but the winner won't get the win because
	// the completeEnough stuff won't do it.  This is probably the correct
	// behavior, though it does illustrate the asymmetry inevitable in a
	// system that only examines one side at a time, as well as the number
	// of multi-syllable words I can use in a row.)
	// 
	ce_result = kNoError;
	if ((have_valid != kNoError) && (gameErrorResult != NULL) &&
		!(state->account->boxAccount.lastMatchup.wasSpecific & kLastChallengeMask))
	{
		Err result;

		result = Server_CompleteEnough(state, gameErrorResult);
		if (result == kEnoughCompletedLocalWinner && have_valid == kFucked) {
			// The game failed and he was winning.  Check for exceptional
			// conditions.
			//
			if ((gameErrorResult->gameError != kRebootDuringGameErr /*-13*/) &&
				(have_valid != kCallWaitingFucker) &&
				(have_valid != kCallWaitingHoser))
			{
				// Override kFucked (which means "generic game failure")
				// with the completeEnough result so we deduct credits
				// appropriately and assign the win later on.
				//
				// The setting of ce_result probably has no effect, since
				// we won't end up in a "fucker mail" routine.  Do we want
				// to set it?
				//
				ce_result = have_valid = result;
			} else {
				PLogmsg(LOGP_DBUG,
					"Ignoring EnoughCompletedLocalWinner due to reset or CW\n");
			}
		} else if (result == kEnoughCompletedRemoteWinner) {
			// Hang on to this so we can pass it to "fucker mail" routines.
			// This has no other effect.
			//
			ce_result = result;
		}

		// print something nice in the log
		//
		{
			WinAnalysis winAnal;

			Server_AnalyzeWin(gameErrorResult, &winAnal);

			Logmsg("COMPL: %.4s-0x%.8lx : %5d to %5d, err=%4d, result=",
				(char *)&state->platformID, gameErrorResult->gameID,
				winAnal.pointsFor, winAnal.pointsAgainst,
				gameErrorResult->gameError);

			switch (result) {
			case kNotEnoughCompletedTie:
				Logmsg("kNotEnoughCompletedTie");
				break;
			case kEnoughCompletedTie:
				Logmsg("kEnoughCompletedTie");
				break;
			case kEnoughCompletedLocalWinner:
				Logmsg("kEnoughCompletedLocalWinner");
				break;
			case kEnoughCompletedRemoteWinner:
				Logmsg("kEnoughCompletedRemoteWinner");
				break;
			default:
				PLogmsg(LOGP_FLAW, "(completeEnough??? - %d)", result);
				break;
			}

			if (result == kEnoughCompletedLocalWinner &&
				have_valid != kEnoughCompletedLocalWinner)
			{
				Logmsg(" [not used]\n");
			}
			Logmsg("\n");
		}
	}

	/* count successfully completed challenges for promos */
	if (have_valid == kNoError &&
	    state->account->userAccount.billingType == CAT_ACCT_BILL_PROMO)
	{
	    Server_CountCompletedChallenges(state);
	    Server_ResetXBNFreebieCount(state);
	}


#ifdef DEDUCT_NOW
+	// We give them back their previous credit if certain criteria are met.
+	//
+	//	- last connection was an auto-match request or a specific-match
+	//	  request (i.e. not a mail-only or hosed connection)
+	//	- they don't post valid game results [this should actually be
+	//	  determined by the game patch... if we're in the 4th quarter
+	//	  of JAMS they shouldn't get their credit back]
+	//
+	if (have_valid != kNoError) {
+		//
+		// There was a problem.  Decide if we want to give them a refund.
+		//
+		// First, the generic reasons for denial:
+		//
+		//	- they're still in a wait queue
+		//	- they did an evil reset while playing
+		//	- they did an evil call waiting
+		//	- they hit reset while waiting for someone to call
+		//
+		// Someday, add "played outside of prime-time hours."
+		//
+		if (Server_IsPlayerOnQueue(state)) {
+			Logmsg("GameRefund: nope, player is still on a queue\n");
+		} else if (have_valid == kResetDefinite) {
+			Logmsg("GameRefund: nope, player hit reset\n");
+//#ifdef CW_WORKS
+		} else if (Server_CheckCallWaiting(state, gameErrorResult) != kNoError)
+		{
+			Logmsg("GameRefund: nope, didn't continue after call waiting\n");
+//#endif
+#ifdef WAIT_RESET_WORKS
+		// Disabled 94/12/11.  Too many complaints about things locking up,
+		// having to hit reset, and then getting nailed.  At the very least
+		// we need to look for kPeerConnectFailed, and not dock credits if
+		// we see it... box can still be registered after a peer con failure.
+		//
+		} else if (state->boxOSState.lastBoxState & kListeningForPeerConnection)
+		{
+			// This is risky with the "play with yourself" mode.
+			Logmsg("GameRefund: nope, player reset while waiting\n");
+#endif
+		} else {
+			//
+			// Now we have to handle things in different ways, depending
+			// on what kind of connection they did.  Remember that, if we got
+			// this far, they must not have valid game results (because
+			// of the initial check on have_valid).
+			//
+			// If they came in for an auto-match, deny a refund if:
+			//
+			//	- they post valid game results
+			//
+			// If they came in for a specific-match, deny a refund if:
+			//
+			//	- they post valid game results
+			//
+			// (Hey, those are now the same.  Well, whatever.)
+			//
+			// If they came in for a mail-only connect, always deny.
+			//
+			// If they came in for a hosed auto or specific match, deny.
+			// This happens if you're using the wrong cart or (I think)
+			// come in during restricted hours.
+			//
+			switch (state->account->userAccount.typeLastConnect) {
+			case kConnTypeAutoMatch:
+				if (gameResult == NULL && gameErrorResult == NULL) {
+					Logmsg("GameRefund: yup, refund after expired(?) waiting for auto\n");
+				} else {
+					Logmsg("GameRefund: yup, refund after failed automatch\n");
+				}
+				Server_RefundCredit(state);
+				break;
+			case kConnTypeSpecificMatch:
+				if (gameResult == NULL && gameErrorResult == NULL) {
+					Logmsg("GameRefund: yup, refund after expired(?) waiting for specific\n");
+				} else {
+					Logmsg("GameRefund: yup, refund after failed specific\n");
+				}
+				Server_RefundCredit(state);
+				break;
+
+			case kConnTypeHosedAutoMatch:
+				Logmsg("GameRefund: nope, was a hosed auto-match\n");
+				break;
+			case kConnTypeHosedSpecificMatch:
+				Logmsg("GameRefund: nope, was a hosed specific-match\n");
+				break;
+			case kConnTypeMailOnly:
+				Logmsg("GameRefund: nope, mail-only connect\n");
+				break;
+			default:
+				Logmsg("GameRefund: how'd I get here (%d)?  Give it to him.\n",
+					state->account->userAccount.typeLastConnect);
+				Server_RefundCredit(state);
+				break;
+			}
+		}
+	} else {
+		Logmsg("GameRefund: nope, successful game\n");
+	}
+
#else	/*DEDUCT_NOW*/

	// We take away one credit unless certain criteria are met:
	//
	//	- last connection was an auto-match request or a specific-match
	//	  request (i.e. not a mail-only or hosed connection)
	//	- they don't post valid game results [this should actually be
	//	  determined by the game patch... if we're in the 4th quarter
	//	  of JAMS they shouldn't get their credit back]
	//
	if (have_valid != kNoError) {
		//
		// There was a problem.  Decide if we want to deduct a credit.
		//
		// First, the generic reasons for deduction:
		//
		//	- they're still in a wait queue
		//	- they did an evil reset while playing
		//	- they did an evil call waiting
		//	- they hit reset while waiting for someone to call
		//
		// Someday, add "played outside of prime-time hours."
		//
		if (Server_IsPlayerOnQueue(state)) {
			Logmsg("CreditDeduct: yup, player is still on a queue\n");
			Server_DeductCredit(state);
			state->creditChangeFlags |= kCreditChange_Deduct_OnQueue;
		} else if (have_valid == kResetDefinite) {
			Logmsg("CreditDeduct: yup, player hit reset\n");
			Server_DeductCredit(state);
			state->creditChangeFlags |= kCreditChange_Deduct_EvilReset;
		} else if ( have_valid == kCallWaitingFucker ||
					have_valid == kCallWaitingHoser)
		{
			Logmsg("CreditDeduct: yup, didn't continue after call waiting\n");
			Server_DeductCredit(state);
			state->creditChangeFlags |= kCreditChange_Deduct_EvilCW;
		} else if (have_valid == kCordPullFucker) {
			Logmsg("CreditDeduct: yup, player pulled the cord\n");
			Server_DeductCredit(state);
			state->creditChangeFlags |= kCreditChange_Deduct_CordPull;
		} else if ( have_valid == kEnoughCompletedTie ||
					have_valid == kEnoughCompletedLocalWinner ||
					have_valid == kEnoughCompletedRemoteWinner)
		{
			Logmsg("CreditDeduct: yup, game was complete enough\n");
			Server_DeductCredit(state);
			state->creditChangeFlags |= kCreditChange_Deduct_CompleteEnough;
		} else if
			( (state->boxOSState.lastBoxState & kListeningForPeerConnection) &&
			 !(state->boxOSState.lastBoxState & kPeerConnectFailed) &&
			 !(state->boxOSState.lastBoxState & kPlayingSinglePlayerGame) &&
			  (gameErrorResult == NULL))
		{
			// They hit reset or powered off while waiting for a peer
			// connect.  Three possibilities I'm aware of:
			//	- they got bored and hit reset [fucker]
			//	- they were in single-play mode and got bored [fucker]
			//	- they were in single-play mode and it locked up [!fucker]
			//	- something funky happened with the peer connect, and they
			//	  only got called twice, so the box didn't un-register
			//	  itself after the failure and they just dialed back in
			//	  while still pseudo-registered [!fucker]
			//
			// For now, don't yell at them if there was a failed peer connect,
			// if they posted game error results, or they were playing in
			// single-player mode.
			//
			// 950406: does kPeerConnectFailed *always* come up along with
			// kListeningForPeerConnection?!?
			//
			Logmsg("CreditDeduct: yup, player reset while waiting\n");
			Server_DeductCredit(state);
			state->creditChangeFlags |= kCreditChange_Deduct_WaitReset;

			//sprintf(msgbuf,
			//	"You hit reset or turned off your Sega while waiting for an opponent.  You have been charged the credit your opponent would have spent for a successful match.");
			sprintf(msgbuf,
				gettext("You hit reset or turned off your Sega while waiting for an opponent.  Please don't do this or we may have to penalize you a credit."));

			// Penalizing them an *additional* credit is done below, since
			// it's a penalty and not just a normal deduction.
		} else {
			//
			// Now we have to handle things in different ways, depending
			// on what kind of connection they did.  Remember that, if we got
			// this far, they must not have valid game results (because
			// of the initial check on have_valid).
			//
			// If they came in for an auto-match, deny a refund if:
			//
			//	- they post valid game results
			//
			// If they came in for a specific-match, deny a refund if:
			//
			//	- they post valid game results
			//
			// (Hey, those are now the same.  Well, whatever.)
			//
			// If they came in for a mail-only connect, always deny.
			//
			// If they came in for a hosed auto or specific match, deny.
			// This happens if you're using the wrong cart or (I think)
			// come in during restricted hours.
			//
			switch (state->account->userAccount.typeLastConnect) {
			case kConnTypeAutoMatch:
				Server_PrintNoCreditDeduct(state, gameResult, gameErrorResult,
					"automatch");
				break;
			case kConnTypeSpecificMatch:
				Server_PrintNoCreditDeduct(state, gameResult, gameErrorResult,
					"specific");
				break;

			case kConnTypeHosedAutoMatch:
				Logmsg("CreditDeduct: yup, hosed auto-match\n");
				Server_DeductCredit(state);
				state->creditChangeFlags |= kCreditChange_Deduct_HosedAuto;
				break;
			case kConnTypeHosedSpecificMatch:
				Logmsg("CreditDeduct: yup, hosed specific-match\n");
				Server_DeductCredit(state);
				state->creditChangeFlags |= kCreditChange_Deduct_HosedSpecific;
				break;
			case kConnTypeMailOnly:
                //
                // If gConfig.debitMailConnectNow is set, then we debited the previous
                // mail-only connection on the last connect.  So we don't do it again.
                //
                if (!gConfig.deductMailConnectNow) {
                    Server_DeductCredit(state);
                    state->creditChangeFlags |= kCreditChange_Deduct_MailOnly;
                    Logmsg("CreditDeduct: yup, mail-only connect\n");
                } else
                    Logmsg("CreditDeduct: nope, last connect was a mail-only connect\n");
                break;
			case kConnTypeNever:
				// This got swapped with kConnTypeMailOnly, so it will
				// fire often for the first few days.  950130
				//
				Logmsg("CreditDeduct: nope, first time ever connected\n");
				break;
			default:
				PLogmsg(LOGP_FLAW,
					"CreditDeduct: how'd I get here (%d)?  No deduction.\n",
					state->account->userAccount.typeLastConnect);
				break;
			}
		}
	} else {
		Logmsg("CreditDeduct: yup, successful game (%.4s-0x%.8lx)\n",
			(char *)&state->platformID, gameResult->gameID);
		Server_DeductCredit(state);
		state->creditChangeFlags |= kCreditChange_Deduct_SuccessfulGame;
	}
#endif


	// If we deducted a credit because they hit reset while waiting for
	// an opponent, we may also want to penalize them an additional credit
	// (i.e. the one that we have to refund to their opponent).
	//
	// The current thinking is that we should ALWAYS penalize the credit
	// to be consistent.  I'm of a mind to only penalize them if somebody
	// else was matched to them and got hosed, but I'm currently outvoted...
	//
	if (state->creditChangeFlags & kCreditChange_Deduct_WaitReset) {
		// dialog was already sent above, I guess.  May want to move it
		// down here.
		//
		// 950406: don't penalize an extra credit.
		//
		//Server_DeductCredit(state);
		//state->creditChangeFlags |= kCreditChange_Penalize_WaitReset;
		Logmsg("(Not currently penalizing additional wait-reset credit.\n");
	}

	// If we don't have valid game results, there's nothing else to do.
	// Usually.
	//
	if (have_valid != kNoError) {
		// If he was a fucker, we need to keep going for a little while, so
		// that the reset stuff gets updated in the correct PlayerAccount.
		// It's possible that one player is a total hoser while one guy is
		// clean, so we don't want to put it in the box account.
		//
		switch (have_valid) {
		case kFucked:
		case kCallWaitingHoser:
			goto done;		// all done with it

		case kResetMaybe:
		case kResetDefinite:
		case kCallWaitingFucker:
		case kCordPullFucker:
		case kEnoughCompletedLocalWinner:
			break;			// further processing needed

		case kNotEnoughCompletedTie:
		case kEnoughCompletedTie:
		case kEnoughCompletedRemoteWinner:
			PLogmsg(LOGP_FLAW,
				"ERROR: unexpected have_valid value %d; bailing\n", have_valid);
			goto done;		// bug

		default:
			PLogmsg(LOGP_FLAW,
				"ERROR: invalid have_valid value %d; bailing\n", have_valid);
			goto done;		// bug
		}
	}


	// Make sure we update the right player!
	//
	if (account->boxAccount.lastMatchup.player == account->playerAccount.player)
	{
		PLogmsg(LOGP_PROGRESS, "Updating rankingInfo for current player\n");
		//Logmsg("DEBUG val1=%d, val2=%d\n",
		//	account->boxAccount.lastMatchup.player,
		//	account->playerAccount.player);
		updateAccount = account;
	} else {
		userIdentification tmpUserID;

		PLogmsg(LOGP_PROGRESS,
			"Updating rankingInfo for DIFFERENT player (%d)\n",
			account->boxAccount.lastMatchup.player);
		tmpUserID.box.box = account->boxAccount.box.box;
		tmpUserID.box.region = account->boxAccount.box.region;
		tmpUserID.userID = account->boxAccount.lastMatchup.player;
		tmpUserID.userName[0] = '\0';
		if ((updateAccount = WrapperDB_GetAccount(&tmpUserID)) == NULL) {
			FPLogmsg(LOG_RATING, LOGP_FLAW,
				"ERROR: couldn't update rank for player %d on (%ld,%ld)[%ld]\n",
				account->boxAccount.lastMatchup.player,
				account->boxAccount.box.box,
				account->boxAccount.box.region,
				(long)account->playerAccount.player);
			err = kFucked;
			goto done;	// bug
		}
	}

	// Figure out what the gameID is.  We're not guaranteed to have
	// valid gameResults at this point, since we could be fucker-hunting.
	//
	if (gameResult != NULL)
		gameID = gameResult->gameID;
	else if (gameErrorResult != NULL)
		gameID = gameErrorResult->gameID;
	else {
		Logmsg("GLITCH: No gameRes, no gameErrorRes, how'd we get here?\n");
		WrapperDB_UpdateAccount(updateAccount);
		DataBaseUtil_FreeAccount(updateAccount);
		goto done; // bug
	}

	// Find the appropriate RankingInfo structure to mess with.
	//
	myRankInfo = Server_FindRankingInfo(state, updateAccount, gameID);

	if (myRankInfo == NULL) {
		if (updateAccount != account) {
			WrapperDB_UpdateAccount(updateAccount);
			DataBaseUtil_FreeAccount(updateAccount);
		}
		goto done; // bug
	}

	// If I don't have any ranking info, give me some.
	//
	if (!myRankInfo->gameID) {
		// my first time
		Logmsg("My first time playing this game.\n");
		InitializePlayerRankings(myRankInfo,
			Common_GetCanonicalGameID(state->platformID, gameID));
	}

	// After this, we're sure to change something.
	//
	updateAccount->playerModified |= kPA_ranking;
	myRankInfo->detail.rankingFlags |= kRankingDirty;

	// Reset daily stuff as needed, and get the array index for the
	// daily counters.
	//
	dailyPtr = Server_GetCurrentDailyPtr(state, myRankInfo);
	PLogmsg(LOGP_DBUG, "Updating daily[%d]\n", dailyPtr);


	// Update the address book.  If we failed do it now, otherwise do it
	// after we compute the win/loss stuff so we don't have to do that
	// twice.  (We're really just touching the dateLastPlayed.)
	//
	if (have_valid != kNoError) {
		Server_UpdateAddrBookAfterGame(updateAccount,
			&state->account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber,
			state->account->boxAccount.lastMatchup.prevOpponent.oppPlayer,
			0, 0,
			state->account->boxAccount.lastMatchup.when);
	}


	// If he hit reset or call-waited in an evil manner, update it & bail.
	// Also catch the "completeEnough" stuff.
	//
	if (have_valid != kNoError) {
		switch (have_valid) {
		case kResetMaybe:
			// Specific matches don't matter.
			//
			if (!(state->account->boxAccount.lastMatchup.wasSpecific &
				kLastChallengeMask))
			{
				updateAccount->playerAccount.numIffyResets++;
				FLogmsg(LOG_RATING, "Iffy resets for 0x%.8lx now %ld\n",
					(gameErrorResult == NULL) ? 0 : gameErrorResult->gameID,
					updateAccount->playerAccount.numIffyResets);
			}
			updateAccount->playerModified |= kPA_numResets;
			goto done;

		case kResetDefinite:
			// If the last match was a specific match, then we don't care if
			// he hit reset or not.  Send mail anyway though.
			//
			// If it was an auto-match, send nasty mail, penalize the fucker,
			// and recredit the other guy.
			//
			Server_SendResetFuckerMail(state, updateAccount, ce_result);
			if (!(state->account->boxAccount.lastMatchup.wasSpecific &
				kLastChallengeMask))
			{
				Server_SendFuckerResults(state, updateAccount, ce_result);
				updateAccount->playerAccount.numEvilResets++;
				myRankInfo->detail.dailyEvilResets[dailyPtr]++;
				FLogmsg(LOG_RATING, "Evil resets for 0x%.8lx now %ld\n",
					(gameErrorResult == NULL) ? 0 : gameErrorResult->gameID,
					updateAccount->playerAccount.numEvilResets);
				Server_DeductCredit(state);
				state->creditChangeFlags |= kCreditChange_Penalize_EvilReset;
				Server_RefundCreditOther(state,
					&account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber);
#ifdef TED_TOURNEY
				// Disqualify from tourney since he hit reset.
				// Calling Server_InvalidTourneyResults after this won't matter.
				Server_TourneyEvilReset(state);
#endif //TED_TOURNEY
				//TourneyLite
				// TODO:
				//    Turn this on before the tourney.
				// Server_TourneyEvilReset(state);
			}
			updateAccount->playerModified |= kPA_numResets;
			goto done;

		case kCordPullFucker:
			// Just like resets:
			//
			// If the last match was a specific match, then we don't care if
			// he hit reset or not.  Send mail anyway though.
			//
			// If it was an auto-match, send nasty mail, penalize the fucker,
			// and recredit the other guy.
			//
			Server_SendCordPullFuckerMail(state, updateAccount, ce_result);
			if (!(state->account->boxAccount.lastMatchup.wasSpecific &
				kLastChallengeMask))
			{
				Server_SendFuckerResults(state, updateAccount, ce_result);

				//updateAccount->playerAccount.numEvilResets++;
				//myRankInfo->detail.dailyEvilResets[dailyPtr]++;
				//FLogmsg(LOG_RATING, "Evil resets for 0x%.8lx now %ld\n",
				//	(gameErrorResult == NULL) ? 0 : gameErrorResult->gameID,
				//	updateAccount->playerAccount.numEvilResets);
				//Server_DeductCredit(state);
				//state->creditChangeFlags |= kCreditChange_Penalize_EvilReset;
				//Server_RefundCreditOther(state,
				//	&account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber);
			}
			goto done;

		case kCallWaitingFucker:
			// Nail this fucker.  The other guy didn't have to pay for the
			// aborted game, so there's no need to recredit him.  Take no
			// action if it was a specific-match.
			//
			// (We do the FuckerResults down in CWFuckerMail, because we
			// need to know if he was losing or not...)
			//
			Server_SendCWFuckerMail(state, updateAccount, ce_result);
			goto done;

		case kEnoughCompletedLocalWinner:
			// I won, mostly.  Need to convert the game error result into
			// a winning successful game result.
			//
			gameResult = Server_ForgeSuccessfulGame(state, gameErrorResult, 1);
			if (gameResult == NULL)
				goto done;		// yikes
			Server_NotifyCompleted(state, state->account);
			have_valid = kNoError;
			break;		// continue as if it were a successful game

		default:
			PLogmsg(LOGP_FLAW,
				"How the hell did we get here (%d)?  Reset sw.\n", have_valid);
			goto done;
		}
	}


	//
	// At this point, we know we have valid game results (have_valid ==
	// kNoError).
	//
	// Do the dirty work.
	//
	Server_UpdateRankingInfo(updateAccount, gameResult, gameErrorResult,
		myRankInfo, dailyPtr, state->validFlags & kServerValidFlag_WinsLosses);

	// If we receieved win/loss info from the box then update the 
	// address book info from that rather than from the game result info
	// in the above function. Currently, only snes sends this up.
	//
	if (state->validFlags & kServerValidFlag_WinsLosses)
	{
		Server_UpdateAddrBookAfterGame(account, 
			&account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber,
			account->boxAccount.lastMatchup.prevOpponent.oppPlayer,
			state->matchWins, state->matchLosses,
			account->boxAccount.lastMatchup.when);
	}


#ifdef TED_TOURNEY
	//
	// If this was a tournament game, update tourney results for player.
	// Calling Server_InvalidTourneyResults after this won't matter.
	//
	Server_TourneyRankings(state, gameResult, gameErrorResult);
#endif //TED_TOURNEY
	// Even for non-challenge, we will have updated secret ranking stuff.
	// (or will we? currently don't)
	//
	// If we were updating a different account on this box, update it and
	// free it immediately.
	//
	if (updateAccount != account) {
		WrapperDB_UpdateAccount(updateAccount);
		DataBaseUtil_FreeAccount(updateAccount);
	}
done:
#ifdef TED_TOURNEY
	Server_InvalidTourneyResults(state);
#endif //TED_TOURNEY

	PLogmsg(LOGP_PROGRESS, "Server_ExamineGameResults done\n");
	return err;
}


//
// Print the reason why we aren't deducting a credit.
//
// DO NOT change these messages without good reason.  They are currently
// used in the ASCII-log-based stat generation.
//
PRIVATE void
Server_PrintNoCreditDeduct(ServerState *state, NewGameResult *gameResult,
	NewGameResult *gameErrorResult, char *type)
{
	if (gameResult == NULL && gameErrorResult == NULL) {
		Logmsg("CreditDeduct: nope, expired(?) waiting for %s\n", type);

	} else {
		if ((gameErrorResult != NULL) && gameErrorResult->gameID) {
			// Look for non-game errors that are being blamed on the game.
			// I've entered these as numbers since that's the way the
			// reports come out.
			//
			switch (gameErrorResult->gameError) {
			case -413:		// kConnectBusy
			case -415:		// kNoAnswer
			case -416:		// kNoDialtone
			case -429:		// kHandshakeErr
			case -432:		// kCallWaitingTimeoutErr (CW, didn't continue)
			case -434:		// kCallWaitingContinuedTimeoutErr (CW, didn't get called back)
				Logmsg("CreditDeduct: nope, failed %s (misc) (%.4s-0x%.8lx)\n",
					type, (char *)&state->platformID,gameErrorResult->gameID);
				break;
			default:
				// This is iffy... chances are gameErrorResults are the
				// result of something outside the control of the game
				// patch, especially if the error result is positive.
				//
				Logmsg("CreditDeduct: nope, failed %s (game) (%.4s-0x%.8lx)\n",
					type, (char *)&state->platformID,gameErrorResult->gameID);
				break;
			}

		} else if ((gameResult != NULL) && gameResult->gameID) {
			// These are almost certainly game-related.
			//
			Logmsg("CreditDeduct: nope, failed %s (game) (%.4s-0x%.8lx)\n",
				type, (char *)&state->platformID, gameResult->gameID);
		} else
			Logmsg("CreditDeduct: nope, failed %s (peer)\n", type);
	}
}


//
// Fill out the fields in a WinAnalysis based on the game results.
//
// This was inspired by the addition of the "forfeit bit" to the game
// scores, with the threat of future bits being grabbed for other things.
// Easiest to do all the comparisons in one place.
//
int
Server_AnalyzeWin(const NewGameResult *gameResult, WinAnalysis *winAnal)
{
	extern ServerState *boxState;	// Sloppy, sloppy, but what the hell!
	const GameInfo *gameInfo;
	Boolean hosedPoints = false;

	memset(winAnal, 0, sizeof(WinAnalysis));

	winAnal->pointsFor =
		(gameResult->localPlayer1Result & kGameNonScoreMask) +
		(gameResult->localPlayer2Result & kGameNonScoreMask);
	winAnal->pointsAgainst =
		(gameResult->remotePlayer1Result & kGameNonScoreMask) +
		(gameResult->remotePlayer2Result & kGameNonScoreMask);

	// Sanity check for ridiculous points for/against being sent up.
	// In this case we just ignore this part of the game results.
	//
	if (gameResult->gameID) {
		gameInfo = Common_GameInfoForGame(boxState->platformID,
			gameResult->gameID);
		if (gameInfo == NULL) {
			PLogmsg(LOGP_FLAW, 
				"Can't check point validity, game doesn't exist.\n");
			hosedPoints = true;
		} else if (gameInfo->gameInfoFlags & kGIFlagResultsArePoints) {
			if (winAnal->pointsFor > kMaxPointsMagic || 
				winAnal->pointsAgainst > kMaxPointsMagic)
			{
				hosedPoints = true;
			}
		} else if (gameInfo->gameInfoFlags & kGIFlagResultsAreMatches) {
			if (winAnal->pointsFor > kMaxMatchMagic ||
				winAnal->pointsAgainst > kMaxMatchMagic)
			{
				hosedPoints = true;
			}
		}

		if (hosedPoints) {
			PLogmsg(LOGP_NOTICE,
				"HOSED_POINTS for %.4s-0x%.8lx (scores %lu to %lu)\n",
				(char *)&boxState->platformID, gameResult->gameID,
				winAnal->pointsFor, winAnal->pointsAgainst);
			winAnal->pointsFor = 0;
			winAnal->pointsAgainst = 0;
			return(0);
		}
	}

	winAnal->winByPoints = (winAnal->pointsFor > winAnal->pointsAgainst) ?
		1 : (winAnal->pointsFor < winAnal->pointsAgainst) ? -1 : 0;
	
	if (gameResult->localPlayer1Result & kGameOpponentForfeit) {
		// He forfeit, I win.
		//
		winAnal->forfeit = -1;
		winAnal->win = 1;
	} else if (gameResult->remotePlayer1Result & kGameOpponentForfeit) {
		// I forfeit, he wins.
		//
		winAnal->forfeit = 1;
		winAnal->win = -1;
	} else {
		// Nobody forfeit, win is by points.
		//
		winAnal->forfeit = 0;
		winAnal->win = winAnal->winByPoints;
	}

	if ((gameResult->localPlayer1Result & kGameOpponentForfeit) &&
		(gameResult->remotePlayer1Result & kGameOpponentForfeit))
	{
		FPLogmsg(LOG_GAMERESULT, LOGP_NOTICE,
			"GLITCH: box posted 2-way forfeit, ignoring\n");
		winAnal->forfeit = 0;
		winAnal->win = winAnal->winByPoints;
	}

	FPLogmsg(LOG_GAMERESULT, LOGP_DETAIL,
		"WinAnalysis (%lu): %lu-%lu winByPoints=%d forfeit=%d win=%d\n",
		Server_GetMatchCookie(boxState),	// ick... but much easier
		winAnal->pointsFor, winAnal->pointsAgainst,
		winAnal->winByPoints, winAnal->forfeit, winAnal->win);

	return (0);
}


//
// This should only get called with valid gameResults.
//
// (Originally this was going to get called in the event of an evil reset
// or CW.  Turns out it makes more sense to just put it all in
// Server_SendFuckerResults.)
//
PRIVATE Err
Server_UpdateRankingInfo(Account *account, NewGameResult *gameResult,
	NewGameResult *gameErrorResult, RankingInfo *myRankInfo, int dailyPtr,
	long updateAddr)
{
	extern ServerState *boxState;	// yuck
	RankingInfo oppRankInfo;
	WinAnalysis winAnal;
	long matchValue, nextLevel;
	int wasSpecific = 0;
	long p1wins=0, p2wins=0;
	long platformID;
	long myOldRating, oppOldRating;

	// This is one of the few places where we pull the platformID out of
	// the account instead of using what the box passed up.  Want to be
	// sure we recover gracefully if it's hosed.
	//
	platformID = account->boxAccount.platformID;
#ifdef TESTING_GAME_RESULTS
	if (!gConfig.isProduction) {
		platformID = kPlatformGenesis;		// useful on funky servers
		PLogmsg(LOGP_NOTICE, "NOTE: forcing platformID to 'sega'\n");
	}
#endif

	if (platformID != kPlatformGenesis && platformID != kPlatformSNES && platformID != kPlatformSJNES) {
		// This is a TEMPORARY measure to ensure we don't hose anybody
		// while all this platform stuff is still new.
		//
		PLogmsg(LOGP_FLAW, "*******************************************\n");
		PLogmsg(LOGP_FLAW, "***                                     ***\n");
		PLogmsg(LOGP_FLAW, "***               Whoops.               ***\n");
		PLogmsg(LOGP_FLAW, "***                %.4s                 ***\n",
			(char *)&platformID);
		PLogmsg(LOGP_FLAW, "***                                     ***\n");
		PLogmsg(LOGP_FLAW, "*******************************************\n");

		// Well, that ought to get their attention.  Force it to a rational
		// value.
		//
		platformID = kPlatformGenesis;
	}

	// After a successful match, copy the last matched opponent out of
	// lastMatchup and into the list of previous opponents.
	//
	account->playerAccount.prevOpponent[account->playerAccount.nextPrevOpponent] =
		account->boxAccount.lastMatchup.prevOpponent;
	Logmsg("Set prevOpp[%d] for plyr %d to (%ld,%ld) at %ld\n",
		account->playerAccount.nextPrevOpponent,
		account->boxAccount.lastMatchup.player,
		account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber.box,
		account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber.region,
		account->boxAccount.lastMatchup.prevOpponent.when);
	if (++account->playerAccount.nextPrevOpponent >= kMaxPreviousOpponent)
		account->playerAccount.nextPrevOpponent = 0;
	account->playerModified |= kPA_prevOpponent;

	Server_AnalyzeWin(gameResult, &winAnal);
	FLogmsg(LOG_RATING, "UpdateRanking for '%s' (%s)  (%ld,%ld)[%ld]\n",
		account->playerAccount.userName,
		account->boxAccount.gamePhone.phoneNumber,
		account->boxAccount.box.box,
		account->boxAccount.box.region,
		(long)account->playerAccount.player);
	FLogmsg(LOG_RATING,
		//"gameID=%.4s-0x%.8lx  ptsFor=%lu (%lu,%lu)%s  ptsAgnst=%lu (%lu,%lu)%s  time=%ld %c\n",
		"gameID=%.4s-0x%.8lx  ptsFor=%lu%s  ptsAgnst=%lu%s  time=%ld %c\n",
		(char *)&platformID, gameResult->gameID,
		winAnal.pointsFor,
		//gameResult->localPlayer1Result, gameResult->localPlayer2Result,
		(winAnal.forfeit == 1) ? "!!" : "",
		winAnal.pointsAgainst,
		//gameResult->remotePlayer1Result, gameResult->remotePlayer2Result,
		(winAnal.forfeit == -1) ? "!!" : "",
		gameResult->playTime,
		(account->boxAccount.lastMatchup.wasSpecific & kLastChallengeMask) ?
			'C' : ' ' /*,
		Server_BoxWasMaster(state) ? 'M':'S'*/);

	// If I don't have any ranking info, give me some.
	//
	if (!myRankInfo->gameID) {
		// my first time
		Logmsg("My first time playing this game.\n");
		InitializePlayerRankings(myRankInfo,
			Common_GetCanonicalGameID(account->boxAccount.platformID,
				gameResult->gameID));
	}

	// oppRankInfo is a *copy* of the RankingInfo from lastMatchup.
	//
	oppRankInfo = account->boxAccount.lastMatchup.oppRankingInfo;

	if (!account->boxAccount.lastMatchup.prevOpponent.when) {
		// can't happen?
		Logmsg("lastMatch.when == 0\n");
		memset(&oppRankInfo, 0, sizeof(RankingInfo));
		InitializePlayerRankings(&oppRankInfo,
			Common_GetCanonicalGameID(account->boxAccount.platformID,
				gameResult->gameID));
	}

	// set houskeeping stuff
	//
	myRankInfo->timeOfLastPlay = account->boxAccount.lastMatchup.when;

	// Don't give real points if it was a challenge match.
	//
	if (account->boxAccount.lastMatchup.wasSpecific & kLastChallengeMask) {
		wasSpecific++;
		FLogmsg(LOG_RATING,
			"Last match was a specific challenge [0x%.2x], ratings not updated.\n",
				(unsigned char)account->boxAccount.lastMatchup.wasSpecific);
	}

	// Assign the appropriate number of XBAND points for a victory.  No
	// points are assigned for a tie.
	//
	nextLevel = GetNextLevelPoints(myRankInfo);
	FLogmsg(LOG_RATING,
		"Currently at rating=%ld%s, XBAND points=%lu, level=%d, next at %d\n",
		myRankInfo->rating,
		(myRankInfo->detail.rankingFlags & kRankingIsProvisional) ? "*" : "",
		myRankInfo->totalXBandPoints, GetCurrentLevel(myRankInfo), nextLevel);
	FLogmsg(LOG_RATING,
		"Opponent '%s' (%ld,%ld)[%ld] was at rating=%ld%s, xpoints=%lu\n",
		account->boxAccount.lastMatchup.oppUserName,
		account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber.box,
		account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber.region,
		account->boxAccount.lastMatchup.prevOpponent.oppPlayer,
		oppRankInfo.rating, 
		(oppRankInfo.detail.rankingFlags & kRankingIsProvisional) ? "*" : "",
		oppRankInfo.totalXBandPoints);

	if (!wasSpecific) {
		// keep these just for fun (and for secret rankings)
		myRankInfo->pointsFor += winAnal.pointsFor;
		myRankInfo->pointsAgainst += winAnal.pointsAgainst;
		myRankInfo->detail.dailyTotalGames[dailyPtr]++;

		if (winAnal.win > 0) {
			// award XBAND points
			matchValue = GetMatchPointValueForP1(myRankInfo, &oppRankInfo);
			myRankInfo->totalXBandPoints += matchValue;
			if (myRankInfo->totalXBandPoints > kMaxXBandPoints)
				myRankInfo->totalXBandPoints = kMaxXBandPoints;
			myRankInfo->detail.dailyWins[dailyPtr]++;
			FLogmsg(LOG_RATING,
				"Awarding %d XBAND points, totalXBandPoints now %lu%s (daily wins=%d)\n",
				matchValue, myRankInfo->totalXBandPoints,
				(myRankInfo->totalXBandPoints >=nextLevel) ? " (promoted!)":"",
				myRankInfo->detail.dailyWins[dailyPtr]);
		}

		if (Server_GetNumWins(platformID, gameResult, &p1wins, &p2wins) !=
			kNoError)
		{
			PLogmsg(LOGP_FLAW,
				"GetNumWins failed (platformID bad?), using points\n");
			if (winAnal.win > 0)
				p1wins = 2, p2wins = 0;
			else if (winAnal.win < 0)
				p1wins = 0, p2wins = 2;
			else
				p1wins = p2wins = 1;
		}
		//Logmsg("NumWins: p1=%d, p2=%d\n", p1wins, p2wins);
	}

	// Unlike most things, this gets updated whether it was a specific-match
	// game or not.  Too bad it doesn't work: if they play more than one
	// game, the server doesn't get any result back, so we can't update
	// our copy correctly.
	//
	// 950825: actually, this should be fixed now (updateAddr is set by
	// caller if it did stuff). Hmm, does this handle ties correctly?  ++ATM
	//
	if (!updateAddr) {
		Server_UpdateAddrBookAfterGame(account, 
			&account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber,
			account->boxAccount.lastMatchup.prevOpponent.oppPlayer,
			(winAnal.win > 0) ? 1 : 0,
			(winAnal.win < 0) ? 1 : 0,
			account->boxAccount.lastMatchup.when);
	}

	// Call CalculateContinuousRankings to update our:
	//	numOpponentsPlayed
	//	totalWinsTimesTwo
	//	totalLossesTimesTwo
	//
	// We have already updated:
	//	totalXBandPoints
	//	dailyWins
	//
	// Note that this call may change oppRankInfo as well, though any
	// changes there should be ignored.  (That's why we need a copy, in
	// case somebody reorders the routines and wants to put valid data
	// in there before we get called.)
	//
	// Don't want to touch any of those values if the last game was a
	// player list match.
	//
	if (!wasSpecific) {
		myOldRating = myRankInfo->rating;
		oppOldRating = oppRankInfo.rating;

		CalculateContinuousRankings(myRankInfo, &oppRankInfo, p1wins, p2wins,
			winAnal.win != winAnal.winByPoints);

		FLogmsg(LOG_RATING,
			"Now rating=%ld, wins=%.1f-%.1f, points=%ld-%ld, XBAND points=%lu, level=%ld\n",
			myRankInfo->rating,
			(float)myRankInfo->totalWinsTimesTwo/2.0,
			(float)myRankInfo->totalLossesTimesTwo/2.0,
			myRankInfo->pointsFor, myRankInfo->pointsAgainst,
			myRankInfo->totalXBandPoints,
			GetCurrentLevel(myRankInfo));

		// Generate a single line to make Kon's world a happier place.
		//
		PLogmsg(LOGP_STATISTICS,
			"RANK (%lu): %.4s-0x%.8lx (%ld,%ld)[%d] vs (%ld,%ld)[%d] : %s%s (%ld-%ld) : %ld->%ld %c %.1f-%.1f / %ld->%ld %c %.1f-%.1f\n",
			Server_GetMatchCookie(boxState),	// fix this boxState crap
			(char *)&boxState->platformID, gameResult->gameID,
			account->boxAccount.box.box,
			account->boxAccount.box.region,
			account->playerAccount.player,
			account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber.box,
			account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber.region,
			account->boxAccount.lastMatchup.prevOpponent.oppPlayer,
			(winAnal.win > 0) ? "won!" : (winAnal.win < 0) ? "lost" : "tied",
			(winAnal.win != winAnal.winByPoints) ? "-forfeit" : "",
			winAnal.pointsFor, winAnal.pointsAgainst,
			myOldRating, myRankInfo->rating,
			(myRankInfo->detail.rankingFlags & kRankingIsProvisional) ? 'P':'-',
			(float)myRankInfo->totalWinsTimesTwo/2.0,
			(float)myRankInfo->totalLossesTimesTwo/2.0,
			oppOldRating, oppRankInfo.rating,
			(oppRankInfo.detail.rankingFlags & kRankingIsProvisional) ? 'P':'-',
			(float)oppRankInfo.totalWinsTimesTwo/2.0,
			(float)oppRankInfo.totalLossesTimesTwo/2.0);
	}


	return(kNoError);
}


//
// Return a pointer to account's RankingInfo struct for this game.  If the
// game can't be found (because it's his first time playing it), create
// a new RankingInfo struct.
//
// Can be called for an account other than the current one, but should
// NOT be called if the other account is on a different platform.  This
// could be an issue for cross-platform games.  Mumble.
//
// Returns NULL if the game shouldn't be scored (e.g. because it's just
// a test patch).
//
RankingInfo *
Server_FindRankingInfo(ServerState *state, Account *account, long gameID)
{
	int idx;

	// Temporary hack to see if it works
	//
	// If you add something, make sure there's enough room in the array
	// in ServerDataBase.h, then update numRankingInfo initialization
	// in UserAccount.c.  Yuck.  Shouldn't have to worry about database
	// save stuff unless you exceed kMaxRankingInfo.
	//
	if (state->platformID == kPlatformGenesis) {
		switch (Common_GetCanonicalGameID(state->platformID, gameID)) {
		case kMortalKombatGameID:	// MK
			idx = 0;
			break;
		case 0x39677bdb:			// NBA JAM
			idx = 1;
			break;
		case 0xa61b53f8:			// NHL '94
			idx = 2;
			break;
		case 0x8f6b9f70:			// NHL '95
			idx = 3;
			break;
		case 0xc4cddf0c:			// MK II
			idx = 4;
			break;
		case 0x31ed8123:			// Madden '95
			idx = 5;
			break;
		case 0x3fed23f2:			// Road Rash 3
			idx = 6;
			break;
		case 0x00192660:			// NBA Live '95
			idx = 7;
			break;
		case 0x4d1c4e1d:			// Super Street Fighter II
			idx = 8;
			break;
		case 0x8d68bdfb:			// Weapon Lord (beta)
		case 0x4a017a94:			// Weapon Lord (two versions)
			idx = 9;
			break;
		case 0x433e2840:			// FIFA Soccer '95
			idx = 10;
			break;
		case 0x3bb5e378:			// Primal Rage (beta)
		case 0xc6906e52:			// Primal Rage
			idx = 11;
			break;
		case 0x067a218f:			// Ballz
			idx = 12;
			break;
		case 0x4d402d90:			// Madden '96
			idx = 13;
			break;
		case 0xafc0ce39:			// NHL '96
			idx = 14;
			break;
		case 0x6d14eb41:			// Mortal Kombat 3
			idx = 15;
			break;
		case 666:					// simulator
		case 0x51a5e383:			// Rampart
		case 0x6edb32d0:			// Micro Machines
		default:
			FLogmsg(LOG_RATING,
				"Not storing game results for %.4s-0x%.8lx\n",
				(char *)&state->platformID, gameID);
			return (NULL);
		}

	} else if (state->platformID == kPlatformSNES) {
		switch (Common_GetCanonicalGameID(state->platformID, gameID)) {
		case 0xb11f972e:			// MK II (two versions)
			idx = 0;
			break;
		case 0x55ce0daf:			// Zelda (test only)
			idx = 1;
			break;
		case 0x127e8181:			// NHL '95
			idx = 2;
			break;
		case 0x1969d2af:			// NBA JAM TE
			idx = 3;
			break;
		case 0xef120a61:			// SSF2
			idx = 4;
			break;
		case 0xb8958396:			// Madden '95
			idx = 5;
			break;
		case 0x3d1c44eb:			// Super Mario Kart
			idx = 6;
			break;
		case 0x972404cc:			// FIFA Int'l Soccer
			idx = 7;
			break;
		case 0x0572a585:			// Weapon Lord (two versions)
			idx = 8;
			break;
		case 0x19a2c936:			// NBA Live '95
			idx = 9;
			break;
		case 0xa8973c8c:			// Ken Griffey Baseball (19 & 19A)
			idx = 10;
			break;
		case 0x2d17c045:			// Killer Instinct
			idx = 11;
			break;
		case 0x085d3cdb:			// Madden '96
			idx = 12;
			break;
		case 0x25f372a5:			// NHL '96
			idx = 13;
			break;
		case 0x94b564b5:			// Doom
			idx = 14;
			break;
 		case 0x05484971:			// MK 3
			idx = 15;
			break;
 		case 0x83e627ef:			// Kirby's Avalanche
			idx = 16;
			break;
		default:
			FLogmsg(LOG_RATING,
				"Not storing game results for %.4s-0x%.8lx\n",
				(char *)&state->platformID, gameID);
			return (NULL);
		}

	} else if (state->platformID == kPlatformSJNES) {
		switch (Common_GetCanonicalGameID(state->platformID, gameID)) {
		case 0xb11f972e:			// MK II (two versions)
			idx = 0;
			break;
		case 0x55ce0daf:			// Zelda (test only)
			idx = 1;
			break;
		case 0x0a2c238a:			// Super Mario Kart
			idx = 2;
			break;
		case 0xd8222103:			// SSF2
			idx = 3;
			break;
 		case 0x8442c640:			// Puyopuyo
			idx = 4;
			break;
 		case 0x925b41fc:			// Super Fire ProWrestling X
			idx = 5;
			break;
		default:
			FLogmsg(LOG_RATING,
				"Not storing game results for %.4s-0x%.8lx\n",
				(char *)&state->platformID, gameID);
			return (NULL);
		}

	} else {
		// It's the Mystery Platform!
		//
		FLogmsg(LOG_RATING,
			"Not storing game results for %.4s-0x%.8lx\n",
			(char *)&state->platformID, gameID);
		return (NULL);
	}

	if (idx >= kMaxRankingInfo) {
		FPLogmsg(LOG_RATING, LOGP_FLAW,
			"idx (%d) > kMaxRankingInfo for %.4s-0x%.8lx, not updated\n",
			idx, (char *)&state->platformID, gameID);
		return (NULL);
	}

	// Lame way of allocating new spots.  Update to Oracle someday.
	//
	if (idx >= account->playerAccount.numRankingInfo)
		account->playerAccount.numRankingInfo = idx + 1;

	return (&(account->playerAccount.rankingInfo[idx]));
}

//
// Return the index into the "daily" stuff for the given RankingInfo.
//
// Starts with "dailyToday".  If the corresponding dailyDate field is
// zero, use that.  Otherwise, see if it matches today's date.  If so,
// return it.  If not, advance dailyToday to the next field, set dailyDate
// equal to the current time, and zero out all the daily fields.
//
// BRAIN DAMAGE: we're currently adding it to *today's* wins, even if the
// game was played a week ago.  This may actually be desirable behavior;
// otherwise wins that are too old for this week's tally would never be
// factored into any top 10 calculation ever.
//
int
Server_GetCurrentDailyPtr(ServerState *state, RankingInfo *myRankInfo)
{
	int idx = myRankInfo->detail.dailyToday;
	time_t now = time(0);

	if (Server_IsSameDay(myRankInfo->detail.dailyDate[idx], now)) {
		// we're currently updating this one, so do nothing exciting
		return (idx);
	}
	if (myRankInfo->detail.dailyDate[idx]) {
		// move on to next one
		idx = (idx + 1) % kRankNumDays;
	}

	// Either dailyDate was zero and we're going to overwrite it, or
	// we've moved on to the next slot.
	//
	myRankInfo->detail.dailyToday = idx;
	myRankInfo->detail.dailyDate[idx] = now;
	myRankInfo->detail.dailyWins[idx] = 0;
	myRankInfo->detail.dailyTotalGames[idx] = 0;
	myRankInfo->detail.dailyEvilResets[idx] = 0;
	myRankInfo->detail.dailyCordPulls[idx] = 0;

	return (idx);
}

//
// Returns magicCookie from last matchup (used for logging game results).  
// Uses info in oldMatchupRegurg if it is available.
//
long
Server_GetMatchCookie(const ServerState *state)
{
	// Regurgitated matchup info takes precedence over guesswork.
	//
	if ((state->oldMatchupRegurg != NULL) && 
		(state->oldMatchupRegurg->version == kMatchupRegurgVersion)) 
	{
		return (state->oldMatchupRegurg->magicCookie);
	}

#ifdef TESTING_GAME_RESULTS
	return(state->connid);
#else
	// If the above wasn't there this is probably 0, but what the hey!
	return (state->account->boxAccount.lastMatchup.magicCookie);
#endif
}

//
// Returns TRUE if the two dates fall on the same calendar day, FALSE if
// not.
//
// Someday this ought to take time zone into account.
//
PRIVATE int
Server_IsSameDay(time_t date1, time_t date2)
{
	struct tm tm1, tm2;

#define	HALF_DAY (12*60*60)
	/*
	 * We want a "day" to be a period from noon to noon,
	 * instead of midnite to midnite.
	 */
	date1 -= HALF_DAY;
	date2 -= HALF_DAY;
#undef	HALF_DAY

	tm1 = *localtime(&date1);
	tm2 = *localtime(&date2);

	if ((tm1.tm_mday == tm2.tm_mday) &&
		(tm1.tm_mon == tm2.tm_mon) &&
		(tm1.tm_year == tm2.tm_year))
	{
		return (1);
	}
	return (0);
}

//
// Determine if this box was the master or the slave on its last connect.
// 950213: use MatchupRegurg if it's available.
//
// The flag kluged onto lastMatchup.wasSpecific value is unreliable, because
// of the following scenario:
//
//	- play as master
//	- log in again with a specific match request against somebody not around
//	- do a voice call to the box
//
// The box will post a -415 error, but will claim to be the master, since
// nobody scribbled on lastMatchup.  So, if his slave enqueue time is more
// recent than his lastMatchup time, he must not have been matched up to
// anyone, and we conclude he was a slave.  Under no circumstances should
// this be considered foolproof.
//
// NOTE: If the connection is lost before the server update but after the box
// has been told to wait or dial, this result may be twisted.  (This is true
// for any number of things.)
//
// Returns "true" if the box was the master last time, "false" if not.
//
int
Server_BoxWasMaster(const ServerState *state)
{
	MatchupRegurg *regurg = state->oldMatchupRegurg;

	// Regurgitated matchup info takes precedence over guesswork.
	//
	if ((regurg != NULL) && (regurg->version == kMatchupRegurgVersion)) {
		PLogmsg(LOGP_DETAIL, "BoxWasMaster: using matchupRegurg (%d)\n",
			regurg->master);
		return (regurg->master);
	}

	// Try to figure it out.
	//
	if (state->account->boxAccount.lastSlaveInfo.slaveQueuedWhen >
		state->account->boxAccount.lastMatchup.when)
	{
		// Was a slave more recently than the last time somebody set his
		// lastMatchup field, so his last connect must've been as a slave
		// (or it died near the end, or he is getting matched now, or ...)
		//
		return (false);

	} else {
		// The lastMatchup field was modified more recently than (or at the
		// same time as) the last time his lastMatchup was updated, so
		// whatever is in lastMatchup is correct.
		//
		if (state->account->boxAccount.lastMatchup.wasSpecific & kLastMaster)
			return (true);
		else
			return (false);
	}
	/*NOTREACHED*/
}

//
// Check to see if we have something worth scoring.  Also tries to detect
// malicious resets.
//
// Returns kNoError if game should be scored, something else if not.
// Will return kFucked for most failures, but will return one of the reset
// error codes or the cord pull error code if a fucker was detected.
//
PRIVATE Err
Server_HaveValidGameResults(ServerState *state,
	const NewGameResult *gameResult, const NewGameResult *gameErrorResult)
{
	Account *account = state->account;
	Err err;
	long cookie;

	cookie = Server_GetMatchCookie(state);

	if (gameResult == NULL) {		// no gameResults
		FLogmsg(LOG_RATING,
			"No gameRes%s for '%s'; last known oppnt '%s' (%ld,%ld)[%ld]\n",
			(gameErrorResult == NULL) ? " or gameErrRes" : "",
			account->playerAccount.userName,
			account->boxAccount.lastMatchup.oppUserName,
			account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber.box,

			account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber.region,
			(long)account->boxAccount.lastMatchup.prevOpponent.oppPlayer);

		if (gameErrorResult != NULL) {
			err = Server_CheckForReset(state, gameResult, gameErrorResult);
			if (err != kNoError)
				return (err);
			err = Server_CheckForCordPull(state, gameResult, gameErrorResult);
			if (err != kNoError)
				return (err);
			// wasn't a special failure, but was a failure nonetheless
			return (kFucked);
		}
		return (kFucked);
	}

	// Ever been working late at night and wonder if anybody will ever
	// read your comments?
	//
	if (gameResult->gameError) {
		FLogmsg(LOG_RATING, "UpdateRanking for plyr %d (%s)  (%ld,%ld)[%ld]\n",
			account->boxAccount.lastMatchup.player,
			account->boxAccount.gamePhone.phoneNumber,
			account->boxAccount.box.box,
			account->boxAccount.box.region,
			(long)account->playerAccount.player);
		FLogmsg(LOG_RATING,
			"Game ended in error (%d/%d/%d), rankings not updated\n",
			gameResult->gameError, gameResult->errorWhere,
			gameResult->connectPhase);
		FLogmsg(LOG_RATING,
			"Opponent was '%s' (%ld,%ld)[%ld]\n",
			account->boxAccount.lastMatchup.oppUserName,
			account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber.box,
			account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber.region,
			account->boxAccount.lastMatchup.prevOpponent.oppPlayer);

		err = Server_CheckForReset(state, gameResult, gameErrorResult);
		if (err != kNoError)
			return (err);
		else
			return (kFucked);
	}
	if (gameErrorResult != NULL && !gameResult->gameError) {
		// This apparently means that the first game succeeded, but something
		// happened during an encore game.
		//
		FLogmsg(LOG_GAMERESULT,
			"%ld-NOTE: found gameErrorResult, but gameResult->gameError==0\n",
			cookie);
	}

	// Look for other circumstances, like single-quarter play.
	//
	if (Server_ShouldGameBeScored(state, gameResult) != kNoError)
	{
		return (kFucked);
	}

	return (kNoError);
}


//
// Dump the MatchupRegurg SendQ item, if any.
//
// Annoying brain damage: the "when" field is when the regurg struct was
// filled out, so it may be 1 second later than the time found in lastMatchup
// or lastSlaveInfo (more if the machine is reaalllly slow).
//
PRIVATE int
Server_DumpMatchupRegurg(ServerState *state)
{
	MatchupRegurg *regurg = state->oldMatchupRegurg;
	char timebuf[32];		// actually 26

	if (regurg == NULL) {
		PLogmsg(LOGP_DETAIL,
			"Server_DumpMatchupRegurg: oldMatchupRegurg was NULL\n");
		return (kNoError);
	}

	if (regurg->version != kMatchupRegurgVersion) {
		Logmsg("Server_DumpMatchupRegurg: got version %d, current is %d\n",
			regurg->version, Server_DumpMatchupRegurg);
		return (kFucked);
	}

	strcpy(timebuf, ctime(&regurg->when));
	FPLogmsg(LOG_GAMERESULT, LOGP_INFO,
		"%ld-Regurg: (%c) ID=%.4s-0x%.8lx ver=%ld  (%.24s)%s\n",
		regurg->magicCookie, regurg->master ? 'M' : 'S', 
		(char *)&state->platformID, regurg->gameID, regurg->gamePatchVer,
		timebuf, (regurg->flags & kRegurgFlagUsedXBN) ? " XBN" : "");

	return (kNoError);
}


#ifdef TESTING_GAME_RESULTS
typedef struct MKResults {
	unsigned short  frameDelay;
	unsigned short  totalVBLs;
	unsigned short  skippedVBLs;
	unsigned short  mkState;
	short           checkLineResult;
} MKResults;

//
// Creates one set of fake game results and/or game error results.  Values
// stuffed in are pointers to static structures.  The value of "set"
// determines which set of results are used.
//
PRIVATE int
CreateFakeGameResults(ServerState *state, NewGameResult **gameResult,
	NewGameResult **gameErrorResult, int set)
{
	static NewGameResult result, errorResult;
	MKResults *mkresults;

	PLogmsg(LOGP_FLAW, "USING FAKE GAME RESULTS (set %d)\n", set);
	if (gConfig.isProduction) {
		PLogmsg(LOGP_FLAW, "Are you insane?\n");
		return (-1);
	}

	// Initialize.
	//
	*gameResult = &result;
	*gameErrorResult = &errorResult;
	memset(&result, 0, sizeof(NewGameResult));
	memset(&errorResult, 0, sizeof(NewGameResult));

/*
	// Use these to test the "no matchup occurred" mess.
	//
	state->account->boxAccount.lastSlaveInfo.slaveQueuedWhen = 3;
	state->account->boxAccount.lastMatchup.when = 6;
	state->account->boxAccount.lastSlaveInfo.slaveExpireWhen = 5;
	state->account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber.box = 1;
	state->account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber.region =
		state->account->boxAccount.box.region;
*/

	result.size = sizeof(NewGameResult);
	errorResult.size = sizeof(NewGameResult);
	/* */
	//result.gameID = 666;
	//errorResult.gameID = 666;
	//state->gameIDData.gameID = 666;
	/*sega SSF2*/
	//result.gameID = 0x4d1c4e1d;
	//errorResult.gameID = 0x4d1c4e1d;
	//state->gameIDData.gameID = 0x4d1c4e1d;
	/*SNES SSF2*/
	result.gameID = 0xef120a61;
	errorResult.gameID = 0xef120a61;
	state->gameIDData.gameID = 0xef120a61;
	/* */
	//result.gameID = 0;			// failed in initial peer connect
	//errorResult.gameID = 0;
	/* */
	//result.gameID = 1234;
	//errorResult.gameID = 1234;
	//state->gameIDData.gameID = 1234;

	// foo
	//
	if (set < 6) {
		state->account->boxAccount.lastMatchup.wasSpecific = 0;
		state->account->userAccount.typeLastConnect = kConnTypeAutoMatch;
	} else {
		state->account->boxAccount.lastMatchup.wasSpecific = 0x03;
		state->account->userAccount.typeLastConnect = kConnTypeSpecificMatch;
		set -= 6;
	}

	// make me a master
	//
	state->account->boxAccount.lastMatchup.wasSpecific |= kLastMaster;

	// Well now, what shall we send.
	//
	switch (set) {
	case 0:		// player 1 won
	case 1:		// player 2 won
		// Successful game, no errors.
		//
		*gameErrorResult = NULL;
		result.playTime = 4;
		result.numLocalPlayers = 1;
		switch (set) {
		case 0:
			result.localPlayer1Result = 2;
			result.remotePlayer1Result = 1;
			break;
		case 1:
			result.localPlayer1Result = 1;
			result.remotePlayer1Result = 2;
			break;
		}
		//result.localPlayer1Result |= kGameOpponentForfeit;  // he forf, I win
		break;

//#define ERROR_DUJOUR	-432		// call waiting
//#define ERROR_DUJOUR	-434		// call waiting, no foul
//#define ERROR_DUJOUR	-12		// junk
#define ERROR_DUJOUR	-13		// reset

	case 2:		// player 1 winning
	case 3:		// player 2 winning
		// Game halted by player 1 being called (if err==-432) or player 1
		// hitting reset (if err==-13).  Case 3 is an evil reset.
		//
		*gameResult = NULL;
		errorResult.gameError = ERROR_DUJOUR;
		errorResult.errorWhere = kCallWaitingGRMod >> 16;
		errorResult.connectPhase = 4;
		errorResult.playTime = 2;
		errorResult.numLocalPlayers = 1;
		mkresults = (MKResults *)errorResult.gameReserved;
		mkresults->mkState = 8;
		switch (set) {
		case 2:
			errorResult.localPlayer1Result = 4;
			errorResult.remotePlayer1Result = 1;
			break;
		case 3:
			errorResult.localPlayer1Result = 1;
			errorResult.remotePlayer1Result = 4;
			break;
		}
		break;

	case 4:		// player 1 winning
	case 5:		// player 2 winning
		// Game halted by player 2 being called (if err==-432).
		//
		*gameResult = NULL;
		errorResult.gameError = ERROR_DUJOUR;
		errorResult.errorWhere = 3;		// fucking constants not in Errors.h
		errorResult.connectPhase = 4;
		errorResult.playTime = 2;
		errorResult.numLocalPlayers = 1;
		switch (set) {
		case 4:
			errorResult.localPlayer1Result = 2;
			errorResult.remotePlayer1Result = 1;
			break;
		case 5:
			errorResult.localPlayer1Result = 1;
			errorResult.remotePlayer1Result = 2;
			break;
		}
		break;

	default:
		Logmsg("Bad value for FakeGameResult set (%d)\n", set);
		return (-1);
	}

	if (*gameResult != NULL) {
		state->validFlags |= kServerValidFlag_GameResults;
		state->gameResult = (GameResult *) *gameResult;
	}
	if (*gameErrorResult != NULL) {
		state->validFlags |= kServerValidFlag_GameErrorResults;
		memcpy(&state->gameErrorResult, *gameErrorResult, sizeof(NewGameResult));
	}

	return (0);
}

PRIVATE int
TestWorthString(void)
{
	RankingInfo masterRankingInfo, slaveRankingInfo;
	unsigned long masterPoints, slavePoints;

	masterRankingInfo.totalXBandPoints = 1450082;
	masterRankingInfo.rating = 3110;
	slaveRankingInfo.totalXBandPoints = 200;
	slaveRankingInfo.rating = 2943;

	masterPoints = GetMatchPointValueForP1(&masterRankingInfo,
		&slaveRankingInfo);
	slavePoints = GetMatchPointValueForP1(&slaveRankingInfo,
		&masterRankingInfo);
	Logmsg("TEST: My xpoints=%lu rating=%d, his xpoints=%d rating=%d, M:%d/S:%d\n",
		masterRankingInfo.totalXBandPoints,
		masterRankingInfo.rating,
		slaveRankingInfo.totalXBandPoints,
		slaveRankingInfo.rating,
		masterPoints, slavePoints);

	return (0);
}
#endif /*TESTING_GAME_RESULTS*/

