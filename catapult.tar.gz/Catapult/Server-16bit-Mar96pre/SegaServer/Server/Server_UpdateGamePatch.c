/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_UpdateGamePatch.c,v 1.13 1995/07/31 21:26:56 fadden Exp $
 *
 * $Log: Server_UpdateGamePatch.c,v $
 * Revision 1.13  1995/07/31  21:26:56  fadden
 * Only trap the "no patch on box, no patch on server" case here if we know
 * about the game.  If we don't, let StartGamePlay handle it.
 *
 * Revision 1.12  1995/07/10  21:11:49  rich
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.11  1995/06/19  20:45:01  fadden
 * Added some notes to a comment.
 *
 * Revision 1.10  1995/06/02  15:56:04  fadden
 * Don't say it's "temporarily" unavailable; the lack of availability may
 * not be temporary.
 *
 * Revision 1.9  1995/06/01  16:35:10  fadden
 * If we get a new game patch, copy the new version into
 * state->gameIDData.version.
 *
 * Revision 1.8  1995/06/01  15:07:46  fadden
 * If neither the server nor the box has a game patch, disallow game play.
 *
 * Revision 1.7  1995/05/26  23:47:18  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_UpdateGamePatch.c

	Contains:	xxx put contents here xxx

	Written by:	David Jevans


	Change History (most recent first):

		<19>	12/13/94	ATM		Don't set disallowGameConnect; let StartGamePlay deal with
									unsupported games.
		<18>	 9/27/94	ATM		Fixed a printf (%.8lx vs %.8l).
		<17>	 9/19/94	ATM		PLogmsg stuff.
		<16>	 9/16/94	ATM		Improved signal to noise ratio of log messages.
		<15>	 9/15/94	DJ		oops. forgot to include Challnge.h
		<14>	 9/15/94	DJ		don't send game patch on mail-only connect
		<13>	  9/9/94	DJ		added alarm to drop the connection during download of game patch
									(commented out for production, of course)
		<12>	 8/23/94	DJ		added state->disallowGameConnect
		<11>	 8/16/94	ATM		Allow boxes with huge patch numbers.
		<10>	 8/13/94	DJ		ForceEnd
		 <9>	 8/13/94	ATM		Removed reference to gLogFile.
		 <8>	 8/11/94	ATM		Try that again.
		 <7>	 8/11/94	ATM		Converted to Logmsg.
		 <6>	 8/10/94	DJ		added more printfs so you can tell which version of patch we
									downloaded, if any
		 <5>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		 <4>	  7/1/94	DJ		making server handle errors in Comm layer
		 <3>	 6/11/94	DJ		major making real
		 <2>	 5/31/94	DJ		renamed DisposePreformedMsg.. to ReleasePreformedMsg...
		 <1>	 5/27/94	DJ		first checked in

	To Do:
*/

#include "ServerCore.h"
#include "Server.h"
#include "ServerState.h"
#include "ServerDataBase.h"

#include "Challnge.h"

#include <stdio.h>

#include <stdio.h>
#include <sys/types.h>
#include <sys/file.h>
#include <sys/ioctl.h>
#include <signal.h>


//
// Send a game patch down to the box if it doesn't have one or a newer one
// is available.
//
// While games are identified by platformID and gameID, the game patches
// may be different for each ROM revision.  So the call to GetGamePatch has
// to be based on boxType instead.
//
int
Server_UpdateGamePatch(ServerState *state)
{
	long				boxGameVersion, dbGameVersion;
	PreformedMessage	*mesg;
	OSErr				err;

	PLogmsg(LOGP_PROGRESS, "Server_UpdateGamePatch\n");

	if (state->challengeData.userID.box.box == kDownloadOnlyMailSerialNumber) {
		Logmsg("UpdateGamePatch: no patch downloaded for mail only connection\n");
		// Don't set this flag, or Server_StartGamePlay won't print the
		// last Game Results.
		//
		//		state->disallowGameConnect = true;
		return(kServerFuncOK);
	}

	boxGameVersion = state->gameIDData.version;		// shortcut
	mesg = DataBase_GetGamePatch(state->boxOSState.boxType,
		state->gameIDData.gameID, boxGameVersion, &dbGameVersion);

	if (mesg == NULL) {
		// Server didn't send us a game patch.  Report why.
		//
		if (dbGameVersion == -1) {
			Logmsg("UpdateGamePatch: unsupported game %.4s-0x%.8lx\n",
				(char *)&state->platformID, state->gameIDData.gameID);
			if (boxGameVersion != -1) {
				PLogmsg(LOGP_NOTICE,
					"UpdateGamePatch: WARNING: box has v%ld for UNKNOWN game %.4s-0x%.8lx\n",
					state->gameIDData.version, (char *)&state->platformID,
					state->gameIDData.gameID);
			} else {
				// We don't have a game patch, the box doesn't have a
				// game patch, do NOT let them play a game!  This can happen
				// either because this server doesn't have the appropriate
				// game patch or because we've never heard of this game.
				// Send an appropriate dialog.
				//
				// Let Server_StartGamePlay handle this case if we've never
				// heard of the game before; we don't do the appropriate
				// credit deduction stuff here. ++ATM 950731
				//
				if (Common_GameInfoForGame(state->platformID,
					state->gameIDData.gameID) != NULL)
				{
					PLogmsg(LOGP_NOTICE,
						"GLITCH: no game patch on server or in box, disallow play\n");
					Server_SendDialog(state,
						gettext("Sorry, this game is not available. Please try another."),	/*DIALOG*/
						true);
					state->disallowGameConnect = true;
				}
			}
		} else if (dbGameVersion == boxGameVersion) {
			Logmsg("UpdateGamePatch: box has current v%ld for %.4s-0x%.8lx\n",
				dbGameVersion, (char *)&state->platformID,
				state->gameIDData.gameID);
		} else if (dbGameVersion < boxGameVersion) {
			PLogmsg(LOGP_NOTICE,
				"UpdateGamePatch: WARNING: box has game patch version > server!\n");
			PLogmsg(LOGP_NOTICE,
				"                 (%.4s-0x%.8lx v%ld)\n",
				(char *)&state->platformID, state->gameIDData.gameID,
				boxGameVersion);
		} else {
			PLogmsg(LOGP_NOTICE,
				"UpdateGamePatch: GLITCH: server didn't send more recent version.\n");
			PLogmsg(LOGP_NOTICE,
				"                 %.4s-0x%.8lx box v%ld server v%ld\n",
				(char *)&state->platformID, state->gameIDData.gameID,
				boxGameVersion, dbGameVersion);
		}

		return (kNoError);

	} else {
		// Server sent a game patch.  Ship it.
		//
		if (boxGameVersion == -1)
			Logmsg("UpdateGamePatch: box has no patch for this game\n");
		if (dbGameVersion <= 0)
			PLogmsg(LOGP_FLAW, "GLITCH: server didn't set dbGameVersion (%d)\n",
				dbGameVersion);

		Logmsg("UpdateGamePatch: Sending %.4s-0x%.8lx v%ld\n",
			(char *)&state->platformID, state->gameIDData.gameID,
			dbGameVersion);

		err = Server_SendPreformedMessage(state, mesg);
#if	THIS_ACTUALLY_DID_ANYTHING
		DataBase_ReleasePreformedMessage(mesg);		// should be a Common thing
#endif

		// Change the box's uploaded game version to match the DB game
		// version.  This is done so that the "regurg" stuff has the right
		// version number in it, and so StartGamePlay can pass the correct
		// patch version in.
		//
		// Kind of risky if the box somehow rejects the game patch (which
		// should be impossible though).  This should be verified with a
		// call that gets the current game patch version from the box
		// (probably at the start of StartGamePlay, which has to synchronize
		// things anyway).
		//
		state->gameIDData.version = dbGameVersion;

		PLogmsg(LOGP_PROGRESS, "Server_UpdateGamePatch done\n");
		return(err);
	}
	/*NOTREACHED*/
}





#ifdef OLD_STUFF
+void alarm_handler(void);
+
+int Server_UpdateGamePatch(ServerState *state)
+{
+long 				latestGameVersion;
+PreformedMessage	*mesg;
+OSErr				err;
+
+	PLogmsg(LOGP_PROGRESS, "Server_UpdateGamePatch\n");
+
+	if(state->challengeData.userID.box.box == kDownloadOnlyMailSerialNumber)
+	{
+		Logmsg("UpdateGamePatch: no patch downloaded for mail only connection\n");
+		//
+		// Don't set this flag, or Server_StartGamePlay won't print the
+		// last Game Results.
+		//
+		//		state->disallowGameConnect = true;
+		return(kServerFuncOK);
+	}
+
+//
+// This is to test the network when we drop a connection during download of a game patch.
+//
+//		signal(SIGALRM, alarm_handler);
+//		alarm(10);
+//		PLogmsg(LOGP_NOTICE, "Alarm set to %d seconds\n", 15);
+
+
+	if(state->gameIDData.version == -1){
+		Logmsg("UpdateGamePatch: box has no patch for this game\n");
+		//
+		// Box doesn't have *any* version of this game's patch.
+		//
+		if ((latestGameVersion =
+			DataBase_GetLatestGameVersion(state->platformID,
+				state->gameIDData.gameID)) == -1)
+		{
+			Logmsg("UpdateGamePatch: unsupported game ID 0x%.8lx\n",
+				state->gameIDData.gameID);
+			if(Server_SendUnsupportedGame(state) != kServerFuncOK)
+				return(kServerFuncAbort);
+			
+			// let StartGamePlay do this
+			//state->disallowGameConnect = true;
+			return(kServerFuncOK);
+		}
+
+		mesg = DataBase_GetGamePatch(state->platformID, state->gameIDData.gameID);
+		if(!mesg){
+			Logmsg("UpdateGamePatch: game ID 0x%.8lx has no patch\n",
+				state->gameIDData.gameID);
+			return(kServerFuncOK);
+		}
+
+		Logmsg("UpdateGamePatch: sending version %ld for game 0x%.8lx\n",
+			latestGameVersion, state->gameIDData.gameID);
+		err = Server_SendPreformedMessage(state, mesg);
+		DataBase_ReleasePreformedMessage(mesg);
+		PLogmsg(LOGP_PROGRESS, "Server_UpdateGamePatch done\n");
+		return(err);
+	}
+
+	latestGameVersion = DataBase_GetLatestGameVersion(state->platformID,
+		state->gameIDData.gameID);
+	if(latestGameVersion < 0){
+		Logmsg("UpdateGamePatch: unsupported game ID 0x%.8lx\n",
+			state->gameIDData.gameID);
+		if(Server_SendUnsupportedGame(state) != kServerFuncOK)
+				return(kServerFuncAbort);
+		
+		PLogmsg(LOGP_NOTICE,
+			"WARNING: UpdateGamePatch: box has version %ld for UNKNOWN game 0x%.8lx\n",
+			state->gameIDData.version, state->gameIDData.gameID);
+
+		// let StartGamePlay do this
+		//state->disallowGameConnect = true;
+		return(kServerFuncOK);
+	}
+
+	if(latestGameVersion > state->gameIDData.version){
+		//
+		// Box needs latest version of this game's patch.
+		//
+		mesg = DataBase_GetGamePatch(state->platformID, state->gameIDData.gameID);
+		if(!mesg){
+			Logmsg("Server_UpdateGamePatch: game ID = %ld has a NULL patch\n", state->gameIDData.gameID);
+			return(kServerFuncOK);
+		}
+		Logmsg("UpdateGamePatch: box has version %ld for game 0x%.8lx, sending version %ld\n",
+			state->gameIDData.version, state->gameIDData.gameID,
+			latestGameVersion);
+		err = Server_SendPreformedMessage(state, mesg);
+		DataBase_ReleasePreformedMessage(mesg);
+		PLogmsg(LOGP_PROGRESS, "Server_UpdateGamePatch done\n");
+		return(err);
+	}
+
+	if(state->gameIDData.version > latestGameVersion){
+		PLogmsg(LOGP_NOTICE, "WARNING: UpdateGamePatch: box has version %ld for game 0x%.8lx, current version is OLDER %ld\n",
+			state->gameIDData.version, state->gameIDData.gameID,
+			latestGameVersion);
+
+		// ==BRAIN DAMAGE==   should we try to notify the box that it is fucked?
+		// or should we go into a send stream that blows the boxes O/S away
+		// and resets it automagically?
+		//
+		
+		//return(kServerFuncAbort);
+		PLogmsg(LOGP_NOTICE,
+			"UpdateGamePatch: box had a patch version > mine (okay for now)\n");
+		return(kServerFuncOK);
+	}
+
+	Logmsg("UpdateGamePatch: box has current version %ld for 0x%.8lx\n",
+		latestGameVersion, state->gameIDData.gameID);
+
+	return(kServerFuncOK);	// box has current version of game patch.
+}
#endif /*OLD_STUFF*/

