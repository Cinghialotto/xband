/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Merchandising.c,v 1.11 1996/02/02 15:43:12 chs Exp $
 *
 * $Log: Server_Merchandising.c,v $
 * Revision 1.11  1996/02/02  15:43:12  chs
 * use gConfig.catapultTown everywhere.
 *
 * Revision 1.10  1996/01/25  17:51:49  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.9  1996/01/04  22:54:13  hufft
 * added pop mail
 *
 * Revision 1.8  1995/12/11  23:11:06  chs
 * Free the mail in Server_SendMailFromXBAND().
 *
 * Revision 1.7  1995/12/04  16:31:28  chs
 * Moved proto for Server_SendMailFromXBAND() to Server.h.
 *
 * Revision 1.6  1995/10/27  19:43:38  steveb
 * Just did some long needed housecleaning.  No new code.
 *
 * Revision 1.5  1995/10/16  14:54:36  chs
 * Text changes that didn't make it in for the last install.
 * also, set to.userName to make the maillog happy.
 *
 * Revision 1.4  1995/10/11  17:02:13  chs
 * Be much more forgiving with xband-store messages.
 * New text in the reply messages.
 * None of the forward-address-corrections-to-someone stuff anymore.
 *
 * Revision 1.3  1995/10/02  17:55:36  chs
 * Add player number to store-orders file format.
 *
 * Revision 1.2  1995/09/29  18:39:18  chs
 * Put the boxID in all the Logmsg()s.
 * Put the correct product string in the orders file.
 *
 * Revision 1.1  1995/09/27  16:00:19  chs
 * Created.
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <fcntl.h>


#include "Server.h"
#include "ServerDataBase.h"
#include "Common_ReadConf.h"
#include "Common_PlatformID.h"
#include "Common_Log.h"
#include "Common_Missing.h"

Boolean Server_IsStringInFile(char *str, char *filename);


/*XXX*/
void Server_FreeUCA(UCAInfo *uca);
void Server_FreeUCA(UCAInfo *uca) { /* Leak me, baby! */ } 



static char xbandstore[] = "XBAND-Store";

Boolean Server_IsStringInFile(char *str, char *filename)
{
    FILE *fp;
    Boolean rv = false;
    char buf[1024];
    int len;

    fp = fopen(filename, "r");
    if (fp == NULL) {
	PLogmsg(LOGP_NOTICE, "Couldn't open file %s\n", filename);
	return rv;
    }

    len = strlen(str);

    while(fgets(buf, sizeof(buf), fp) != NULL) {
	if (buf[0] == '#')
	    continue;
	if (strncasecmp(str, buf, len) == 0 && buf[len] == '\n') {
	    rv = true;
	    break;
	}
    }

    fclose(fp);
    return rv;
}



Err Server_SendMailFromXBAND(ServerState *state,
			     char *from, char *title, char *body, int serialNumber)
{
    static userIdentification catapult = { {0, -1}, 0, 0, kXBANDPlayerIcon};
    Err err;
    Mail *mail;

    strcpy(catapult.userTown, gConfig.catapultTown);

    mail = malloc(sizeof(Mail) + strlen(body));
    ASSERT(mail);

    mail->to.box = state->account->boxAccount.box;
    mail->to.userID = state->account->playerAccount.player;
	mail->serialNumber = serialNumber;
    strcpy(mail->to.userName, state->account->playerAccount.userName);
    mail->from = catapult;
    strcpy(mail->from.userName, from);
    mail->date = Server_GetSegaDate();

    strcpy(mail->title, title);
    strcpy(mail->message, body);

    err = WrapperDB_AddMailToIncoming(mail);
    PLogmsg(LOGP_PROGRESS, "STORE: box %d sendmail -> %d\n",
	   state->account->boxAccount.box.box,
	   err);
	free(mail);
    return err;
}
//
// Raw mail sends mail independently of the outgoing mail box,
// this can be used by the 800 connects, when the account doesn't exist.
//
Err	Server_SendMailRaw(ServerState *state, char *from, char *title, char *body, int serialNumber, int *sent)
{
	messOut		opCode;
	int			i;
	char		buf[sizeof(Mail) + 1024];
	Mail 		*m = (Mail*)&buf[0];
	short 		num;
	static userIdentification catapult = { {-1, 0}, 0, 0, kXBANDPlayerIcon};

    strcpy(catapult.userTown, gConfig.catapultTown);

	/*
     * Send down the mail if it's not on the box already.
     */
	if (serialNumber)
	{
	    for (i = 0; i < state->loginData.numMailsInBox; i++)
		{
			if(state->loginData.mailSerialNumbers[i] == serialNumber)
			{
				*sent = false;
				return(kNoError);
			}
		}
	}
	strcpy(m->message, body);
	m->date = Server_GetSegaDate();
	strcpy(m->title, title);
	m->to.box = state->loginData.userID.box;
	m->to.userID = state->loginData.userID.userID;
	m->from = catapult;
	strcpy(m->from.userName, from);
	m->serialNumber = serialNumber;

	opCode = msReceiveMail;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	num = 1;
	Server_TWriteDataSync(state->session, sizeof(short), (Ptr)&num);

	Server_SendMailBody(state, m);
	*sent = true;

    if (Server_SyncWithBox(state) != kServerFuncOK)
	{
	/* box is gone, we'll be SIGHUPing shortly, no doubt... */

		Logmsg("TERMS: SyncWithBox failed\n");
    }
	return(kNoError);
}


/*
 * Deal with mail messages to the sales address.
 */
void Server_HandleSalesMail(ServerState *state, Mail *mail)
{
    char buf[1024], re[1024];
    char *product;
    Err err;
    UCAInfo *uca;
    int fd, cclen;
    time_t t;
    FILE *fp;

    Logmsg("STORE: box %d mail title = %s, body = %s\n",
	   state->account->boxAccount.box.box,
	   mail->title, mail->message);

    if (strncasecmp(mail->title, "re: ", 4) == 0) {
	product = mail->title + 4;
	strcpy(re, mail->title);
    }
    else {
	product = mail->title;
	sprintf(re, "Re: %s", mail->title);
    }

    /*
     * Only credit-card customers are allowed to buy things at the Store.
     */
    if (state->account->userAccount.billingType != CAT_ACCT_BILL_VISA &&
	state->account->userAccount.billingType != CAT_ACCT_BILL_MCARD &&
	state->account->userAccount.billingType != CAT_ACCT_BILL_INTERNAL) {
	Server_SendMailFromXBAND(state, xbandstore, "Sorry",
				 "Sorry, only XBAND members who pay for their account with a credit card may make purchases at the XBAND Store.", 0);

	Logmsg("STORE: box %d wasn't a cc customer\n",
	       state->account->boxAccount.box.box);
	return;
    }

    /*
     * XXX check for out-of-stock flags crap.
     */
    if (state->account->boxAccount.platformID == kPlatformGenesis &&
	gConfig.sega_out_of_stock) {
	Server_SendMailFromXBAND(state, xbandstore, "Out of Stock",
				 "Sorry, we are currently out of keyboards for the Sega Genesis.  There will be a post in XBAND News when and if more become available.", 0);
	Logmsg("STORE: box %d got sega out-of-stock\n",
	       state->account->boxAccount.box.box);
	return;
    }
    if (state->account->boxAccount.platformID == kPlatformSNES &&
	gConfig.snes_out_of_stock) {
	Server_SendMailFromXBAND(state, xbandstore, "Out of Stock",
				 "Sorry, we are currently out of keyboards for the Super NES.  There will be a post in XBAND News when and if more become available.", 0);
	Logmsg("STORE: box %d got snes out-of-stock\n",
	       state->account->boxAccount.box.box);
	return;
    }

    /*
     * Check for a valid product name.
     */
    if (Server_IsStringInFile(product, gConfig.sales_products_file) == false) {
	sprintf(buf, "The product you specified, \"%s\", is not available.  Please make another selection.", product);
	Server_SendMailFromXBAND(state, xbandstore, "Product Unavailable", buf, 0);

	Logmsg("STORE: box %d gave bogus product name: %s\n",
	       state->account->boxAccount.box.box, product);
	return;
    }

    err = WrapperDB_FindUCAInfoByCSID(state->account->
				      userAccount.customerServiceID,
				      &uca);
    if (err) {
	uca = NULL;
	Logmsg("STORE: box %d finduca -> %d\n",
	       state->account->boxAccount.box.box, err);

      temp_trouble:
	Server_SendMailFromXBAND(state, xbandstore, "Temporary Problem",
				 "There is a temporary problem with the XBAND Store.  Please try again in a few minutes.", 0);
	goto out;
    }

    if (strstr(mail->message, uca->access_code) == NULL) {
	Server_SendMailFromXBAND(state, xbandstore,
				 "Problem with Access Code",
				 "The access code you provided does not match our records. In the title box enter the word Keyboard. In the message area enter only your access code and the last 4 digits of your credit card number.", 0);
	Logmsg("STORE: box %d gave wrong code\n",
	       state->account->boxAccount.box.box);
	goto out;
    }

    if (uca->cc_num == NULL || (cclen = strlen(uca->cc_num)) < 4) {
	Logmsg("STORE: box %d has weird cc number\n",
	       state->account->boxAccount.box.box);
	goto temp_trouble;
    }

    if (strstr(mail->message, uca->cc_num + cclen - 4) == NULL) {
	Server_SendMailFromXBAND(state, xbandstore,
				 "Problem with Credit Card",
				 "The 4 last digits of the credit card you provided do not match our records. In the title box enter the word Keyboard. In the message area enter only your access code and the last 4 digits of your credit card number.", 0);
	Logmsg("STORE: box %d gave wrong cc num\n",
	       state->account->boxAccount.box.box);
	goto out;
    }

    fd = open(gConfig.sales_output_file, O_WRONLY|O_APPEND|O_CREAT,
	      S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP|S_IROTH|S_IWOTH);
    if (fd == -1 || (fp = fdopen(fd, "a")) == NULL) {
	PLogmsg(LOGP_FLAW, "STORE: unable to open order file\n");
	goto temp_trouble;
    }

    Logmsg("STORE: box %d putting order in file\n",
	   state->account->boxAccount.box.box);

    t = time(NULL);
    if (fprintf(fp, "%s, 0, %ld, %ld, %d, %s",
		product,
		state->account->boxAccount.box.box,
		state->account->boxAccount.box.region,
		state->account->playerAccount.player,
		ctime(&t)) == EOF) {
	PLogmsg(LOGP_FLAW, "STORE: couldn't write to orders file\n");
	goto temp_trouble;
    }
    if (fclose(fp) != 0) {
	PLogmsg(LOGP_FLAW, "STORE: error closing orders file\n");
	goto temp_trouble;
    }

    /* success! yay! */
    Server_SendMailFromXBAND(state, xbandstore, "Thank You",
			     "Your XBAND keyboard order has been accepted.  We are currently verifying your credit card account.  A confirmation X-Mail will be sent within the next 2 days when your order ships.", 0);
    sprintf(buf, "Your order will be shipped to %s, %s, %s  %s.  If this is not your current address, please reply to this message giving your correct address within 24 hours.",
	    uca->address, uca->city, uca->state, uca->zip);
    Server_SendMailFromXBAND(state, "XBAND-Address", "Address info", buf, 0);

  out:
    if (uca)
	Server_FreeUCA(uca);
}
