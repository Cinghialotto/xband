/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_snes_GameSpecific.c,v 1.27 1995/12/20 19:09:04 ansell Exp $
 *
 * $Log: Server_snes_GameSpecific.c,v $
 * Revision 1.27  1995/12/20  19:09:04  ansell
 * Added dispatch entry for Kirby's Avalanche.
 *
 * Revision 1.26  1995/12/12  21:44:18  josh
 * Added one-sided win algorithm for SNES MK3 (standard best-of-5 cheeze)
 *
 * Revision 1.25  1995/11/16  17:12:07  ansell
 * Added jump table entry for "Mortal Kombat 3".
 *
 * Revision 1.24  1995/10/15  20:35:49  josh
 * Added Madden '96 and NHL '96 one-sided-win algorithms
 *
 * Revision 1.23  1995/10/09  15:15:34  josh
 * Added SNES WeaponLord one-sided win algorithm (best of 7)
 *
 * Revision 1.22  1995/10/03  17:07:11  ansell
 * Added new SNES game Doom.
 *
 * Revision 1.21  1995/09/27  00:56:52  ansell
 * Added jump table entry for NHL '96.
 *
 * Revision 1.20  1995/09/26  10:37:46  ansell
 * Added dispatcher entry for Madden '96.
 *
 * Revision 1.19  1995/09/16  17:14:24  fadden
 * Added SNES_KillerInstinct_Resolver and SNES_KGBaseball_Resolver.  Changed
 * Madden point spread from 17 to 10.
 *
 * Revision 1.18  1995/09/13  14:34:48  fadden
 * Added comment - now two versions of Weapon Lord.
 *
 * Revision 1.17  1995/09/13  14:25:00  ted
 * Fixed warnings.
 *
 * Revision 1.16  1995/09/10  22:34:55  fadden
 * Added CompleteEnough stuff.
 *
 * Revision 1.15  1995/08/27  18:53:34  fadden
 * Added snes Killer Instinct.
 *
 * Revision 1.14  1995/08/16  16:56:32  fadden
 * Added Ken Griffey Baseball.
 *
 * Revision 1.13  1995/08/06  18:40:48  fadden
 * Use GenericCheckReset for SNES MK2.
 *
 * Revision 1.12  1995/08/02  22:34:35  fadden
 * Activate reset check for snes-SSF2.
 *
 * Revision 1.11  1995/07/31  21:29:14  fadden
 * Added Weapon Lord and NBA Live '95.  Enabled reset detects for NHL '95
 * and Zelda.
 *
 * Revision 1.10  1995/07/12  18:17:33  fadden
 * Added Super Mario Kart and FIFA International Soccer.
 *
 * Revision 1.9  1995/05/26  23:47:33  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_snes_GameSpecific.c

	Contains:	Game-specific code for SNES ('snes').

	Written by:	Andy McFadden

*/


#include <sys/types.h>
#include <time.h>

#include "Server.h"
#include "Server_GameSpecific.h"
#include "Common.h"

#include "Errors.h"

//
// Local function.
//
PRIVATE Err SNES_MK2_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SNES_NBAJamTE_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SNES_SSF2_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SNES_NHL95_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SNES_Madden95_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SNES_Zelda_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SNES_KillerInstinct_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SNES_KGBaseball_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SNES_WeaponLord_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SNES_NHL96_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SNES_Madden96_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err	SNES_MK3_Resolver( NewGameResult *gameErrorResult );


//
// Known SNES games (see Common_GameInfo.c for definitive list):
//
//	0x00000000	(game patch not entered)
//	0x0000000?	(test patch, could be anything)
//	0x0000029a	Simulator
//	0x0572a585	Weapon Lord [rev 1]
//	0x0572dd87	Weapon Lord [rev 2] (aliased to 0x0572a585)
//	0x127e8181	NHL '95
//	0x25f372a5	NHL '96
//	0x1969d2af	NBA JAM TE
//	0x19a2c936	NBA Live '95
//	0x2d17c045	Killer Instinct
//	0x3d1c44eb	Super Mario Kart
//	0x55ce0daf	Zelda (maze game)
//	0x972404cc	FIFA Int'l Soccer
//	0xa8973c8c	Ken Griffey Baseball [19]
//	0xb11f972e	Mortal Kombat II [rev 1]
//	0xb8958396	Madden '95
//	0x085d3cdb	Madden '96
//	0xc0432172	Mortal Kombat II [rev 2] (aliased to 0xb11f972e)
//	0xdf5aa2e2	Ken Griffey Baseball [19A] (aliased to 0xa8973c8c)
//	0xef120a61	SSF2
//	0x94b564b5	Doom
//	0x05484971	Mortal Kombat 3
//	0x83e627ef	Kirby's Avalanche
//
static GameSpecificJumpTable gameSpecific[] = {
	{ 0x0000029a, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL },
	{ 0x127e8181, NULL, NULL, NULL,
		NULL, NULL, NULL, SNES_NHL95_Resolver },
	{ 0x1969d2af, NULL, NULL, NULL,
		NULL, NULL, NULL, SNES_NBAJamTE_Resolver },
	{ 0x3d1c44eb, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL },
	{ 0x55ce0daf, NULL, NULL, NULL,
		NULL, NULL, NULL, SNES_Zelda_Resolver },
	{ 0x972404cc, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL },
	{ 0xb11f972e, NULL, NULL, NULL /*MatchGetNumWins*/,
		NULL, NULL, NULL, SNES_MK2_Resolver },
	{ 0xb8958396, NULL, NULL, NULL,
		NULL, NULL, NULL, SNES_Madden95_Resolver },
	{ 0xef120a61, NULL, NULL, NULL /*MatchGetNumWins*/,
		NULL, NULL, NULL, SNES_SSF2_Resolver },
	{ 0x0572a585, NULL, NULL, NULL /*MatchGetNumWins*/,
		NULL, NULL, NULL, SNES_WeaponLord_Resolver },
	{ 0x19a2c936, NULL, NULL, NULL /*MatchGetNumWins*/,
		NULL, NULL, NULL, NULL },
	{ 0xa8973c8c, NULL, NULL, NULL,
		NULL, NULL, NULL, SNES_KGBaseball_Resolver },
	{ 0x2d17c045, NULL, NULL, NULL /*MatchGetNumWins*/,
		NULL, NULL, NULL, SNES_KillerInstinct_Resolver },
	{ 0x085d3cdb, NULL, NULL, NULL,
		NULL, NULL, NULL, SNES_Madden96_Resolver },
	{ 0x25f372a5, NULL, NULL, NULL,
		NULL, NULL, NULL, SNES_NHL96_Resolver },
	{ 0x94b564b5, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL },
	{ 0x05484971, NULL, NULL, NULL,
		NULL, NULL, NULL, SNES_MK3_Resolver },
	{ 0x83e627ef, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL },
};


//
// Look up a game.
//
// Returns a pointer to the appropriate gameSpecific entry via gsjtpp.
//
SEMI_PRIVATE int
Server_snes_LookupGameSpecific(const long gameID, GameSpecificJumpTable **gsjtpp)
{
	int i;

	*gsjtpp = NULL;
	for (i = 0; i < NELEM(gameSpecific); i++) {
		if (gameSpecific[i].gameID == gameID) {
			*gsjtpp = &gameSpecific[i];
			return (0);
		}
	}
	return (0);
}



// ===========================================================================
//		CompleteEnough stuff (from Josh)
// ===========================================================================

//
// These are all piled together, in no particular order.
//

typedef struct SNES_MK2_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} SNES_MK2_GameData;

PRIVATE Err
SNES_MK2_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
SNES_MK2_GameData *mk2Data = (SNES_MK2_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long wins;
unsigned long losses;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( mk2Data->dataVersion != kSNES_MK2_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif
	
	/* for now, we'll call any matches that are 2-0 a win. And we'll call */
	/* matches that are 2-2 and 2-1 a tie. Others are not far enough along. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	wins = winAnal.pointsFor;
	losses = winAnal.pointsAgainst;

	if ( ( wins > 3 ) || ( losses > 3 ) || ( ( wins == 3 ) && ( losses == 3 ) ) )
	{
		// wacky win/loss thing. Bail!
		return (kNotEnoughCompletedTie);
	}
	
	// 3-X is a win! (Probably shouldn't be gameErrors in this case, but who knows?
	if ( wins == 3 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 3 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 2-0 is a win!
	if ( wins == 2 && losses == 0 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 2 && wins == 0 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 2-2, 2-1 is a tie. (Note that 2-0 cases are handled above)
	if ( wins == 2 || losses == 2 )
	{
		return (kEnoughCompletedTie);
	}
	
	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct SNES_NBAJamTE_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} SNES_NBAJamTE_GameData;

PRIVATE Err
SNES_NBAJamTE_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
SNES_NBAJamTE_GameData *nbaJamTEData = (SNES_NBAJamTE_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long player1Points;
unsigned long player2Points;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( nbaJamTEData->dataVersion != kSNES_NBAJamTE_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif

	/* for now, we'll call an 8 point lead a victory. Otherwise it's a tie if
there */
	/* are more than 80 points scored. */
	/* This logic will need revving once I figure out what quarter it is, etc. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	player1Points = winAnal.pointsFor;
	player2Points = winAnal.pointsAgainst;

	/* Quick sanity check. 200 points would be a lot! */
	if ( ( player1Points > 200 ) || ( player2Points > 200 ) )
	{
		return (kNotEnoughCompletedTie);
	}

	/* 8 point lead or more is a win! */
	if ( player1Points >= player2Points + 8 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( player2Points >= player1Points + 8 )
	{
		return (kEnoughCompletedRemoteWinner);
	}

	if ( player1Points + player2Points > 80 )
	{
		return (kEnoughCompletedTie);
	}

	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct SNES_SSF2_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} SNES_SSF2_GameData;

PRIVATE Err
SNES_SSF2_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
SNES_SSF2_GameData *ssf2Data = (SNES_SSF2_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long wins;
unsigned long losses;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( ssf2Data->dataVersion != kSNES_SSF2_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif
	
	/* for now, we'll call any matches that are 2-0 a win. And we'll call */
	/* matches that are 2-2 and 2-1 a tie. Others are not far enough along. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	wins = winAnal.pointsFor;
	losses = winAnal.pointsAgainst;

	if ( ( wins > 3 ) || ( losses > 3 ) || ( ( wins == 3 ) && ( losses == 3 ) ) )
	{
		// wacky win/loss thing. Bail!
		return (kNotEnoughCompletedTie);
	}
	
	// 3-X is a win! (Probably shouldn't be gameErrors in this case, but who knows?
	if ( wins == 3 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 3 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 2-0 is a win!
	if ( wins == 2 && losses == 0 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 2 && wins == 0 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 2-2, 2-1 is a tie. (Note that 2-0 cases are handled above)
	if ( wins == 2 || losses == 2 )
	{
		return (kEnoughCompletedTie);
	}
	
	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct SNES_NHL95_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} SNES_NHL95_GameData;

PRIVATE Err
SNES_NHL95_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
SNES_NHL95_GameData *nhl95Data = (SNES_NHL95_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long player1Points;
unsigned long player2Points;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( nhl95Data->dataVersion != kSNES_NHL95_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif

	/* for now, we'll call a 3 point lead a victory. Otherwise it's a tie if
there */
	/* are more than 9 points scored. */
	/* This logic will need revving once I figure out what quarter it is, etc. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	player1Points = winAnal.pointsFor;
	player2Points = winAnal.pointsAgainst;

	/* Quick sanity check. 100 points would be a lot! */
	if ( ( player1Points > 100 ) || ( player2Points > 100 ) )
	{
		return (kNotEnoughCompletedTie);
	}

	/* 3 point lead or more is a win! */
	if ( player1Points >= player2Points + 3 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( player2Points >= player1Points + 3 )
	{
		return (kEnoughCompletedRemoteWinner);
	}

	if ( player1Points + player2Points > 9 )
	{
		return (kEnoughCompletedTie);
	}

	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct SNES_Madden95_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} SNES_Madden95_GameData;

PRIVATE Err
SNES_Madden95_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
SNES_Madden95_GameData *madden95Data = (SNES_Madden95_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long player1Points;
unsigned long player2Points;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( madden95Data->dataVersion != kSNES_Madden95_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif

	/* for now, we'll call a 10 point lead a victory. Otherwise it's a tie if
there */
	/* are more than 50 points scored. */
	/* This logic will need revving once I figure out what quarter it is, etc. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	player1Points = winAnal.pointsFor;
	player2Points = winAnal.pointsAgainst;

	/* Quick sanity check. 200 points would be a lot! */
	if ( ( player1Points > 200 ) || ( player2Points > 200 ) )
	{
		return (kNotEnoughCompletedTie);
	}

	/* 10 point lead or more is a win! */
	if ( player1Points >= player2Points + 10 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( player2Points >= player1Points + 10 )
	{
		return (kEnoughCompletedRemoteWinner);
	}

	if ( player1Points + player2Points > 50 )
	{
		return (kEnoughCompletedTie);
	}

	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct SNES_Zelda_GameData {
	// is there really anything here?
	unsigned short dummy;
} SNES_Zelda_GameData;

PRIVATE Err
SNES_Zelda_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
SNES_Zelda_GameData *zeldaData = (SNES_Zelda_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long player1Points;
unsigned long player2Points;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( zeldaData->dataVersion != kSNES_Zelda_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	player1Points = winAnal.pointsFor;
	player2Points = winAnal.pointsAgainst;

	// Oh, just assume there isn't enough.  This is here for testing, really.
	return (kNotEnoughCompletedTie);

	//return (kEnoughCompletedLocalWinner);
	//return (kEnoughCompletedRemoteWinner);
	//return (kEnoughCompletedTie);
}

#ifdef UNUSED
typedef struct SNES_KillerInstinct_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} SNES_KillerInstinct_GameData;
#endif

PRIVATE Err
SNES_KillerInstinct_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
SNES_KillerInstinct_GameData *kiData = (SNES_KillerInstinct_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long wins;
unsigned long losses;

#ifdef UNUSED           // right now, we don't look at any game-specific data
	if ( kiData->dataVersion != kSNES_KillerInstinct_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif
	
	/* for now, we'll call any matches that are 2-0 a win. And we'll call */
	/* matches that are 2-2 and 2-1 a tie. Others are not far enough along. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	wins = winAnal.pointsFor;
	losses = winAnal.pointsAgainst;

	if ( ( wins > 3 ) || ( losses > 3 ) || ( ( wins == 3 ) && ( losses == 3 ) ) )
	{
		// wacky win/loss thing. Bail!
		return (kNotEnoughCompletedTie);
	}
	
	// 3-X is a win! (Probably shouldn't be gameErrors in this case, but who knows?
	if ( wins == 3 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 3 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 2-0 is a win!
	if ( wins == 2 && losses == 0 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 2 && wins == 0 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 2-2, 2-1 is a tie. (Note that 2-0 cases are handled above)
	if ( wins == 2 || losses == 2 )
	{
		return (kEnoughCompletedTie);
	}
	
	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

#ifdef UNUSED
typedef struct SNES_KGBaseball_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} SNES_KGBaseball_GameData;
#endif

PRIVATE Err
SNES_KGBaseball_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
SNES_KGBaseball_GameData *kgbData = (SNES_KGBaseball_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long player1Points;
unsigned long player2Points;

#ifdef UNUSED           // right now, we don't look at any game-specific data
	if ( kgbData->dataVersion != kSNES_KGBaseball_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif
	
	/* for now, we'll call a 5 point lead a victory. Otherwise it's a tie if there */
	/* are more than 9 points scored. */
	/* This logic will need revving once I figure out what quarter it is, etc. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	player1Points = winAnal.pointsFor;
	player2Points = winAnal.pointsAgainst;

	/* Quick sanity check. 100 points would be a lot! */
	if ( ( player1Points > 100 ) || ( player2Points > 100 ) )
	{
		return (kNotEnoughCompletedTie);
	}

	/* 3 point lead or more is a win! */
	if ( player1Points >= player2Points + 5 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( player2Points >= player1Points + 5 )
	{
		return (kEnoughCompletedRemoteWinner);
	}

	if ( player1Points + player2Points > 9 )
	{
		return (kEnoughCompletedTie);
	}

	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct SNES_WeaponLord_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} SNES_WeaponLord_GameData;

PRIVATE Err
SNES_WeaponLord_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
SNES_WeaponLord_GameData *weaponLordData = (SNES_WeaponLord_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long wins;
unsigned long losses;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( weaponLordData->dataVersion != kSNES_WeaponLord_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif
	
	/* for now, we'll call any matches that are 3-0, 3-1 a win. And we'll call */
	/* matches that are 2-2 a tie. Others are not far enough along. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	wins = winAnal.pointsFor;
	losses = winAnal.pointsAgainst;

	if ( ( wins > 4 ) || ( losses > 4 ) || ( ( wins == 4 ) && ( losses == 4 ) ) )
	{
		// wacky win/loss thing. Bail!
		return (kNotEnoughCompletedTie);
	}
	
	// 4-X is a win! (Probably shouldn't be gameErrors in this case, but who knows?
	if ( wins == 4 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 4 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 3-0, 3-1 is a win!
	if ( wins == 3 && losses < 2 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 3 && wins < 2 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 2-2, 3-3, 3-2 is a tie.
	if ( wins == 3 || losses == 3 || ( ( wins == 2 ) && ( losses == 2 ) ) )
	{
		return (kEnoughCompletedTie);
	}
	
	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct SNES_NHL96_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} SNES_NHL96_GameData;

PRIVATE Err
SNES_NHL96_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
SNES_NHL96_GameData *nhl96Data = (SNES_NHL96_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long player1Points;
unsigned long player2Points;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( nhl96Data->dataVersion != kSNES_NHL96_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif

	/* for now, we'll call a 3 point lead a victory. Otherwise it's a tie if there */
	/* are more than 9 points scored. */
	/* This logic will need revving once I figure out what quarter it is, etc. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	player1Points = winAnal.pointsFor;
	player2Points = winAnal.pointsAgainst;

	/* Quick sanity check. 100 points would be a lot! */
	if ( ( player1Points > 100 ) || ( player2Points > 100 ) )
	{
		return (kNotEnoughCompletedTie);
	}

	/* 3 point lead or more is a win! */
	if ( player1Points >= player2Points + 3 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( player2Points >= player1Points + 3 )
	{
		return (kEnoughCompletedRemoteWinner);
	}

	if ( player1Points + player2Points > 9 )
	{
		return (kEnoughCompletedTie);
	}

	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct SNES_Madden96_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} SNES_Madden96_GameData;

PRIVATE Err
SNES_Madden96_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
SNES_Madden96_GameData *madden96Data = (SNES_Madden96_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long player1Points;
unsigned long player2Points;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( madden96Data->dataVersion != kSNES_Madden96_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif

	/* for now, we'll call a 10 point lead a victory. Otherwise it's a tie if there */
	/* are more than 50 points scored. */
	/* This logic will need revving once I figure out what quarter it is, etc. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	player1Points = winAnal.pointsFor;
	player2Points = winAnal.pointsAgainst;

	/* Quick sanity check. 200 points would be a lot! */
	if ( ( player1Points > 200 ) || ( player2Points > 200 ) )
	{
		return (kNotEnoughCompletedTie);
	}

	/* 10 point lead or more is a win! */
	if ( player1Points >= player2Points + 10 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( player2Points >= player1Points + 10 )
	{
		return (kEnoughCompletedRemoteWinner);
	}

	if ( player1Points + player2Points > 50 )
	{
		return (kEnoughCompletedTie);
	}

	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct SNES_MK3_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} SNES_MK3_GameData;

PRIVATE Err
SNES_MK3_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
SNES_MK3_GameData *mk3Data = (SNES_MK3_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long wins;
unsigned long losses;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( mk3Data->dataVersion != kSNES_MK3_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif
	
	/* for now, we'll call any matches that are 2-0 a win. And we'll call */
	/* matches that are 2-2 and 2-1 a tie. Others are not far enough along. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	wins = winAnal.pointsFor;
	losses = winAnal.pointsAgainst;

	if ( ( wins > 3 ) || ( losses > 3 ) || ( ( wins == 3 ) && ( losses == 3 ) ) )
	{
		// wacky win/loss thing. Bail!
		return (kNotEnoughCompletedTie);
	}
	
	// 3-X is a win! (Probably shouldn't be gameErrors in this case, but who knows?
	if ( wins == 3 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 3 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 2-0 is a win!
	if ( wins == 2 && losses == 0 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 2 && wins == 0 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 2-2, 2-1 is a tie. (Note that 2-0 cases are handled above)
	if ( wins == 2 || losses == 2 )
	{
		return (kEnoughCompletedTie);
	}
	
	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}
