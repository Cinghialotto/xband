/*
 * Catapult Entertainment, Inc.
 *
 * $Id: Server_GameSpecific.h,v 1.7 1995/10/02 17:38:19 ansell Exp $
 *
 * $Log: Server_GameSpecific.h,v $
 * Revision 1.7  1995/10/02  17:38:19  ansell
 * Added prototype for Server_sjne_LookupGameSpecific.
 *
 * Revision 1.6  1995/09/10  22:33:59  fadden
 * Added completeEnough to game specific jump table struct.
 *
 * Revision 1.5  1995/07/31  21:21:46  fadden
 * Added proto for GenericCheckReset.
 *
 * Revision 1.4  1995/05/21  23:03:50  fadden
 * Don't try to define PRIVATE here.
 *
 */

/*
	File:		Server_GameSpecific.h

	Contains:	Declarations for game-specific code.

	Written by:	Andy McFadden

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <4>	11/23/94	ATM		Added PossiblyLosing stuff.
		 <3>	10/19/94	ATM		Change prototype for Server_DumpGameResult.
		 <2>	10/17/94	ATM		Added stuff.
		 <1>	10/17/94	ATM		first checked in

	To Do:
*/

#include "Server.h"
#include "ServerState.h"

// ===========================================================================
//		Public stuff
// ===========================================================================

Err Server_DumpGameResultSendQ(const ServerState *state,
	const unsigned char *data, const long size);
Err Server_DumpGameResult(const ServerState *state,
	const NewGameResult *gameResult, int isErr);
Err Server_GetNumWins(const long platformID, const NewGameResult *gameResult,
	long *p1wins, long *p2wins);
Err Server_ShouldGameBeScored(const ServerState *state,
	const NewGameResult *gameResult);
Err Server_PossiblyLosing(const ServerState *state,
	const NewGameResult *gameResult);
Err Server_CheckReset(const ServerState *state, const NewGameResult *gameResult,
	const NewGameResult *gameErrorResult);
Err Server_CompleteEnough(const ServerState *state,
	const NewGameResult *gameErrorResult);


// ===========================================================================
//		Private stuff, common to all platforms
// ===========================================================================

//
// Pointer to a function returning Err.
//
typedef Err (*ERR_FUNC_PTR)();

//
// Jump table for known games.  One table for each platform.
//
// This doesn't belong in Common_GameInfo, because it has to be resolved
// at link time, and there's no reason for a game to be in this table if
// there's no specific code for it.
//
typedef struct {
	long			gameID;					// which game it is
	ERR_FUNC_PTR	displaySendQ;			// pretty-print stuff from SendQ
	ERR_FUNC_PTR	displayGameResult;		// pretty-print gameReserved field

	ERR_FUNC_PTR	getNumWins;				// compute #of wins for each side
	ERR_FUNC_PTR	checkScorable;			// determine if game is scorable
	ERR_FUNC_PTR	possiblyLosing;			// might player have been losing?
	ERR_FUNC_PTR	checkReset;				// determine if reset was malicious
	ERR_FUNC_PTR	completeEnough;			// was the game completed far enuf?
} GameSpecificJumpTable;

//
// Local functions.  These are private to the game-specific stuff, but must
// be visible from the different platform-specific routines.
//
#ifndef SEMI_PRIVATE
# define SEMI_PRIVATE
#endif

SEMI_PRIVATE Err GenericGetNumWins(const NewGameResult *gameResult,
	long *p1wins, long *p2wins);
SEMI_PRIVATE Err MatchGetNumWins(const NewGameResult *gameResult,
	long *p1wins, long *p2wins);
SEMI_PRIVATE Err GenericCheckReset(const ServerState *state,
	const NewGameResult *gameResult, const NewGameResult *gameErrorResult);


//
// Game-specific functions that must be accessible from the common code.
//
SEMI_PRIVATE int Server_sega_LookupGameSpecific(const long gameID,
	GameSpecificJumpTable **retval);
SEMI_PRIVATE int Server_snes_LookupGameSpecific(const long gameID,
	GameSpecificJumpTable **retval);
SEMI_PRIVATE int Server_sjne_LookupGameSpecific(const long gameID,
	GameSpecificJumpTable **retval);

