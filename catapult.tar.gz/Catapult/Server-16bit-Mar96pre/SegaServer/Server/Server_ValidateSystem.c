/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_ValidateSystem.c,v 1.13 1996/01/31 00:09:34 fadden Exp $
 *
 * $Log: Server_ValidateSystem.c,v $
 * Revision 1.13  1996/01/31  00:09:34  fadden
 * Rewrote Server_ValidateSystem to use "SystemPatch.num" and "RattlePatch.num"
 * files when available.  Added Server_GetCurrentPatchVersion and
 * Server_ScanForPatchVersion.
 *
 * Revision 1.12  1996/01/30  22:46:08  fadden
 * Removed cruft.
 *
 * Revision 1.11  1995/09/13  14:24:56  ted
 * Fixed warnings.
 *
 * Revision 1.10  1995/08/29  16:37:43  ansell
 * Check for new kBoxFlag_OSTester flag being set in boxFlags to see if
 * user should revceive RattlePatches.
 *
 * Revision 1.9  1995/07/17  22:49:12  fadden
 * Check for valid hardwareID before calling CompareHardwareID in sim check.
 *
 * Revision 1.8  1995/07/04  22:54:18  fadden
 * Changed the Common_CompareHardwareID calls.
 *
 * Revision 1.7  1995/06/19  20:50:51  fadden
 * Added Server_BoxIsSimulator to determine if the box is a simulator or not.
 * Added code to check for the SNES hardwareID value.
 *
 * Revision 1.6  1995/06/08  11:11:23  ted
 * Refer to kBoxFlag_VIP.
 *
 * Revision 1.5  1995/05/26  23:47:22  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_ValidateSystem.c

	Written by:	David Jevans

	Change History (most recent first):

		<19>	 12/7/94	ATM		Fix RattleBug.
		<18>	 12/6/94	ATM		Send RattlePatches to VIPs and Catapult boxes.
		<17>	 11/9/94	DJ		Renamed some DB routines to DataBaseUtil_ and also to WrapperDB_
									(for Oracle).
		<16>	 11/9/94	ATM		Don't download patches to kSpecialFuckers.
		<15>	 11/4/94	ATM		Back to 2.
		<14>	 11/4/94	ATM		Changed it back to 1; bug in patches.
		<13>	 11/3/94	ATM		SystemPatch.Initial is now patch version 2 to differentiate it
									from the factory SRAM patch.
		<12>	10/19/94	DJ		Doesn't send any system patches to Simulators.
		<11>	10/19/94	DJ		Added Server_ValidateInitialSystemPatch.
		<10>	 9/26/94	ATM		Current system patch version was always ending up 0.
		 <9>	 9/26/94	ATM		Converted debugN to debug[N].
		 <8>	 9/21/94	ATM		Changed the logic slightly.
		 <7>	 9/21/94	ATM		Added support for RattlePatches.
		 <6>	 9/19/94	ATM		PLogmsg stuff.
		 <5>	  9/2/94	DJ		more printf cheese
		 <4>	 8/30/94	DJ		Server_ValidateSystem now just looks on the filesystem for the
									latest patch file instead of looking in the database.  So you
									can put a SystemPatch.1 where SunSega runs and it will get send
									to patchversion 0 boxes without having to bounce the DB.
		 <3>	  7/1/94	DJ		making server handle errors from the comm layer
		 <2>	 5/31/94	DJ		using ReleasePreformedMessage
		 <1>	 5/27/94	DJ		first checked in
*/

#include <stdio.h>
#include <unistd.h>
#include <memory.h>

#include "Server.h"
#include "Messages.h"
#include "UsrConfg.h"
#include "ServerDataBase.h"

#include "Common_PlatformID.h"
#include "Common_Missing.h"

//
// Local prototypes.
//
static int Server_GetCurrentPatchVersion(ServerState *state, char *basename);
static int Server_ScanForPatchVersion(ServerState *state, char *basename);

//
// Now system patches are read in by the SunSega processes, so we don't have to
// bounce the database when we add a new patch.
//
#define kSystemPatchFileName	"SystemPatch"
#define kRattlePatchFileName	"RattlePatch"
#define kSystemPatchFileNameLength	500
#define kBiggestSystemVersion	150L


//
// Returns true if the box is a simulator, false otherwise.
//
Boolean
Server_BoxIsSimulator(ServerState *state)
{
	SnesHardwareID snesSimSnesID = {	// hwid used in SNES sim
		0x01, { 0x9b, 0xce, 0x3c, 0x00, 0x00, 0x00 }, 0xae
	};
	HardwareID snesSimID;				// frame to hold the above
	HardwareID tmpHwid;

	PLogmsg(LOGP_PROGRESS, "Server_BoxIsSimulator\n");

	// The old standby: gameID 666 is Sega sim.
	//
	if (state->gameIDData.gameID == 666)
		return (true);

	// Check the hwid (if any).
	//
	// NOTE: ReceiveLogin is going to blow away the hardwareIDtype,
	// replacing it with kHWID_NoHWID, and putting the real hardwareIDtype
	// into realHardwareIDtype.  This routine will be called both before
	// and after this occurs.
	//
	tmpHwid = state->loginData.hardwareID;
	if (state->loginData.hardwareID.hardwareIDtype == kHWID_NoHWID &&
		state->loginData.realHardwareIDtype != kHWID_NoHWID)
	{
		// This in and of itself should be sufficient to tell us that
		// we've got a simulator.  Oh well, keep going.
		//
		tmpHwid.hardwareIDtype = state->loginData.realHardwareIDtype;
	}
	if ((tmpHwid.hardwareIDtype != kHWID_NoHWID) &&
		((tmpHwid.hardwareIDtype == kHWID_DallasTouch) &&
			(tmpHwid.hwid.snesHWID.snesHardwareIDerror == 0)) )
	{
		memset(&snesSimID, 0, sizeof(HardwareID));		// init to zero
		snesSimID.hardwareIDtype = kHWID_DallasTouch;
		snesSimID.hwid.snesHWID.snesHardwareIDerror = 0;
		snesSimID.hwid.snesHWID.snesHardwareID = snesSimSnesID;
		if (Common_CompareHardwareID(&snesSimID, &tmpHwid) == 0)
			return (true);
	}

	return (false);
}


//
// This guy downloads a very small initial patch that fixes any critical
// transport layer bugs.  For a new (or restored box) this gets called before
// Server_ValidateSystem in order to improve the reliability of downloading
// the much bigger normal system patch.  The initial patch is only sent for
// boxes with system version == 0.  It makes their system version = 1.
//
// NOTE: this may be called before state->account is set (e.g. box restore).
//
int
Server_ValidateInitialSystemPatch(ServerState *state)
{
PreformedMessage	*patch = NULL;
char				fname[kSystemPatchFileNameLength];
int					err;

	PLogmsg(LOGP_PROGRESS, "Server_ValidateInitialSystemPatch\n");
	err = kServerFuncOK;

	if (Server_GetSpecialPhone(state) & kSpecialFucker) {
		PLogmsg(LOGP_NOTICE, "NOTE: initial patch NOT downloaded to fucker\n");
		return (kNoError);
	}

	if(!Server_BoxIsSimulator(state))		// don't send patch to simulators
	{
		if(state->systemVersionData.version < 2)
		{
			sprintf(fname, "%.4s/%s.initial",
				(char *)&state->boxOSState.boxType, kSystemPatchFileName);
			patch = PreformedMessage_ReadFromFile(fname);
			if(patch) {
				Logmsg("SystemPatch: Box at v%d, sending %.4s/%s.initial (len=%ld)\n",
					state->systemVersionData.version,
					(char *)&state->boxOSState.boxType,
					kSystemPatchFileName,
					patch->length);
				err = Server_SendPreformedMessage(state, patch);
				PreformedMessage_Dispose(patch);
				
				state->systemVersionData.version = 2;	// Needed to let Server_ValidateSystem know that we're at patch version 2 already.
														// Probably extraneous.
			}
			else
				Logmsg("SystemPatch: Box at v%d, could not find %.4s/%s.inital.\n",
					state->systemVersionData.version,
					(char *)&state->boxOSState.boxType,
					kSystemPatchFileName);
		}
	} else {
		PLogmsg(LOGP_PROGRESS, "Not even trying to send initial patch to sim\n");
	}
	
	PLogmsg(LOGP_PROGRESS, "Server_ValidateInitialSystemPatch done\n");
	return(err);
}


//
// Send a system patch to the user if he needs one.
//
// If a user can get a RattlePatch, and we have both SystemPatch.N and
// RattlePatch.N, the user will get the RattlePatch.
//
int
Server_ValidateSystem(ServerState *state)
{
char				fname[kSystemPatchFileNameLength];
PreformedMessage	*patch = NULL;
int					patchNum, rpatchNum, tryRattlePatch, max, err;

	PLogmsg(LOGP_PROGRESS, "Server_ValidateSystem\n");
	ASSERT(state->validFlags & kServerValidFlag_Account);

	if (Server_GetSpecialPhone(state) & kSpecialFucker) {
		PLogmsg(LOGP_NOTICE, "NOTE: system patch NOT downloaded to fucker\n");
		return (kNoError);
	}

	if (Server_BoxIsSimulator(state)) {
		PLogmsg(LOGP_PROGRESS, "Server_ValidateSystem done (simulator)\n");
		return (kServerFuncOK);
	}

	// See if he's eligible for a RattlePatch.
	//
	tryRattlePatch =
		((state->account->boxAccount.debug[1] & kBA_debug_RattlePatch) ||
		 (Server_GetSpecialPhone(state) & kSpecialVIPTester) ||
		 (Server_GetSpecialPhone(state) & kSpecialCatapult) ||
		 (state->account->boxAccount.boxFlags & kBoxFlag_VIP) ||
		 (state->account->boxAccount.boxFlags & kBoxFlag_OSTester) );

	// Get the current patch versions out of the "indirect" file.  If the
	// attempt fails, the patch numbers will be set to -1.
	//
	// If the guy isn't elligible for a rattlePatch, we just set the
	// patch number to zero so it gets ignored from here on out.
	//
	patchNum = Server_GetCurrentPatchVersion(state, kSystemPatchFileName);
	if (patchNum < 0)
		patchNum = Server_ScanForPatchVersion(state, kSystemPatchFileName);

	rpatchNum = 0;
	if (tryRattlePatch) {
		rpatchNum = Server_GetCurrentPatchVersion(state, kRattlePatchFileName);
		if (rpatchNum < 0)
			rpatchNum = Server_ScanForPatchVersion(state, kRattlePatchFileName);
	}

	// If patchNum is -1, we didn't just fail to find a system patch, we
	// had system errors while looking.  This is bad.
	//
	if (patchNum < 0) {
		PLogmsg(LOGP_FLAW, "ERROR: failed in SystemPatch\n");
		return (kServerFuncAbort);	// extreme?
	}

	// See if there's anything at all to send.
	//
	if (!patchNum && !rpatchNum) {
		Logmsg("SystemPatch: no patches found on server\n");
		return (kServerFuncOK);
	}

#define LIVE_DANGEROUSLY
#ifdef LIVE_DANGEROUSLY
	// Don't load the patch if the box doesn't need it.  This is actually
	// sort of dangerous, because if the xxxx.num file is inaccurate
	// we'd be bailing out before we should.  However, this does avoid
	// loading an unnecessary file from disk.
	//
	max = (rpatchNum > patchNum) ? rpatchNum : patchNum;
	if (state->systemVersionData.version >= max) {
		Logmsg("SystemPatch: No download (box at %ld, current %ld)\n",
			state->systemVersionData.version, max);
		return (kServerFuncOK);
	}
#endif

retry:
	// Load whichever is newer.  RattlePatches take precedence over
	// normal system patches.
	//
	if (rpatchNum >= patchNum) {
		sprintf(fname, "%.4s/%s.%d", (char *)&state->boxOSState.boxType,
			kRattlePatchFileName, rpatchNum);
		patch = PreformedMessage_ReadFromFile(fname);
		if (patch != NULL)
			Logmsg("SystemPatch: Loaded '%s'\n", fname);
	} else {
		sprintf(fname, "%.4s/%s.%d", (char *)&state->boxOSState.boxType,
			kSystemPatchFileName, patchNum);
		patch = PreformedMessage_ReadFromFile(fname);
		if (patch != NULL)
			Logmsg("SystemPatch: Loaded '%s'\n", fname);
	}

	// See if the patch load succeeded.  If it didn't, do the scan-by-name
	// and try again.  This is sort of icky.
	//
	if (patch == NULL) {
		int oldPatchNum = patchNum;
		int oldRpatchNum = rpatchNum;

		PLogmsg(LOGP_NOTICE,
			"SystemPatch: load of '%s' failed, retrying with scan\n", fname);

		patchNum = Server_ScanForPatchVersion(state, kSystemPatchFileName);
		if (tryRattlePatch)
			rpatchNum = Server_ScanForPatchVersion(state, kRattlePatchFileName);

		if (patchNum != oldPatchNum || rpatchNum != oldRpatchNum) {
			// Hmm, something new here, so try it again.
			// This can only get into an infinite loop if the filesystem
			// has gone insane and we're oscillating between two values.
			//
			goto retry;
		}

		PLogmsg(LOGP_FLAW, "SystemPatch: scan retry failed, bailing\n");
		return (kServerFuncAbort);		// extreme?
	}


	// Send it down, if necessary.
	//
	err = kServerFuncOK;

	max = (rpatchNum > patchNum) ? rpatchNum : patchNum;
	if (max > state->systemVersionData.version) {
		Logmsg("SystemPatch: box at v%ld, sending %ld (len=%ld)\n",
			state->systemVersionData.version, max, patch->length);
		err = Server_SendPreformedMessage(state, patch);
	} else {
		Logmsg("SystemPatch: no download (box at %ld, current %ld)\n",
			state->systemVersionData.version, max);
	}

	if (patch)
		PreformedMessage_Dispose(patch);

	PLogmsg(LOGP_PROGRESS, "Server_ValidateSystem done\n");
	return(err);
}


#define kMaxNumLen	10
//
// Find the current system patch or rattle patch version number by
// opening "xxxx/SystemPatch.num" or "xxx/RattlePatch.num", where
// "xxxx" is the boxType.
//
// Returns -1 if an error occurs along the way.
//
static int
Server_GetCurrentPatchVersion(ServerState *state, char *basename)
{
	char fname[kSystemPatchFileNameLength], linebuf[kMaxNumLen];
	FILE *fp;
	int num;

	PLogmsg(LOGP_PROGRESS, "Server_GetCurrentPatchVersion (%s)\n", basename);

	sprintf(fname, "%.4s/%s.num", (char *)&state->boxOSState.boxType,
		basename);
	if ((fp = fopen(fname, "r")) == NULL) {
		PLogmsg(LOGP_FLAW, "Unable to open '%s' (%d)\n", fname, errno);
		return (-1);
	}
	fgets(linebuf, kMaxNumLen, fp);
	if (ferror(fp) || feof(fp)) {
		PLogmsg(LOGP_FLAW, "Error or EOF on '%s'\n", fname);
		fclose(fp);
		return (-1);
	}

	num = atoi(linebuf);
	PLogmsg(LOGP_DETAIL, "SystemPatch: '%s' held %d\n", fname, num);

	// Prevent silly users from making it look like we're failing.
	//
	if (num < 0)
		num = 0;

	fclose(fp);
	return (num);
}


//
// Find the current system patch or rattle patch version number by
// doing a long and painful search through the directory.
//
// Returns 0 if no patch was found.
// Returns -1 if an error occurs along the way.
//
static int
Server_ScanForPatchVersion(ServerState *state, char *basename)
{
	char fname[kSystemPatchFileNameLength];
	int i;

	PLogmsg(LOGP_PROGRESS, "Server_ScanForPatchVersion (%s)\n", basename);

	for (i = kBiggestSystemVersion; i; i--) {
		sprintf(fname, "%.4s/%s.%d", (char *)&state->boxOSState.boxType,
			basename, i);
		if (access(fname, R_OK) < 0)
			continue;
		Logmsg("SystemPatch: found '%s'\n", fname);
		break;
	}

	return (i);
}

