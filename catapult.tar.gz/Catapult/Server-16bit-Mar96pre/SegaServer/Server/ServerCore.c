/*
 * Catapult Entertainment, Inc.
 *
 * $Id: ServerCore.c,v 1.42 1996/01/29 21:59:48 hufft Exp $
 *
 * $Log: ServerCore.c,v $
 * Revision 1.42  1996/01/29  21:59:48  hufft
 * upd packet changes
 *
 * Revision 1.41  1996/01/25  17:51:36  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.40  1996/01/17  13:53:29  fadden
 * Spiffy new dialog text.
 *
 * Revision 1.39  1996/01/16  22:52:07  fadden
 * Added machineBusy check.
 *
 * Revision 1.38  1995/11/08  18:38:47  jhsia
 * Moved stuff from Server_snes_RecvComplete() to SetRandomThings(). (fadden)
 *
 * Revision 1.37  1995/11/06  02:41:27  felix
 * Added dispatcher call to Server_UpdateDebitCard, following Server_ClearMiscQueues
 *
 * Revision 1.36  1995/10/30  16:46:09  steveb
 * Environment variables read are now XBAND_ANI and XBAND_X25_ADDRESS.
 *
 * Revision 1.35  1995/10/27  19:43:31  steveb
 * Just did some long needed housecleaning.  No new code.
 *
 * Revision 1.34  1995/09/16  17:28:25  fadden
 * Fix the FAX timeout constant for sn07 boxes.
 *
 * Revision 1.33  1995/09/13  14:24:18  ted
 * Fixed warnings.
 *
 * Revision 1.32  1995/07/26  22:52:44  fadden
 * Added magnifyMode logmsg for magicID.  Added kReregisterLockout to set of
 * bits set on SNESs.
 *
 * Revision 1.31  1995/07/17  18:34:29  fadden
 * LRA: removed the PORTAL environment variable dump.  Changed the "ANI says
 * caller is" to "PORTAL_ANI says caller is" in case somebody is grepping for
 * that (note it gets printed again in ValidateLogin, so we're fine either way).
 *
 * Revision 1.30  1995/07/11  15:36:24  fadden
 * Set kDisableHappyServerLogs.
 *
 * Revision 1.29  1995/07/10  20:53:17  rich
 * Added Japanese box type (kBoxType_sj01) and platform ID (kPlatformSJNES).
 *
 * Revision 1.28  1995/07/07  20:40:48  fadden
 * Added a quick hack to turn off the titles supplied when sending mail to
 * XBAND on snes.  Added MiscPrefs to dispatcher table.  Rearranged RRD stuff.
 *
 * Revision 1.27  1995/06/26  13:51:00  felix
 * Added assignment of state->boxType
 *
 * Revision 1.26  1995/06/01  16:20:23  fadden
 * Turn off kServerTests on SNES.
 *
 * Revision 1.25  1995/05/11  05:44:33  fadden
 * Broke RecvComplete into pieces.  The SNES version sets the Fifo fix bits
 * if necessary.  Moved NoLogin check and GetConnectCookie into RecvComplete.
 * Added kServerSendRequestData/kServerReceiveRequestedData.
 *
 */

/*
	File:		ServerCore.c

	Contains:	Server Core Entry Points

	Progeny of:	Dave Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

	   <127>	11/30/94	SR		Partial DB update on early connect termination
	   <126>	11/15/94	SR		Binary log - first pass.
	   <125>	11/10/94	DJ		WrapperDB on init, shutdown, and savetodisk.
	   <124>	 11/2/94	DJ		Printing out Portal env variables.
	   <123>	10/28/94	ATM		SpecialPhone stuff.
	   <122>	10/26/94	DJ		 Moved ServerStateInit around so that setting timeOfThisConnect
									will work properly.
	   <121>	10/24/94	DJ		Setting boxState->timeOfThisConnect when PListen succeeds.
	   <120>	10/20/94	DJ		Added kServerStartConnection and kServerCheckAccountCredits.
	   <119>	10/20/94	DJ		Clearing out conn stats and setting activationDate for old Beta
									accounts.  Also don';t total neterrors if there is a
									crashRecord.
	   <118>	10/19/94	DJ		Added Server_GeneralBoxUpdate and Server_ValidateInitialPatch.
	   <117>	10/17/94	DJ		Updating userAccount->dateLastConnect in UpdateAccount
	   <116>	10/17/94	ATM		Changed DataBase_UpdateRanking to Server_UpdateRanking.
	   <115>	10/10/94	DJ		Just moved a line around.  Only cosmetic
	   <114>	10/10/94	ATM		Added Server_UpdateGameResults.  Moved stuff out of
									RecvComplete.
	   <113>	 10/9/94	ATM		Pass gameErrorResults into UpdateGameResult.
	   <112>	 10/6/94	ATM		Remove call to AgeWaitQ.
	   <111>	 10/1/94	ATM		Moved call to DataBase_UpdateRanking in here (RecvComplete).
	   <110>	 9/29/94	ATM		Don't total up net errors if it's a brand new box (get a load of
									0xffffs).  Added UpdateNGPVersion to dispatcher table.
	   <109>	 9/28/94	DJ		added MessageOfTheDay to UpdateDB
	   <108>	 9/28/94	ATM		Changed gHangupOkay stuff.
	   <107>	 9/28/94	ATM		Need to NULL-terminate phone number field in the statistics.
	   <106>	 9/27/94	DJ		totalling netErrorTotals up in UpdateDB
	   <105>	 9/27/94	DJ		LoadFilterFile
	   <104>	 9/26/94	ATM		Added RecvComplete and abandonShip handling..
	   <103>	 9/26/94	ATM		Converted debugN to debug[N].
	   <102>	 9/25/94	ATM		Print a single line of info with statistically interesting
									stuff.
	   <101>	 9/20/94	DJ		better dialogs for testing all pops
	   <100>	 9/20/94	DJ		error dialogs if can't test all pops cuz can't open
									cpsnum.catapult
		<99>	 9/20/94	DJ		support for testing all pops in the country (send mail to
									"testpops").  fun.
		<98>	 9/19/94	ATM		PLogmsg stuff.  Changed seg8 and seg9 to 'dead'.
		<97>	 9/16/94	ATM		Didn't quite succeed with previous fix.
		<96>	 9/16/94	ATM		boxFlags->boxModified, playerFlags->playerModified,
									acceptChallenges->playerFlags.
		<95>	  9/3/94	ATM		Added gHangupOkay flag.  Stripped out old, unused junk.  See
									previous rev for "old tubs of shit docs" and the first 8
									dispatcher table initializers.
		<94>	 8/30/94	ATM		Converted accountChangedMask references to Account flags.
		<93>	 8/28/94	ATM		Changes for 'segb'.
		<92>	 8/27/94	ATM		seg9 changes, plus check on validFlags in UpdateDataBaseAccount.
		<91>	 8/26/94	DJ		clearing out dispatcher tables with NULL for safety
		<90>	 8/26/94	ATM		Added handlers for anticipated SEG9, but left them #ifdefed out
									for now.  (SEG8 + new CreditDebitInfo)
		<89>	 8/26/94	BET		msSendClearSendQueue message needs to call
									Server_SendClearMiscQueues.
		<88>	 8/25/94	BET		Add support for multiple NetErrorRecord types for both X25 and
									800 services.
		<87>	 8/25/94	DJ		added Server_SendClearMiscQueues
		<86>	 8/25/94	ATM		Now at seg7 for f2 ROMs.
		<85>	 8/21/94	DJ		update the database Account if EndCommunication is called
		<84>	 8/21/94	DJ		new ROM version.. 'seg6'
		<83>	 8/20/94	DJ		new ROM version.. 'seg5'
		<82>	 8/19/94	BET		Turn off listen timeout, sigalarm should catch the server if it
									blows.
		<81>	 8/18/94	DJ		fixed redial treat
		<80>	 8/18/94	DJ		more printfs
		<79>	 8/17/94	DJ		receiveloginversion2
		<78>	 8/16/94	DJ		made tlisten timeout 1 min instead of 5
		<77>	 8/16/94	DJ		senddateandtime
		<76>	 8/13/94	DJ		forceend
		<75>	 8/13/94	BET		Added SendNetErrors
		<74>	 8/13/94	ATM		Fixed gLogFile stuff for Mac.
		<73>	 8/13/94	ATM		Pulled logging and debugging stuff out.
		<72>	 8/12/94	DJ		calling validatesystem
		<71>	 8/12/94	DJ		supports multiple ROM versions
		<70>	 8/12/94	ATM		Reversed strings for NBA Jam.
		<69>	 8/12/94	ATM		Added Server_GameName.
		<68>	 8/12/94	DJ		turned it off
		<67>	 8/12/94	DJ		turned on personification
		<66>	 8/12/94	ATM		Updated logging stuff.
		<65>	 8/12/94	ATM		Added Statusmsg().
		<64>	 8/11/94	DJ		news sends immediately
		<63>	 8/11/94	ATM		Added Logmsg().
		<62>	 8/10/94	DJ		personification
		<61>	  8/8/94	DJ		loopback is now enabled by mail
		<60>	  8/6/94	DJ		fuck me
		<59>	  8/6/94	DJ		another
		<58>	  8/6/94	DJ		bugler
		<57>	  8/6/94	DJ		bug
		<56>	  8/6/94	DJ		playeraccount stuff
		<55>	  8/5/94	DJ		playeraccount stuff
		<54>	  8/5/94	DJ		game error results
		<54>	  8/5/94	DJ		game error results
		<53>	  8/4/94	ATM		Commented out Server_SetupGamePatches (now done on database
									side).
		<52>	  8/4/94	BET		Comment out gratuitous NetIdle call.
		<51>	  8/3/94	ATM		Added memory watch debug stuff.
		<50>	  8/4/94	ATM		Commented out Server_SetupAccounts call.
		<49>	  8/3/94	DJ		just some jizz
		<48>	  8/2/94	DJ		googar
		<47>	 7/31/94	DJ		sending new problem token and validation         token before
									endCommunication
		<46>	 7/29/94	DJ		sending new problem token and validation token before
									endCommunication
		<45>	 7/26/94	DJ		fixed serverprogress bug
		<44>	 7/26/94	BET		Add ifndef unix to STANDALONE definition
		<43>	 7/26/94	DJ		fixing crasher to ByteCopy in ServerState_Init
		<42>	 7/25/94	DJ		5 days of hacking, including: async listens so can age the waitq
		<41>	 7/20/94	DJ		no ServerState passed to dbase routines
		<40>	 7/20/94	DJ		removed configstr from serverstate
		<39>	 7/20/94	DJ		DoCommand returns true after a full connect sequence
		<38>	 7/20/94	DJ		added Server_Comm stuff
		<37>	 7/19/94	BET		#ifndef unix to the gLogFile setting
		<36>	 7/19/94	DJ		server test
		<35>	 7/18/94	DJ		driving boxType msg
		<34>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		<33>	 7/16/94	dwh		more unix-ise.
		<32>	 7/15/94	DJ		added new mail
		<31>	 7/14/94	DJ		new mail
		<30>	 7/14/94	DJ		moved news later to avoid resendack bug
		<29>	 7/13/94	dwh		unix crud.
		<28>	 7/12/94	DJ		sends news right after Login
		<27>	  7/8/94	DJ		made it work over and over if TListen failes
		<26>	  7/6/94	DJ		address book validation
		<25>	  7/5/94	DJ		added pclose if tlisten fails
		<24>	  7/4/94	DJ		using that param
		<23>	  7/3/94	DJ		added param to CloseServerConnection to avoid TClose in error
									situations cuz it can hand
		<22>	  7/1/94	DJ		making server handle errors from the comm layer
		<21>	 6/30/94	DJ		validate the system, send update patches
		<20>	 6/28/94	BET		Update for new transport interfaces for OSErr         on Open
									and Listen.
		<19>	 6/22/94	BET		Update for new phys interfaces for OSErr on Open and Listen.
									Still need to convert transport interfaces once they are ready.
		<18>	 6/15/94	DJ		added PClose
		<17>	 6/12/94	DJ		checks the game patch and also starts game play (does waitQ and
									ranking match).
		<16>	 6/11/94	DJ		removed any NetIdle stuff after PListen
		<15>	 6/11/94	DJ		removed any NetIdle stuff after PListen
		<14>	 6/10/94	BET		Don't call NetIdle after PListen, call PNetIdle.  NetIdle has
									the opportunity to take packets off the incoming fifo before the
									listen is complete, and they get tossed.
		<13>	 6/10/94	DJ		relistens after each connect, also fragmented DoCommand and
									don't call Server_Drive anymore.
		<12>	  6/9/94	BET		Fix interface change
		<11>	  6/5/94	BET		Make it multisession
		<10>	  6/5/94	BET		Change interface to InitServer
		 <9>	  6/5/94	BET		Change interfaces to TListen
		 <7>	 5/31/94	DJ		cheezewad gloggler
		 <6>	 5/29/94	DJ		gibbly treats
		 <5>	 5/29/94	DJ		test stuff for reading preformatted msgs
		 <4>	 5/27/94	DJ		added comments about identifying 'sega' and 'nint'
		 <3>	 5/26/94	DJ		removed dome printfs
		 <2>	 5/25/94	DJ		fixed driving etc
		 <4>	 5/25/94	DJ		new routines and comments etc
		 <3>	 5/23/94	BET		A starting point?
		 <2>	 5/23/94	BET		Possible poo for you

	To Do:
	
	5/24/94
	
	Validation.
	
	Subdivide SendQ so that it discriminates between mail, game results, new address books,
	and other personification shit (?).
	Clear box's sendQ
	
	Kool stuff.  Where does it go?  Sprinkle it about?
	
	Test all the driving of database - get,set items and types
		(adds sounds, taunts, images, whatever).
		
	Test drawing
	
	patching the O/S
	patching and removing message patches
	
	sending a new NGP (done at every connection probably).
	
	setting box serial number (?)
	What about setting which local service number box is to call?
	
	Competitive opCode needs work
	
	
*/


#include <memory.h>
#include "ServerCore.h"
#include "Server.h"
#include "Messages.h"
#include "ServerDataBase.h"
#include "Server_Log.h"
#include "Dates.h"
#include "PhysicalLayer.h"
#include "NetMisc.h"
#include "Challnge.h"
#include "DBConstants.h"
#include "FilterHandle.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <sys/time.h>

#include "Common_Missing.h"


#ifndef unix
# define STANDALONE
# error "I think you'd better use -Dunix!"
#endif

// #define EXTERNAL_MODEM


//
// Local prototypes
//
PRIVATE int Server_common_RecvComplete(ServerState *state);
PRIVATE Boolean Server_IsXBANDOnline(ServerState *state);


//
// Stuff for communicating via a file instead of modem (for debugging).
//
#define kServerWriteTeeFile  "ServerWriteData.tee"
#define kServerReadTeeFile  "ServerReadData.tee"
#define kServerInputFile  "ServerInputData.tee"

#define kTListenTimeout	0			/* no timeout for TListen, the alarm process should catch the server */


//
// Positive numbers are which message the server is processing.
// Negative numbers indication connection status during the process of connecting.
//
#define kServerConnected	0
#define	kServerNotListening	-1
#define kServerPListening	-2
#define kServerTListening	-3


// ===========================================================================
//		Platform-specific setup.
// ===========================================================================

#ifndef NELEM
# define NELEM(x)	(sizeof(x) / sizeof(x[0]))
#endif

void Server_sega_InitDispatcher(MessageDispatcher *dispatcher, long boxType);
void Server_snes_InitDispatcher(MessageDispatcher *dispatcher, long boxType);
void Server_intl_InitDispatcher(MessageDispatcher *dispatcher, long boxType);
void Server_generic_InitDispatcher(MessageDispatcher *dispatcher);

// Valid ROM identifiers.  IDs for unsupported ROMs should be removed from
// the list.
//
static long romForGenesis[] = {
	kBoxType_segb, kBoxType_segc
};
static long romForSnes[] = {
	kBoxType_sn07
};
static long romForIntel[] = {
	kBoxType_in00
};
static long romForSjnes[] = {
	kBoxType_sj01
};
static long romForSaturn[] = {
	kBoxType_tj01
};

// Table of platforms.
//
// Note that the dispatcher table from the first entry in the list will be
// used until the box's ROM can be identified.
//
// The Japanese SNES platform will be forced to look exactly like the
// rest-of-world SNES platform initially.  This may change over time.
//
static Platform platforms[] = {
	"Sega Genesis",	kPlatformGenesis, kPlatformGenesisMask,	NELEM(romForGenesis),
		romForGenesis, NULL, Server_sega_InitDispatcher,
	"SNES",         kPlatformSNES,    kPlatformSNESMask,	NELEM(romForSnes),
		romForSnes, NULL, Server_snes_InitDispatcher,
	"Intel",        kPlatformIntel,   kPlatformIntelMask,	NELEM(romForIntel),
		romForIntel, NULL, Server_intl_InitDispatcher,
	"Japanese SNES", kPlatformSJNES,   kPlatformSJNESMask,	NELEM(romForSjnes),
		romForSjnes, NULL, Server_snes_InitDispatcher,
	"Japanese SATURN", kPlatformSATURN,   kPlatformSATURNMask,	NELEM(romForSaturn),
		romForSaturn, NULL, Server_snes_InitDispatcher,
};
static	SessionType	session_type = SESSION_ADSP;
static MessageDispatcher *currentDispatcher = NULL;



// ===========================================================================
//		Initialization and driver routines
// ===========================================================================

#if defined(STANDALONE) && !defined(unix)

#define kConfigStrLength	1000

char *FindConfigString(char *config);


main()
{
ServerState *boxState;

#ifdef EXTERNAL_MODEM
char	configStr[kConfigStrLength];

	boxState = InitServer('a', FindConfigString(configStr));
#else
	boxState = InitServer('a', NULL);
#endif

	if(boxState)
	{
		for(;;)
		{
			DoCommand(boxState);
		}
	}

	free(boxState->session);
	boxState->session = NULL;
}

#endif


//
// Start the server up.
//
ServerState *InitServer(char connect_arg, char *config)
{
ServerState	*boxState;
char		*ani_cp;


	switch (connect_arg)
	{
	case	's':
		session_type = SESSION_STREAM;
		break;
	case	'a':
	default:
		session_type = SESSION_ADSP;
	}
	// Print their phone number from ANI for yuks.
	//
	if ((ani_cp = getenv("XBAND_ANI")) != NULL)
		PLogmsg(LOGP_DBUG, "XBAND_ANI says caller is '%s'\n", ani_cp);


	Server_LoadMessageDispatchers();
//	if (Server_SwapMessageDispatcher(kSegaIdentification) != kServerFuncOK) {
//		PLogmsg(LOGP_FLAW, "InitServer: Server boys are hosers\n");
//		return (NULL);
//	}


	boxState = NULL;
	
	PLogmsg(LOGP_PROGRESS, "Init server\n");

	boxState = (ServerState *)malloc(sizeof(ServerState));
	if(!boxState) 
	{
		PLogmsg(LOGP_FLAW, "no memory for ServerState");
	}
	else 
	{
		WrapperDB_Initialize();
		//Server_SetupAccounts();
		//Server_SetupGamePatches();

		LoadFilterFile();

		ServerState_Init(boxState, session_type, NULL, config);

		boxState->serverProgress = kServerNotListening;	// not connected

		Server_TInit(session_type);
	}

	return(boxState);
}


//
// Open a connection.
//

static ConnSession	*aGame = NULL;
static long 		numConnects = 0, numFailedConnects = 0;


int InitServerConnection(ServerState *boxState)
{

OSErr		err;
char		*config;
NetParamBlock	net;

	//DataBase_AgeWaitQ(kMaxTimeInWaitQ);

	if(boxState->configBuffer[0])
	{
		config = boxState->configBuffer;
	}
	else
	{
		config = NULL;
	}

	if(boxState->serverProgress == kServerNotListening)
	{

		aGame = (ConnSession *)malloc(sizeof(ConnSession));
		if(!aGame) 
		{
			PLogmsg(LOGP_FLAW, "no memory for ConnSession");
			ServerState_Init(boxState, session_type, NULL, NULL);
			return(-1);	// some kind of error notification, please
		}

		PLogmsg(LOGP_PROGRESS, "listening\n");

#ifdef STANDALONE
		err = Server_PListenAsync(session_type, config, kUseServerProtocol);
#else
		err = Server_PListen(session_type, config, kUseServerProtocol);
#endif
		if(err != noErr)
		{
			PLogmsg(LOGP_FLAW, "PListenAsync failed with error #%ld\n",
				(long)err);
			Server_PCheckError(boxState->session);
			ServerState_Init(boxState, session_type, NULL, config);
			free(aGame);
			aGame = NULL;
			numFailedConnects++;
			return(-1);
		}
		else
		{
			Boolean machineBusy;
	
			// ATM 950116: this was previous called from InitServer, but
			// apparently needs to be called again (try it and see if you
			// don't believe me).  I don't want to lose the value of
			// boxState->machineBusy, so we hold onto it across the call.
			//
			// It's either this, hold it in a global, or compute it later.
			// Or fix the init routines so they don't suck.
			//
			machineBusy = boxState->machineBusy;
			ServerState_Init(boxState, session_type, aGame, config);
			boxState->machineBusy = machineBusy;
	
			//
			// Start timing the connection.
			//
			boxState->timeOfThisConnect = (unsigned long)time(0);
			boxState->validFlags |= kServerValidFlag_TimeOfThisConnect;
	
			boxState->serverProgress = kServerPListening;
			Logmsg("PListen succeeded\n");
		}
	}
	
	
	if (boxState->serverProgress == kServerPListening)
	{
		
		if((err = Server_TNetIdle(session_type, &net)) != noErr)
		{
			PLogmsg(LOGP_NOTICE, "Server_TNetIdle returned error #%ld\n", err);
			Server_TCheckError(boxState->session);
			Server_PCheckError(boxState->session);
			ServerState_Init(boxState, session_type, NULL, config);
			boxState->serverProgress = kServerNotListening;
			free(aGame);
			aGame = NULL;
			numFailedConnects++;
			return(-1);
		}
	
		if(net.ioPhysNetState == kConnOpen)
		{
			boxState->serverProgress = kServerTListening;
		}
	}
	
	if(boxState->serverProgress == kServerTListening)
	{
		err = Server_TListen(aGame, -1, 0, kTListenTimeout);
		if(err != noErr)
		{
			PLogmsg(LOGP_NOTICE, "TListen failed with error #%ld\n", (long)err);
			Server_TCheckError(boxState->session);
			if(Server_PClose(boxState->session) != noErr)
				Server_PCheckError(boxState->session);

			PLogmsg(LOGP_NOTICE, "connection failed\n");
			ServerState_Init(boxState, session_type, NULL, config);
			free(aGame);
			aGame = NULL;
			boxState->serverProgress = kServerNotListening;
			numFailedConnects++;
			return(-1);
		}
		Logmsg("TListen succeeded\n");
		PLogmsg(LOGP_PROGRESS, "connected\n");
		boxState->serverProgress = kServerConnected;
			
		numConnects++;
			
		// if we are generating a tee file of the data for debugging
		if(Server_OpenDataTee(kServerWriteTeeFile, kServerReadTeeFile, kServerInputFile) != 0)
		{
			PLogmsg(LOGP_FLAW, "*** Unable to open tee file ***\n");
		}
	}
	
	return(0);
}

//
// Close a connection.
//
Boolean CloseServerConnection(ServerState *boxState)
{
Boolean	retVal;
OSErr		err;
#ifdef unix
extern long gHangupOkay;
#endif

	FPLogmsg(LOG_NETERR, LOGP_DBUG, "Reached TClose\n");
	retVal = false;
	if(boxState->validFlags & kServerValidFlag_SessionRec)
	{
		gHangupOkay = 2;		// mostly okay if box hangs up and we get SIGHUP
		PLogmsg(LOGP_PROGRESS, "Sending TClose\n");
		if( Server_TClose(boxState->session) != noErr)	// shouldn't hang anymore
			Server_TCheckError(boxState->session);
			
#ifdef unix
		gHangupOkay = 3;		// okay if box hangs up and we get SIGHUP
#endif

		err = Server_PClose(boxState->session);
		if(err != noErr)
		{
			// chances are we catch a SIGHUP before we get here
			Logmsg("PClose failed with error #%ld\n", err);
			Server_PCheckError(boxState->session);
		}

		Server_CloseDataTee();	// if we are generating a tee file of the data for debugging
	} else {
		PLogmsg(LOGP_PROGRESS, "Nobody home, not sending TClose\n");
	}

	ServerState_Empty(boxState);	// luckily doesn't clear configString
	boxState->serverProgress = kServerNotListening;	// done
	PLogmsg(LOGP_PROGRESS, "Shutting down the connection\n");

	return(0);
}


//
// Final shutdown of the server from the menu.
//
Boolean KillServer(ServerState *boxState)
{
Boolean	retVal;

	retVal = CloseServerConnection(boxState);
	
	free(boxState);

	WrapperDB_Shutdown();

	return(0);
}



//
// This is the driver loop for the server.
//
Boolean DoCommand(ServerState *boxState)
{
int		retVal;

	if(!boxState)
		return(false);

	if(boxState->serverProgress != kServerConnected)
	{
		// this is a poo hack that relies on ServerState_Empty not clearing configString
		//
		if(InitServerConnection(boxState) != 0)
		{
			Server_WriteNewBinaryLog(boxState, kConnNeverConnected);
			PLogmsg(LOGP_NOTICE, "Failed connection\n");
			return(true);
		}
	}

	if(!(boxState->validFlags & kServerValidFlag_SessionRec)){
		return(false);
	}

	ASSERT(boxState->session);

/* 8/4/94 3:54:43 PM (BET): 
	err = Server_TNetIdle(nil);
	if(err != noErr)
	{
		PLogmsg(LOGP_NOTICE, "TNetIdle returned error #%ld\n", (long)err);
		Server_TCheckError();
		retVal = kServerFuncAbort;
		goto abort;
	}
*/

	retVal = kServerFuncOK;
	
	ASSERT(boxState->serverProgress >= 0);
	
	if(boxState->serverProgress >= kServerLastAction){
		ServerState_Print(boxState);
		Server_WriteNewBinaryLog(boxState, kConnExitGraceful);
		WrapperDB_SaveToDisk();
		CloseServerConnection(boxState);
		return true;
	}

	// Fancy debugging shit.
	//
	if (boxState->magnifyMode) {
		if (boxState->account != NULL) {
			Logmsg("MAGNIFY: state %d  box.magicID=0x%.8lx\n",
				boxState->serverProgress,
				boxState->account->boxAccount.magicID);
		}
	}

	if (currentDispatcher->functions[boxState->serverProgress])
		retVal = (*currentDispatcher->functions[boxState->serverProgress])(boxState);
	else
		PLogmsg(LOGP_DBUG, "NOTE: NULL dispatcher function %d in 0x%.8lx\n",
			boxState->serverProgress, currentDispatcher->boxType);

	switch(retVal)
	{
			case kServerFuncOK:
				boxState->serverProgress++;
				break;
			case kServerFuncSkipNext:	
				boxState->serverProgress += 2;
				break;
			case kServerFuncAbort:
				boxState->serverProgress = kServerNotListening;
				Server_UpdateDataBaseAccountPartial(boxState);
				Server_WriteNewBinaryLog(boxState, kConnExitServerAbort);
				PLogmsg(LOGP_NOTICE, "Server aborting connection\n");
				CloseServerConnection(boxState);
				return true;
				break;
			case kServerFuncEnd:
				boxState->serverProgress = kServerUpdateDataBaseAccount;
				// will end next time through DoCommand()
				Logmsg("Server ending connection\n");
				break;
			case kServerFuncForceEnd:
				boxState->serverProgress = kServerLastAction;	// will end now
				retVal = Server_UpdateDataBaseAccount(boxState);
				retVal = Server_ForceEndCommunication(boxState);
				PLogmsg(LOGP_NOTICE, "Server forcing end connection\n");
				break;
	}


	return false;
}



// ===========================================================================
//		RecvComplete stuff
// ===========================================================================

int
Server_sega_RecvComplete(ServerState *state)
{
	return (Server_common_RecvComplete(state));
}

int
Server_snes_RecvComplete(ServerState *state)
{
	Err err;
	DBID id;
	long val;
	const unsigned long wantedBits =
		kRespectFifoSemaphores |		// magic TLayer stuff
		kFixFifoUnderflowInSTIdle |		// magic TLayer stuff
		kDisableHappyServerLogs |		// don't u/l server box log unless fail
		kReregisterLockout;				// don't let them re-register

	if ((err = Server_common_RecvComplete(state)) != kServerFuncOK)
		return (err);

	// Check to see if all of the desirable SNES magic SpecialModeFlags bits
	// are set.  If any are missing, set them.
	//
	val = state->niftyInfo.any.specialModeFlags;
	if ((val & wantedBits) != wantedBits)
	{
		PLogmsg(LOGP_DETAIL,
			"Setting kRespectFifoSemaphores | kFixFifoUnderflowInSTIdle | kDisableHappyServerLogs | kReregisterLockout\n");
		val |= wantedBits;
		id = kSpecialModeFlagsConst;
		if (Server_SendDBConstants(state, 1, &id, &val) != kServerFuncOK)
			return (kServerFuncAbort);

		// Update local copy so that other routines that check this won't
		// nuke our changes.
		//
		state->niftyInfo.any.specialModeFlags = val;
	}

	return (kServerFuncOK);
}

int
Server_intl_RecvComplete(ServerState *state)
{
	return (Server_common_RecvComplete(state));
}

//
// Things to do after we have received all of the data from the box.
//
// This is called "RecvComplete" and not "ReceiveComplete" so that people
// don't think is the routine that receives the "complete" structure from
// the box.
//
// This doesn't do much now that ValidateLogin once again comes after
// we've received everything.
//
PRIVATE int
Server_common_RecvComplete(ServerState *state)
{
	userIdentification  *userID;

	PLogmsg(LOGP_PROGRESS, "Server_common_RecvComplete\n");

	// Say hi.
	//
	userID = &state->loginData.userID;
	Logmsg("Connection from box # (%ld,%ld)[%ld]\n", userID->box.box,
		userID->box.region, (long)userID->userID);

	// Check if XBAND is online or not.  *NO* RPC connections should have
	// been attempted before now.
	//
	if(!Server_IsXBANDOnline(state)) {
		Logmsg("END: NoLogin file exists\n");
		return (kServerFuncEnd);
	}

	// Check if the max process count has been exceeded.
	//
	if (state->machineBusy) {
		Server_SendDialog(state,
			gettext("Whoa! Major traffic jam. XBAND's systems are overloaded. Please try to connect again in a few minutes."),	/*DIALOG*/
			true);
		Logmsg("END: machineBusy set\n");
		return (kServerFuncEnd);
	}
	// Get a connect cookie.
	//
	state->connid = DataBase_GetConnectCookie();
	Logmsg("Unique Connect Cookie = %lu\n", state->connid);

	return (kServerFuncOK);
}


//
// If there is an "NoLogin.sunsega" file, read it and send as a dialog to the
// box, then shutdown SunSega, because the existence of that file indicates
// that XBAND is down.
//
PRIVATE Boolean
Server_IsXBANDOnline(ServerState *state)
{
FILE			*nologinFP;
char 			linebuf[1000];

	if((nologinFP = fopen(kNoLoginFile, "rb")))
	{
		fgets(linebuf, 1000, nologinFP);
		linebuf[999] = 0;
		
		if (!feof(nologinFP) && !ferror(nologinFP))
		{
			Server_SendLargeDialog(state, linebuf, true);
		}
		
		fclose(nologinFP);
		return(false);	// XBAND is down.
	}
	
	return(true);		// XBAND is up.
}



// ===========================================================================
//		Dispatcher table initialization & selection
// ===========================================================================

//
// Find the appropriate platform, then find the appropriate dispatcher
// inside.
//
int
Server_SwapMessageDispatcher(ServerState *state, long boxType)
{
	int i, j;

	for (i = 0; i < NELEM(platforms); i++) {
		if ((platforms[i].platformID & platforms[i].platformIDMask) ==
			(boxType & platforms[i].platformIDMask))
		{
			for (j = 0; j < platforms[i].numDispatchers; j++) {
				if (platforms[i].dispatchers[j].boxType == boxType) {
					Logmsg("Using message dispatcher for %s [%.4s]\n",
						platforms[i].platformName, (char *)&boxType);
					currentDispatcher = &platforms[i].dispatchers[j];
					state->platformID = platforms[i].platformID;
					state->boxType = boxType;
					state->validFlags |= kServerValidFlag_platformID;
					return (kServerFuncOK);
				}
			}
			PLogmsg(LOGP_NOTICE,
				"ERROR: Unable to find dispatcher for %s 0x%.8lx\n",
				platforms[i].platformName, boxType);
			return (kServerFuncAbort);
		}
	}
	
	PLogmsg(LOGP_NOTICE, "ERROR: unknown box ROM version 0x%.8lx\n", boxType);
	return(kServerFuncAbort);
}


//
// Allocate space for the message dispatcher tables, and call their init
// routine.
//
// Sets currentDispatcher to a dispatcher that will work for the first
// part of the connect with any box.
//
void
Server_LoadMessageDispatchers(void)
{
	int i, j;

	// Allocate space for the dispatcher tables, and init them.
	//
	for (i = 0; i < NELEM(platforms); i++) {
		platforms[i].dispatchers = (MessageDispatcher *)
			malloc(sizeof(MessageDispatcher) * platforms[i].numDispatchers);

		for (j = 0; j < platforms[i].numDispatchers; j++) {
			(platforms[i].dispInitFunc)(&platforms[i].dispatchers[j],
				platforms[i].boxTypes[j]);
		}
	}

	// Set a default dispatcher so we can get started.  We could use a
	// special "generic" one, but we might as well just grab whatever
	// comes first.
	//
	currentDispatcher = &platforms[0].dispatchers[0];
}


//
// Init the dispatcher table for all flavors of Sega Genesis ROMs.
//
void
Server_sega_InitDispatcher(MessageDispatcher *dispatcher, long boxType)
{
	ASSERT(dispatcher);

	PLogmsg(LOGP_PROGRESS,"Server_sega_InitDispatcher (0x%.8lx)\n", boxType);

	// Start with the generic routines.
	//
	Server_generic_InitDispatcher(dispatcher);
	dispatcher->boxType = boxType;

	// Replace the routines that all Genesis boxes need.
	//
	dispatcher->functions[kServerReceiveLogin] 				= Server_sega_ReceiveLogin;
	dispatcher->functions[kServerSendRequestData]			= Server_sega_SendRequestData;
	dispatcher->functions[kServerDownloadKoolStuff] 		= Server_sega_DownloadKoolStuff;
	dispatcher->functions[kServerSendAccountInfo] 			= Server_sega_SendAccountInfo;
	dispatcher->functions[kServerReceiveGameResults] 		= Server_sega_ReceiveGameResults;
	dispatcher->functions[kServerReceiveNetErrors]			= Server_sega_ReceiveNetErrors;
	dispatcher->functions[kServerReceiveRequestedData]		= Server_sega_ReceiveRequestedData;
	dispatcher->functions[kServerRecvComplete] 				= Server_sega_RecvComplete;
	dispatcher->functions[kServerUpdateMiscPrefs] 			= Server_sega_UpdateMiscPrefs;

	// Replace routines that particular ROM versions need.
	//
	switch (boxType) {
	case kBoxType_segc:
		// Do Sega1.1 stuff here.
		//
		break;
	}
}

//
// Init the dispatcher table for all flavors of SNES ROMs.
//
void
Server_snes_InitDispatcher(MessageDispatcher *dispatcher, long boxType)
{

	ASSERT(dispatcher);

	PLogmsg(LOGP_PROGRESS,"Server_snes_InitDispatcher (0x%.8lx)\n", boxType);

	// Start with the generic routines.
	//
	Server_generic_InitDispatcher(dispatcher);
	dispatcher->boxType = boxType;

	// Replace the routines that only SNES boxes need.
	//
	dispatcher->functions[kServerReceiveLogin] 				= Server_snes_ReceiveLogin;
	dispatcher->functions[kServerSendRequestData]			= Server_snes_SendRequestData;
	dispatcher->functions[kServerDownloadKoolStuff] 		= Server_snes_DownloadKoolStuff;
	dispatcher->functions[kServerSendAccountInfo] 			= Server_snes_SendAccountInfo;
	dispatcher->functions[kServerReceiveInterestingDBConstants] = Server_snes_ReceiveInterestingDBConstants;
	dispatcher->functions[kServerReceiveGameResults] 		= Server_snes_ReceiveGameResults;
	dispatcher->functions[kServerReceiveNetErrors]			= Server_snes_ReceiveNetErrors;
	dispatcher->functions[kServerReceiveBoxLogs]			= Server_snes_ReceiveBoxLogs;
	dispatcher->functions[kServerReceiveRequestedData]		= Server_snes_ReceiveRequestedData;
	dispatcher->functions[kServerRecvComplete] 				= Server_snes_RecvComplete;
	dispatcher->functions[kServerUpdateMiscPrefs] 			= Server_snes_UpdateMiscPrefs;
	//dispatcher->functions[kServerTests]						= Server_snes_SendTests;

	// Replace routines that particular ROM versions need.
	//
	switch (boxType) {
	case kBoxType_sn07:
		// Nothing to do.
		//
		break;
	case kBoxType_sj01:
		break;
	}
}

//
// Init the dispatcher table for Intel "ROM"s.
//
void
Server_intl_InitDispatcher(MessageDispatcher *dispatcher, long boxType)
{
	ASSERT(dispatcher);

	PLogmsg(LOGP_PROGRESS, "Server_intl_InitDispatcher (0x%.8lx)\n", boxType);

	// Start with the generic routines.
	//
	//Server_generic_InitDispatcher(dispatcher);

	// (for now, it's easier to zero it and just add the few we want)
	memset(dispatcher, 0, sizeof(MessageDispatcher));
	dispatcher->boxType = boxType;

	// Replace the routines that only Intel stuff needs.
	//
	/**/dispatcher->functions[kServerStartConnection]			= Server_StartConnection;
	dispatcher->functions[kServerReceiveLogin] 				= Server_snes_ReceiveLogin;
	dispatcher->functions[kServerDownloadKoolStuff] 		= Server_intl_DownloadKoolStuff;
	/**/dispatcher->functions[kServerReceiveGameID] 			= Server_ReceiveGameID;
	/**/dispatcher->functions[kServerReceiveCompetitiveChallenge] = Server_ReceiveCompetitiveChallenge;
	/**/dispatcher->functions[kServerRecvComplete] 				= Server_intl_RecvComplete;
	/**/dispatcher->functions[kServerValidateLogin]				= Server_ValidateLogin;
	/**/dispatcher->functions[kServerStartGamePlay] 			= Server_StartGamePlay;
	/**/dispatcher->functions[kServerUpdateDataBaseAccount] 	= Server_UpdateDataBaseAccount;
	/**/dispatcher->functions[kServerEndCommunication] 			= Server_EndCommunication;


	// Replace routines that particular "ROM" versions need.
	//
	switch (boxType) {
	case 0:
		// These are now dead; we shouldn't be here.
		//
		PLogmsg(LOGP_FLAW, "ERROR: bad box type\n");
		Common_Abort();
		break;

	case kBoxType_in00:
		// Nothing to do.
		//
		break;
	}
}

//
// Init the dispatcher table with generic stuff.
//
// This starts by erasing the entire table to zero, so wait until after you
// call it to set the boxType field.
//
void
Server_generic_InitDispatcher(MessageDispatcher *dispatcher)
{
	ASSERT(dispatcher);

	memset(dispatcher, 0, sizeof(MessageDispatcher));

	dispatcher->functions[kServerStartConnection]			= Server_StartConnection;
	//dispatcher->functions[kServerSendRequestData]			= Server_SendRequestData;
	dispatcher->functions[kServerReceiveBoxType]			= Server_ReceiveBoxType;
	//dispatcher->functions[kServerReceiveLogin] 				= Server_ReceiveLogin;
	dispatcher->functions[kServerReceiveCreditDebitInfo] 	= Server_ReceiveCreditDebitInfo;
	dispatcher->functions[kServerReceiveGameID] 			= Server_ReceiveGameID;
	dispatcher->functions[kServerReceiveSystemVersion] 		= Server_ReceiveSystemVersion;
	dispatcher->functions[kServerReceiveCompetitiveChallenge] = Server_ReceiveCompetitiveChallenge;
	dispatcher->functions[kServerReceiveNGP] 				= Server_ReceiveNGP;
	dispatcher->functions[kServerReceiveInterestingDBConstants]	= NULL;
	dispatcher->functions[kServerReceiveSendQ] 				= Server_ReceiveSendQ;
	dispatcher->functions[kServerReceiveAddressBookValidationQueries] = Server_ReceiveAddressBookValidationQueries2;
	dispatcher->functions[kServerReceiveMail] 				= Server_ReceiveMail;
	dispatcher->functions[kServerReceiveGameResults] 		= NULL;
	dispatcher->functions[kServerReceiveGameErrorResults]	= Server_ReceiveGameErrorResults;
	//dispatcher->functions[kServerReceiveNetErrors]			= Server_ReceiveNetErrors;
	dispatcher->functions[kServerUpdateGameResults] 		= Server_UpdateGameResults;
	dispatcher->functions[kServerReceivePersonification] 	= Server_ReceivePersonification;
	//dispatcher->functions[kServerReceiveRequestedData]		= Server_ReceiveRequestedData;

	//dispatcher->functions[kServerRecvComplete] 				= Server_RecvComplete;

	dispatcher->functions[kServerValidateLogin]				= Server_ValidateLogin;
	dispatcher->functions[kServerCheckAccountCredits]		= Server_CheckAccountCredits;
	dispatcher->functions[kServerValidateInitialSystemPatch] = Server_ValidateInitialSystemPatch;

	//dispatcher->functions[kServerDownloadKoolStuff] 		= Server_DownloadKoolStuff;
	dispatcher->functions[kServerValidateSystem]			= Server_ValidateSystem;
	dispatcher->functions[kServerGeneralBoxUpdate]			= Server_GeneralBoxUpdate;
	//dispatcher->functions[kServerUpdateMiscPrefs] 			= Server_UpdateMiscPrefs;
	dispatcher->functions[kServerUpdateNGPVersion] 			= Server_UpdateNGPVersion;
	dispatcher->functions[kServerUpdateGamePatch] 			= Server_UpdateGamePatch;
	dispatcher->functions[kServerProcessSendQ] 				= Server_ProcessSendQ;
	dispatcher->functions[kServerProcessIncomingMail] 		= Server_ProcessIncomingMail;
	dispatcher->functions[kServerSendMail] 					= Server_SendMail;
	dispatcher->functions[kServerProcessAddrBookValidations] = Server_ProcessAddrBookValidations;
	dispatcher->functions[kServerSendClearSendQ] 			= Server_SendClearMiscQueues;
	dispatcher->functions[kServerUpdateDebitCard] 			= Server_UpdateDebitCard;
	//dispatcher->functions[kServerSendAccountInfo] 			= Server_SendAccountInfo;
	dispatcher->functions[kServerSendRanking] 				= Server_SendRanking;
	dispatcher->functions[kServerSendDateAndTime] 			= Server_SendDateAndTime;
	dispatcher->functions[kServerProcessPersonifications]	= Server_ProcessPersonifications;
	dispatcher->functions[kServerStartGamePlay] 			= Server_StartGamePlay;
	dispatcher->functions[kServerSendProblemToken] 			= NULL;
	dispatcher->functions[kServerSendValidationToken] 		= NULL;
	dispatcher->functions[kServerUpdateDataBaseAccount] 	= Server_UpdateDataBaseAccount;
	dispatcher->functions[kServerEndCommunication] 			= Server_EndCommunication;
}

