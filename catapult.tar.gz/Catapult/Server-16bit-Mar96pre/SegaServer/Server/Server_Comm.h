/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Comm.h,v 1.4 1996/01/31 18:02:25 hufft Exp $
 *
 * $Log: Server_Comm.h,v $
 * Revision 1.4  1996/01/31  18:02:25  hufft
 * UDP socket changes
 *
 * Revision 1.3  1996/01/25  17:51:45  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.2  1995/05/26  23:46:09  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_Comm.h

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		 <3>	  8/2/94	DJ		Server_SetTransportHold
		 <2>	 7/25/94	DJ		added async listen
		 <1>	 7/20/94	DJ		first checked in

	To Do:
*/


#ifndef __ServerComm__
#define __ServerComm__

#include	<sys/types.h>
#include	<errno.h>
#include	"TransportStructs.h"
#include	"TransportLayer.h"
#include	"PhysicalLayer.h"
#include	"inet.h"

//
// Stuff for communicating via a file instead of modem (for debugging).
//
#define kWriteTeeFile		"WriteData.tee"
#define kReadTeeFile		"ReadData.tee"
#define kInputFile			"InputData.tee"

// no timeout for TListen, the alarm process should catch the server
#define kTListenTimeout	0

typedef	struct	_QUEUE	{
	void	*next;
	void	*prev;
}	_QUEUE, *_QUEUE_P;


typedef	struct	UdpPacket	{
	_QUEUE		q;
	char		*data_p;
	u_char		type;
	u_char		seq;
	u_short		length;
	u_short		crc;
	u_short		reserved;
	char		data[1];
} UdpPacket, *UdpPacket_P;

typedef enum
{
	SESSION_NONE = -1,
	SESSION_STREAM,
	SESSION_ADSP
} SessionType;

typedef	enum	{
	UDP_PK_TYPE_HELLO = 0,
	UDP_PK_TYPE_DATA,
	UDP_PK_TYPE_ACK,
	UDP_PK_TYPE_BYE
} UDP_PK_TYPE;

typedef struct StreamRec
{
	int				infd;
	int 			outfd;
	u_long 			nread;
	u_long 			nwritten;
	Boolean 		buffer;
	Boolean 		closed;			// if true then connection closed
	u_char			in_seq;			// next inbound seq#
	u_char			out_seq;		// next outbound seq#
	UdpPacket_P		q_in_p;			// input packet queue
	UdpPacket_P		in_p;			// input packet
	UdpPacket_P		q_out_p;		// output packet queue
	UdpPacket_P		out_p;			// output packet
	SOCKADDR_IN		sockaddr_in;	// clients UDP socket addr
	int				sockaddr_len;	// length of socket protocol
	int				in_timeout;		// in milliseconds
	int				out_timeout;	// out milliseconds
	int				error;			// error state
} StreamRec, *StreamRec_P;

typedef struct ConnSession {
	SessionType type;
	union {
		StreamRec stream;
		SessionRec adsp;
	} rec;
} ConnSession, *ConnSession_P;

//
// These are wrappers for TransportLayer TReadDataSync and TWriteDataSync
//

int		Server_OpenDataTee(char *writeoutname, char *readoutname, char *inputfilename);
int		Server_CloseDataTee(void);

short 	Server_TNetIdle(SessionType type, NetParamBlock *pBlock);
OSErr	Server_TListen(ConnSession_P s, PortT localPort, PortT remPort, u_long timeout);
OSErr	Server_TClose(ConnSession_P s);
void	Server_TInit(SessionType);
OSErr	Server_TReadDataSync(ConnSession_P sess, u_long length, Ptr address);
OSErr	Server_TWriteDataSync(ConnSession_P sess, u_long length, Ptr address);
OSErr	Server_TCheckError(ConnSession_P);

OSErr	Server_PListen(SessionType type, char *config, long flags);
OSErr	Server_PListenAsync(SessionType type, char *config, long flags);
OSErr	Server_PClose(ConnSession_P);
OSErr	Server_PCheckError(ConnSession_P);

void 	Server_SetTransportHold(ConnSession_P, Boolean hold);
#endif
