/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Personification.h,v 1.3 1995/06/19 20:33:32 fadden Exp $
 *
 * $Log: Server_Personification.h,v $
 * Revision 1.3  1995/06/19  20:33:32  fadden
 * Changed Server_ReadCustomIcon from "void" to "Err".
 *
 * Revision 1.2  1995/05/26  23:46:39  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_Personification.h

	Contains:	xxx put contents here xxx

	Written by:	Brian Topping


	Change History (most recent first):

		 <6>	11/21/94	DJ		Added Server_ClearCustomIcon.
		 <5>	10/13/94	DJ		Made Server_SendPersonification callable from Server_RestoreBox
		 <4>	 8/15/94	DJ		sendpersonification
		 <3>	 8/11/94	DJ		new personifuckation that takes/sends a flag of what changed
		 <2>	 8/10/94	DJ		deletepersonification
		 <1>	  8/4/94	BET		first checked in

	To Do:
*/

#ifndef __Server_Personification__
#define __Server_Personification__

#include "ServerState.h"

int Server_GetPersonificationFromWire( ServerState *state, PersonificationSetupRec *OPers, unsigned char flags );
void Server_PutPersonificationOnWire( ServerState *state, PersonificationSetupRec *PSR );
void Server_DeletePersonification( PersonificationSetupRec *OPers );
void Server_SendPersonification(ServerState *state, PlayerAccount *playerAccount, unsigned char flags);

// Read an icon from /opt/catapult/conf (current directory for SunSega) and
// attach to account.
//
Err Server_ReadCustomIcon(ServerState *state, char *iconFile);
void Server_ClearCustomIcon(ServerState *state);

#endif
