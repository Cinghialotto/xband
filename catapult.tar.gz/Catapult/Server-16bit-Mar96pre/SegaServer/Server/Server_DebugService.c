/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_DebugService.c,v 1.2 1995/05/26 23:46:15 jhsia Exp $
 *
 * $Log: Server_DebugService.c,v $
 * Revision 1.2  1995/05/26  23:46:15  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_DebugService.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		 <7>	 9/19/94	ATM		PLogmsg stuff.
		 <6>	 8/16/94	DJ		turned off printfs
		 <5>	 8/11/94	ATM		Convert to Logmsg.
		 <4>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		 <3>	  7/1/94	DJ		making server handle errors in Comm layer
		 <2>	 6/10/94	DJ		commented out the loopback
		 <1>	  6/4/94	DJ		first checked in

	To Do:
*/


// #define LOOPBACKTEST	1		// does a loopback of LOOPBACKNUM before every message.
#define kLOOPBACKNUM		100


#include "ServerCore.h"
#include "Server.h"
#include "Messages.h"
#include <stdio.h>


//
// This gets called heavily by the KoolStuff routines.
//
int Server_DebugService(ServerState *state)
{
short retVal;

	//PLogmsg(LOGP_PROGRESS, "Server_DebugService\n");
	retVal = kServerFuncOK;

#ifdef LOOPBACKTEST
	retVal = Server_SendLoopback(state, kLOOPBACKNUM);
#endif

	//PLogmsg(LOGP_PROGRESS, "Server_DebugService done\n");
	return(retVal);
}


