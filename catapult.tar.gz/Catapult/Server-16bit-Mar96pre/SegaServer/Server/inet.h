#ifndef	__inet_h
#define	__inet_h
#include	<stdio.h>
#include	<errno.h>
#include	<sys/types.h>
#include	<sys/socket.h>
#include	<netinet/in.h>
#include	<arpa/inet.h>
typedef	struct	sockaddr	SOCKADDR, *SOCKADDR_P;
typedef	struct	sockaddr_in	SOCKADDR_IN, *SOCKADDR_IN_P;
int	poll_dg(int sockfd, int delay);
int	send_dg(int sockfd, char *data, int len, SOCKADDR_P to_addr_p, int to_len);
int	recv_dg(int sockfd, char *data, int len, SOCKADDR_P from_addr_p, int *from_len, int timeout);
#endif
