/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_GameSpecific.c,v 1.27 1996/02/13 20:27:01 fadden Exp $
 *
 * $Log: Server_GameSpecific.c,v $
 * Revision 1.27  1996/02/13  20:27:01  fadden
 * Declare some read-only tables as "const".
 *
 * Revision 1.26  1996/02/08  13:24:08  steveb
 * Changed the log level of the game results spooge from LOGP_DBUG to LOGP_INFO
 * so they'll get printed at level 30.
 *
 * Revision 1.25  1995/12/11  18:00:31  ansell
 * Moved some PLogmsg()s from DBUG up to higher priority since they represented
 * error conditions.
 *
 * Revision 1.24  1995/10/02  17:37:54  ansell
 * Added entry for SJNES in the game specific jump table.
 *
 * Revision 1.23  1995/09/13  15:58:19  fadden
 * Server_GetNumWins now uses Generic if game not found in gsjtp.
 *
 * Revision 1.22  1995/09/10  22:33:35  fadden
 * Added Server_CompleteEnough.  Changed CheckReset so it calls Generic
 * routine when game is found but no entry exists in game specific tab.
 *
 * Revision 1.21  1995/08/25  17:41:32  fadden
 * Use WinAnalysis structs instead of computing win/loss/tie directly.
 *
 * Revision 1.20  1995/08/03  12:30:34  fadden
 * Check for kGIFlagResetEnable in Server_CheckReset.  Use PossiblyLosing
 * in GenericCheckReset instead of score comparison.
 *
 * Revision 1.19  1995/08/02  22:35:49  fadden
 * Check the score in GenericCheckReset.
 *
 * Revision 1.18  1995/07/31  21:21:22  fadden
 * Added GenericCheckReset.
 *
 * Revision 1.17  1995/07/28  16:34:51  ansell
 * Re-wrote FLoghexdump2 calls for more flexible logging routine.
 *
 * Revision 1.16  1995/07/12  17:30:31  ansell
 * Prepended magic cookie to "Game Result" type logs messages.
 *
 * Revision 1.15  1995/07/10  21:00:06  rich
 * Added Japanese SNES platform (kPlatformSJNES).
 *
 * Revision 1.14  1995/05/26  23:46:17  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_GameSpecific.c

	Contains:	High-level handling of game-specific stuff.

	Written by:	Andy McFadden


	Change History (most recent first):

		<24>	12/13/94	ATM		If a JAMs game hasn't started yet, zero out the scores (getting
									funky stuff passed up by the game patch).
		<23>	 12/2/94	ATM		Show a lower case 's' for the "no matchup" cases.
		<22>	 12/2/94	ATM		"No matchup" doesn't apply to master.
		<21>	 12/2/94	ATM		Say "No matchup occurred" if no matchup occurred since the last
									time we were on a queue.
		<20>	11/28/94	ATM		Fix printing of "Matched up at" date.
		<19>	11/27/94	ATM		Added table entry for Madden '95.
		<18>	11/25/94	ATM		Swapped totalVBLs and skippedVBLs in NHL results (longword
									alignment prob).
		<17>	11/23/94	ATM		Added "Matched up at" line to game results.
		<16>	11/23/94	ATM		Added PossiblyLost stuff.  Updated structs for JAMs and NHL.
		<15>	11/19/94	ATM		Show master vs slave in game results.
		<14>	11/18/94	ATM		Jams playTime==6 is acceptable (double overtime).
		<13>	11/17/94	KD		Update server dialog text (doug/kon).
		<12>	11/14/94	ATM		Show gameResult->connectPhase.
		<11>	 11/5/94	ATM		Changed the values for JAMs win percentages.
		<10>	 11/2/94	ATM		New win percentage calc stuff.
		 <9>	10/28/94	ATM		Rearranged the reset stuff slightly.
		 <8>	10/24/94	ATM		Added different return values for CheckReset (clean, maybe,
									evil).
		 <7>	10/20/94	DJ		Added "dialog" in caps comment on same line as server dialogs
									(useful for greping).
		 <6>	10/19/94	ATM		Moved DumpGameResult in here.  Show username and full phone
									number in results.
		 <5>	10/19/94	ATM		Added a return.
		 <4>	10/18/94	ATM		Fixed thing with Jams.
		 <3>	10/18/94	ATM		Fix MK reset detection.
		 <2>	10/17/94	ATM		Implemented reset detection.
		 <1>	10/17/94	ATM		first checked in

	To Do:
*/


#include <sys/types.h>
#include <time.h>

#include "Server.h"
#include "Common_PlatformID.h"
#include "Server_GameSpecific.h"
#include "Common.h"

#include "Errors.h"


//
// Local functions
//
PRIVATE GameSpecificJumpTable *Server_LookupGameSpecific(const long platformID,
	const long gameID);
PRIVATE void DumpGenericGameResult(const ServerState *state,
	const NewGameResult *gameResult, const int isErr);
PRIVATE Err GenericPossiblyLosing(const ServerState *state,
	const NewGameResult *gameResult);
PRIVATE int Server_any_LookupGameSpecific(const long gameID,
	GameSpecificJumpTable **gsjtpp);


// ===========================================================================
//		High-Level Stuff
// ===========================================================================

//
// Look up a game in the gameSpecific table for the appropriate platform.
//
PRIVATE GameSpecificJumpTable *
Server_LookupGameSpecific(const long platformID, const long gameID)
{
	GameSpecificJumpTable *gsjtp = NULL;
	long canonicalGameID;

	SubDispatcher subDisp[] = {
		{ kPlatformGenesis,	kPlatformGenesisMask,	Server_sega_LookupGameSpecific },
		{ kPlatformSNES,	kPlatformSNESMask,		Server_snes_LookupGameSpecific },
		{ kPlatformSJNES,	kPlatformSJNESMask,		Server_sjne_LookupGameSpecific },
		{ kPlatformAny,		0,						Server_any_LookupGameSpecific },
		{ 0,				0,						NULL },		// blorph
	};

	//PLogmsg(LOGP_PROGRESS, "Server_LookupGameSpecific (%.4s-0x%.8lx)\n",
	//	(char *)&platformID, gameID);

	canonicalGameID = Common_GetCanonicalGameID(platformID, gameID);

	(Common_SubDispatch(platformID, subDisp))(canonicalGameID, &gsjtp);
	return (gsjtp);
}

PRIVATE int
Server_any_LookupGameSpecific(const long gameID, GameSpecificJumpTable **gsjtpp)
{
	PLogmsg(LOGP_FLAW,
		"GLITCH: unknown platform in LookupGameSpecific (gameID=0x%.8lx)\n",
		gameID);
	*gsjtpp = NULL;
	return (0);
}


//
// Dump the contents of a kGameResultDataDBID SendQ item.  The first word
// of the sendQ stuff must be the gameID.
//
Err
Server_DumpGameResultSendQ(const ServerState *state, const unsigned char *data,
	const long size)
{
	GameSpecificJumpTable *gsjtp;
	long gameID, cookie;

	ASSERT(data != NULL);
	cookie = Server_GetMatchCookie(state);
	gameID = *((long *) data);
	if ((gsjtp = Server_LookupGameSpecific(state->platformID, gameID)) ==NULL ||
		(gsjtp->displaySendQ == NULL))
	{
		FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
			"%ld-  No format routine for %.4s-0x%.8lx, dumping hex\n",
			cookie, (char *)&state->platformID, gameID);
		FLoghexdump2(LOG_GAMERESULT, data, size, "%ld-", cookie);
	} else {
		(*gsjtp->displaySendQ)(data, size, cookie);
	}
	return (kNoError);
}


//
// Dump the generic and gameReserved fields of a gameResult structure.
//
Err
Server_DumpGameResult(const ServerState *state,
	const NewGameResult *gameResult, int isErr)
{
	GameSpecificJumpTable *gsjtp;
	long gameID, cookie;

	cookie = Server_GetMatchCookie(state);

	if (gameResult != NULL) {
		gameID = gameResult->gameID;
		DumpGenericGameResult(state, gameResult, isErr);
	} else {
		FPLogmsg(LOG_GAMERESULT, LOGP_FLAW,
			"%ld- DumpGameResult: Unable to get gameID!\n", cookie);
		return (kNoError);
	}

	if ((gsjtp = Server_LookupGameSpecific(state->platformID, gameID)) ==NULL ||
		(gsjtp->displayGameResult == NULL))
	{
		FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "%ld- No format routine\n", cookie);
		//FLoghexdump(LOG_GAMERESULT, data, size);
	} else {
		(*gsjtp->displayGameResult)(gameResult, cookie);
	}
	return (kNoError);
}

//
// Returns kNoError if everything went okay, kFucked if not.  Uses
// GenericGetNumWins if no method is defined.
//
Err
Server_GetNumWins(const long platformID, const NewGameResult *gameResult,
	long *p1wins, long *p2wins)
{
	GameSpecificJumpTable *gsjtp;

	if (gameResult == NULL)
		return (kFucked);
	if ((gsjtp = Server_LookupGameSpecific(platformID, gameResult->gameID)) == NULL)
	{
		FPLogmsg(LOG_GAMERESULT, LOGP_NOTICE,
			" Attempt to score unknown game %.4s-0x%.8lx, using Generic\n", 
			(char *)&platformID, gameResult->gameID);
		return (GenericGetNumWins(gameResult, p1wins, p2wins));
	}
	if (gsjtp->getNumWins == NULL) {
		return (GenericGetNumWins(gameResult, p1wins, p2wins));
	} else {
		return ((*gsjtp->getNumWins)(gameResult, p1wins, p2wins));
	}
	/*NOTREACHED*/
}

//
// Check to see if an apparently clean game should not be scored for some
// obscure reason (e.g. one-quarter play mode on Jams).
//
// Returns kNoError if the game should be scored, kFucked if not.
//
Err
Server_ShouldGameBeScored(const ServerState *state,
	const NewGameResult *gameResult)
{
	GameSpecificJumpTable *gsjtp;
	long gameID, cookie;

	cookie = Server_GetMatchCookie(state);

	if (gameResult != NULL)
		gameID = gameResult->gameID;
	else {
		FPLogmsg(LOG_GAMERESULT, LOGP_FLAW,
			"%ld- ShouldGameBeScored: Unable to get gameID!\n", cookie);
		return (kNoError);
	}
	if ((gsjtp = Server_LookupGameSpecific(state->platformID, gameID)) ==NULL ||
		(gsjtp->checkScorable == NULL))
	{
		//FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "%ld- No scorable check routine\n", cookie);
		return (kNoError);
	} else {
		return ((*gsjtp->checkScorable)(state, gameResult));
	}
	/*NOTREACHED*/
}

//
// Determine if the player was possibly losing.  For some games (like MK)
// it's more certain (unless there was a tie).  For others (like JAMs) there's
// a point where they could've just barely pulled ahead and then pulled the
// phone cord out.
//
// Returns kNoError if he was winning, kFucked if he was possibly losing.
//
Err
Server_PossiblyLosing(const ServerState *state, const NewGameResult *gameResult)
{
	GameSpecificJumpTable *gsjtp;
	long gameID, cookie;

	cookie = Server_GetMatchCookie(state);

	if (gameResult != NULL)
		gameID = gameResult->gameID;
	else {
		FPLogmsg(LOG_GAMERESULT, LOGP_FLAW,
			"%ld- PossiblyLosing: Unable to get gameID!\n", cookie);
		return (kNoError);
	}
	if ((gsjtp = Server_LookupGameSpecific(state->platformID, gameID)) ==NULL ||
		(gsjtp->checkScorable == NULL))
	{
		FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
			"%ld- No possibly losing routine, using generic\n", cookie);
		return (GenericPossiblyLosing(state, gameResult));
	} else {
		return ((*gsjtp->possiblyLosing)(state, gameResult));
	}
	/*NOTREACHED*/
}

//
// Check to see if reset was hit in the middle of a game.  We should
// not be here unless we know that the user at least hit reset or turned
// the power off.
//
// Returns kNoError if the reset was acceptable, kResetDefinite or
// kResetMaybe if the guy was a fucker, or kResetUnknown if we don't
// have a routine that checks it yet.
//
Err
Server_CheckReset(const ServerState *state, const NewGameResult *gameResult,
	const NewGameResult *gameErrorResult)
{
	GameSpecificJumpTable *gsjtp;
	long gameID, cookie;
	const GameInfo *gi = NULL;

	cookie = Server_GetMatchCookie(state);

	if (gameResult != NULL)
		gameID = gameResult->gameID;
	else if (gameErrorResult != NULL)
		gameID = gameErrorResult->gameID;
	else {
		FPLogmsg(LOG_GAMERESULT, LOGP_FLAW,
			"%ld- CheckReset: Unable to get gameID!\n", cookie);
		return (kResetUnknown);
	}

	// Check the GIFlags to see if reset checking is on at all.
	//
	if ((gi = Common_GameInfoForGame(state->platformID, gameID)) == NULL) {
		PLogmsg(LOGP_FLAW, "ERROR: unable to find game info for %.4s-0x%.8lx\n",
			(char *)&state->platformID, gameResult->gameID);
		return (kResetUnknown);
	} else if (!(gi->gameInfoFlags & kGIFlagResetEnable)) {
		FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "%ld- Reset not enabled\n", cookie);
		return (kNoError);
	}

	if ((gsjtp = Server_LookupGameSpecific(state->platformID, gameID)) ==NULL ||
		(gsjtp->checkReset == NULL))
	{
		FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
			"%ld- No reset check routine, using generic\n", cookie);
		return (GenericCheckReset(state, gameResult, gameErrorResult));
	} else {
		return ((*gsjtp->checkReset)(state, gameResult, gameErrorResult));
	}
	/*NOTREACHED*/
}


//
// Determine whether an incomplete game was complete enough to be worth
// treating as a full game.
//
// Josh says (from a Mac):
//
// There are two different concepts here, which are only somewhat related.
// Concept 1 is the concept of "sufficient for a win". This is based on
// score delta within
//		the context of when the failure occured.
// Concept 2 is the concept of "enough of the game completed to snarf a
// credit". This is related.
//		For now, concept 2 must be true for concept 1 to say anything other
// than "do nothing", but
//		that is not necesarily so! (But for now, we'll do it this way so
// people can't use the
//		one-sided win stuff to get lots of points w/o paying credits.
//
// Returns one of:
//	kNotEnoughCompletedTie
//	kEnoughCompletedTie
//	kEnoughCompletedLocalWinner
//	kEnoughCompletedRemoteWinner
//
// (Blame for this stuff goes to Josh.)
//
Err Server_CompleteEnough(const ServerState *state,
	const NewGameResult *gameErrorResult)
{
	GameSpecificJumpTable *gsjtp;
	long gameID, cookie;

	cookie = Server_GetMatchCookie(state);

	if (gameErrorResult != NULL)
		gameID = gameErrorResult->gameID;
	else {
		FPLogmsg(LOG_GAMERESULT, LOGP_FLAW,
			"%ld- CompleteEnough: Unable to get gameID!\n", cookie);
		return (kNoError);
	}
	if ((gsjtp = Server_LookupGameSpecific(state->platformID, gameID)) ==NULL ||
		(gsjtp->completeEnough == NULL))
	{
		FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
			"%ld- No completeEnough routine, returning incomplete\n", cookie);
		return (kNotEnoughCompletedTie);
	} else {
		return ((*gsjtp->completeEnough)(gameErrorResult));
	}
	/*NOTREACHED*/
}



// ===========================================================================
//		Generic
// ===========================================================================

//
// Dump the generic part of the game results into the log.  We want to
// do this here instead of Server_ReceiveGameID.c because we want to show
// the full phone number and the UserName from the LastMatchup struct.
//
PRIVATE void
DumpGenericGameResult(const ServerState *state,
	const NewGameResult *gameResult, const int isErr)
{
	Account *account = state->account;
	long structSize, extraSize, cookie;
	char timebuf[32];		// actually 26
	int masterChar;			// master the possibilities

	ASSERT(state->validFlags & kServerValidFlag_Account);

	cookie = Server_GetMatchCookie(state);

	structSize = ((unsigned char *)&gameResult->pad) -
		((unsigned char *)gameResult);

	FPLogmsg(LOG_GAMERESULT, LOGP_INFO,
		"%ld-%s Results for %s (%s) [size=%ld]:\n",
		cookie,
		isErr ? "Game Error" : "Game",
		state->account->playerAccount.userName,
		state->account->boxAccount.gamePhone.phoneNumber,
		gameResult->size);

	// If he was the master or was a slave and the matchup occurred while
	// he was on a queue, print the appropriate info.  Otherwise, nobody
	// was matched to him, and the stats he is printing are the result of
	// a voice call.
	//
	masterChar = Server_BoxWasMaster(state) ? 'M' : 'S';

	if (Server_BoxWasMaster(state) ||
		((account->boxAccount.lastMatchup.when >=
			account->boxAccount.lastSlaveInfo.slaveQueuedWhen) &&
		 (account->boxAccount.lastMatchup.when <=
			account->boxAccount.lastSlaveInfo.slaveExpireWhen)))
	{
		FPLogmsg(LOG_GAMERESULT, LOGP_INFO,
			"%ld- Opponent was '%s' (%ld,%ld)[%ld]\n",
			cookie,
			account->boxAccount.lastMatchup.oppUserName,
			account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber.box,
			account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber.region,
			account->boxAccount.lastMatchup.prevOpponent.oppPlayer);
		// need to copy into timebuf because ctime() uses a static buffer
		strcpy(timebuf, ctime(&state->account->boxAccount.lastMatchup.when));
		FPLogmsg(LOG_GAMERESULT, LOGP_INFO, "%ld- Matched up at %s", 
				 cookie, timebuf);
	} else {
		FPLogmsg(LOG_GAMERESULT, LOGP_NOTICE, "%ld- No matchup occurred\n",
				 cookie);
		masterChar = 's';
	}

	FPLogmsg(LOG_GAMERESULT, LOGP_INFO,
		"%ld- gameID=%.4s-0x%.8lx  gameError=%d/%d/%d (%c)  playTime=%ld\n",
		cookie,
		(char *)&state->platformID, gameResult->gameID, gameResult->gameError,
		gameResult->errorWhere, gameResult->connectPhase,
		masterChar, gameResult->playTime);
	FPLogmsg(LOG_GAMERESULT, LOGP_INFO,
		"%ld- local1=%lu  local2=%lu  remote1=%lu  remote2=%lu\n",
		cookie,
		gameResult->localPlayer1Result, gameResult->localPlayer2Result,
		gameResult->remotePlayer1Result, gameResult->remotePlayer2Result);
	FPLogmsg(LOG_GAMERESULT, LOGP_INFO,
		"%ld- dbIDDataPtr=%ld  dbIDDataSize=%ld  numPlayers=%ld gameReserved:\n",
		cookie,
		gameResult->dbIDDataPtr, gameResult->dbIDDataSize,
		(long)gameResult->numLocalPlayers);
	FPLogmsg(LOG_GAMERESULT, LOGP_INFO,
		"%ld-  localGameError: %-5d  errorRecovers: %-5d\n",
		cookie,
		gameResult->localGameError, gameResult->errorRecovers);
	FPLogmsg(LOG_GAMERESULT, LOGP_INFO,
		"%ld-  checksumErrors: %-3d    timeouts: %-3d\n",
		cookie,
		gameResult->checksumErrors, gameResult->timeouts);
	FPLogmsg(LOG_GAMERESULT, LOGP_INFO,
		"%ld-  frameErrors: %-3d       overrunErrors: %-3d\n",
		cookie,
		gameResult->frameErrors, gameResult->overrunErrors);
	FLoghexdump2(LOG_GAMERESULT, (unsigned char *) &gameResult->gameReserved,
		sizeof(gameResult->gameReserved), "%ld-", cookie); 
	extraSize = gameResult->size - structSize;
	extraSize -= 2;		// guess we need this

	// do a sanity check so we don't go nuts
	if (extraSize < 0 || extraSize > 1024) {
		FPLogmsg(LOG_GAMERESULT, LOGP_NOTICE, "%ld- extraSize = %ld, wrong!\n",
				 cookie);
		return;
	}
	if (extraSize) {
		FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "%ld- Extra stuff (%ld bytes):\n",
				 cookie, extraSize);
		FLoghexdump2(LOG_GAMERESULT, (unsigned char *)&gameResult->pad,
			extraSize, "%ld-", cookie); 
	} else {
		FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "%ld- No extra stuff\n",
				 cookie);
	}
}

//
// Sets one value to "1" and the other to "0".
//
SEMI_PRIVATE Err
GenericGetNumWins(const NewGameResult *gameResult, long *p1wins, long *p2wins)
{
	WinAnalysis winAnal;

	Server_AnalyzeWin(gameResult, &winAnal);

	if (winAnal.win > 0) {
		*p1wins = 2;
		*p2wins = 0;
	} else if (winAnal.win < 0) {
		*p1wins = 0;
		*p2wins = 2;
	} else {
		*p1wins = *p2wins = 1;
	}
	return (kNoError);
}

//
// Sets the win values equal to twice the point values.
//
SEMI_PRIVATE Err
MatchGetNumWins(const NewGameResult *gameResult, long *p1wins, long *p2wins)
{
	WinAnalysis winAnal;

	Server_AnalyzeWin(gameResult, &winAnal);

	*p1wins = winAnal.pointsFor * 2;
	*p2wins = winAnal.pointsAgainst * 2;

	if (winAnal.win != winAnal.winByPoints) {
		// Winner won by forfeit only, but we're about to tell the rating
		// system that he lost.  Reality is the KONratings don't get adjusted
		// in the event of a forfeit, but ought to fix it here in case it
		// gets changed.
		//
		*p1wins = *p2wins +2;
		FLogmsg(LOG_RATING, "MatchGetNumWins on forfeit game, faking it\n");
	}

	return (kNoError);
}

//
// Generic "possibly losing" routine.  If he's behind or tied, return kFucked;
// otherwise return kNoError.
//
PRIVATE Err
GenericPossiblyLosing(const ServerState *state, const NewGameResult *gameResult)
{
	WinAnalysis winAnal;

	Server_AnalyzeWin(gameResult, &winAnal);

	if (winAnal.win <= 0)
		return (kFucked);
	else
		return (kNoError);
}


//
// Generic reset detect routine.  Any -13 is evil.
//
SEMI_PRIVATE Err
GenericCheckReset(const ServerState *state, const NewGameResult *gameResult,
	const NewGameResult *gameErrorResult)
{
	long cookie;

	cookie = Server_GetMatchCookie(state);

	FPLogmsg(LOG_GAMERESULT, LOGP_PROGRESS, "%ld-GenericCheckReset\n",
		cookie);
	if (gameErrorResult == NULL) {
		FLogmsg(LOG_GAMERESULT,
			"%ld-  Odd: reset detected in gameResult, NO gameErrorResult\n",
			cookie);
		return (kNoError);
	} else {
		// Look for a crash record.
		//
		if (Server_FindSendQItem(state, kRestartInfoType) != NULL) {
			FLogmsg(LOG_GAMERESULT,
				"%ld-  Found a crash record, probably OK.\n", cookie);
			return (kResetMaybe);
		}

		// See if he was losing or tied.
		//
		if (Server_PossiblyLosing(state, gameErrorResult) == kNoError) {
			FLogmsg(LOG_GAMERESULT,
				"%ld-  Player was ahead by at least 1, OK.\n", cookie);
			return (kResetMaybe);
		}

		// Well, nothing to check.
		//
		return (kResetDefinite);
	}

	/* (not currently used) */
	FLogmsg(LOG_GAMERESULT, "%ld-  All criteria checked, looks okay.\n",
		cookie);
	return (kNoError);
}

