/*

 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Pop.c,v 1.3 1996/01/10 14:49:20 hufft Exp $
 *
 * $Log: Server_Pop.c,v $
 * Revision 1.3  1996/01/10  14:49:20  hufft
 * changed to use libphonedb
 *
 * Revision 1.2  1996/01/04  22:54:14  hufft
 * added pop mail
 *
 * Revision 1.1  1995/11/13  19:45:14  hufft
 * pop lookup itf change
 *
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <search.h>
#include <memory.h>
#include "Server.h"
#include "ServerDataBase.h"
#include "Server_Pop.h"
#include "Common.h"
#include "Common_Missing.h"
#include "Common_PlatformID.h"

//
// Client side get pops
//
Err Server_LookupPops(long pop, phoneNumber *boxPhone, phoneNumber* popPhone, phoneNumber* altPhone, Hometown town, int pop_sel, ulong dateLastConnect)
{
phoneNumber	*nums[kMaxPopSelect16];
LOOKUP_POP	lookup;
int			quick;
Err			err;
int			i;

	nums[0] = popPhone;
	nums[1] = altPhone;
	quick = (dateLastConnect && strlen(popPhone->phoneNumber) && strlen(altPhone->phoneNumber));
	err = PhoneDB_GetPops(pop, boxPhone, quick, pop_sel, dateLastConnect, &lookup);
	//
	// if nothing changed
	//
	if (err == kPOPFileIsUpToDate)
	{
		return(err);
	}
	for (i = 0; i < lookup.num_pops; i++)
	{
		//
		// use pattern info to format
		//
		Common_PhoneFormatDialString(lookup.pop[i].phone.phoneNumber, nums[i]->phoneNumber,
			lookup.pop[i].pattern);
		PLogmsg(LOGP_DBUG, "Server_LookupPops:formats %s -> %s\n",
			lookup.pop[i].phone.phoneNumber, nums[i]->phoneNumber);
		nums[i]->scriptID = lookup.pop[i].phone.scriptID;
		nums[i]->length = lookup.pop[i].phone.length;
	}
	memcpy(town, lookup.homeTown, sizeof(lookup.homeTown));
	return(err);
}
//
// Client side validate any pop
//
Err Server_ValidatePopAny(char *raw, DBID *scriptID_p)
{
	return(PhoneDB_ValidatePopAny(raw, scriptID_p));
}
