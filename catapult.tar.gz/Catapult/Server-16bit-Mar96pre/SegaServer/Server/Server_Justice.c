/*
 * Copyright:	� 1995 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Justice.c,v 1.12 1996/02/13 20:27:43 fadden Exp $
 *
 * $Log: Server_Justice.c,v $
 * Revision 1.12  1996/02/13  20:27:43  fadden
 * Declare some read-only tables and their pointers as "const".
 *
 * Revision 1.11  1996/02/02  15:43:09  chs
 * use gConfig.catapultTown everywhere.
 *
 * Revision 1.10  1995/11/17  13:24:55  fadden
 * Changed a (kCallWaitingFucker + 1) to a kCallWaitingHoser.
 *
 * Revision 1.9  1995/09/28  15:57:16  ansell
 * Moved kMaxPointsMagic, kMaxMatchMagic constants from Server_Justice.c into
 * Server.h
 *
 * Revision 1.8  1995/09/25  00:55:27  fadden
 * Added an extra argument to the "fucker mail" and SendFuckerResults, so
 * that we don't re-do what the CompleteEnough stuff will do for us.  Fixed
 * a bug in the call waiting handler that was preventing it from sending
 * mail to the evildoer.
 *
 * Revision 1.7  1995/09/20  00:03:34  fadden
 * Added Server_ForgeSuccessfulGame and Server_NotifyCompleted.  Changed
 * (kCallWaitingFucker + 1) return value to kCallWaitingHoser.  Corrected
 * mail times (midnight is 12am instead of 0am, noon is 12pm instead of 12am).
 *
 * Revision 1.6  1995/09/13  14:24:31  ted
 * Fixed warnings.
 *
 * Revision 1.5  1995/08/28  15:48:33  fadden
 * Update dailyTotalGames in Server_SendFuckerResults, for both sides.
 *
 * Revision 1.4  1995/08/25  17:42:56  fadden
 * Use WinAnalysis structs instead of computing win/loss/tie directly.
 *
 * Revision 1.3  1995/08/11  15:12:54  fadden
 * Track cordPullData.min and cordPullData.max.
 *
 * Revision 1.2  1995/08/07  21:47:59  fadden
 * Added cord pull stuff.
 *
 * Revision 1.1  1995/08/07  14:45:57  fadden
 * Initial revision.  Moved the fucker checks out of Server_GameResults.c
 * and into here.
 *
 */

#include <stdio.h>
#include <memory.h>
#include <sys/time.h>
#include <malloc.h>
#include <strings.h>

#include "Common.h"
#include "Common_PlatformID.h"
#include "Common_ReadConf.h"
#include "Common_Missing.h"
#include "Server.h"
#include "ServerDataBase.h"
#include "Server_GameSpecific.h"
#include "Server_Rankings.h"


//
// Local prototypes.
//
PRIVATE struct tm *Server_GetLocalTime(ServerState *state, time_t when);


#define MY_MAX_MAIL_MESG_SIZE	512
#define TIME_ADJUST	(2L*60L)



// ===========================================================================
//		FAX machines
// ===========================================================================

//
// See if the current player got rejected by his opponent's fax machine.
//
void
Server_CheckForFAX(ServerState *state, GameResult *gameResult, GameResult *gameErrorResult)
{
	Mail *mm;
	userIdentification catapult = {		// from address
			{-1, -1}, 0, 0, kXBANDPlayerIcon, "",
			kMailXbandFaxScan 
	};
	struct tm *tm;
	long cookie;
	char day[64], timestr[64];

	strcpy(catapult.userTown, gConfig.catapultTown);

#ifdef TESTING_GAME_RESULTS
	//state->boxOSState.boxFlags |= kFAXMachineDetected;
#endif

	if( !(state->boxOSState.boxFlags & kFAXMachineDetected) )
		return;

	// Don't penalize the fax guy if they played a game

	if (gameResult && gameResult->gameID)
		return;
	
	if (gameErrorResult && gameErrorResult->gameID)
		return;

	// Okay, they didn't play a game, so debit the sleazeball
	
	cookie = Server_GetMatchCookie(state);

	mm = (Mail *)malloc(sizeof(Mail) + MY_MAX_MAIL_MESG_SIZE);
	if (mm == NULL) {
		PLogmsg(LOGP_FLAW, "Out of memory in Server_CheckForFAX\n");
		Common_Abort();
	}

	// Get the local time values for when the match was set up.  Fix it by
	// TIME_ADJUST seconds so that it's the start of the game rather than
	// when the server matchup occurred.
	//
	tm = Server_GetLocalTime(state,
		state->account->boxAccount.lastMatchup.prevOpponent.when + TIME_ADJUST);

	// Pretty-print it.
	//
	sprintf(timestr, "%d:%.2d%s %s",
		(!tm->tm_hour) ? 12 :
			(tm->tm_hour > 12) ? (tm->tm_hour - 12) : tm->tm_hour,
		tm->tm_min,
		(tm->tm_hour >= 12) ? "pm" : "am",
		(tm->tm_isdst) ? "PDT" : "PST");
	if (strftime(day, 64, "%a %m/%d", tm) == 0) {
		FPLogmsg(LOG_GAMERESULT, LOGP_FLAW, "%ld-Glitch, day not set!\n",
				 cookie);
		strcpy(day, "??:??");
	}

#ifdef NASTY_FAX
	// Set the message.
	//
	sprintf(mm->message,
		gettext("Your FAX machine answered instead of your XBAND Modem when %s called you for a game of %s at %s on %s. You've been charged a credit."),
		state->account->playerAccount.userName,
		Common_AliasedGameName(state->platformID,
			state->account->boxAccount.lastMatchup.oppRankingInfo.gameID),
		timestr,
		day );


	FLogmsg(LOG_GAMERESULT, "%ld- Sending mail: Evil Slave with FAX: '%s'\n", 
			cookie, mm->message);
	Server_DeductCreditOther(state,
		&state->account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber);

#else	/*NASTY_FAX*/
	// Set the message.
	//
	sprintf(mm->message,
		gettext("We think a FAX machine may have answered instead of your XBAND Modem when %s called you at %s on %s.  If you have one, please turn it off."),
		state->account->playerAccount.userName,
		timestr,
		day );


	FLogmsg(LOG_GAMERESULT, "%ld- Sending mail: Maybe slave with FAX: '%s'\n",
		    cookie, mm->message);

#endif	/*NASTY_FAX*/

	// Put it in the mailbox of the guy who played last.
	//
	mm->from = catapult;
	strcpy(mm->to.userName, "");
	mm->to.box = state->account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber;
	mm->to.userID = state->account->boxAccount.lastMatchup.prevOpponent.oppPlayer;
#ifdef TESTING_GAME_RESULTS
	//mm->to.box = state->loginData.userID.box;
	//mm->to.userID = state->account->boxAccount.lastMatchup.player;
#endif
#ifdef NASTY_FAX
	strcpy(mm->title, gettext("Turn off your FAX!"));
#else
	strcpy(mm->title, gettext("Turn off your FAX?"));
#endif
	mm->date = Server_GetSegaDate();
	WrapperDB_AddMailToIncoming(mm);

#ifdef NASTY_FAX
	sprintf(mm->message,
		gettext("We determined that %s's FAX machine answered instead of his XBAND modem for a game of %s at %s on %s. Your credit has been refunded."),
		state->account->boxAccount.lastMatchup.oppUserName,
		Common_AliasedGameName(state->platformID,
			state->account->boxAccount.lastMatchup.oppRankingInfo.gameID),
		timestr,
		day);

#else
	sprintf(mm->message,
		gettext("We think that a FAX machine answered instead of %s's XBAND modem for a game of %s at %s on %s. Your credit has been refunded."),
		state->account->boxAccount.lastMatchup.oppUserName,
		Common_AliasedGameName(state->platformID,
			state->account->boxAccount.lastMatchup.oppRankingInfo.gameID),
		timestr,
		day);

	Server_DeductCreditOther(state,
		&state->account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber);
#endif

	FLogmsg(LOG_GAMERESULT, "%ld- Good Master: '%s'\n", 
			cookie, mm->message);

	// Put this one in the other guy's box.
	//
	strcpy(mm->to.userName, "");
	mm->to.box = state->loginData.userID.box;
	mm->to.userID = state->account->boxAccount.lastMatchup.player;
	strcpy(mm->title, gettext("Opponent FAX detected?"));
	WrapperDB_AddMailToIncoming(mm);
	free(mm);
}



// ===========================================================================
//		Evil Resets
// ===========================================================================

//
// Check to see if the guy hit reset while playing a game.  Checks some
// generic stuff, then calls the game-specific stuff if necessary.
//
// If the player DID hit reset while playing, appropriate action is taken.
// Returns kNoError if no problemo, some other value if something bad
// happened.
//
Err
Server_CheckForReset(ServerState *state, const NewGameResult *gameResult,
	const NewGameResult *gameErrorResult)
{
	WinAnalysis winAnal;
	const GameInfo *gameInfo;
	int hosedReset;
	Err err;

	if (gameErrorResult == NULL) {
		// Maybe it came back in gameResult?  Don't think it can, but
		// check anyway.
		//
		if (gameResult == NULL)
			return (kNoError);
		if (gameResult->gameError != kRebootDuringGameErr)
			return (kNoError);
		FLogmsg(LOG_RATING, "Investigating Reset in %.4s-0x%.8lx...\n",
			(char *)&state->platformID, gameResult->gameID);
	} else {
		// Got an error, did he hit reset?
		//
		if (gameErrorResult->gameError != kRebootDuringGameErr)
			return (kNoError);
		FLogmsg(LOG_RATING, "Investigating reset in %.4s-0x%.8lx...\n",
			(char *)&state->platformID, gameErrorResult->gameID);

		// Seeing some weird stuff where false resets come back with really
		// bizarre values for the score.  Try to figure out if this is one
		// of those cases.
		//
		Server_AnalyzeWin(gameErrorResult, &winAnal);
		gameInfo = Common_GameInfoForGame(state->platformID,
			gameErrorResult->gameID);
		if (gameInfo == NULL) {
			PLogmsg(LOGP_FLAW, "Can't investigate reset, game doesn't exist.\n");
			return (kNoError);
		}
		hosedReset = false;
		if (gameInfo->gameInfoFlags & kGIFlagResultsArePoints) {
			if (winAnal.pointsFor > kMaxPointsMagic ||
				winAnal.pointsAgainst > kMaxPointsMagic)
			{
				hosedReset = true;
			}
		} else if (gameInfo->gameInfoFlags & kGIFlagResultsAreMatches) {
			if (winAnal.pointsFor > kMaxMatchMagic ||
				winAnal.pointsAgainst > kMaxMatchMagic)
			{
				hosedReset = true;
			}
		}
		if (hosedReset) {
			PLogmsg(LOGP_NOTICE,
				"HOSED_RESET for %.4s-0x%.8lx (scores %lu to %lu)\n",
				(char *)&state->platformID, gameErrorResult->gameID,
				winAnal.pointsFor, winAnal.pointsAgainst);
			return (kNoError);
		}
	}


	// These log messages will be inaccurate if the person dialing in
	// is different from the one who just played.  However, the important
	// stuff *is* being handled correctly.  I'd rather not have to pass
	// the real account in here, because in "real life" that's another
	// database lookup.
	//
	err = Server_CheckReset(state, gameResult, gameErrorResult);
	switch (err) {
	case kNoError:
		FLogmsg(LOG_RATING, "  Looks clean.\n");
		Statusmsg("         (Looks like valid reset for '%s' (%s).)\n",
			state->account->playerAccount.userName,
			state->account->boxAccount.gamePhone.phoneNumber);
		break;
	case kResetUnknown:
		FLogmsg(LOG_RATING, "  No check routine.\n");
		Statusmsg("         (Couldn't check valid reset for '%s' (%s).)\n",
			state->account->playerAccount.userName,
			state->account->boxAccount.gamePhone.phoneNumber);
		break;
	case kResetMaybe:
		FLogmsg(LOG_RATING, "  Probably clean.\n");
		Statusmsg("         (Might be valid reset for '%s' (%s).)\n",
			state->account->playerAccount.userName,
			state->account->boxAccount.gamePhone.phoneNumber);
		break;
	case kResetDefinite:
		FLogmsg(LOG_RATING, "--> EVIL RESET <--\n");
		Statusmsg("         (Looks like an EVIL RESET for '%s' (%s).)\n",
			state->account->playerAccount.userName,
			state->account->boxAccount.gamePhone.phoneNumber);
		//Server_SendResetFuckerMail(state);
		break;
	default:
		FLogmsg(LOG_RATING, "  Strange result.\n");
		Statusmsg("         (Strange result? valid reset for '%s' (%s).)\n",
			state->account->playerAccount.userName,
			state->account->boxAccount.gamePhone.phoneNumber);
		err = kResetUnknown;
		break;
	}
	return (err);
}


//
// Send a nasty-o-gram to this guy (which he should get this connect),
// and a sorry-o-gram to the guy he reset on.
//
void
Server_SendResetFuckerMail(ServerState *state, Account *updateAccount, Err ceResult)
{
	WinAnalysis winAnal;
	Mail *mm;
	userIdentification catapult = {		// from address
			{-1, -1}, 0, 0, kXBANDPlayerIcon, "", 
			kMailXbandResetScan
	};
	struct tm *tm;
	long cookie;
	char day[64], timestr[64];
	const GameInfo *gi = NULL;

	strcpy(catapult.userTown, gConfig.catapultTown);

	cookie = Server_GetMatchCookie(state);

	if (!(state->validFlags & kServerValidFlag_GameErrorResults)) {
		PLogmsg(LOGP_FLAW, "How'd we get here?  FuckerMail w/o ger\n");
		FPLogmsg(LOG_GAMERESULT, LOGP_FLAW, "%ld-Glitch, mail not sent\n",
				 cookie);
		return;
	}

	Server_AnalyzeWin((NewGameResult *)&state->gameErrorResult, &winAnal);

	mm = (Mail *)malloc(sizeof(Mail) + MY_MAX_MAIL_MESG_SIZE);
	if (mm == NULL) {
		PLogmsg(LOGP_FLAW, "Out of memory in FuckerMail\n");
		Common_Abort();
	}

	// Get the local time values for when the match was set up.  Fix it by
	// TIME_ADJUST seconds so that it's the start of the game rather than
	// when the server matchup occurred.
	//
	tm = Server_GetLocalTime(state,
		updateAccount->boxAccount.lastMatchup.prevOpponent.when + TIME_ADJUST);

	// Pretty-print it.
	//
	sprintf(timestr, "%d:%.2d%s %s",
		(!tm->tm_hour) ? 12 :
			(tm->tm_hour > 12) ? (tm->tm_hour - 12) : tm->tm_hour,
		tm->tm_min,
		(tm->tm_hour >= 12) ? "pm" : "am",
		(tm->tm_isdst) ? "PDT" : "PST");
	if (strftime(day, 64, "%a %m/%d", tm) == 0) {
		FPLogmsg(LOG_GAMERESULT, LOGP_FLAW, "%ld-Glitch, day not set!\n",
				 cookie);
		strcpy(day, "??:??");
	}

	// Set the message.
	//
	sprintf(mm->message,
		gettext("We detected that you hit reset during a game of %s against %s at %s on %s.  %s %ld to %ld."),
		Common_AliasedGameName(state->platformID,
			updateAccount->boxAccount.lastMatchup.oppRankingInfo.gameID),
		updateAccount->boxAccount.lastMatchup.oppUserName,
		timestr,
		day,
		(winAnal.pointsFor < winAnal.pointsAgainst) ?
			gettext("You were losing") : gettext("The score was"),
		winAnal.pointsFor,
		winAnal.pointsAgainst);

	if (updateAccount->boxAccount.lastMatchup.wasSpecific & kLastChallengeMask)
	{
		strcat(mm->message,
			gettext("  Because this was a player-list match, no action will be taken."));
	} else {
		strcat(mm->message, gettext("  You've been fined a credit and given the loss."));
	}
	FLogmsg(LOG_GAMERESULT, "%ld- Sending mail:\n", cookie);

	// Put it in the mailbox of the guy who played last.
	//
	mm->from = catapult;
	strcpy(mm->to.userName, "");
	mm->to.box = state->loginData.userID.box;
	mm->to.userID = updateAccount->boxAccount.lastMatchup.player;
	strcpy(mm->title, gettext("You hit reset"));
	mm->date = Server_GetSegaDate();

	// Only send mail if the kGIFlagResetMailBoth flag is set.
	//
	if ((gi = Common_GameInfoForGame(state->platformID,
		state->gameErrorResult.gameID)) == NULL)
	{
		// impossible
		PLogmsg(LOGP_FLAW, "ERROR: unable to find game info for %.4s-0x%.8lx\n",
			(char *)&state->platformID, state->gameErrorResult.gameID);
	} else if (gi->gameInfoFlags & kGIFlagResetMailBoth) {
		FLogmsg(LOG_GAMERESULT, "%ld- Resetter: '%s'\n", cookie, mm->message);
		WrapperDB_AddMailToIncoming(mm);
	} else {
		FLogmsg(LOG_GAMERESULT, "%ld- Resetter: (not sending)\n", cookie);
	}

	sprintf(mm->message,
		gettext("We determined that %s hit reset during a game of %s at %s on %s."),
		updateAccount->playerAccount.userName,
		Common_AliasedGameName(state->platformID,
			updateAccount->boxAccount.lastMatchup.oppRankingInfo.gameID),
		timestr,
		day);

	if (updateAccount->boxAccount.lastMatchup.wasSpecific & kLastChallengeMask)
	{
		strcat(mm->message,
			gettext("  Because this was a player-list match, no action will be taken."));
	} else {
		strcat(mm->message,
			gettext("  Your credit has been refunded, and you were awarded the win."));
		//Server_SendFuckerResults(state, updateAccount);   (done earlier)
	}

	// Put this one in the other guy's box.
	//
	strcpy(mm->to.userName, "");
	mm->to.box = updateAccount->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber;
	mm->to.userID = updateAccount->boxAccount.lastMatchup.prevOpponent.oppPlayer;
	strcpy(mm->title, gettext("Reset was hit"));
	if (ceResult != kEnoughCompletedRemoteWinner) {
		FLogmsg(LOG_GAMERESULT, "%ld- Resettee: '%s'\n", cookie, mm->message);
		WrapperDB_AddMailToIncoming(mm);
	} else {
		FLogmsg(LOG_GAMERESULT, "%ld- Resettee: (not sending)\n", cookie);
	}

	free(mm);
}



// ===========================================================================
//		Cord pulls
// ===========================================================================

#define kCordPullInit		0x2B02

//
// Update the CordPullData field in the database with the values sent up
// by the box.  This maintains the min/max/weighted-average values.
//
void
Server_UpdateCordPullData(ServerState *state)
{
	QItem *item;
	unsigned short serverValue, origValue;
	unsigned long temp;
	
	// Average starts with a value pulled out of Josh's... calculations.
	//
	if (!state->account->boxAccount.cordPullData.weightedAverage) {
		state->account->boxAccount.cordPullData.weightedAverage = kCordPullInit;
		state->account->boxModified |= kBA_cordPullData;
	}

	item = Server_FindSendQItem(state, kCordPullQElement);
	if (item == NULL)
		return;

	// We don't care about the rest of the SendQ item at this point;
	// detecting fuckers is done in the next routine (which actually gets
	// done first).
	//
	// It's called "serverValue" because it's determined at the end of a
	// server connect.
	//
	serverValue = *(short *)item->data;
	origValue = state->account->boxAccount.cordPullData.weightedAverage;
	temp = (unsigned long)serverValue + (unsigned long)origValue;
	temp /= 2;
	state->account->boxAccount.cordPullData.weightedAverage =
		(unsigned short) temp;
	if (!state->account->boxAccount.cordPullData.min ||
		serverValue < state->account->boxAccount.cordPullData.min)
	{
		state->account->boxAccount.cordPullData.min = serverValue;
	}
	if (!state->account->boxAccount.cordPullData.max ||
		serverValue > state->account->boxAccount.cordPullData.max)
	{
		state->account->boxAccount.cordPullData.max = serverValue;
	}
	state->account->boxModified |= kBA_cordPullData;

	FPLogmsg(LOG_DBUG, LOGP_DBUG, "Cord Pull Data (%.4s) (%.4x+%.4x=%.4x) -",
		(char *)&state->account->boxAccount.platformID, origValue, serverValue,
		state->account->boxAccount.cordPullData.weightedAverage);
	FLoghexdump(LOG_DBUG, item->data, item->size);
}


#define kCordPullMin		0x3800
#define kCordPullLocalDev	0x1000
#define kCordPullWtAvgDev	0x800

//
// See if we done got us a cord puller.  Criteria are the presence of a
// detection value that looks like a pulled cord, plus the guy was losing
// the game.
//
// This should NOT be called if we have valid game results; pulling the cord
// on game that don't count isn't a crime.
//
// Returns kCordPullFucker if we've got one, kNoError if not.  Does not
// affect rankings, send mail, or update the account.
//
Err
Server_CheckForCordPull(ServerState *state, const NewGameResult *gameResult,
	const NewGameResult *gameErrorResult)
{
	QItem *item;
	unsigned short serverValue;		// sampled at end of server connect
	unsigned short hosedValue;		// sampled when the game is hosed
	Boolean evilPull = false;
	
	PLogmsg(LOGP_PROGRESS, "Server_CheckForCordPull\n");

//#define TESTING_CORD_PULL
#ifdef TESTING_CORD_PULL
	if (!gConfig.isProduction) {
		static struct {
			unsigned short val1;
			unsigned short val2;
		} shorty;
		int mode = 0;

		switch (mode) {
		case 0:		// non-fucker
			shorty.val1 = 0x2b00;
			shorty.val2 = 0x2c00;
			break;
		case 1:		// fucker
			shorty.val1 = 0x2b00;
			shorty.val2 = 0x4000;
			break;
		case 2:		// okay because of agedAverage
			state->account->boxAccount.cordPullData.weightedAverage = 0x3002;
			shorty.val1 = 0x2800;
			shorty.val2 = 0x3801;
			break;
		case 3:		// okay because of absolute minimum
			shorty.val1 = 0x2000;
			shorty.val2 = 0x37ff;
			break;
		default:	// huh?
			PLogmsg(LOGP_FLAW, "Go away.\n");
			Common_Abort();
		}

		item = Server_FindSendQItem(state, kCordPullQElement);
		if (item != NULL) {
			item->data = (unsigned char *)&shorty;
			item->size = 4;
		}
	}
#endif	/*TESTING_CORD_PULL*/

	item = Server_FindSendQItem(state, kCordPullQElement);
	if (item == NULL)
		return (kNoError);
	if (item->size <= 2)
		return (kNoError);		// no hosedValue
	if (!state->account->boxAccount.cordPullData.weightedAverage)
		return (kNoError);		// let it run through once at least

	serverValue = *(short *)item->data;
	hosedValue = *(((short *)item->data) + 1);

	if (hosedValue > serverValue + kCordPullLocalDev) {
		Logmsg("Cord Pull Scan:");
		if (hosedValue > kCordPullMin) {
			if (hosedValue >
				state->account->boxAccount.cordPullData.weightedAverage +
					kCordPullWtAvgDev)
			{
				// We have a fucker.
				//
				Logmsg(" EVIL (%ld,%ld)[%d] avg=0x%.4x,",
					state->loginData.userID.box.box,
					state->loginData.userID.box.region,
					state->loginData.userID.userID,
					state->account->boxAccount.cordPullData.weightedAverage);
				evilPull = true;
			} else {
				Logmsg(" not above aged avg (0x%.4x+0x%.4x):",
					state->account->boxAccount.cordPullData.weightedAverage,
					kCordPullWtAvgDev);
			}
		} else {
			Logmsg(" not above min (0x%.4x):", kCordPullMin);
		}

		Logmsg(" server=0x%.4x, hosed=0x%.4x\n", serverValue, hosedValue);
	}

	if (evilPull) {
		// Do all sorts of nasty things, like sending mail and fucker
		// results, but only if they were losing.
		//
		// (do me)


		// this is TEMPORARY, for debugging
		if (Server_GetSpecialPhone(state) & kSpecialCatapult) {
			Server_SendDialog(state, "(CAT) cord pulled", true);
		}

		// (don't do this yet!!)
		// return (kCordPullFucker);
		return (kNoError);
	}

	// No problems, outta here.
	//
	return (kNoError);
}


//
// Send a nasty-o-gram to this guy (which he should get this connect),
// and a sorry-o-gram to the guy he pulled the cord on.
//
// (works just like reset stuff)
//
void
Server_SendCordPullFuckerMail(ServerState *state, Account *updateAccount, Err ceResult)
{
	// (do me)
}



// ===========================================================================
//		Call waiting
// ===========================================================================

//
// Send a nasty-o-gram to this guy (which he should get this connect),
// and a sorry-o-gram to the guy he hosed with CW.
//
// We do the FuckerResults in here, because we only send them if the guy
// was actually losing.  Otherwise we just recredit appropriately.
//
void
Server_SendCWFuckerMail(ServerState *state, Account *updateAccount, Err ceResult)
{
	WinAnalysis winAnal;
	Mail *mm;
	userIdentification catapult = {		// from address
			{-1, -1}, 0, 0, kXBANDPlayerIcon, "", 
			kMailXbandCallScan
	};
	struct tm *tm;
	long cookie;
	char day[64], timestr[64];

	strcpy(catapult.userTown, gConfig.catapultTown);

	cookie = Server_GetMatchCookie(state);

	if (!(state->validFlags & kServerValidFlag_GameErrorResults)) {
		PLogmsg(LOGP_FLAW, "How'd we get here?  CWFuckerMail w/o ger\n");
		FPLogmsg(LOG_GAMERESULT, LOGP_FLAW, "%ld-Glitch, mail not sent\n",
				 cookie);
		return;
	}

	Server_AnalyzeWin((NewGameResult *)&state->gameErrorResult, &winAnal);

	mm = (Mail *)malloc(sizeof(Mail) + MY_MAX_MAIL_MESG_SIZE);
	if (mm == NULL) {
		PLogmsg(LOGP_FLAW, "Out of memory in CWFuckerMail\n");
		Common_Abort();
	}

	// Get the local time values for when the match was set up.  Fix it by
	// TIME_ADJUST seconds so that it's the start of the game rather than
	// when the server matchup occurred.
	//
	tm = Server_GetLocalTime(state,
		updateAccount->boxAccount.lastMatchup.prevOpponent.when + TIME_ADJUST);

	// Pretty-print it.
	//
	sprintf(timestr, "%d:%.2d%s %s",
		(!tm->tm_hour) ? 12 :
			(tm->tm_hour > 12) ? (tm->tm_hour - 12) : tm->tm_hour,
		tm->tm_min,
		(tm->tm_hour >= 12) ? "pm" : "am",
		(tm->tm_isdst) ? "PDT" : "PST");
	if (strftime(day, 64, "%a %m/%d", tm) == 0) {
		FPLogmsg(LOG_GAMERESULT, LOGP_FLAW, "%ld-Glitch, day not set!\n",
				 cookie);
		strcpy(day, "??:??");
	}

	// Set the message.
	//
	sprintf(mm->message,
		gettext("We detected that you got a call and didn't continue during a game of %s against %s at %s on %s.  %s %ld to %ld."),
		Common_AliasedGameName(state->platformID,
			updateAccount->boxAccount.lastMatchup.oppRankingInfo.gameID),
		updateAccount->boxAccount.lastMatchup.oppUserName,
		timestr,
		day,
		(winAnal.pointsFor < winAnal.pointsAgainst) ?
			"You were losing" : "The score was",
		winAnal.pointsFor,
		winAnal.pointsAgainst);

	if (updateAccount->boxAccount.lastMatchup.wasSpecific & kLastChallengeMask)
	{
		strcat(mm->message,
			gettext("  This was a player-list match, so no action will be taken."));
	} else {
		if (Server_PossiblyLosing(state, (const NewGameResult *)&state->gameErrorResult))
			strcat(mm->message, gettext("  You've been given the loss."));
		else
			strcat(mm->message, gettext("  A credit has been deducted."));
	}
	FLogmsg(LOG_GAMERESULT, "%ld- Sending mail:\n", cookie);
	FLogmsg(LOG_GAMERESULT, "%ld- Called: '%s'\n", cookie, mm->message);

	// Put it in the mailbox of the guy who played last.
	//
	mm->from = catapult;
	strcpy(mm->to.userName, "");
	mm->to.box = state->loginData.userID.box;
	mm->to.userID = updateAccount->boxAccount.lastMatchup.player;
	strcpy(mm->title, gettext("Called & didn't continue"));
	mm->date = Server_GetSegaDate();
	WrapperDB_AddMailToIncoming(mm);

	sprintf(mm->message,
		gettext("We determined that %s got a call and didn't continue during a game of %s at %s on %s."),
		updateAccount->playerAccount.userName,
		Common_AliasedGameName(state->platformID,
			updateAccount->boxAccount.lastMatchup.oppRankingInfo.gameID),
		timestr,
		day);

	if (updateAccount->boxAccount.lastMatchup.wasSpecific & kLastChallengeMask)
	{
		strcat(mm->message,
			gettext("  This was a player-list match, so no action will be taken."));
	} else {
		// Mumble.  We don't explicitly refund the credit; if the side that
		// wasn't the one being called hit "continue" and this guy didn't,
		// they won't have a credit deducted.  What happens if neither side
		// elects to continue?  Looks like we only get here if the current
		// guy had fewer points, so this next "if" clause is useless, maybe.
		//
		// Interestingly, we don't *fine* this guy credits, but we do deduct
		// the one from the connect.  Very different from evil reset.
		// -- 950130 ATM
		//
		if (Server_PossiblyLosing(state, (const NewGameResult *)&state->gameErrorResult)) {
			strcat(mm->message,
				gettext("  You have been awarded the win."));
			Server_SendFuckerResults(state, updateAccount, ceResult);
		} else {
			strcat(mm->message,
				gettext("  You were not charged for that game."));
		}
	}


	// Put this one in the other guy's box.
	//
	strcpy(mm->to.userName, "");
	mm->to.box = updateAccount->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber;
	mm->to.userID = updateAccount->boxAccount.lastMatchup.prevOpponent.oppPlayer;
	strcpy(mm->title, gettext("Opponent called"));
	if (ceResult != kEnoughCompletedRemoteWinner) {
		FLogmsg(LOG_GAMERESULT, "%ld- Victim: '%s'\n", cookie, mm->message);
		WrapperDB_AddMailToIncoming(mm);
	} else {
		FLogmsg(LOG_GAMERESULT, "%ld- Victim: (not sending)\n", cookie);
	}

	free(mm);
}


//
// Checks to see if this guy got a call and decided not to continue.  Only
// evil if the guy was losing at the time.
//
// Do we want to return "evil" on 0-0?  i.e. before the game has really begun?
// (Hmm, don't want to give a loss for a game that hasn't started...)
//
// This should ONLY be called if we didn't get valid game results.  We don't
// care what happens to a game after the first one.
//
// Returns kNoError if CW wasn't involved, kCallWaitingFucker if the guy
// called himself while losing, and kCallWaitingHoser if he got call
// waiting but wasn't being evil.
//
// HOW CW REPORTING WORKS:
//	if you didn't choose to continue (called or not), you report a -432
//	if you were the master, chose to continue, and it failed, you get -415
//	if you were the slave, chose to continue, and never got called, get -434
//	for all cases:
//	  if you were called, you show kCallWaitingGRMod (2) in errorWhere
//	  if other guy was called, you show kRemoteCallWaitingGRMod (3)
//
Err
Server_CheckCallWaiting(ServerState *state, NewGameResult *gameErrorResult)
{
	WinAnalysis winAnal;
	long cookie;

	if (gameErrorResult == NULL)
		return (kNoError);

	// If I didn't say "don't continue", I wasn't evil
	//
	if (gameErrorResult->gameError != kCallWaitingTimeoutErr)
		return (kNoError);

	// If I wasn't the one who got called, I wasn't evil, but I was a hoser.
	//
	if (gameErrorResult->errorWhere != (kCallWaitingGRMod >> 16))
		return (kCallWaitingHoser);

	cookie = Server_GetMatchCookie(state);

	// (950825: this used to use state->gameErrorResult; dunno why)
	Server_AnalyzeWin(gameErrorResult, &winAnal);

	if (winAnal.win < 0) {
		FLogmsg(LOG_GAMERESULT,
			"%ld-EVIL: Losing player got call and chose not to continue\n",
			cookie);
		return (kCallWaitingFucker);
	} else {
		FLogmsg(LOG_GAMERESULT,
			"%ld-Winning/tied player got call and chose not to continue\n",
			cookie);
		return (kCallWaitingHoser);
	}
	/*NOTREACHED*/
}



// ===========================================================================
//		Complete enough a/k/a sufficient win
// ===========================================================================

//
// Snatch victory from the jaws of a failed game.
//
// If a game result struct has been allocated in the "state" structure,
// just tweak the values therein.  If not, allocate one and add it to state.
// Either way, return it.
//
// It's possible that our attempt to create the game result will fail,
// where failure is defined as AnalyzeWin reporting that the current
// player had a result that doesn't match winExpected.
//
// winExpected should be -1 if the player lost, 0 if he tied, 1 if he won
// (same values AnalyzeWin uses).  This routine will try to adjust things
// to ensure that the caller gets what is asked for (i.e. you want a tie,
// you'll get a tie).
//
// Attempting to do completeEnough processing on the returned struct would
// be a mistake; this doesn't retain any of the extra goodies.
//
// Returns a pointer to the gameResult struct on success, NULL on failure.
//
NewGameResult *
Server_ForgeSuccessfulGame(ServerState *state, NewGameResult *gameErrorResult,
	int winExpected)
{
	WinAnalysis winAnal;
	NewGameResult *gameResult;

	PLogmsg(LOGP_PROGRESS, "Server_ForgeSuccessfulGame (%d)\n", winExpected);

	if (gameErrorResult == NULL) {
		PLogmsg(LOGP_FLAW, "ERROR: NULL ger passed to Forge\n");
		return (NULL);
	}

	// Usually this won't have been allocated.  Either way, erase it.
	//
	if (state->gameResult == NULL) {
		state->gameResult = (GameResult *)malloc(sizeof(GameResult));
		// Not sure if I should set this or not.  I'm going to say
		// "not" so it doesn't show up in the binlogs.
		//
		//state->validFlags |= kServerValidFlag_GameResults;
	}
	memset(state->gameResult, 0, sizeof(GameResult));

	gameResult = (NewGameResult *)state->gameResult;

	// Copy the scores over.
	//
	gameResult->size = sizeof(GameResult);
	gameResult->gameID = gameErrorResult->gameID;
	gameResult->gameError = 0;
	gameResult->localPlayer1Result = gameErrorResult->localPlayer1Result;
	gameResult->localPlayer2Result = gameErrorResult->localPlayer2Result;
	gameResult->remotePlayer1Result = gameErrorResult->remotePlayer1Result;
	gameResult->remotePlayer2Result = gameErrorResult->remotePlayer2Result;
	gameResult->playTime = gameErrorResult->playTime;

	Server_AnalyzeWin(gameResult, &winAnal);
	if (winAnal.win != winExpected) {
		switch (winExpected) {
		case 0:		// wanted to tie
			Logmsg("ForgeSuccessfulGame forcing tie\n");
			gameResult->localPlayer1Result = gameResult->remotePlayer1Result;
			gameResult->localPlayer2Result = gameResult->remotePlayer2Result;
			break;
		case 1:		// wanted to win
			Logmsg("ForgeSuccessfulGame forcing win\n");
			gameResult->localPlayer1Result = gameResult->remotePlayer1Result +1;
			gameResult->localPlayer2Result = gameResult->remotePlayer2Result +1;
			break;
		case -1:	// wanted to lose
			Logmsg("ForgeSuccessfulGame forcing loss\n");
			gameResult->remotePlayer1Result = gameResult->localPlayer1Result +1;
			gameResult->remotePlayer2Result = gameResult->localPlayer2Result +1;
			break;
		}

		// Check it.
		//
		Server_AnalyzeWin(gameResult, &winAnal);
		if (winAnal.win != winExpected) {
			// okay, I give up
			PLogmsg(LOGP_FLAW,
				"ForgeSuccessfulGame unable to force %d (%d/%d %d/%d)\n",
				gameErrorResult->localPlayer1Result,
				gameErrorResult->localPlayer2Result,
				gameErrorResult->remotePlayer1Result,
				gameErrorResult->remotePlayer2Result);
			return (NULL);
		}
	}

	return (gameResult);
}


//
// After a CompleteEnough judgement, notify the player of the outcome.
//
// Doesn't do anything different if the previous match was a specific-match,
// since we shouldn't be here at all in that event.
//
void
Server_NotifyCompleted(ServerState *state, Account *updateAccount)
{
	WinAnalysis winAnal;
	Mail *mm;
	userIdentification catapult = {		// from address
			{-1, -1}, 0, 0, kXBANDPlayerIcon, "", 
			kMailXbandCompleteEnough
	};
	struct tm *tm;
	long cookie;
	char day[64], timestr[64];

	strcpy(catapult.userTown, gConfig.catapultTown);

	cookie = Server_GetMatchCookie(state);

	if (state->gameResult == NULL) {
		PLogmsg(LOGP_FLAW, "NotifyCompleted w/o gr\n");
		FPLogmsg(LOG_GAMERESULT, LOGP_FLAW, "%ld-Glitch, mail not sent\n",
				 cookie);
		return;
	}

	Server_AnalyzeWin((NewGameResult *)&state->gameErrorResult, &winAnal);
	if (winAnal.win != 1) {
		// I don't have official text for dealing with people who lose,
		// so for now just send mail to people who win.
		//
		PLogmsg(LOGP_FLAW,
			"GLITCH: Server_NotifyCompleted only knows about winners\n");
		return;
	}

	mm = (Mail *)malloc(sizeof(Mail) + MY_MAX_MAIL_MESG_SIZE);
	if (mm == NULL) {
		PLogmsg(LOGP_FLAW, "Out of memory in NotifyCompleted\n");
		Common_Abort();
	}

	// Get the local time values for when the match was set up.  Fix it by
	// TIME_ADJUST seconds so that it's the start of the game rather than
	// when the server matchup occurred.
	//
	tm = Server_GetLocalTime(state,
		updateAccount->boxAccount.lastMatchup.prevOpponent.when + TIME_ADJUST);

	// Pretty-print it.
	//
	sprintf(timestr, "%d:%.2d%s %s",
		(!tm->tm_hour) ? 12 :
			(tm->tm_hour > 12) ? (tm->tm_hour - 12) : tm->tm_hour,
		tm->tm_min,
		(tm->tm_hour >= 12) ? "pm" : "am",
		(tm->tm_isdst) ? "PDT" : "PST");
	if (strftime(day, 64, "%a %m/%d", tm) == 0) {
		FPLogmsg(LOG_GAMERESULT, LOGP_FLAW, "%ld-Glitch, day not set!\n",
				 cookie);
		strcpy(day, "??:??");
	}

	// Set the message.
	//
	sprintf(mm->message,
		gettext("Your game of %s against %s at %s on %s could NOT be completed. The score was %ld to %ld. You have been awarded the WIN."),
		Common_AliasedGameName(state->platformID,
			updateAccount->boxAccount.lastMatchup.oppRankingInfo.gameID),
		updateAccount->boxAccount.lastMatchup.oppUserName,
		timestr,
		day,
		winAnal.pointsFor,
		winAnal.pointsAgainst);

	FLogmsg(LOG_GAMERESULT, "%ld- Sending mail: '%s'\n", cookie, mm->message);

	// Put it in the mailbox of the guy on this box who played last.
	//
	mm->from = catapult;
	strcpy(mm->to.userName, "");
	mm->to.box = state->loginData.userID.box;
	mm->to.userID = updateAccount->boxAccount.lastMatchup.player;
	strcpy(mm->title, gettext("Your Win"));
	mm->date = Server_GetSegaDate();
	WrapperDB_AddMailToIncoming(mm);

	free(mm);
}



// ===========================================================================
//		Generic
// ===========================================================================

//
// If the guy was a fucker (either by hitting reset or calling himself
// while losing), award a loss to the current player and a win to the
// other player.
//
// One thing that we don't want to change is their KONrating, because
// this doesn't say anything about skill level.
//
// Believe it or not, it's cleaner & easier to replicate a fair portion
// of Server_UpdateRankingInfo than it is to merge them into one.  Basic
// problem is that the guy who really needs his stats updated may not
// have a useful lastMatchup field anymore, so we need to be able to see
// both accounts.  Half the stuff from the original needs to be disabled
// anyway.
//
// BRAIN DAMAGE: this needs to update the player list entry on the box, too.
//
// (Interesting question: we're modifying somebody else's account.  Is there
// a chance of the change being lost due to concurrency issues?
// Yes, there is.  Sigh.)
//
Err
Server_SendFuckerResults(ServerState *state, Account *fuckerAccount, Err ceResult)
{
	NewGameResult *gameResult;
	WinAnalysis winAnal;
	RankingInfo *fuckerRankInfo, *fukdRankInfo;
	Account *fukdAccount = NULL;
	RankingInfo oppRankInfo;
	long matchValue, nextLevel;
	int dailyPtr;
	userIdentification tmpUserID;
	const GameInfo *gi = NULL;

	Logmsg("Sending fucker results\n");

	if (fuckerAccount->boxAccount.lastMatchup.wasSpecific & kLastChallengeMask)
	{
		PLogmsg(LOGP_NOTICE, "GLITCH: FuckerResults after challenge match\n");
		return (kFucked);
	}

	// Since he was a fucker, we'll have game error results instead of
	// game results.  If somehow we *do* have game results, use those.
	//
	// (We shouldn't be here if they finished a game and then one guy reset
	// on the other during the second game.)
	//
	if (state->validFlags & kServerValidFlag_GameResults) {
		PLogmsg(LOGP_NOTICE, "WEIRD: game results in SendFuckerResults\n");
		gameResult = (NewGameResult *)state->gameResult;
	} else
		gameResult = (NewGameResult *)&state->gameErrorResult;

	// We don't expect forfeits and evil resets to occur at the same time,
	// but use AnalyzeWin anyway for consistency.
	//
	Server_AnalyzeWin(gameResult, &winAnal);

	// He may have been tied rather than losing.  If so, give him one more
	// point.
	//
	// We use PossiblyLosing here because for some games (e.g. NBA JAM)
	// we regard the player as losing even if he was up by 1 point... prevents
	// hitting reset right as the winning 3-pointer is about to go in.
	//
	if (Server_PossiblyLosing(state, gameResult) == kNoError) {
		PLogmsg(LOGP_NOTICE, "GLITCH: alleged fucker was winning?\n");
		return (kFucked);
	} else if (winAnal.pointsFor == winAnal.pointsAgainst) {
		PLogmsg(LOGP_DBUG, " tie game, adding one more point\n");
		winAnal.pointsFor++;
		gameResult->localPlayer1Result++;	// well... it works
	}


	//
	// Start by sticking the fucker with a loss.
	//
	// You don't lose XBAND points for losing, so we don't need to touch those.
	// However, we do want to touch the address book entry (urgh).
	//

	FLogmsg(LOG_RATING, "F-UpdateRanking for '%s' (%s)  (%ld,%ld)[%ld]\n",
		fuckerAccount->playerAccount.userName,
		fuckerAccount->boxAccount.gamePhone.phoneNumber,
		fuckerAccount->boxAccount.box.box,
		fuckerAccount->boxAccount.box.region,
		(long)fuckerAccount->playerAccount.player);
	FLogmsg(LOG_RATING,
		"F-gameID=%.4s-0x%.8lx  ptsFor=%lu  ptsAgnst=%lu  time=%ld\n",
		(char *)&state->platformID,
		gameResult->gameID, winAnal.pointsFor,
		//gameResult->localPlayer1Result, gameResult->localPlayer2Result,
		winAnal.pointsAgainst,
		//gameResult->remotePlayer1Result, gameResult->remotePlayer2Result,
		gameResult->playTime);

	// If I don't have any ranking info, give me some.  Set the "dirty"
	// bit so it'll get updated next time I log in.
	//
	fuckerRankInfo = Server_FindRankingInfo(state, fuckerAccount,
		gameResult->gameID);
	if (!fuckerRankInfo->gameID) {
		// my first time
		Logmsg("F-My first time playing this game.\n");
		InitializePlayerRankings(fuckerRankInfo,
			Common_GetCanonicalGameID(state->platformID, gameResult->gameID));
	}
	fuckerRankInfo->detail.rankingFlags |= kRankingDirty;

	// We're going to add it to *today's* daily wins, even though the game
	// could've been held a while ago.
	//
	dailyPtr = Server_GetCurrentDailyPtr(state, fuckerRankInfo);
	PLogmsg(LOGP_DBUG, "F-Updating fucker daily[%d]\n", dailyPtr);
	fuckerRankInfo->detail.dailyTotalGames[dailyPtr]++;

	// oppRankInfo is a *copy* of the RankingInfo from lastMatchup.
	// (Since we're not calling CalculateContinuousRankings, we could
	// just use a pointer, but we won't in case we revert later.)
	//
	oppRankInfo = fuckerAccount->boxAccount.lastMatchup.oppRankingInfo;

	if (!fuckerAccount->boxAccount.lastMatchup.prevOpponent.when) {
		// can't happen?
		Logmsg("lastMatch.when == 0\n");
		memset(&oppRankInfo, 0, sizeof(RankingInfo));
		InitializePlayerRankings(&oppRankInfo,
			Common_GetCanonicalGameID(state->platformID, gameResult->gameID));
	}

	// Set houskeeping stuff.
	//
	fuckerRankInfo->timeOfLastPlay = fuckerAccount->boxAccount.lastMatchup.when;

	// Since we aren't going to call CalculateContinuousRankings, we need to
	// update our:
	//	numOpponentsPlayed
	//	totalWinsTimesTwo
	//	totalLossesTimesTwo
	//
	// If we're not sending mail to the guy who hit reset to tell him
	// that we're sticking him with a loss, we probably shouldn't change
	// his win/loss stats.
	//
	if ((gi = Common_GameInfoForGame(state->platformID, gameResult->gameID))
		== NULL)
	{
		// impossible?
		PLogmsg(LOGP_FLAW, "ERROR: couldn't find info for %.4s-0x%.8lx\n",
			(char *)&state->platformID, gameResult->gameID);
	} else if ((gameResult->gameError != kRebootDuringGameErr) ||
			   (gi->gameInfoFlags & kGIFlagResetMailBoth))
	{
		fuckerRankInfo->numOpponentsPlayed++;
		fuckerRankInfo->totalLossesTimesTwo += 2;
	} else {
		PLogmsg(LOGP_DBUG,
			"F-Not adding a loss for reset hit but MailBoth not set\n");
	}


	//
	// Now award a victory to the other guy, unless CompleteEnough is
	// going to handle it for us.
	//


	// If we get a RemoteWinner, the other guy will get a LocalWinner.
	// Of course, there are exceptional cases (e.g. player said "don't
	// continue after call waiting) that will cause asymmetry, but that's
	// not necessarily incorrect behavior.
	//
	if (ceResult == kEnoughCompletedRemoteWinner) {
		FLogmsg(LOG_RATING,
			"F-Not updating other, completeEnough says remote won\n");
		return (kNoError);
	}

	// Get his account.
	//
	tmpUserID.box =
		state->account->boxAccount.lastMatchup.prevOpponent.oppBoxSerialNumber;
	tmpUserID.userID =
		state->account->boxAccount.lastMatchup.prevOpponent.oppPlayer;
	tmpUserID.userName[0] = '\0';
	if ((fukdAccount = WrapperDB_GetAccount(&tmpUserID)) == NULL) {
		PLogmsg(LOGP_FLAW,
			"ERROR: unable to award victory to fukdAccount (%ld,%ld)[%ld]\n",
			tmpUserID.box.box, tmpUserID.box.region, tmpUserID.userID);
		return (kFucked);
	}
	FLogmsg(LOG_RATING, "F-UpdateRankingOther for '%s' (%s)  (%ld,%ld)[%ld]\n",
		fukdAccount->playerAccount.userName,
		fukdAccount->boxAccount.gamePhone.phoneNumber,
		fukdAccount->boxAccount.box.box,
		fukdAccount->boxAccount.box.region,
		(long)fukdAccount->playerAccount.player);

	// We know we're gonna change something.
	//
	fukdAccount->playerModified |= kPA_ranking;

	// Get the appropriate ranking info, and set the dirty bit.
	//
	fukdRankInfo = Server_FindRankingInfo(state, fukdAccount,
		gameResult->gameID);
	if (!fukdRankInfo->gameID) {
		// my first time
		Logmsg("F-His first time playing this game.\n");
		InitializePlayerRankings(fukdRankInfo,
			Common_GetCanonicalGameID(state->platformID, gameResult->gameID));
	}
	fukdRankInfo->detail.rankingFlags |= kRankingDirty;

	// The lastMatchup stuff may have been replaced by now (it may be
	// being replaced at this very instant), so use the fucker's current
	// ranking info.
	//
	oppRankInfo = *fuckerRankInfo;

	// We're going to add it to *today's* daily wins, even though the game
	// could've been held a while ago.
	//
	dailyPtr = Server_GetCurrentDailyPtr(state, fukdRankInfo);
	PLogmsg(LOGP_DBUG, "F-Updating fucked daily[%d]\n", dailyPtr);


	// Assign the appropriate number of XBAND points for a victory.  No
	// points are assigned for a tie.
	//
	nextLevel = GetNextLevelPoints(fukdRankInfo);
	FLogmsg(LOG_RATING,
		"F-Other is currently at XBAND points=%lu, level=%d, next at %d\n",
		fukdRankInfo->totalXBandPoints, GetCurrentLevel(fukdRankInfo),
		nextLevel);

	// Keep these just for fun (and for secret rankings), note they're
	// backwards from the fucker's copy.
	//
	fukdRankInfo->pointsFor += winAnal.pointsAgainst;
	fukdRankInfo->pointsAgainst += winAnal.pointsFor;

	// Award XBAND points.
	//
	matchValue = GetMatchPointValueForP1(fukdRankInfo, &oppRankInfo);
	fukdRankInfo->totalXBandPoints += matchValue;
	if (fukdRankInfo->totalXBandPoints > kMaxXBandPoints)
		fukdRankInfo->totalXBandPoints = kMaxXBandPoints;
	fukdRankInfo->detail.dailyTotalGames[dailyPtr]++;
	fukdRankInfo->detail.dailyWins[dailyPtr]++;
	FLogmsg(LOG_RATING,
		"F-Awarding %d XBAND points, totalXBandPoints now %lu%s\n",
		matchValue, fukdRankInfo->totalXBandPoints,
		(fukdRankInfo->totalXBandPoints >=nextLevel) ? " (promoted!)":"");

	//Server_GetNumWins(gameResult, &p1wins, &p2wins);

	// Don't do UpdateAddrBookAfterGame; the box doesn't.


	// Since we aren't going to call CalculateContinuousRankings, we need to
	// update our:
	//	numOpponentsPlayed
	//	totalWinsTimesTwo
	//	totalLossesTimesTwo
	//
	// We have already updated:
	//	totalXBandPoints
	//	dailyWins
	//
	fukdRankInfo->numOpponentsPlayed++;
	fukdRankInfo->totalWinsTimesTwo += 2;

	FLogmsg(LOG_RATING,
		"F-Now wins=%.1f-%.1f, points=%ld-%ld, XBAND points=%lu, level=%ld\n",
		(float)fukdRankInfo->totalWinsTimesTwo/2.0,
		(float)fukdRankInfo->totalLossesTimesTwo/2.0,
		fukdRankInfo->pointsAgainst, fukdRankInfo->pointsFor,
		fukdRankInfo->totalXBandPoints,
		GetCurrentLevel(fukdRankInfo));
	WrapperDB_UpdateAccount(fukdAccount);
	DataBaseUtil_FreeAccount(fukdAccount);

	return(kNoError);
}


//
// Determine what day and time it is in the *caller's* time zone.
//
// For now, just do it in PT, until we get an area code --> TZ map.  When
// this gets fixed, change all the "PST" strings in previous messages to
// be whatever is appropriate.  (Do a "man" on localtime to see how to make
// it do things for a different timezone.)
//
PRIVATE struct tm *
Server_GetLocalTime(ServerState *state, time_t when)
{
	struct tm *tm;

	// do nifty stuff
	tm = localtime(&when);
	// undo nifty stuff

	return (tm);
}

