/*
 * Catapult Entertainment, Inc.
 *
 * $Id: ServerWrapperDB.h,v 1.10 1995/09/27 15:48:41 chs Exp $
 *
 * $Log: ServerWrapperDB.h,v $
 * Revision 1.10  1995/09/27  15:48:41  chs
 * Changed FindAccessCode to FindUCA.
 *
 * Revision 1.9  1995/09/13  14:24:20  ted
 * Fixed warnings.
 *
 * Revision 1.8  1995/07/26  13:51:39  ansell
 * Added prototype for WrapperDB_FindPlayerInfoChanges().
 *
 * Revision 1.7  1995/06/19  20:29:43  fadden
 * Added WrapperDB_NewFindAccount, tweaked WrapperDB_FindAccountBySerial.
 *
 * Revision 1.6  1995/06/01  15:04:56  fadden
 * Merge in from newbr.
 * -> Changed lookup-by-phone functions.
 *
 * Revision 1.5  1995/05/12  05:58:21  fadden
 * Use ServerPlayerInfo instead of PlayerInfo.
 *
 * Revision 1.5.2.2  1995/05/24  01:18:28  fadden
 * Added WrapperDB_CreateNewAccount (a UCA call).
 *
 * Revision 1.5.2.1  1995/05/22  03:16:47  fadden
 * Shuffled restore prototypes.
 *
 */

/*
	File:		ServerWrapperDB.h

	Contains:	xxx put contents here xxx

	Written by:	Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <5>	11/15/94	DJ		Added WrapperDB_GenerateUniqueBoxSerialNumber.
		 <4>	11/12/94	DJ		Removed generateuniqueboxserialnumber.
		 <3>	11/10/94	DJ		Added initialize, shutdown, and savetodisk.
		 <2>	 11/9/94	DJ		Adding some more mail routines to WrapperDB
		 <1>	 11/9/94	DJ		Wrappers for database routines that will access Oracle.

	To Do:
*/


#ifndef __ServerWrapperDB__
#define __ServerWrapperDB__

#include "ServerDataBase.h"


Err WrapperDB_Initialize(void);
Err WrapperDB_Shutdown(void);
void WrapperDB_SaveToDisk(void);

Err WrapperDB_FindUserIdentification(const userIdentification *userID, userIdentification *updatedUserID);
ServerPlayerInfo **WrapperDB_FindPlayerInfoChanges(const userIdentification *userIDList, const userIdentification *userID, const long lastChecked);
ServerPlayerInfo *WrapperDB_FindPlayerInfo(const userIdentification *playerID, const userIdentification *userID);
Account *WrapperDB_GetAccount(const userIdentification *userID);
Err WrapperDB_CreatePlayerAccount(userIdentification *userID, long platformID, long *result, Account **account);
Err WrapperDB_UpdateAccount(const Account *account);
Err WrapperDB_CreateBoxAndPlayerAccount(userIdentification *userID, phoneNumber *boxPhoneNumber, long platformID, long *result, Account **account);

//Err WrapperDB_FindReplacementAccountByGamePhoneAndPlayerNum(phoneNumber *newBoxPhoneNumber, unsigned char playerNum, long platformID, Account **account);
//Err WrapperDB_FindAccountByGamePhoneAndPlayerNum(phoneNumber *newBoxPhoneNumber, unsigned char playerNum, long platformID, Account **account);
Err WrapperDB_FindAccount(const userIdentification *userID, Account **account);
Err WrapperDB_NewFindAccount(const userIdentification *userID, Account **account);
Err WrapperDB_FindSerialByPhone(const phoneNumber *phoneNum, long mode, long platformID, BoxSerialNumber *boxp);
Err WrapperDB_FindSerialByHWID(const HardwareID *hwid, long platformID, BoxSerialNumber *boxp);
Err WrapperDB_FindAccountBySerial(BoxSerialNumber *boxp, char playerNum, long *statusFlagp, Account **accountp);
Err WrapperDB_FindUCAInfoByCSID(int csid, UCAInfo **ucainfo);


Err WrapperDB_NewUpdateUserHandle(userIdentification *userID, long platformID, Account *account, long *result); // will supercede UpdateUserHandle.

Err WrapperDB_AddMailToIncoming(const Mail *mail);
long WrapperDB_GetNumIncomingMail(const userIdentification *userID);
Mail *WrapperDB_GetIncomingMail(const userIdentification *userID, long mailIndex);
void WrapperDB_MarkMailAsSent(const userIdentification *userID, long mailIndex);
void WrapperDB_RemoveSentMail( const userIdentification *userID);

void WrapperDB_GenerateUniqueBoxSerialNumber(BoxSerialNumber *boxSerialNumber);

//
// UCA calls
//
Err WrapperDB_NonUCACreateNewAccount(unsigned int csid, phoneNumber *boxPhone, long platformID, char *prodstr, long billingType, Account **account);

#endif
