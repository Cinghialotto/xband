/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Rankings.c,v 1.8 1995/09/13 14:24:40 ted Exp $
 *
 * $Log: Server_Rankings.c,v $
 * Revision 1.8  1995/09/13  14:24:40  ted
 * Fixed warnings.
 *
 * Revision 1.7  1995/08/25  17:44:24  fadden
 * Don't update KONratings if the guy only won by forfeit (i.e. he was actually
 * losing at the time, but the other guy's cat caught fire).
 *
 * Revision 1.6  1995/05/26  23:46:45  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_Rankings.c

	Contains:	KON's rating stuff

	Written by:	KON


	Change History (most recent first):

		 <5>	12/13/94	ATM		Change xpoints to unsigned, though it looks like Kon was
									watching for overflow anyway.
		 <4>	11/16/94	ATM		Add KON's new match worth stuff, but leave it commented out.
		 <3>	 11/2/94	ATM		Updated for changed RankingInfo struct.
		 <2>	10/31/94	ATM		Initialize RankingInfo to zero with memset.
		 <1>	10/17/94	ATM		Moved here from DataBase_Rankings.c.
		<13>	10/16/94	ATM		Replaced provisional stuff.  Now we just do the normal ratings
									stuff, but don't count win/loss against the other guy.
		<12>	10/15/94	ATM		Mumble.
		<11>	10/14/94	ATM		Now it sucks less.
		<10>	10/14/94	ATM		It sucks.  Whatever.
		 <9>	10/14/94	ATM		Added a return, twiddled provisional stuff.
		 <8>	10/14/94	ATM		Major changes to the way provisional stuff works.
		 <7>	10/14/94	ATM		Added a logmsg to indicate that the rating computed is based on
									one or both players being in the Provisional Zone.
		 <6>	10/14/94	ATM		Twiddled logmsgs.
		 <5>	10/10/94	ATM		Made InitializePlayerRankings init the rest of the fields in
									RankingInfo.
		 <4>	 10/4/94	ATM		Need to adjust stuff in GetMatchPointValueForP1, or new players
									never get any xpoints.
		 <3>	 10/4/94	ATM		Make first transition at 2.
		 <2>	 10/1/94	ATM		Added some log messages.
		 <1>	 10/1/94	ATM		Checked into server source tree.
		 <6>	 9/27/94	KON		Added GetNextLevelPoints function.
		 <5>	 9/27/94	KON		Added function to return game point values.
		 <4>	 9/25/94	KON		Pin ratings at zero.
		 <3>	 9/24/94	KON		wins are now 2, ties 1, and losses 0. Made normal function array
									a const.
		 <2>	 9/24/94	KON		First checked in.

	To Do:
*/

#include <math.h>
#include <memory.h>
#include "Server.h"
#include "ServerDataBase.h"
#include "Server_Rankings.h"
#include "Common_Missing.h"

//
// external entry points defined in Rankings.h
//

//
// internal functions
//
static long GetK( RankingInfo *r1 );
static short GetWinExpectancy( long rankDelta );
static unsigned long GetLevelPointValue( short level );

//
// Initialize a RankingInfo struct to initial values.  Marks the structure
// as "dirty" so that the server will send a copy to the box.
//
void
InitializePlayerRankings( RankingInfo *rank, long gameID )
{
	PLogmsg(LOGP_PROGRESS, "InitializePlayerRankings 0x%.8lx\n", gameID);

	memset(rank, 0, sizeof(RankingInfo));

	rank->rating = kProvisionalRating;
	rank->detail.rankingFlags = kRankingIsProvisional | kRankingDirty;

	rank->gameID = gameID;
	rank->detail.dbid = 255;
}

void CalculateContinuousRankings( RankingInfo *r1, RankingInfo *r2,
	long p1Wins, long p2Wins, Boolean forfeitOnly )
{
long	winExpectationP1;
long	winExpectationP2;
long	rankDifference;
long	p1WinPercent;

//
// NOTE: A win is 2, a tie is 1, and a loss counts 0
//

	if( p1Wins+p2Wins == 0) {
		PLogmsg(LOGP_FLAW, "CalculateContinuousRankings: p1 and p2 both zero\n");
		return;
	}
	
	p1WinPercent = (100*p1Wins)/(p1Wins+p2Wins);

	// A win at MK gets you 3 to 5 matchWins and 1 totalWin (6-10 and 2
	// after multiplying by 2, which should be done by the caller).
	//
	// (This is true only if the feature is enabled, which it currently
	// isn't... a win at MK is always a 100% win right now.  ++ATM 950825)
	//
	r1->detail.matchWinsTimesTwo += p1Wins;
	r1->detail.matchLossesTimesTwo += p2Wins;
	if (p1Wins > p2Wins)
		r1->totalWinsTimesTwo += 2;
	else if (p1Wins < p2Wins)
		r1->totalLossesTimesTwo += 2;
	else {
		r1->totalWinsTimesTwo++;
		r1->totalLossesTimesTwo++;
	}
	r1->numOpponentsPlayed++;

	r2->detail.matchWinsTimesTwo += p2Wins;
	r2->detail.matchLossesTimesTwo += p1Wins;
	if (p2Wins > p1Wins)
		r2->totalWinsTimesTwo += 2;
	else if (p2Wins < p1Wins)
		r2->totalLossesTimesTwo += 2;
	else {
		r2->totalWinsTimesTwo++;
		r2->totalLossesTimesTwo++;
	}
	r2->numOpponentsPlayed++;

	if (forfeitOnly) {
		// He was losing when the other guy forfeit.  He gets all the
		// wins and stuff, but we don't touch his KONrating.
		//
		FPLogmsg(LOG_RATING, LOGP_DBUG,
			"NOT updating KONratings: winning player forfeit\n");
		return;
	}

//
// Look for players who are transitioning from provisional to real
//
// "Provisional" now just means that you don't affect the ratings of other
// opponents.
//
	if( (r1->detail.rankingFlags & kRankingIsProvisional) &&
		r1->numOpponentsPlayed >= kProvisionalGameCount )
	{
		r1->detail.rankingFlags &= ~(kRankingIsProvisional);

		FPLogmsg(LOG_RATING, LOGP_DBUG,
			"R1 transition from provisional to real\n");
	}

//
// ratings for rated players don't change if opponent is provisional
//
	if( ! (r1->detail.rankingFlags & kRankingIsProvisional) &&
		(r2->detail.rankingFlags & kRankingIsProvisional))
	{
		FPLogmsg(LOG_RATING, LOGP_DBUG,
			"Player is rated, opponent was provisional, no change\n");
		return;
	}

	rankDifference = r1->rating - r2->rating;
		
	winExpectationP1 = GetWinExpectancy( rankDifference );	
	winExpectationP2 = 100 - winExpectationP1;
	
	// compute the new rating for this player
	r1->rating = r1->rating + (GetK( r1 )*( p1WinPercent - winExpectationP1 ))/100;
	FPLogmsg(LOG_RATING, LOGP_DBUG, "R1 calc: K=%d wp=%d we=%d, now %d\n",
		GetK(r1), p1WinPercent, winExpectationP1, r1->rating);
	if( r1->rating < 0 )
		r1->rating = 0;		

	// this one's just for show
	r2->rating = r2->rating + (GetK( r2 )*( (100-p1WinPercent) - winExpectationP2 ))/100;		
	FPLogmsg(LOG_RATING, LOGP_DBUG, "R2 calc: K=%d wp=%d we=%d, now %d\n",
		GetK(r2), (100-p1WinPercent), winExpectationP2, r2->rating);
	if( r2->rating < 0 )
		r2->rating = 0;		
}

short GetNormalFunctionWin( long rankDelta )
{
	return GetWinExpectancy( rankDelta );
}
//
// returns a value [0 - 100] indicating the win expectation
// rankDelta assumes chess rankings with sigma = 200
//
static short GetWinExpectancy( long rankDelta )
{
short	iii;
short	absRank;
short	returnVal;

static const short normalArray[103] =
		{ 0, 50,   4, 51,  11, 52,  18, 53,  26, 54,  33, 55, 40, 56,
		 47, 57,  54, 58,  62, 59,  69, 60,  77, 61,  84, 62, 92, 63,
		 99, 64, 107, 65, 114, 66, 122, 67, 130, 68, 138, 69,
		146, 70, 154, 71, 163, 72, 171, 73, 180, 74, 189, 75,
		198, 76, 207, 77, 216, 78, 226, 79, 236, 80, 246, 81,
		257, 82, 268, 83, 279, 84, 291, 85, 303, 86, 316, 87,
		329, 88, 345, 89, 358, 90, 375, 91, 392, 92, 412, 93,
		433, 94, 457, 95, 485, 96, 518, 97, 560, 98, 620, 99, 735, 100, 0x7FFF };

	absRank = rankDelta;
	if( absRank < 0 )
		absRank = -absRank;
		
	for( iii = 1; iii <= 50; iii++ )
	{
		if( normalArray[iii<<1] > absRank )
			break;
	}
	iii--;
	returnVal = normalArray[1+(iii<<1)];
	if( rankDelta < 0 )
		returnVal = 100-returnVal;
		
	return returnVal; 
}

static long GetK( RankingInfo *rank )
{
	if( rank->numOpponentsPlayed < 14 )
	{
		return (200 - rank->numOpponentsPlayed*10 );
	}
	else
		return 30;
}

static unsigned long GetLevelPointValue( short level )
{
static const unsigned long pointLevelArray[30] =
		{ 0, 2, 5,
		10,  20, 50,
		100, 200, 500,
		1000, 2000, 5000,  
		10000, 20000, 50000, 
		100000, 200000, 500000, 
		1000000, 2000000, 5000000,  
		10000000, 20000000, 50000000,
		100000000, 200000000, 500000000, 
		1000000000, 2000000000, 
		0x7FFFFFFF };

	if( level > 30 )
		return 0x7FFFFFFF;
	else
		return pointLevelArray[ level ];
}

//#define OLD_GMPV
#ifdef OLD_GMPV
unsigned long GetMatchPointValueForP1( RankingInfo *p1Rank, RankingInfo *p2Rank )
{
unsigned long	p2PointValue;
unsigned long	p1LevelDelta;
long	absoluteRating;
int		iii;
unsigned long	pointValue;

	//
	// Match points are point value for player 2 or 1/5th of 
	// the level delta for player 1...whichever is less
	// but never less than 1/20th of what is needed!!
	//

	absoluteRating =  p2Rank->rating - kMinimumRating;
	if( absoluteRating < 0 )
		absoluteRating = 0;
		
	iii = absoluteRating/kLevelStandardDeviation;
	p2PointValue = (1<<iii);

	for( iii = 1; iii < 32; iii++ )
	{
		if( p1Rank->totalXBandPoints < GetLevelPointValue(iii) )
			break;
	}

	p1LevelDelta = GetLevelPointValue(iii) - GetLevelPointValue(iii-1);
	
	if( p2PointValue > p1LevelDelta/5 )
		pointValue = p1LevelDelta/5;
	else
		pointValue = p2PointValue;
		
	if( p1Rank->totalXBandPoints < GetLevelPointValue( 21 ) )
	{
		if( pointValue < p1LevelDelta/20 )
			pointValue = p1LevelDelta/20;
	}
	else
	{
		if( pointValue < p1LevelDelta/50 )
			pointValue = p1LevelDelta/50;
	}

	// This can happen now that the first transition is at 2 wins instead
	// of 5.
	if (!pointValue)
		pointValue = 1;
	
	return pointValue;
}
#else OLD_GMPV
unsigned long GetMatchPointValueForP1( RankingInfo *p1Rank, RankingInfo *p2Rank )
{
unsigned long    p2PointValue;
unsigned long    p1LevelDelta;
long    absoluteRating;
int     currentLevel;
unsigned long    pointValue;
short   levelMaxMatches;
short   levelMinMatches;
static const short MinMatchTable[30] =
                { 2, 5, 5,
                5, 5, 10,
                10, 10, 10,
                15, 15, 15,
                15, 20, 20,
                20, 20, 30,
                30, 40, 40,
                50, 50, 75,
                75, 100, 200,
                300, 500,
                0x7FFF };

static const short MaxMatchTable[30] =
                { 2, 5, 5,
                5,  5, 10,
                15, 20, 40,
                50, 50, 100,
                100, 150, 200,
                200, 300, 300,
                500, 500, 1000,
                1000, 2000, 3000,
                4000, 5000, 6000,
                7000, 10000,
                0x7FFF };

        //
        // Match points are point value for player 2 or 1/5th of
        // the level delta for player 1...whichever is less
        // but never less than 1/20th of what is needed!!
        //

        absoluteRating = p2Rank->rating - kMinimumRating;
        if( absoluteRating < 0 )
                absoluteRating = 0;

        currentLevel = absoluteRating/kLevelStandardDeviation;
        p2PointValue = (1<<currentLevel);

        for( currentLevel = 1; currentLevel < 32; currentLevel++ )
        {
                if( p1Rank->totalXBandPoints <
					GetLevelPointValue(currentLevel) )
                        break;
        }

        p1LevelDelta = GetLevelPointValue(currentLevel) -
			GetLevelPointValue(currentLevel-1);

        levelMinMatches = MinMatchTable[currentLevel];
        levelMaxMatches = MaxMatchTable[currentLevel];

		//
		// Set the match maximum point value
		//
        if( p2PointValue > p1LevelDelta/levelMinMatches )
                pointValue = p1LevelDelta/levelMinMatches;
        else
                pointValue = p2PointValue;

		//
		// Set the match minimum point value
		//
        if( pointValue < p1LevelDelta/levelMaxMatches )
                        pointValue = p1LevelDelta/levelMaxMatches;

        // This can happen now that the first transition is at 2 wins instead
        // of 5.
        if (!pointValue)
                pointValue = 1;

        return pointValue;
}
#endif /*OLD_GPMV*/


unsigned long GetNextLevelPoints( RankingInfo *p1Rank )
{
int	iii;

	for( iii = 1; iii < 32; iii++ )
	{
		if( p1Rank->totalXBandPoints < GetLevelPointValue(iii) )
			break;
	}

	return GetLevelPointValue( iii );
}

//
// Determine what XBAND level the guy is at, based on how many XBAND
// points he has.
//
long GetCurrentLevel( RankingInfo *p1Rank )
{
	int iii;

	for (iii = 1; iii < 32; iii++) {
		if (p1Rank->totalXBandPoints < GetLevelPointValue(iii) )
			break;
	}

	return (iii - 1);
}


