/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_GeneralBoxUpdate.c,v 1.52 1996/01/25 17:51:47 hufft Exp $
 *
 * $Log: Server_GeneralBoxUpdate.c,v $
 * Revision 1.52  1996/01/25  17:51:47  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.51  1996/01/15  12:22:32  chs
 * Added code to try to prevent people getting stuck in tourney mode:
 * when we put the box in tourney mode, update the boxflags
 * in segad immediately to minimize the window during which a SIGHUP
 * will cause problems.
 * Also added a gConfig flag to force clearing tourney mode in the box.
 *
 * Revision 1.50  1996/01/04  22:54:12  hufft
 * added pop mail
 *
 * Revision 1.49  1995/12/11  18:00:33  ansell
 * Moved some PLogmsg()s from DBUG up to higher priority since they represented
 * error conditions.
 *
 * Revision 1.48  1995/11/15  18:44:11  hufft
 * simpilied name reference
 *
 * Revision 1.47  1995/11/15  18:41:01  hufft
 * added missing comment
 *
 * Revision 1.46  1995/11/13  19:44:34  hufft
 * pop lookup interface changes, rpc returns a list of pops, and dial patterns
 *
 * Revision 1.45  1995/11/01  10:29:10  chs
 * Split tourney "debug" flag into "nomatcher" and "nogamepatch" flags,
 * to allow selective disabling of the various pieces of a tourney.
 *
 * Revision 1.44  1995/10/24  16:51:59  ted
 * Removed some obsolete comments.
 *
 * Revision 1.43  1995/10/19  22:25:15  hufft
 * Japan Database Changes
 *
 * Revision 1.42  1995/10/16  14:29:37  sriram
 * Cleaned up old tourney stuff. Modifications for new tourney format.
 *
 * Revision 1.41  1995/10/03  16:55:22  ted
 * Call Server_XNU_GeneralUpdate per box connect. Change Network Access X-Mail
 * title and text for Customer Support.
 *
 * Revision 1.40  1995/09/27  18:22:58  hufft
 * added Common_Phone_Code
 *
 * Revision 1.39  1995/09/25  23:42:53  steveb
 * Check gConfig.statOverride to determine whether Override800 or OverrideX25
 * need to be stat'ed and have their timestamps compared to the box's
 * dateLastConnect.
 *
 * Revision 1.38  1995/09/21  16:38:40  steveb
 * Added support for 800/X25 Overrides based on game phone.
 *
 * Revision 1.37  1995/09/18  21:32:49  steveb
 * Added support for 800/X25 Overrides based on player names.
 *
 * Revision 1.36  1995/09/17  20:45:55  steveb
 * Added support for selective 800 Number and X25 Chat String overrides.
 *
 * Revision 1.35  1995/09/16  19:24:37  fadden
 * Added a logmsg.
 *
 * Revision 1.34  1995/09/13  19:17:36  steveb
 * Added some code to selectively override the 800 number a box will call.
 *
 * Revision 1.33  1995/09/13  14:24:28  ted
 * Fixed warnings.
 *
 * Revision 1.32  1995/08/24  11:28:31  ted
 * Observe new kBoxFlag_DisableXBN flag.
 *
 * Revision 1.31  1995/08/07  13:11:22  ted
 * Fixed recurring pop lookup problem.
 *
 * Revision 1.30  1995/07/19  13:01:53  ted
 * Only display one phone number if both POPs are same in Server_SetBoxAccountPops.
 * Factor creditapproved flag into challenge area options.
 *
 * Revision 1.29  1995/07/17  18:37:00  fadden
 * Changed some logmsgs to either LOGP_PROGRESS or LOGP_DETAIL.
 *
 * Revision 1.28  1995/07/13  15:36:19  ted
 * Use gettext when sending pop changed mail to box.
 *
 * Revision 1.27  1995/07/11  22:05:03  ted
 * Replaced pop xmail with Joey-approved text.
 *
 * Revision 1.26  1995/07/10  21:00:30  rich
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.25  1995/07/10  10:35:07  ted
 * Added Server_SetBoxAccountPops which updates the box's pop numbers and sends
 * XMail to the box when the numbers change.
 *
 * Revision 1.24  1995/07/07  20:47:22  fadden
 * Put Server_SetTransportHold calls around three routines.
 *
 * Revision 1.23  1995/06/19  10:27:13  ted
 * Override help text and challenge area radio text when Nationwide in effect.
 * Removes the overriding db items when Nationwide is no longer in effect.
 *
 * Revision 1.22  1995/06/14  11:12:41  ted
 * Observe Server_GetSpecialPhone(state) & kSpecialLongDistance flag when updating
 * box's challenge area button.
 *
 * Revision 1.21  1995/06/08  11:13:43  ted
 * Final "Joey-approved" challenge area UI.
 *
 * Revision 1.20  1995/06/07  13:58:40  fadden
 * Added error checking to Server_SendXYString, made it public.
 *
 * Revision 1.19  1995/06/05  14:35:25  ted
 * Revert string to "Long" until we do the right thing for Joey.
 *
 * Revision 1.18  1995/05/30  10:12:18  ted
 * Display "National" instead of "Long" in the Setup screen. Enable the challenge
 * area option for Sega players who get free XBN or are VIPs.
 *
 * Revision 1.17  1995/05/26  23:46:19  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_GeneralBoxUpdate.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		<11>	 12/9/94	HEC		Send hometown if account flag has changed.
		<10>	11/22/94	HEC		Smarter hometown decision.  Removed long distance pop dialog to
									user.
		 <9>	11/12/94	DJ		Load password blaster code if account has emptystring one.
		 <8>	 11/9/94	DJ		Turned on password erase code.
		 <7>	 11/8/94	DJ		If there's no originalgamephone, copy gamephone in.  this is for
									BETA only.
		 <6>	 11/8/94	HEC		Fix POP probs
		 <5>	 11/7/94	DJ		Added passwordErase stuff.
		 <4>	10/29/94	ATM		Hmm, line was broken in half.
		 <3>	10/29/94	ATM		Don't bail when POPLookup returns kFucked.
		 <2>	10/20/94	DJ		Added disable outgoing mail.
		 <1>	10/18/94	DJ		first checked in

	To Do:
*/


#include <sys/types.h>
#include <sys/stat.h>
#include <malloc.h>
#include <strings.h>

#include "SegaTypes.h"
#include "ServerCore.h"
#include "Server.h"
#include "ServerState.h"
#include "Messages.h"
#include "UsrConfg.h"
#include "ServerDataBase.h"
#include "Server_Pop.h"
#include "Common.h"
#include "Common_ReadConf.h"
#include "Common_Missing.h"
#include "Server_Tournament.h"
#include "OpaqueStoreKeys.h"

#include "SegaIn.h"
#include "DBConstants.h"
#include "StringDB.h"
#include "DBTypes.h"

void Server_TestServerSwitch(ServerState *state);
void Server_sega_OverrideAcceptChallenges(ServerState *state);
void Server_snes_OverrideAcceptChallenges(ServerState *state);
Err Server_snes_SendString(ServerState *state, char *string, DBType type, DBID id);
void Server_Override800Number(ServerState *state);
void Server_OverrideX25ChatString(ServerState *state);

//
// Update the box if anything in the account has changed behind it's back.
// This includes
//		- POP number
//		- custom icon
//		- disable the account if it was closed (?)
//
int Server_GeneralBoxUpdate(ServerState *state)
{
long cons;
DBID id;


	PLogmsg(LOGP_PROGRESS, "Server_GeneralBoxUpdate\n");


	ASSERT_MESG(state->account, "Server_GeneralBoxUpdate: state->account was NULL.\n");
	if(!state->account)
		return(kServerFuncOK);


	// If this is a kiosk box, send the dbconstant.  There is no way
	// yet to unset this, so once a kiosk, always a kiosk!  12/27/94.
	//
	if(state->account->boxAccount.boxFlags & kBoxFlag_KioskBox)
	{
		Logmsg("Setting Kiosk dbconstants.\n");
		id = 254;
		cons = 7;
	        Server_SendDBConstants(state, 1, &id, &cons);
	}



	// If originalGamePhone not set, the set it (this is for BETA only!).
	// After BETA all accounts should have original set by UCA and also this is
	// checked at account creation time in ValidateLogin.  This code here is only
	// for boxes that may be been created early in BETA and didn't set originalGamePhone.
	//
	if(strlen(state->account->boxAccount.originalGamePhone.phoneNumber) == 0)
	{
		state->account->boxAccount.originalGamePhone = state->account->boxAccount.gamePhone;
		state->account->boxModified |= kBA_gamePhone;
	}

	//
	// Load the passwd blaster if you don't already have such a code.
	//
	if(strlen(state->account->playerAccount.passwordEraseCode) == 0)
		Server_GenerateAndSendPasswordEraseCode(state);

#if	0
	//
	// all of the phone/pop related update account setting, etc is done in Server_PopUpdate
	// which is always called by Server_ValidateLogin.
	//

	// don't do this if we just restored yer box (cuz we reload POP there).
	if(!state->boxRestored && state->account)
	{
		Server_PopUpdate(state, 0, 0, 0, 0, kX25_OTHER_CONNECT, false);
	}
#endif


	if(state->account)
	{
		//
		// See if customer service disabled mail for this account cuz he/she is foul-mouthed.
		//
		if(state->account->boxAccount.csUpdatedFlags & kCSUpdatedFlag_DisableOutgoingMail)
		{
			state->disallowOutgoingMail = true;
			Logmsg("Server_GeneralBoxUpdate: sending of mail has been disabled on this account.\n");
		}
		//
		// See if we need to update the user's town
		//
		if(state->account->boxAccount.csUpdatedFlags & kCSUpdatedFlag_HomeTownUpdated)
		{
			Server_SendNewBoxHometown(state, state->account->boxAccount.homeTown);
			Logmsg("Server_GeneralBoxUpdate: sending box home town (%s).\n",
				state->account->boxAccount.homeTown);
		}
		//
		// See if we need to switch between test/main servers
		//
		Server_TestServerSwitch(state);
		if (state->platformID == kPlatformGenesis)
			Server_sega_OverrideAcceptChallenges(state);
		if (state->platformID == kPlatformSNES)
			Server_snes_OverrideAcceptChallenges(state);
	}



	//
	// TourneyStuff:
	//
	if (Server_InitializeTourneyData(state) == kServerFuncEnd)
	    return(kServerFuncEnd);

	if (state->tourneyData &&
	    (state->tourneyData->flags & kTourneyNoGamePatchFlag) == 0)
	{
	    // A tourney is on right now and this box is playing in it.
	    // Enable tourney box patch.
	    Server_SetTourneyBoxMode(state);
	} else {
	    if (state->account->boxAccount.boxFlags & kBoxFlag_TourneyBox
			|| gConfig.forceClearBoxMode) {
	        // This box is not playing in a tourney now, but it appears 
	        // to be in tourney mode. Therefore, clear that state.
		Server_ClearBoxMode(state);
	    }
  	}


	/*
	 * Reprogram the 800 number and X25 Chat String for selected boxes.
	 */
	Server_Override800Number(state);
	Server_OverrideX25ChatString(state);

	// XBAND Nationwide Usage Housekeeping
	Server_XNU_GeneralUpdate(state);

	PLogmsg(LOGP_PROGRESS, "Server_GeneralBoxUpdate done\n");
	return(kServerFuncOK);
}


void Server_TestServerSwitch(ServerState *state)
{
	long switchToTest;
	long switchToMain;
	TestServerStore test;
	char bomb[1000];
    OpaqueStoreValue value;
	long err;

	//
	// READ OPAQUE STORE FOR TEST INFORMATION
	//

	PLogmsg(LOGP_PROGRESS, "Server_TestServerSwitch\n");

	switchToTest = 0;
	switchToMain = 0;

    value.buf = (char *)&test;
    value.numMaxBytes = sizeof(TestServerStore);
    err = OpqStore_GetKeyValue(&state->account->boxAccount.opaqueStore,
		kTestServerKey, &value);
    if (err == kOpqNoError)
    {
    	if (test.switchserver)	// switch servers
    	{
    		if (gConfig.isProduction)
    			switchToTest = 1;
    		else
    			switchToMain = 1;
			// clear switch request
			test.switchserver = 0;
			err = OpqStore_SetKeyValue(&state->account->boxAccount.opaqueStore,
				kTestServerKey, &value);
			if (err)
				printf("OpqStore_SetKeyValue err %ld\n", err);
			state->account->boxModified |= kBA_opaqueStore;
    	}
    }
    else if (err == kOpqUnknownKey)
    {
		PLogmsg(LOGP_DETAIL, "No test server data for box %ld\n",
			state->loginData.userID.box.box);
		return;
    }
    else
    {
		PLogmsg(LOGP_FLAW, 
	    "Server_TestServerSwitch: OpqStore_GetKeyValue failed with unknown error!\n");
	    return;
    }


	//
	// MAKE THE SWITCH TO TEST OR MAIN SERVER IF DETERMINED
	//

	if (switchToTest)
	{
		// Change the writeable string so it chooses the specified server.
		//
		unsigned char opCode;
		unsigned long length;
		char buffer[1000];
		xyString	*xystr;
		DBID		theID;
		DBType		theType;
		
		Logmsg("Switching to Test Server (%s) for box %ld\n",
			test.selector, state->loginData.userID.box.box);

		opCode = msAddItemToDB;
		Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode);
		
		xystr = (xyString *)buffer;
		xystr->xPos = 0;
		xystr->yPos = 0;
		sprintf(xystr->cString, "CATAPULT,%s\r", test.selector);
		length = sizeof(xyString) + strlen( xystr->cString );	// no need for +1 cuz xyString.cString[1] already
	
		theID = kCompuserveReturn1;	/* default for this str is 'CATAPULT,SEGA\r'  */
		theType = kStringType;
		
		Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
		Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
		Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length);
		Server_TWriteDataSync(state->session, length, (Ptr) xystr);

		sprintf(bomb, gettext("(Main Server) Future X25 connections will be through the Test Server (%s)."), xystr->cString);
		Server_SendDialog(state, bomb, false);
		state->disallowGameConnect = true;
		return;
	}

	if (switchToMain)
	{
	
		// Change the writeable string so it chooses the mainserver (SEGA on cm1).  9/28/94  dj
		//
		unsigned char opCode;
		unsigned long length;
		char buffer[1000];
		xyString	*xystr;
		DBID		theID;
		DBType		theType;
		
		Logmsg("Switching to Main Server for box %ld\n", state->loginData.userID.box.box);

		opCode = msAddItemToDB;
		Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode);
		
		xystr = (xyString *)buffer;
		xystr->xPos = 0;
		xystr->yPos = 0;
		sprintf(xystr->cString, "CATAPULT,SEGA\r");
		length = sizeof(xyString) + strlen( xystr->cString );	// no need for +1 cuz xyString.cString[1] already
	
		theID = kCompuserveReturn1;	/* default for this str is 'CATAPULT,SEGA\r'  */
		theType = kStringType;
		
		Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
		Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
		Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length);
		Server_TWriteDataSync(state->session, length, (Ptr) xystr);

		sprintf(bomb, gettext("(Test Server) Future X25 connections will be through the Main Server (%s)."), xystr->cString);
		Server_SendDialog(state, bomb, false);
		state->disallowGameConnect = true;
		return;
	}
}

// RSTR type is 108 (radio button text)
// DSTR type is 109 (help text)

void Server_snes_OverrideAcceptChallenges(ServerState *state)
{
	long xbn;
	long vip;
	long freexbn;

	freexbn = (state->account->boxAccount.boxFlags & kBoxFlag_FreeXBN);
	vip = ((Server_GetSpecialPhone(state) & kSpecialVIPTester)
		  || (state->account->boxAccount.boxFlags & kBoxFlag_VIP));
	xbn = ((state->account->boxAccount.restrictArea & kRestrictArea_XBNLongDistance)
		  && (state->account->boxAccount.boxFlags & kBoxFlag_CreditApproved)
		  && !(state->account->boxAccount.boxFlags & kBoxFlag_DisableXBN))
		  || vip || freexbn;

	// Override Challenge Area text/help if XBN available, else remove old db items
	if (xbn)
	{
		Server_snes_SendString(state, "Nationwide", 108, 12);
		Server_snes_SendString(state, "Matches may be long distance.", 109, 12);
		Server_snes_SendString(state, "Matches will be local.", 109, 13);
	}
	else
	{
		Server_DeleteDBItem(state, 108, 12);
		Server_DeleteDBItem(state, 109, 12);
		Server_DeleteDBItem(state, 109, 13);
	}
}

void Server_sega_OverrideAcceptChallenges(ServerState *state)
{
	unsigned char opCode;
	unsigned long length;
	DBID theID;
	DBType theType;
	static unsigned short new_radio_data[25] =
	{
		0x0008, 0x0007, 0x0021, 0x0009,
        0x0000, 0x000B, 0x0A00, 0x0000,
        0x0000, 0x0000, 0x00C0, 0x0000,
        0x000B, 0x0A00, 0x0009, 0x0800,
        0x0078, 0x0000, 0x0000, 0x0000,
        0x0002, 0x0000, 0x00FA, 0x0000,
        0x00FB
    };
	
	if (gConfig.overrideSegaAcceptChallenges)
	{
		long xbn;
		long vip;
		long ld;
		long freexbn;

		freexbn = (state->account->boxAccount.boxFlags & kBoxFlag_FreeXBN);
		vip = ((Server_GetSpecialPhone(state) & kSpecialVIPTester)
			|| (state->account->boxAccount.boxFlags & kBoxFlag_VIP));
		xbn = ((state->account->boxAccount.restrictArea & kRestrictArea_XBNLongDistance)
			&& (state->account->boxAccount.boxFlags & kBoxFlag_CreditApproved)
			&& !(state->account->boxAccount.boxFlags & kBoxFlag_DisableXBN))
			|| vip || freexbn;
		ld  = (state->account->boxAccount.restrictArea & (kRestrictArea_dialLongDistance
			| kRestrictArea_temporaryDialLongDistance)) || xbn
			|| (Server_GetSpecialPhone(state) & kSpecialLongDistance);
		
		Server_SendXYString(state, gettext("Challenge Area:"), 49, 192);
		Server_SendXYString(state, gettext("Local"), 49, 251);
		if (xbn)
			Server_SendXYString(state, gettext("Matches will be local."), 49, 193);
		else
			Server_SendXYString(state, gettext("Outgoing calls will be local."), 49, 193);
	
		opCode = msAddItemToDB;
		theType = 79;
		theID = 1;
		length = 25*sizeof(unsigned short);
		Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode);
		Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
		Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
		Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length);
		Server_TWriteDataSync(state->session, length, (Ptr) new_radio_data);
	
		// Make second choice either local or long depending on box capability
		if (ld)
		{
			if (xbn)
			{
				Server_SendXYString(state, gettext("Nationwide"), 49, 250);
				Server_SendXYString(state, gettext("Matches may be long distance."), 49, 194);
			}
			else
			{
				Server_SendXYString(state, gettext("Long Distance"), 49, 250);
				Server_SendXYString(state, gettext("Outgoing calls may be long distance."), 49, 194);
			}
		}
		else
		{
			Server_SendXYString(state, gettext("Local"), 49, 250);
			Server_SendXYString(state, gettext("Outgoing calls will be local."), 49, 194);
		}
	}
	else
	{
		// Delete any db items we may have overridden before
		Server_DeleteDBItem(state,49,192);
		Server_DeleteDBItem(state,49,193);
		Server_DeleteDBItem(state,49,194);
		Server_DeleteDBItem(state,49,250);
		Server_DeleteDBItem(state,49,251);
		Server_DeleteDBItem(state,79,1);
	}
}

Err Server_SendXYString(ServerState *state, char *string, DBType type, DBID id)
{
	unsigned char opCode;
	unsigned long length;
	char buffer[256];
	xyString	*xystr;

	if (strlen(string) >= 256) {
		PLogmsg(LOGP_FLAW, "String too long in Server_SendXYString (%d)\n",
			strlen(string));
		Common_Abort();
	}

	opCode = msAddItemToDB;
	xystr = (xyString *)buffer;
	xystr->xPos = 0;
	xystr->yPos = 0;
	strcpy(xystr->cString,string);
	length = sizeof(xyString) + strlen( xystr->cString );
	// no need for +1 cuz xyString.cString[1] already

	Server_SetTransportHold(state->session, true);
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &type);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &id);
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length);
	Server_TWriteDataSync(state->session, length, (Ptr) xystr);
	Server_SetTransportHold(state->session, false);

	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	return (kServerFuncOK);
}

Err Server_snes_SendString(ServerState *state, char *string, DBType type, DBID id)
{
	unsigned char opCode;
	unsigned long length;

	length = strlen(string) + 1;
	if (length >= 256)
	{
		PLogmsg(LOGP_FLAW, "String too long in Server_snes_SendString (%d)\n",
			strlen(string));
		Common_Abort();
	}

	opCode = msAddItemToDB;
	Server_SetTransportHold(state->session, true);
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &type);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &id);
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length);
	Server_TWriteDataSync(state->session, length, (Ptr) string);
	Server_SetTransportHold(state->session, false);

	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	return (kServerFuncOK);
}

void Server_DeleteDBItem(ServerState *state, DBType type, DBID id)
{
	unsigned char opCode;

	PLogmsg(LOGP_PROGRESS, "Server_DeleteDBItem %d %d\n", type, id);

	opCode = msDeleteItemFromDB;
	Server_SetTransportHold(state->session, true);
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &type);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &id);
	Server_SetTransportHold(state->session, false);
}


long	Server_SetBoxAccountPops(ServerState *state, phoneNumber *newPop1, phoneNumber *newPop2)
{
	PLogmsg(LOGP_PROGRESS, "Server_SetBoxAccountPops\n");

	// Determine if we should announce pop change to player
	if (Common_PhoneCompareNumbers(newPop1->phoneNumber,
		state->account->boxAccount.popPhone.phoneNumber)
	|| (Common_PhoneCompareNumbers(newPop2->phoneNumber,
		state->account->boxAccount.altPopPhone.phoneNumber)))
	{
		// Pops changed
		char prettyMain[24];
		char prettyAlt[24];
		char message[128];
					
		if (state->account)
		{
			Logmsg("Pops changed: Old = '%s' and '%s'. New = '%s' and '%s'.\n",
				state->account->boxAccount.popPhone.phoneNumber,
				state->account->boxAccount.altPopPhone.phoneNumber,
				newPop1->phoneNumber,
				newPop2->phoneNumber);
	
			state->account->boxAccount.popPhone = *newPop1;
			state->account->boxAccount.altPopPhone = *newPop2;
			state->account->boxModified |= kBA_popPhone;
		}

		// Inform player we updated his pop.
		
		if (newPop1->phoneNumber[0] != 0)
		{
			Common_PhoneFormatDisplay(newPop1->phoneNumber, prettyMain);
			Common_PhoneFormatDisplay(newPop2->phoneNumber, prettyAlt);

			if (Common_PhoneCompareNumbers(newPop1->phoneNumber, newPop2->phoneNumber) == 0)
			{
				sprintf(message,gettext("Your modem will dial %s each time "
				"it connects to XBAND. If this is a long distance call, "
				"charges will appear on your phone bill."), prettyMain);
			}
			else
			{
				sprintf(message,gettext("Your modem will dial either %s or %s each "
				"time it connects to XBAND. If these are long distance calls, "
				"charges will appear on your phone bill."), prettyMain, prettyAlt);
			}
			Server_SendMailFromXBAND(state, gettext("XBAND"), gettext("Network Access"), message,0);
		}
		return(1);
	}
	else
	{
		return(0);
	}
}
void Server_Override800Number(ServerState *state)
{
	struct stat stat_buf;
	unsigned char chat;
	unsigned char code;
	unsigned char zero;
	unsigned long len;
	char *number;
	char bomb[100];
	char *name;
	char buf[80];
	int override;
	DBType type;
	int dialog;
	FILE *fp;
	DBID id;
	int box;
	int rv;
	int lo;
	int hi;
	char	*argv[5];

	if ( gConfig.statOverride )
	{
		if (stat("Override800", &stat_buf) == -1 )
			return;
	
		if ( stat_buf.st_mtime < state->account->userAccount.dateLastConnect )
			return;
	}
	fp = fopen("Override800", "r");
	if ( fp == NULL )
		return;

	while ( fgets(buf, 80, fp) ) {
		override = 0;

		if ( buf[0] == '#' )
			continue;

		rv = Common_ArgList(4, argv, buf);
		if (rv >= 3)
		{
			number = argv[0];
			dialog = atoi(argv[1]);
			if ( !Common_PhoneNumberValid800(number) ) {
				if (LOCALE_PHONE_C() || gConfig.ustest)
				{
					PLogmsg(LOGP_NOTICE, "Bogus 800 number format.  Must be [1800ABCDEFG]\n");
				}
				else
				{
					PLogmsg(LOGP_NOTICE, "Bogus 0120 number format.  Must be [0120-ABCDEFG]\n");
				}
				continue;
			}
		}
		if ( rv == 4 ) {
			lo = atoi(argv[2]);
			hi = atoi(argv[3]);
			PLogmsg(LOGP_DBUG, "800 override for boxes %d - %d : %s\n", lo, hi, number);

			box = state->account->boxAccount.box.box;
			if ( box >= lo && box <= hi ) {
				override = 1;
				PLogmsg(LOGP_DBUG, "Overriding box %d to %s\n", box, number);
			}
		}
		else if (rv == 3)
		{
			name = argv[2];
			if ( rv == 3 ) {
				if (strcmp(name, "0"))
				{
					/*
					 * This can be either a quoted player name or an unquoted
					 * game phone.
					 */
					if ( name[0] == '"' ) {
						/* get rid of the quotes */
						name[strlen(name) -1] = 0x00;
						name++;
						PLogmsg(LOGP_DBUG, "800 override for user %s : %s\n", name, number);
						if (!strcmp(name, state->account->playerAccount.userName))
						{
							override = 1;
							PLogmsg(LOGP_DBUG, "Overriding user %s to %s\n", name, number);
						}
					}
					else
					{
						PLogmsg(LOGP_DBUG, "800 override for phone %s : %s\n", name, number);
						if (!Common_PhoneCompareNumbers(name, 
							state->account->boxAccount.gamePhone.phoneNumber)) {
							override = 1;
							PLogmsg(LOGP_DBUG, "Overriding phone %s to %s\n", name, number);
						}
					}
				}
			}
			else {
				PLogmsg(LOGP_NOTICE, "Bogus 800 override format:%s\n", buf);
				continue;
			}
		}

		if ( override ) {
			code = msAddItemToDB;

			switch ( state->platformID ) {
				case kPlatformGenesis: 
					type = 98; 
					break;
				case kPlatformSNES: 
				case kPlatformSJNES: 
					type = 101; 
					break;
				default:
					PLogmsg(LOGP_FLAW, "Unhandled platform type in Override800\n");
					continue;
			}

			id = 2;
			len = 14;
			chat = 1;
			zero = 0;

			Server_SetTransportHold(state->session, true);
			Server_TWriteDataSync(state->session, sizeof(messOut),(Ptr) &code);
			Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &type);
			Server_TWriteDataSync(state->session, sizeof(DBID),   (Ptr) &id);
			Server_TWriteDataSync(state->session, sizeof(long),   (Ptr) &len);
			Server_TWriteDataSync(state->session, sizeof(char),   (Ptr) &chat);
			Server_TWriteDataSync(state->session, sizeof(char),   (Ptr) &zero);
			Server_TWriteDataSync(state->session, 12, number);
			Server_SetTransportHold(state->session, false);

			if ( dialog ) {
				sprintf(bomb, gettext(
					"(SERVER) Your server 800 number has been changed to: %s."),
					number);
				Server_SendDialog(state, bomb, false);
			}

			return;
		}
	}
}

void Server_OverrideX25ChatString(ServerState *state)
{
	struct stat stat_buf;
	char *platform;
	char *string;
	char bomb[100];
	char *name;
	char buf[80];
	int override;
	int dialog;
	FILE *fp;
	int box;
	int rv;
	int lo;
	int hi;
	char	*argv[6];

	if ( gConfig.statOverride )
	{
		if ( stat("OverrideX25", &stat_buf) == -1 )
			return;
	
		if ( stat_buf.st_mtime < state->account->userAccount.dateLastConnect )
			return;
	}
	fp = fopen("OverrideX25", "r");
	if ( fp == NULL )
		return;

	while ( fgets(buf, 80, fp) ) {
		override = 0;

		if ( buf[0] == '#' )
			continue;

		rv = Common_ArgList(5, argv, buf);
//
//		platform, dialog, string, lo, hi
//
		if ( rv == 5 ) {
			platform = argv[0];
			dialog = atoi(argv[1]);
			string = argv[2];
			lo = atoi(argv[3]);
			hi = atoi(argv[4]);
			PLogmsg(LOGP_DBUG, "X25 override for %s boxes %d - %d : %s\n", 
				platform, lo, hi, string);

			box = state->account->boxAccount.box.box;
			if ( box >= lo && box <= hi ) {
				override = 1;
				PLogmsg(LOGP_DBUG, "Overriding box %d to %s\n", box, string);
			}
		}
		else
		{
//
//			platform, &dialog, string, name
//
            if ( rv == 4 ) {
				platform = argv[0];
				dialog = atoi(argv[1]);
				string = argv[2];
				name = argv[3];
				/*
				 * This can be either a quoted player name or an unquoted
				 * game phone.
				 */
				if ( name[0] == '"' ) {
					/* get rid of the quotes */
					name[strlen(name) -1] = 0x00;
					name++;
					PLogmsg(LOGP_DBUG, "X25 override for user %s : %s\n", name, string);
					if (!strcmp(&name, 
						state->account->playerAccount.userName)) {
						override = 1;
						PLogmsg(LOGP_DBUG, "Overriding user %s to %s\n", name, string);
					}
				}
				else {
					PLogmsg(LOGP_DBUG, "X25 override for phone %s : %s\n", name, string);
					if (!Common_PhoneCompareNumbers(name, 
						state->account->boxAccount.gamePhone.phoneNumber)) {
						override = 1;
						PLogmsg(LOGP_DBUG, "Overriding phone %s to %s\n", name, string);
					}
				}
            }
            else {
                PLogmsg(LOGP_NOTICE, "Bogus X25 override format");
                continue;
            }
		}

		if ( override ) {
			switch ( state->platformID ) {
				case kPlatformGenesis: 
					if ( strcasecmp(platform, "SEGA") != 0 )
						continue;
					break;
				case kPlatformSNES: 
					if ( strcasecmp(platform, "SNES") != 0 )
						continue;
					break;

				case kPlatformSJNES: 
					if ( strcasecmp(platform, "SJNES") != 0 )
						continue;
					break;
				default:
					PLogmsg(LOGP_FLAW, "Unhandled platform type in OverrideX25\n");
					continue;
			}

			sprintf(buf, "%s\r", string);
			Server_SendXYString(state, buf, kStringType, kCompuserveReturn1);

			if ( dialog ) {
				sprintf(bomb, gettext(
					"(SERVER) Your server chat string has been changed to: %s."),
					string);
				Server_SendDialog(state, bomb, false);
			}

			return;
		}
	}
}
