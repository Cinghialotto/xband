/*
 * Copyright:	� 1995 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Nationwide.c,v 1.6 1996/02/23 15:56:34 ted Exp $
 *
 * $Log: Server_Nationwide.c,v $
 * Revision 1.6  1996/02/23  15:56:34  ted
 * Fixed bug where if customer server increases someone's cap, but the person
 * already exceeded their previous cap, we need to clear their kXU_ExceededLimit
 * and kXU_NearingLimit usage flags so they can continue playing over XBN.
 *
 * Revision 1.5  1996/02/05  15:40:58  fadden
 * Added CVS keywords.
 *
 */

#include <unistd.h>
#include <string.h>
#include <malloc.h>
#include <memory.h>
#include "Server.h"
#include "ServerState.h"
#include "ServerDataBase.h"
#include "Common_ReadConf.h"
#include "Common_Missing.h"
#include "OpaqueStoreKeys.h"

PRIVATE Mail *Server_XNU_PrepareMail(ServerState *state);
PRIVATE void Server_XNU_CheckCap(ServerState *state);

Err Server_XBN_ReadMCIFile(ServerState *state)
{
	// Get MCI 800# and id code.
	// Stuff in state->carrierphone and state->carriercode.
	// Return true if there is a problem getting the information. This signals
	// Server_StartGamePlay to disable the XBAND Nationwide match.
	// Return false if information was retrieved.

	FILE *fp;
	long n;
	long tries;
	long acctlen;
	char acctstr[20];
	char s[40];
	char code[20];

	// Open MCI Data File
	for (tries = 2; tries >= 0; tries--)
	{
		fp = fopen(gConfig.mciFileName,"r");
		if (fp)
			break;
		else
		{
			if (!gConfig.isProduction)	// on test server, don't retry.
				break;
			Logmsg("Server_ReadMCIFile: '%s' not available, sleeping for 2 seconds.\n",
				gConfig.mciFileName);
			sleep(2);	// wait for file to be updated/copied before retrying.
		}
	}
	if (fp == nil)
	{
		Logmsg("Server_ReadMCIFile: Can't open %s.\n", gConfig.mciFileName);
		return 1;	
	}
	// Read phone number and id code
	fgets(s, sizeof(s), fp);
	fclose(fp);
	if (sscanf(s, "%10s %7s", state->carrierphone, code) != 2)
	{
		// Yikes! We could not succesfully scan the file!
		Logmsg("Server_ReadMCIFile: Could not understand '%s'.\n", s);
		return 1;
	}
	sprintf(state->carriercode,"%.7s0000", code);
	sprintf(acctstr,"%lu",state->connid);
	acctlen = strlen(acctstr);
	// fill in last four digits of carriercode (can't use sprintf to do this)
	for (n = 10 ; acctlen>0 && n>6; n--, acctlen--)
		state->carriercode[n] = acctstr[acctlen-1];
	Logmsg("Server_ReadMCIFile: %s and %s\n", state->carrierphone, state->carriercode);
	return 0;
}


// Scan the box.Account.mciPhoneList to see if the player's current game phone is listed.
// If so, he can be called on XBAND Nationwide, otherwise he cannot.
//
Boolean Server_XBN_IsCallable(ServerState *state)
{
	if (state->account->boxAccount.boxFlags & kBoxFlag_DisableXBN)
	{
		PLogmsg(LOG_DBUG,"Server_XBN_IsCallable: kBoxFlag_DisableXBN = 1.\n");
		return 0;	// Someone doesn't like this person, so they cannot play XBN!
	}
	if (!Common_PhoneHasNPA(state->account->boxAccount.gamePhone.phoneNumber))
	{
		PLogmsg(LOG_DBUG,"Server_XBN_IsCallable: gamePhone invalid!\n");
		return 0;	// illegal gamePhone!
	}
	if (!state->account->boxAccount.mciPhoneList)
	{
		PLogmsg(LOG_DBUG,"Server_XBN_IsCallable: mciPhoneList is null.\n");
		return 0;	// empty list so can't be called.
	}
	return strstr(state->account->boxAccount.mciPhoneList,
		state->account->boxAccount.gamePhone.phoneNumber) != 0;
}

//
// Server_ProcessSendQ calls us with the number of minutes uploaded
// from the box. We must check if the call was XBN, and make sure we don't
// count it more than once.
// 
void Server_XNU_AddMinutes(ServerState *state, long minutesUsed)
{
	struct tm *when;
	XBNBoxUsage *usage = &state->account->boxAccount.xbnUsage;

	// make sure we only do this if last matchup was billed XBN
	if (state->account->boxAccount.lastMatchup.callType != kXBNCall)
		return;
	if (!(state->account->boxAccount.lastMatchup.flags & kLM_tallyBoxEst))
		return;

	// clear flag so we don't try this again if SIGHUP occurs...
	state->account->boxAccount.lastMatchup.flags &= ~kLM_tallyBoxEst;
	state->account->boxModified |= kBA_lastMatchup;

	PLogmsg(LOGP_DETAIL, "Server_XNU_AddMinutes: %ld minutes\n", minutesUsed);
	when = localtime(&state->account->boxAccount.lastMatchup.when);
	
	if ((when->tm_mon == usage->current.month) && (when->tm_year == usage->current.year))
	{
		usage->current.minutes += minutesUsed;
		state->account->boxAccount.csUpdatedFlags |= kCSUpdatedFlag_UpdatedRestrictions;
		state->account->boxModified |= kBA_csUpdatedFlags | kBA_xbnUsage;
	}
	else if ((when->tm_mon == usage->previous.month) && (when->tm_year == usage->previous.year))
	{
		usage->previous.minutes += minutesUsed;
		state->account->boxAccount.csUpdatedFlags |= kCSUpdatedFlag_UpdatedRestrictions;
		state->account->boxModified |= kBA_csUpdatedFlags | kBA_xbnUsage;
	}
	Server_XNU_CheckCap(state);
	
	// cause Server_sega_SendRestrictions to update box restrictions
}

//
// On every connect see if we need to adjust the usage dates.
// If so, update the XBNBoxUsage and the box.
//
void Server_XNU_GeneralUpdate(ServerState *state)
{
	XBNBoxUsage *usage = &state->account->boxAccount.xbnUsage;
	struct tm *when;

	if (!(state->account->boxAccount.restrictArea & kRestrictArea_XBNMask))
		return;
		
	// set default monthly cap if not overridden and different
	if (!(usage->flags & kXU_OverrideLimit))
	{
		if (usage->monthlycap != gConfig.defaultXNMonthlyLimit)
		{
			usage->flags = 0;
			usage->monthlycap = gConfig.defaultXNMonthlyLimit;
			state->account->boxModified |= kBA_xbnUsage;
		}
	}

	when = localtime(&state->timeOfThisConnect);
	// Check for initial state of XBNBoxUsage
	if (usage->current.year == 0)
	{
		// initialize structure for the first time
		usage->current.minutes = 0;
		usage->current.month = when->tm_mon;
		usage->current.year = when->tm_year;
		usage->previous.minutes = 0;
		usage->previous.month = (when->tm_mon+11) % 12;
		usage->previous.year = 0;	// 0 year means N/A
		state->account->boxModified |= kBA_csUpdatedFlags | kBA_xbnUsage;
	}
	else if ((usage->current.month < when->tm_mon)
	|| (usage->current.year < when->tm_year))
	{
		usage->previous = usage->current;
		usage->current.minutes = 0;
		usage->current.month = when->tm_mon;
		usage->current.year = when->tm_year;
		state->account->boxModified |= kBA_csUpdatedFlags | kBA_xbnUsage;
	}
	// Check if current usage is less than the cap but kXU_ExceededLimit is set.
	// In this case, cap has been adjusted higher so we should turn off
	// the kXU_ExceededLimit flag so they can continue to play.
	if ((usage->current.minutes < usage->monthlycap) && (usage->flags & kXU_ExceededLimit))
	{
		usage->flags &= ~(kXU_ExceededLimit | kXU_NearingLimit);
		state->account->boxModified |= kBA_csUpdatedFlags | kBA_xbnUsage;
	}
}

#define XMAILTEXT1 \
	gettext("Your limit is %ld minutes. If you would like to increase " \
		"your limit, please mail in the authorization card " \
		"included in your confirmation letter or send written " \
		"authorization including the name and ")

#define XMAILTEXT2 \
	gettext("address on your credit card, cc #, cc expiration date, new limit, " \
	"modem phone number and signature matching the credit card to XBAND, " \
	"PO Box 2006, Cupertino, CA 95015-2006.")

PRIVATE void Server_XNU_CheckCap(ServerState *state)
{
	Mail *mm;
	XBNBoxUsage *usage = &state->account->boxAccount.xbnUsage;

	PLogmsg(LOGP_DETAIL, "Server_XNU_CheckCap\n");

	// Has box exceeded monthly limit?
	if (usage->current.minutes >= usage->monthlycap)
	{
		// have we already sent xmail/dialog?
		if (!(usage->flags & kXU_ExceededLimit))
		{
			mm = Server_XNU_PrepareMail(state);
			usage->flags |= kXU_ExceededLimit;
			state->account->boxModified |= kBA_xbnUsage;
			strcpy(mm->title, gettext("Exceeded Nationwide Limit (1)"));
			sprintf(mm->message, XMAILTEXT1, usage->monthlycap);
			WrapperDB_AddMailToIncoming(mm);
			strcpy(mm->title, gettext("Exceeded Nationwide Limit (2)"));
			strcpy(mm->message, XMAILTEXT2);
			WrapperDB_AddMailToIncoming(mm);
			free(mm);
			Server_SendDialog(state, gettext("You've exceeded your XBAND Nationwide limit. "
				"XBAND will match you locally until next month. See your X-MAIL "
				"for details."), true);
		}
	}
	else if (usage->current.minutes >= (gConfig.defaultXNPrecapThresh * usage->monthlycap))
	{
		// have we already sent xmail/dialog?
		if (!(usage->flags & kXU_NearingLimit))
		{
			mm = Server_XNU_PrepareMail(state);
			usage->flags |= kXU_NearingLimit;
			state->account->boxModified |= kBA_xbnUsage;
			strcpy(mm->title, gettext("Near Nationwide Limit (1)"));
			sprintf(mm->message, XMAILTEXT1, usage->monthlycap);
			WrapperDB_AddMailToIncoming(mm);
			strcpy(mm->title, gettext("Near Nationwide Limit (2)"));
			strcpy(mm->message, XMAILTEXT2);
			WrapperDB_AddMailToIncoming(mm);
			free(mm);
			Server_SendDialog(state, gettext("You're approaching your XBAND Nationwide limit. "
				"See your X-Mail for details."), true);
		}
	}
}

//
// Return true if player is below his XN Monthly Cap
//
Boolean Server_XNU_IsBelowCap(ServerState *state)
{
	struct tm *when;
	XBNBoxUsage *usage = &state->account->boxAccount.xbnUsage;

	PLogmsg(LOGP_DETAIL, "Server_XNU_IsBelowCap\n");
	when = localtime(&state->timeOfThisConnect);
	if (when->tm_mon != usage->current.month
	|| when->tm_year != usage->current.year)
	{
		// set up new month
		usage->previous = usage->current;
		usage->current.year = when->tm_year;
		usage->current.month = when->tm_mon;
		usage->current.minutes = 0;
		usage->flags = 0;
		if (!(usage->flags & kXU_OverrideLimit))
			usage->monthlycap = gConfig.defaultXNMonthlyLimit;
		state->account->boxModified |= kBA_xbnUsage;
		return true;
	}
	else if (usage->current.minutes < usage->monthlycap)
		return true;
		
	Server_SendDialog(state, gettext("You hit your XBAND Nationwide limit. You will "
		"be matched locally until next month. Set Challenge Area to \"Local\" to "
		"avoid this message in the future."), true);

	return false;
}

PRIVATE Mail *Server_XNU_PrepareMail(ServerState *state)
{
	Mail *mm = (Mail *)malloc(sizeof(Mail) + 512);
	if (mm == NULL) {
		PLogmsg(LOGP_FLAW, "Server_XNU_PrepareMail: Out of memory.\n");
		Common_Abort();
	}
	mm->from.box.region = -1;
	mm->from.box.box = -1;
	mm->from.userID = 0;
	mm->from.colorTableID = 0;
	mm->from.ROMIconID = kXBANDPlayerIcon;
	strcpy(mm->from.userTown, gConfig.catapultTown);
	strcpy(mm->from.userName, gettext("XBAND"));
	mm->date = Server_GetSegaDate();
	strcpy(mm->to.userName, "");
	mm->to.box = state->account->boxAccount.box;
	mm->to.userID = state->account->playerAccount.player;
	return mm;
}


#if UNUSED
Err Server_XNU_ReadOpaqueStore(ServerState *state, XBNBoxUsage *usage)
{
	Err err;
	long key = kXBNBoxUsageKey;
    OpaqueStoreValue osval;
    u_int ossize;
    OpaqueStore *os = &state->account->boxAccount.opaqueStore;

	PLogmsg(LOGP_DETAIL, "Server_XNU_ReadOpaqueStore\n");
	// Get size of existing opaque store entry
	osval.buf = (char *)usage;
	osval.numMaxBytes = osval.numBytes = sizeof(XBNBoxUsage);
    err = OpqStore_GetValueSize(os, key, &ossize);
    if (err != kOpqNoError)
    	return err;
	// make sure the old value was the right size
	if (ossize != osval.numMaxBytes)
	{
	    Logmsg("Server_XNU_ReadOpaqueStore: wrong opaque size\n");
	  	return kOpqInsufficientValueSize;
	}
	else
	{
		// get the old value
		err = OpqStore_GetKeyValue(os, key, &osval);
		if (err != kOpqNoError)
		{
		    Logmsg("Server_XNU_ReadOpaqueStore: OpqStore_GetKeyValue err: %d\n", err);
		    return err;
		}
	}
	// data has been read successfully
	return noErr;
}

Err Server_XNU_WriteOpaqueStore(ServerState *state, XBNBoxUsage *usage)
{
	Err err;
	long key = kXBNBoxUsageKey;
    OpaqueStoreValue osval;
    OpaqueStore *os = &state->account->boxAccount.opaqueStore;

	PLogmsg(LOGP_DETAIL, "Server_XNU_WriteOpaqueStore\n");
	osval.buf = (char *)usage;
	osval.numMaxBytes = osval.numBytes = sizeof(XBNBoxUsage);
	err = OpqStore_SetKeyValue(os, key, &osval);
	if (err != kOpqNoError)
	{
	    Logmsg("Server_XNU_WriteOpaqueStore: OpqStore_SetKeyValue err: %ld.\n", err);
		err = OpqStore_DeleteKeyValue(os, key);
		// don't care about the err, just delete it, or ignore if none to delete
		err = OpqStore_NewKeyValue(os, key, &osval);
		if (err != kOpqNoError)
		{
		    Logmsg("Server_XNU_WriteOpaqueStore: OpqStore_NewKeyValue err: %ld\n", err);
		    return err;
		}
	}
	state->account->boxModified |= kBA_opaqueStore;
	return noErr;
}
#endif
