
/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Log.h,v 1.21 1995/11/17 22:02:58 felix Exp $
 *
 * $Log: Server_Log.h,v $
 * Revision 1.21  1995/11/17  22:02:58  felix
 * Added WriteSmartCardInfo
 *
 * Revision 1.20  1995/11/12  20:42:32  davej
 * Added new kBlogBillEcp and retrofitted kBlogBillPromo.
 *
 * Revision 1.19  1995/10/27  19:43:37  steveb
 * Just did some long needed housecleaning.  No new code.
 *
 * Revision 1.18  1995/10/23  18:25:25  davej
 * Backed out previous changes for ECP DB fields.
 *
 * Revision 1.17  1995/10/23  17:03:28  davej
 * Defined new billing type code kBlogBillEcp and retrofitted kBlogBillPromo.
 *
 * Revision 1.16  1995/10/16  14:29:40  sriram
 * Cleaned up old tourney stuff. Modifications for new tourney format.
 *
 * Revision 1.15  1995/09/13  14:24:33  ted
 * Fixed warnings.
 *
 * Revision 1.14  1995/08/03  17:38:19  felix
 * Added BlogMatchupRegurg
 *
 * Revision 1.13  1995/07/17  17:24:36  ted
 * Defined BlogPeerTime struct.
 *
 * Revision 1.12  1995/06/26  13:23:20  felix
 * Added BlogBoxTypeInfo
 *
 * Revision 1.11  1995/06/08  11:10:24  ted
 * Added BlogLocalTime struct.
 *
 * Revision 1.10  1995/05/26  23:46:32  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_Log.h

	Contains:	Prototypes and declarations for log stuff

	Written by:	Andy McFadden


	Change History (most recent first):

		 <6>	12/14/94	SR		Miscellaneous additions/mods to binlog; bumped version to 2.
		 <5>	11/15/94	SR		Binary log - first pass.
		 <4>	 9/18/94	ATM		THIS FILE IS NOW OBSOLETE.  See Common_Log.h.
		 <3>	 9/16/94	ATM		Added LOG_NETERR.
		 <2>	 9/11/94	ATM		Shuffled things a bit.
		 <1>	 9/11/94	ATM		first checked in

	To Do:
*/


#ifndef __Server_Log_h__
#define __Server_Log_h__

#include <time.h>
#include "SegaTypes.h"
#include "Server.h"


// Increment the version number when any of the
// structs change.
#define kLogVersionNumber	7


/* sunsega termination conditions */
enum {
	kConnExitUnknown = 0,
	kConnExitGraceful,				// normal termination
	kConnNeverConnected,			// InitServerConnection() failed
	kConnExitServerAbort,			// some func returned kServerFuncAbort
	kConnExitSighup,				// SIGHUP was received prematurely
	kConnExitTimeout,				// SIGALARM was received
	kConnExitGenericSignal,			// zapped by a generic signal
	kConnExitRpcAbort				// some RPC failure
};

typedef struct {
    short     areaCode;
    int       localNumber;
} BlogPhoneNumber_v0;

typedef char BlogPhoneNumber[24];

#define kLogX25AddressSize 14

typedef struct {
    char        		x25Addr[kLogX25AddressSize+1];
    BlogPhoneNumber_v0	main;
    BlogPhoneNumber_v0	alt;
} BlogPopInfo_v0;

typedef struct {
    char        		x25Addr[kLogX25AddressSize+1];
    BlogPhoneNumber		main;
    BlogPhoneNumber		alt;
} BlogPopInfo;

typedef struct {
    BoxSerialNumber     serialNum;
    unsigned char   	userNum;
} BlogBoxInfo, BlogBoxInfo_v0;

typedef struct {
	long				cookie;
} BlogCookieInfo;

typedef struct {
    BlogBoxInfo			boxInfo;
    BlogPhoneNumber_v0	phone;			// always full (10-digit) opponent phone number
    long				cookie;			// connection cookie of opponent
} BlogOpponentInfo_v0;

typedef struct {
    BlogBoxInfo			boxInfo;		// opponent box info
    BlogPhoneNumber		phone;			// opponent phone (normalized 10-digit number)
    long				cookie;			// opponent cookie
    unsigned			toll:1;			// match was non-local
    unsigned			sprint:1;		// Sprint calling card used
    unsigned			mci:1;			// MCI 800RA used (XBAND Nationwide)
    unsigned			billslave:1;	// opponent should be billed for mci usage
    unsigned			billmaster:1;	// master should be billed for mci usage
    unsigned			xbnslave:1;		// slave subscribes to XBAND Nationwide
    unsigned			xbnmaster:1;	// master subscribes to XBAND Nationwide
} BlogOpponentInfo;

typedef struct {
	char				id[16];			// secret code
	char				d800[11];		// 10-digit 800# dialed
} BlogCarrierCode;

typedef struct {
	long				boxType;		// i.e. sn07,
} BlogBoxTypeInfo;						//      in00

#define kBlogInvalid	0

#define kBlogMail	1
#define kBlogGame	2

#define kBlogAutomatch	1
#define kBlogChallenge	2

#define kBlogDial	1
#define kBlogWait	2

// accountCreation values
#define kBlogPlayerCreated	1
#define kBlogAccountCreated	2

// billingType - keep in sync with cat_fld_bill_type_t in cat_share_defs.h
#define kBlogBillUndefined 	1	// invalid - used during acct create 
#define kBlogBillPrepaid 	2	// prepaid to keep positive balance 
#define kBlogBillInvoice 	3	// invoiced monthly 
#define kBlogBillDebit 		4	// checking account debit 
#define kBlogBillVisa 		5	// Visa 
#define kBlogBillMcard 		6	// Mastercard 
#define kBlogBillAmex 		7	// American Express 
#define kBlogBillSmartc 	8	// Smartcard 
#define kBlogBillSubord 	9	// roll up to parent account 
#define kBlogBillBeta 		10	// beta testers - ignored by billing 
#define kBlogBillInternal 	11	// internal employee, same as guest 
#define kBlogBillGuest 		12	// no charge, but credit limits apply 
#define kBlogBillPromo 		13	// promotional account, unlimited play
#define kBlogBillEcp 		14	// ECP: Electronic Check Processing

//
// Stadler's Stuff for debugging Sighups etc. 12/13/94
// (struct copied from Server_ProcessSendQ.c)
typedef struct {
        short   version;		// 1
        short   checkErr;		// Result from TCheckError
        short   openErr;		// TOpen result OR progress code
        short   lastOpcode;		// Most recent opcode
} StreamErrorReport_v1;
#define StreamErrorReport StreamErrorReport_v1

typedef struct {
    unsigned		validLogin		: 1;
    unsigned		validAccount		: 1;
    unsigned		x25Conn    		: 1;
    unsigned		crashRecord  		: 1;
    unsigned		gameResults 		: 1;
    unsigned		gameErrorResults 	: 1;
    unsigned		netErrors800 		: 1;
    unsigned		netErrorsX25 		: 1;
    unsigned		streamError		: 1;

    unsigned		mailOrGame  		: 2;
    unsigned		autoOrChall 		: 2;			
    unsigned		dialOrWait  		: 2;
    unsigned		accountCreation		: 2;

	} BlogLoginInfoFlags_v0;
	
typedef struct {
    unsigned		validLogin		: 1;
    unsigned		validAccount		: 1;
    unsigned		x25Conn    		: 1;
    unsigned		crashRecord  		: 1;
    unsigned		gameResults 		: 1;
    unsigned		gameErrorResults 	: 1;
    unsigned		netErrors800 		: 1;
    unsigned		netErrorsX25 		: 1;
    unsigned		streamError		: 1;

    unsigned		mailOrGame  		: 2;
    unsigned		autoOrChall 		: 2;			
    unsigned		dialOrWait  		: 2;
    unsigned		accountCreation		: 2;
    unsigned		tournament			: 1;

	} BlogLoginInfoFlags_v1;
	
typedef struct {
    unsigned		validLogin			: 1;
    unsigned		validAccount		: 1;
    unsigned		x25Conn				: 1;
    unsigned		crashRecord  		: 1;
    unsigned		gameResults 		: 1;
    unsigned		gameErrorResults 	: 1;
    unsigned		netErrors800 		: 1;
    unsigned		netErrorsX25 		: 1;
    unsigned		streamError			: 1;

    unsigned		mailOrGame  		: 2;
    unsigned		autoOrChall 		: 2;			
    unsigned		dialOrWait  		: 2;
    unsigned		accountCreation		: 2;

    unsigned		tournament			: 1;
    unsigned		gameSendQErrors		: 1;
    unsigned		boxSendQErrors		: 1;
    unsigned		challengeArea		: 1;
    unsigned		vip					: 1;
} BlogLoginInfoFlags, BlogLoginInfoFlags_v2;
	
typedef struct {
	unsigned short			size;
	unsigned short			version;
	BlogLoginInfoFlags_v0	flags;
    unsigned				exitStatus		: 4;
    unsigned				billingType		: 4;
	long					hostAddr;
    time_t					startTime;
    short					duration;
    BlogPhoneNumber_v0		callingNumber;
    BlogBoxInfo	     		boxInfo;
    UserName            	nameStr;       /* BUG - do we need to store names ? */
} BlogLoginInfo_v3;

typedef struct {
	unsigned short			size;
	unsigned short			version;
	BlogLoginInfoFlags_v1	flags;
    unsigned				exitStatus		: 4;
    unsigned				billingType		: 4;
	long					hostAddr;
    time_t					startTime;
    short					duration;
    BlogPhoneNumber_v0		callingNumber;
    BlogBoxInfo     		boxInfo;
    UserName            	nameStr; 
} BlogLoginInfo_v5;

typedef struct {
    unsigned short			size;
    unsigned short			version;
    BlogLoginInfoFlags		flags;
    unsigned				exitStatus	: 4;
    unsigned        		billingType	: 4;
    long					hostAddr;
    time_t					startTime;
    short					duration;
    BlogPhoneNumber_v0		callingNumber;
    BlogBoxInfo				boxInfo;
    UserName				nameStr;
} BlogLoginInfo_v6;

typedef struct {
	unsigned short			size;
	unsigned short			version;
	BlogLoginInfoFlags		flags;
    unsigned				exitStatus	: 4;
    unsigned				billingType	: 4;
	long					hostAddr;
    time_t					startTime;
    short					duration;
    BlogPhoneNumber			callingNumber;
    BlogBoxInfo     		boxInfo;
    UserName            	nameStr;
    long					connid;
} BlogLoginInfo;

typedef struct {
	time_t					time;
} BlogLocalTime;

typedef struct {
	short					connects;		// per session
	long					seconds;		// cumulative
} BlogPeerTime;

typedef struct {
  char	master;
  long	when;
  long	magicCookie;
  long	gamePatchVer;
  long	gameID;
  BoxSerialNumber oppBoxSerialNumber;
} BlogMatchupRegurg;

// Valid bit flags are defined in Server_Tournament.h
typedef struct {
    int         flags;
} BlogTourneyResult;

typedef struct {
    long	identifier;
    long	version;
    time_t	createTime;
} BlogFileHeader;

typedef struct {
	long			currentOrigCardCredits;
	DebitCardDBInfo currentCard;
	DebitCardDBInfo prevCard;
} BlogSmartCardInfo;

/* generic constants */
#define kLogInvalidPhoneNumber	0
#define kLogConnStartMarker	0x1aaaaaaa
#define kLogConnEndMarker	0x2aaaaaaa

/* function prototypes */
Boolean Server_WriteNewBinaryLog(ServerState *, unsigned char);

#endif __Server_Log_h__


