/*
 * Catapult Entertainment, Inc.
 *
 * $Id: Server.h,v 1.72 1996/01/25 17:51:35 hufft Exp $
 *
 * $Log: Server.h,v $
 * Revision 1.72  1996/01/25  17:51:35  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.71  1996/01/04  22:25:18  hufft
 * added missing
 *
 * Revision 1.70  1996/01/04  22:21:30  hufft
 * added changes for pop mail
 *
 * Revision 1.69  1996/01/04  14:57:20  felix
 * Changed prototype for Database_GetDebitCardInfo
 *
 * Revision 1.68  1995/12/06  00:25:07  steveb
 * #ifdef'ed out the prototype for gettext() for non SVR4 systems.  Solaris
 * already provides for this in a standard header.
 *
 * Revision 1.67  1995/12/04  16:30:56  chs
 * Added proto for Server_SendMailFromXBAND().
 *
 * Revision 1.66  1995/11/08  18:36:33  jhsia
 * Added proto for Server_SetRandomThings(). (fadden)
 *
 * Revision 1.65  1995/11/06  02:38:16  felix
 * Added function prototypes for functions in Server_SmartCards.c
 *
 * Revision 1.64  1995/10/27  19:43:29  steveb
 * Just did some long needed housecleaning.  No new code.
 *
 * Revision 1.63  1995/10/16  14:29:32  sriram
 * Cleaned up old tourney stuff. Modifications for new tourney format.
 *
 * Revision 1.62  1995/10/03  17:11:49  ted
 * Added XBN protos.
 *
 * Revision 1.61  1995/10/02  15:04:41  sriram
 * Better error returns for Server_UpdateBoxDocument().
 *
 * Revision 1.60  1995/09/28  15:57:17  ansell
 * Moved kMaxPointsMagic, kMaxMatchMagic constants from Server_Justice.c into
 * Server.h
 *
 * Revision 1.59  1995/09/27  18:37:19  hufft
 * added Common_Phone support
 *
 * Revision 1.58  1995/09/27  15:48:14  chs
 * Added prototype for xband-store stuff.
 *
 * Revision 1.57  1995/09/25  00:55:43  fadden
 * Updated prototypes for some of the "justice" routines.
 *
 * Revision 1.56  1995/09/20  10:51:52  chs
 * Added separate error code for terminating a connection early
 * for a T+C failure.
 *
 * Revision 1.55  1995/09/19  23:54:32  fadden
 * Added kMailXbandCompleteEnough and prototypes for CompleteEnough stuff.
 *
 * Revision 1.54  1995/09/19  17:27:39  ted
 * Changes to XBNBoxUsage structure and defined flags for it.
 *
 * Revision 1.53  1995/09/17  21:50:59  fadden
 * Added proto for Server_CheckInvalidChallenge.
 *
 * Revision 1.52  1995/09/13  14:24:17  ted
 * Fixed warnings.
 *
 * Revision 1.51  1995/09/11  15:36:19  chs
 * Added prototype for Server_DBIsValid().
 *
 * Revision 1.50  1995/09/05  17:22:38  ansell
 * Changed prototypes of SendRegisterPlayer and SendRegisterChallengePlayer to
 * include an argument for the player being XBN callable.
 *
 * Revision 1.49  1995/08/31  17:56:28  fadden
 * Changed kGameOpponentForfeit from 0x80000000L to 0x40000000L.
 *
 * Revision 1.48  1995/08/25  17:38:51  fadden
 * Added WinAnalysis stuff.
 *
 * Revision 1.47  1995/08/16  18:07:07  fadden
 * Added XBN flag to matchupRegurg.
 *
 * Revision 1.46  1995/08/07  21:39:14  fadden
 * Added prototypes for cord pull stuff.
 *
 * Revision 1.45  1995/08/07  14:47:16  fadden
 * Added a bunch of prototypes for the new Server_Justice.c.
 *
 * Revision 1.44  1995/08/02  17:14:18  fadden
 * Added kSnesGameIDQElement for tracking down weird SNES gameID problems.
 *
 * Revision 1.43  1995/07/28  16:34:04  ansell
 * Added constant for phone-cord pull sendQ item.
 *
 * Revision 1.42  1995/07/25  22:59:31  ted
 * Added account param to Server_RestoreModemStuff.
 *
 * Revision 1.41  1995/07/19  18:00:30  ted
 * Define kLocalAccessPhoneResultQElement, kOpponentPhoneResultQElement,
 * and kModemSelfTestDataQElement.
 *
 * Revision 1.40  1995/07/17  11:48:15  ted
 * Defined kPeerTimeQElement.
 *
 * Revision 1.39  1995/07/10  20:51:18  rich
 * Added gettext() prototype.
 *
 * Revision 1.38  1995/07/10  10:32:29  ted
 * Added Server_SetBoxAccountPops and Server_ResetXBNFreebieCount.
 *
 * Revision 1.37  1995/07/07  20:39:06  fadden
 * Rearranged some prototypes, notably in the RRD stuff.
 *
 * Revision 1.36  1995/06/19  20:23:19  fadden
 * Added many prototypes, removed default taunt/info, added SNES reset const.
 *
 * Revision 1.35  1995/06/08  11:13:11  ted
 * Added Server_GetBoxTimeZone.
 *
 * Revision 1.34  1995/06/07  13:58:04  fadden
 * Added Server_SendXYString.
 *
 * Revision 1.33  1995/06/01  22:32:02  fadden
 * Use MatchupRegurg.reserved2 for gameID.
 *
 * Revision 1.32  1995/06/01  16:32:43  fadden
 * Use MatchupRegurg.reserved1 to hold gamePatchVer.
 *
 * Revision 1.31  1995/06/01  15:03:05  fadden
 * Merge in from newbr.
 * -> Added enums and prototypes for new restore stuff.
 *
 * Revision 1.30  1995/05/25  22:37:09  davej
 * Added prototype for Server_IsFreeMonth (for new billing plan support).
 *
 * Revision 1.29  1995/05/11  05:42:26  fadden
 * Added new prototypes (most notably, broke RecvComplete into pieces).
 *
 */

/*
	File:		Server.h

	Contains:	xxx put contents here xxx

	Written by:	Dave Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<91>	12/15/94	DJ		Added kAllYouCanEatCredits (BETA HACK).
		<90>	12/15/94	BET		Added Server_SendXmailToInet() proto.
		<89>	 12/6/94	ATM		Added kConnTypeHosedSpecificMatch.
		<88>	 12/2/94	HEC		Added Server_PenalizeCreditCreditOther.
		<87>	11/30/94	SR		Partial DB update on early connect termination
		<86>	11/30/94	DJ		Added replaceModem param to Server_DoRestore.
		<85>	11/23/94	ATM		Changed proto for UpdateAddrBookAfterGame.
		<84>	11/22/94	HEC		Added Server_WhichTown (validate login).
		<83>	11/15/94	HEC		Made mail routine public.
		<82>	11/14/94	ATM		Added proto for Server_DequeuePlayer.
		<81>	11/14/94	ATM		Split errorWhere into errorWhere and connectPhase.
		<80>	11/11/94	ATM		Added kConnTypeHosedAutoMatch.
		<79>	 11/9/94	DJ		Added kCreditsChargedForPasswordErase.
		<78>	 11/9/94	ATM		Changed protos for stuff related to worth strings.
		<77>	 11/8/94	ATM		Added protos for Server_TimeToSegaDate and
									Server_UpdateAddrBookAfterGame.
		<76>	 11/7/94	DJ		Added Server_SendPasswordEraseCode etc.
		<75>	 11/7/94	DJ		Adding #defines
		<74>	 11/7/94	SR		added dbitems to news pages
		<73>	 11/6/94	ATM		Removed prototype for UpdateRanking.
		<72>	 11/2/94	ATM		Enum for connect types.  New prototypes for recredit stuff.
		<71>	10/28/94	ATM		SpecialPhone stuff.  Included header file.
		<70>	10/25/94	DJ		Added Server_SendAddressBook.
		<69>	10/25/94	DJ		Added Server_CreateConnectInfo.
		<68>	10/24/94	DJ		Server_DoRestore returns an int now.
		<67>	10/24/94	ATM		#ifdefed out old neterr prototypes.
		<66>	10/20/94	DJ		Added Server_StartConnection.
		<65>	10/19/94	DJ		Added Server_GeneralBoxUpdate and
									Server_ValidateInitialSystemPatch.
		<64>	10/17/94	ATM		Added prototype for UpdateRanking.
		<63>	10/14/94	ATM		Reversed gameError and errorWhere.
		<62>	10/13/94	DJ		Added Server_DoRestore.
		<61>	10/13/94	DJ		Added enums for BoxRestartInfo parsing (this is duplicated from
									OSCore/Exceptions.h)
		<60>	10/12/94	ATM		Did something, don't remember what.
		<59>	10/12/94	ATM		Put NewGameResults back in.
		<58>	10/12/94	ATM		Moved BoxRestartInfo in.
		<57>	10/12/94	DJ		added some new error values and some send routines for
									boxmindrestoration.
		<56>	10/12/94	DJ		added kServerForceRedial and a few other error types for
									Server_RestoreBox.  Also added send routines to getHiddenBoxIDs
		<55>	10/10/94	ATM		Added prototypes for Server_UpdateGameResults and
									Server_RecvComplete.
		<54>	 10/2/94	ATM		Change proto for SendWorthString.
		<53>	 9/29/94	DJ		added kUnlimitedXBandCredits
		<52>	 9/20/94	DJ		HAPPY_REGION = 12
		<51>	 9/18/94	ATM		Server_Log.h --> Common_Log.h.  Incremented HAPPY_REGION.
		<50>	 9/17/94	ATM		Added INLINE for those about to rock.
		<49>	 9/16/94	DJ		xband free credits now == 32 not 35
		<48>	 9/16/94	ATM		HAPPY_REGION reaches double digits, film at 11.
		<47>	 9/11/94	ATM		Moved logging stuff into its own header, so you don't have to
									include all of Server.h if you just want logs.
		<46>	  9/7/94	ATM		Added LOG_RPC.
		<45>	  9/7/94	ATM		Incremented HAPPY_REGION.
		<44>	  9/6/94	ATM		Added LOG_MATCHING.
		<43>	  9/4/94	ATM		HAPPY_REGION gets even happier.
		<42>	  9/3/94	ATM		Changed LOG_DEBUG to LOG_DBUG.
		<41>	  9/1/94	ATM		Changed all the logging stuff.
		<40>	 8/28/94	ATM		Proto for Server_SEG9_ReceiveMail.
		<39>	 8/26/94	DJ		added Server_RestoreBox
		<38>	 8/25/94	BET		Change HAPPY_REGION to 5.
		<37>	 8/25/94	BET		Update for multiple NetErrorRecord types.
		<36>	 8/25/94	ATM		Increased HAPPY_REGION to 4.
		<35>	 8/25/94	DJ		add Server_SendClearMiscQueues
		<34>	 8/25/94	ATM		Add prototype for StatusPrintGameResults.
		<33>	 8/21/94	DJ		added Server_RestoreBox.c
		<32>	 8/21/94	DJ		setlocalaccessphonenumber takes 2 phone nums (2nd is fallback
									number)
		<31>	 8/20/94	BET		Added Server_SendOpponentNameString.
		<30>	 8/20/94	DJ		receiveaddressbookverifications2
		<29>	 8/19/94	DJ		added Server_SendWorthString
		<28>	 8/19/94	ATM		HAPPY_REGION is now 3.  Is there a better way to do this?
		<27>	 8/18/94	ATM		Incremented HAPPY_REGION.
		<26>	 8/17/94	ATM		Added Crashmsg per request.
		<25>	 8/17/94	ATM		Moved HAPPY_VERSION in here.
		<24>	 8/17/94	DJ		receiveloginversion2
		<23>	 8/17/94	ATM		Added Loghexdump.
		<22>	 8/16/94	DJ		senddebitsmartcard
		<21>	 8/16/94	DJ		senddateandtime
		<20>	 8/13/94	DJ		forceendcomm
		<19>	 8/13/94	DJ		Sever_ValidateLogin returns int instead of err
		<18>	 8/13/94	BET		Add Server_ReceiveNetErrors.
		<17>	 8/12/94	ATM		Added Server_GameName.
		<16>	 8/11/94	ATM		Added message logging stuff.
		<15>	 8/10/94	ATM		Moved area code munging out, added phoneNumber prettifier.
		<13>	  8/9/94	ATM		Phone number tweak routines for area codes.
		<12>	  8/8/94	DJ		SendDialog takes boolean whether to stick or disappear in 3 sec.
		<11>	  8/5/94	DJ		playeraccout stuff
		<10>	  8/5/94	ATM		Added #include "AddressBook.h"
		 <9>	  8/5/94	DJ		new address book poop: Server_SendCorrelateAddressBookEntry
		 <8>	  8/4/94	DJ		added Server_ReceiveGameErrorResults
		 <7>	  8/3/94	ATM		Fuck.
		 <6>	  8/3/94	ATM		Added memory watch debug stuff.
		 <5>	  8/3/94	DJ		handy dandy utility: Server_SendUserIdentification
		 <4>	  8/2/94	DJ		removed sendbitmap and sendtext
		 <3>	 7/29/94	DJ		added Server_SendCreditToken
		 <2>	 7/25/94	DJ		5 days of hacking, including: added Server_SendDBConstants
		 <1>	 7/20/94	DJ		first checked in
		<29>	 7/20/94	BET		Blew away all the "Brain Damaged Shit" that was in the last
									checkin.
		<28>	 7/20/94	DJ		added Server_Comm stuff
		<27>	 7/19/94	DJ		gamename is now just a char*
		<26>	 7/19/94	DJ		server tests routine
		<25>	 7/18/94	DJ		added #defines for msg order
		<24>	 7/16/94	BET		unix-ise include file capitalization.
		<23>	 7/15/94	DJ		added largedialog
		<22>	 7/14/94	DJ		new mail msgs
		<21>	 7/13/94	DJ		added Server_SendRegisterPlayer
		<20>	 7/12/94	DJ		updated Server_SendNewBoxSerialNumber to send new boxser format
		<19>	  7/8/94	DJ		msgs to set box phone numbers
		<18>	  7/6/94	DJ		address book validation
		<17>	  7/2/94	DJ		rankings
		<16>	 6/30/94	DJ		new news
		<15>	 6/11/94	DJ		added kServerFuncEnd retVal
		<14>	 6/10/94	DJ		Server_DebugService
		<13>	  6/9/94	BET		Fix hairy compiles based on TransportSlayer.h
		<12>	  6/5/94	DJ		removed extra proto for Server_SendBitmap
		<11>	  6/4/94	DJ		making everything take a ServerState instead of SessionRec
		<10>	  6/2/94	BET		news
		 <9>	  6/1/94	DJ		api tweaks
		 <8>	 5/31/94	DJ		Mail
		 <7>	 5/29/94	DJ		KoolStuff
		 <6>	 5/27/94	DJ		Server driving: accounts, opponents, patches, system validation,
									etc.
		 <5>	 5/26/94	BET		Update for new world order
		 <4>	 5/26/94	DJ		added LoopBack for network debugging
		 <3>	 5/25/94	DJ		fixed include prob
		 <2>	 5/25/94	DJ		added text sending
		 <2>	 5/25/94	DJ		fucked with project farts
	To Do:
*/

#ifndef __Server_h__
#define __Server_h__


#include "Errors.h"

#if !defined(__SERVER__) && defined(__MWERKS__)
#define __SERVER__
#endif

#define DEBUG		1
#define MESSAGES	1
#define DEBUGSERVICE	1		// turns on network debugging (loopbacks, etc.)

// This should be "inline" or blank.  Requires "gcc -O2" to do anything
// useful.  If they didn't specify it with -D, they probably don't want it.
//
#ifndef INLINE
# define INLINE
#endif


//#define HAPPY_REGION	12		// debugging hack, used to invalidate accounts

#define kFreeXBandCredits	32	// number of free credits given during Alpha & Beta test.
#define kUnlimitedXBandCredits	0xffffffffL

// The following constants specify how XBAND support can be 
// reached through email.
#define kMailXbandSupport	"support"
#define kMailXbandSupportDomain	"@catapent.com"

// The following constants specify hard-coded XBAND mail 
// addresses. 
#define kMailXbandFaxScan  	"XBAND FAX Scan"
#define kMailXbandResetScan	"XBAND Reset Scan"
#define kMailXbandCallScan 	"XBAND Call Scan"
#define kMailXbandCompleteEnough 	"XBAND Game Check"


#include "ServerState.h"		// for ServerState
#include "SegaGraphics.h"		// for segaBitMap
#include "News.h"				// for NewsPage
#include "PreformedMessage.h"
#include "DataBase.h"
#include "GameDB.h"				// for gameName
#include "AddressBook.h"		// for AddressBook
#include "Common_Log.h"			// all them logging goodies
#include "Server_SpecialPhone.h"	// specially gifted phone numbers

typedef int (*ServerFunc)(struct ConnSession *session);

enum {
	kServerFuncOK,
	kServerFuncSkipNext,
	kServerFuncAbort,		// fatal comm error
	kServerFuncEnd,			// can't finish transaction (example: unsupported game)
	kServerFuncForceEnd,	// same as kServerFuncEnd, but drops line. does not wait for box's endcomm msg
	kServerFuncEndTerms,		// ended connection early for failure to agree to Terms+Conditions


	//kRestoreForceRedial,
	//kRestoreLostYourAccount,
	//kServerRestoredAccount
};

// Nationwide time spent per month per box kept in box opaquestore
// Maximum of 44640 minutes per month fits into an unsigned short.
//
typedef struct XBNMonthUsage {
	unsigned short minutes;	// minutes used this month
	signed char month;		// month number 0-11 (like tm struct)
	signed char year;		// year-1900 (like tm struct)
} XBNMonthUsage;

typedef struct XBNBoxUsage {
	XBNMonthUsage current;
	XBNMonthUsage previous;
	unsigned long monthlycap;	// modifiable by cust. service (minutes). "0" resets to default.
	unsigned long flags;
	long reserved1;
	long reserved2;
} XBNBoxUsage;

// Flags for XBNBoxUsage.flags field:
#define kXU_NearingLimit		(1<<0)	// set after we send box nearing limit xmail/dialog
#define kXU_ExceededLimit		(1<<1)	// set after we send box limit xmail/dialog
#define kXU_OverrideLimit		(1<<2)	// set when customer service overrides monthlycap

//
// Load the database with initial accounts and game patches.
//
//void Server_SetupAccounts(void);
//void Server_SetupGamePatches(void);


//
// Debugging of the network (sends loopbacks, etc)
//
#ifdef DEBUGSERVICE

int Server_DebugService(ServerState *state);

#else

#define Server_DebugService(a)

#endif

//
// returns a long in sega date format for today.  used for mail and news to timestamp.
//
long Server_GetSegaDate(void);
long Server_TimeToSegaDate(long now);



//
// The first thing called in a connection.
//
int Server_StartConnection(ServerState *state);


//
// Handlers for receiving from box
//
int Server_ReceiveBoxType(ServerState *state);
int Server_sega_ReceiveLogin(ServerState *state);
int Server_snes_ReceiveLogin(ServerState *state);
int Server_ReceiveGameID(ServerState *state);
int Server_ReceiveSystemVersion(ServerState *state);
int Server_ReceiveCompetitiveChallenge(ServerState *state);
int Server_ReceiveNGP(ServerState *state);
int Server_snes_ReceiveInterestingDBConstants(ServerState *state);
int Server_sega_SendRequestData(ServerState *state);
int Server_snes_SendRequestData(ServerState *state);
int Server_sega_ReceiveRequestedData(ServerState *state);
int Server_snes_ReceiveRequestedData(ServerState *state);
int Server_GetDBConstant(ServerState *state, DBID id, long *datap);
int Server_ReceiveSendQ(ServerState *state);
int Server_ReceiveAddressBookValidationQueries(ServerState *state);
	int Server_ReceiveAddressBookValidationQueries2(ServerState *state);	// 8/19/94 version.
int Server_EndCommunication(ServerState *state);
int Server_ForceEndCommunication(ServerState *state);
int Server_ReceiveMail(ServerState *state);
int Server_SEG9_ReceiveMail(ServerState *state);	// temp compat value
int Server_ReceiveCreditDebitInfo(ServerState *state);
	// helper routine for Server_ReceiveCreditDebitInfo and Server_SendDebitSmartcart
	int Server_ReceiveCreditDebitInfoIntoStruct(ServerState *state, CreditDebitInfo *creditDebitInfo);

int Server_sega_ReceiveGameResults(ServerState *state);
//int Server_sn00_ReceiveGameResults(ServerState *state);	// nuke me eventually
int Server_snes_ReceiveGameResults(ServerState *state);
int Server_ReceiveGameErrorResults(ServerState *state);
int Server_ReceivePersonification(ServerState *state);
#ifdef NOT_USED
int Server_ReceiveNetErrorsOld(ServerState *state);
int Server_ReceiveNetErrorsCombined(ServerState *state);
#endif
int Server_snes_ReceiveNetErrors(ServerState *state);
int Server_sega_ReceiveNetErrors(ServerState *state);


//
// Drive the box
//
//int Server_Drive(ServerState *state);
int Server_UpdateDataBaseAccount(ServerState *state);	// called before EndCommunication to update Account and do things.
void Server_CreateConnectInfo(ServerState *state);		// called by Server_UpdateDataBaseAccount to store a conninfo in the db.
void Server_UpdateDataBaseAccountPartial(ServerState *state);	// called when the connection is terminated prematurely



// Prepend "9," to the pops if the boxAccount->debug[1] has the dial9 flag set.
//
void  Server_AddPBX_Dial9(ServerState *state, phoneNumber *newAccessPhoneNumber, phoneNumber *altAccessPhoneNumber);


// Send calls.
//
int Server_SendLoopback(ServerState *state, long numLoops, Boolean sticky);
int Server_SendWaitForOpponent(ServerState *state, long magicCookie, long randomVal);
int Server_SendOpponentPhoneNumber(ServerState *state, const phoneNumber *opponentPhoneNumber, long magicCookie, long randomVal);
int Server_SendLongOpponentPhoneNumber(ServerState *state, const char *opponentPhoneNumber, long magicCookie, long randomVal);
int Server_SendNewBoxSerialNumber(ServerState *state, BoxSerialNumber *boxSerialNumber);
int Server_SendUnsupportedGame(ServerState *state);
int Server_SendDialog(ServerState *state, char *str, Boolean sticky);
int Server_SendLargeDialog(ServerState *state, char *str, Boolean sticky);

int Server_SendQDefDialog(ServerState *state, short when, char *cString, DBID templat, short minTime, short maxTime);
struct RankingInfo *Server_FindRankingInfo(ServerState *state, struct Account *account, long gameID);
int Server_SendRanking(ServerState *state);
int Server_SendAllRankings(ServerState *state, struct Account *account);
int Server_SendAddItemToDB(ServerState *state, DBType theType, DBID theID, long length, void *data);
#ifdef NOT_USED
int Server_SendClearSendQ(ServerState *state);
#endif
int Server_SendClearMiscQueues(ServerState *state);  // used instead of ClearSendQ in ROM version 7 (seg7)
int Server_SendSetBoxPhoneNumber(ServerState *state, phoneNumber *newBoxPhoneNumber);
int Server_SendSetLocalAccessPhoneNumber(ServerState *state, phoneNumber *newAccessPhoneNumber,
phoneNumber *fallbackAccessPhoneNumber, Boolean redail);
int Server_SendRegisterPlayer(ServerState *state, long timeoutValue, char *gameName, long xbnable);
int Server_SendRegisterChallengePlayer(ServerState *state, long timeoutValue, char *gameName, char *challengeName, long xbnable);
int Server_sega_SendAccountInfo(ServerState *state);
int Server_snes_SendAccountInfo(ServerState *state);
int Server_sn02_SendAccountInfo(ServerState *state);	// backward compat
//int Server_SendRestrictions(ServerState *state);
//int Server_SendCreditInfo(ServerState *state);
int Server_SendNewBoxHometown(ServerState *state, Hometown town);
int Server_SendNewCurrentUserName(ServerState *state, UserName name);
int Server_SendDBConstants(ServerState *state, long numConsts, DBID *ids, long *constants);
int Server_SendProblemToken(ServerState *state);
int Server_SendValidationToken(ServerState *state);
int Server_SendCreditToken(ServerState *state, unsigned long smartCardToken);
int Server_SendDateAndTime(ServerState *state);
int Server_SendDebitSmartcard(ServerState *state, long numDebits);
Err Server_SendWorthString(ServerState *state, char *slaveString, char *masterString);
int Server_SendGameOverString(ServerState *state);
Err Server_SendWritableString(ServerState *state, char *string, DBID theID);
int Server_SendOpponentNameString(ServerState *state, char *opponentName);
int Server_SendRegurg(ServerState *state);
int Server_SendRankingEnable(ServerState *state);
int Server_SendRankingDisable(ServerState *state);
Err Server_SendXYString(ServerState *state, char *string, DBType type, DBID id);
long Server_SetBoxAccountPops(ServerState *state, phoneNumber *newPop1, phoneNumber *newPop2);
void Server_ResetXBNFreebieCount(ServerState *state);


int Server_SendTests(ServerState *state);
int Server_snes_SendTests(ServerState *state);

int Server_sega_RecvComplete(ServerState *state);
int Server_snes_RecvComplete(ServerState *state);
int Server_intl_RecvComplete(ServerState *state);



int Server_snes_ReceiveBoxLogs(ServerState *state);

int Server_SendAddressBook(ServerState *state, struct Account *account);
int Server_SendCorrelateAddressBookEntry(ServerState *state,
										userIdentification *userID,
										unsigned char ownerUserID,
										unsigned char serverUniqueID);

int Server_SendPlayerInfo(				ServerState *state,
										struct PlayerInfo *playerInfo,
										unsigned char ownerUserID);

int Server_SendDeleteAddressBookEntry(	ServerState *state,
										userIdentification *userID,
										unsigned char ownerUserID);


// sends a preformed message (eg. mail, patch, Zeus-generated bitmap).
int Server_SendPreformedMessage(ServerState *state, PreformedMessage *mesg);

//
// Rental stuff
//
int Server_IsRentalValid(ServerState *state);


// news 
typedef struct ServerNewsPage {
	DBType		type;
	long		length;
	NewsPage	*page;
} ServerNewsPage;

typedef struct ServerDbItem {
	DBType          type;
	DBID            id;
	long            length;
	unsigned char   *data;
} ServerDbItem;

int Server_SendFirstNewsPage(ServerState *state, ServerNewsPage *page);
int Server_SendNoNewsPage(ServerState *state, DBType pagetype);
int Server_SendNewsPage(ServerState *state, ServerNewsPage *page);

// Debit card stuff
Err Server_DoDebitCardDBUpdate(ServerState *state);
Err Database_GetDebitCardInfo(ServerState *state, long serialNumber,
	DebitCardDBInfo *card);
Err Database_UpdateDebitCardInfo (DebitCardDBInfo *card);
int Server_SendDebitSmartcard(ServerState *state, long numDebits);
int Server_SendCreditToken(ServerState *state, unsigned long smartCardToken);
int Server_UpdateDebitCard(ServerState *state);

//
// Do the real server work.
//
int Server_SendSystemPatches(ServerState *state, long version);
int Server_ValidateSystem(ServerState *state);
int Server_ValidateLogin(ServerState *state);
void Server_GetBoxTimeZone(ServerState *state);
int Server_CheckAccountCredits(ServerState *state);
int Server_UpdateNGPVersion(ServerState *state);
int Server_UpdateGamePatch(ServerState *state);
int Server_ProcessSendQ(ServerState *state);
int Server_StartGamePlay(ServerState *state);
int Server_SendMail(ServerState *state);
int Server_SendMailBody(ServerState *state, Mail *mail);
int Server_ProcessAddrBookValidations(ServerState *state);
int Server_ProcessIncomingMail(ServerState *state);
void Server_HandleSalesMail(ServerState *state, Mail *mail);
int Server_ProcessPersonifications(ServerState *state);
Err Server_UpdateAddrBookAfterGame(struct Account *account,
	BoxSerialNumber *box, unsigned char player, int wins, int losses, long when);
Err Server_ClearBoxMode(ServerState *state);
Err Server_SetTourneyBoxMode(ServerState *state);
Boolean Server_CheckInvalidChallenge(ServerState *state);

// This news stuff probably needs to go into its own header file
int Server_sega_DownloadKoolStuff(ServerState *state);
int Server_snes_DownloadKoolStuff(ServerState *state);
int Server_intl_DownloadKoolStuff(ServerState *state);
int Server_GeneralBoxUpdate(ServerState *state);
int Server_ValidateInitialSystemPatch(ServerState *state);
void Server_DeleteDBItem(ServerState *state, DBType type, DBID id);
int Server_UpdateBoxDocument(ServerState *state, int channel,
	void *newsServer, int documentID, int *numBytes);

// Return codes for Server_UpdateBoxDocument()
#define kSvrNewsRealSent		(1L<<0)
#define	kSvrNewsBoxUptoDate 		(1L<<1)
#define	kSvrNewsServerGetFailed 	(1L<<2)
#define	kSvrNewsBoxSendFailed 		(1L<<3)
#define	kSvrNewsGenericSent 		(1L<<4)
#define	kSvrNewsUnknownPlatform 	(1L<<5)



int Server_IsPlayerOnQueue(ServerState *state);
Err Server_DequeuePlayer(ServerState *state, const long gameID);
Err Server_RefundCredit(ServerState *state);
Err Server_RefundCreditOther(ServerState *state, BoxSerialNumber *box);
Err Server_DeductCredit(ServerState *state);
Err Server_DeductCreditOther(ServerState *state, BoxSerialNumber *box);

// This is used for the userAccount.typeLastConnect field.
//
enum {
	kConnTypeNever = 0,				// never connected before
	kConnTypeAutoMatch,
	kConnTypeSpecificMatch,
	kConnTypeHosedAutoMatch,		// tried to compete with unknown gameID
	kConnTypeHosedSpecificMatch,	// ditto
	kConnTypeMailOnly,
};

//
// In case the box loses its poor little mind.  Called by Server_GetAccount().
//
Boolean Server_DBIsValid(ServerState *state);
Boolean Server_IsRestoreNecessary(ServerState *state);
Err Server_MarkBoxDBValid(ServerState *state);
Err Server_RestoreAccount(ServerState *state, BoxSerialNumber *boxp);
Boolean Server_BoxSentValidHWID(ServerState *state);
Err Server_SyncWithBox(ServerState *state);
void Server_SendBoxWipeMind(ServerState *state);
Err Server_RestoreModemStuff(ServerState *state, struct Account *account);

Err Server_SetRandomThings(ServerState *state, struct Account *account);

int Server_sega_UpdateMiscPrefs(ServerState *state);
int Server_snes_UpdateMiscPrefs(ServerState *state);
Err Server_RestoreMiscPrefs(ServerState *state, struct Account *account);

Boolean Server_BoxIsSimulator(ServerState *state);
Err Server_GetDefaultTauntAndInfo(ServerState *state, char **tauntp, char **infop);


Err Server_GetHiddenSerials(ServerState *state, BoxSerialNumber *s1, BoxSerialNumber *s2);
Err Server_SendSetCurrentUserNumber(ServerState *state, unsigned char userNum);

int Server_BoxWasMaster(const ServerState *state);
//Err Server_UpdateRanking(ServerState *state, const GameResult *oldGameResult,
//	const GameResult *oldGameErrorResult);


//
// High-level compression goodies.
//
int Server_SendOptCompressedString(ServerState *state, char *string);
int Server_ReceiveOptCompressedString(ServerState *state, short *sizePtr, char **bufPtr);

//
// Server_Nationwide stuff
//
Boolean Server_XBN_IsCallable(ServerState *state);
Err Server_XBN_ReadMCIFile(ServerState *state);
void Server_XNU_GeneralUpdate(ServerState *state);
Boolean Server_XNU_IsBelowCap(ServerState *state);
void Server_XNU_AddMinutes(ServerState *state, long minutes);

//
// Handy dandy utility
//

int Server_SendUserIdentification(ServerState *state, userIdentification *userID);
void Server_WhichTown(ServerState *state, Hometown town);
int Server_IsFreeMonth(struct Account *account);

//
// For passwordEraseCode.
//
int Server_GenerateAndSendPasswordEraseCode(ServerState *state);
int Server_SendPasswordEraseCode(ServerState *state, struct Account *account);
void Server_GenerateRandomPassword(ServerState *state, Password passwd);
int Server_DisableBoxWithPassword(ServerState *state, char *reason);
int Server_ClearBoxPassword(ServerState *state);


#if	0
//
// Phone number thang
//
Err Server_MakePhoneNumberPretty(phoneNumber *newAccessPhoneNumber);
#endif
//
// Mail routines
//
int Server_SendXmailToInet(Mail *, ServerState *, char *, Boolean);
Err Server_SendMailFromXBAND(ServerState *, char *, char *, char *, int);
Err	Server_SendMailRaw(ServerState *state, char *from, char *title, char *body, int mail_SN, int *sent);


void StatusPrintGameResults(ServerState *state);

//
// Updated game result struct
//
typedef struct NewGameResult
{
	long			size;			// the size of the game results structure
	long			gameID;
	char			connectPhase;
	char			errorWhere;
	short			gameError;
	unsigned long	localPlayer1Result;
	unsigned long	localPlayer2Result;
	unsigned long	remotePlayer1Result;
	unsigned long	remotePlayer2Result;
	long			playTime;
	long			dbIDDataPtr;
	long			dbIDDataSize;
	short			localGameError;
	short			errorRecovers;
	unsigned char	checksumErrors;
	unsigned char	timeouts;
	unsigned char	frameErrors;
	unsigned char	overrunErrors;
	long			gameReserved[ 8 ];
	short			numLocalPlayers;
	char			pad[2];
} NewGameResult;

// Game results and related routines.
//
int Server_UpdateGameResults(ServerState *state);
int Server_GetCurrentDailyPtr(ServerState *state, struct RankingInfo *myRankInfo);
long Server_GetMatchCookie(const ServerState *state);


// Game result "justice" routines.
//
Err Server_CheckForReset(ServerState *state, const NewGameResult *gameResult, const NewGameResult *gameErrorResult);
void Server_SendResetFuckerMail(ServerState *state, struct Account *updateAccount, Err ceResult);
void Server_SendCWFuckerMail(ServerState *state, struct Account *updateAccount, Err ceResult);
Err Server_SendFuckerResults(ServerState *state, struct Account *updateAccount, Err ceResult);
Err Server_CheckCallWaiting(ServerState *state, NewGameResult *gameErrorResult);
void Server_CheckForFAX(ServerState *state, GameResult *gameResult, GameResult *gameErrorResult);
void Server_UpdateCordPullData(ServerState *state);
Err Server_CheckForCordPull(ServerState *state, const NewGameResult *gameResult, const NewGameResult *gameErrorResult);
void Server_SendCordPullFuckerMail(ServerState *state, struct Account *updateAccount, Err ceResult);
NewGameResult *Server_ForgeSuccessfulGame(ServerState *state, NewGameResult *gameErrorResult, int winExpected);
void Server_NotifyCompleted(ServerState *state, struct Account *updateAccount);



// This defines which bits in a game result score field don't actually have
// anything to do with the score.
//
#define kGameOpponentForfeit	(0x40000000L)
#define kGameNonScoreMask		(~(kGameOpponentForfeit))

// Max number of points or matches that actually makes sense.  If we see
// values beyond this, we assume they must be bogus.
//
#define kMaxPointsMagic		400
#define kMaxMatchMagic		20

// Analysis of win/loss.  Takes into account things like forfeits.  If
// win != winByPoints, the KONratings aren't updated.
//
typedef struct WinAnalysis {
	unsigned long pointsFor;
	unsigned long pointsAgainst;
	int		winByPoints;		// 1=won, -1=loss, 0=tie by points only
	int		win;				// 1=won, -1=loss, 0=tie with all considered
	int		forfeit;			// 1=I forfeit, -1=he forfeit, 0=nobody forfeit
} WinAnalysis;

int Server_AnalyzeWin(const NewGameResult *gameResult, WinAnalysis *winAnal);

//
// Matchup regurgitation stuff.  Only meaningful to the server.
//
// A version number is included so that we can update this struct and
// deftly ignore older data that we no longer comprehend.
//
// "master" ought to be in "flags", but it's used all over the place now.
// Whatever.
//
typedef struct MatchupRegurg {
	unsigned char	version;		// version of this very struct
	unsigned char	master;			// boolean
	unsigned char	flags;			// bit flags
	unsigned char	pad;			// (use as needed)
	long			when;			// time_t; when enqueued or told to dial
	long			magicCookie;	// cookie sent to both master and slave
	long			randomVal;		// random value; might be useful to someone
	long			gamePatchVer;	// game patch version number
	long			gameID;			// gameID (need it here if no GameResults)
} MatchupRegurg;
#define kMatchupRegurgVersion	1
// bits for "flags" field
#define kRegurgFlagUsedXBN		(1)
#define kRegurgFlagUsedTourney		(1<<1)


// Restart info
//

// these structs assume that if you pile up shorts,
// Sparc C will push them together.  All of the longs in the ck and the below
// code start on long boundaries.

#define kHistorySize	8

//typedef struct BoxSerialNumber
//{
//	long	region;				// the region id for the box
//	long	box;				// the identifier for this box within the region
//} BoxSerialNumber;


//
// Originals for the following struct and enums are in SegaOS/OSCore/Exceptions.h
//
typedef struct BoxRestartInfo {					// there's room for 48 longs, change globals.h if longer!
	unsigned long	reg[16];		// these values are filled up by an exception handler
	
	unsigned short	excMode;		// the first 3 fields are only on Addr/Bus errors
	unsigned short	excAddr[2];
	unsigned short	excInstrReg;
	unsigned short	excSR;			// SR and PC are saved for all exceptions
	unsigned short	excPC[2];
	unsigned short	excCode;		// set at crash time
	
			 long	unstablePC;		// last PC who set OSUnstable
	unsigned long	startupFlags;	// set by the startup code
	
	short	histCallNums[kHistorySize];
	long	histCallers[kHistorySize];
	short	prevEntry;

	short	osState;				// set by various routines

	BoxSerialNumber	setBoxID;		// the one set by _SetBoxSerialNumber
	BoxSerialNumber	coldBoxID;		// boxID at cold boot time
	BoxSerialNumber	warmBoxID;		// boxID at end of StartupSega
	
	unsigned long	stackLowWater;	// deepest stack depth

	unsigned long	boxState;
	unsigned long	lastBoxState;
	
} BoxRestartInfo;

enum	{
	kMachineDead		=   0x001,		// bit fields for "restartFlags"
	kDataDead			=   0x002,
	kGameHeapDead		=   0x004,
	kResetting			=   0x008,
	kResetWhileUnstable =   0x010,
	kGameRestart		=   0x020,
	kOSUnstable			=   0x040,
	kDataBaseUnstable	=   0x080,
	kMadeOSUnstable		=   0x100,
	kBadBoxID			=   0x200,
	kBadEarlyRamTest	=   0x400,
	kBadLowVectors		=   0x800,
	kOSUnstableAtHpCk	=  0x1000,
	kOSUnreliableAtHpCk	=  0x2000,
	kOSHeapNonVerify	=  0x4000,
	kDBDBNonVerify		=  0x8000,
	kDBHeapCollide		= 0x10000,
	kDBHeapUnstable		= 0x20000,
	kDBHeapNonVerify	= 0x40000

};


QItem *Server_FindSendQItem(const ServerState *state, long ident);
int Server_DumpStreamErrorReport(ServerState *state);

// Results of pop dialing and rotation
//
#define kLocalAccessPhoneResultQElement		4

// Results of peer dialing and rotation
//
#define kOpponentPhoneResultQElement		5

// Modem version uploaded only on 800# connects
// sega: 4 bytes, snes: 10 bytes
//
#define kModemSelfTestDataQElement			6

// SendQ value for Reset Reports (SNES sound chip stuff)
//
#define kSNESResetQElement	7

// SendQ value for Peer Connect Cumulative Time
//
#define kPeerTimeQElement	19

// SendQ value for Stream Error Reports
//
#define kStreamErrorReportQElement	21

// SendQ value that tells us the player used the passwd erase code.
//
#define kPasswordEraseQElement	22

// We charge 4 credits for using the password erase code.
#define kCreditsChargedForPasswordErase 4

// SendQ value Josh uses for sending up line pull information
//
#define kCordPullQElement	23

// SendQ value for SNES gameID checks
//
#define kSnesGameIDQElement		24

// SendQ value used for gameResult regurgitation stuff
//
#define kMatchupRegurgQElement	239

// SendQ value KON uses for Box History stuff
//
#define kMagicQElement	240

//
// Until Jan 95 we will let people who have a spending cap of 20 (ie can
// spend 52 credits per month) play above 52 credits for free.
//
#define kAllYouCanEatCredits (52L - 32L)

#ifndef __svr4__
// For internationalized messaging.
//
char *
gettext(char *);
#endif /* __svr4__ */

#endif __Server_h__
