/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: ServerState.c,v 1.9 1996/01/31 18:02:23 hufft Exp $
 *
 * $Log: ServerState.c,v $
 * Revision 1.9  1996/01/31  18:02:23  hufft
 * UDP socket changes
 *
 * Revision 1.8  1996/01/25  17:51:39  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.7  1996/01/04  14:59:34  felix
 * Added initialization of state->commitSmartCardChanges
 *
 * Revision 1.6  1995/09/13  14:24:19  ted
 * Fixed warnings.
 *
 * Revision 1.5  1995/07/26  13:51:06  ansell
 * Added check for null sendQ data item in case sendQ was hosed during send-up.
 *
 * Revision 1.4  1995/07/17  18:36:08  fadden
 * LRA: changed messages in ServerState_Empty, ServerState_Print, and
 * ServerState_PrintUserIdentification to be LOGP_DETAIL.
 *
 * Revision 1.3  1995/05/26  23:45:56  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		ServerState.c

	Contains:	ServerState

	Written by:	Dave Jevans


	Change History (most recent first):

		<34>	 11/9/94	DJ		Renamed some DB routines to DataBaseUtil_ and also to WrapperDB_
									(for Oracle).
		<33>	 11/7/94	SR		added dbitems to news pages
		<32>	 9/26/94	ATM		Added abandonShip.
		<31>	 9/19/94	ATM		PLogmsg stuff.
		<30>	  9/7/94	ATM		Moved the Statusmsg off to StartGamePlay.
		<29>	 8/30/94	ATM		Converted accountChangedMask references to Account flags.
									Changed userID printing.
		<28>	 8/26/94	ATM		Added a Logmsg to avoid confusion.
		<27>	 8/25/94	ATM		(doh!)
		<26>	 8/25/94	ATM		Changed some log messages.
		<25>	 8/23/94	DJ		state->disallowGameConnect
		<24>	 8/21/94	DJ		added state->personificationFlagsEditedByServer
		<23>	 8/19/94	BET		serverState->gameResult is a pointer now, fix up
									ServerState_Print to do the right thing.
		<22>	 8/19/94	ATM		Fixed game result printing.
		<21>	 8/17/94	ATM		Added logging of game results.
		<20>	 8/13/94	ATM		Bug.
		<19>	 8/13/94	ATM		Added Statusmsg call for mail-only connects.
		<18>	 8/11/94	DJ		latest personifuckation
		<17>	 8/10/94	DJ		personifuckation
		<16>	  8/5/94	DJ		playeraccount stuff
		<15>	  8/4/94	DJ		no more SNDQElement
		<14>	 7/20/94	DJ		removed configstr from serverstate
		<13>	 7/18/94	DJ		added opponentMagicCookie
		<12>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		<11>	 7/14/94	DJ		new mail
		<10>	 7/12/94	DJ		supports mail-only connections
		 <9>	  7/6/94	DJ		address book validation
		 <8>	 6/30/94	DJ		new sendQ format
		 <7>	 6/29/94	BET		(Really DJ) Clean up after KON.
		 <6>	 6/15/94	DJ		boxSerialNumber tweaks
		 <5>	 6/10/94	DJ		supporting configString better
		 <4>	  6/9/94	BET		Fix hairy compiles based on TransportSlayer.h
		 <3>	  6/4/94	DJ		setting the sessionrec in ServerState_Init
		 <2>	 5/27/94	DJ		updated to userIdentity struct
	To Do:
*/

#include <memory.h>
#include "ServerCore.h"
#include "Server.h"
#include "ServerState.h"
#include "Messages.h"
#include "UsrConfg.h"
#include <stdio.h>
#include <stdlib.h>
#include "Utils.h"
#include "ServerDataBase.h"
#include "Server_Personification.h"
#include "Common_Missing.h"


void ServerState_Init(ServerState *state, SessionType type, ConnSession *session, char *config)
{
#ifdef OUCH
register long a;
register char *p;

	// clear every field of ServerState
	//
	for(p = (char *)state, a = 0; a < sizeof(ServerState); a++)
		*p++ = 0;
#endif
	memset(state, 0, sizeof(ServerState));


	state->validFlags = kServerValidFlag_None;
	
	state->session = session;
	if(session)
	{
		memset(session, 0, sizeof(*session));
		session->type = type;
		if (type == SESSION_STREAM)
		{
			session->rec.stream.infd = 0;
			session->rec.stream.outfd = 1;
			session->rec.stream.sockaddr_len = sizeof(session->rec.stream.sockaddr_in);
			session->rec.stream.in_timeout = 60000;
			session->rec.stream.out_timeout = 2000;
		}
		state->validFlags |= kServerValidFlag_SessionRec;
	}
	
	if(config)
	{
		state->validFlags |= kServerValidFlag_ConfigString;
		ByteCopy((Ptr)state->configBuffer, (Ptr)config, kConfigStrLength);
	} else
		state->configBuffer[0] = 0;
	
	// hmm, these shouldn't be necessary after the memset() above.  (94/09/26)
	//
	state->account = NULL;
	
	state->personificationFlags = 0;
	state->personificationFlagsEditedByServer = 0;
	
	state->disallowGameConnect = false;

	state->animations = NewSortedList();

	state->commitSmartCardChanges = false;
}

void ServerState_Empty(ServerState *state)
{
	PLogmsg(LOGP_PROGRESS, "ServerState_Empty\n");

	if(state->validFlags & kServerValidFlag_Account)
	{
		ASSERT(state->account);
		
		state->validFlags &= ~(kServerValidFlag_Account);
		DataBaseUtil_FreeAccount(state->account);
		state->account = NULL;
	}
	
	PLogmsg(LOGP_DETAIL, "Freeing SendQ items\n");
	if(	state->validFlags & kServerValidFlag_SendQ)
	{
		long i;
		
		for(i = 0; i < state->sendQData.count; i++){
			PLogmsg(LOGP_DETAIL, "\tItem %ld:\n", i);
			PLogmsg(LOGP_DETAIL, "\t\tDBID = %ld, Size = %ld\n",
				(long)state->sendQData.items[i].theID,
				state->sendQData.items[i].size);
			// Check for partial sendQ
			if (!state->sendQData.items[i].data)
				break;
			free(state->sendQData.items[i].data);
		}
		free(state->sendQData.items);
		state->sendQData.items = NULL;
	}
	
	if(state->validFlags & kServerValidFlag_AddrValidation)
	{
		// BRAIN DAMAGE????
	}
	
	if(state->validFlags & kServerValidFlag_IncomingMail)
	{
		short i;
		
		for(i = 0; i < state->incomingMail.count; i++)
			if(state->incomingMail.mailItems[i].mail)
				free(state->incomingMail.mailItems[i].mail);
		
		if(state->incomingMail.mailItems)
			free(state->incomingMail.mailItems);
		state->incomingMail.mailItems = NULL;
		state->incomingMail.count = 0;
	}
	
	if(state->validFlags & kServerValidFlag_GameResults)
	{
		free((Ptr)state->gameResult);
	}
		
	state->validFlags = kServerValidFlag_None;
}


void ServerState_Print(ServerState *state)
{
	if(state->validFlags & kServerValidFlag_Login)
	{
		PLogmsg(LOGP_DETAIL, "Login Data:\n");
		ServerState_PrintUserIdentification(&state->loginData.userID);
		PLogmsg(LOGP_DETAIL, "\tPhone number = %s\n",
			state->boxPhoneNumber.phoneNumber);
	} else
		PLogmsg(LOGP_DETAIL, "Login Data is invalid\n");
	
	if(state->validFlags & kServerValidFlag_ChallengeOrCompete)
	{
		if(state->challengeData.userID.box.box == -3) {
			PLogmsg(LOGP_DETAIL, "Mail only connection\n");
			//Statusmsg("SunSega: Mail-only connect from '%s' (%s)\n",
			//	state->loginData.userID.userName,
			//	state->boxPhoneNumber.phoneNumber);
			//StatusPrintGameResults(state);
		} else if(state->challengeData.userID.box.box == -2)
			PLogmsg(LOGP_DETAIL, "Normal competitive game request\n");
		else
		{
			PLogmsg(LOGP_DETAIL, "Challenge Request:\n");
			ServerState_PrintUserIdentification(&state->challengeData.userID);
		}
	} else
		PLogmsg(LOGP_DETAIL, "ChallengeOrCompete is invalid\n");
	
	if(state->validFlags & kServerValidFlag_SystemVersion)
	{
		PLogmsg(LOGP_DETAIL, "System Version:\n");
		PLogmsg(LOGP_DETAIL, "\tlength = %d, version = %ld\n",
			state->systemVersionData.length, state->systemVersionData.version);
	} else
		PLogmsg(LOGP_DETAIL, "System Version is invalid\n");

	if(state->validFlags & kServerValidFlag_NGPVersion)
	{
		PLogmsg(LOGP_DETAIL, "NGP Version = %ld\n", state->NGPVersion);
	} else
		PLogmsg(LOGP_DETAIL, "NGP Version is invalid\n");
	
	if(state->validFlags & kServerValidFlag_GameID)
	{
		PLogmsg(LOGP_DETAIL, "Game ID:\n");
		PLogmsg(LOGP_DETAIL, "\tgameID = 0x%.8lx, version = %ld\n",
			state->gameIDData.gameID, state->gameIDData.version);
	} else
		PLogmsg(LOGP_DETAIL, "Game ID is invalid\n");

	if(	state->validFlags & kServerValidFlag_SendQ)
	{
		long i;
		
		PLogmsg(LOGP_DETAIL, "SendQ Count = %d:\n", state->sendQData.count);
		for(i = 0; i < state->sendQData.count; i++){
			PLogmsg(LOGP_DETAIL, "\tItem %ld:\n", i);
			PLogmsg(LOGP_DETAIL, "\t\tType = %ld, Size = %ld\n",
				(long)state->sendQData.items[i].theID,
				state->sendQData.items[i].size);
		}
	} else 
		PLogmsg(LOGP_DETAIL, "SendQ is invalid\n");

	if(state->validFlags & kServerValidFlag_IncomingMail)
	{		
		PLogmsg(LOGP_DETAIL, "Incoming Mail count = %ld\n",
			(long)state->incomingMail.count);
	}
}


void ServerState_PrintUserIdentification(const userIdentification *userID)
{
	PLogmsg(LOGP_DETAIL, "  User identification:\n");
	PLogmsg(LOGP_DETAIL, "\tBox serial number = (%ld,%ld) [%ld]\n",
		userID->box.box, userID->box.region, (long)userID->userID);
	PLogmsg(LOGP_DETAIL, "\tUser name = '%s'\n", userID->userName);
	PLogmsg(LOGP_DETAIL, "    User town = '%s'\n", userID->userTown);
	PLogmsg(LOGP_DETAIL, "    iconID = %ld, colorTableID = %ld\n",
		(long) userID->ROMIconID, (long)userID->colorTableID);
}

