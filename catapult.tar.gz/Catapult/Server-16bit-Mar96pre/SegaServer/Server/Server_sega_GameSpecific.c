/*
 * Catapult Entertainment, Inc.
 *
 * $Id: Server_sega_GameSpecific.c,v 1.41 1995/12/11 17:58:20 ansell Exp $
 *
 * $Log: Server_sega_GameSpecific.c,v $
 * Revision 1.41  1995/12/11  17:58:20  ansell
 * Added new Sega game "Mortal Kombat 3".
 *
 * Revision 1.40  1995/10/15  20:35:18  josh
 * Added Madden '96 and NHL '96 one-sided-win algorithms
 *
 * Revision 1.39  1995/10/09  15:14:44  josh
 * Added WeaponLord one-sided-win algorithm (best of 7)
 *
 * Revision 1.38  1995/10/05  03:13:22  ansell
 * Added jump table entry for new Sega game NHL '96.
 *
 * Revision 1.37  1995/10/02  14:56:13  ansell
 * Added entry for new Sega game Madden '96.
 *
 * Revision 1.36  1995/09/16  17:13:21  fadden
 * Added Genesis_FIFASoccer95_Resolver.  Changed Madden completeEnough
 * point spread from 17 to 10.
 *
 * Revision 1.35  1995/09/13  16:59:51  fadden
 * Added an alias for Genesis Weapon Lord.
 *
 * Revision 1.34  1995/09/13  14:31:02  fadden
 * Removed extra entry from table.
 *
 * Revision 1.33  1995/09/13  14:24:58  ted
 * Fixed warnings.
 *
 * Revision 1.32  1995/09/10  22:34:23  fadden
 * Added CompleteEnough stuff.
 *
 * Revision 1.31  1995/08/25  17:51:00  fadden
 * Use WinAnalysis struct instead of comparing raw data.
 *
 * Revision 1.30  1995/08/10  12:03:12  fadden
 * Changed entry from Primal Rage (beta) gameID to Primal Rage gameID.
 *
 * Revision 1.29  1995/07/31  21:28:24  fadden
 * Added Ballz.  Changed SSF2 to use GenericCheckReset (which is just the
 * SSF2 reset check with a different name).
 *
 * Revision 1.28  1995/07/12  18:17:01  fadden
 * Added Rampart and Micro Machines.
 *
 * Revision 1.27  1995/07/12  17:30:32  ansell
 * Prepended magic cookie to "Game Result" type logs messages.
 *
 * Revision 1.26  1995/07/10  21:13:50  rich
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.25  1995/07/04  22:54:37  fadden
 * Added Primal Rage (beta).
 *
 * Revision 1.24  1995/06/22  23:09:45  fadden
 * Added Weapon Lord (final), made the beta version an alias to it.
 *
 * Revision 1.23  1995/06/17  14:00:35  fadden
 * Who would've guessed: turned the Madden '95 reset check off.
 *
 * Revision 1.22  1995/06/16  22:57:22  fadden
 * Put the SSF2 reset check in the right place.
 *
 * Revision 1.21  1995/06/09  13:58:57  fadden
 * Removed DumpMK2SendQ from the table.  #ifdefed out all the MK2 reset check
 * code, since it relied on the old MK2SendQ stuff.
 *
 * Revision 1.20  1995/06/07  11:30:26  fadden
 * Updated Madden '95 pretty-print.
 *
 * Revision 1.19  1995/05/29  21:06:38  fadden
 * Added reset check for SSF2.
 *
 * Revision 1.18  1995/05/22  17:13:00  fadden
 * Turned Madden '95 reset check back on (at KON's request).
 *
 */

/*
	File:		Server_sega_GameSpecific.c

	Contains:	Game-specific code for Sega Genesis ('sega').

	Written by:	Andy McFadden

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
*/


#include <sys/types.h>
#include <time.h>

#include "Server.h"
#include "Server_GameSpecific.h"
#include "Common.h"

#include "Errors.h"

//
// Local functions.
//
PRIVATE Err DumpJamsSendQ(const unsigned char *data, const long size,
	const long cookie);
PRIVATE Err CheckJamsScorable(const ServerState *state,
	const NewGameResult *gameResult);
PRIVATE Err JamsPossiblyLosing(const ServerState *state,
	const NewGameResult *gameResult);
PRIVATE Err DumpMKResult(const NewGameResult *gameResult, const long cookie);
PRIVATE Err DumpNHLResult(const NewGameResult *gameResult, const long cookie);
PRIVATE Err DumpMaddenResult(const NewGameResult *gameResult, 
	const long cookie);
PRIVATE Err MaddenPossiblyLosing(const ServerState *state, 
	const NewGameResult *gameResult);

#ifdef UNUSED
PRIVATE Err GetJamsNumWins(const NewGameResult *gameResult, long *p1wins,
	long *p2wins);
PRIVATE Err CheckJamsReset(const ServerState *state,
	const NewGameResult *gameResult, const NewGameResult *gameErrorResult);
PRIVATE Err CheckMKReset(const ServerState *state,
	const NewGameResult *gameResult, const NewGameResult *gameErrorResult);
PRIVATE Err CheckMK2Reset(const ServerState *state,
	const NewGameResult *gameResult, const NewGameResult *gameErrorResult);
PRIVATE Err CheckNHLReset(const ServerState *state,
	const NewGameResult *gameResult, const NewGameResult *gameErrorResult);
PRIVATE Err CheckMaddenReset(const ServerState *state,
	const NewGameResult *gameResult, const NewGameResult *gameErrorResult);
PRIVATE Err DumpMK2SendQ(const unsigned char *data, const long size,
	const long cookie);
#endif

PRIVATE Err Genesis_MK1_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err Genesis_MK2_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err Genesis_SSF2_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err Genesis_PrimalRage_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err Genesis_NBAJam_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err Genesis_NBALive_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err Genesis_NHL95_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err Genesis_Madden95_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err Genesis_FIFASoccer95_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err Genesis_WeaponLord_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err Genesis_NHL96_Resolver( NewGameResult *gameErrorResult);
PRIVATE Err Genesis_Madden96_Resolver( NewGameResult *gameErrorResult);

//
// Known Sega Genesis games (see Common_GameInfo.c for definitive list):
//
//	0x00000000	(game patch not entered)
//	0x0000000?	(test patch, could be anything)
//	0x00192660	NBA Live '95
//	0x067a218f	Ballz
//	0x31ed8123	Madden '95
//	0x3bb5e378	Primal Rage (beta) (aliased to 0xc6906e52)
//	0x3fed23f2	Road Rash 3
//	0x39677bdb	NBA JAM	(new)
//	0x433e2840	FIFA Soccer '95
//	0x4a017a94	Weapon Lord [rev 1]
//	0x4d1c4e1d	Super Street Fighter II
//	0x51a5e383	Rampart
//	0x6edb32d0	Micro Machines
//	0x8d68bdfb	Weapon Lord (beta) (aliased to 0x4a017a94)
//	0x8f6b9f70	NHL Hockey '95
//	0xa61b53f8	NHL Hockey '94
//	0xab6348e9	Mortal Kombat
//	0xbf33efc7	Weapon Lord [rev 2] (aliased to 0x4a017a94)
//	0xc4cddf0c	Mortal Kombat II
//	0xc6906e52	Primal Rage
//	0xe30c296e	NBA JAM (old) (aliased to 0x39677bdb)
//	0x4d402d90	Madden '96
//	0xafc0ce39	NHL '96
//	0x6d14eb41	Mortal Kombat 3
//
PRIVATE GameSpecificJumpTable gameSpecific[] = {
	{ 0x39677bdb, DumpJamsSendQ, NULL, NULL /*GetJamsNumWins*/,
		CheckJamsScorable, JamsPossiblyLosing, NULL /*CheckJamsReset*/,
		Genesis_NBAJam_Resolver },
	{ 0xab6348e9, NULL, DumpMKResult, NULL /*MatchGetNumWins*/,
		NULL, NULL, NULL /*CheckMKReset*/,
		Genesis_MK1_Resolver },
	{ 0xc4cddf0c, NULL /*DumpMK2SendQ*/, NULL, NULL /*MatchGetNumWins*/,
		NULL, NULL, NULL,
		Genesis_MK2_Resolver },
	{ 0xa61b53f8, NULL, DumpNHLResult, NULL,
		NULL, NULL, NULL,
		NULL },
	{ 0x8f6b9f70, NULL, DumpNHLResult, NULL,
		NULL, NULL, NULL /*CheckNHLReset*/,
		Genesis_NHL95_Resolver },
	{ 0x31ed8123, NULL, DumpMaddenResult, NULL,
		NULL, MaddenPossiblyLosing, NULL /*CheckMaddenReset*/,
		Genesis_Madden95_Resolver },
	{ 0x3fed23f2, NULL, NULL, NULL,
		NULL, NULL, NULL,
		NULL },
	{ 0x00192660, NULL, NULL, NULL,
		NULL, NULL, NULL,
		Genesis_NBALive_Resolver },
	{ 0x4d1c4e1d, NULL, NULL, NULL /*MatchGetNumWins*/,
		NULL, NULL, NULL,
		Genesis_SSF2_Resolver },
	{ 0x4a017a94, NULL, NULL, NULL /*MatchGetNumWins*/,
		NULL, NULL, NULL,
		Genesis_WeaponLord_Resolver },
	{ 0x433e2840, NULL, NULL, NULL,
		NULL, NULL, NULL,
		Genesis_FIFASoccer95_Resolver },
	{ 0xc6906e52, NULL, NULL, NULL /*MatchGetNumWins*/,
		NULL, NULL, NULL,
		Genesis_PrimalRage_Resolver },
	{ 0x51a5e383, NULL, NULL, NULL,
		NULL, NULL, NULL,
		NULL },
	{ 0x6edb32d0, NULL, NULL, NULL,
		NULL, NULL, NULL,
		NULL },
	{ 0x067a218f, NULL, NULL, NULL,
		NULL, NULL, NULL,
		NULL },
	{ 0x4d402d90, NULL, NULL, NULL,
		NULL, NULL, NULL,
		Genesis_Madden96_Resolver },
	{ 0xafc0ce39, NULL, NULL, NULL,
		NULL, NULL, NULL,
		Genesis_NHL96_Resolver },
	{ 0x6d14eb41, NULL, NULL, NULL,
		NULL, NULL, NULL,
		NULL },
};


//
// Look up a game.
//
// Returns a pointer to the appropriate gameSpecific entry via gsjtpp.
//
SEMI_PRIVATE int
Server_sega_LookupGameSpecific(const long gameID, GameSpecificJumpTable **gsjtpp)
{
	int i;

	*gsjtpp = NULL;
	for (i = 0; i < NELEM(gameSpecific); i++) {
		if (gameSpecific[i].gameID == gameID) {
			*gsjtpp = &gameSpecific[i];
			return (0);
		}
	}
	return (0);
}


// ===========================================================================
//		NBA JAM (0xe30c296e, 0x39677bdb)
// ===========================================================================

//Err
//DumpJamsResult(NewGameResult *gameResult)
//{
//}

// Stuff to help Steve debug NBA Jam scoring
//

/*     printfStats.c
       By Steve Perlman 8/23/94
*/

typedef struct JamsStats {
	long	gameID;
	long	frameCount;
	long	lateCount;
	long	lostSyncCount;
	long	caughtLateCount;
	long	gameFrames;
	long	skipCount;
	long	syncFlagSkips;
	long	rxFifoEmptyCount;

	long	endQFrameCount;
	long	endQLateCount;
	long	endQLostSyncCount;
	long	endQCaughtLateCount;
	long	endQGameFrames;
	long	endQSkipCount;
	long	endQSyncFlagSkips;
	long	endQRxFifoEmptyCount;

	unsigned char	refTimeStamp;				// syncOTron reference time stamp
	unsigned char	lastTimeStamp;				// last rxByte's timeStamp
	unsigned char	latencyCount;				// frames of latency
	unsigned char	isLeader;					// 1 if IAmLeader, 0 if IAmFollower

//	long			syncPtr;
//	unsigned char	syncList[24];

	long			patchHistPtr;
	unsigned char	patchHistBuf[32];				// patch history

	short			mode;
	unsigned short	avgEqm;
	unsigned short	maxEqm;
	//unsigned short	recoveryCount;
} JamsStats;


PRIVATE Err
DumpJamsSendQ(const unsigned char *data, const long size, const long cookie)
{
	int 		i;
	JamsStats *	j = (JamsStats *)data;
	double		latencyMSec;
	

	if (size != sizeof(JamsStats)) {
		FPLogmsg(LOG_GAMERESULT, LOGP_FLAW,
			"%ld-WARNING: data rcvd in SendQ != sizeof(JamsStats) (%ld vs %ld)\n",
			cookie, size, sizeof(JamsStats));
	}

	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "%ld-Jams SendQ Item:\n", cookie);

	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-Since resync:           frameCount:      %08x; gameFrames:       %08x.\n",
		cookie, j->frameCount, j->gameFrames);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-skipCount:    %08x; syncFlagSkips:   %08x; rxFifoEmptyCount: %08x.\n",
		cookie, j->skipCount, j->syncFlagSkips, j->rxFifoEmptyCount);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-lateCount:    %08x; caughtLateCount: %08x; lostSyncCount:    %08x.\n",
		cookie, j->lateCount, j->caughtLateCount, j->lostSyncCount);

	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-Last quarter:           frameCount:      %08x; gameFrames:       %08x.\n",
		cookie, j->endQFrameCount, j->endQGameFrames);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-skipCount:    %08x; syncFlagSkips:   %08x; rxFifoEmptyCount: %08x.\n",
		cookie, j->endQSkipCount, j->endQSyncFlagSkips, j->endQRxFifoEmptyCount);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-lateCount:    %08x; caughtLateCount: %08x; lostSyncCount:    %08x.\n",
		cookie, j->endQLateCount, j->endQCaughtLateCount, j->endQLostSyncCount);

	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-refTimeStamp: %02x      ; lastTimeStamp:   %02x      ; latencyCount:     %02x.\n",
		cookie, j->refTimeStamp, j->lastTimeStamp, j->latencyCount);

	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-mode:         %04x    ; isLeader:        %02x.\n",
		cookie, j->mode, j->isLeader);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-avgEqm:       %04u    ; maxEqm:          %02u.\n",
			cookie, j->avgEqm, j->maxEqm /*, j->recoveryCount*/);

/*
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "%ld-SyncList:", cookie);
	for (i = 0; i < j->syncPtr; i++) {
		if (i == 24) {
			FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "\n%ld-syncPtr overflow.",
				cookie);
			break;
		}			
		if ((i % 8) == 0)
			FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "\n%ld-", cookie);
		FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "%02x ", j->syncList[i]);
	}
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "\n");
*/
	
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "%ld-Patch History Buffer: \n%ld-",
		cookie, cookie);
	for (i = 0; i < j->patchHistPtr; i++) {
		if (i && !(i % 8)) {
			FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "\n%ld-", cookie);
			FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "\t");
		}
		if (i == 32) {
			FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, " patchHistPtr overflow.\n%ld-",
				cookie);
			break;
		}
		FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "%02x ", j->patchHistBuf[i]);	
	}
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "\n");

	latencyMSec = ( ((double)j->latencyCount - 3.0) +
					(((double)j->refTimeStamp - 37.0)/97.0)
				  ) * 16.66667;
	if (latencyMSec < 0.0) latencyMSec = 0.0;

	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-Computed latency as %.1fms\n", cookie, latencyMSec);
	return 0;
}

#ifdef UNUSED
//
// Determine #of wins for each JAMs player.
//
// Assume 10 points are available for the entire game.  The points are
// divided between winner and loser as follows:
//
// Solid victory (12+ points):		10-0
// Strong victory (5-11 points):	9-1
// Narrow victory (1-4 points):		8-2
// Tie game (0 points):				5-5
//
PRIVATE Err
GetJamsNumWins(const NewGameResult *gameResult, long *p1wins, long *p2wins)
{
	WinAnalysis winAnal;
	long delta, win, lose;

	Server_AnalyzeWin(gameResult, &winAnal);

	delta = (winAnal.pointsFor > winAnal.pointsAgainst) ?
		winAnal.pointsFor - winAnal.pointsAgainst :
		winAnal.pointsAgainst - winAnal.pointsFor;
	if (delta >= 12) {
		win = 10;
		lose = 0;
	} else if (delta >= 5) {
		win = 9;
		lose = 1;
	} else if (delta >= 1) {
		win = 8;
		lose = 2;
	} else {
		win = 5;
		lose = 5;
	}

	if (winAnal.win > 0) {
		*p1wins = win;
		*p2wins = lose;
	} else {
		*p1wins = lose;
		*p2wins = win;
	}

	return (kNoError);
}
#endif UNUSED

//
// Given a game with no errors or other abnormalities, determine if
// it should actually be recorded.
//
// Only games that run to completion (time == 4 or 5) should be used
// for rankings.  People who set single-quarter mode should not receive
// anything.
//
// Returns kNoError if game should be scored, kFucked otherwise.
//
PRIVATE Err
CheckJamsScorable(const ServerState *state, const NewGameResult *gameResult)
{
	if (gameResult == NULL)
		return (kFucked);		// shouldn't happen

	if (gameResult->playTime < 4 || gameResult->playTime > 6) {
		FLogmsg(LOG_RATING, "NBA Jam playTime=%ld, game not scored\n",
			gameResult->playTime);
		if (gameResult->playTime == 9) {
			// I18N Appears: For Beta testers when testing.
			//
			Server_SendDialog((ServerState *)state, gettext("Your previous game of NBA Jam only lasted one quarter, because a special code was used.  These games do not affect your Stats."), true);	/* DIALOG */
		}
		return(kFucked);
	}

	return (kNoError);
}

//
// Determine whether or not a JAMs player was losing.  We don't want them
// to get away with stuff by shooting a 3-pointer and then hitting reset
// or calling themselves.
//
// Doesn't handle forfeits.  Don't think it needs to.
//
// Returns kNoError if he was probably winning, kFucked if he was possibly
// losing.
//
PRIVATE Err
JamsPossiblyLosing(const ServerState *state, const NewGameResult *gameResult)
{
	WinAnalysis winAnal;

	Server_AnalyzeWin(gameResult, &winAnal);

	if (winAnal.pointsFor <= (winAnal.pointsAgainst + 3))
		return (kFucked);

	return (kNoError);
}

#ifdef UNUSED
//
// Criteria for determining whether or not the reset was intentional:
//
//	- no valid gameResult (if we got those, we can score it)
//	- localGameError == 0
//	- playTime > 0
//	- local score <= remote score (being within 3 counts; no resets during
//	  last-minute 3-pointers!!)
//	- no crash record
//	- frameCount < 2*gameFrames
//
// If the game had started and you weren't winning, it counts as a "maybe"
// reset, which has no effect other than a counter being incremented.
//
PRIVATE Err
CheckJamsReset(const ServerState *state, const NewGameResult *gameResult,
	const NewGameResult *gameErrorResult)
{
	WinAnalysis winAnal;
	long cookie;
	QItem *item, *jamsItem;
	JamsStats *j;
	int i;

	cookie = Server_GetMatchCookie(state);

	if (gameErrorResult == NULL) {
		FLogmsg(LOG_GAMERESULT,
			"%ld-  Odd: reset detected in gameResult, NO gameErrorResult\n",
			cookie);
		return (kNoError);
	} else {
		if (gameResult != NULL) {
			if ((gameResult->playTime >= 4 && gameResult->playTime <= 5) ||
				gameResult->playTime == 8)
			{
				// Probably reset in a post-"do you want to playl again" match.
				// No stats, no foul.
				//
				FLogmsg(LOG_GAMERESULT,
					"%ld-  Found gameResult with valid playTime, assuming OK.\n"
					, cookie);
				return (kNoError);
			}
		}

/*
	Removed 94/11/20
		// -1  == game not started
		//  0  == in first quarter or fields not yet initialized to -1
		// 1-4 == end of that quarter
		// 5,6 == end of overtime1 or overtime2
		//  8  == in first quarter, 1qtr mode
		//  9  == end of game, 1qtr mode
		if (gameErrorResult->playTime <= 0) {
			FLogmsg(LOG_GAMERESULT,
				"%ld-  gameErrorResult->playTime <= 0, OK.\n", cookie);
			return (kNoError);
		}
*/
		// If game hasn't started, zero the score out.  Otherwise we get
		// wacky stuff like -65513.
		//
		// This violation of const declarations brought to you by the
		// number 7 and the letter P.  [ Brett may have fixed this one
		// recently. ++ATM 950503 ]
		//
		if (gameErrorResult->playTime == -1) {
			gameErrorResult->localPlayer1Result =
				gameErrorResult->localPlayer2Result =
				gameErrorResult->remotePlayer1Result =
				gameErrorResult->remotePlayer2Result = 0;
		}

		Server_AnalyzeWin(gameErrorResult, &winAnal);

/*
	Removed 94/11/21
		if (local == -1 && remote == -1) {
			FLogmsg(LOG_GAMERESULT, "%ld-  Both scores were -1, OK.\n",
				cookie);
			return (kNoError);
		}
*/

		// Doesn't handle forfeits, but that should be irrelevant if
		// the guy hit reset.
		//
		if ((gameErrorResult->playTime) >= 0 &&
			(winAnal.pointsFor > winAnal.pointsAgainst + 3))
		{
			FLogmsg(LOG_GAMERESULT,
				"%ld-  Player was ahead by at least 4, OK.\n", cookie);
			return (kResetMaybe);
		}

		if (gameErrorResult->localGameError) {
			FLogmsg(LOG_GAMERESULT,
				"%ld-  gameErrorResult->localGameError!=0, probably OK\n",
				cookie);
			return (kResetMaybe);
		}

		// Look for a crashRecord.  This is iffy... they could do something
		// to deliberately crash their machine.
		//
		jamsItem = NULL;
		for (i = 0; i < state->sendQData.count; i++) {
			item = &state->sendQData.items[i];

			if (item->theID == kRestartInfoType) {
				FLogmsg(LOG_GAMERESULT,
					"%ld-  Found a crash record, probably OK.\n", cookie);
				return (kResetMaybe);
			}
			if (item->theID == kGameResultDataDBID)
				jamsItem = item;
		}

		if (jamsItem == NULL) {
			FLogmsg(LOG_GAMERESULT,
				"%ld-  Odd: no Jams SendQ item, skipping test.\n", cookie);
				return (kNoError);
		} else {
			j = (JamsStats *)jamsItem->data;
			if (j->frameCount > j->gameFrames * 2) {
				FLogmsg(LOG_GAMERESULT,
					"%ld-  Found frameCount > 2*gameFrames, OK.\n", cookie);
				return (kNoError);
			}
		}
	}

	// If we get all the way down here, we didn't catch on any of the tests.
	//
	return (kResetDefinite);
}
#endif UNUSED

// ===========================================================================
//		Mortal Kombat (0xab6348e9)
// ===========================================================================

typedef struct MKResults {
	unsigned short	frameDelay;
	unsigned short	totalVBLs;
	unsigned short	skippedVBLs;
	unsigned short	mkState;
	short			checkLineResult;
} MKResults;

PRIVATE Err
DumpMKResult(const NewGameResult *gameResult, const long cookie)
{
	MKResults *mkresults = (MKResults *)gameResult->gameReserved;

	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "%ld-Mortal Kombat stuff:\n", cookie);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  frameDelay: %-5u    totalVBLs: %-5u\n",
		cookie, mkresults->frameDelay, mkresults->totalVBLs);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  skippedVBLs: %-5u   mkState: 0x%.4x\n",
		cookie, mkresults->skippedVBLs, mkresults->mkState);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  checkLineResult: %-5d\n",
		cookie, mkresults->checkLineResult);
	return 0;
}

#ifdef UNUSED
//
// Criteria for determining whether or not the reset was intentional:
//
//	- localGameError != 0
//	- mkState != 0 (make sure it got set)
//	- mkState high byte == 0
//
PRIVATE Err
CheckMKReset(const ServerState *state, const NewGameResult *gameResult,
	const NewGameResult *gameErrorResult)
{
	WinAnalysis winAnal;
	MKResults *mkresults;
	QItem *item;
	long cookie;
	int i;

	cookie = Server_GetMatchCookie(state);

	if (gameErrorResult == NULL) {
		FLogmsg(LOG_GAMERESULT,
			"%ld-  Odd: reset detected in gameResult, NO gameErrorResult\n",
			cookie);
		return (kNoError);
	} else {
		mkresults = (MKResults *)gameErrorResult->gameReserved;

		if (mkresults->mkState == 0) {
			FLogmsg(LOG_GAMERESULT,
				"%ld-  mkresults->mkState==0, mkstate not initialized, OK.\n",
				cookie);
			return (kNoError);
		}

		Server_AnalyzeWin(gameErrorResult, &winAnal);
		if (winAnal.pointsFor > winAnal.pointsAgainst) {
			FLogmsg(LOG_GAMERESULT, "%ld-  Player was winning, OK.\n",
				cookie);
			return (kNoError);
		}
		if (!winAnal.pointsFor && !winAnal.pointsAgainst) {
			FLogmsg(LOG_GAMERESULT, "%ld-Score was 0-0, probably OK.\n",
				cookie);
			return (kResetMaybe);
		}

		if (gameErrorResult->localGameError != 0) {
			FLogmsg(LOG_GAMERESULT,
				"%ld-  gameErrorResult->localGameError!=0, probably OK.\n",
				cookie);
			return (kResetMaybe);
		}

		if ((mkresults->mkState & 0xff00) != 0) {
			FLogmsg(LOG_GAMERESULT,
				"%ld-  According to mkState we were handling err, probably OK.\n",
				cookie);
			return (kResetMaybe);
		}

		for (i = 0; i < state->sendQData.count; i++) {
			item = &state->sendQData.items[i];

			if (item->theID == kRestartInfoType) {
				FLogmsg(LOG_GAMERESULT,
					"%ld-  Found a crash record, probably OK.\n", cookie);
				return (kResetMaybe);
			}
		}

		//FLogmsg(LOG_GAMERESULT,
		//	"%ld-Found mkState = 0x%.4lx (&->0x%.4lx); DEBUG:\n",
		//		cookie, mkresults->mkState, mkresults->mkState & 0xff00);
		//DumpMKResult(gameErrorResult);
		//FLogmsg(LOG_GAMERESULT, "%ld---- end DEBUG\n", cookie);
	}

	return (kResetDefinite);
}
#endif UNUSED

// ===========================================================================
//		Mortal Kombat II (0xc4cddf0c)
// ===========================================================================

#ifdef UNUSED
typedef struct MK2SendQ {
	u_long	gameID;
	u_long	syncFlagSkips;			// synco junk
	u_long	rxFifoEmptyCount;
	u_long	lateCount;
	u_long	lostSyncCount;
	u_long	caughtLateCount;
	u_long	gameFrames;				// count of non-skipped vbls

	u_char	refTimeStamp;			// more synco junk
	u_char	lastTimeStamp;
	u_char	latencyCount;			// frame delta between the two machines
	u_char	isLeader;				// true if i am the master

	u_char	callWaitingCount;		// # of call waiting events
	u_char	gameHoldOff;			// (counts by 2) frames to hold off
									//   while other catches up

	u_char	p1RoundWins;			// # of P1 wins THIS ROUND
	u_char	p2RoundWins;			// # of P2 wins THIS ROUND

	u_long	errRecoverTime;			// error recovery timeout tick count

	u_char	inResync;				// Nonzero -> in resync
	u_char	uploadPad[3];			// padbyte
} MK2SendQ;

PRIVATE Err
DumpMK2SendQ(const unsigned char *data, const long size, const long cookie)
{
	MK2SendQ *mk2res = (MK2SendQ *)data;

	if (size != sizeof(MK2SendQ)) {
		FPLogmsg(LOG_GAMERESULT, LOGP_FLAW,
			"%ld-WARNING: data rcvd in SendQ != sizeof(MK2SendQ) (%ld vs %ld)\n",
			cookie, size, sizeof(MK2SendQ));
		// (just dump hex and bail?)
	}

	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "%ld-MK2 SendQ Item:\n", cookie);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  syncFlagSkips: %.8lx  rxFifoEmptyCount: %.8lx\n",
		cookie, mk2res->syncFlagSkips, mk2res->rxFifoEmptyCount);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  lateCount: %.8lx  lostSyncCount: %.8lx\n",
		cookie, mk2res->lateCount, mk2res->lostSyncCount);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  caughtLateCount: %.8lx  gameFrames: %.8lx\n",
		cookie, mk2res->caughtLateCount, mk2res->gameFrames);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  refTimeStamp: 0x%.2x  lastTimeStamp: 0x%.2x  latencyCount: 0x%.2x\n",
		cookie, mk2res->refTimeStamp, mk2res->lastTimeStamp, mk2res->latencyCount);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  isLeader: 0x%.2x  callWaitingCount: 0x%.2x  gameHoldOff: 0x%.2x\n",
		cookie, mk2res->isLeader, mk2res->callWaitingCount, mk2res->gameHoldOff);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  p1RoundWins: 0x%.2x  p2RoundWins: 0x%.2x\n",
		cookie, mk2res->p1RoundWins, mk2res->p2RoundWins);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  errRecoverTime: 0x%.8lx inResync: 0x%.2x\n",
		cookie, mk2res->errRecoverTime, mk2res->inResync);

	return (kNoError);
}
#endif UNUSED

#ifdef UNUSED
//
// Criteria for determining whether or not the reset was intentional:
//
//	- no valid gameResult (if we got those, we can score it)
//	- scores not zero
//	- my wins <= his wins (including match scores, yay!)
//	- no crash record
//
// If the game had started and you weren't winning, it counts as a "maybe"
// reset, which has no effect other than a counter being incremented.
//
PRIVATE Err
CheckMK2Reset(const ServerState *state, const NewGameResult *gameResult,
	const NewGameResult *gameErrorResult)
{
	WinAnalysis winAnal;
	long cookie;
	QItem *item, *mk2Item;
	MK2SendQ *mkq;
	int i;

	cookie = Server_GetMatchCookie(state);

	if (gameErrorResult == NULL) {
		FLogmsg(LOG_GAMERESULT,
			"%ld-  Odd: reset detected in gameResult, NO gameErrorResult\n",
			cookie);
		return (kNoError);
	} else {
		// Look for a crashRecord.  This is iffy... they could do something
		// to deliberately crash their machine.
		//
		// Pull out the MK2 item while we're here.
		//
		mk2Item = NULL;
		for (i = 0; i < state->sendQData.count; i++) {
			item = &state->sendQData.items[i];

			if (item->theID == kRestartInfoType) {
				FLogmsg(LOG_GAMERESULT,
					"%ld-  Found a crash record, probably OK.\n", cookie);
				return (kResetMaybe);
			}
			if (item->theID == kGameResultDataDBID)
				mk2Item = item;
		}
		if (mk2Item == NULL) {
			FLogmsg(LOG_GAMERESULT,
				"%ld-  Odd: no MK2 SendQ item, skipping test.\n", cookie);
				return (kNoError);
		}
		mkq = (MK2SendQ *)mk2Item->data;

		Server_AnalyzeWin(gameErrorResult, &winAnal);

		// (fix me)

		if (!local && !remote && !mkq->p1RoundWins && !mkq->p2RoundWins) {
			FLogmsg(LOG_GAMERESULT, "%ld-  All scores were 0, OK.\n", cookie);
			return (kNoError);
		}

		if (mkq->inResync) {
			FLogmsg(LOG_GAMERESULT,
				"%ld-  Player was in resync, probably OK.\n", cookie);
			return (kResetMaybe);
		}

		// If the round scores were even, factor in the match results
		// current round (which will be either 1 or 0 for each player).
		//
		if (local == remote) {
			if (mkq->isLeader) {
				local += mkq->p1RoundWins;		// leader == master == p1
				remote += mkq->p2RoundWins;
			} else {
				local += mkq->p2RoundWins;		// !leader == slave == p2
				remote += mkq->p1RoundWins;
			}
		}

		// Now compare the adjusted round scores.  If we're at 4-4 with 1-1,
		// we'll be tied, so nail them when tied as well as when losing.
		//
		if (local > remote) {
			FLogmsg(LOG_GAMERESULT, "%ld-  Player was winning, OK.\n", cookie);
			return (kNoError);
		}
	}

	// If we get all the way down here, we didn't catch on any of the tests.
	//
	return (kResetDefinite);
	return (kNoError);
}
#endif UNUSED

// ===========================================================================
//		NHL Hockey '94 (0xa61b53f8) and NHL Hockey '95 (0x8f6b9f70)
// ===========================================================================

typedef struct NHLResults {
	short   stage;
	short   gameState;
	short   frameDelay;
	short   gtErrorRecovers;
	short   gtRecovered;
	short   skippedVBLs;
	long    totalVBLs;
	long    controlChksum;
	long    controlXOR;
	short   crcErrors;
	short   checklineErr;
	char    callWaits;
	char    remoteCallWaits;
	char    connectLost;
	char    errTimeouts;
} NHLResults;


PRIVATE Err
DumpNHLResult(const NewGameResult *gameResult, const long cookie)
{
	NHLResults *nhlresults = (NHLResults *)gameResult->gameReserved;

	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "%ld-NHL Hockey '94/'95 stuff:\n",
		cookie);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  stage: 0x%x  gameState: 0x%x  frameDelay: 0x%x\n", cookie,
		nhlresults->stage, nhlresults->gameState, nhlresults->frameDelay);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  gtErrorRecovers: 0x%x  gtRecovered: 0x%x\n", cookie,
		nhlresults->gtErrorRecovers, nhlresults->gtRecovered);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  totalVBLs: 0x%x  skippedVBLs: 0x%x\n", cookie,
		nhlresults->totalVBLs, nhlresults->skippedVBLs);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  controlChksum: 0x%x  controlXOR: 0x%x\n", cookie,
		nhlresults->controlChksum, nhlresults->controlXOR);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  crcErrors: 0x%x  checklineErr: 0x%x\n", cookie,
		nhlresults->crcErrors, nhlresults->checklineErr);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  callWaits: 0x%x  remoteCallWaits: 0x%x\n", cookie,
		nhlresults->callWaits, nhlresults->remoteCallWaits);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  connectLost: 0x%x  errTimeouts: 0x%x\n", cookie,
		nhlresults->connectLost, nhlresults->errTimeouts);

	return (kNoError);
}

#ifdef UNUSED
//
// Criteria for NHL evil reset:
//	- localGameError is zero
//	- either game hasn't started, or game has started and player is losing
//	- no crash record
//
PRIVATE Err
CheckNHLReset(const ServerState *state, const NewGameResult *gameResult,
	const NewGameResult *gameErrorResult)
{
	WinAnalysis winAnal;
	long cookie;

	cookie = Server_GetMatchCookie(state);

	if (gameErrorResult == NULL) {
		FLogmsg(LOG_GAMERESULT,
			"%ld-  Odd: reset detected in gameResult, NO gameErrorResult\n",
			cookie);
		return (kNoError);
	} else {
		Server_AnalyzeWin(gameErrorResult, &winAnal);

		// Patch was broken for a while... fixed now?
		//
		if (winAnal.pointsFor > 100 || winAnal.pointsAgainst > 100) {
			FLogmsg(LOG_GAMERESULT, "%ld-  Wacky scores %d/%d, not evil.\n",
				cookie, winAnal.pointsFor, winAnal.pointsAgainst);
			return (kNoError);
		}

		if (gameErrorResult->localGameError != 0) {
			FLogmsg(LOG_GAMERESULT,
				"%ld-  Reset while in Error Recover, OK.\n", cookie);
			return (kNoError);					
		}
		
		// Doesn't handle forfeits, but that should be irrelevant if
		// the guy hit reset.
		//
		if ((gameErrorResult->playTime) >= 0 &&
			(winAnal.pointsFor > winAnal.pointsAgainst))
		{
			FLogmsg(LOG_GAMERESULT,
				"%ld-  Player was ahead by at least 1, OK.\n", cookie);
			return (kResetMaybe);
		}

		// Look for a crashRecord.  This is iffy... they could do something
		// to deliberately crash their machine.
		//
		if (Server_FindSendQItem(state, kRestartInfoType) != NULL) {
			FLogmsg(LOG_GAMERESULT,
				"%ld-  Found a crash record, probably OK.\n", cookie);
			return (kResetMaybe);
		}
	}

	// If we get all the way down here, we didn't catch on any of the tests.
	//
	return (kResetDefinite);
}
#endif UNUSED


// ===========================================================================
//		Madden '95 (0x31ed8123)
// ===========================================================================

typedef struct MaddenResults {
	char				quarter;
	char				quarterLen;
	char				homeTeam;
	char				visitTeam;

	long				vblTicker;
	unsigned long int	watchdogTimer;
	short int			pauseJoy;

	unsigned short int	timeLeft;
	unsigned short int	gameState;
	short int			frameDelay;
	short int			gtErrorRecovers;
	short int			gtRecovered;
	short int			crcFailures;

	short int			lastGTError;
	short int			checklineErr;

	unsigned char		callWaits;
	unsigned char		remoteCallWaits;
	unsigned char		connectLost;
	unsigned char		errTimeouts;
} MaddenResults;

//
// Madden defs
//

#define kState_Normal				0x0000	// normal game state
#define kState_EstablishSynch		0x0100	// in OS establish sync routine
#define kState_ErrorRecovery		0x0200	// in error recovery
#define kState_PowerUps				0x0400	// power-up mode enabled
#define kState_VBlank				0x0800	// in vertical blank
#define kState_ExtraCheckSum		0x2000	// extra checksum enabled
#define kState_InFade				0x4000	// in forced fader

#define kState_Credits				0x01	// showing credit screens
#define kState_SetOptions			0x02	// setting game options
#define kState_SetJoysticks			0x04	// setting game controllers
#define kState_CoinToss				0x08	// doing coin toss
#define kState_Game					0x10	// in main game loop
#define kState_Intermission			0x20	// in intermission screen
#define kState_PauseMode			0x40	// doing pause mode
#define kState_GameOver				0x80	// end of game


PRIVATE Err
DumpMaddenResult(const NewGameResult *gameResult, const long cookie)
{
	MaddenResults *maddenres = (MaddenResults *)gameResult->gameReserved;

	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG, "%ld-Madden '95 stuff:\n", cookie);
	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  Quarter#: %d, Quarter Index: %d, Home#: %d, Visitor#: %d\n",
		cookie, maddenres->quarter, maddenres->quarterLen, maddenres->homeTeam,
		maddenres->visitTeam);

	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-GameState: [%02x-%02x %s %s %s %s %s], FrameDelay: %d\n",
		cookie, maddenres->gameState >> 8, maddenres->gameState & 0xff,
		(maddenres->gameState & kState_PowerUps)
			? "PU" : "",
		(maddenres->gameState & kState_VBlank)
			? "VB" : "",
		(maddenres->gameState & kState_ExtraCheckSum)
			? "CK" : "",
		(maddenres->gameState & kState_ErrorRecovery)
			? "ER" : "",
		(maddenres->gameState & kState_InFade)
			? "IF" : "",
		maddenres->frameDelay);

	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-VBLs: %d, WatchDog: %d, Time left: %d\n",
		cookie, maddenres->vblTicker, maddenres->watchdogTimer,
		maddenres->timeLeft);

	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  Last GTError: %d, GTErrRecovers: %d (Good: %d)\n",
		cookie, maddenres->lastGTError, maddenres->gtErrorRecovers,
		maddenres->gtRecovered);

	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-  Errors: [CheckLine: %d, CallWaits: (local: %d, remote: %d)]\n",
		cookie, maddenres->checklineErr, maddenres->callWaits,
		maddenres->remoteCallWaits);

	FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
		"%ld-          [CRC: %d, ConnectLost: %d, Timeouts: %d]\n", cookie,
		maddenres->crcFailures, maddenres->connectLost, maddenres->errTimeouts);

	return (kNoError);
}

//
// Determine whether or not a Madden player was losing.  We don't want them
// to try to avoid a last-minute guaranteed field goal by hitting reset
// or calling themselves.
//
// Doesn't handle forfeits.  Don't think it needs to.
//
// Returns kNoError if he was probably winning, kFucked if he was possibly
// losing.
//
PRIVATE Err
MaddenPossiblyLosing(const ServerState *state, const NewGameResult *gameResult)
{
	WinAnalysis winAnal;

	Server_AnalyzeWin(gameResult, &winAnal);

	if (winAnal.pointsFor <= (winAnal.pointsAgainst + 2))
		return (kFucked);

	return (kNoError);
}

#ifdef UNUSED
//
// (Sequential) criteria for determining whether or not the reset was evil:
//
//	- not evil if we were doing error recovery (unless due to call waiting)
//	//- not evil if other guy (?) was doing lots of delays
//	- evil if in non-play mode
//	//- evil if we were losing, or winning by only a small amount
//
PRIVATE Err
CheckMaddenReset(const ServerState *state, const NewGameResult *gameResult,
	const NewGameResult *gameErrorResult)
{
	WinAnalysis winAnal;
	MaddenResults *maddenres;
	long diff;
	unsigned long cookie;

	cookie = Server_GetMatchCookie(state);

	if (gameErrorResult == NULL) {
		FLogmsg(LOG_GAMERESULT,
			"%ld-  Odd: reset detected in gameResult, NO gameErrorResult\n",
			cookie);
		return (kNoError);
	} else {
		maddenres = (MaddenResults *)gameErrorResult->gameReserved;

		// Look for a crash record.
		//
		if (Server_FindSendQItem(state, kRestartInfoType) != NULL) {
			FLogmsg(LOG_GAMERESULT,
				"%ld-  Found a crash record, probably OK.\n", cookie);
			return (kResetMaybe);
		}

		// See if they reset before the game began.
		//
		if (gameErrorResult->playTime <= 0) {
			FLogmsg(LOG_GAMERESULT, "%ld-  game not started, definite.\n",
				cookie);
			return (kResetDefinite);
		}

		// Check game state.
		//
		if (maddenres->gameState & kState_ErrorRecovery)
		{
			// Check if we're here because of call waiting.
			//
			if (gameErrorResult->localGameError == kCallWaitingErr ||
				gameErrorResult->localGameError == kRemoteCallWaitingErr)
			{
				FLogmsg(LOG_GAMERESULT,
					"%ld-  inErrorRecovery, call waiting error, definite.\n",
					cookie);
				return (kResetDefinite);
			} else {
				FLogmsg(LOG_GAMERESULT, "%ld-  inErrorRecovery, not cw, maybe.\n",
					cookie);
				return (kResetMaybe);
			}
		}

#ifdef NO_MORE
		// Check if we have some delays, but not enough for -440.
		//
		if (maddenres->delaysPerQuarter[maddenres->quarter] >= 2) {
			FLogmsg(LOG_GAMERESULT, "%ld-  Many delays, maybe.\n", cookie);
			return (kResetMaybe);
		}
#endif

		Server_AnalyzeWin(gameErrorResult, &winAnal);

		// Check if we are in the end of game.
		//
		// Doesn't handle forfeits; shouldn't matter.
		//
		if ((maddenres->gameState & 0xff) == kState_GameOver) {
			if (winAnal.pointsFor >= winAnal.pointsAgainst) {
				FLogmsg(LOG_GAMERESULT, "%ld-  Finished game & didn't lose.\n",
					cookie);
				return (kNoError);
			} else {
				FLogmsg(LOG_GAMERESULT, "%ld-  Game over man, definite.\n",
					cookie);
				return (kResetDefinite);
			}
		}

		// Check if we are losing and how far into the game we are
		//
		diff = winAnal.pointsFor - winAnal.pointsAgainst;
		if (maddenres->quarter < 3) {
			// Must be losing toward beginning.
			//
			if (diff < 0) {
				FLogmsg(LOG_GAMERESULT,
					"%ld-  Early in game, losing, definite.\n", cookie);
				return (kResetDefinite);
			}
		} else if (diff <= 3) {
			// May be winning slightly toward the end... don't want them
			// to hit reset just as the other guy sets up for an easy
			// field goal.
			//
			FLogmsg(LOG_GAMERESULT,
				"%ld-  Late in game, score within 3, definite.\n", cookie);
			return (kResetDefinite);
		}
	}

	FLogmsg(LOG_GAMERESULT, "%ld-  All criteria checked, looks okay.\n",
		cookie);
	return (kNoError);
}
#endif UNUSED

// ===========================================================================
//		CompleteEnough stuff (from Josh)
// ===========================================================================

//
// These are all piled together, in no particular order.
//

//
// This function will look at MK2 game results and decide whether a
//completed game should be declared,
// and if so, who should get the "win" points (if it wasn't a player-list match)
//
// (Fadden, this will be from some lookup table, presumably)
//

typedef struct Genesis_MK1_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} Genesis_MK1_GameData;

PRIVATE Err
Genesis_MK1_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
Genesis_MK1_GameData *mk1Data = (Genesis_MK1_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long wins;
unsigned long losses;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( mk1Data->dataVersion != kGenesis_MK1_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif
	
	/* for now, we'll call any matches that are 2-0 a win. And we'll call */
	/* matches that are 2-2 and 2-1 a tie. Others are not far enough along. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	wins = winAnal.pointsFor;
	losses = winAnal.pointsAgainst;

	if ( ( wins > 3 ) || ( losses > 3 ) || ( ( wins == 3 ) && ( losses == 3 ) ) )
	{
		// wacky win/loss thing. Bail!
		return (kNotEnoughCompletedTie);
	}
	
	// 3-X is a win! (Probably shouldn't be gameErrors in this case, but who knows?
	if ( wins == 3 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 3 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 2-0 is a win!
	if ( wins == 2 && losses == 0 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 2 && wins == 0 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 2-2, 2-1 is a tie. (Note that 2-0 cases are handled above)
	if ( wins == 2 || losses == 2 )
	{
		return (kEnoughCompletedTie);
	}
	
	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct Genesis_MK2_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} Genesis_MK2_GameData;

PRIVATE Err
Genesis_MK2_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
Genesis_MK2_GameData *mk2Data = (Genesis_MK2_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long wins;
unsigned long losses;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( mk2Data->dataVersion != kGenesis_MK2_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif
	
	/* for now, we'll call any matches that are 3-0, 4-0, 4-1, 4-2 a win. And
we'll call */
	/* matches that are 4-3 and 4-4 a tie. Others are not far enough along. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	wins = winAnal.pointsFor;
	losses = winAnal.pointsAgainst;

	if ( ( wins > 5 ) || ( losses > 5 ) || ( ( wins == 5 ) && ( losses == 5 ) ) )
	{
		// wacky win/loss thing. Bail!
		return (kNotEnoughCompletedTie);
	}
	
	// 5-X is a win! (Probably shouldn't be gameErrors in this case, but who knows?
	if ( wins == 5 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 5 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 4-0, 4-1, 4-2 is a win!
	if ( wins == 4 && losses < 3 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 4 && wins < 3 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 4-3, 4-4 is a tie.
	if ( wins == 4 || losses == 4 )
	{
		return (kEnoughCompletedTie);
	}
	
	// 3-0 is a win.
	if ( wins == 3 && losses == 0 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 3 && wins == 0 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct Genesis_SSF2_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} Genesis_SSF2_GameData;

PRIVATE Err
Genesis_SSF2_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
Genesis_SSF2_GameData *ssf2Data = (Genesis_SSF2_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long wins;
unsigned long losses;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( ssf2Data->dataVersion != kGenesis_SSF2_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif
	
	/* for now, we'll call any matches that are 3-0, 4-0, 4-1, 4-2 a win. And
we'll call */
	/* matches that are 4-3 and 4-4 a tie. Others are not far enough along. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	wins = winAnal.pointsFor;
	losses = winAnal.pointsAgainst;

	if ( ( wins > 5 ) || ( losses > 5 ) || ( ( wins == 5 ) && ( losses == 5 ) ) )
	{
		// wacky win/loss thing. Bail!
		return (kNotEnoughCompletedTie);
	}
	
	// 5-X is a win! (Probably shouldn't be gameErrors in this case, but who knows?
	if ( wins == 5 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 5 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 4-0, 4-1, 4-2 is a win!
	if ( wins == 4 && losses < 3 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 4 && wins < 3 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 4-3, 4-4 is a tie.
	if ( wins == 4 || losses == 4 )
	{
		return (kEnoughCompletedTie);
	}
	
	// 3-0 is a win.
	if ( wins == 3 && losses == 0 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 3 && wins == 0 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct Genesis_PrimalRage_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} Genesis_PrimalRage_GameData;

PRIVATE Err
Genesis_PrimalRage_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
Genesis_PrimalRage_GameData *primalRageData = (Genesis_PrimalRage_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long wins;
unsigned long losses;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( primalRageData->dataVersion != kGenesis_PrimalRage_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif
	
	/* for now, we'll call any matches that are 3-0, 3-1 a win. And we'll call */
	/* matches that are 2-2 a tie. Others are not far enough along. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	wins = winAnal.pointsFor;
	losses = winAnal.pointsAgainst;

	if ( ( wins > 4 ) || ( losses > 4 ) || ( ( wins == 4 ) && ( losses == 4 ) ) )
	{
		// wacky win/loss thing. Bail!
		return (kNotEnoughCompletedTie);
	}
	
	// 4-X is a win! (Probably shouldn't be gameErrors in this case, but who knows?
	if ( wins == 4 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 4 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 3-0, 3-1 is a win!
	if ( wins == 3 && losses < 2 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 3 && wins < 2 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 2-2, 3-3, 3-2 is a tie.
	if ( wins == 3 || losses == 3 || ( ( wins == 2 ) && ( losses == 2 ) ) )
	{
		return (kEnoughCompletedTie);
	}
	
	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct Genesis_NBAJam_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} Genesis_NBAJam_GameData;

PRIVATE Err
Genesis_NBAJam_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
Genesis_NBAJam_GameData *nbaJamData = (Genesis_NBAJam_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long player1Points;
unsigned long player2Points;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( nbaJamData->dataVersion != kGenesis_NBAJam_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif

	/* for now, we'll call an 8 point lead a victory. Otherwise it's a tie if
there */
	/* are more than 80 points scored. */
	/* This logic will need revving once I figure out what quarter it is, etc. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	player1Points = winAnal.pointsFor;
	player2Points = winAnal.pointsAgainst;

	/* Quick sanity check. 200 points would be a lot! */
	if ( ( player1Points > 200 ) || ( player2Points > 200 ) )
	{
		return (kNotEnoughCompletedTie);
	}

	/* 8 point lead or more is a win! */
	if ( player1Points >= player2Points + 8 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( player2Points >= player1Points + 8 )
	{
		return (kEnoughCompletedRemoteWinner);
	}

	if ( player1Points + player2Points > 80 )
	{
		return (kEnoughCompletedTie);
	}

	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct Genesis_NBALive_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} Genesis_NBALive_GameData;

PRIVATE Err
Genesis_NBALive_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
Genesis_NBALive_GameData *nbaLiveData = (Genesis_NBALive_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long player1Points;
unsigned long player2Points;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( nbaLiveData->dataVersion != kGenesis_NBALive_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif

	/* for now, we'll call an 8 point lead a victory. Otherwise it's a tie if
there */
	/* are more than 80 points scored. */
	/* This logic will need revving once I figure out what quarter it is, etc. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	player1Points = winAnal.pointsFor;
	player2Points = winAnal.pointsAgainst;

	/* Quick sanity check. 200 points would be a lot! */
	if ( ( player1Points > 200 ) || ( player2Points > 200 ) )
	{
		return (kNotEnoughCompletedTie);
	}

	/* 8 point lead or more is a win! */
	if ( player1Points >= player2Points + 8 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( player2Points >= player1Points + 8 )
	{
		return (kEnoughCompletedRemoteWinner);
	}

	if ( player1Points + player2Points > 80 )
	{
		return (kEnoughCompletedTie);
	}

	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct Genesis_NHL95_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} Genesis_NHL95_GameData;

PRIVATE Err
Genesis_NHL95_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
Genesis_NHL95_GameData *nhl95Data = (Genesis_NHL95_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long player1Points;
unsigned long player2Points;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( nhl95Data->dataVersion != kGenesis_NHL95_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif

	/* for now, we'll call an 3 point lead a victory. Otherwise it's a tie if
there */
	/* are more than 9 points scored. */
	/* This logic will need revving once I figure out what quarter it is, etc. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	player1Points = winAnal.pointsFor;
	player2Points = winAnal.pointsAgainst;

	/* Quick sanity check. 100 points would be a lot! */
	if ( ( player1Points > 100 ) || ( player2Points > 100 ) )
	{
		return (kNotEnoughCompletedTie);
	}

	/* 3 point lead or more is a win! */
	if ( player1Points >= player2Points + 3 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( player2Points >= player1Points + 3 )
	{
		return (kEnoughCompletedRemoteWinner);
	}

	if ( player1Points + player2Points > 9 )
	{
		return (kEnoughCompletedTie);
	}

	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct Genesis_Madden95_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} Genesis_Madden95_GameData;

PRIVATE Err
Genesis_Madden95_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
Genesis_Madden95_GameData *madden95Data = (Genesis_Madden95_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long player1Points;
unsigned long player2Points;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( madden95Data->dataVersion != kGenesis_Madden95_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif

	/* for now, we'll call a 10 point lead a victory. Otherwise it's a tie if
there */
	/* are more than 50 points scored. */
	/* This logic will need revving once I figure out what quarter it is, etc. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	player1Points = winAnal.pointsFor;
	player2Points = winAnal.pointsAgainst;

	/* Quick sanity check. 200 points would be a lot! */
	if ( ( player1Points > 200 ) || ( player2Points > 200 ) )
	{
		return (kNotEnoughCompletedTie);
	}

	/* 10 point lead or more is a win! */
	if ( player1Points >= player2Points + 10 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( player2Points >= player1Points + 10 )
	{
		return (kEnoughCompletedRemoteWinner);
	}

	if ( player1Points + player2Points > 50 )
	{
		return (kEnoughCompletedTie);
	}

	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}


#ifdef UNUSED
typedef struct Genesis_FIFASoccer95_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} Genesis_FIFASoccer95_GameData;
#endif

PRIVATE Err
Genesis_FIFASoccer95_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
Genesis_FIFASoccer95_GameData *fifaData = (Genesis_FIFASoccer95_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long player1Points;
unsigned long player2Points;

#ifdef UNUSED           // right now, we don't look at any game-specific data
	if ( fifaData->dataVersion != Genesis_FIFASoccer95_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif

	/* for now, we'll call a 3 point lead a victory. Otherwise it's a tie if there */
	/* are more than 9 points scored. */
	/* This logic will need revving once I figure out what quarter it is, etc. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	player1Points = winAnal.pointsFor;
	player2Points = winAnal.pointsAgainst;

	/* Quick sanity check. 100 points would be a lot! */
	if ( ( player1Points > 100 ) || ( player2Points > 100 ) )
	{
		return (kNotEnoughCompletedTie);
	}

	/* 3 point lead or more is a win! */
	if ( player1Points >= player2Points + 3 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( player2Points >= player1Points + 3 )
	{
		return (kEnoughCompletedRemoteWinner);
	}

	if ( player1Points + player2Points > 9 )
	{
		return (kEnoughCompletedTie);
	}

	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct Genesis_WeaponLord_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} Genesis_WeaponLord_GameData;

PRIVATE Err
Genesis_WeaponLord_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
Genesis_WeaponLord_GameData *weaponLordData = (Genesis_WeaponLord_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long wins;
unsigned long losses;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( weaponLordData->dataVersion != kGenesis_WeaponLord_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif
	
	/* for now, we'll call any matches that are 3-0, 3-1 a win. And we'll call */
	/* matches that are 2-2 a tie. Others are not far enough along. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	wins = winAnal.pointsFor;
	losses = winAnal.pointsAgainst;

	if ( ( wins > 4 ) || ( losses > 4 ) || ( ( wins == 4 ) && ( losses == 4 ) ) )
	{
		// wacky win/loss thing. Bail!
		return (kNotEnoughCompletedTie);
	}
	
	// 4-X is a win! (Probably shouldn't be gameErrors in this case, but who knows?
	if ( wins == 4 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 4 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 3-0, 3-1 is a win!
	if ( wins == 3 && losses < 2 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( losses == 3 && wins < 2 )
	{
		return (kEnoughCompletedRemoteWinner);
	}
	
	// 2-2, 3-3, 3-2 is a tie.
	if ( wins == 3 || losses == 3 || ( ( wins == 2 ) && ( losses == 2 ) ) )
	{
		return (kEnoughCompletedTie);
	}
	
	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct Genesis_NHL96_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} Genesis_NHL96_GameData;

PRIVATE Err
Genesis_NHL96_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
Genesis_NHL96_GameData *nhl96Data = (Genesis_NHL96_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long player1Points;
unsigned long player2Points;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( nhl96Data->dataVersion != kGenesis_NHL96_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif

	/* for now, we'll call an 3 point lead a victory. Otherwise it's a tie if there */
	/* are more than 9 points scored. */
	/* This logic will need revving once I figure out what quarter it is, etc. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	player1Points = winAnal.pointsFor;
	player2Points = winAnal.pointsAgainst;

	/* Quick sanity check. 100 points would be a lot! */
	if ( ( player1Points > 100 ) || ( player2Points > 100 ) )
	{
		return (kNotEnoughCompletedTie);
	}

	/* 3 point lead or more is a win! */
	if ( player1Points >= player2Points + 3 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( player2Points >= player1Points + 3 )
	{
		return (kEnoughCompletedRemoteWinner);
	}

	if ( player1Points + player2Points > 9 )
	{
		return (kEnoughCompletedTie);
	}

	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}

typedef struct Genesis_Madden96_GameData {
	/* I haven't a clue, I'm waiting for the cracker input here! */
	/* For right now, I'm going to ignore this. It would be nice */
	/* to have rounds won (within each match), and damage, too! */
	unsigned short dummy;
} Genesis_Madden96_GameData;

PRIVATE Err
Genesis_Madden96_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
Genesis_Madden96_GameData *madden96Data = (Genesis_Madden96_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long player1Points;
unsigned long player2Points;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( madden96Data->dataVersion != kGenesis_Madden96_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif

	/* for now, we'll call a 10 point lead a victory. Otherwise it's a tie if there */
	/* are more than 50 points scored. */
	/* This logic will need revving once I figure out what quarter it is, etc. */

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	player1Points = winAnal.pointsFor;
	player2Points = winAnal.pointsAgainst;

	/* Quick sanity check. 200 points would be a lot! */
	if ( ( player1Points > 200 ) || ( player2Points > 200 ) )
	{
		return (kNotEnoughCompletedTie);
	}

	/* 10 point lead or more is a win! */
	if ( player1Points >= player2Points + 10 )
	{
		return (kEnoughCompletedLocalWinner);
	}
	if ( player2Points >= player1Points + 10 )
	{
		return (kEnoughCompletedRemoteWinner);
	}

	if ( player1Points + player2Points > 50 )
	{
		return (kEnoughCompletedTie);
	}

	// Everything else is just not sufficient.
	return (kNotEnoughCompletedTie);
}
