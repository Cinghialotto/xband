/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: ServerState.h,v 1.46 1996/01/25 17:51:40 hufft Exp $
 *
 * $Log: ServerState.h,v $
 * Revision 1.46  1996/01/25  17:51:40  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.45  1996/01/16  22:52:21  fadden
 * Added machineBusy.
 *
 * Revision 1.44  1996/01/15  12:22:30  chs
 * Added code to try to prevent people getting stuck in tourney mode:
 * when we put the box in tourney mode, update the boxflags
 * in segad immediately to minimize the window during which a SIGHUP
 * will cause problems.
 * Also added a gConfig flag to force clearing tourney mode in the box.
 *
 * Revision 1.43  1996/01/04  15:14:32  felix
 * Moved definition of DebitCardDBInfo struct into SmartDB.h, which is now
 * included here.
 *
 * Revision 1.42  1995/11/09  17:03:03  jhsia
 * Made some fields in DebitCardDBInfo unsigned so time compares work.
 *
 * Revision 1.41  1995/11/06  02:39:52  felix
 * Added typedef for DebitCardDBInfo struct, as well as *currentCard, *prevCard pointers to it
 *
 * Revision 1.40  1995/10/16  14:29:33  sriram
 * Cleaned up old tourney stuff. Modifications for new tourney format.
 *
 * Revision 1.39  1995/10/12  19:42:12  felix
 * Added *origLastMatchup, to hold the original state of account->lastMatchup
 *
 * Revision 1.38  1995/09/20  10:52:45  chs
 * Added a flag to tells us if this connect is the one where the user
 * made it past the T+C check.
 *
 * Revision 1.37  1995/09/19  23:54:51  fadden
 * Added kCreditChange_Deduct_CompleteEnough.
 *
 * Revision 1.36  1995/08/16  17:05:27  ansell
 * Added matchWins and matchLosses as well as "validFlag" constant so that we
 * can track the total wins/losses in a connect when it is sent up by the box.
 *
 * Revision 1.35  1995/08/07  21:39:59  fadden
 * Added some constants for cord pull stuff.
 *
 * Revision 1.34  1995/07/26  22:53:21  fadden
 * Added magnifyMode.
 *
 * Revision 1.33  1995/07/17  12:31:56  ted
 * Added peerConnects and peerSeconds to ServerState structure.
 *
 * Revision 1.32  1995/07/12  17:28:23  ansell
 * Renamed matchupRegurg to oldMatchupRegurg and added newMatchupRegurg.
 *
 * Revision 1.31  1995/07/11  14:18:46  fadden
 * Added soundOptions to NiftyInfo.
 *
 * Revision 1.30  1995/07/07  20:41:37  fadden
 * Renamed XBANDOptions1 to xbandOptions1 to match MiscPreferences struct.
 *
 * Revision 1.29  1995/06/26  13:27:40  felix
 * Added boxType.
 *
 * Revision 1.28  1995/06/19  20:23:46  fadden
 * Added realHardwareIDtype.
 *
 * Revision 1.27  1995/06/08  11:09:22  ted
 * Added localConnectTime field.
 *
 * Revision 1.26  1995/06/03  19:44:19  fadden
 * Use a struct HardwareID in ServerState instead of the temp struct.
 *
 * Revision 1.25  1995/06/01  15:04:09  fadden
 * Merge in from newbr.
 * -> Added NiftyInfo fields for restore-related things.
 *
 * Revision 1.24  1995/05/26  23:45:58  jhsia
 * switch to rcs keywords
 *
 * Revision 1.23.2.2  1995/05/24  01:17:44  fadden
 * Removed include of Common.h.  Added note about changing hwid around.
 *
 * Revision 1.23.2.1  1995/05/22  03:15:59  fadden
 * Added hidden1 and hidden2 to "any" niftyInfo.
 *
 */

/*
	File:		ServerState.h

	Contains:	The state of a box

	Written by:	Dave Jevans


	Change History (most recent first):

		<53>	12/14/94	SR		added streamErrorReport field.
		<52>	11/30/94	SR		Partial DB update on early connect termination
		<51>	 11/9/94	DJ		Added passwordEraseCodeWasUsed.
		<50>	 11/7/94	SR		added dbitems to news pages
		<49>	10/28/94	ATM		SpecialPhone stuff.  Added specialPhone to state struct.
		<48>	10/24/94	DJ		Added matchup and kServerValidFlag_CheckAccountCredits.
		<47>	10/24/94	DJ		Added kServerValidFlag_CheckAccountCredits.
		<46>	10/20/94	DJ		Added accountCreated, playerCreated, disallowOutgoingMail,
									disallowAllService (this is unused yet).
		<45>	10/20/94	DJ		Added timeOfThisConnect.
		<44>	10/14/94	DJ		Added boxRestored.
		<43>	10/13/94	DJ		Added crashRecord.
		<42>	10/10/94	DJ		added connect800 to track if this is an 800 call
		<41>	 9/26/94	ATM		Added abandonShip.
		<40>	  9/7/94	ATM		Removed extractedPhoneNumber.
		<39>	 8/30/94	ATM		Removed accountChangedMask.
		<38>	 8/25/94	BET		Add support for multiple NetErrorRecord types for both X25 and
									800 services.
		<37>	 8/23/94	DJ		added disallowGameConnect
		<36>	 8/21/94	DJ		state->personificationFlagsEditedByServer
		<35>	 8/21/94	DJ		boxFlags added to boxLogin data
		<34>	 8/20/94	DJ		serverUniqueID added to AddrBookInfo
		<33>	 8/19/94	BET		Make serverState->gameResult a pointer.
		<32>	 8/17/94	DJ		receiveloginversion2
		<31>	 8/13/94	BET		Add state changes for net errors.
		<30>	 8/11/94	DJ		personification change flags
		<29>	 8/10/94	DJ		personifications
		<28>	  8/5/94	DJ		player account stuff
		<27>	  8/5/94	DJ		added servervalidflag_addrbookvalidation
		<26>	  8/4/94	BET		Add personification.
		<25>	  8/4/94	DJ		added gameErrorResult
		<24>	  8/4/94	DJ		no more SNDQElement
		<23>	  8/3/94	DJ		changed the way challenge requests work (sends less data now)
		<22>	  8/2/94	DJ		free token is now in debitcardinfo
		<21>	 7/31/94	DJ		lastBoxState sent with login
		<20>	 7/27/94	DJ		CreditToken is now a long
		<19>	 7/20/94	DJ		removed configstr from serverstate
		<18>	 7/20/94	DJ		game results
		<17>	 7/19/94	DJ		gameName is now just a char*
		<16>	 7/18/94	DJ		smartcard stuff, opponentMagicCookie, etc
		<15>	 7/14/94	DJ		new mail
		<14>	 7/12/94	DJ		supporting new challenge format
		<13>	  7/6/94	DJ		address book validation
		<12>	 6/30/94	DJ		updated to new sendq format
		<11>	 6/15/94	DJ		no phone number in LoginData
		<10>	 6/11/94	DJ		added extractedPhoneNumber which is a cache of the box's phone
									number
		 <9>	 6/10/94	DJ		added ConfigString in server state
		 <8>	  6/9/94	BET		Fix hairy compiles based on TransportSlayer.h
		 <7>	  6/5/94	BET		Forgot to include TransportLayer.h on the checkin merge
		 <6>	  6/5/94	BET		Make it multisession
		 <5>	  6/5/94	DJ		box now sends # of mails in inbox so server won't send more than
									kMaxInBox and overflow its mailQ
		 <4>	  6/4/94	DJ		passing in a sessionrec to ServerState_Init
		 <3>	 5/31/94	DJ		added sdbUser (not used yet)
		 <2>	 5/27/94	DJ		updating to userIdentification struct
	To Do:

	I'll do this as necessary:
		We could set flags in the state and hook in the user and box so we can avoid
		researching for them all the time.

*/

#ifndef __ServerState__
#define __ServerState__

// These are included for type definitions (eg. phoneNumber, DBType, Mail)
//
#include "DataBase_HardwareID.h"

#include "SegaTypes.h"
#include "UsrConfg.h"
#include "DataBase.h"
#include "TransportStructs.h"
#include "SendQ.h"
#include "Mail.h"
#include "SmartCard.h"
#include "Personification.h"
#include "SNESHardwareID.h"
#include "SmartDB.h"

//#include "Common.h"
#include "Common_List.h"


typedef struct LoginData {
	userIdentification	userID;
	short				numMailsInBox;	// box can only have kMaxInBoxEntries mails in inbox.
	short				mailSerialNumbers[kMaxInBoxEntries];
	long				validationToken;
	long				rentalCardSerialNum;
	long				rentalCardPrefix;
	HardwareID			hardwareID;
	char				realHardwareIDtype;		// on sim only
	long				nastyFlags;				// for SNES
} LoginData;


typedef struct SystemVersionData {
	short			length;
	long			version;
} SystemVersionData;


typedef struct QItem {
	long			size;
	unsigned char	*data;
	DBID			theID;
} QItem;


typedef struct SendQData {
	// mail
	// address book entries for validation
	// game results
	// other personification poop

	short			count;
	QItem			*items;
} SendQData;


typedef struct ChallengeData {
	unsigned char		challengeType;
	userIdentification	userID;
} ChallengeData;


typedef struct GameIDData {
	long		gameID;
	long		version;
} GameIDData;


typedef struct AddrValidItem {
	userIdentification	userIdent;
	unsigned char		ownerUserID;
	unsigned char		serverUniqueID;
} AddrValidItem;

typedef struct AddrValidationData {
	short			count;
	AddrValidItem	*items;
} AddrValidationData;


typedef struct MailItem {
	short			size;
	Mail			*mail;
} MailItem;

typedef struct IncomingMail {
	short			count;
	MailItem		*mailItems;
} IncomingMail;

typedef struct BoxOSState {
	long	boxType;
	//long	osState;	// <--- no longer sent after version2 of ReceiveLogin (8/16/94)
	long	lastBoxState;
	
	unsigned long	osFree;
	unsigned long	dbFree;
	
	long	boxFlags;
} BoxOSState;

typedef struct CreditDebitInfo {
	unsigned char			usingType;
	XBANDCard				debitCardInfo;
    short                   currentCredits;
} CreditDebitInfo;

typedef struct SQSaveTuple {
	int					id;
	void				*data;
	int					size;
	struct SQSaveTuple	*next;
} SQSaveTuple;

// Info from the box, either sent up automatically (a la SNES
// DoSendInterestingDBConstants) or requested initially (to be done...)
//
// These should ALL be valid after the initial server login sequence has
// completed (i.e. by the time we get to Server_ValidateLogin).  If it's
// not, don't put it here.
//
// Fields which are SNES-specific are in the "snes" struct, Genesis-specific
// are in the "sega" struct, and generally available stuff is in "any".  The
// alternatives to doing it this way are to use something like validFlags
// (which sucks) or just trusting that nobody will examine values that aren't
// defined for the current platform (which also sucks).
//
typedef struct NiftyInfo {
	struct {
		long	specialModeFlags;			// kSpecialModeFlagsConst
		BoxSerialNumber	hidden1;			// "hidden" serials, set 1
		BoxSerialNumber	hidden2;			// "hidden" serials, set 2
		long	xbandOptions1;				// CW, kbd, etc for all 4 players
	} any;
	struct {
		long	phoneOptions;				// kPhoneOptionsConst
		long	soundOptions;				// kSoundOptionsConst (RRD)
		long	bandwidthVersion;			// kBANDWIDTHVersion
		long	xbandNewsVersion;			// kXBANDNewsVersion
		unsigned char	waitTime;			// GetWaitTime()
		unsigned char	callingArea;		// GetCallingAreaOption()
		unsigned char	dialingPrefix;		// GetBoxPrefix() (==prefix+1)
		unsigned char	callWaitingOption;	// GetCallWaitingOption()
	} snes;
	struct {
		long	foo;						// to be done
	} sega;
} NiftyInfo;

#include	"Server_Comm.h"

typedef struct ServerState {

	unsigned long		connid;				// unique connection id per SunSega instantiation

	CreditDebitInfo		creditDebitInfo;

	BoxOSState			boxOSState;

	//phoneNumber			extractedPhoneNumber;	// 	extracted from the DB at CheckAccount() time

	phoneNumber			boxPhoneNumber;	// this phone number can come from several places:
											//	- ani
											//	- message to change local number.

	char				configBuffer[kConfigStrLength];	// for configuring TListen()

	long				validFlags;

	LoginData			loginData;
	SystemVersionData	systemVersionData;
	
	long				NGPVersion;
	
	SendQData			sendQData;

	AddrValidationData	addrValidationData;

	IncomingMail		incomingMail;

	ChallengeData		challengeData;

	GameIDData			gameIDData;

	GameResult			*gameResult;
	GameResult			gameErrorResult;
	void				*gameErrorDBIDData;
	int					gameErrorDBIDSize;
	SQSaveTuple			*SQSHead;
	
	PersonificationSetupRec	 userPersonification;
	unsigned char		personificationFlags;
	unsigned char		personificationFlagsEditedByServer;	// which fields the server edited (added kustom icon, filtered taunt, etc)

	struct Account		*account;
	
	NetErrorRecord		boxNetErrors800;
	NetErrorRecord		boxNetErrorsX25;

	// the GameTalk connection record.  Union of SessionRec (ADSP) and Stream Socket
	ConnSession	*session;

	short				serverProgress;
	Boolean				disallowGameConnect;		// set to true by ValidateLogin and UpdateGamePatch if unsupported game or no credits or bad restrictions.
	Boolean				abandonShip;				// set to true by ValidateLogin if we want to bail right after we finish reading all the data from the box.
	Boolean				connect800;					// set to true by ValidateLogin if this is a 1-800 connect.
	Boolean				accountCreated;				// set to true by ValidateLogin if new account was created.
	Boolean				playerCreated;				// set to true by ValidateLogin if new player was created.
	Boolean				disallowAllService;			// set to true by CheckAccountCredits if no credits or account not open.
	Boolean				disallowOutgoingMail;		// set to true by GeneralBoxUpdate if Customer Service has disabled mail for this account.

	Boolean				passwordEraseCodeWasUsed;	// set in ProcessSendQ
	Boolean				firstX25Connect;			// if true, last connect was through 1-800
	Boolean				boxPhoneSyncDone;			// if true, box phone was reprogrammed synchronously on first X25 connect.
	Boolean				commitSmartCardChanges;		// if true, the mail and game results from the box have been cleared, so we can update smartcard db.
	Boolean				updateDatabaseDone;			// set after Server_UpdateDataBaseAccount updates the DB

	struct BoxRestartInfo	*crashRecord;
	Boolean				boxRestored;			// set to true if box was restored (Server_RestoreBox)

	unsigned long		timeOfThisConnect;		// set in ValidateLogin.  Used by other routines to know the time.  Avoids calling time() everywhere.
	unsigned long		localConnectTime;		// set in ValidateLogin.  Local time of caller (adjusted for time zone and daylight savings)

	struct Matchup		*matchup;

	ListHead			*specialPhone;			// special phone numbers

	ListHead			*animations;			// List of animations sent to the box.
	unsigned char		*streamErrorReport;		// debugging stuff the box uploads for sighups
	struct MatchupRegurg	*oldMatchupRegurg;		// prev match from sendQ
	struct MatchupRegurg	*newMatchupRegurg;		// fed to box after match

	unsigned long		creditChangeFlags;		// deductions and refunds (for logging)
	long				platformID;				// kind of box we're talking to

	struct TourneyData	*tourneyData;
	struct TourneyResult	*tourneyResult;	

	char				carriercode[16];	// secret code used for toll call for matchup
	char				carrierphone[11];	// carrier's phone number (usually 800#)


	NiftyInfo			niftyInfo;

	unsigned long		boxType;		// i.e. sn07 (use boxOSState.boxType!)
	
	short				peerConnects;			// # connects in last peer session
	long				peerSeconds;			// # seconds in last peer session
	Boolean				magnifyMode;			// look for de bug
	long				matchWins;				// Total wins/losses 
	long				matchLosses;			//  during a matchup.
	long			firstRealConnect;	/* is this the first time we made it past the T+C checks? */
	long				origBoxFlags;	/* copy of boxAccount.boxFlags at beginning of connection */

    struct LastMatchup	*origLastMatchup;  // original state of account->lastMatchup 

	DebitCardDBInfo		*currentCard;	// Info about debit card currently installed
	DebitCardDBInfo		*prevCard;		// Info about debit card used on last connect
	Boolean				machineBusy;	// if set, machine is too busy
} ServerState;


//
// These flags let us track what's been sent to the server from the box
//
#define kServerValidFlag_None				0
#define kServerValidFlag_Login				1L
#define kServerValidFlag_SystemVersion		(1L<<1)
#define kServerValidFlag_NGPVersion			(1L<<2)
#define kServerValidFlag_SendQ				(1L<<3)
#define kServerValidFlag_ChallengeOrCompete	(1L<<4)
#define kServerValidFlag_GameID				(1L<<5)
#define kServerValidFlag_SessionRec			(1L<<6)
#define kServerValidFlag_ConfigString		(1L<<8)
#define kServerValidFlag_BoxPhoneNumber		(1L<<9)
//#define kServerValidFlag_ExtractedPhoneNumber		(1L<<10)
#define kServerValidFlag_AddrValidation		(1L<<11)
#define kServerValidFlag_IncomingMail		(1L<<12)
#define kServerValidFlag_CreditDebitInfo	(1L<<13)
#define kServerValidFlag_BoxType			(1L<<14)
#define kServerValidFlag_GameResults		(1L<<15)
#define kServerValidFlag_GameErrorResults	(1L<<16)
#define kServerValidFlag_AddressBook		(1L<<17)
#define kServerValidFlag_Account			(1L<<18)
#define kServerValidFlag_Personifications	(1L<<19)
#define kServerValidFlag_NetErrors800		(1L<<20)
#define kServerValidFlag_NetErrorsX25		(1L<<21)
#define kServerValidFlag_TimeOfThisConnect	(1L<<22)
#define kServerValidFlag_CheckAccountCredits	(1L<<23)
#define kServerValidFlag_platformID			(1L<<24)
#define kServerValidFlag_WinsLosses			(1L<<25)
#define kServerValidFlag_TourneyResult			(1L<<26)


//
// These are set in Server_GameResults.c; they explain why credits were
// deducted, penalized, or refunded.
//
// There are several cases where a different player gets a refund based on
// what the current player did.  These never cause a flag to get set, so
// just watching these flags isn't sufficient if you're trying to track the
// long-term progress of credits.
//
// There is one case where a deduction can occur that won't appear here:
// if the current user detected that his opponent was using a FAX machine,
// a credit will be deducted from the other guy's account, but one of these
// flags won't get set the next time he logs in.  Insignificant.
//
// kCreditChange_Deduct_* flags are set when a credit is deducted for normal
// reasons (e.g. a successful game was played or a mail-only connect was
// done).  kCreditChange_Penalize_* flags are set for exceptional conditions,
// where we penalize an additional credit from the box beyond the normal
// deduction (usually because the guy did something nasty like hit reset).
//
// (There aren't any kCreditChange_Refund_* flags defined, because at
// present we never refund credits to the current box.)
//
#define kCreditChange_Deduct_SuccessfulGame	(1L)
#define kCreditChange_Deduct_OnQueue		(1L<<1)
#define kCreditChange_Deduct_EvilReset		(1L<<2)
#define kCreditChange_Deduct_EvilCW			(1L<<3)
#define kCreditChange_Deduct_WaitReset		(1L<<4)
#define kCreditChange_Deduct_MailOnly		(1L<<5)
#define kCreditChange_Deduct_HosedSpecific	(1L<<6)
#define kCreditChange_Deduct_HosedAuto		(1L<<7)
#define kCreditChange_Deduct_CordPull		(1L<<8)
#define kCreditChange_Deduct_CompleteEnough	(1L<<9)
#define kCreditChange_Penalize_WaitReset	(1L<<16)
#define kCreditChange_Penalize_EvilReset	(1L<<17)
#define kCreditChange_Penalize_PasswordCode	(1L<<18)
#define kCreditChange_Penalize_CordPull		(1L<<19)


//
// Routines.
//
void ServerState_Init(ServerState *state, SessionType type, ConnSession *session, char *configString );
void ServerState_Print(ServerState *state);
void ServerState_PrintUserIdentification(const userIdentification *userID);
void ServerState_Empty(ServerState *state);

#endif __ServerState__

