/*
 * Catapult Entertainment, Inc.
 *
 * $Id: Server_StartGamePlay.c,v 1.107 1996/03/07 19:49:52 roxon Exp $
 *
 * $Log: Server_StartGamePlay.c,v $
 * Revision 1.107  1996/03/07 19:49:52  roxon
 * Restriction time applies to SJNE, too.
 *
 * Revision 1.106  1996/02/20  19:30:36  roxon
 * Use gConfig.weekendDay1 and gConfig.weekendDay2 to check play time
 * restriction instead of hardcoded Friday and Saturday.
 *
 * Revision 1.105  1996/02/13  20:28:25  fadden
 * Declare some read-only tables and their pointers as "const".
 *
 * Revision 1.104  1996/01/25  17:52:01  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.103  1996/01/15  12:22:34  chs
 * Added code to try to prevent people getting stuck in tourney mode:
 * when we put the box in tourney mode, update the boxflags
 * in segad immediately to minimize the window during which a SIGHUP
 * will cause problems.
 * Also added a gConfig flag to force clearing tourney mode in the box.
 *
 * Revision 1.102  1995/12/11  23:11:49  chs
 * In SEtourneys, always set waitTime to long.
 *
 * Revision 1.101  1995/12/07  22:06:07  chs
 * Call Server_TourneyRedirectChallenge earlier in
 * Server_StartGamePlay() and set the freexbn flag if needed
 * (instead of duplicating the effect of that flag elsewhere).
 *
 * Revision 1.100  1995/12/05  16:33:29  chs
 * Only store the matchup in the tourney blob if a tourney is running.
 *
 * Revision 1.99  1995/12/04  18:15:39  fadden
 * Use DISPLAY_LOCALE macro to send "Opponent" (C) or "Diailing Opponent" (ja).
 *
 * Revision 1.98  1995/12/04  16:33:50  chs
 * Added support for specific-match (currently single-elimination) tourneys.
 *
 * Revision 1.97  1995/11/09  12:56:02  ted
 * For wildcard matches (kSpecialLookLongFirst set), force ignore challenges too.
 *
 * Revision 1.96  1995/11/02  13:11:47  chs
 * Use the new flag in the lastMatchup info to distinguish slaves timing-out
 * from peer-connect failures.
 *
 * Revision 1.95  1995/11/01  10:29:13  chs
 * Split tourney "debug" flag into "nomatcher" and "nogamepatch" flags,
 * to allow selective disabling of the various pieces of a tourney.
 *
 * Revision 1.94  1995/10/16  14:29:42  sriram
 * Cleaned up old tourney stuff. Modifications for new tourney format.
 *
 * Revision 1.93  1995/10/11  09:35:28  ted
 * Replaced lost revision headers 1.86 through 1.90.
 *
 * Revision 1.92  1995/10/10  10:35:43  ted
 * Added code for testing tourney/matcher (triggered only by SpecialPhone).
 *
 * Revision 1.91  1995/10/03  17:12:16  ted
 * Check for XBN below monthly cap.
 *
 * Revision 1.90  1995/09/29  18:17:44  ted
 * Fixed Common_PhoneHasNPA test in Server_AreWeXBNCallable that caused people not
 * to be callable on XBN!!!!!!!!!
 *
 * Revision 1.89  1995/09/27  18:38:16  hufft
 * added Common_Phone support for Japan Server
 *
 * Revision 1.88  1995/09/24  16:42:30  fadden
 * Changed InvalidChallenge to trap specific-match requests as well.
 *
 * Revision 1.87  1995/09/18  21:18:05  ansell
 * Moved code to set the box's lastMatchup modified flag outside of Ted's
 * ifdef.
 *
 * Revision 1.86  1995/09/18  16:32:44  fadden
 * Added a comment to the invalid challenge stuff.
 *
 * Revision 1.85  1995/09/17  21:52:28  fadden
 * Added Server_CheckInvalidChallenge and Server_GameAccessAllowed.
 *
 * Revision 1.84  1995/09/13  14:24:46  ted
 * Fixed warnings.
 *
 * Revision 1.83  1995/09/05  17:24:04  ansell
 * Added checks for whether the player being told to wait is XBN callable and
 * if the player dialing is calling via XBN.
 *
 * Revision 1.82  1995/08/29  23:07:23  fadden
 * Add boxIDs to unknown game reject message.
 *
 * Revision 1.81  1995/08/27  18:52:54  fadden
 * Added support for kGIFlagVIPAndGameTester.
 *
 * Revision 1.80  1995/08/24  19:27:49  rich
 * Server_StartGamePlay(): no time restrictions in Japan.
 *
 * Revision 1.79  1995/08/24  11:29:16  ted
 * Observe new kBoxFlag_DisableXBN flag.
 *
 * Revision 1.78  1995/08/21  11:31:37  ted
 * Read MCI phone and id code from MCIFile now instead of server.conf.
 *
 * Revision 1.77  1995/08/10  14:13:18  fadden
 * Tweaked a logmsg.
 *
 * Revision 1.76  1995/07/31  21:26:15  fadden
 * Tweaked a logmsg.  Added an exception so we don't try to dock credits
 * from people trying to challenge with an unsupported game on SNES.
 *
 * Revision 1.75  1995/07/26  18:56:38  steveb
 * Added the platform type to the mail-only connect status message.
 *
 * Revision 1.74  1995/07/26  14:01:55  ansell
 * Renamed failedServerConnects to totalServerConnects.
 *
 * Revision 1.73  1995/07/21  16:58:34  ted
 * Call Server_ResetXBNFreebieCount when user reregisteres or a warning is returned.
 * Clear contestant struct very first thing in Server_StartGamePlay().
 *
 * Revision 1.72  1995/07/20  16:21:28  ted
 * Removed #if 0..#endif Server_snes_CheckXBNFreebie.
 *
 * Revision 1.71  1995/07/20  13:54:06  ted
 * Add Server_AreWeXBNCallable() which scans boxAccount.mciPhoneList to see
 * if the box's current gamePhone is present to determine whether or not the
 * player can be called on XBAND Nationwide or not.
 *
 * Revision 1.70  1995/07/17  18:38:52  fadden
 * LRA: changed some logmsgs to LOGP_DETAIL.
 *
 * Revision 1.69  1995/07/17  12:31:10  ted
 * Removed gameID from contestant structure to reduce its size. Pass box preferred
 * wait time to matchers. Use gettext on free xbn dialog.
 *
 * Revision 1.68  1995/07/12  20:23:32  fadden
 * Removed #define STUPID.
 *
 * Revision 1.67  1995/07/11  22:41:48  fadden
 * Fixed "no such player" dialog.
 *
 * Revision 1.66  1995/07/10  21:10:25  rich
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.65  1995/07/10  20:44:25  fadden
 * Changed AutoToAuto dialog to be nastier (per KON's request).
 *
 * Revision 1.64  1995/07/10  10:44:53  ted
 * Call Server_ResetXBNFreebieCount when box dials out.
 *
 * Revision 1.63  1995/07/06  20:01:24  ted
 * Only allow awards for the first week after first connect to network. Also
 * prevent vips and Free XBN'ers from getting awards.
 *
 * Revision 1.62  1995/07/04  22:53:18  fadden
 * Added some comments about game patch version stuff.
 *
 * Revision 1.61  1995/06/29  17:22:47  ted
 * Separated check for free game from increment of challenge request.
 *
 * Revision 1.60  1995/06/28  17:02:52  ted
 * Final logic added/tested for awarding free long distance matches for snes players.
 *
 * Revision 1.57  1995/06/23  17:03:22  ted
 * Added "t" after dialing MCI so pulse modems can play over XBN.
 *
 * Revision 1.56  1995/06/22  23:05:49  fadden
 * Don't show blank string for nonexistent player
 *
 * Revision 1.55  1995/06/19  20:44:27  fadden
 * Changed GetHiddenSerials to SyncWithBox.  Added calls to enable/disable
 * auto-stat-update on SNES.
 *
 * Revision 1.54  1995/06/19  17:46:06  ted
 * Added Server_snes_CheckXBNFreebie. Defaults to off.
 *
 * Revision 1.53  1995/06/08  11:12:13  ted
 * Use state->localConnectTime now for checking restrictions.
 *
 * Revision 1.52  1995/06/03  14:40:43  ted
 * Fixed XBN billing bug.
 *
 * Revision 1.51  1995/06/02  20:56:39  fadden
 * Use the actual random value instead of TEMP_RANDOM.
 *
 * Revision 1.50  1995/05/24  15:14:43  ted
 * Fixed bug with generating ID code for MCI.
 *
 * Revision 1.49  1995/05/23  16:38:34  ted
 * XBAND Nationwide. Simplify dial code.
 *
 * Revision 1.48  1995/05/16  17:14:54  ted
 * Added 6 new area codes for time-zone restrictions.
 *
 * Revision 1.47  1995/05/12  01:10:40  fadden
 * Make unknown matcher return value a LOGP_FLAW instead of a LOGP_NOTICE.
 *
 */
//#define TESTING_CALLING_CARD	// use calling cards or MCI for local calls, too

/*
	File:		Server_StartGamePlay.c

	Contains:	Asks the Matcher to find an opponent for the box.

	Written by:	David Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

	   <120>	12/16/94	ATM		Implemented Server_GetGameIDAndPatchVersion, but left it
									#ifdefed out because it nukes anything that doesn't get a system
									patch (like simulators).
	   <119>	12/14/94	HEC		Pass down commands from XBAND.MATCHER xmail.
	   <118>	12/13/94	ATM		Print xpoints unsigned.  For first 10 server connects, don't hit
									them for a credit if they log in with an unsupported cartridge.
	   <117>	 12/6/94	HEC		Display :LD: for long distance players. Rewording of specific
									match failure dialogs.
	   <116>	 12/5/94	ATM		Changed a printf to a Logmsg, and added more info to Logmsgs for
									restrictions.
	   <115>	11/29/94	HEC		Pass down kREALPlayerFlag to matcher.
	   <114>	11/28/94	HEC		Why did Ted not enter area codes 201-219?
	   <113>	11/27/94	ATM		Now check kSpecialLongDistance flag here.
	   <112>	11/27/94	ATM		Use kSpecialShortWait flag to keep wait times down.
	   <111>	11/26/94	ATM		Eject queued people doing a challenge request.  Don't recredit
									if they try during restricted hours.
	   <110>	11/20/94	ATM		If box serial # > 3000, print ":REAL:" if the guy is waiting.
	   <109>	11/19/94	HEC		Send down new player flag to matcher.
	   <108>	11/17/94	ATM		Turned a logmsg back on.
	   <107>	11/17/94	KD		wordsmithed some dialogs (doug/kon).
	   <106>	11/17/94	HEC		Fixed time zone stuff in check restrictions.
	   <105>	11/17/94	KD		Update server dialog text (doug/kon).
	   <104>	11/16/94	HEC		Fixed typo.
	   <103>	11/16/94	ATM		Fixed the worth string stuff.
	   <102>	11/16/94	HEC		Time zone restrictions.  Catapult phones wait short time like
									VIPs.
	   <101>	11/16/94	ATM		Send the correct worth string.
	   <100>	11/15/94	HEC		Changed tiny nit displaying time as mm:ss instead of XmYs for
									Andy1.
		<99>	11/14/94	HEC		Lower VIP wait time.  Display wait time for all slaves in
									statuslog.
		<98>	11/14/94	ATM		Added Server_DequeuePlayer.
		<97>	11/13/94	ATM		Make phone numbers pretty so that the log file can still be
									parsed.
		<96>	11/13/94	ATM		Server_IsPlayerOnQueue should work correctly now.
		<95>	11/11/94	ATM		Minor rearranging.  Set state->disallowGameConnect if the game
									is known but restricted, so that their credit doesn't get
									refunded.  (hmm)
		<94>	 11/9/94	DJ		Renamed some DB routines to DataBaseUtil_ and also to WrapperDB_
									(for Oracle).
		<93>	 11/9/94	ATM		Changed def of Server_SendWorthString.  Added
									Server_SendGameOverString.
		<92>	 11/7/94	HEC		Include DataBase_Match.h
		<91>	 11/7/94	HEC		Print out specific challenger info.
		<90>	 11/5/94	HEC		Send duration of wait time to box, not absolute time.
		<89>	 11/5/94	HEC		Send slave timeout from matcher instead of constant.
		<88>	 11/3/94	ATM		Added printing of "::VIP::" for VIP testers.
		<87>	 11/2/94	ATM		Added Server_IsPlayerOnQueue.
		<86>	10/28/94	ATM		Allow access to early versions of games for certain people.
		<85>	10/26/94	DJ		Added ability to dial longdistance for playerlist only and also
									the temporaryLongDistance flag (used if a market has too few
									people.  server will automatically turn it off for people when
									each given market gets big enuf).
		<84>	10/26/94	ATM		Support for single-game matching.  Changed slaveExpireWhen to
									lastSlaveInfo struct.  Unfinished work on reregister detection.
		<83>	10/25/94	ATM		Support for slaveExpireWhen and LastMatchup's when.
		<82>	10/25/94	ATM		Removed MPW output that ended up in the file.
		<81>	10/24/94	DJ		Added matchup to state.
		<80>	10/22/94	ATM		Let Server_SendDialog() do the log messages.
		<79>	10/20/94	ATM		Added log messages for re-registers.
		<78>	10/20/94	DJ		Added "dialog" in caps comment on same line as server dialogs
									(useful for greping).
		<77>	10/20/94	ATM		Remove restriction on DA BOYZZZ.
		<76>	10/19/94	ATM		Copy oppUserName into LastMatchup.
		<75>	10/17/94	ATM		Removed the logmsg about box reset, and changed the told-to-call
									message for when the slave requested a specific match.
		<74>	10/17/94	DJ		Added Server_CheckRestrictions to actually implement
									restrictions.
		<73>	10/17/94	ATM		Added slime to keep DA BOYZZZ off.
		<72>	10/14/94	ATM		Changed DataBase_GetGameName to Common_AliasedGameName.
		<71>	10/14/94	DJ		Added call to GetHIddenSerials which will essentially
									synchronize the box with the server prior to calling the
									matcher.
		<70>	10/14/94	ATM		Changed a DataBase_GetGameName to Common_GameName.
		<69>	10/14/94	ATM		Added Server_SendSpecificToAuto.
		<68>	10/14/94	ATM		Added magic incantation to tell the box that we've converted a
									challenge request into an auto-match request.
		<67>	10/11/94	ATM		Set kLastMaster (where'd that go??)
		<66>	10/11/94	ATM		Use NewGameResult to show errors.
		<65>	10/10/94	ATM		Added RankingInfo to Contestant and Matchup (replaces rating).
		<64>	 10/7/94	DJ		tracking the various kinds of connections (eg.
									challengeConnects, msgCheckConnects, etc) in playerAccount
		<63>	 10/7/94	ATM		Print a logmsg for challenge on nonexistent user.
		<62>	 10/7/94	ATM		Pass PreviousOpponent array into Contestant.  Update for new
									LastMatched.
		<61>	 10/6/94	ATM		Watch for matchup->warning, kLeaveOnQueue, and
									kOpponentIsDialing.  Added StatusPrintWarning.
		<60>	 10/6/94	ATM		Don't send last opponent if the lastMatched player wasn't the
									current player.
		<59>	 10/5/94	ATM		Added "player" to PlayerAccount and LastMatched.  Moved
									LastMatched into BoxAccount.
		<58>	 10/4/94	ATM		Change statuslog message for specificShunt.
		<57>	 10/3/94	ATM		Use oppSpecific.  Fixed various bugs, mostly in the "don't match
									against previous opponent" stuff.
		<56>	 10/2/94	ATM		Pass previous opponent in.  Set wasSpecific flag.  Now call
									SendWorthString.
		<55>	 10/1/94	ATM		Implemented lastMatchup field.  Use updated RankingInfo and
									Contestant structs.
		<54>	 9/30/94	ATM		Changed romID to gamePatchVersion.  Added a flawed way of
									getting the patch version.
		<53>	 9/26/94	ATM		Converted debugN to debug[N].
		<52>	 9/23/94	DJ		area restrictions are now in restrictArea not boxFlags
		<51>	 9/21/94	ATM		Use #define for kBA_debug_dial9.
		<50>	 9/19/94	ATM		PLogmsg stuff.
		<49>	 9/18/94	ATM		Server_GameName becomes Common_GameName.
		<48>	 9/16/94	ATM		Added "9," hack based on debug1.
		<47>	 9/16/94	ATM		Send the "long distance okay" flag to the matcher.
		<46>	 9/12/94	ATM		Tweaked the log messages.
		<45>	 9/10/94	ATM		Tweaked a dialog to handle an unusual condition.
		<44>	  9/7/94	ATM		Moved the "Mail-only connect" statusmsg in here.
		<43>	  9/7/94	ATM		Add dialogs for some unusual cases.
		<42>	  9/6/94	ATM		Complete overhaul of matching system.
		<41>	 8/29/94	ATM		Don't send blank string as opponent phone number.  Nuked
									extractedPhoneNumber use.
		<40>	 8/25/94	ATM		Don't allow player to challenge someone on his own box.
									(Prohibited by address book, but let's be thorough.)
		<39>	 8/25/94	ATM		Added "your ROMs don't match" message.
		<38>	 8/25/94	ATM		Added StatusPrintGameResults.
		<37>	 8/23/94	DJ		added state->disallowGameConnect
		<36>	 8/22/94	DJ		groomed dialog text
		<35>	 8/22/94	ATM		De-CHEEZEd.
		<34>	 8/21/94	BET		Add dummy opponent name string to send to box until we get the
									database hacked up to send it back.
		<33>	 8/20/94	BET		Added calls to Server_SendOpponentNameString.
		<32>	 8/19/94	BET		serverState->gameResult is now a pointer, fix up
									Server_StartGamePlay to do the right thing.
		<31>	 8/19/94	ATM		Fixed game result printing.
		<30>	 8/18/94	DJ		smarter messages for challenges
		<29>	 8/18/94	ATM		Show challenge connects.
		<28>	 8/17/94	ATM		Added printing of game results per request.
		<27>	 8/13/94	ATM		Added separate Statusmsg for challenges.
		<26>	 8/13/94	ATM		Fixed it.
		<25>	 8/13/94	ATM		Added a sanity check on the phone number length.
		<24>	 8/13/94	ATM		Changed extractedPhoneNumber to boxPhoneNumber; trying to avoid
									"blank phone number" syndrome.
		<23>	 8/12/94	ATM		Updated Statusmsg calls to use Server_GameName.
		<22>	 8/12/94	ATM		Added Statusmsg calls.
		<21>	 8/11/94	ATM		Converted to Logmsg.
		<20>	 8/10/94	DJ		mpw sucks
		<18>	 8/10/94	ATM		Changed "find opponent" calls to include boxPhoneNumber as well
									(for area code munging).
		<17>	  8/9/94	ATM		Cope with area codes.
		<16>	  8/8/94	DJ		SendDialog takes boolean whether to stick or disappear in 3 sec.
		<15>	 7/26/94	DJ		nuthin honey
		<14>	 7/25/94	DJ		5 days of hacking, including: added support for challenges
		<13>	 7/20/94	DJ		no ServerState passed to dbase routines
		<12>	 7/19/94	DJ		gameName is now just a char*
		<11>	 7/18/94	DJ		added opponentVerificationTag (magicCookie)
		<10>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		 <9>	 7/15/94	DJ		made mail-only connects work
		 <8>	 7/14/94	DJ		added 1min timeout for kon
		 <7>	 7/13/94	DJ		added Server_SendRegisterPlayer
		 <6>	 7/12/94	DJ		getting ready for mail-only connections
		 <5>	  7/8/94	DJ		printfs for testing
		 <4>	  7/1/94	DJ		making server handle errors in Comm layer
		 <3>	 6/12/94	DJ		seems to work well.
		 <2>	 6/11/94	DJ		made this real at the same time as making the dbase for games
									real
		 <1>	 5/27/94	DJ		first checked in

	To Do:
*/
#include <unistd.h>
#include <memory.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/types.h>
#include <sys/time.h>

#include "ServerCore.h"
#include "Server.h"
#include "ServerState.h"
#include "ServerDataBase.h"
#include "Server_Tournament.h"
#include "Server_Rankings.h"
#include "OpaqueStoreKeys.h"
#include "Common_OpaqueStore.h"

#include "Common.h"
#include "Common_ReadConf.h"
#include "Common_Missing.h"

#include "Challnge.h"
#include "DataBase_Match.h"
#include "DBConstants.h"



//Turn this off since marketing and customer service wants vips to chat & play again
#define ENABLE_VIP_BOX_MODE 1

//
// Local prototypes.
//
Err SetLastMatchup(ServerState *state, Matchup *matchup, RankingInfo *myRankingInfo);
void StatusPrintWarning(ServerState *state, Matchup *matchup);
Err Server_SendClearNetOpponent(ServerState *state);
Err Server_GetGameIDAndPatchVersion(ServerState *state, long *gameID, long *patchVersion);
Err Server_SetVIPBoxMode(ServerState *state);
long Server_snes_CheckXBNFreebie(ServerState *state);
void Server_snes_BumpRegisterCount(ServerState *state);
static Boolean Server_CheckRestrictions(ServerState *state,
	struct Restriction *weekdayRestrict, struct Restriction *weekendRestrict);
Boolean Server_FormatCallingCard(char *, char *, char *);
PRIVATE Boolean Server_GameAccessAllowed(ServerState *state);
PRIVATE Err Server_UpdateBoxFlags(ServerState *, Boolean);


// Number of times you can connect to the server before we start penalizing
// you credits for connecting with a game we don't support.
//
#define kMaxConnWithBogusGame	10



// ===========================================================================
//		Entry point
// ===========================================================================

//
// Do all the pre- and post-work involved in getting a match.
//
// We still want to call this for mail-only connects, to make sure people
// get dequeued and to print messages to the statuslog.
//
int Server_StartGamePlay(ServerState *state)
{
	ContestantInput contestant;
	userIdentification challengeUserID;
	RankingInfo *rankingInfo;
	const GameInfo *gameInfo;
	Err err;
	char msg[256];
	int i;
	phoneNumber prettyPhone;
	Mail *mail;
	long special;
	long freexbn;
	long boxFlags;
	long restrictArea;
	long creditapproved;
	long can_receive_xbn = 0;
	long vip;
	long preferLong;
	long freexbnDialog = 0;
	long matcherGameID;
	long xbndisabled;
	long xbnbelowcap;
	Boolean tourney_redirect = false;
	
	PLogmsg(LOGP_PROGRESS, "Server_StartGamePlay\n");

	ASSERT((state->validFlags & kServerValidFlag_Account));
	ASSERT((state->validFlags & kServerValidFlag_ChallengeOrCompete));
	memset(&contestant, 0, sizeof(contestant));

	matcherGameID = state->gameIDData.gameID;
	special = Server_GetSpecialPhone(state);
	restrictArea = state->account->boxAccount.restrictArea;
	boxFlags = state->account->boxAccount.boxFlags;
	creditapproved = (boxFlags & kBoxFlag_CreditApproved) != 0;
	vip = ((special & kSpecialVIPTester) || (boxFlags & kBoxFlag_VIP)) != 0;
	freexbn = (boxFlags & kBoxFlag_FreeXBN) || vip;
	preferLong = !(restrictArea & kRestrictArea_dialLocalPreferred);
	xbndisabled = (state->account->boxAccount.boxFlags & kBoxFlag_DisableXBN) != 0;
	Common_PhoneFormatDisplay(state->account->boxAccount.gamePhone.phoneNumber,
		prettyPhone.phoneNumber);

	// See if we're already on a queue.  If so, we need to tell the
	// appropriate matching process to nuke us.
	//
	// We're getting a copy of the LastMatched structure when we log in.
	// However, it could've been updated by a master as we're dialing.  In
	// such a case, we will think he's calling in before being expired,
	// even though the real truth is he's a double-fucker and is calling in
	// when somebody is calling him.
	//
	// Either way he loses a credit, and the matcher should catch it if
	// he's calling in for the same game.
	//
	if (Server_IsPlayerOnQueue(state)) {
		LastSlaveInfo *lsip = &state->account->boxAccount.lastSlaveInfo;

		Logmsg("Player is still on queue for 0x%.8lx, id %ld (%ld left)\n",
			lsip->gameID, lsip->contestantID, lsip->slaveExpireWhen - time(0));

		// Always reset timeout count when creep registers...
		Server_ResetXBNFreebieCount(state);

		// Do something useful.
		//
		// If this is a specific challenge request, there are a number of
		// ways he can fail that leave him not on a queue.  Fix that by
		// ejecting him now.
		//
		if (state->challengeData.userID.box.box !=
			kFindNetworkOpponentSerialNumber)
		{
			Server_DequeuePlayer(state,
				state->account->boxAccount.lastSlaveInfo.gameID);
		}
	}
	else if (state->challengeData.userID.box.box == kFindNetworkOpponentSerialNumber)
	{
		// auto match, snes... only if not already on the queue
		if (state->platformID == kPlatformSNES)
		{
			if (Server_snes_CheckXBNFreebie(state))
			{
				preferLong = 1; 				// force long match for prize winner
				freexbn = 1;					// make sure it's free!
				freexbnDialog = 1;				// flag to send dialog later
				contestant.flags |= kForceSlave;
			}
		}
	}

	// Init LastSlaveInfo, so if we don't become a slave (for whatever reason)
	// all the fields are zeroed out.
	//
	memset(&state->account->boxAccount.lastSlaveInfo, 0, sizeof(LastSlaveInfo));
	state->account->boxModified |= kBA_lastSlaveInfo;

	/*
	 * Single-elimination tourney stuff.
	 */
	if (Server_TourneyDisallowMatch(state)) {
		PLogmsg(LOGP_NOTICE,
				"Server_StartGamePlay: not matching SEtourney contestant\n");
		return kServerFuncOK;
	}
	if (state->tourneyData &&
		state->tourneyData->type == kTourneySpecificMatch)
	{
		tourney_redirect = Server_TourneyRedirectChallenge(state);
		if (tourney_redirect) {
			freexbn = 1;
		}
		PLogmsg(LOGP_DETAIL, "Server_StartGamePlay: %sredirecting challenge\n",
					tourney_redirect ? "" : "not ");
	}


	if(state->challengeData.userID.box.box == kDownloadOnlyMailSerialNumber)
	{
		Statusmsg("SunSega: '%.4s' Mail-only connect from '%s' (%s)\n",
			(char *)&state->platformID,
			state->loginData.userID.userName, 
			prettyPhone.phoneNumber);
		StatusPrintGameResults(state);

		state->account->playerAccount.msgCheckConnects++;
		state->account->playerModified |= kPA_msgCheckConnects;

		return(kServerFuncOK);
	}

	if(state->disallowGameConnect) {
		PLogmsg(LOGP_NOTICE, "REJECT: Game connect is disallowed.\n");
		return(kServerFuncOK);
	}

	xbnbelowcap = preferLong ? Server_XNU_IsBelowCap(state) : 0;

		//
		// Check restrictions to see if you are allowed play.
		//
		if(!Server_CheckRestrictions(state, &state->account->boxAccount.restrictInfo[0], &state->account->boxAccount.restrictInfo[1]))
		{
		
			// I18N Appears:  When player tries to connect to XBAND outside 
			//           of his allowed times.
			// Solution: Player should connect to XBAND only during 
			//           the times that he or she is not restricted.  Player could also 
			//           use the IVR to change their restrictions times.
			//
			Server_SendDialog(state, gettext("Sorry, you tried to connect to XBAND during restricted hours.  Check Account Info under Options to see the restrictions that apply to your account."),	/* DIALOG */
				true);
			state->disallowGameConnect = true;	// don't refund credit next time
			return (kServerFuncOK);
		}

	//
	// We won't register the box with the matcher until
	// we know the box has processed everything sent
	// to it prior to this point.
	//
	err = Server_SyncWithBox(state);
	if(err != kServerFuncOK)
		return(err);

#ifdef DONT_USE_YET
// someday, replace the above worthless junk with the thing below
	{
		long gameID=-1, patchVersion=-1;

		Server_GetGameIDAndPatchVersion(state, &gameID, &patchVersion);
		Logmsg("In SGP, box has gameID=0x%.8lx, patchVersion=%ld\n");
	}
#endif


	if ((gameInfo = Common_GameInfoForGame(state->platformID,
			state->gameIDData.gameID)) == NULL)
	{
		Logmsg("REJECT: Unknown gameID %.4s-0x%.8lx on box (%ld,%ld)\n",
			(char *)&state->platformID, state->gameIDData.gameID,
			state->loginData.userID.box.box,
			state->loginData.userID.box.region);

		// 950731: special exception for SNES, which seems to be reporting
		// strange gameID values with some frequency.  Hopefully they'll get
		// the SNES straightened out and we can remove this.
		//
		if (state->platformID == kPlatformSNES) {
			Server_SendDialog(state,
				gettext("Sorry, this game is not available. Please try another."),	/* DIALOG */
				true);
		} else
		if (state->account->boxAccount.totalServerConnects < kMaxConnWithBogusGame)
		{
			// I18N Appears:  When player tries to connect to XBAND with a 
			//           game that is not supported on the XBAND Network.
			// Solution: Connect with a game that is supported on 
			//           XBAND (eg. Mortal Kombat, NBA Jam, Madden Football, etc).
			//
			Server_SendDialog(state, gettext("This game is not yet supported on XBAND.  Connecting with it will soon cost you credits."), true);	/* DIALOG */
		} else {
			state->disallowGameConnect = true;	// don't refund credit next time
			// I18N Appears:  When player tries to connect to XBAND with a 
			//           game that is not supported on the XBAND Network.
			// Solution: Connect with a game that is supported on 
			//           XBAND (eg. Mortal Kombat, NBA Jam, Madden Football, 
			//           etc).  After connecting 10 times with an unsupported 
			//           game, XBAND will start charging the player a credit each 
			//           time he or she logs in with an unsupported game.
			//
			Server_SendDialog(state, gettext("This game is not yet supported on XBAND.  You have been charged a credit."), true);	/* DIALOG */
		}
		return (kServerFuncOK);
	}

	// See if he is allowed to play this game.
	//
	if (!Server_GameAccessAllowed(state)) {
		Logmsg("REJECT: Unallowed game 0x%.8lx\n", state->gameIDData.gameID);
		if (state->account->boxAccount.totalServerConnects < kMaxConnWithBogusGame)
		{
			Server_SendDialog(state, gettext("This game is not yet available on XBAND.  Connecting with it will soon cost you credits."), true);	/* DIALOG */
		} else {
			state->disallowGameConnect = true;	// don't refund credit next time
			Server_SendDialog(state,
				gettext("This game is not yet available on XBAND.  You have been charged a credit."),	/* DIALOG */
				true);
		}
		return (kServerFuncOK);
	}


	// If this game is generally available but on a trial basis, warn them.
	//
	if (gameInfo->gameInfoFlags & kGIFlagNewlyAvailable) {
		sprintf(msg, gettext("Thanks for helping us test %s. Please use X-Mail to send comments about your games To: XBAND Title: NEWGAME\n"),	/* DIALOG */
			Common_AliasedGameName(state->platformID, state->gameIDData.gameID));
		Server_SendDialog(state, msg, true);
	}

	//
	// Set up the Contestant struct.
	//
	contestant.boxSerialNumber = state->loginData.userID.box;
	contestant.player = state->loginData.userID.userID;
	strcpy(contestant.userName, state->loginData.userID.userName);
	contestant.boxPhoneNumber = state->account->boxAccount.gamePhone;
	contestant.contestantID = state->connid;
	contestant.waitTime = kWaitAverage;
	
	if (state->account->boxAccount.debug[1] & kBA_debug_dial9)
		contestant.flags |= kForceMaster;
	
	if (state->platformID == kPlatformSNES)
	{
		contestant.waitTime = state->niftyInfo.snes.waitTime;
		if (state->niftyInfo.snes.dialingPrefix != 0)
			contestant.flags |= kForceMaster;
	}

	if ((restrictArea & kRestrictArea_XBNMask) && !xbndisabled)
		contestant.xbn = 1;

	if (gConfig.isXBNOn && Server_XBN_IsCallable(state))
	{
		can_receive_xbn = 1;
	}

	    if (state->challengeData.userID.box.box != kFindNetworkOpponentSerialNumber)
	    {
	    	///////// SPECIFIC CHALLENGE
	    	//
			contestant.challengeFlags = kSpecificChallenge;
			
			// Check basic long distance capability
			//
			if (restrictArea & kRestrictArea_dialLongDistance ||
				restrictArea & kRestrictArea_playerListDialLongDistance ||
				restrictArea & kRestrictArea_temporaryDialLongDistance)
			{
				contestant.callLongDistance = true;
			}
			//
			// Check XBAND Nationwide
			//
			if (gConfig.isXBNOn)
			{
				if (freexbn || ((restrictArea & kRestrictArea_XBNMask) && creditapproved
				&& !xbndisabled && xbnbelowcap))
				{
					contestant.xbndial = true;
					contestant.callLongDistance = true;
					if (can_receive_xbn)
						contestant.xbncallable = true;
					if (!freexbn)
						contestant.billme = true;
				}
			}
			state->account->playerAccount.challengeConnects++;
			state->account->playerModified |= kPA_challengeConnects;
	    }
	    else if (state->challengeData.userID.box.box == kFindNetworkOpponentSerialNumber)
	    {
	    	///////// AUTO CHALLENGE
	    	//
	   		if (gConfig.overrideSegaAcceptChallenges &&
			(state->platformID == kPlatformGenesis))
	   		{
	   			contestant.challengeFlags = kAcceptChallenges;
	   		}
	   		else if (state->account->playerAccount.playerFlags & kPlayerFlags_acceptChallenges)
				contestant.challengeFlags = kAcceptChallenges;
			else
				contestant.challengeFlags = kIgnoreChallenges;

			// Force ignore challenge on wild card overrides
			if (special & kSpecialLookLongFirst)
			{
				contestant.challengeFlags = kIgnoreChallenges;
				contestant.flags |= kLookLongFirst;
			}

			//
			// User must allow long distance challenges
			//
			if (preferLong)
			{
				// Check basic long distance capability
				//
				if (restrictArea & (kRestrictArea_dialLongDistance |
					kRestrictArea_temporaryDialLongDistance))
				{
					contestant.callLongDistance = true;
				}
				//
				// Check XBAND Nationwide
				//
				if (gConfig.isXBNOn)
				{					
					if (freexbn || ((restrictArea & kRestrictArea_XBNLongDistance) &&
					creditapproved && !xbndisabled && xbnbelowcap))
					{
						contestant.xbndial = true;
						contestant.callLongDistance = true;
						if (can_receive_xbn)
							contestant.xbncallable = true;
						if (!freexbn)
							contestant.billme = true;
					}
				}
			}
			state->account->playerAccount.autoMatchConnects++;
			state->account->playerModified |= kPA_autoMatchConnects;
	    } else {
			PLogmsg(LOGP_FLAW, "Invalid state->challengeData.userID.box.box\n");
			return (kServerFuncAbort);
	    }

		// Regardless of what their account says, if they're in the SpecialPhone
		// file as being set up for long distance, allow them to call LD.
		//
		if (special & kSpecialLongDistance && preferLong)
			contestant.callLongDistance = true;
	
		// HACK to keep VIPs from having to wait too long if turned into slaves.
		// Don't do the short wait if the game patch is restricted or we're
		// on a non-production server; otherwise the VIPs won't find anybody
		// to play against.
		//
		if (special & kSpecialShortWait)
			contestant.flags |= kShortWaitFlag;

//#define STUPID		// make sure it works the new way before changing over
#ifdef STUPID
	// Get the game patch version in a really bad way (race condition).
	// BRAIN DAMAGE 'R US.  (To be fixed soon...)
	//
	contestant.gamePatchVersion =
	 DataBase_GetLatestGameVersion(state->platformID, state->gameIDData.gameID);
	if (contestant.gamePatchVersion != state->gameIDData.version) {
		PLogmsg(LOGP_FLAW, "GLITCH: game patch vers mismatch (%d/%d)\n",
			contestant.gamePatchVersion, state->gameIDData.version);
		// (If you connect to a test server that doesn't have this game
		// patch, but you do have one, it will say (-1/29) or something
		// similar.  This is normal, and in fact proves that the OLD stuff
		// had a bug in it.  ++ATM 950623)
		//
		// (This kind of hoses things for the SNES simulator, since it's
		// patchVersion is hard-wired in, and therefore will never be
		// matched to a real box.  Hmm.  Kluge it?  ++ATM 950627)
	}
#else
	contestant.gamePatchVersion = state->gameIDData.version;
#endif

	// The "opp" fields get the desired opponent's identification if it's
	// a specific match request, or the previous opponent's identification
	// if it's an auto-match request.
	//
	if (contestant.challengeFlags == kSpecificChallenge) {
		// specific request
		//
		contestant.oppBoxSerialNumber = state->challengeData.userID.box;
		contestant.oppPlayer = state->challengeData.userID.userID;

		// he wants to challenge a specific player.
		// check if that is a valid playerID.
		//
		// NOTES:
		//
		// This check is necessary to get the boxIDs (if you only have the
		// name) or the name (if you only have the boxIDs).  There are a
		// number of other things that would be good to have:
		//
		//	- is this account closed or suspended?
		//	- is this person inside your calling area?
		//	- does this guy have a matching platformID (unless the game
		//	  allows cross-platform play)
		//
		// The test can fail if (1) the name doesn't exist (in which case
		// it should've blown up back in the address book add earlier),
		// or (2) the box serials don't exist.  Case 2 can only happen if
		// we moved from a test server with an address book or we lost some
		// pieces out of the database... in that case we may want to delete
		// the person from the address book.
		//
		// This stuff needs to be done someday. ++ATM 950622
		//
		if (WrapperDB_FindUserIdentification(&state->challengeData.userID,
			&challengeUserID) != kNoError)
		{		
			// Barf back to the dude... no such user.
			if (strlen(state->challengeData.userID.userName) == 0) {
				Server_SendDialog(state,
				// I18N Appears:  When player tries to challenge a player who
				//           does not have an account on XBAND.			
				// Solution: Try challenging a different opponent.  Perhaps 
				//           your opponent changed his or her player name?
				//
					gettext("That player does not exist on XBAND.  You have not been registered to play."),	/* DIALOG */
					true);
			} else {
				sprintf(msg,
					gettext("There is no player named %s on XBAND.  You have not been registered to play."),	/* DIALOG */
					state->challengeData.userID.userName);
				Server_SendDialog(state, msg, true);
			}
			return(kServerFuncOK);
		}
		
		// Do UserIDs match exactly? (box + player#)
		if (DataBaseUtil_CompareUserIdentifications(&challengeUserID,
			&state->loginData.userID))
		{
			// I18N Appears:  When player challenges himself.		
			// Solution: Challenge someone else.
			//
			Server_SendDialog(state, gettext("Come on, you can't play yourself!  You have not been registered to play."), true);	/* DIALOG */
			return(kServerFuncOK);
		}
		// Do the BoxSerialNumbers match? (just box)
		if (DataBaseUtil_CompareBoxSerialNumbers(&challengeUserID.box,
			&state->loginData.userID.box))
		{
			// I18N Appears:  When player tries to challenge another player on 
			//           the same modem.
			// Solution: Challenge someone else.  You cannot challenge 
			//           someone on the same modem.
			//
			Server_SendDialog(state, gettext("You can't play against someone who shares your XBAND Video Game Modem.  You have not been registered to play."), true);	/* DIALOG */
			return(kServerFuncOK);
		}

		contestant.oppBoxSerialNumber = challengeUserID.box;
		contestant.oppPlayer = challengeUserID.userID;
	
		PLogmsg(LOGP_DETAIL, "Specific Challenge Request With:\n");
		ServerState_PrintUserIdentification((const userIdentification *)&challengeUserID);
	} else {
		// auto-match requests
		//
		// If our last match was within the last hour, and for the same
		// game, put the guy's box/region/player in so we don't get matched
		// again.
		//
		
		// Use Dave's wacky field to tell if this is a new player.
		if (state->account->boxAccount.totalServerConnects < 11)
			contestant.flags |= kNewPlayerFlag;
		
		// Pass the entire array in.  Let the matcher decide how old is
		// too old.
		//
		memcpy(&contestant.prevOpponent,
			state->account->playerAccount.prevOpponent,
			sizeof(state->account->playerAccount.prevOpponent));
	}

		// Pass in the rating for this game.
		//
		// Look up the player's ranking for this game.
		//
		rankingInfo = Server_FindRankingInfo(state, state->account,
			matcherGameID);
		if (rankingInfo == NULL) {
			// This can only happen if the game isn't supposed to be scored.
			// So, just fill in the contestant's copy and be done with it.
			//
			// It's good that rankingInfo is NULL, so that when SetLastMatchup
			// gets to it the other fields will also get initialized to new
			// stuff.
			//
			InitializePlayerRankings(&contestant.ranking, matcherGameID);
			PLogmsg(LOGP_DETAIL, "SGP: game will not be scored\n"); // (debug)

		} else {
			// Found the rankingInfo field, or at least the place where it
			// ought to go.
			//
			PLogmsg(LOGP_DETAIL, "SGP: here we go!\n");
			if (!rankingInfo->gameID) {
				// First time playing this game.  Want to initialize the
				// database's copy of the field and mark it as dirty so that
				// the player will get a copy of the initial rankings on
				// THIS connect (important for auto-score-update on SNES).
				//
				// Since this is a keeper, we want to use the *canonical*
				// form for the gameID.  Does it matter for the other stuff
				// in this file?  Probably.  ROM freeze.  Mumble. ++ATM 950408
				//
				InitializePlayerRankings(rankingInfo,
					Common_GetCanonicalGameID(state->platformID, matcherGameID));
				state->account->playerModified |= kPA_ranking;


				// We've already called this, so all we'll send down this
				// trip is the ranking we just created.
				//
				Server_SendRanking(state);
			} else {
				// (debug)
				PLogmsg(LOGP_DETAIL,
					"SGP: rankings for this game already exist\n");
			}

			// Pass it in to the matcher.
			//
			contestant.ranking = *rankingInfo;
		}

	//
	// Check for mail to "XBAND.MATCHER" to override any attributes
	// Commands are series of single chars in the message field:
	//		"w" forces you to be a slave (wait)
	//		"L" forces you to be long distance
	//		"l" forces you to be local (forces wait if no local players)
	//		"a" forces players to accept specific challenges
	//		"n" make me a new player
	//		"s" force short wait
	//		"m" force master
	//
	for(i = 0; i < state->incomingMail.count; i++)
	{
		mail = state->incomingMail.mailItems[i].mail;
		if(!DataBaseUtil_CompareStrings(mail->to.userName, "xband.matcher"))
		{
			char *c;
			Logmsg("Processing mail to xband.matcher: %s\n", mail->message);
			for (c = mail->message; *c; c++)
			{
				switch(*c) {
				case 'w':
					contestant.flags |= kForceSlave;
					break;
				case 'n':
					contestant.flags |= kNewPlayerFlag;
					break;
				case 's':
					contestant.flags |= kShortWaitFlag;
					break;
				case 'a':
					contestant.flags |= kForceAcceptChallengeFlag;
					break;
				case 'l':
					contestant.callLongDistance = 0;
					break;
				case 'L':
					contestant.callLongDistance = 1;
					break;
				case 'm':
					contestant.flags |= kForceMaster;
					break;
				}
			}
		}
	}


	// XBAND Nationwide. Grab current 800# and ID CODE.
	// If there's a problem getting the data, revert to local matching (maybe send dialog).
	if (gConfig.isXBNOn && contestant.xbndial)
	{
		if (Server_XBN_ReadMCIFile(state))
		{
			PLogmsg(LOGP_FLAW,"*** ALERT - Nationwide Error - Can't load MCI ID CODE  ***\n");
			contestant.callLongDistance = 0;
			contestant.xbndial = 0;
			Server_SendDialog(state, gettext("XBAND Nationwide is currently down. You were registered for a local match."), true);
		}
	}
	Logmsg("XBN: creditapproved %d, freexbn %d, vip %d, can_receive_xbn %d\n",
		creditapproved, freexbn, vip, can_receive_xbn);
	Logmsg("XBN: xbndial %d, xbncallable %d, xbnbillme %d, xbndisabled %d\n",
		contestant.xbndial, contestant.xbncallable, contestant.billme, xbndisabled);
	Logmsg("XBN: xbnbelowcap %d\n", xbnbelowcap);

	//
	// TourneyStuff:
	// For automatch rounds: if this is a tourney player, then force him
	// to ignore challenges. This prevents someone from "sabotaging" this
	// player by challenging him (playerlist matches dont count for
	// automatch rounds).
	//
	/*
	 * For single-elimination rounds:
	 * Check for an opaquestore blobby to see if we're in the tourney.
	 * If so, force a specific-challenge with the person we're scheduled
	 * to play.
	 */

	if (state->tourneyData &&
		(state->tourneyData->flags & kTourneyNoMatcherFlag) == 0) {

		switch (state->tourneyData->type)
		{
		  case kTourneyAutoMatch:
			contestant.flags |= kTournamentFlag;
			contestant.challengeFlags = kIgnoreChallenges;
			PLogmsg(LOGP_DETAIL,
					"Server_StartGamePlay: setting automatch tourney flags\n");
			break;
		  case kTourneySpecificMatch:
			if (tourney_redirect) {
				contestant.waitTime = kWaitLong;
				strcpy(challengeUserID.userName,
					   "your Tournament opponent");
			}
			break;
		  default:
			PLogmsg(LOGP_FLAW,
					"Server_StartGamePlay: unknown tourney type %d\n",
					state->tourneyData->type);
		}
	}
	else {
		PLogmsg(LOGP_DETAIL,
			"Server_StartGamePlay: not setting tourney flags\n");
	}

	/*
	 * clear the bit indicating that we were matched,
	 * in case we become a slave and time out.
	 */
	state->account->boxAccount.lastMatchup.flags &= ~kLM_weWereMatched;
	state->account->boxModified |= kBA_lastMatchup;

	//
	// One-stop shopping.
	//
	state->matchup = (Matchup *)RPC_FindMatch(&contestant, state->platformID, matcherGameID);
	//
	// Don't miss it if you can!
	//



	if (state->matchup == NULL)
	{
	    // ay caramba
		if (special & kSpecialCatapult) {
			// Include a special message for catapult folks when the matcher
			// is dead.  This was motivated by confusion over the different
			// versions of SNES MK II.
			//
			sprintf(msg, "(CAT) Game is %s (%.4s-0x%.8lx)\n", /* DIALOG */
				Common_GameName(state->platformID, matcherGameID),
				(char *)&state->platformID, matcherGameID);
			Server_SendDialog(state, msg, true);
		}

			sprintf(msg,
				// I18N Appears:  When there is a problem with XBAND.
				// Solution: UCA should call Catapult immediately.
				//
				gettext("The XBAND Network is having problems with matching for %s.  Please try another game."),	/* DIALOG */
				Common_AliasedGameName(state->platformID, matcherGameID));
		Server_SendDialog(state, msg, true);
		return(kServerFuncOK);
	}

	/*
	 * Single-elimination tourney:
	 * store matchup in the tourney blobby.
	 */
	if (state->tourneyData &&
		state->tourneyData->type == kTourneySpecificMatch) {
		Server_TourneyProcessMatchup(state);
	}

	// (debug: show the random value returned by the matcher)
	//
	if (state->matchup->result == kMatchDial)
		PLogmsg(LOGP_DETAIL,
			"RANDOM (dial): rnd=0x%.8lx, omc=0x%.8lx (mc=0x%.8lx)\n",
			state->matchup->randomVal, state->matchup->oppMagicCookie,
			state->matchup->magicCookie);
	else
		PLogmsg(LOGP_DETAIL,
			"RANDOM (wait): rnd=0x%.8lx, mc=0x%.8lx\n",
			state->matchup->randomVal, state->matchup->magicCookie);

	// Generic errors.
	//
	switch (state->matchup->result)
	{
	case kCannotForceMaster:
		strcpy(msg, gettext("You can only make outgoing calls and we could not find an opponent for you to dial.  Please try again later."));	/* DIALOG */
		Server_SendDialog(state, msg, true);
		Logmsg("REJECT: cannot force master\n");
		return(kServerFuncOK);
	
	case kInvalidArguments:
		strcpy(msg, gettext("The XBAND Network is having problems.  Please try again later."));	/* DIALOG */
		Server_SendDialog(state, msg, true);
		Logmsg("REJECT: confused\n");
		return(kServerFuncOK);

	case kInvalidPhoneNumber:
		// I18N Appears:  When XBAND is having troubles 
		//           understanding your phone number.
		// Solution: Select "New Number" from the Options screen 
		//           and try connecting to XBAND again.  If the problem 
		//           persists UCA should escalate to Catapult.
		// 
		strcpy(msg, gettext("The XBAND Network can't understand your phone number.  Please try again later."));	/* DIALOG */
		Server_SendDialog(state, msg, true);
		Logmsg("REJECT: invalid phone number\n");
		return(kServerFuncOK);

	case kOpponentIsDialing:
		// NOTE: this is now trapped in Server_ValidateLogin().
		//
		// I18N Appears:  When player reregisters to XBAND at the same 
		//           time that an opponent tried to connect to the player.
		// Solution: Do not connect to XBAND while XBAND is 
		//           searching for an opponent for you.
		//
		strcpy(msg, gettext("Your opponent was dialing you, or is dialing now!  Don't connect to the XBAND Network while waiting for an opponent!"));	/* DIALOG */
		Server_SendDialog(state, msg, true);
		// Send the WaitForOpponent thing again so that he'll answer the
		// phone.  Don't think we need to send SendRegisterPlayer too.
		//
		Server_SendWaitForOpponent(state, state->matchup->magicCookie,
			state->matchup->randomVal);
		Statusmsg("         '%s' (%s) Rejected because opponent is dialing!\n",
			state->account->playerAccount.userName,
			prettyPhone.phoneNumber);
		Logmsg("REJECT: opponent is dialing\n");
		return(kServerFuncOK);

	case kOpponentIsDialingForWrongGame:
		// I18N Appears:  When player changed games while waiting for
		//           an opponent.
		// Solution: Do not change games while XBAND is 
		//           searching for an opponent for you.
		//
		strcpy(msg, gettext("An opponent was dialing you, but you changed games! Don't change games while waiting for an opponent!"));	/* DIALOG */
		Server_SendDialog(state, msg, true);
		// Send WaitForOpponent with a bogus magicCookie, so that the box
		// will accept the connection and then reject it immediately.  This
		// might cause the box to miss the dialog... should this one and
		// the last one be sent in a couple of pieces to ensure it gets
		// seen?
		//
		// HELLO: this could be the cause of some of the -306s.  ++ATM 950407
		//
		Server_SendWaitForOpponent(state, 0, state->matchup->randomVal);
		Statusmsg("         '%s' (%s) Rejected; opponent dialing with different game!\n",
			state->account->playerAccount.userName,
			prettyPhone.phoneNumber);
		Logmsg("REJECT: opponent is dialing, for different game\n");
		return(kServerFuncOK);

	default:
		break;
	}

	// Post warning messages.  This comes before the usual messages, which
	// means it will be seen after them.  In most cases it's also possible
	// that these will appear after they play the game (if they end up
	// being the master).
	//
	strcpy(msg, gettext("Hmm, thought I had something to say..."));
	switch (state->matchup->warning)
	{
	case kMWarnNone:
		break;
	case kMWarnSpecificToAuto:
	case kMWarnSpecificToSpecific:
		// I18N Appears:  When player connects to XBAND while XBAND 
		//           is searching for an opponent for the player.
		// Solution: Do not reconnect to XBAND while XBAND is 
		//           searching for an opponent for you.
		//
		strcpy(msg, gettext("You were still waiting for an opponent!  You have been registered again, but your original credit will not be refunded."));	/* DIALOG */
		break;
	case kMWarnAutoChangedGame:
		// I18N Appears:  When player changed games while waiting for
		//           an opponent.
		// Solution: Do not change games while XBAND is 
		//           searching for an opponent for you.
		//
		strcpy(msg, gettext("You changed cartridges!  You have been registered again, but your original credit will not be refunded."));	/* DIALOG */
		break;
	case kMWarnAutoChangedPlayer:
		// I18N Appears:  When player connects to XBAND while XBAND 
		//           is searching for an opponent for the player.
		// Solution: Do not reconnect to XBAND while XBAND is 
		//           searching for an opponent for you.
		//
		strcpy(msg, gettext("You changed players!  You have been registered again, but your original credit will not be refunded."));	/* DIALOG */
		break;
	case kMWarnAutoToSpecific:
		// I18N Appears:  When player connects to XBAND while XBAND 
		//           is searching for an opponent for the player.
		// Solution: Do not reconnect to XBAND while XBAND is 
		//           searching for an opponent for you.
		//
		strcpy(msg, gettext("You were still registered with XBAND!  You have been registered again, but your original credit will not be refunded."));	/* DIALOG */
		break;
	case kMWarnAutoToAuto:
		// This always comes down immediately, because they're never the
		// master after this.
		// I18N Appears:  When player connects to XBAND while XBAND 
		//           is searching for an opponent for the player.
		// Solution: Do not reconnect to XBAND while XBAND is 
		//           searching for an opponent for you.
		//
		strcpy(msg, gettext("You were already registered with XBAND!  You have been registered again, charged another credit, and placed at the bottom of the list."));	/* DIALOG */
		break;
	default:
		sprintf(msg, "Warning #%ld", state->matchup->warning); /* DIALOG */
		Logmsg("%s\n", msg);
		break;
	}
	if (state->matchup->warning != kMWarnNone)
	{
		Server_SendDialog(state, msg, true);
		// Always reset timeout count when a warning occurs
		Server_ResetXBNFreebieCount(state);
	}

	// Interpret the matchOrExpWhen field.  Either we're dialing or we're not;
	// if so, the value is put into the LastMatchup struct as the matchup
	// time (later).  If not, it's put into the BoxAccount as the slave
	// expire time.
	//
	if (state->matchup->result != kMatchDial) {
		LastSlaveInfo *lsip = &state->account->boxAccount.lastSlaveInfo;

		lsip->gameID = matcherGameID;
		lsip->contestantID = state->matchup->magicCookie;
		lsip->randomVal = state->matchup->randomVal;
		lsip->slaveExpireWhen = state->matchup->matchOrExpWhen;
		lsip->slaveQueuedWhen = time(0);
		state->account->boxModified |= kBA_lastSlaveInfo;
	}


	//
	// Handle errors based on what we tried to do.
	//
	if (contestant.challengeFlags == kSpecificChallenge)
	{
		//
		// Was a specific match request.
		//
		if (state->matchup->result == kMatchDial)
		{
			// TourneyStuff
			if (state->tourneyData)
			    Statusmsg("TOURNEY SPECIFIC: '%s' dialing\n", contestant.userName);
		}
		
		// NOTE: these can't happen if we're pushing them off onto the auto-match queue.
		
		else if (state->matchup->result == kSlaveUnReachableXBN)
		{
			sprintf(msg, gettext("%s subscribes to XBAND Nationwide but is not reachable at this time. You have not been registered to play."), challengeUserID.userName);	/* DIALOG */
			Server_SendDialog(state, msg, true);
			return(kServerFuncOK);
		}
		else if (state->matchup->result == kSlaveDoesntHaveXBN)
		{
			sprintf(msg, gettext("%s is long distance and does not subscribe to XBAND Nationwide. You have not been registered to play."), challengeUserID.userName);	/* DIALOG */
			Server_SendDialog(state, msg, true);
			return(kServerFuncOK);
		}
		else if (state->matchup->result == kChallengeeWaitingForDifferentGame)
		{		
			// I18N Appears:  When player challenges someone who is 
			//           currently playing a different game.		
			// Solution: Challenge someone else, or change game 
			//           cartridges and try challenging again.
			//
			sprintf(msg, gettext("%s has a different game cartridge installed.  You have not been registered to play."), challengeUserID.userName);	/* DIALOG */
			Server_SendDialog(state, msg, true);
			return(kServerFuncOK);
		}
		else if (state->matchup->result == kChallengeeWaitingForDifferentUser)
		{
			// I18N Appears:  When player challenges someone who is 
			//           challenging somebody else.
			// Solution: Challenge someone else.
			//
			sprintf(msg, gettext("%s has registered to play someone else.  You have not been registered to play."), challengeUserID.userName);	/* DIALOG */
			Server_SendDialog(state, msg, true);
			return(kServerFuncOK);
		}
		else if (state->matchup->result == kChallengeeTooFar)
		{
			// I18N Appears:  When player challenges someone who is outside 
			//           of the player's local calling area.  This happens when the 
			//           player has local calls selected.
			// Solution: Challenge someone else.  Or use the IVR to 
			//           change your calling restrictions to Long Distance.
			//
			sprintf(msg, gettext("%s is outside your calling area.  You have not been registered to play."), challengeUserID.userName);	/* DIALOG */
			Server_SendDialog(state, msg, true);
			return(kServerFuncOK);
		}
		else if (state->matchup->result == kChallengeeWaitingForAutoMatch)
		{
			// BRAIN DAMAGE.  If the other player accepts challenges, we should match you together.
			// (ATM: what the fuck does that mean?  We *do* match them.)
			// I18N Appears:  When player challenges someone who is not 
			//           accepting challenges.
			// Solution: Challenge someone else.
			// 
			sprintf(msg, gettext("You can't play %s because they are not accepting challenges.  You have not been registered to play."), challengeUserID.userName);	/* DIALOG */
			Server_SendLargeDialog(state, msg, true);
			return(kServerFuncOK);
		}
		else if (state->matchup->result == kDifferentRomVersion)
		{
			// I18N Appears:  When player challenges someone who has a 
			//           different modem (eg. Sega Genesis cannot play against 
			//           Super Nintendo).
			// Solution: Challenge someone else.
			//
			sprintf(msg, gettext("%s has a different XBAND Video Game Modem.  You have not been registered to play."), challengeUserID.userName);	/* DIALOG */
			Server_SendDialog(state, msg, true);
			return(kServerFuncOK);
		}
		else if (state->matchup->result == kMatchWait)
		{
			// TourneyStuff
			if (state->tourneyData)
			    Statusmsg("TOURNEY SPECIFIC: '%s' waiting\n", contestant.userName);
		}
		// catch-all
		else if (state->matchup->result != kLeaveOnQueue)
		{
			PLogmsg(LOGP_FLAW, "specific-Matching_FindMatch returned error %ld\n",
				state->matchup->result);
			// I18N Appears:  When XBAND is having a problem matching.
			// Solution: Challenge someone else.  If the problem persists, 
			//           UCA should notify Catapult.
			//
			sprintf(msg, gettext("Your challenge request could not be completed.  You have not been charged a credit."));	/* DIALOG */
			Server_SendDialog(state, msg, true);
			return(kServerFuncOK);
		}
		
		// bummer.  that dude isn't online, fall out into wait handler

	} else {
		//
		// Was an auto-match request.
		//
		if (state->matchup->result == kMatchWait)
		{
			// increment challenge count if waiting for automatch and snes player.
			if ((state->challengeData.userID.box.box == kFindNetworkOpponentSerialNumber)
			&& (state->platformID == kPlatformSNES) && !state->matchup->warning)
				Server_snes_BumpRegisterCount(state);
			
			// TourneyStuff
	    	    	if (state->tourneyData)
			    Statusmsg("TOURNEY: '%s' waiting\n", contestant.userName);
		}
		else if (state->matchup->result == kMatchDial)
		{
			// TourneyStuff
		    if (state->tourneyData)
			    Statusmsg("TOURNEY: '%s' dialing\n", contestant.userName);
		}
		else if (state->matchup->result != kLeaveOnQueue)
		{
			PLogmsg(LOGP_NOTICE, "RPC_FindMatch returned result %ld\n",
				state->matchup->result);
			// I18N Appears:  When XBAND is having a problem matching.
			// Solution: Challenge someone else.  If the problem persists, 
			//           UCA should notify Catapult.
			//
			sprintf(msg, gettext("Your challenge request could not be completed.  You have not been registered to play."));	/* DIALOG */
			Server_SendDialog(state, msg, true);
			return(kServerFuncOK);
		}
	}

	//
	// Handle dialing after auto or specific challenge cases
	//
	if (state->matchup->result == kMatchDial)
	{
		char dialString[64], nameString[256];
	
		// Always reset timeout count when a match is made.
		Server_ResetXBNFreebieCount(state);

		strcpy(dialString,state->matchup->oppPhoneNumber.phoneNumber);
			
#ifdef TESTING_CALLING_CARD
			if (!gConfig.isProduction || state->matchup->oppTollCall)
#else
			if (state->matchup->oppTollCall)
#endif
			{
			// Call is long distance, so we determine here how to dial.
			// There are currently three possibilities:
			//		1. XBAND Nationwide
			//		2. Sprint calling card
			//		3. Dial direct
			// XBN overrides Sprint and Sprint overrides dialing direct.

				// Disable certain box features for VIPs that go long distance
				if (vip)
					if (Server_SetVIPBoxMode(state))
					{
					    PLogmsg(LOGP_FLAW,
							"Server_SetVIPBoxMode failed - returning kServerFuncAbort\n");
				   		return(kServerFuncAbort);
					}

				if (gConfig.isXBNOn && state->matchup->xbndial)
				{
					// XBAND Nationwide (MCI)
					state->matchup->mci = 1;

					// Form MCI dial string
					sprintf(dialString,"1%swt1%sw%s",
						state->carrierphone,							// mci 800#
						state->matchup->oppOrigPhoneNumber.phoneNumber,	// dest ANI
						state->carriercode);							// secret code
				}
				else
				{
					// Use Sprint
					if (Server_GetSpecialCallingCard(state,
					state->matchup->oppOrigPhoneNumber.phoneNumber, dialString))
						state->matchup->sprint = 1;
				}
				// Default is to direct dial (we just don't modify the dialString)
		    	}

		//
		// "dialString" at this point is the exact number the box will dial.
		// I.e., it might be a direct local or toll call, or be a full 1-800 number sequence.
		//
		// If the "dial 9 to get out" hack is in effect, prepend "9,".
		//
		if (state->account->boxAccount.debug[1] & kBA_debug_dial9)
		{
			char tmpStr[64];
			strcpy(tmpStr,dialString);
			sprintf(dialString,"9,%s", tmpStr);
		}

		Statusmsg("SunSega: %s%s'%s' (%s) told to call %s'%s' (%s) for %.4s %s cookie %lu\n",
			(state->matchup->mci) ? ":XBN:" : (state->matchup->sprint) ? ":SPRINT:" : "",
			(vip) ?
				":VIP:" : contestant.callLongDistance ? ":LD:" : "",
			contestant.userName,
			prettyPhone.phoneNumber,
			(state->matchup->oppSpecific) ? "challenger " : "",
			state->matchup->oppUserName,
			dialString,
			(char *)&state->platformID,
			Common_GameName(state->platformID, matcherGameID),
			state->matchup->oppMagicCookie);
		StatusPrintWarning(state, state->matchup);
		StatusPrintGameResults(state);
		SetLastMatchup(state, state->matchup, rankingInfo);

		if (state->matchup->mci)
			strcpy(nameString, gettext("via XBAND Nationwide"));
		else {
			if (DISPLAY_LOCALE(state->platformID) == LOCALE_JA)
				strcpy(nameString, gettext("Dialing Opponent"));
			else
				strcpy(nameString, gettext("Opponent"));
		}

		Server_SendOpponentNameString(state, nameString);

		Logmsg("*** Sending Opponent Phone: %s (cookie %lu)\n",
			dialString, state->matchup->oppMagicCookie);
		
		return (Server_SendLongOpponentPhoneNumber(state,
			(const char *)dialString,
			state->matchup->oppMagicCookie,
			state->matchup->randomVal));
	}
	// end kMatchDial

	//
	// Used to be sendwaitforopponent
	//
	if (state->matchup->result == kMatchWait || state->matchup->result == kLeaveOnQueue)
	{		
		// Tell the box to wait for a call.
		//
		Logmsg("@@@ Wait For Opponent (my cookie=%ld)\n", state->matchup->magicCookie);
		if (contestant.challengeFlags == kSpecificChallenge &&
			!state->matchup->specificShunt)
		{
			Statusmsg("SunSega: '%s' (%s) waiting for %.4s %s challenge with %s\n",
				contestant.userName,
				prettyPhone.phoneNumber,
				(char *)&state->platformID,
				Common_GameName(state->platformID, matcherGameID),
				challengeUserID.userName);
			StatusPrintWarning(state, state->matchup);
			StatusPrintGameResults(state);
			// shouldn't need to send this
			Server_SendWorthString(state, gettext("1\npoint"), NULL);
			Server_SendGameOverString(state);
		} else {
			Statusmsg("SunSega: '%s' (%s) waiting %ld:%02ld for %.4s %s\n",
				contestant.userName,
				prettyPhone.phoneNumber,
				(state->matchup->matchOrExpWhen-time(0))/60,
				(state->matchup->matchOrExpWhen-time(0))%60,
				(char *)&state->platformID,
				Common_GameName(state->platformID, matcherGameID));
			StatusPrintWarning(state, state->matchup);
			StatusPrintGameResults(state);
			// shouldn't need to send this
			Server_SendWorthString(state, gettext("1\npoint"), NULL);
			Server_SendGameOverString(state);
		}
		if (state->matchup->specificShunt)
		{
			// Box still thinks it's registered for a specific match.
			// Convince it otherwise.
			//
			// (Can't happen with the existing matcher?)
			Server_SendClearNetOpponent(state);
		}
		err = Server_SendWaitForOpponent(state, state->matchup->magicCookie,
			state->matchup->randomVal);
		if (err == kServerFuncOK)
		{
			char gameName[kGameNameSize], *gptr;
		
			if ((gptr = Common_AliasedGameName(state->platformID,
					matcherGameID)) == NULL)
				gameName[0] = 0;
			else
				strcpy(gameName, gptr);

			if ((contestant.challengeFlags == kSpecificChallenge) &&
				(!state->matchup->specificShunt))
			{
				err = Server_SendRegisterChallengePlayer(state,
					(state->matchup->matchOrExpWhen-time(0)) * 60, gameName,
					challengeUserID.userName, contestant.xbncallable);
			} else {
				err = Server_SendRegisterPlayer(state,
					(state->matchup->matchOrExpWhen-time(0)) * 60, gameName, 
					contestant.xbncallable);
			}
			
			if (freexbnDialog)
			{
				Server_SendDialog(state, gettext("XBAND has been unable to find a match "
				"for you. You have been awarded one free XBAND Nationwide match for this "
				"connection ONLY."), true);	/* DIALOG */
			}
			// If they got shunted, tell them why.
			//
			switch (state->matchup->specificShunt)
			{
			case 0:
				break;
			case kChallengeeWaitingForDifferentGame:
				// I18N Appears:  See above.  Only difference is that you have been 
				//           registered for a normal  challenge match.
				//
				sprintf(msg, gettext("%s has a different game cartridge installed.  You have been registered for a Challenge match."),	/* DIALOG */
					challengeUserID.userName);
				Server_SendDialog(state, msg, true);
				break;
			case kChallengeeTooFar:
				// I18N Appears:  See above.  Only difference is that you have been 
				//           registered for a normal  challenge match.
				//
				sprintf(msg, gettext("%s is not in your calling area.  You have been registered for a Challenge match."),	/* DIALOG */
					challengeUserID.userName);
				Server_SendDialog(state, msg, true);
				break;
			case kChallengeeWaitingForDifferentUser:
				// I18N Appears:  See above.  Only difference is that you have been 
				//           registered for a normal  challenge match.
				//
				sprintf(msg, gettext("%s has registered to play someone else.  You have been registered for a Challenge match."),	/* DIALOG */
					challengeUserID.userName);
				Server_SendDialog(state, msg, true);
				break;
			case kChallengeeWaitingForAutoMatch:
				// I18N Appears:  See above.  Only difference is that you have been 
				//           registered for a normal  challenge match.
				//
				sprintf(msg, gettext("%s isn't accepting challenges.  You have been registered for a Challenge match."),	/* DIALOG */
					challengeUserID.userName);
				Server_SendLargeDialog(state, msg, true);
				break;
			default:
				// I18N Appears:  See above.  Only difference is that you have been 
				//           registered for a normal  challenge match.
				//
				sprintf(msg, gettext("XBAND was not able to match you with %s.  You have been registered for a Challenge match."),	/* DIALOG */
					challengeUserID.userName);
				Server_SendLargeDialog(state, msg, true);
				break;
			}
			return(err);
		}
		else
		{
			PLogmsg(LOGP_NOTICE,
				"Server_SendWaitForOpponent returned error %ld\n", err);
			return(kServerFuncAbort);
		}
	}
	return(kServerFuncOK);
}



// ===========================================================================
//		Matching-related subroutines
// ===========================================================================

//
// Called only for the master.
//
// Set the lastMatchup fields in both my account and my opponent's account.
// He gets my ranking info, and I get his.
//
// Most of the other fields are unnecessary until we get fancy with
// checking for hosers.  The "when" field is used as a flag; if set to
// zero then the rest of the fields should be considered invalid (can
// only happen on a newly initialized account).
//
// (Yeah, myRankingInfo could be pulled out of state & state->account.)
//
Err
SetLastMatchup(ServerState *state, Matchup *matchup, RankingInfo *myRankingInfo)
{
	Account *oppAccount;
	userIdentification oppUserID, *myUserID;
	RankingInfo *oppRankingInfo;
	LastMatchup *lastMatchup, *oppLastMatchup;
	time_t now = time(0);
	int mySpecific = 0, oppSpecific = 0;
	long masterPoints, slavePoints;
	char masterStr[64], slaveStr[64];

	if (state->challengeData.userID.box.box != kFindNetworkOpponentSerialNumber)
		mySpecific = kLastIChallenged;
	if (matchup->oppSpecific)
		oppSpecific = kLastOppChallenged;

	// Get his Account.  This will have to change, because we want this
	// operation to be write-only on the database.
	//
	oppUserID.box.box = matchup->oppBoxSerialNumber.box;
	oppUserID.box.region = matchup->oppBoxSerialNumber.region;
	oppUserID.userID = matchup->oppPlayer;
	oppUserID.userTown[0] = '\0';
	oppUserID.userName[0] = '\0';
	if ((oppAccount = WrapperDB_GetAccount(&oppUserID)) == NULL) {
		PLogmsg(LOGP_FLAW,
			"ERROR: couldn't find account for opponent (%ld,%ld)[%ld]\n",
			oppUserID.box.box, oppUserID.box.region, oppUserID.userID);
		return (kFucked);
	}

	// Set his lastMatchup field.
	//
	// Originally "when==0" would mean the field was invalid, but since
	// we update his account here and our account later, it's possible
	// that HIS final update would wipe out the data we dropped in.  Might
	// be possible to make it work, but I don't think we need it to.  It
	// still means that, since it's initialized to zero when the account
	// is created.
	//
	// Note that magicCookie for BOTH sides is oppMagicCookie; this is
	// because that's the cookie that's actually used during the peer connect.
	//
	// Looks like myRankingInfo can be NULL the first time we play a
	// particular game.  Act accordingly.
	//
	// We're the master, so matchOrExpWhen is the matchup time (i.e. right now).
	//
	oppLastMatchup = &oppAccount->boxAccount.lastMatchup;
	myUserID = &state->loginData.userID;
	oppLastMatchup->prevOpponent.when = (long)now;
	oppLastMatchup->prevOpponent.oppBoxSerialNumber.box = myUserID->box.box;
	oppLastMatchup->prevOpponent.oppBoxSerialNumber.region = myUserID->box.region;
	oppLastMatchup->prevOpponent.oppPlayer = myUserID->userID;
	oppLastMatchup->wasSpecific = mySpecific | oppSpecific;
	oppLastMatchup->player = matchup->oppPlayer;	// who he was
	oppLastMatchup->when = matchup->matchOrExpWhen;
	oppLastMatchup->magicCookie = matchup->oppMagicCookie;
	if (myRankingInfo != NULL)
		oppLastMatchup->oppRankingInfo = *myRankingInfo;
	else {
		InitializePlayerRankings(&oppLastMatchup->oppRankingInfo,
			state->gameIDData.gameID);
	}
	strcpy(oppLastMatchup->oppUserName, state->account->playerAccount.userName);
	oppLastMatchup->flags = kLM_weWereMatched;
	if (state->matchup->mci)
	{
		oppLastMatchup->callType = kXBNCall;
		if (matchup->billslave)
			oppLastMatchup->flags |= kLM_tallyBoxEst;
	}
	else if (state->matchup->oppTollCall)
		oppLastMatchup->callType = kLongCall;
	else
		oppLastMatchup->callType = kLocalCall;

	// Update his Account.  We could free it now, but it's convenient to
	// pull our rankings out of his LastMatchup structure in case we didn't
	// have any and had to initialize them above.
	//
	oppAccount->boxModified |= kBA_lastMatchup;
	WrapperDB_UpdateAccount(oppAccount);

	// Now put him in my account, and mark for update later.
	//
	// The slave's rankingInfo struct comes out of Matchup.
	//
	oppRankingInfo = &matchup->oppRankingInfo;

	lastMatchup = &(state->account->boxAccount.lastMatchup);
	lastMatchup->prevOpponent.when = (long)now;
	lastMatchup->prevOpponent.oppBoxSerialNumber.box =
		matchup->oppBoxSerialNumber.box;
	lastMatchup->prevOpponent.oppBoxSerialNumber.region =
		matchup->oppBoxSerialNumber.region;
	lastMatchup->prevOpponent.oppPlayer = matchup->oppPlayer;
	lastMatchup->wasSpecific = mySpecific | oppSpecific | kLastMaster;
	lastMatchup->when = matchup->matchOrExpWhen;
	lastMatchup->player = state->loginData.userID.userID;	// who I am
	lastMatchup->magicCookie = matchup->oppMagicCookie;
	strcpy(lastMatchup->oppUserName, matchup->oppUserName);
	lastMatchup->oppRankingInfo = *oppRankingInfo;
	lastMatchup->flags = kLM_weWereMatched;
	if (state->matchup->mci)
	{
		lastMatchup->callType = kXBNCall;
		if (matchup->billmaster)
			lastMatchup->flags |= kLM_tallyBoxEst;
	}
	else if (state->matchup->oppTollCall)
		lastMatchup->callType = kLongCall;
	else
		lastMatchup->callType = kLocalCall;
	state->account->boxModified |= kBA_lastMatchup;

	// Set the strings shown at the "versus" screen.  We can actually do
	// the right thing now!
	//
	if (mySpecific || oppSpecific) {
		Server_SendWorthString(state, gettext("NO\nPoints"), gettext("NO\nPoints"));
		Server_SendRankingDisable(state);
	} else {
		Server_SendRankingEnable(state);
		masterPoints = GetMatchPointValueForP1(&oppLastMatchup->oppRankingInfo,
			oppRankingInfo);
		slavePoints = GetMatchPointValueForP1(oppRankingInfo,
			&oppLastMatchup->oppRankingInfo);
		Logmsg("%ld-My xpoints=%lu rating=%d, his xpoints=%d rating=%d, M:%d/S:%d\n",
			state->matchup->oppMagicCookie,
			oppLastMatchup->oppRankingInfo.totalXBandPoints,
			oppLastMatchup->oppRankingInfo.rating,
			oppRankingInfo->totalXBandPoints,
			oppRankingInfo->rating,
			masterPoints, slavePoints);

		sprintf(masterStr, gettext("%d\nPoint%s"), masterPoints,
			(masterPoints == 1) ? "" : "s");
		sprintf(slaveStr, gettext("%d\nPoint%s"), slavePoints,
			(slavePoints == 1) ? "" : "s");
		Server_SendWorthString(state, slaveStr, masterStr);
	}
	Server_SendGameOverString(state);

	// Fly, be free.  Free the account.
	//
	DataBaseUtil_FreeAccount(oppAccount);
	oppAccount = NULL;
	return kServerFuncOK;
}


//
// Print a game result status message.
//
void
StatusPrintGameResults(ServerState *state)
{
	char numbuf[16];
	NewGameResult *gameResult = (NewGameResult *)state->gameResult;

	if (state->validFlags & kServerValidFlag_GameResults) {
		sprintf(numbuf, "  ERR %d/%d/%d", gameResult->gameError,
			gameResult->errorWhere, gameResult->connectPhase);

		Statusmsg("         local: %ld  remote: %ld  playTime: %ld%s  (%.4s-0x%.8lx)\n",
			gameResult->localPlayer1Result + gameResult->localPlayer2Result,
			gameResult->remotePlayer1Result + gameResult->remotePlayer2Result,
			gameResult->playTime,
			gameResult->gameError ? numbuf : "",
			(char *)&state->platformID,
			gameResult->gameID);
	} else {
		// say nothing; will make the log smaller
		//Statusmsg("         (no game results)\n");
	}
}


//
// Print a summary of the warning to the status log.
//
void
StatusPrintWarning(ServerState *state, Matchup *matchup)
{
	char *msg = NULL;
	phoneNumber prettyPhone;

	prettyPhone = state->account->boxAccount.gamePhone;
	Common_PhoneFormatDisplay(state->account->boxAccount.gamePhone.phoneNumber,
		prettyPhone.phoneNumber);

	switch (matchup->warning) {
	case kMWarnNone:
		break;
	case kMWarnSpecificToAuto:
		msg = "Reregister from Specific to Auto";
		break;
	case kMWarnSpecificToSpecific:
		msg = "Reregister from Specific to Specific";
		break;
	case kMWarnAutoChangedGame:
		msg = "Reregister on Auto with different game";
		break;
	case kMWarnAutoChangedPlayer:
		msg = "Reregister on Auto with different player";
		break;
	case kMWarnAutoToSpecific:
		msg = "Reregister from Auto to Specific";
		break;
	case kMWarnAutoToAuto:
		msg = "Attempted reregister from Auto to Auto";
		break;
	default:
		Statusmsg("         (sent warning #%ld)\n", matchup->warning);
		break;
	}
	if (msg)
		Statusmsg("         '%s' (%s) %s\n",
			state->account->playerAccount.userName,
			prettyPhone.phoneNumber, msg);
	if (msg)
		Logmsg("REREGISTER: %s\n", msg);
}

static time_t parse_date(line,year)
char *line;
int year;
{
   char *first,*second;
   struct tm t_date;

   memset(&t_date,0,sizeof(struct tm));

   t_date.tm_mon=atoi(line)-1;
   first=strchr(line,'/');
   t_date.tm_mday=atoi(first+1)-1;
   if ((second=strrchr(line,'/'))!=first)
      t_date.tm_year=atoi(second+1);
   else
      t_date.tm_year=year;

   return(timelocal(&t_date));
}

#define DAY 60*60*24
#define YEAR DAY*365

static int parse_holiday(line,t,year)
char *line;
time_t t;
int year;
{
   int match=0;
   time_t t1,t2;
   char *s;

   if ((s=strchr(line,'-')))
      {
      *s=NULL;
      t2=parse_date(s+1,year);
      }

   t1=parse_date(line,year);

   if (!s)
      t2=t1;
   else
      if (t2<t1)
         t2+=YEAR;

   if (t>=t1 && t<t2+DAY)
      match=1;

   return(match);
}

static int check_holiday_file(filename,t,year)
char *filename;
time_t t;
int year;
{
   char line[81];
   int match=0;
   FILE *fp;

   if ((fp=fopen(filename,"r")))
      {
      while (fgets(line,80,fp))
         if (*line!='#' && (match=parse_holiday(line,t,year)))
            break;

      fclose(fp);
      }

   return(match);
}

//
// Check if it's OK for him/her to play.
//
// Return TRUE if okay, FALSE if not.
//
static Boolean
Server_CheckRestrictions(ServerState *state, Restriction *weekdayRestrict,
	Restriction *weekendRestrict)
{
// adjust for time zone based (stupidly right now) on area code
// what day is it?
time_t		t;
struct tm 	*tm;
short		ourtime;
Restriction	*restrict;

	Logmsg("CheckRestrictions: weekday %d/%d, weekend %d/%d\n",
		weekdayRestrict->start, weekdayRestrict->end,
		weekendRestrict->start, weekendRestrict->end);

	t = state->localConnectTime;
	tm = localtime(&t);
	if (!tm) {
		PLogmsg(LOGP_FLAW, "ERROR: localtime() failed\n");
		return (true);		// let them in
	}

	if (check_holiday_file("Holidays.sunsega",t,tm->tm_year))
	   return(true);

	ourtime = tm->tm_hour * 60 + tm->tm_min;

	// Is today a "weekend" (friday or saturday)?  (unix time: day 0 == sunday)
	//
	if(tm->tm_wday == gConfig.weekendDay1 || tm->tm_wday == gConfig.weekendDay2)
		restrict = weekendRestrict;
	else
		restrict = weekdayRestrict;


	if(restrict->start == kRestrictionTime_PlayAnytime &&
		restrict->end == kRestrictionTime_PlayAnytime)
			return(true);
	if(restrict->start == kRestrictionTime_PlayNever &&
		restrict->end == kRestrictionTime_PlayNever)
			return(false);


	if(restrict->start < restrict->end)
	{
		if(ourtime >= restrict->start && ourtime <= restrict->end)
			return(true);
		else
			return(false);
	}
	else
	{
		if(ourtime >= restrict->start || ourtime <= restrict->end)
			return(true);
		else
			return(false);
	}
}

//
// Determine if the player is still on a wait queue.
//
// Returns TRUE if he is, FALSE if not.
//
int Server_IsPlayerOnQueue(ServerState *state)
{
	if (state->account->boxAccount.lastSlaveInfo.slaveExpireWhen &&
		state->account->boxAccount.lastSlaveInfo.slaveQueuedWhen)
	{
		LastSlaveInfo *lsip = &state->account->boxAccount.lastSlaveInfo;
		time_t now = time(0);

		// They are on a queue if
		//	(1) their expire time hasn't arrived yet, and
		//	(2) their last matchup time is earlier than their Enqueue time
		//
		// Note that lastMatchup.when could be zero if uninitialized; OK.
		//
		if (lsip->slaveExpireWhen > now &&
			state->account->boxAccount.lastMatchup.when <
				state->account->boxAccount.lastSlaveInfo.slaveQueuedWhen)
		{
			return (true);
		}
	}

	return (false);
}

//
// Tell a matcher to throw a player off its queue.
//
Err Server_DequeuePlayer(ServerState *state, const long gameID)
{
	MatchControl mc;
	MatchControl_DequeueContestant *deq = (MatchControl_DequeueContestant *)&mc;

	Logmsg("Telling matcher for 0x%.8lx to remove (%ld,%ld)\n", gameID,
		state->loginData.userID.box.box, state->loginData.userID.box.region);

	deq->type = kMatchCtl_DequeueContestant;
	deq->boxSerialNumber = state->loginData.userID.box;

	RPC_MatchingControl(&mc, state->platformID, gameID);

	return (kNoError);
}


#define kMagicBadGameID	0x53484954		// 'SHIT'

//
// Determine whether we should completely obstruct a player from logging
// in because they're challenging with an unsupported cartridge.
//
// This is necessary because the first round of SNES hardware had difficulty
// reading the hardwareID, so we can't charge a credit to people logging
// in with an invalid cartridge because they might have a valid cartridge
// that just read wrong.
//
// There are three possibilities: (1) first-time user who doesn't know any
// better, (2) honest user with a bad cartridge read, and (3) fucker who
// wants to get free mail and address book lookups.  The actions we take
// and dialogs we send need to work for all three.
//
// (Special case: if the gameID is the 4-byte constant 'SHIT', then the
// SNES OS patch has verified that the guy has a flaky gameID read.)
//
// Returns "true" if the player should be nuked, "false" if it's okay.
// Sends an appropriate dialog to the luser.
//
Boolean
Server_CheckInvalidChallenge(ServerState *state)
{
	const GameInfo *gi = NULL;

	PLogmsg(LOGP_PROGRESS, "Server_CheckInvalidChallenge %.4s-0x%.8lx\n",
		(char *)&state->platformID, state->gameIDData.gameID);

	// Only interesting for auto-match "challenge" requests.
	//
	if (state->challengeData.userID.box.box != kFindNetworkOpponentSerialNumber)
		return (false);

	// It's not clear if this will affect the sj01 boxes too.  For now
	// just do it to sn07.
	//
	if (state->boxOSState.boxType != kBoxType_sn07)
		return (false);

	// See if we've ever heard of the game.
	//
	gi = Common_GameInfoForGame(state->platformID, state->gameIDData.gameID);
	if (gi != NULL) {
		// The game exists.  If they're not authorized to play it, we'll
		// hit them later, so we don't need to do the check now.
		//
		//if (Server_GameAccessAllowed(state))

		return (false);		// happy
	}

	// If they're new to the system, let them get news and stuff, so they'll
	// have the list of supported games.
	//
	if (state->account->boxAccount.totalServerConnects < kMaxConnWithBogusGame)
		return (false);

	// Send down an appropriate denial-of-service dialog.
	//
	// If his gameID was 'SHIT', tell him about it, OR
	//
	// If he tried to send mail, tell him we didn't send it, OR
	//
	// If he had an address book query that needed to be resolved, tell him
	// we didn't resolve it, OR
	//
	// Just tell him that his game wasn't recognized, using the same dialog
	// we're currently using in StartGamePlay to yell at SNES people.
	//
	// They won't receive any messages if they're just logging in to see
	// if they have any new mail, which is a bad from the "teach the user"
	// perspective.  However, if we told them about new mail they'd be able
	// to use it to check and see if they have new mail before using a credit
	// to get the mail in question.
	//
	if (state->gameIDData.gameID == kMagicBadGameID) {
		// (note the terminology is Nintendo-ish; this matches the box's dialog)
		Server_SendLargeDialog(state,
			gettext("XBAND is unable to read your Game Pak. Please turn off power from your Control Deck, remove the Game Pak, clean all connection points, then reconnect the Pak to your XBAND Modem."),
			true);
	} else if (state->incomingMail.count) {
		Server_SendDialog(state,
			gettext("The game you have installed is NOT supported by XBAND. Challenge cannot be completed. X-Mail message(s) cannot be sent."),
			true);
	} else if (state->addrValidationData.count) {
		Server_SendDialog(state,
			gettext("The game you have installed is NOT supported by XBAND. Challenge cannot be completed. Player List cannot be updated."),
			true);
	} else {
		Server_SendDialog(state,
			gettext("Sorry, this game is not available. Please try another."),	/* DIALOG */
			true);
	}

	return (true);
}


//
// Determine if the user is allowed to play the current game.
//
// Returns "true" if he's allowed, "false" if not.
//
PRIVATE Boolean
Server_GameAccessAllowed(ServerState *state)
{
	Boolean vip;
	long special;
	const GameInfo *gameInfo;

	PLogmsg(LOGP_PROGRESS, "Server_GameAccessAllowed\n");

	if ((gameInfo = Common_GameInfoForGame(state->platformID,
		state->gameIDData.gameID)) == NULL)
	{
		// If the game doesn't exist in the table, we shouldn't even be
		// being called.  Decision to return "false" is arbitrary but seems
		// reasonable.
		//
		return (false);		// deny
	}

	special = Server_GetSpecialPhone(state);
	vip = ((special & kSpecialVIPTester) ||
		(state->account->boxAccount.boxFlags & kBoxFlag_VIP)) != 0;

	if (gameInfo->gameInfoFlags & kGIFlagRestrictedMask) {
		if (special & kSpecialNewGames) {
			// If he has the 'G' flag set, he can always play.
			//
			PLogmsg(LOGP_DBUG, "Access to %.4s-0x%.8lx allowed (G)\n",
				(char *)&state->platformID, state->gameIDData.gameID);

		} else if ( vip &&
					((gameInfo->gameInfoFlags & kGIFlagVIPOnly) ||
					 (gameInfo->gameInfoFlags & kGIFlagVIPAndGameTester)) )
		{
			// If he's a VIP ('V' flag or VIP box flag set), and the game is
			// allowed to VIPs, let him in.
			//
			PLogmsg(LOGP_DBUG, "Access to %.4s-0x%.8lx allowed (V)\n",
				(char *)&state->platformID, state->gameIDData.gameID);

		} else if ((gameInfo->gameInfoFlags & kGIFlagVIPAndGameTester) &&
			(state->account->boxAccount.boxFlags & kBoxFlag_GameTester))
		{
			// If he has the "GameTester" box flag set, and access is allowed
			// to those people, let him in.
			//
			PLogmsg(LOGP_DBUG, "Access to %.4s-0x%.8lx allowed (T)\n",
				(char *)&state->platformID, state->gameIDData.gameID);

		} else {
			// Doesn't have sufficient access, nuke him.
			//
			PLogmsg(LOGP_DBUG, "Access to %.4s-0x%.8lx DENIED\n",
				(char *)&state->platformID, state->gameIDData.gameID);
			return (false);
		}
	}

	return (true);	// allow
}



// ===========================================================================
//		Box message routines
// ===========================================================================

//
// Messages that exist on patched 'segb' (Genesis v1.0) boxes.  These
// also exist on SNES, but will not exist on Sega 1.0 simulators.
//
// (There are now standard names for each of these.)
//
#ifdef USE_PATCHED_NAMES
#define pmsGetGameInfo			0x42	// sends msGameIDAndPatchVersion
#define pmsClearNetOpponent		0x43	// no reply
#define pmsGetBoxMemInfo		0x44	// sends pmsSendSizes

#define pmsSendSizes			30		// response to pmsGetBoxMemInfo
#endif


#ifdef DONT_USE_YET
//
// Retrieve the gameID and patch version from the box.  This tells us
// whether or not the previous patch download actually worked.
//
// (Not yet tested; will blow up simulators and un-patched boxes.)
//
Err
Server_GetGameIDAndPatchVersion(ServerState *state, long *gameID, long *patchVersion)
{
messOut	opCode;
char	numHidden;

	PLogmsg(LOGP_PROGRESS, "Server_GetGameIDAndPatchVersion\n");
	if(Server_DebugService(state) != kServerFuncOK)
		return(kServerFuncAbort);

	opCode = pmsGetGameInfo;
	Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr)&opCode);

	Server_TReadDataSync( state->session, 1, (Ptr)&opCode );
	if(opCode != msGameIDAndPatchVersion)
	{
		PLogmsg(LOGP_FLAW,
			"Error: Box didn't respond to pmsGetGameInfo with msGameIDAndPatchVersion (got %d)\n",
			opCode);
		return(kServerFuncAbort);
	}

	Server_TReadDataSync( state->session, sizeof(long), (Ptr) gameID);
	Server_TReadDataSync( state->session, sizeof(long), (Ptr) patchVersion);

	if(Server_TCheckError() != noErr)
		return(kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_GetGameIDAndPatchVersion done\n");

	return(kServerFuncOK);
}
#endif	/*DONT_USE_YET*/


#ifdef OLD_SEGA_STUFF
//
// Tell the box that it is now on an auto-match queue.  Requires a system
// patch (version 12 or later), which should already have been sent.
//
//	 0: 09 00 00 00 16 30 3C 0E 9C 20 78 00 40 B1 FC 4E
//	10: F9 00 22 66 04 4E F8 00 40 4E D0
//
// UPDATE: this should be replaced with pmsClearNetOpponent.
//
Err
Server_SendSpecificToAuto(ServerState *state)
{
	PreformedMessage pm;
	static unsigned char magic[] = {
		0x09, 0x00, 0x00, 0x00, 0x16, 0x30, 0x3c, 0x0e,
		0x9c, 0x20, 0x78, 0x00, 0x40, 0xb1, 0xfc, 0x4e,
		0xf9, 0x00, 0x22, 0x66, 0x04, 0x4e, 0xf8, 0x00,
		0x40, 0x4e, 0xd0,
	};

	Logmsg("Sending Specific-to-Auto magic\n");
	pm.length = sizeof(magic);
	pm.message = magic;
	Server_SendPreformedMessage(state, &pm);
}
#endif
//
// Tell the box that it is no longer registered for a match; useful for
// switching people from specific-match to auto-match (or vice-versa).  This
// isn't needed if they logged in with a different request, it's needed if
// they requested a specific match but we want to register them for an auto
// match.
//
// Works on patched Sega 1.0 boxes and SNES, will explode on a Sega 1.0
// simulator.
//
Err
Server_SendClearNetOpponent(ServerState *state)
{
	char opCode;

	// If it's a sega sim, bail.
	//
	if ((state->platformID == kPlatformGenesis) &&
		(state->gameIDData.gameID == 666))
	{
		Logmsg("NOT sending ClearNetOpponent to Genesis simulator\n");
		return (kServerFuncOK);
	}

	// Send down the opCode.  No data, no reply.
	//
	Logmsg("Sending ClearNetOpponent\n");

	opCode = msClearNetOpponent;
	if (Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr) &opCode) != noErr)
		return (kServerFuncAbort);

	return (kServerFuncOK);
}



// ===========================================================================
//		Set special modes on the box
// ===========================================================================

/*
 * Similar to Server_UpdateDatabaseAccountPartial().
 * Update boxAccount.boxFlags in segad RIGHT NOW.
 * This should help prevent boxes from being stuck in tourney-mode
 * by reducing the window during which a SIGHUP can result in the
 * box being in tourney-mode but the server not recording that fact.
 *
 * We make sure to only change the tourney bit in boxFlags by
 * using the value we stored at the beginning of the connection,
 * rather than the current value in state->account (which may
 * have already had other changes made to it that we don't want to
 * push out to the DB yet).
 */

PRIVATE Err
Server_UpdateBoxFlags(ServerState *state, Boolean tourneyFlag)
{
	Err err;
	long pm, um, bm, realBoxFlags;

	err = Server_SyncWithBox(state);
	if (err != kServerFuncOK)
		return err;

	pm = state->account->playerModified;
    um = state->account->userModified;
    bm = state->account->boxModified;
	realBoxFlags = state->account->boxAccount.boxFlags;

    state->account->playerModified = 0;
    state->account->userModified = 0;
    state->account->boxModified = kBA_boxFlags;
	state->account->boxAccount.boxFlags =
		tourneyFlag ?
			state->origBoxFlags | kBoxFlag_TourneyBox :
			state->origBoxFlags & ~(kBoxFlag_TourneyBox);

	err = WrapperDB_UpdateAccount(state->account);

	PLogmsg(LOGP_PROGRESS, "Server_UpdateBoxFlags: boxFlags set to %08x\n",
			state->account->boxAccount.boxFlags);

    state->account->playerModified = pm;
    state->account->userModified = um;
    state->account->boxModified = bm;
	state->account->boxAccount.boxFlags = realBoxFlags;

	return (err == kNoError) ? kServerFuncOK : kServerFuncAbort;
}



Err
Server_SetTourneyBoxMode(ServerState *state)
{
	// Send down a dbconstant that tells the box to turn off call waiting,
	// disallow chat and playing again, and tell games it's in tournament mode.
	DBID id;
	long data;

	if (state->tourneyData == NULL) {
	    PLogmsg(LOGP_FLAW, 
		"Server_SetTourneyBoxMode called with NULL tourneyData -ignoring");
	    return(kServerFuncOK);
	}
	
	id = kSpecialModeFlagsConst;
	if (Server_GetDBConstant(state, id, &data) != kServerFuncOK)
		return (kServerFuncAbort);
	if (data == -1)
		data = 0;

	//
	// TourneyStuff:
	// Current policy is that we turn off call waiting and post-game 
	// stuff only for specific match rounds. We always turn on the 
	// tourney game bit for game patches to look at.
	//
	switch(state->tourneyData->type) {
	    case kTourneyAutoMatch:
		data |= kTourneyGame;
		break;

	    case kTourneySpecificMatch:
		data |= kDemoNoCW | kDemoNoPostGame | kTourneyGame;
		break;

	    default:
	        PLogmsg(LOGP_FLAW, 
		    "Server_SetTourneyBoxMode: unknown tourney type '%d'",
		    state->tourneyData->type);
	        return(kServerFuncOK);
	}

	if(Server_SendDBConstants(state, 1, &id, &data) != kServerFuncOK)
		return(kServerFuncAbort);

	if (Server_UpdateBoxFlags(state, true) != kServerFuncOK)
		return kServerFuncAbort;

	Logmsg("Server_SetTourneyBoxMode: sent dbid %d data %#x\n",
	    (int)id, (int)data);
	
	state->account->boxAccount.boxFlags |= kBoxFlag_TourneyBox;
	state->account->boxModified |= kBA_boxFlags;

	Logmsg("Tourney patch turned on for box %ld\n",
	    state->loginData.userID.box.box);

	return kServerFuncOK;
}


Err
Server_SetVIPBoxMode(ServerState *state)
{
	// Send down a dbconstant that tells the box to disallow chat and playing again.
	// We don't want VIPs using up our hard earned cash for chat, etc. We want to
	// increase the number of matches.
	DBID id;
	long data;

#ifdef ENABLE_VIP_BOX_MODE
	// Figure out what we currently have set.  This should be kept in
	// the database and cleared out if the box loses its DB.
	//
	id = kSpecialModeFlagsConst;
	if (Server_GetDBConstant(state, id, &data) != kServerFuncOK)
		return (kServerFuncAbort);
	if (data == -1)
		data = 0;

	// Set the "no post-game stuff" flag.
	//
	data |= kDemoNoPostGame;
	if(Server_SendDBConstants(state, 1, &id, &data) != kServerFuncOK)
		return(kServerFuncAbort);
	
	state->account->boxAccount.boxFlags |= kBoxFlag_VIPBox;
	state->account->boxModified |= kBA_boxFlags;
#endif
	return kServerFuncOK;
}

Err
Server_ClearBoxMode(ServerState *state)
{
	// If we put the box into a special mode before, turn it off now.
	DBID id;
	long data;

		// Figure out what we currently have set.  This should be kept in
		// the database and cleared out if the box loses its DB.
		//
		id = kSpecialModeFlagsConst;
		if (Server_GetDBConstant(state, id, &data) != kServerFuncOK)
			return (kServerFuncAbort);
		if (data == -1)
			data = 0;

		// Clear the VIP and tournament flags.
		//
		data &= ~(kDemoNoCW | kDemoNoPostGame | kTourneyGame);
		if(Server_SendDBConstants(state, 1, &id, &data) != kServerFuncOK)
			return(kServerFuncAbort);

		if (Server_UpdateBoxFlags(state, false) != kServerFuncOK)
			return kServerFuncAbort;

		state->account->boxAccount.boxFlags &= ~(kBoxFlag_VIPBox|kBoxFlag_TourneyBox);
		state->account->boxModified |= kBA_boxFlags;

		Logmsg("VIP/Tourney box flags cleared for %ld\n",
			state->loginData.userID.box.box);

	return kServerFuncOK;
}

//
// Retrieve a single DB constant from the box.  The constant will be -1
// if the constant is really -1 or if it doesn't exist.
//
// (Doesn't really belong in this file.  Move it someday.)
//
int
Server_GetDBConstant(ServerState *state, DBID id, long *datap)
{
	unsigned char opCode;

	PLogmsg(LOGP_PROGRESS, "Server_GetDBConstant (%d)\n", id);

	opCode = msGetConstant;
	Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&id);

	//PLogmsg(LOGP_PROGRESS, "Sent msGetConstant, awaiting reply\n");

	Server_TReadDataSync(state->session, sizeof(long), (Ptr)datap);

	PLogmsg(LOGP_DBUG, "GetConstant: %d = 0x%.8lx\n", id, *datap);
	return (kServerFuncOK);
}


// This function returns non-zero if a non-long distance snes player has had too
// many timeouts. See corresponding code in Server_GameResults.c

long Server_snes_CheckXBNFreebie(ServerState *state)
{
    OpaqueStore *os = &state->account->playerAccount.opaqueStore;
    OpaqueStoreValue osval;
    unsigned int ossize = -1;
    Err err;
	long count;
	long rnd;

	srandom(state->localConnectTime);

	PLogmsg(LOGP_PROGRESS, "Server_snes_CheckXBNFreebie\n");
	Logmsg("gConfig.snesXBNFreebieThreshold = %lu\n",gConfig.snesXBNFreebieThreshold);

	// Check timeout threshold
	if (!gConfig.snesXBNFreebieThreshold)
		return 0;
	
	// Skip vips or free xbn'ers
	if ((Server_GetSpecialPhone(state) & kSpecialVIPTester) ||
	(state->account->boxAccount.boxFlags & (kBoxFlag_VIP|kBoxFlag_FreeXBN)))
		return 0;

	// Only for non-long distance dudes
	if (state->account->boxAccount.restrictArea & kRestrictArea_longOnlyCapableMask)
		return 0;
	
	// Only allow people to get this service first week of new account
	if (state->timeOfThisConnect > state->account->userAccount.dateFirstConnect
		+ (24*60*60*7))
		return 0;

	// compare with account challenge count
    err = OpqStore_GetValueSize(os, kXBNFreebieCountKey, &ossize);
    if (err == kOpqNoError)
    {
		/* make sure the old value was the right size */
		if (ossize != sizeof(long))
		{
		    Logmsg("wrong kXBNFreebieCountKey opaque size\n");
		    return 0;
		}
		/* get the value */
		osval.buf = (char *)&count;
		osval.numMaxBytes = osval.numBytes = sizeof(long);
		err = OpqStore_GetKeyValue(os, kXBNFreebieCountKey, &osval);
		if (err != kOpqNoError)
		{
		    Logmsg("OpqStore_GetKeyValue err: %d\n", err);
		    return 0;
		}
		rnd = random() % 3;
		Logmsg("timeout count: %ld+%ld\n", count, rnd);
		// does player get a free game?
		if (count >= gConfig.snesXBNFreebieThreshold + rnd)
		{
			Logmsg("*** FREE XBN MATCH AWARDED TO LOCAL SNES PLAYER ***\n",count);
			count = 0;
			err = OpqStore_SetKeyValue(os, kXBNFreebieCountKey, &osval);
			if (err != kOpqNoError)
			{
			    Logmsg("OpqStore_SetKeyValue err: %d. Attempting to delete this key...\n", err);
				err = OpqStore_DeleteKeyValue(&state->account->playerAccount.opaqueStore,kXBNFreebieCountKey);
				if (err != kOpqNoError)
					Logmsg("Could not delete this key either! HELP! CALL SRIRAM OR TED!\n");
			}
			state->account->playerModified |= kPA_opaqueStore;
			return 1;
		}
    }
	return 0;
}

void Server_snes_BumpRegisterCount(ServerState *state)
{
    OpaqueStore *os = &state->account->playerAccount.opaqueStore;
    OpaqueStoreValue osval;
    unsigned int ossize = -1;
    Err err;
	long count;

	PLogmsg(LOGP_PROGRESS, "Server_snes_BumpRegisterCount\n");
	
	//Only for non-long distance dudes
	if (state->account->boxAccount.restrictArea & kRestrictArea_longOnlyCapableMask)
		return;
	
	// check timeout threshold
	if (!gConfig.snesXBNFreebieThreshold)
		return;
	
	osval.buf = (char *)&count;
	osval.numMaxBytes = osval.numBytes = sizeof(long);
    err = OpqStore_GetValueSize(os, kXBNFreebieCountKey, &ossize);
    if (err != kOpqNoError)
    	goto remake;
    
	/* make sure the old value was the right size */
	if (ossize != sizeof(long))
	{
	    Logmsg("wrong kXBNFreebieCountKey opaque size\n");
	    goto remake;
	}
	/* get the old value */
	err = OpqStore_GetKeyValue(os, kXBNFreebieCountKey, &osval);
	if (err != kOpqNoError)
	{
	    Logmsg("OpqStore_GetKeyValue err: %d\n", err);
	    goto remake;
	}
	count++;
	Logmsg("timeout count: %d\n", count);
	err = OpqStore_SetKeyValue(os, kXBNFreebieCountKey, &osval);
	if (err != kOpqNoError)
	{
	    Logmsg("OpqStore_SetKeyValue err: %ld.\n", err);
		goto remake;
	}
	state->account->playerModified |= kPA_opaqueStore;
	return;

remake:
	/* create new entry */
	err = OpqStore_DeleteKeyValue(&state->account->playerAccount.opaqueStore,
		kXBNFreebieCountKey);
	if (err != kOpqNoError)
		Logmsg("OpqStore_DeleteKeyValue err: %ld! HELP!\n",err);

	count = 1;
	err = OpqStore_NewKeyValue(os, kXBNFreebieCountKey, &osval);
	if (err != kOpqNoError)
	{
	    Logmsg("OpqStore_NewKeyValue err: %ld\n", err);
	}
	state->account->playerModified |= kPA_opaqueStore;
}





// TourneyLite
//	Format the dial string we want to sent to the box with 
//	the appropriate tournament calling card information.
//	Caller supplies both input and output strings
Boolean
Server_FormatCallingCard(char *dialPrefix, char *phone, char *result)
{
    char *cp;
    char str[256];

    PLogmsg(LOGP_PROGRESS, "Server_FormatCallingCard\n");

    ASSERT(dialPrefix);
    ASSERT(phone);

    strcpy(str, dialPrefix);

    cp = strtok(str, "?");
    if (cp == NULL) {
	result[0] = '\0';
	PLogmsg(LOGP_FLAW, 
	    "GetTourneyCallingCard: invalid calling card string %s\n",
	    dialPrefix);
	return(false);
    }

    if (phone[0] == '1')
	strcpy(phone,&phone[1]);	// if prepended '1', remove it.

    strcpy(result, cp);
    strcat(result, phone);
    strcat(result, strtok(NULL,"\0"));

    return(true);
}

