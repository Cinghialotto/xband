/*
 * Copyright: @ 1995 Catapult Entertainment Inc., all rights reserved
 *
 * $Id: Server_SmartCards.c,v 1.11 1996/01/25 17:51:59 hufft Exp $
 *
 * $Log: Server_SmartCards.c,v $
 * Revision 1.11  1996/01/25  17:51:59  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.10  1996/01/17  15:37:39  felix
 * Added dialogs for single credit and no credits on card
 *
 * Revision 1.9  1996/01/05  18:20:34  felix
 * ifdef'ed out DEBUG dialogs for smartCard card debiting
 *
 * Revision 1.8  1996/01/04  15:10:11  felix
 * Numerous changes to switch from file-based smartcard database to real
 * client-server smartcard database.
 *
 * Revision 1.7  1995/11/17  19:38:13  felix
 * Added "you swapped cards but we will bill you anyway" dialog
 *
 * Revision 1.6  1995/11/14  15:38:49  felix
 * Added check for null state->currentCard, prevCard in Server_DoDebitCardDBUpdate
 *
 * Revision 1.5  1995/11/13  17:57:44  felix
 * changed smartcard database format, changed glaring errors
 *
 * Revision 1.4  1995/11/09  17:15:02  jhsia
 * Added ugly FORCE_DEBIT ifdefs everywhere for testing.  Added OLD_DEBIT_MSG
 * ifdef to debug flaky smartcard debiting on cards with 4680 credits.
 *
 * Revision 1.3  1995/11/08  18:49:34  jhsia
 * Fixed comment delimiters.  Added new Server_SendDebitSmartcard that uses
 * the more intelligent debit message, but left it #ifdefed out so things
 * won't break on existing boxes.
 *
 */

#include "ServerCore.h"
#include "Server.h"
#include "ServerState.h"
#include "Messages.h"
#include "UsrConfg.h"
#include "ServerDataBase.h"
#include "Server_Comm.h"
#include "Common_ReadConf.h"
#include "Common_Missing.h"
#include "../../newrpc/smartdb/SmartDB.h"

#include "SegaIn.h"
#include "DBConstants.h"
#include "StringDB.h"
#include "DBTypes.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <sys/types.h>
#include <sys/time.h>
#include <time.h>

int Server_SendDebitSmartcard(ServerState *state, long numDebits);
Err Database_GetDebitCardInfo(ServerState *state, long serialNumber, 
	DebitCardDBInfo *card);
Err Database_UpdateDebitCardInfo (DebitCardDBInfo *card);

// #define DEBUG_DIALOGS

//
// FORCE_DEBIT here and in ValidateLogin causes the credits to be
// deducted on every connect, and ignores the fancy smartcard logic.
// The dialogs say "(TEST)" in them.
//
// NEW_WAY sends the new credit deduct message to the box, and has
// simplified logic for dealing with the results.
//
// OLD_DEBIT_MSG uses the old message in the NEW_WAY code, which isn't
// recommended since it won't catch card swaps at all.
//

// make sure we're in the NEW_WAY code if we're forcing the simple debits
#ifdef FORCE_DEBIT
# define NEW_WAY
#endif

#ifdef NEW_WAY
//
// Send a message to debit the smartcard.
//
int
Server_SendDebitSmartcard(ServerState *state, long numDebits)
{
	unsigned char 	opCode;
	CreditDebitInfo	info;
	Err				err;
	char			msg[256];
	long			actualDebits;

	// Sanity checks.
	//
	if (state->creditDebitInfo.usingType != kUsingDebitCard) {
		PLogmsg(LOGP_FLAW,
			"GLITCH: SendDebitSmartcard: no debit card installed, usingType=%d\n",
			state->creditDebitInfo.usingType);
		return (kServerFuncAbort);
	}
	if (state->creditDebitInfo.debitCardInfo.type != kCardGPM103) {
		PLogmsg(LOGP_NOTICE,
			"WARNING: SendDebitSmartcard on non-GPM103, type=%d\n",
			state->creditDebitInfo.debitCardInfo.type);
	}
	if (!state->creditDebitInfo.debitCardInfo.serialNumber) {
		PLogmsg(LOGP_NOTICE,
			"WARNING: SendDebitSmartcard for serialNumber==0?!\n");
	}
#ifndef FORCE_DEBIT
	if (state->currentCard == NULL) {
		PLogmsg(LOGP_FLAW,
			"ERROR: SendDebitSmartcard called with currentCard == NULL\n");
		return (kServerFuncAbort);
	}
#endif

#ifndef OLD_DEBIT_MSG
	// Send the debit message
	//
	PLogmsg(LOGP_DETAIL, "SendDebitSmartcard: %ld 0x%.8lx\n",
		numDebits, state->creditDebitInfo.debitCardInfo.serialNumber);

	opCode = msSafeSmartCardDebit;
	Server_SetTransportHold(true);
	Server_TWriteDataSync(state->session, 1, (Ptr)&opCode );
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&numDebits );
	Server_TWriteDataSync(state->session, sizeof(long),
		(Ptr)&state->creditDebitInfo.debitCardInfo.serialNumber );
	Server_SetTransportHold(false);

	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);
#else
	// Send the older debit message
	//
	PLogmsg(LOGP_DETAIL, "SendDebitSmartcard: 0x%.8lX (old msg)\n",
		numDebits, state->creditDebitInfo.debitCardInfo.serialNumber);

	opCode = msLiveDebitSmartCard;
	Server_TWriteDataSync(state->session, 1, (Ptr)&opCode );
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&numDebits );

	err = Server_ReceiveCreditDebitInfoIntoStruct(state, &info);
#endif	/*OLD_DEBIT_MESSAGE*/

	// Box responds with actual number of credits debited.
	//
	Server_TReadDataSync( state->session, sizeof(long), (Ptr)&actualDebits );
	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	switch (actualDebits) {
	case -1:	// no card installed
		Logmsg("SC: bonehead pulled the card out\n");
#ifndef FORCE_DEBIT
		sprintf(msg,
			gettext("Your XBAND SmartCard could not be read.  Your XBAND SmartCard should have %ld credits, and will be updated the next time you connect."), /* DIALOG */
			state->creditDebitInfo.currentCredits);
		Server_SendLargeDialog(state, msg, true);
#else
		Server_SendLargeDialog(state,
			gettext("(TEST) Unable to debit smartcard."), true);
#endif
		break;

	case -2:	// different card installed
		Logmsg("SC: bonehead tried to switch cards\n");
#ifndef FORCE_DEBIT
		sprintf(msg,
			gettext("You switched XBAND SmartCards.  The first one should have %ld credits, and will be updated the next time you connect."), /* DIALOG */
			state->creditDebitInfo.currentCredits);
		Server_SendLargeDialog(state, msg, true);
#else
		Server_SendLargeDialog(state,
			gettext("(TEST) Unable to debit smartcard."), true);
#endif
		break;

	default:	// debited all, some, or none
		if (numDebits == actualDebits) {
#ifndef FORCE_DEBIT
			sprintf(msg,
				gettext("Your XBAND SmartCard now has %d credits."), /*DIALOG*/
				state->currentCard->actualBalance);
			Server_SendLargeDialog(state, msg, true);
#else
			sprintf(msg,
				gettext("(TEST) Your XBAND SmartCard now has %d credits."), /*DIALOG*/
				state->creditDebitInfo.debitCardInfo.creditsLeft - actualDebits);
			Server_SendLargeDialog(state, msg, true);
#endif
		} else if (actualDebits < numDebits) {
			Logmsg("SC: couldn't debit all, wanted %d got %d\n",
				numDebits, actualDebits);
#ifndef FORCE_DEBIT
			sprintf(msg,
				gettext("Your XBAND SmartCard could not be read.  Your XBAND SmartCard should have %ld credits, and will be updated the next time you connect."), /*DIALOG*/
				state->currentCard->actualBalance);
			Server_SendLargeDialog(state, msg, true);
#else
			Server_SendLargeDialog(state,
				gettext("(TEST) Unable to debit smartcard."), true);
#endif

		} else {
			// Really weird, could only happen with a malfunctioning
			// smartcard reader.  We just saw this happen.  Unfortunately
			// the smartcard code on the box doesn't deal with errors very
			// well, so we may actually end up with "numDebits==0" even
			// though we actually debited a huge amount.
			//
			PLogmsg(LOGP_NOTICE, "SC: wacky debit problem\n");
#ifndef FORCE_DEBIT
			sprintf(msg,
				gettext("There was a problem debiting your XBAND SmartCard.  Your card should have %ld credits."), /*DIALOG*/
				state->currentCard->actualBalance);
			Server_SendLargeDialog(state, msg, true);
#else
			Server_SendLargeDialog(state,
				gettext("(TEST) Unable to debit smartcard."), true);
#endif
		}
		break;
	}

	return (kServerFuncOK);
}
#endif /*NEW_WAY*/


#ifndef NEW_WAY
//
// send a message to debit the smartcard.
//
int Server_SendDebitSmartcard(ServerState *state, long numDebits)
{
unsigned char 	opCode;
CreditDebitInfo	info;
int				err;
char			msg[256];
long			actualDebited;

	PLogmsg(LOGP_PROGRESS, "Server_SendDebitSmartcard\n");

	opCode = msLiveDebitSmartCard;
	Server_TWriteDataSync(state->session, 1, (Ptr)&opCode );
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&numDebits );

	err = Server_ReceiveCreditDebitInfoIntoStruct(state, &info);

	if(err != kServerFuncOK)
	{
		PLogmsg(LOGP_FLAW, "Server_SendDebitSmartcard: Server_ReceiveCreditDebitInfoIntoStruct blew up when I tried to live debit the smartcard.\n");
		return(err);
	}

	Server_TReadDataSync( state->session, sizeof(long), (Ptr)&actualDebited );
	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	switch(info.usingType)
	{
		case kUsingCreditToken:
				PLogmsg(LOGP_FLAW, "Server_SendDebitSmartcard: a credit token was received.  This is bogus, because I just cleared the token!");
#ifdef DEBUG_DIALOGS
				Server_SendLargeDialog(state, "(DEBUG) The server could not live debit the card because the box sent a credit token.  This is screwed because I just cleared the token.", true);
#endif
			break;
		
		case kUsingDebitCard:
				Logmsg("Smart card serialno: %ld, credits left: %ld, recharges left: %ld\n",
						info.debitCardInfo.serialNumber,
						(long)info.debitCardInfo.creditsLeft,
						(long)info.debitCardInfo.rechargesLeft);
				if(state->creditDebitInfo.usingType == kUsingDebitCard)
				{
					if(info.debitCardInfo.serialNumber != state->creditDebitInfo.debitCardInfo.serialNumber)
					{
						sprintf(msg, "(DEBUG) Smartcard serial numbers differ.  Initial = %ld (0x%.8lX), Live = %ld (0x%.8lX).", state->creditDebitInfo.debitCardInfo.serialNumber, state->creditDebitInfo.debitCardInfo.serialNumber, info.debitCardInfo.serialNumber, info.debitCardInfo.serialNumber); /*DIALOG*/
#ifdef DEBUG_DIALOGS
						Server_SendDialog(state, msg, true);
#endif
					}
					else
					{
						if(state->creditDebitInfo.debitCardInfo.creditsLeft == 0)
						{
							Logmsg("Dumbcard cannot be debited because it has zero credits.\n");
#ifdef DEBUG_DIALOGS
							Server_SendDialog(state, "(DEBUG) Dumbcard cannot be debited because it has zero credits.", true); /*DIALOG*/
#endif
						}
						else
						{
							if(info.debitCardInfo.creditsLeft != state->creditDebitInfo.debitCardInfo.creditsLeft - numDebits)
							{
								sprintf(msg, "(DEBUG) Smartcard credits did not decrement correctly: old credits = %d, new credits = %d.", /*DIALOG*/
									state->creditDebitInfo.debitCardInfo.creditsLeft, info.debitCardInfo.creditsLeft);
#ifdef DEBUG_DIALOGS
								Server_SendDialog(state, msg, true);
#endif
							}
							else	// all is kool
							{
								sprintf(msg, "(DEBUG) Smartcard debited correctly.  Balance is %d.", info.debitCardInfo.creditsLeft); /*DIALOG*/
#ifdef DEBUG_DIALOGS
								Server_SendDialog(state, msg, true);
#endif
							}
						}
					}
				}

				// Did the card decrement the correct number of times?
				//

				if(info.debitCardInfo.serialNumber != 
				   state->creditDebitInfo.debitCardInfo.serialNumber) 
					sprintf(msg,
						gettext("You switched XBAND SmartCards.  The first one should have %ld credits, and will be updated the next time you connect."), /* DIALOG */
					state->currentCard->actualBalance);
				else if(actualDebited == numDebits)
					if (info.debitCardInfo.creditsLeft == 1) {
						sprintf(msg, gettext("Time for a new XBAND SmartCard!  This one has only one credit left!"));         /* DIALOG */
					} else if (info.debitCardInfo.creditsLeft == 0) {
						sprintf(msg, gettext("Time for a new XBAND SmartCard!  This one has run out of credits."));         /* DIALOG */
					} else {
						sprintf(msg, gettext("Your XBAND SmartCard now has %d credits."), info.debitCardInfo.creditsLeft); /* DIALOG */
					}
				else
					sprintf(msg, gettext("Your XBAND SmartCard could not be read.  Your XBAND SmartCard should have %ld credits, and will be updated the next time you connect."), state->currentCard->actualBalance); /* DIALOG */
				PLogmsg(LOGP_NOTICE, "%s\n", msg);
				Server_SendLargeDialog(state, msg, true);

			break;
		
		case kUsingCreditCard:
#ifdef DEBUG_DIALOGS
				Server_SendDialog(state, "(DEBUG) The server could not live-debit the card because it was removed.", true);	/* DIALOG */
#endif
					sprintf(msg, "Your XBAND SmartCard could not be read.  Your XBAND SmartCard should have %d credits, and will be updated the next time you connect.", state->creditDebitInfo.currentCredits); /* DIALOG */
				PLogmsg(LOGP_NOTICE, "%s\n", msg);
				Server_SendLargeDialog(state, msg, true);
			break;
		
		default:
#ifdef DEBUG_DIALOGS
				Server_SendDialog(state, "(DEBUG) Server_SendDebitSmartcard: got an unknown usingType.", true);	/* DIALOG */
#endif
			break;
	}

	return(kServerFuncOK);
}
#endif	/*OLD_WAY*/


//
// Send a magic smartcard free day token
//
int Server_SendCreditToken(ServerState *state, unsigned long smartCardToken)
{
unsigned char opCode;

	PLogmsg(LOGP_PROGRESS, "Server_SendCreditToken\n");

	opCode = msReceiveCreditToken;
	Server_TWriteDataSync(state->session, 1, (Ptr)&opCode );
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&smartCardToken );

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_SendCreditToken done\n");

	return(kServerFuncOK);
}

//
// Fill card struct with data from debit card database for this card serial number
//
Err
Database_GetDebitCardInfo(ServerState *state, long serialNumber, DebitCardDBInfo *d) 
{
	unsigned char	cardType = 4;
	int				status;

	status = SmartCardDBRead(cardType, serialNumber, d);

	switch(status) {
		case kAck:
			return(kServerFuncOK);	
			break;
		case kCommError:	
			PLogmsg(LOGP_FLAW, 
"Database_GetDebitCardInfo: Error communicating with SmartCard database.\n");
			return(kServerFuncEnd);	
			break;
		case kNotFound:	
			Server_SendLargeDialog(state,
	   			gettext("This is not a valid XBAND SmartCard."),  /* DIALOG */
				true); 
			return(kServerFuncEnd); 
			break;
		default:
			PLogmsg(LOGP_FLAW, 
"Database_GetDebitCardInfo: Unknown return card from SmartCard_DBRead.\n");
			return(kServerFuncEnd);
			break;
	}

	return(kServerFuncOK);	

}

//
//  Update the debit card database for the debit card in the machine now, as well as
//  the debit card installed during the previous connection.  Do only one update
//  if these are the same card.
//
Err Server_DoDebitCardDBUpdate(ServerState *state) 
{
	unsigned char	status;

	// This function is called from Server_UpdateDataBaseAccount and
	// Server_UpdateDataBaseAccountPartial;  We can enter this function 
	// after a SIGHUP occurrs, so take care.
	
	if (gConfig.useDebitCardOnly && state 
		&& state->currentCard && state->prevCard) {

		// These two operations (UpdateFormerBalance and SmartCardDBDebit)
		// could be condensed to use a single API call when previous card
		// serial number and current card serial number are the same.

		status = SmartCardUpdateFormerBalance(state->currentCard->serialNumber,
			state->currentCard->formerBalance);

		if (status == kCommError) {
			PLogmsg(LOGP_FLAW, "Server_DoDebitCardDBUpdate: Error communicating with SmartCard Database (Update)\n");
			return(kServerFuncEnd);
		} else if (status == kOutOfRange) {
			PLogmsg(LOGP_FLAW, "Server_DoDebitCardDBUpdate: Card not in DB spec file.  Someone screwed up smart card database spec file. (Update)\n");
			return(kServerFuncEnd);
		} else if (status == kNotFound) {
			PLogmsg(LOGP_FLAW, "Server_DoDebitCardDBUpdate: Card not in DB.  Should never be here if card not in DB (Update)\n");
			return(kServerFuncEnd);
		} else if (status != kAck)  {
			PLogmsg(LOGP_FLAW, "Server_DoDebitCardDBUpdate: Unknown ret code from SmartCardUpdateFormerBalance (Update)\n");
			return(kServerFuncEnd);
		}

		if (state->commitSmartCardChanges == true) {

			status = SmartCardDBDebit(state->prevCard->serialNumber, 
				state->prevCard->actualBalance - 
				state->creditDebitInfo.currentCredits);

		 PLogmsg(LOGP_PROGRESS, "state->prevCard->actualBalance %d\n", state->prevCard->actualBalance);
		PLogmsg(LOGP_PROGRESS, "state->creditDebitInfo.currentCredits %d\n", state->creditDebitInfo.currentCredits);

			if (status == kCommError) {
				PLogmsg(LOGP_FLAW, "Server_DoDebitCardDBUpdate: Error communicating with SmartCard Database\n (Debit)");
				return(kServerFuncEnd);
			} else if (status == kOutOfRange) {
				PLogmsg(LOGP_FLAW, "Server_DoDebitCardDBUpdate: Card not in DB spec file.  Someone screwed up smart card database spec file. (Debit)\n");
				return(kServerFuncEnd);
			} else if (status == kNotFound) {
				PLogmsg(LOGP_FLAW, "Server_DoDebitCardDBUpdate: Card not in DB.  Should never be here if card not in DB (Debit)\n");
				return(kServerFuncEnd);
			} else if (status != kAck)  {
				PLogmsg(LOGP_FLAW, "Server_DoDebitCardDBUpdate: Unknown ret code from SmartCardDBDebit\n (Debit)");
				return(kServerFuncEnd);
			}
		}
	}

	return(kServerFuncOK);
}

//
// Determine the difference between initial credits read from the debit card and
// current number of credits, and send a 'debit down card' message for this quantity.
//
int Server_UpdateDebitCard(ServerState *state) 
{
short creditDelta;


 	if (((gConfig.useDebitCardOnly) && (state->currentCard)) &&
		(state->currentCard->serialNumber != 0)) {

	PLogmsg(LOGP_PROGRESS, "creditsLeft = %d\n", state->creditDebitInfo.debitCardInfo.creditsLeft);
	PLogmsg(LOGP_PROGRESS, "state->creditDebitInfo.currentCredits = %d\n", state->creditDebitInfo.currentCredits);
	PLogmsg(LOGP_PROGRESS, "state->currentCard->actualBalance = %d\n", state->currentCard->actualBalance);

		if (state->prevCard == state->currentCard)
			creditDelta = state->creditDebitInfo.debitCardInfo.creditsLeft -
    			state->creditDebitInfo.currentCredits;
		else
			creditDelta = state->creditDebitInfo.debitCardInfo.creditsLeft -
    			state->currentCard->actualBalance;

	PLogmsg(LOGP_PROGRESS, "creditDelta %d\n", creditDelta);

	    if (creditDelta > state->creditDebitInfo.debitCardInfo.creditsLeft)
   	 	creditDelta = state->creditDebitInfo.debitCardInfo.creditsLeft;

		if (creditDelta > 0) {

			// This should be removed once more testing is done.

		    if (creditDelta > gConfig.maxSmartCardDebits) {
				PLogmsg(LOGP_PROGRESS, "Server_UpdateDebitCard: STRANGE! debit exceeds maximum -- trimming from %d to %d\n",
				creditDelta, gConfig.maxSmartCardDebits);
				creditDelta = gConfig.maxSmartCardDebits;
			}
		
			PLogmsg(LOGP_PROGRESS, "Server_UpdateDebitCard: Sending card debit message for %d credits\n",
			creditDelta);

		// Send debit message to the card.  

			Server_SendDebitSmartcard(state, creditDelta);

		}

	}

	return (kServerFuncOK);
}
