/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_AddressBook.c,v 1.27 1996/01/25 17:51:41 hufft Exp $
 *
 * $Log: Server_AddressBook.c,v $
 * Revision 1.27  1996/01/25  17:51:41  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.26  1996/01/16  17:56:08  fadden
 * Add an extra kMPheaderExpansion bytes on the player info compression buffer,
 * and check the return value from malloc().
 *
 * Revision 1.25  1995/12/11  18:00:29  ansell
 * Moved some PLogmsg()s from DBUG up to higher priority since they represented
 * error conditions.
 *
 * Revision 1.24  1995/10/30  17:48:41  jhsia
 * put a normal quote into "can't"; was a smart quote, which was causing the i18n
 * stuff to not match (fadden)
 *
 * Revision 1.23  1995/10/03  17:05:23  ansell
 * Added beter check for player being deleted/re-added.  Set lastplayed date to
 * 1 on deleted entry so that re-used entries never show weird dates if the
 * entry doesn't get properly re-initialized (I think).
 *
 * Revision 1.22  1995/10/03  16:43:05  fadden
 * Increase buffer size for 'sjne' player info compress.
 *
 * Revision 1.21  1995/09/27  15:42:25  fadden
 * Added 'sjne' entry to Server_SendPlayerInfo.  Use JRHuff for Japanese boxes
 * in Server_snes_SendPlayerInfo.
 *
 * Revision 1.20  1995/09/20  14:29:32  ansell
 * Added some stuff to avoid some error messages in the logs.
 *
 * Revision 1.19  1995/09/15  15:55:34  ansell
 * Changed some log messages to lower priority now that the addr book update
 * stuff is stable.
 *
 * Revision 1.18  1995/09/13  14:24:21  ted
 * Fixed warnings.
 *
 * Revision 1.17  1995/08/30  12:27:59  ansell
 * Needed one more check to differentiate between old deleted entries and
 * entries being delete/added via a peer connect.
 *
 * Revision 1.16  1995/08/30  00:33:27  ansell
 * OK.  This time it really works...no...I mean it!  Added code to check and see
 * if one of the "deleted" entries is actually one of the "to be added" entries
 * in which case we don't delete it.  Later, when adding entries from a peer
 * connect, we also see if it is replacing an old entry or just updating a current
 * one.  This should cover it...until the next bug sneaks out...
 *
 * Revision 1.15  1995/08/29  17:27:59  ansell
 * More stuff to take care of win/loss stats in the player list.
 *
 * Revision 1.14  1995/08/29  16:36:43  ansell
 * When we delete someone from the player list we need to completely
 * "blow out" the info that was previously there so there are no strange
 * remnants when we update an entry after a peer connect.
 *
 * Revision 1.13  1995/08/16  13:04:17  ansell
 * Changed case where the "new" entry was an update from a peer-connect and we
 * don't want to re-set the win/loss and lastplayed stuff.
 *
 * Revision 1.12  1995/07/26  13:54:45  ansell
 * Added support for periodic checking of personal info changes of players
 * contained in address book.
 * Also added support for the box sending a '-1' count to indicate when all
 * the address book entries have been deleted.
 *
 * Revision 1.11  1995/07/17  14:35:41  fadden
 * Trivial change for ansell.
 *
 * Revision 1.10  1995/07/10  20:56:39  rich
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.9  1995/06/07  16:24:02  fadden
 * Added some logmsgs.
 *
 * Revision 1.8  1995/05/26  23:46:00  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_AddressBook.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		<11>	11/23/94	ATM		UpdateAddrBookAfterGame needs player # too.
		<10>	11/17/94	KD		Update dialog text (doug/kon).
		 <9>	11/16/94	ATM		Sanity-check args to UpdateAddrBookAfterGame.
		 <8>	 11/9/94	DJ		Renamed some DB routines to DataBaseUtil_ and also to WrapperDB_
									(for Oracle).
		 <7>	 11/9/94	ATM		Fix a logmsg.
		 <6>	 11/9/94	ATM		Added a logmsg for an assertion failure.
		 <5>	 11/8/94	DJ		Updating addrbook modified.
		 <4>	 11/8/94	DJ		Extracting datelastplayed, wins, and losses from addrbook in
									SendAddressBook.
		 <3>	 11/8/94	ATM		Added Server_UpdateAddrBookAfterGame.  Who knows, it might even
									work.
		 <2>	10/26/94	DJ		Made Server_SendAddressBook not blow box up if lots-o-addrbook
									entries.
		 <1>	10/25/94	DJ		Moved in stuff from Server_ProcessSendQ.c and added
									Server_SendAddressBook.

	To Do:
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>

#include "ServerCore.h"
#include "Server.h"
#include "ServerState.h"
#include "ServerDataBase.h"
#include "ServerDataBase_priv.h"
#include "Common.h"
#include "Common_PlatformID.h"
#include "Common_ReadConf.h"
#include "MegaPack.h"

#include "DBTypes.h"
#include "Mail.h"
#include "SendQ.h"
#include "BoxSer.h"
#include "Messages.h"
#include "PlayerDB.h"
#include "AddressBook.h"
#include "StringDB.h"

#include "FilterHandle.h"


//
// Local prototypes.
//
PRIVATE int Server_sega_SendPlayerInfo(ServerState *state, PlayerInfo *playerInfo);
PRIVATE int Server_snes_SendPlayerInfo(ServerState *state, PlayerInfo *playerInfo);
PRIVATE int Server_CheckAddressBook(ServerState *state);



//
// Send the entire address book down, being careful not to overfill the box.
//
// Only used for box restores.  Think about renaming this to
// "Server_RestoreAddressBook".
//
// (It looks like this should come after the address book validation stuff,
// so that state->addrValidationData.count doesn't include bogus entries.
// I'm not sure if that will work or not though, since the validation stuff
// may be making assumptions about what's on the box.)
//
int Server_SendAddressBook(ServerState *state, Account *account)
{
ServerPlayerInfo 	*splayerInfo;
long				a;
userIdentification	myUserID, addrUserID, updatedAddrUserID;
Err					retVal;
long				count;

	PLogmsg(LOGP_PROGRESS, "Server_SendAddressBook\n");

	// If we are restoring the account, no need to check again later.
	gConfig.checkAddrBook = false;

	memset(&myUserID, 0, sizeof(userIdentification));
	myUserID.box = account->boxAccount.box;
	myUserID.userID = account->playerAccount.player;


	//
	// You must be careful to avoid blowing the box's address book up.
	// This will happen if server tries to send more than kMaxAddressBookEntries
	// (ie. 10) addressbook entries to the box.
	//
	// This might occur for example if box crashes.  Prior to crash the box has
	// a full address book.  Before logging into XBand again the frustrated
	// user goes and reenters 1 or more address book items (tries to restore
	// his/her own account by hand!).  Then box logs in.  We go and happily
	// restore the old address book entries here.  Then later on in the server,
	// in Server_ProcessAddrBookValidations, we validate all the addrbook
	// entries that the user typed in.  * But * we just filled up the address
	// book with a restore.... so Server_ProcessAddrBookValidations will go
	// and blow the box up by sending more addrbook entries than will fit.
	//
	// This is a cheezy way to avoid that.  Simply figure out how many
	// unvalidated addr book entries are incoming from the box (hopefully 0,
	// but could be lots if user tried to "hand restore" own box).  Make sure
	// we don't restore more than
	//	kMaxAddressBookEntries - state->addrValidationData.count
	// so that Server_ProcessAddrBookValidations can't blow the world up!
	// 10/26/94  dj
	//
	count = kMaxAddressBookEntries - state->addrValidationData.count;

	// Loop over all address book entries we know about.
	//
	for(a = 0; a < kMaxAddressBookEntries; a++)
	{
		// Blank spots are marked with kUncorrelatedEntry; skip over those.
		//
		if(account->playerAccount.addressBook[a].serverUniqueID != kUncorrelatedEntry)
		{
			PLogmsg(LOGP_DBUG, "Restoring addr book %d/%d (%ld,%ld)[%d]\n",
				a, account->playerAccount.addressBook[a].serverUniqueID,
				account->playerAccount.addressBook[a].box.box,
				account->playerAccount.addressBook[a].box.region,
				account->playerAccount.addressBook[a].playerNumber);

			memset(&addrUserID, 0, sizeof(userIdentification));
			addrUserID.box = account->playerAccount.addressBook[a].box;
			addrUserID.userID = account->playerAccount.addressBook[a].playerNumber;
			
			if(WrapperDB_FindUserIdentification(&addrUserID, &updatedAddrUserID) != kNoError)
			{
				// This entry in the addr book doesn't seem to exist anymore.
				// Delete it.
				//
				PLogmsg(LOGP_DBUG,
					"  Eliminating addr book entry for nonexistent user\n");
				account->playerAccount.addressBook[a].serverUniqueID = kUncorrelatedEntry;
				account->playerModified |= kPA_addressBook;
				continue;
			}


			// Avoid overloading the box's address book by dropping any extras
			// on the floor.  This triggers once we have sent down enough
			// entries to raise the total to 10.
			//
			if (--count < 0) {
				account->playerAccount.addressBook[a].serverUniqueID = kUncorrelatedEntry;
				account->playerModified |= kPA_addressBook;
				PLogmsg(LOGP_PROGRESS,
					"SendAddressBook: ignoring overflow addrbook entry\n");
				continue;
			}

			splayerInfo = WrapperDB_FindPlayerInfo(&updatedAddrUserID, &myUserID);
			if(!splayerInfo)
			{
				ERROR_MESG("WrapperDB_FindUserIdentification returned OK, but WrapperDB_FindPlayerInfo couldn't find a playerInfo!?");
				return (kServerFuncAbort);
			}

			// Get the most up to date wins, losses, and datelastplayed from my
			// addr book.
			//
			splayerInfo->playerInfo.serverUniqueID = account->playerAccount.addressBook[a].serverUniqueID;
			splayerInfo->playerInfo.dateLastPlayed = account->playerAccount.addressBook[a].lastPlayed;
			splayerInfo->playerInfo.wins = account->playerAccount.addressBook[a].wins;
			splayerInfo->playerInfo.losses = account->playerAccount.addressBook[a].losses;

			// Convert the icon.
			//
			splayerInfo->playerInfo.userId.ROMIconID =
				Common_ConvertROMIconID(splayerInfo->iconPlatformID,
					state->platformID,
					splayerInfo->playerInfo.userId.ROMIconID);
			splayerInfo->iconPlatformID = state->platformID;

			retVal = Server_SendPlayerInfo(state, &splayerInfo->playerInfo,
				myUserID.userID);
			if(retVal != kServerFuncOK)
				return(retVal);
		}
	}

	PLogmsg(LOGP_PROGRESS, "Server_SendAddressBook done\n");
	return(kServerFuncOK);
}


int Server_CheckAddressBook(ServerState *state)
{
Account				*account;
AddressBook			*addressBook;
char				pooMsg[1000];
long				i, numDeleted = 0;
userIdentification	addrUserIDList[kMaxAddressBookEntries];
ServerPlayerInfo	**splayerInfoList;
long				index;
Err					retVal;

	PLogmsg(LOGP_PROGRESS, "Server_CheckAddressBook\n");

	account = state->account;
	ASSERT(account);
	addressBook = account->playerAccount.addressBook;

	// Loop over all address book entries we know about.
	//
	for(i = 0; i < kMaxAddressBookEntries; i++)
	{
		// Blank spots are marked with kUncorrelatedEntry; skip over those.
		//
		if(addressBook[i].serverUniqueID != kUncorrelatedEntry)
		{
			memset(&addrUserIDList[i], 0, sizeof(userIdentification));
			addrUserIDList[i].box = addressBook[i].box;
			addrUserIDList[i].userID = addressBook[i].playerNumber;
		}
		else
		{
			// Tell database routine to ignore this entry.
			memset(&addrUserIDList[i], 0, sizeof(userIdentification));
			addrUserIDList[i].box.box = -1;
			addrUserIDList[i].box.region = -1;
			addrUserIDList[i].userID = -1;
		}
	}

	splayerInfoList = WrapperDB_FindPlayerInfoChanges(addrUserIDList, 
		&state->loginData.userID, account->playerAccount.lastAddrBookCheck);

	if (!splayerInfoList)
	{
		PLogmsg(LOGP_NOTICE, "Failed looking up player info changes.\n");
		return(kServerFuncAbort);
	}

	for (i=0; splayerInfoList[i]; i++)
	{
		index = splayerInfoList[i]->playerInfo.serverUniqueID;

		PLogmsg(LOGP_DBUG, "Changing addr book %d/%d (%ld,%ld)[%d]\n",
			index, addressBook[index].serverUniqueID, 
			addressBook[index].box.box,
			addressBook[index].box.region, addressBook[index].playerNumber);

		if (splayerInfoList[i]->iconPlatformID != -1)
		{
			// Get the most up to date wins, losses, and datelastplayed 
			// from my addr book.
			//
			splayerInfoList[i]->playerInfo.serverUniqueID = 
				addressBook[index].serverUniqueID;
			splayerInfoList[i]->playerInfo.dateLastPlayed = 
				addressBook[index].lastPlayed;
			splayerInfoList[i]->playerInfo.wins = addressBook[index].wins;
			splayerInfoList[i]->playerInfo.losses = addressBook[index].losses;

			// Convert the icon.
			//
			splayerInfoList[i]->playerInfo.userId.ROMIconID =
				Common_ConvertROMIconID(splayerInfoList[i]->iconPlatformID,
					state->platformID,
					splayerInfoList[i]->playerInfo.userId.ROMIconID);

			retVal = Server_SendPlayerInfo(state, 
				&splayerInfoList[i]->playerInfo,
				state->loginData.userID.userID);
			if(retVal != kServerFuncOK)
				return(retVal);
		}
		else
		{
			// This entry in the addr book doesn't seem to exist anymore.
			// Delete it.
			//
			PLogmsg(LOGP_DBUG,
				"  Eliminating addr book entry for nonexistent user\n");

			numDeleted++;
			retVal = Server_SendDeleteAddressBookEntry(state, 
				&addrUserIDList[index], state->loginData.userID.userID);
			if(retVal != kServerFuncOK)
				return(retVal);

			addressBook[index].serverUniqueID = kUncorrelatedEntry;
			account->playerModified |= kPA_addressBook;
		}
		DataBaseUtil_ReleaseServerPlayerInfo(splayerInfoList[i]);
	}
	free(splayerInfoList);

	if (numDeleted > 0)
	{
		if (numDeleted == 1)
			sprintf(pooMsg, gettext("One of the players in your Player List no longer has an XBAND account.  That player has been deleted.")); /* DIALOG */
		else
			sprintf(pooMsg, gettext("%ld of the players in your Player List no longer have an XBAND account.  The players have been deleted."), numDeleted); /* DIALOG */
		retVal = Server_SendDialog(state, pooMsg, false);
	}

	account->playerAccount.lastAddrBookCheck = state->timeOfThisConnect;
	account->playerModified |= kPA_lastAddrBookCheck;

	PLogmsg(LOGP_PROGRESS, "Server_CheckAddressBook done\n");
	return(kServerFuncOK);
}


//
// go thru the addr book and validate the entries.
// if valid, send em, if not, send dialog and remove msg
//
//
// This brings up the issue of slave registers, then changes playerinfo while 
// waiting.  this is exchanged.  but the handle is non-unique or something, so 
// the data that was sent to the opponent during peer connect is invalid.  This
// will be dealt with by either not letting slaves change Info while waiting, 
// or by them only exchanging validated Info and queuing up a changed Info if 
// they change while waiting for master to call.
//
// IMPORTANT: this must come before game results are recorded.  Otherwise
// we may end up trying to update an entry in the server's copy of the
// address book before it exists.
//
int Server_ProcessAddrBookValidations(ServerState *state)
{
short 				i, j;
char				pooMsg[1000];
userIdentification	addrUserIDList[kMaxAddressBookEntries];
ServerPlayerInfo	**splayerInfoList;
long				index;
ServerPlayerInfo	*splayerInfo;
Boolean				found, checkAddrBook = false;
messOut				opCode;
unsigned char		serverUniqueID, tmpUniqueID;
unsigned char		addrBookIDs[kMaxAddressBookEntries];
int					retVal = 0;
userIdentification	updatedUserIdent;
AddressBook			*addressBook;
Account				*account;
long				numDeleted = 0;


	PLogmsg(LOGP_PROGRESS, "Server_ProcessAddrBookValidations\n");
	ASSERT(state->validFlags & kServerValidFlag_AddressBook);
	ASSERT(state->validFlags & kServerValidFlag_Account);

	account = state->account;
	ASSERT(account);
	addressBook = state->account->playerAccount.addressBook;

	if (gConfig.checkAddrBook && 
		(state->timeOfThisConnect - account->playerAccount.lastAddrBookCheck) 
			>= (gConfig.checkAddrBookFreq*60))
	{
		checkAddrBook = true;
	}

	if(state->addrValidationData.count <= 0)
	{
		// Have all the entries been deleted?
		if (state->addrValidationData.count == -1)
		{
			PLogmsg(LOGP_DBUG, "All addresses deleted on box; removing from database.\n");
			for(i = 0; i < kMaxAddressBookEntries; i++)
			{
				// Mark as 'deleted' and clobber the info.
				addressBook[i].serverUniqueID = kUncorrelatedEntry;	
				addressBook[i].box.box = -1;
				addressBook[i].box.region = -1;
				addressBook[i].playerNumber = 0;
				addressBook[i].lastPlayed = 1;
				addressBook[i].wins = 0;
				addressBook[i].losses = 0;
				account->playerModified |= kPA_addressBook;
			}
			return(kServerFuncOK);
		}

		// There were no changes.  Is it time to check for updates?
		if (checkAddrBook)
			return(Server_CheckAddressBook(state));

		return(kServerFuncOK);
	}

	ASSERT(state->addrValidationData.count <= kMaxAddressBookEntries);
	if(state->addrValidationData.count > kMaxAddressBookEntries)
	{
		PLogmsg(LOGP_NOTICE,
			"Server_ProcessAddrBookValidations: there are %ld entries in the user's address book, but %ld is the maximum!?!?!\n",
			state->addrValidationData.count,  kMaxAddressBookEntries);
		return(kServerFuncAbort);
	}


	//
	// The serverUniqueID of a newly typed in address book entry is set to 
	// kUncorrelatedEntry (0xff) on the box.  When the server validates the 
	// entry, it creates a new serverUniqueID and sends it to the box, along 
	// with the entry's info text.  The serverUniqueID actually corresponds 
	// one-to-one to the index in the playerAccount addressBook.  So it is 0 
	// thru kMaxAddressBookEntries - 1.
	//
	

	// Set 'em all to kUncorrelatedEntry
	//
	for(i = 0; i < kMaxAddressBookEntries; i++)
		addrBookIDs[i] = kUncorrelatedEntry;

	// then scan through what's on the box and flag those as valid.
	//
	for(i = 0; i < state->addrValidationData.count; i++)
	{
		serverUniqueID = state->addrValidationData.items[i].serverUniqueID;

		if (serverUniqueID != kUncorrelatedEntry)
		{

			if (serverUniqueID >= kMaxAddressBookEntries)
			{
				PLogmsg(LOGP_NOTICE, "Box passed up bad serverUniqueID %d\n",
					serverUniqueID);
				continue;
			}
			addrBookIDs[serverUniqueID] = serverUniqueID;
		}
	}

	// now go thru the addr book in the playerAccount and blow away anything 
	// that's no longer on the box (this happens when the user deleted an entry)
	//
	for(i = 0; i < kMaxAddressBookEntries; i++)
	{
		if(addressBook[i].serverUniqueID != kUncorrelatedEntry)
		{
			if(addrBookIDs[i] == kUncorrelatedEntry)
			{
				// Before we go and delete this guy, check to see if 
				// he might be one of the fellas we are going to 'add'
				// later.  This happens on player info updates after
				// peer connects due to the delete/add thingy.
				//
				found = false;
				for (j = 0; j < state->addrValidationData.count; j++)
				{
					// Found uncorrelated entry on box (newly added) that 
					// exactly matches one already in the database.
					//
					if (state->addrValidationData.items[j].serverUniqueID ==
						kUncorrelatedEntry &&
						state->addrValidationData.items[j].userIdent.box.box ==
						addressBook[i].box.box &&
						state->addrValidationData.items[j].userIdent.box.region
						== addressBook[i].box.region &&
						state->addrValidationData.items[j].userIdent.userID ==
						addressBook[i].playerNumber)
					{
						PLogmsg(LOGP_DETAIL, "Address (%d,%d)[%d] changed on box, to be updated in database.\n",
							addressBook[i].box.box,
							addressBook[i].box.region,
							addressBook[i].playerNumber);

						found = true;
						break;
					}
				}

				// He isn't going to be added, so delete him.
				//
				if (!found)
				{
					PLogmsg(LOGP_DETAIL, "Address (%d,%d)[%d] deleted on box, removing from database.\n",
						addressBook[i].box.box,
						addressBook[i].box.region,
						addressBook[i].playerNumber);

					addressBook[i].box.box = -1;
					addressBook[i].box.region = -1;
					addressBook[i].playerNumber = 0;
					addressBook[i].lastPlayed = 1;
					addressBook[i].wins = 0;
					addressBook[i].losses = 0;
					addressBook[i].serverUniqueID = kUncorrelatedEntry;
					account->playerModified |= kPA_addressBook;
				}
			}
		}
		else if(addrBookIDs[i] != kUncorrelatedEntry)
		{
			// It is impossible for the box to have a correlated entry that
			// the server doesn't have (unless the database crashed... 
			// shit!)
			//
			ERROR_MESG("Server_ProcessAddrBookValidations: the box has a correlated entry that the playerAccount doesn't have!?!?!?  Did the server crash or bounce since last login?\n");

			// it is very bad to drop the connection, so I will cobble 
			// something up here.
			addressBook[i].serverUniqueID = i;
			addressBook[i].box.box = -1;
			addressBook[i].box.region = -1;

			account->playerModified |= kPA_addressBook;

			//
			// *** we should probably delete the entry from the box, 
			// because we don't have a record of it
			// *** and the box doesn't send us the info we need to fill it 
			// out.  This is caused by either the
			// *** server database losing its mind or a bug in this routine 
			// where we didn't update the addrbook
			// *** properly.  The other option is to directly query the box
			// for the addrbook info of these
			// *** unknown entries.  Hmmm.  -dj 10/7/94
			//
			// ** for now i will just assign them bogus -1, -1.  Be careful
			// to check for this when restoring a box!
			//
		}
	}

	PLogmsg(LOGP_PROGRESS, "Server_ProcessAddrBookValidations: Checking for new entries and for changes.\n");
	//
	// Now go through what's on the box and check new entries for validity.
	//
	for(i = 0; i < state->addrValidationData.count; i++)
	{
		if (state->addrValidationData.items[i].serverUniqueID == 
			kUncorrelatedEntry)
		{
			if (checkAddrBook)
			{
				// Tell database routine to ignore this entry.
				memset(&addrUserIDList[i], 0, sizeof(userIdentification));
				addrUserIDList[i].box.box = -1;
				addrUserIDList[i].box.region = -1;
				addrUserIDList[i].userID = -1;
			}
			PLogmsg(LOGP_DETAIL, "Server_ProcessAddrBookValidations: New entry found (%d, %d)[%d].\n",
			state->addrValidationData.items[i].userIdent.box.box,
			state->addrValidationData.items[i].userIdent.box.region,
			state->addrValidationData.items[i].userIdent.userID);
			// This has just been added to his addr book.
			//
			if(WrapperDB_FindUserIdentification(&state->addrValidationData.items[i].userIdent, &updatedUserIdent) != kNoError)
			{
				if(state->addrValidationData.items[i].userIdent.box.box == -1)
				{
					// I18N Appears: When player adds a playername to their 
					// Player List, but that player does not have an account 
					// with XBAND.
					//
					sprintf(pooMsg, gettext("%s does not exist on XBAND.  %s has been deleted from your Player List."),								/* DIALOG */
						state->addrValidationData.items[i].userIdent.userName, 
						state->addrValidationData.items[i].userIdent.userName);
					retVal = Server_SendDialog(state, pooMsg, false);
				}
				else
				{
					// This is an extremely extremely wacky case.  The address 
					// book entry came from a peer-to-peer connect (because the
					// userIdent.box.box != -1), yet the server claims that 
					// account doesn't exist.  This must indicate that the box 
					// is trashed, or the server is totally screwed (since we 
					// presumably just brokered this connection a few minutes 
					// ago), or someone is hacking us.
					//	HACKER ALERT
					//
					Logmsg("AddressBook: found unknown boxid (%ld,%ld)\n",
						state->addrValidationData.items[i].userIdent.box.box,
						state->addrValidationData.items[i].userIdent.box.region);
					ERROR_MESG("HACKER ALERT: this is extremely unlikely since we just brokered this peer-to-peer connection in the last few minutes, yet the account doesn't exist now?!?!?\n");

					numDeleted++;
				}
			}
			else
			{
				//
				// This is a valid entry
				//
				if(updatedUserIdent.box.region == 
					state->loginData.userID.box.region &&
					updatedUserIdent.box.box == state->loginData.userID.box.box)
				{
					// You can't add someone on your own box (eg. yourself or 
					// sister) to your addr book.
					//
					// I18N Appears: When player adds a player on his own modem 
					//          to his Player List.  This is not supported on 
					//			XBAND.
					//
					sprintf(pooMsg, gettext("You can't add yourself or players who share your XBAND Video Game Modem to your Player List.  %s has been deleted."), state->addrValidationData.items[i].userIdent.userName);	/* DIALOG */
					retVal = Server_SendDialog(state, pooMsg, false);
					
					continue;
				}

				splayerInfo = WrapperDB_FindPlayerInfo(&updatedUserIdent,
					&state->loginData.userID);

				if(!splayerInfo)
				{
					ERROR_MESG("WrapperDB_FindUserIdentification returned OK, but WrapperDB_FindPlayerInfo couldn't find a playerInfo!?");
					return(kServerFuncAbort);
				}


				// Check for -1 boxid.  if so, then dude typed this addr book 
				// entry in, if not -1, then this addr book entry came from a 
				// peer-to-peer connect, in which case i just upload a 
				// serverUniqueID instead of the whole playerInfo.
				//
				if(state->addrValidationData.items[i].userIdent.box.box == -1)
				{
					// This came from a user typing in the handle.  send the 
					// playerInfo to their addr book.
					//
					tmpUniqueID = kMaxAddressBookEntries;
					for(serverUniqueID = 0; 
						serverUniqueID < kMaxAddressBookEntries; 
						serverUniqueID++)
					{
						// If the player is already there, use the entry.
						//
						if (addressBook[serverUniqueID].box.box ==
							splayerInfo->playerInfo.userId.box.box &&
							addressBook[serverUniqueID].box.region ==
							splayerInfo->playerInfo.userId.box.region &&
							addressBook[serverUniqueID].playerNumber ==
							splayerInfo->playerInfo.userId.userID)
						{
							tmpUniqueID = serverUniqueID;
							break;
						}

						// Otherwise, use the first available entry.
						//
						if (addrBookIDs[serverUniqueID] == kUncorrelatedEntry
							&& tmpUniqueID == kMaxAddressBookEntries)
							tmpUniqueID = serverUniqueID;
					}
					serverUniqueID = tmpUniqueID;

					ASSERT(serverUniqueID != kMaxAddressBookEntries);

					addrBookIDs[serverUniqueID] = serverUniqueID;
					splayerInfo->playerInfo.serverUniqueID = serverUniqueID;

					// Convert the icon.
					//
					splayerInfo->playerInfo.userId.ROMIconID =
						Common_ConvertROMIconID(splayerInfo->iconPlatformID,
							state->platformID,
							splayerInfo->playerInfo.userId.ROMIconID);

					retVal = Server_SendPlayerInfo(state,
						&splayerInfo->playerInfo,
						state->addrValidationData.items[i].ownerUserID);
					
					//
					// Add it to the playerAccount so we can restore it if box 
					// crashes.
					//
					addressBook[serverUniqueID].serverUniqueID = serverUniqueID;
					addressBook[serverUniqueID].box = 
						splayerInfo->playerInfo.userId.box;
					addressBook[serverUniqueID].playerNumber = 
						splayerInfo->playerInfo.userId.userID;
					addressBook[serverUniqueID].lastPlayed = 
						splayerInfo->playerInfo.dateLastPlayed;
					addressBook[serverUniqueID].wins = 
						splayerInfo->playerInfo.wins;
					addressBook[serverUniqueID].losses = 
						splayerInfo->playerInfo.losses;
					
					account->playerModified |= kPA_addressBook;
				}
				else
				{
					// This came from a peer connect.  the info has been 
					// validated by a server.  We just need to assign
					// it a serverUniqueID.
					//
					tmpUniqueID = kMaxAddressBookEntries;
					for(serverUniqueID = 0; 
						serverUniqueID < kMaxAddressBookEntries; 
						serverUniqueID++)
					{
						// If the player is already there, use the entry.
						//
						if (addressBook[serverUniqueID].box.box ==
							splayerInfo->playerInfo.userId.box.box &&
							addressBook[serverUniqueID].box.region ==
							splayerInfo->playerInfo.userId.box.region &&
							addressBook[serverUniqueID].playerNumber ==
							splayerInfo->playerInfo.userId.userID)
						{
							tmpUniqueID = serverUniqueID;
							break;
						}

						// Otherwise, use the first available entry.
						//
						if (addrBookIDs[serverUniqueID] == kUncorrelatedEntry
							&& tmpUniqueID == kMaxAddressBookEntries)
							tmpUniqueID = serverUniqueID;
					}
					serverUniqueID = tmpUniqueID;

					ASSERT(serverUniqueID != kMaxAddressBookEntries);

					addrBookIDs[serverUniqueID] = serverUniqueID;

					retVal = Server_SendCorrelateAddressBookEntry(state,
						&splayerInfo->playerInfo.userId,
						state->addrValidationData.items[i].ownerUserID,
						serverUniqueID);

					//
					// Add it to the playerAccount so we can restore it if box 
					// crashes.  If we are replacing a deleted entry then
					// make sure the win/loss record is clear.  Should be 
					// done above, but old servers didn't have that code and
					// deleted entries may still have win/loss records.
					//
					if (addressBook[serverUniqueID].serverUniqueID ==
						kUncorrelatedEntry)
					{
						addressBook[serverUniqueID].lastPlayed = 1;
						addressBook[serverUniqueID].wins = 0;
						addressBook[serverUniqueID].losses = 0;
					}
					addressBook[serverUniqueID].serverUniqueID = serverUniqueID;
					addressBook[serverUniqueID].box = 
						splayerInfo->playerInfo.userId.box;
					addressBook[serverUniqueID].playerNumber = 
						splayerInfo->playerInfo.userId.userID;
					account->playerModified |= kPA_addressBook;
				}

				DataBaseUtil_ReleaseServerPlayerInfo(splayerInfo);
			}
		}
		else
		{
			// This item is in their addr book.  We add it to the list of
			// accounts to do a lookup on later.
			if (checkAddrBook)
			{
				// Get the index from the validation data and use the
				// info in the database to make the check (the box only
				// sends up userIdent info for uncorrelated entries).
				serverUniqueID = 
					state->addrValidationData.items[i].serverUniqueID;

				memset(&addrUserIDList[i], 0, sizeof(userIdentification));
				addrUserIDList[i].box = addressBook[serverUniqueID].box;
				addrUserIDList[i].userID = 
					addressBook[serverUniqueID].playerNumber;
			}
		}
	}
	
	if (checkAddrBook)
	{
		for (i = state->addrValidationData.count; i < kMaxAddressBookEntries;
			i++)
		{
			// Ignore all the rest of the entries
			memset(&addrUserIDList[i], 0, sizeof(userIdentification));
			addrUserIDList[i].box.box = -1;
			addrUserIDList[i].box.region = -1;
			addrUserIDList[i].userID = -1;
		}

		splayerInfoList = WrapperDB_FindPlayerInfoChanges(addrUserIDList,
			&state->loginData.userID, account->playerAccount.lastAddrBookCheck);

		if (!splayerInfoList)
		{
			PLogmsg(LOGP_NOTICE, "Failed looking up player info changes.\n");
			return(kServerFuncAbort);
		}

		for (i=0; splayerInfoList[i]; i++)
		{
			// Indexed indices
			index = splayerInfoList[i]->playerInfo.serverUniqueID;
			index = state->addrValidationData.items[index].serverUniqueID;

			PLogmsg(LOGP_DETAIL, "Changing addr book %d/%d (%ld,%ld)[%d]\n",
				index, addressBook[index].serverUniqueID, 
				addressBook[index].box.box,
				addressBook[index].box.region, addressBook[index].playerNumber);

			if (splayerInfoList[i]->iconPlatformID != -1)
			{
				// Get the most up to date wins, losses, and datelastplayed 
				// from my addr book.
				//
				splayerInfoList[i]->playerInfo.serverUniqueID = 
					addressBook[index].serverUniqueID;
				splayerInfoList[i]->playerInfo.dateLastPlayed = 
					addressBook[index].lastPlayed;
				splayerInfoList[i]->playerInfo.wins = addressBook[index].wins;
				splayerInfoList[i]->playerInfo.losses = 
					addressBook[index].losses;

				// Convert the icon.
				//
				splayerInfoList[i]->playerInfo.userId.ROMIconID =
					Common_ConvertROMIconID(splayerInfoList[i]->iconPlatformID,
						state->platformID,
						splayerInfoList[i]->playerInfo.userId.ROMIconID);

				retVal = Server_SendPlayerInfo(state, 
					&splayerInfoList[i]->playerInfo,
					state->loginData.userID.userID);
				if(retVal != kServerFuncOK)
					return(retVal);
			}
			else
			{
				// This entry in the addr book doesn't seem to exist anymore.
				// Delete it.
				//
				PLogmsg(LOGP_DBUG,
					"  Eliminating addr book entry for nonexistent user\n");

				numDeleted++;
				retVal = Server_SendDeleteAddressBookEntry(state, 
					&addrUserIDList[index], state->loginData.userID.userID);
				if(retVal != kServerFuncOK)
					return(retVal);

				addressBook[index].serverUniqueID = kUncorrelatedEntry;
			}
			DataBaseUtil_ReleaseServerPlayerInfo(splayerInfoList[i]);
		}
		free(splayerInfoList);
	}

	if (checkAddrBook)
	{
		account->playerAccount.lastAddrBookCheck = state->timeOfThisConnect;
		account->playerModified |= kPA_lastAddrBookCheck;
	}

	if (numDeleted > 0)
	{
		if (numDeleted == 1)
			sprintf(pooMsg, gettext("One of the players in your Player List no longer has an XBAND account.  That player has been deleted.")); /* DIALOG */
		else
			sprintf(pooMsg, gettext("%ld of the players in your Player List no longer have an XBAND account.  The players have been deleted."), numDeleted); /* DIALOG */
		retVal = Server_SendDialog(state, pooMsg, false);
	}

	//
	// Tell the box to delete any uncorrelated address book entries.
	//
	opCode = msDeleteUncorrelatedAddressBookEntries;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	return(retVal);
}


int Server_SendDeleteAddressBookEntry(ServerState *state, userIdentification *userID, unsigned char ownerUserID)
{
messOut				opCode;

	opCode = msDeleteAddressBookEntry;

	Server_SetTransportHold(state->session, true);
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(unsigned char), 
		(Ptr)&ownerUserID);
	Server_TWriteDataSync(state->session, sizeof(userIdentification), 
		(Ptr)userID);
	Server_SetTransportHold(state->session, false);

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	return(kServerFuncOK);
}


// Assign a serverUniqueID existing addrbook entry on the box (this entry got there from a peer connect)
//
int Server_SendCorrelateAddressBookEntry(ServerState *state, userIdentification *userID, unsigned char ownerUserID, unsigned char serverUniqueID)
{
messOut				opCode;

	opCode = msCorrelateAddressBookEntry;

	Server_SetTransportHold(state->session, true);
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(unsigned char), 
		(Ptr)&ownerUserID);
	Server_TWriteDataSync(state->session, sizeof(BoxSerialNumber), 
		(Ptr)&userID->box);
	Server_TWriteDataSync(state->session, sizeof(unsigned char), 
		(Ptr)&userID->userID);
	Server_TWriteDataSync(state->session, sizeof(unsigned char), 
		(Ptr)&serverUniqueID);
	Server_SetTransportHold(state->session, false);

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	return(kServerFuncOK);
}


int Server_SendPlayerInfo(ServerState *state, PlayerInfo *playerInfo, unsigned char ownerUserID)
{
messOut				opCode;
SubDispatcher		subdisp[] = {
	{ kPlatformSNES,	kPlatformSNESMask,		Server_snes_SendPlayerInfo },
	{ kPlatformSJNES,	kPlatformSJNESMask,		Server_snes_SendPlayerInfo },
	{ kPlatformAny,		0,						Server_sega_SendPlayerInfo },
	{ 0,				0,						NULL },		// `witty remark`
};

	PLogmsg(LOGP_PROGRESS, "Server_SendPlayerInfo\n");

	opCode = msAddAddressBookEntry;
	Server_SetTransportHold(state->session, true);
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(unsigned char), 
		(Ptr)&ownerUserID);

	PLogmsg(LOGP_DBUG,
		"DBUG: uid=(%ld,%ld)[%d] dlp=0x%.8lx win=%d loss=%d uniq=%d\n",
		playerInfo->userId.box.box,
		playerInfo->userId.box.region,
		playerInfo->userId.userID,
		playerInfo->dateLastPlayed,
		playerInfo->wins,
		playerInfo->losses,
		playerInfo->serverUniqueID);

	(Common_SubDispatch(state->boxOSState.boxType, subdisp))(state, playerInfo);
	Server_SetTransportHold(state->session, false);

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_SendPlayerInfo done\n");
	return (kServerFuncOK);
}

//
// Send it down without compression.
//
PRIVATE int
Server_sega_SendPlayerInfo(ServerState *state, PlayerInfo *playerInfo)
{
	short size;

	size = sizeof(PlayerInfo);
	size += strlen(playerInfo->info);	// no need to +1 cuz there's already an extra byte: PlayerInfo.info[1]

	Server_TWriteDataSync(state->session, sizeof(short), (Ptr)&size);
	Server_TWriteDataSync(state->session, size, (Ptr)playerInfo);

	return (kServerFuncOK);
}

//
// Send it down with Digram+RLE compression.
//
// Can't used SendOptCompressedString because the size field covers
// the entire PlayerInfo struct... have to do it all by hand.
//
PRIVATE int
Server_snes_SendPlayerInfo(ServerState *state, PlayerInfo *playerInfo)
{
	PlayerInfo		*tmpPI;
	unsigned long	flags, compressedSize;
	short			size, stringSize;

	// Allocate a playerInfo buf that's larger than it can possibly be after
	// expansion.  For Digram the max expansion is kMPdigramMaxExpansion,
	// but for JRHuff it's the standard MegaPack 2x factor.
	//
	// Don't need to add +1 because there's already an extra byte.
	//
	tmpPI = (PlayerInfo *)malloc(sizeof(PlayerInfo) +
		strlen(playerInfo->info) * 2 + kMPheaderExpansion);
	if (tmpPI == NULL) {
		PLogmsg(LOGP_FLAW, "snes SendPlayerInfo: malloc(%d) failed!\n",
			sizeof(PlayerInfo) +
			strlen(playerInfo->info) * 2 + kMPheaderExpansion);
		return (kServerFuncAbort);
	}

	// Copy the bulk of the struct.
	//
	*tmpPI = *playerInfo;

	// Compress the info string into the struct.
	//
	flags = 0x00000000
		| kMPtryNone
		| kMPuseRLE
		| kMPincludeCRC
		;
	if (state->platformID == kPlatformSJNES)
		flags |= kMPtryJRHuff;					// Japanese
	else
		flags |= kMPtryDigram | kMPremapText;	// English

	if ((compressedSize = Compress(playerInfo->info, tmpPI->info,
		strlen(playerInfo->info) +1, flags)) <= 0)
	{
		PLogmsg(LOGP_FLAW,
			"Compression failed in Server_snes_SendPlayerInfo(%d)\n",
			compressedSize);
		free(tmpPI);
		return (kServerFuncAbort);
	}
	size = sizeof(PlayerInfo) + compressedSize;
	//PLogmsg(LOGP_DBUG, " OUTGOING COMPRESSED PlayerInfo (%d bytes):\n", size);
	//Loghexdump((char *)tmpPI, size);

	Server_TWriteDataSync(state->session, sizeof(short), (Ptr)&size);
	Server_TWriteDataSync(state->session, size, (Ptr)tmpPI);

	// Success.  Gloat.
	//
	stringSize = strlen(playerInfo->info) +1;
	if (!(tmpPI->info[1] & 0x0f)) {
		PLogmsg(LOGP_DBUG,
			"  Outgoing PlayerInfo: only RLE (%d-->%d)\n",
			stringSize, compressedSize);
	} else if ((tmpPI->info[1] & 0x0f) == kMPjrHuff) {
		PLogmsg(LOGP_DBUG,
			"  Outgoing compressed PlayerInfo: JRHuff (%d-->%d)\n",
			stringSize, compressedSize);
	} else if ((tmpPI->info[1] & 0x0f) == kMPdigram) {
		PLogmsg(LOGP_DBUG,
			"  Outgoing compressed PlayerInfo: Digram table %c %d-->%d (%.2f%%)\n",
			tmpPI->info[6], stringSize, compressedSize,
			((float)stringSize - (float)compressedSize) /
				(float)stringSize * 100.0);
	} else {
		PLogmsg(LOGP_DBUG,
			"  Outgoing compressed PlayerInfo: did something? (%d-->%d)\n",
			stringSize, compressedSize);
	}

	return (kServerFuncOK);
}


//
// After a game, update our copy of the address book so the win/loss and
// date last played fields track what's on the box.
//
// Pass in both wins and losses in case we really want the address book to
// include every game played, including non-stats ones.
//
Err Server_UpdateAddrBookAfterGame(Account *account, BoxSerialNumber *box,
	unsigned char player, int wins, int losses, long when)
{
	int i;

	PLogmsg(LOGP_PROGRESS, "Searching for address book matching (%ld,%ld)\n",
		box->box, box->region);
	if (box->box == -1 || box->region == -1) {
		Logmsg("NOTE: Server_UpdateAddrBookAfterGame called for box -1\n");
		return (kNoError);
	}
	if (!box->box || !box->region) {
		Logmsg("NOTE: Server_UpdateAddrBookAfterGame called for box 0\n");
		return (kNoError);
	}
	if (!when) {
		Logmsg("NOTE: Server_UpdateAddrBookAfterGame called with when==0\n");
		return (kNoError);
	}

	for (i = 0; i < kMaxAddressBookEntries; i++) {
		if (DataBaseUtil_CompareBoxSerialNumbers(box,
				&account->playerAccount.addressBook[i].box) &&
			(player == account->playerAccount.addressBook[i].playerNumber))
		{
			Logmsg("Updating addr book entry %d with wins=%d, losses=%d\n",
				i, wins, losses);
			account->playerAccount.addressBook[i].wins += wins;
			account->playerAccount.addressBook[i].losses += losses;
			account->playerAccount.addressBook[i].lastPlayed =
				Server_TimeToSegaDate(when);

			account->playerModified |= kPA_addressBook;
		}
	}

	return (kNoError);
}

