/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_GetSegaDate.c,v 1.5 1996/01/25 17:51:48 hufft Exp $
 *
 * $Log: Server_GetSegaDate.c,v $
 * Revision 1.5  1996/01/25  17:51:48  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.4  1995/09/13  14:24:29  ted
 * Fixed warnings.
 *
 * Revision 1.3  1995/08/11  16:24:23  fadden
 * LRA: change logmsg to LOGP_DETAIL.
 *
 * Revision 1.2  1995/05/26  23:46:22  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_GetSegaDate.c

	Contains:	unix breakout crud

	Written by:	Fucker Eat Shit
	

	Change History (most recent first):

		 <9>	 11/8/94	ATM		Added Server_TimeToSegaDate.
		 <8>	 9/19/94	ATM		PLogmsg stuff.
		 <7>	 8/18/94	DJ		compile on Mac
		 <6>	 8/16/94	DJ		senddateandtime
		 <5>	 8/11/94	ATM		Converted to Logmsg.
		 <4>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		 <3>	 7/15/94	DJ		minor tweak
		 <2>	 7/14/94	DJ		added #include studio.h
		 <1>	 7/13/94	dwh		first checked in

	To Do:
*/


#include <stdio.h>
#include <sys/time.h>

#include "ServerCore.h"
#include "Server.h"
#include "Messages.h"
#include "ServerDataBase.h"
#include "Dates.h"
#include "TransportLayer.h"
#include "PhysicalLayer.h"
#include "NetMisc.h"
#include "Common_Missing.h"


long
Server_GetSegaDate(void)
{
	return (Server_TimeToSegaDate(time(0)));
}

long
Server_TimeToSegaDate(time_t now)
{
static long segaDate;
long year, month, day;
struct tm *datep;

	datep 		= localtime(&now);
	year 		= datep->tm_year + 1900;
	month 		= datep->tm_mon;
	day 		= datep->tm_mday;
	segaDate 	= Date(year, month, day);
	PLogmsg(LOGP_DETAIL, "GetSegaDate: year = %ld, month = %ld, day = %ld\n",
		year, month, day);

	return(segaDate);
}

int Server_SendDateAndTime(ServerState *state)
{
messOut				opCode;
long				segaDate, segaTime;

	PLogmsg(LOGP_PROGRESS, "Server_SendDateAndTime\n");

	opCode = msSetDateAndTime;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);

	segaTime = 0;	// Sega has no notion of time yet.
	segaDate = Server_GetSegaDate();

	Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&segaDate);
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&segaTime);

	if(Server_TCheckError(state->session) != noErr)
		return(kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_SendDateAndTime done\n");

	return(kServerFuncOK);
}

