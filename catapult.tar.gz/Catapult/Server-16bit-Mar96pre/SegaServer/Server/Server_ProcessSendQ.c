/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_ProcessSendQ.c,v 1.94 1996/03/08 13:41:44 fadden Exp $
 *
 * $Log: Server_ProcessSendQ.c,v $
 * Revision 1.94  1996/03/08 13:41:44  fadden
 * Moved mail processing to Server_Mail.c, since the mail has nothing to
 * do with the SendQ.
 *
 * Revision 1.93  1996/02/27  23:12:26  roxon
 * Deduct 4 smartcard credits for changing password.
 *
 * Revision 1.92  1996/02/22  14:20:54  chs
 * add ability to send mail to "xband*" to a file instead of internet.
 *
 * Revision 1.91  1996/02/20  17:17:59  ted
 * Crop negative box peerConnects or peerSeconds to zero.
 *
 * Revision 1.90  1996/02/14  18:02:00  fadden
 * Restored the v1.83 changes, updated to use the new TNetIdle parameters.
 *
 * Revision 1.89  1996/02/13  20:28:06  fadden
 * Declare some read-only tables and their pointers as "const".
 *
 * Revision 1.88  1996/02/12  17:09:51  fadden
 * Show boxID in the SNES mindwipe crash record message.
 *
 * Revision 1.87  1996/02/09  16:48:11  fadden
 * Reduced log priority on a couple of logmsgs, made one more informative.
 *
 * Revision 1.86  1996/02/07  18:09:29  fadden
 * Move notification of a deliberate SNES mind-wipe up to INFO level.
 *
 * Revision 1.85  1996/01/29  18:32:58  fadden
 * Removed an old debugging logmsg.
 *
 * Revision 1.84  1996/01/25  17:51:55  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.82  1996/01/12  15:47:18  steveb
 * Change "testserver" to program box to use CATAPULT instead of BEX0DG in
 * anticipation of losing the 56Kbp X.25 link.
 *
 * Revision 1.81  1996/01/11  17:55:01  steveb
 * Nope, had it right the first time.  I am absolutely 99.99% sure.
 *
 * Revision 1.80  1996/01/11  17:47:11  steveb
 * Reversed the logic from the previous checkin.  I think I've got it right
 * now, but I won't be 100% sure until we try a connect.
 *
 * Revision 1.79  1996/01/11  17:41:47  steveb
 * Modified "whichserver" to correctly program Japanese ROMS in ustest mode.
 *
 * Revision 1.78  1996/01/04  22:54:17  hufft
 * added pop mail
 *
 * Revision 1.77  1996/01/04  15:08:22  felix
 * Set commitSmartCardChanges = true after box queues cleared, as this is
 * the milestone for a successful connection in world of smart card debiting
 *
 * Revision 1.76  1995/12/11  18:00:35  ansell
 * Moved some PLogmsg()s from DBUG up to higher priority since they represented
 * error conditions.
 *
 * Revision 1.75  1995/11/17  19:27:41  felix
 * Update boxModified flag for prevSmartCardSerialNumber so changes saved
 *
 * Revision 1.74  1995/11/13  19:44:36  hufft
 * pop lookup interface changes, rpc returns a list of pops, and dial patterns
 *
 * Revision 1.73  1995/11/09  17:04:39  jhsia
 * Enabled some smartcard stuff.  Made whichserver and mainserver mail
 * targets work correctly for 'sjne' and ja locale.
 *
 * Revision 1.72  1995/11/08  18:44:03  jhsia
 * Added support for PhoneXlate.  Reset the box nasty flags for 'sj01'. (fadden)
 *
 * Revision 1.71  1995/11/06  02:49:55  felix
 * In Server_SendClearMiscQueues,
 * check for mail-only connect: debit now if gConfig.debitMailConnectNow set.
 * If useDebitCardOnly set, commit the credits used for this connect here.
 *
 * Revision 1.70  1995/10/30  17:50:53  jhsia
 * added support for 'sj01' crash records (fadden)
 *
 * Revision 1.69  1995/10/19  22:25:58  hufft
 * Japan Database Changes
 *
 * Revision 1.68  1995/10/19  13:11:34  ted
 * Sanity check peerTime sendQ item from box.
 *
 * Revision 1.67  1995/10/03  16:54:33  ted
 * Moved XBN usage estimation to Server_Nationwide.c.
 *
 * Revision 1.66  1995/09/27  18:37:37  hufft
 * added Common_Phone support
 *
 * Revision 1.65  1995/09/27  15:49:19  chs
 * Added special-case for mail to "xband-store".
 *
 * Revision 1.64  1995/09/20  10:53:37  chs
 * Drop mail to XBAND-legal is this isn't the connect on which
 * the user made it past the T+C check.
 *
 * Revision 1.63  1995/09/18  14:02:45  chs
 * Ignore case when short-circuiting internet mail to xband.com.
 *
 * Revision 1.62  1995/09/16  19:23:58  fadden
 * Moved "patch" handling into Server_HandlePatchMail, added Server_SecurePath
 * and Server_HandleGameIDPatch.
 *
 * Revision 1.61  1995/09/13  14:24:38  ted
 * Fixed warnings.
 *
 * Revision 1.60  1995/09/08  18:32:17  sriram
 * Reprogram "testserver" to BEX0DG,XB11 (this is eliza's news test server).
 *
 * Revision 1.59  1995/08/28  17:48:14  hufft
 * Corrected error in Server_SendSetBoxPhoneNumber(), The write data was using ** instead of *
 * so pointing to garbage.
 *
 * Revision 1.58  1995/08/26  11:22:13  roxon
 * Replace Common_PhoneLocale() with LOCALE_PHONE_xxx().
 *
 * Revision 1.57  1995/08/24  19:25:32  rich
 * aServer_SendSetBoxPhoneNumber() doesn't strip Japanese phone numbers now.
 *
 * Revision 1.56  1995/08/07  21:48:48  fadden
 * Call Server_UpdateCordPullData when the appropriate SendQ item arrives
 * instead of printing logmsgs.
 *
 * Revision 1.55  1995/08/02  17:49:39  fadden
 * Added pretty-print for kSnesGameIDQElement.
 *
 * Revision 1.54  1995/07/28  16:35:23  ansell
 * Added check and special logging for phone-cord pull data item.
 *
 * Revision 1.53  1995/07/26  23:01:36  fadden
 * LRA: changed the "Incoming Mail Item" logmsgs to be LOGP_DETAIL.
 *
 * Revision 1.52  1995/07/25  23:03:26  ted
 * Process kModemSelfTestDataQElement.
 *
 * Revision 1.51  1995/07/17  17:25:21  ted
 * Deal with kPeerTimeQElement SendQ data from boxes. Store in server state which
 * is then loaded into binlogs.
 *
 * Revision 1.50  1995/07/11  16:17:16  fadden
 * Josh's fancy crash record stuff, take two.
 *
 * Revision 1.49  1995/07/10  21:05:15  rich
 * Added Japanese SNES platform (kPlatformSJNES).
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.48  1995/07/10  10:35:39  ted
 * Call Server_SetBoxAccountPops to update box's pop data.
 *
 * Revision 1.47  1995/06/29  22:07:53  fadden
 * SNES crash record enhancements for Josh.  Automatically detects and
 * avoids printing crash records from new boxes and wiped boxes.
 *
 * Revision 1.46  1995/06/19  20:35:18  fadden
 * Send opCode in Server_SendBoxWipeMind.  Added handler for kSNESResetQElement.
 * Ignore mail to XBAND.Replacement.  Added error checking on custom icon read.
 *
 * Revision 1.45  1995/06/07  14:00:05  fadden
 * Changed "whichserver" handler to use Server_SendXYString.
 *
 * Revision 1.44  1995/06/05  22:24:29  chs
 * If someone sends Xmail to *@xband.com,
 * just chop off the @xband.com part and
 * stick it in the database directly
 * rather than bounce it thru the internet.
 *
 * Revision 1.43  1995/06/02  22:51:28  fadden
 * Kluge to reset the NastyFlags on SNES.
 *
 * Revision 1.42  1995/06/01  15:06:42  fadden
 * Merge in from newbr.
 * -> Make "assumebynum" target work for new restore testing.
 *
 * Revision 1.41  1995/05/26  23:46:42  jhsia
 * switch to rcs keywords
 *
 * Revision 1.40  1995/05/25  22:56:22  chs
 * if the arg "whichserver" has a comma in it,
 * don't prepend "CATAPULT," to it.
 * This allows us to bypass Portal, woo woo!
 *
 */

/*
	File:		Server_ProcessSendQ.c

	Contains:	Process SendQ items.

	Written by:	David Jevans


	Change History (most recent first):

	   <163>	12/15/94	BET		Change internet Email calls to call out to separate subroutine.
	   <162>	12/14/94	SR		Set streamErrorReport field in ServerState.
	   <161>	12/14/94	HEC		Added XBAND.MATCHER mail address.
	   <160>	12/14/94	ATM		Changed format of stream error report again.
	   <159>	12/13/94	ATM		Changed format of stream error report.  Changed sendmail
									command.
	   <158>	12/13/94	ATM		Add support for StreamErrorReport SendQ item.  Not tested.
	   <157>	12/13/94	BET		Fix email to come from correct sender.
	   <156>	12/11/94	ATM		Show box number in crash record dump.
	   <155>	 12/8/94	HEC		Changed "phone" mail address to optionally avoid setting a new
									pop for testing. Added ability to set area restriction with
									XBAND.RESTRICT mail address.
	   <154>	11/30/94	ATM		Didn't work.  Now it does.
	   <153>	11/30/94	ATM		Print stuff past end of crashRecord instead of dumping it all as
									hex.  Might work.
	   <152>	11/30/94	DJ		Adding third param to DoRestore call.
	   <151>	11/23/94	ATM		Make that a Usenet-style signature.
	   <150>	11/22/94	SR		Logging mail in separate file.
	   <149>	11/22/94	HEC		Smarted Hometown decision.
	   <148>	11/21/94	DJ		Mail to "XBAND.icon" gives you a custom icon.
	   <147>	11/21/94	ATM		Add a blatant plug to the end of outbound Internet mail.
	   <146>	11/18/94	HEC		Disable changing zip/hometown via xmail.
	   <145>	11/17/94	KD		Update server dialog text (doug/kon).
	   <144>	11/15/94	DJ		Sendmail to XBAND.clearcredits to test running out of credits.
	   <143>	11/15/94	HEC		Ignore mail to XBAND.PhoneNumber.
	   <142>	11/13/94	ATM		Do the make phone number pretty stuff after copying it to
									gamePhone but before sending it to the box.
	   <141>	 11/9/94	DJ		If kPasswordEraseQElement comes in on SendQ, then player used
									the password erase code.
	   <140>	 11/9/94	DJ		Renamed some DB routines to DataBaseUtil_ and also to WrapperDB_
									(for Oracle).
	   <139>	 11/8/94	HEC		Fix POP probs
	   <138>	 11/7/94	DJ		Added mail addr "XBAND.latency" to test x25 latency.
	   <137>	 11/2/94	ATM		Add box history stuff.
	   <136>	10/30/94	ATM		Fix a typo (x-band).
	   <135>	10/27/94	HEC		Make zip code mailing work.
	   <134>	10/27/94	HEC		Don't freak out on errors from DataBase_POPLookup.
	   <133>	10/26/94	DJ		You can send mail to XBand.zipcode to change yer zipcode and
									boxhometown.
	   <132>	10/25/94	DJ		Moved all address book stuff into Server_AddressBook.c
	   <131>	10/24/94	ATM		Send a "mail sent" dialog for mail sent to XBAND.
	   <130>	10/22/94	ATM		Let Server_SendDialog() do the log messages.
	   <129>	10/22/94	ATM		Need to catch "X BAND" and " XBAND" too.
	   <128>	10/20/94	DJ		Added state->disallowOutgoingMail.
	   <127>	10/20/94	DJ		Added "dialog" in caps comment on same line as server dialogs
									(useful for greping).
	   <126>	10/20/94	ATM		Remove phone # from mail sent out to Internet.
	   <125>	10/20/94	DJ		Made testserver goto catapentserver.
	   <124>	10/19/94	DJ		Adding dateLastConnect param to DataBase_POPLookup
									(param == 0).
	   <123>	10/18/94	ATM		Mail sent to "xband.*" all goes to "xband".
	   <122>	10/17/94	DJ		Fixed some comments that were fucked.
	   <121>	10/17/94	DJ		Sending mail to XBand.filtermail toggles incoming mail filter.
									Also added XBand.restrict for testing restrictions.
	   <120>	10/17/94	ATM		Moved DumpJamsStats out, replaced with call to
									Server_DumpGameResultSendQ.
	   <119>	10/17/94	DJ		No mail filtering on outgoing.
	   <118>	10/17/94	ATM		Include the area code on XBAND mail sent to the Internet.
	   <117>	10/13/94	DJ		Fixed typo
	   <116>	10/13/94	DJ		You can turn testpops off, you can also send to "assumebynum".
	   <115>	10/13/94	ATM		Okay, try that again.
	   <114>	10/12/94	ATM		Removed recoveryCount from JamsStats.
	   <113>	10/12/94	ATM		Increased JamsStats patchHistBuf from 8 to 32 entries.  Moved
									BoxRestartInfo out to Server.h.
	   <112>	10/11/94	ATM		Commented out Loghexdump for crash records.
	   <111>	10/10/94	DJ		changing some TWriteDataSync to Server_TWriteDataSync
	   <110>	10/10/94	ATM		Add gameID of last game played to crashlog printout.
	   <109>	 10/9/94	ATM		Catch "x-band" as well as "xband".
	   <108>	 10/7/94	DJ		now setting playerModified correctly so that database actually
									*stores* the addrbook changes.  sigh!
	   <107>	 10/6/94	ATM		Wanted strchr, not strspn.
	   <106>	 10/5/94	ATM		Don't say "3 items were sent" if some of them weren't.
	   <105>	 10/4/94	ATM		Check to see if TO line contains an '@' before trying to send it
									to Internet.
	   <104>	 10/3/94	ATM		Show full phone number in mail messages sent to XBAND.
	   <103>	 10/3/94	ATM		Report an error if pclose() on Internet mail fails.
	   <102>	 10/2/94	ATM		Have x-mail to XBAND go to "catapult" instead of
									"xband@catapent.com" (problems with mail getting out of
									portal.com).
	   <101>	 10/1/94	ATM		Added gameID to start of JamsStats struct.
	   <100>	 9/30/94	DJ		added mail to "newaccount"
		<99>	 9/30/94	ATM		Added carriage returns to the end of some Logmsgs.
		<98>	 9/28/94	DJ		added mainserver and testserver.
		<97>	 9/27/94	DJ		filtering your mail for naughty words
		<96>	 9/26/94	DJ		added \r to whichserver string so it works.
		<95>	 9/26/94	DJ		mail to whichserver sets your server chat string
		<94>	 9/26/94	ATM		Converted debugN to debug[N].
		<93>	 9/25/94	ATM		Added sanity check on JAMS result size.
		<92>	 9/23/94	ATM		Try that again.
		<91>	 9/23/94	ATM		Changed FindAccount to FindUserIdentification in XBAND to
									Internet mail stuff.
		<90>	 9/22/94	BET		Add mail from box to internet, come back  later for internet to
									box.  Also still need to add the header munging for proper
									sender address.
		<89>	 9/21/94	ATM		Added systempatch and rattlepatch mail targets.
		<88>	 9/20/94	DJ		mail to "testpops" routes you through every pop in the country.
									yay.
		<87>	 9/19/94	ATM		PLogmsg stuff.
		<86>	 9/16/94	ATM		Clear the "dial 9" flag if they change the phone and don't set
									it again.
		<85>	 9/16/94	ATM		Change "dial 9" thing with "phone" to use debug1.
		<84>	 9/16/94	ATM		boxFlags->boxModified, playerFlags->playerModified,
									acceptChallenges->playerFlags.
		<83>	 9/15/94	DJ		setting scriptID by title to mail to "server"  (eg. title = #5
									sets scriptID to 5).
		<82>	 9/15/94	DJ		sending mail to server does normal POP lookup first in order to
									get the scriptID
		<81>	 9/12/94	DJ		changed LataLookup to POPLookup (looks up Compuserve POPs)
		<80>	 9/12/94	ATM		Hacked the "phone" mail target to add an arbitrary prefix, for
									dialing out of companies.
		<79>	 9/11/94	ATM		Got rid of NO_OS_STRINGS; now include the OS string stuff all
									the time.
		<78>	  9/7/94	ATM		Enabled STRIP_AREA_CODE, removed reference to
									extractedPhoneNumber.
		<77>	  9/2/94	DJ		storing addr book info in the playerAccount addr book now
		<76>	  9/1/94	DJ		turning off alarm if bigloop
		<75>	  9/1/94	DJ		sending mail to "bigloop" does loop 10 times (ie. 20 minutes of
									thruput testing)
		<74>	  9/1/94	ATM		Updated logging stuff.
		<73>	 8/31/94	ATM		Spiffed up date printing on mail items.
		<72>	 8/30/94	DJ		uncommented NO_OS_STRINGS define
		<71>	 8/30/94	DJ		sending mail to crashlog prints your mail in the crashlog.
									also, when you crash, i now print out which patch version was on
									your box
		<70>	 8/30/94	ATM		Changed call to UpdateUserPhoneNumber.
		<69>	 8/30/94	ATM		Converted accountChangedMask references to Account flags.
		<67>	 8/28/94	ATM		Checked it in with NO_OS_STRINGS commented out.  Whoops.
		<66>	 8/28/94	ATM		Updated mail handling for segb.
		<65>	 8/27/94	ATM		Added NO_OS_STRINGS stuff.
		<64>	 8/27/94	ATM		ChatDebug separation for 800 and X.25.
		<63>	 8/26/94	ATM		Tweaked some logmsgs.
		<62>	 8/26/94	ATM		Added Andy1's crash record printing.
		<61>	 8/25/94	DJ		added Server_SendClearMiscQueues
		<60>	 8/25/94	ATM		Added some more stuff to DumpJamsStats for Steve.
		<59>	 8/23/94	ATM		Fixed DumpJamsStats.
		<58>	 8/23/94	ATM		Added DumpJamsStats (untested!)
		<57>	 8/23/94	ATM		Added game results dump to sendq processing.
		<56>	 8/22/94	DJ		more grooming
		<55>	 8/22/94	DJ		groomed dialog text
		<54>	 8/22/94	DJ		printing chat script errors from sendq
		<53>	 8/21/94	ATM		altPopPhone stuff.
		<52>	 8/21/94	DJ		sendlocalaccessphonenum takes 2 phone numbers (2nd is a fallback
									phone number)
		<51>	 8/20/94	DJ		serverUniqueID is now in PlayerInfo, not userIdentification
		<50>	 8/20/94	BET		Changing the polarity of that last one, the server crashes
									trying to dump the data without the hexdump.
		<49>	 8/20/94	BET		Add Loghexdump for mail body under OPTIONAL compile time flag.
		<48>	 8/20/94	DJ		mail to "patch" will try to read in and download the mesg file
									you specify in the mail body.
		<47>	 8/19/94	DJ		fixed printf of mail serial number
		<46>	 8/18/94	ATM		Changed outbound mail message.
		<45>	 8/18/94	DJ		sending mail to "core" makes sunsega dump.  neato feature.
		<44>	 8/17/94	ATM		Added Crashmsg stuff.
		<43>	 8/17/94	ATM		Redo LATA lookup for "phone" e-mail.
		<42>	 8/17/94	ATM		Tweaked.
		<41>	 8/15/94	ATM		Adjusted hex dump to format correctly with updated Logmsg().
		<40>	 8/15/94	DJ		sticky dialogs for mail only connect
		<39>	 8/13/94	ATM		Don't popen /usr/ucb/mail on Mac!
		<38>	 8/13/94	ATM		Changed strncasecmp("xband") to DataBase_CompareStrings.
		<37>	 8/13/94	ATM		Added dump of data for kRestartInfoType.
		<36>	 8/12/94	ATM		Mail to "xband" goes to xband@catapent.com.
		<35>	 8/12/94	DJ		bollgles the bwain, dunnit?
		<34>	 8/12/94	DJ		bugfix
		<33>	 8/11/94	DJ		bugfix
		<32>	 8/11/94	ATM		Converted to Logmsg.
		<31>	 8/10/94	ATM		Added MakePhoneNumberPretty calls to the special "phone" and
									"server" mail targets.
		<30>	  8/8/94	DJ		can send mail to "loop" and turn on throughput testing
		<29>	  8/6/94	DJ		fix
		<28>	  8/5/94	DJ		you can mail to "redial" to get box to redial server in a loop
		<27>	  8/5/94	DJ		fixes and optimization to ProcessAddreBook
		<26>	  8/5/94	DJ		all new address book stuff!  like
									Server_SendCorrelateAddressBookEntry, etc
		<25>	  8/4/94	DJ		even less SNDQElement
		<24>	  8/4/94	DJ		no more SNDQElement
		<23>	  8/2/94	DJ		fixed mail to "phone"
		<22>	  8/2/94	DJ		update to latest mail sending scheme
		<21>	 7/27/94	DJ		sending dialagain flag when local access number is changed
		<20>	 7/25/94	DJ		nothing
		<19>	 7/20/94	DJ		added Server_Comm stuff
		<18>	 7/19/94	DJ		hmmmmm
		<17>	 7/18/94	DJ		update to latest addrbookvalidation stuff
		<16>	 7/17/94	BET		Make printf's go to gLogFile instead of stdout, which is the
									modem.
		<15>	 7/15/94	SAH		Changed some printf around new GameResult structure.
		<14>	 7/15/94	DJ		added mail processing
		<13>	 7/14/94	DJ		added processmail
		<12>	 7/12/94	DJ		using Server_TCheckError instead of TCheckError
		<11>	 7/11/94	DJ		set extractedPhoneNumber so game is registered with this new ph
									num
		<10>	  7/8/94	DJ		msgs to set phonenums on box
		 <9>	  7/6/94	DJ		address book validation
		 <8>	  7/3/94	DJ		no iconref in mail
		 <7>	  7/3/94	DJ		error tolerant
		 <6>	  7/2/94	DJ		rankings
		 <5>	 6/30/94	DJ		updated to new sendQ format
		 <4>	 6/30/94	DJ		no result FIFOs anymore.
		 <3>	 5/31/94	DJ		better mail handling through database
		 <2>	 5/29/94	DJ		added reading of mail
		 <1>	 5/27/94	DJ		first checked in

	To Do:
*/
#include <ctype.h>
#include <memory.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <malloc.h>

#include "ServerCore.h"
#include "Server.h"
#include "ServerState.h"
#include "ServerDataBase.h"
#include "ServerDataBase_priv.h"
#include "Common.h"
#include "Common_ReadConf.h"
#include "OpaqueStoreKeys.h"

#include "DBConstants.h"
#include "DBTypes.h"
#include "Mail.h"
#include "SendQ.h"
#include "BoxSer.h"
#include "Messages.h"
#include "PlayerDB.h"
#include "AddressBook.h"
#include "StringDB.h"

#include "FilterHandle.h"
#include "Common_Missing.h"
#include "Server_Personification.h"
#include "Server_GameSpecific.h"

#include "Challnge.h"

//
// Local prototypes.
//
PRIVATE int Server_segb_PrintCrashRecord(ServerState *state, unsigned char * cr, long blockSize);
PRIVATE int Server_snes_PrintCrashRecord(ServerState *state, unsigned char *cr, long blockSize);
PRIVATE int Server_any_PrintCrashRecord(ServerState *state, unsigned char *cr, long blockSize);
void Server_GenericRecordSQDebugging(ServerState *state, int theID, void *data, int size);
PRIVATE void Server_SanityCheckPTEst(ServerState *state);

//
// This is for when you send mail to bigloop, wanna turn of the 4 min alarm.
//
#include <sys/types.h>
#include <sys/file.h>
#include <sys/ioctl.h>
#include <signal.h>

//
// KON's box debugging crap
//
#define kMagicNumItems	60
typedef struct
{
	short   numItems;
	OSErr   serverError;
	short   opCode[kMagicNumItems];
	short   bytesReady[kMagicNumItems];
	long    time[kMagicNumItems];
} ServerMonitorThing;

void Server_DumpBoxHist(unsigned char *data, long size);

//
// Stadler's Stuff(tm)
//
typedef struct {
	short	version;			// 1
	short	checkErr;			// Result from TCheckError
	short	openErr;			// TOpen result OR progress code
	short	lastOpcode;			// Most recent opcode
} StreamErrorReport;



#ifdef NOT_USED	// ----------
typedef struct QItem {
	DBType			type;
	long			size;
	unsigned char	*data;
} QItem;

typedef struct SendQData {
	// mail
	// address book entries for validation
	// game results
	// other personification poop

	short			count;
	QItem			*items;
} SendQData;


typedef struct
{
	long	gameID;
	short	userID;
	long	userScore;
	short	opponentID;
	long	opponentScore;
} Result;
#endif	/*NOT_USED*/	// -----



#ifdef NOT_USED
//
// Not used since Genesis version 7 (seg7).
//
int Server_SendClearSendQ(ServerState *state)
{
messOut				opCode;

	opCode = msClearSendQ;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);

	return(kServerFuncOK);
}
#endif

//
// This needs to come before Server_SendRegurg.
//
int Server_SendClearMiscQueues(ServerState *state)
{
messOut				opCode;
long				controlFlags;

	PLogmsg(LOGP_PROGRESS, "Server_SendClearMiscQueues\n");

	opCode = msServerMiscControl;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);

	controlFlags =
		kClearNetErrorsFlag |
		kDeleteSendQFlag |
		kDeleteAllAoutBoxMailFlag |
		kMarkAddressBookUnchangedFlag |
		kClearGameResultsFlag |
	// These two are meaningless on segb, since it doesn't have news controls.
	// They will un-set all of the controls, so we don't normally want to
	// use them.
		//kClearBANDWIDTHControlsFlag |
		//kClearXBANDNewsControlsFlag |
	// This is for the BoxLogs stuff.
		kClearPeerLogFlag;

	Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&controlFlags);
	PLogmsg(LOGP_PROGRESS, "SendClearMiscQueues 0x%.8lx\n", controlFlags);

	// This should go somewhere else.
	//
	if ((state->platformID == kPlatformSNES) ||
		(state->platformID == kPlatformSJNES))
	{
		const long val = 0xd50000aa;

		PLogmsg(LOGP_PROGRESS, "Setting NastyFlags to 0x%.8lx\n", val);
		opCode = msReceieveBoxNastyLong;
		if (Server_TWriteDataSync(state->session, sizeof(opCode),
			(Ptr) &opCode) != noErr)
		{
			return (kServerFuncAbort);
		}
		if (Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &val)
			!= noErr)
		{
			return(kServerFuncAbort);
		}

	}

    //
    // If the current connect is a mail-only connect, and gConfig.debitMailConnectNow
    // is set, we'll debit it now that we've sent a message to the box to clear
    // the mail queue.
    //

    if ((gConfig.deductMailConnectNow) &&
        (state->challengeData.userID.box.box == kDownloadOnlyMailSerialNumber)) {
        Server_DeductCredit(state);
        state->creditChangeFlags |= kCreditChange_Deduct_MailOnly;
    }

	//
	// In the land of SmartCards, this point is a milestone for a successful connection.
	//
	// Commit the changes to the number of credits to the smartcard database
	//

    if (gConfig.useDebitCardOnly) {

 		state->commitSmartCardChanges = true;

		// Update account struct so current card used for 'last' connection

		if (state->account->boxAccount.prevSmartCardSerialNumber !=
			state->creditDebitInfo.debitCardInfo.serialNumber) {
			state->account->boxAccount.prevSmartCardSerialNumber =
				state->creditDebitInfo.debitCardInfo.serialNumber;
    		state->account->boxModified |= kBA_prevSmartCardSerialNumber;
		}

	}

	PLogmsg(LOGP_PROGRESS, "Server_SendClearMiscQueues done\n");
	return(kServerFuncOK);
}

int Server_SendSetBoxPhoneNumber(ServerState *state, phoneNumber *newBoxPhoneNumber)
{
messOut			opCode;
phoneNumber		strippedPhoneNumber;

	Common_PhoneFormatBoxDownload(newBoxPhoneNumber, &strippedPhoneNumber);
	Common_PhoneXlateHitherToYon(state, strippedPhoneNumber.phoneNumber);

	PLogmsg(LOGP_DETAIL, "SendSetBoxPhoneNumber to '%s'\n",
		strippedPhoneNumber.phoneNumber);

	opCode = msSetBoxPhoneNumber;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(phoneNumber), (Ptr)&strippedPhoneNumber);
	return(kServerFuncOK);
}

//
// Tell the box to wipe its little mind.
// I hope this wipes the serial numbers, but I am not sure.  dj 3/13/95
// Nope, it does not wipe out the protected personification info.  Shit.
//
// 950609: this doesn't work at all, the box side is broken. ++ATM
//
void Server_SendBoxWipeMind(ServerState *state)
{
	unsigned char opCode;
	long data;

	PLogmsg(LOGP_PROGRESS, "Server_SendBoxWipeMind\n");

	opCode = msBoxWipeMind;
        Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr)&opCode);
	data = kBoxWipeMindPassword1;
        Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&data);
	data = kBoxWipeMindPassword2;
        Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&data);
	data = kBoxWipeMindPassword3;
        Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&data);
	data = kBoxWipeMindPassword4;
        Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&data);

	data = kSetOSUnstableFlag | kSetDBUnstableFlag;
        Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&data);

	return;
}

//
// Set the local access phone number on the box.  If forceRedial is true then it tells the box
// to redial through that access number after this connection is done.
// 
// The err parameter controls whether Server_SendSetLocalAccessPhoneNumber sends
// a dialog to the box informing the user of the new pop numbers (a new feature
// added 5/95).  If it is -1 then no dialog is sent.
//
int Server_SendSetLocalAccessPhoneNumber(ServerState *state,
	phoneNumber *newAccessPhoneNumber,
	phoneNumber *fallbackAccessPhoneNumber,
	Boolean redial)
{
messOut				opCode;
short				dialAgainFlag;
phoneNumber		first, second;

	// Make a copy so we don't trample the caller's POP values.
	//
	first = *newAccessPhoneNumber;
	second = *fallbackAccessPhoneNumber;
	Common_PhoneXlatePOP(state, state->boxPhoneNumber.phoneNumber,
		first.phoneNumber);
	Common_PhoneXlatePOP(state, state->boxPhoneNumber.phoneNumber,
		second.phoneNumber);

	opCode = msSetLocalAccessPhoneNumber;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(phoneNumber), (Ptr)&first);
	Server_TWriteDataSync(state->session, sizeof(phoneNumber), (Ptr)&second);

	if(redial)
		dialAgainFlag = kRedialTheNetwork;
	else
		dialAgainFlag = kDontRedialTheNetwork;
	Server_TWriteDataSync(state->session, sizeof(short), (Ptr)&dialAgainFlag);

	PLogmsg(LOGP_DBUG, "Sent LocalAccessNumber %s [%d]  fallback %s [%d]\n",
		first.phoneNumber, first.scriptID,
		second.phoneNumber, second.scriptID);

	return(kServerFuncOK);
}


//
// Search the SendQ for an item with the specified type.
//
// Returns a pointer to the item found or NULL if one wasn't found.
//
QItem *
Server_FindSendQItem(const ServerState *state, long ident)
{
	QItem *item;
	int i;

	for (i = 0; i < state->sendQData.count; i++) {
		item = &state->sendQData.items[i];
		if (item->theID == ident)
			return (item);
	}

	return (NULL);
}

//
// If there's a StreamErrorReport on the SendQ, display it.
//
// This is called early on in the connect, so various things may not be
// available.
//
int
Server_DumpStreamErrorReport(ServerState *state)
{
	QItem *item;
	StreamErrorReport *serp;

	item = Server_FindSendQItem(state, kStreamErrorReportQElement);
	if (item != NULL) {
		serp = (StreamErrorReport *)item->data;

		if (item->size != sizeof(StreamErrorReport)) {
			PLogmsg(LOGP_NOTICE, "ERROR: bogus StreamErrorReport, size=%ld, wanted %ld\n",
				item->size, sizeof(StreamErrorReport));
		} else {
			PLogmsg(LOGP_NOTICE, "'%.4s' STREAM ERROR REPORT: version=%-2d checkErr=%-5d openErr=%-5d lastOpcode=%-5d\n",
				(char *)&state->platformID,
				serp->version, serp->checkErr, serp->openErr,
				serp->lastOpcode);
			state->streamErrorReport = item->data;
		}
	}

	return (kServerFuncOK);
}


//
// Process the SendQ.
//
int Server_ProcessSendQ(ServerState *state)
{
short 		i;
QItem		*item;
char		whichPlayer;
char		mesg[256];

SubDispatcher restartSubdisp[] = {
	{ kBoxType_segb,	0xffffffff,			Server_segb_PrintCrashRecord },
	{ kPlatformSNES,	kPlatformSNESMask,	Server_snes_PrintCrashRecord },
	{ kPlatformSJNES,	kPlatformSJNESMask,	Server_snes_PrintCrashRecord },
	{ kPlatformAny,		0,					Server_any_PrintCrashRecord },
	{ 0,				0,					NULL },		// don't tread on me
};

	PLogmsg(LOGP_PROGRESS, "Server_ProcessSendQ:\n");

	ASSERT(state->validFlags & kServerValidFlag_Account);

	for(i = 0; i < state->sendQData.count; i++)
	{
		item = &state->sendQData.items[i];
		//
		// there are no types anymore, just a DBID.  8/4/94
		//
		switch (item->theID) {
		case kRestartInfoType:
			// dump the crash record for Andy1
			FPLogmsg(LOG_CRASH, LOGP_DBUG,
				"RESTART INFO for '%s' (%s) (%ld,%ld)[%d] (OS patch v.%ld) (theID=%ld), size=%ld\n",
				state->loginData.userID.userName,
				state->boxPhoneNumber.phoneNumber,
				state->loginData.userID.box.box,
				state->loginData.userID.box.region,
				state->loginData.userID.userID,
				state->systemVersionData.version,
				(long)item->theID, (long)item->size);
			FPLogmsg(LOG_CRASH, LOGP_DBUG,
				"Last gameID was 0x%.8lx, current gameID is 0x%.8lx\n",
					state->account->boxAccount.lastMatchup.oppRankingInfo.gameID,
					state->gameIDData.gameID);
			(Common_SubDispatch(state->boxOSState.boxType, restartSubdisp))(
				state, item->data, item->size);
			break;
		case kChatDebugType:
		case kDebugChatScriptConst800:
			// dump the chat script debug for Brian
			if (item->theID == kChatDebugType)
				FPLogmsg(LOG_DBUG, LOGP_DBUG,
					"CHAT SCRIPT DEBUG X.25 (theID=%ld, size=%ld)\n",
					(long)item->theID, (long)item->size);
			else
				FPLogmsg(LOG_DBUG, LOGP_DBUG,
					"CHAT SCRIPT DEBUG 800 (theID=%ld, size=%ld)\n",
					(long)item->theID, (long)item->size);
			FPLogmsg(LOG_DBUG, LOGP_DBUG,
				"SCRIPT INFO for '%s' (%s) (theID=%ld), size=%ld\n",
				state->loginData.userID.userName,
				state->boxPhoneNumber.phoneNumber,
				(long)item->theID, (long)item->size);
			FLoghexdump(LOG_DBUG, item->data, item->size);
			break;
		case kGameResultDataDBID:
			// dump the game results for Steve
			// NOTE: first longword in chunk must be gameID
			FPLogmsg(LOG_GAMERESULT, LOGP_DBUG,
				"GAME RESULTS for '%s' (%s) (theID=%ld), size=%ld\n",
				state->loginData.userID.userName,
				state->boxPhoneNumber.phoneNumber,
				(long)item->theID, (long)item->size);
			Server_DumpGameResultSendQ(state, item->data, item->size);
			
			// 2/19/95 12:03:15 AM (BET): save the pointers to this cheeze
			state->gameErrorDBIDData = item->data;
			state->gameErrorDBIDSize = item->size;
			break;
		case kMagicQElement:
			// KON's crap
			FPLogmsg(LOG_BOXHIST, LOGP_DBUG,
				"BOX HISTORY for '%s' (%s) (theID=%ld), size=%ld\n",
				state->loginData.userID.userName,
				state->boxPhoneNumber.phoneNumber,
				(long)item->theID, (long)item->size);
			Server_DumpBoxHist(item->data, item->size);
			break;
		case kPasswordEraseQElement:
			// Player used the passwordEraseCode to clear his password.
			whichPlayer = (char)item->data[0];	// The data is 1 byte which is the playernum.
			FPLogmsg(LOG_DBUG, LOGP_DBUG,
				"PasswordErase was used for player %ld (theID=%ld), size=%ld\n",
				(long)whichPlayer, (long)item->theID, (long)item->size);
			
			state->passwordEraseCodeWasUsed = true;
			//
			// charge him 4 credits.
			//
			// BRAIN DAMAGE: this ought to use one of the routines at the
			// end of Server_CheckAccountCredits.c.  Won't usually matter.
			//
			state->account->boxAccount.usedCredits += kCreditsChargedForPasswordErase;
			state->creditDebitInfo.currentCredits -= kCreditsChargedForPasswordErase;
			state->creditChangeFlags |= kCreditChange_Penalize_PasswordCode;
			sprintf(mesg, gettext("You have been charged %ld credits for using the password erase code."), (long)kCreditsChargedForPasswordErase); /* DIALOG */
			Server_SendDialog(state, mesg, true);
			
			ASSERT(state->account->playerAccountValid);
			if(state->account->playerAccountValid)
			{
				if(whichPlayer == state->account->playerAccount.player)
				{
					// generate and send a new passwordEraseCode.
					//
					Server_GenerateAndSendPasswordEraseCode(state);
				}
				else
					Logmsg("Server_ProcessSendQ: password erase code was used by non-current player.  Not regenerating it.\n");
			}
			//
			// BRAIN DAMAGE
			// what if it is not the current player?  gotta be able to see all
			// playeraccounts.  shit.  for now we just won't reset that
			// player's passwdEraseCode if not the current player.  sigh.
			//  11.9.94  dj
			//
			
			break;
		case kStreamErrorReportQElement:
			// Do nothing.  This is now handled by a separate call, earlier
			// in the login process.
			//
			break;
		case kMatchupRegurgQElement:
			// Do nothing.  This is displayed in Server_GameSpecific.c.
			//
			break;
		case kModemSelfTestDataQElement:
		{
			long pattern;
			long newModemVersion = kRockwellUnknown;

			Logmsg("kModemSelfTestDataQElement: ");
			if (item->size == 10)	// snes
			{
				pattern = (item->data[9] << 24) | (item->data[8] << 16) |
						  (item->data[7] << 8)  | (item->data[6]);
			}
			else if (item->size == 4)	// sega
			{
				pattern = *(long *)item->data;
			}
			else
			{
				PLogmsg(LOGP_NOTICE,"Error: item size=%lu (expected 10 or 4)\n",
					item->size);
				break;
			}
			if (pattern == kRockwell2324Pattern)
				newModemVersion = kRockwell2324;
			else if (pattern == kRockwell2424Pattern)
				newModemVersion = kRockwell2424;
			else
			{
				pattern &= kRockwellMaskPattern;
				if (pattern == kRockwell2324Pattern&kRockwellMaskPattern)
					newModemVersion = kRockwell2324Assumed;
				if (pattern == kRockwell2424Pattern&kRockwellMaskPattern)
					newModemVersion = kRockwell2424Assumed;
			}
			if (newModemVersion != state->account->boxAccount.modemVersion[0])
			{
				Logmsg("changed from (%s) to '%.4s' (%s)",
					state->account->boxAccount.modemVersion[0]==kRockwell2324 ? "2324" :
					state->account->boxAccount.modemVersion[0]==kRockwell2424 ? "2424" :
					state->account->boxAccount.modemVersion[0]==kRockwell2324Assumed ? "2324 assumed" :
					state->account->boxAccount.modemVersion[0]==kRockwell2424Assumed ? "2424 assumed" :
					"unknown",
					(char *)&pattern,
					newModemVersion==kRockwell2324 ? "2324" :
					newModemVersion==kRockwell2424 ? "2424" :
					newModemVersion==kRockwell2324Assumed ? "2324 assumed" :
					newModemVersion==kRockwell2424Assumed ? "2424 assumed" :
					"unknown");
				state->account->boxAccount.modemVersion[0] = newModemVersion; 
				state->account->boxModified |= kBA_modemVersion;
				Server_RestoreModemStuff(state,state->account);
			}
			Logmsg("\n");
			break;
		}
		case kPeerTimeQElement:
			// Extract connections and ticks for peer connection
			//
			if (item->size < 6)
			{
				Logmsg("SendQ: item %ld (size=%ld) should have size=%ld!\n",
					(long) item->theID, (long) item->size, 6);
				break;
			}
			state->peerConnects = *((short *)item->data);
			state->peerSeconds = (*(unsigned short *)(item->data+2)) << 16;
			state->peerSeconds |= *(unsigned short *)(item->data+4);
			state->peerSeconds = (state->peerSeconds+59) / 60;	// round up ticks
			Server_SanityCheckPTEst(state);
			Server_XNU_AddMinutes(state, (state->peerSeconds+59)/60);
			break;
		case kSNESResetQElement:
			// Dump the thing, with hwid.
			//
			PLogmsg(LOGP_DBUG, "SNES Reset Info - ");
			Common_LogHardwareID(&state->loginData.hardwareID);
			FLoghexdump(LOG_VERBOSE, item->data, item->size);
			break;
		case kCordPullQElement:
			Server_UpdateCordPullData(state);
			break;
		case kSnesGameIDQElement:
			{
				struct {
					unsigned long	long3;
					unsigned long	long2;
					unsigned long	long1;
					unsigned short	short0;
				} gameIDstuff;
				unsigned char *src, *dst;

				src = (unsigned char *)item->data;
				dst = (unsigned char *)&gameIDstuff;
				if (item->size != sizeof(gameIDstuff) - 2) {
					Logmsg("SNES GameID Info %d bytes?\n", item->size);
					FLoghexdump(LOG_DBUG, item->data, item->size);
					break;	// out of case
				}

				// Data is little-endian short/long/long/long, so we have
				// to byte-swap and deal with the non-32bit-aligned stuff.
				//
				dst += item->size;
				while (dst > (unsigned char *)&gameIDstuff)
					*--dst = *src++;

				PLogmsg(LOGP_DBUG,
					"SNES GameID Info for (%ld,%ld) (stable=%d, os=%d): "
					"0x%.4x 0x%.8lx 0x%.8lx 0x%.8lx\n",
					state->account->boxAccount.box.box,
					state->account->boxAccount.box.region,
					state->boxOSState.osFree >> 16,
					state->systemVersionData.version,
					gameIDstuff.short0,
					gameIDstuff.long1,
					gameIDstuff.long2,
					gameIDstuff.long3);
				//FLoghexdump(LOG_DBUG, item->data, item->size);
			}
			break;
		default:
			if ((item->theID >= 0x10) && (item->theID <= 0x1F)) {
				// 2/22/95 6:01:41 PM (BET): record it generically for Herr Stadler
				Server_GenericRecordSQDebugging(state, item->theID, item->data, item->size);
				}
			// just drop it
			//Logmsg("Server_ProcessSendQ: ignored item with ID %ld\n",
			//	(long)item->theID);
			Logmsg("SendQ: unknown item %ld (size=%ld)\n",
				(long) item->theID, (long) item->size);
			if (item->size < 256)
				FLoghexdump(LOG_DBUG, item->data, item->size);
			else
				FLogmsg(LOG_DBUG, "  (too large to dump)\n");
			break;
		}
	}

	PLogmsg(LOGP_PROGRESS, "Server_ProcessSendQ done\n");
	return(kServerFuncOK);
}


// ===========================================================================
//		Crash records and XBN
// ===========================================================================

//
// Print the box history
//
void Server_DumpBoxHist(unsigned char *data, long size)
{
	ServerMonitorThing *smt = (ServerMonitorThing *)data;
	int i;

	if (size != sizeof(ServerMonitorThing)) {
		FPLogmsg(LOG_BOXHIST, LOGP_NOTICE,
			"WARNING: got %ld bytes, expected %d\n",
			size, sizeof(ServerMonitorThing));
	}
	if (smt->numItems > kMagicNumItems) {
		FPLogmsg(LOG_BOXHIST, LOGP_NOTICE,
			"WARNING: numItems = %d, max is %d, ignoring extras\n",
			smt->numItems, kMagicNumItems);
		smt->numItems = kMagicNumItems;
	}

	FPLogmsg(LOG_BOXHIST, LOGP_NOTICE, "  numItems = %d, serverError = %d\n",
		smt->numItems, smt->serverError);
	FPLogmsg(LOG_BOXHIST, LOGP_NOTICE, "##  opCode  bytesReady  time\n");
	for (i = 0; i < smt->numItems; i++) {
		FPLogmsg(LOG_BOXHIST, LOGP_DBUG, "%.2d    %3d     %5d     %4ld\n",
			i, smt->opCode[i], smt->bytesReady[i], smt->time[i]);
	}
}


// Stuff to help Andy1 interpret crash records
//

#ifndef NO_OS_STRINGS
# include "Server_segb_OSNumbers.h"
#endif

enum	{								// exception codes from restarts
	kBusError			=	1,			// handling a bus error
	kIllegal			=	2,			// an illegal instruction was hit
	kZeroDivide			=	3,			// zero divide
	kChkException		=	4,			// any other exception handler
	kTrapVException		=	5,
	kPrivException		=	6,
	kTraceException		=	7,
	kLineFException		=	8,
	kBadIRQException	=	9,
	kExtIRQException	=  10,
	kHorIRQException	=  11,
	kOddIRQException	=  12,
	kOtherException		=  13
};


PRIVATE int
Server_segb_PrintCrashRecord(ServerState *state,
	unsigned char *data, long blockSize)
{
	BoxRestartInfo	*cr;
	unsigned long	addr;
	long			dispNum;
	int				count;

	cr = (BoxRestartInfo *)data;
	
	if (blockSize != sizeof(BoxRestartInfo))	{
		// If what we got is smaller than the struct, dump it and bail.
		// If it's larger, assume it's Shannon adding junk to the end,
		// and show the normal dump, plus the extra stuff in hex.
		//
		FPLogmsg(LOG_CRASH, LOGP_DBUG,
			"WARNING: blockSize = %ld, sizeof(BoxRestartInfo) = %ld\n",
			blockSize, sizeof(BoxRestartInfo));
		if (blockSize < sizeof(BoxRestartInfo)) {
			FLoghexdump(LOG_CRASH, (unsigned char *)cr, blockSize);
			return (0);
		}
	}

	// temporary measure
	//FPLogmsg(LOG_CRASH, LOGP_DBUG, "--- full hex dump, as a sanity check ---\n");
	//FLoghexdump(LOG_CRASH, data, blockSize);
	
	FPLogmsg(LOG_CRASH, LOGP_DBUG, "D0-D3:  %.8lX %.8lX %.8lX %.8lX\n",
		cr->reg[ 0], cr->reg[ 1], cr->reg[ 2], cr->reg[ 3]);
	FPLogmsg(LOG_CRASH, LOGP_DBUG, "D4-D7:  %.8lX %.8lX %.8lX %.8lX\n",
		cr->reg[ 4], cr->reg[ 5], cr->reg[ 6], cr->reg[ 7]);
	FPLogmsg(LOG_CRASH, LOGP_DBUG, "A0-A3:  %.8lX %.8lX %.8lX %.8lX\n",
		cr->reg[ 8], cr->reg[ 9], cr->reg[10], cr->reg[11]);
	FPLogmsg(LOG_CRASH, LOGP_DBUG, "A4-A7:  %.8lX %.8lX %.8lX %.8lX\n",
		cr->reg[12], cr->reg[13], cr->reg[14], cr->reg[15]);

	if (cr->excCode == kBusError)	{
		addr = (cr->excAddr[0] << 16) | (cr->excAddr[1]);
		
		FPLogmsg(LOG_CRASH, LOGP_DBUG,
			"Bus Error, mode %X, addr %.8lX, instr %x\n",
			cr->excMode, addr, cr->excInstrReg);
	}
	
	addr = (cr->excPC[0] << 16) | (cr->excPC[1]);
	FPLogmsg(LOG_CRASH, LOGP_DBUG,
		"Status Reg %X, Exception PC %.8lX, Exception Code %x\n",
		cr->excSR, addr, cr->excCode);
	
	if (cr->unstablePC < 0)
		FPLogmsg(LOG_CRASH, LOGP_DBUG, "OS WAS UNSTABLE, from PC %.8lx\n",
			cr->unstablePC);
	else
		FPLogmsg(LOG_CRASH, LOGP_DBUG, "os was stable, from PC %.8lx\n",
			cr->unstablePC);

	FPLogmsg(LOG_CRASH, LOGP_DBUG, "dispatched calls:  ");
#ifdef NO_OS_STRINGS
	for (count = 0; count < kHistorySize; ++count)
		FPLogmsg(LOG_CRASH, LOGP_DBUG, "%d ", cr->histCallNums[count] / 4);
#else
	FPLogmsg(LOG_CRASH, LOGP_DBUG, "\n");
	for (count = 0; count < kHistorySize; ++count) {
		dispNum = cr->histCallNums[count] / 4;
		FPLogmsg(LOG_CRASH, LOGP_DBUG, "\t%2d: %d (%s)\n", count, dispNum,
			(dispNum >= 0 && dispNum < NELEM(segb_dispCallStrs)) ?
				segb_dispCallStrs[dispNum] : "(invalid)");
	}
#endif
	FPLogmsg(LOG_CRASH, LOGP_DBUG, "\n");
	FPLogmsg(LOG_CRASH, LOGP_DBUG, "called from PC's:  ");
	for (count = 0; count < kHistorySize; ++count)	{
		FPLogmsg(LOG_CRASH, LOGP_DBUG, "%8lX ", cr->histCallers[count]);
		if (count == 3) {
			FPLogmsg(LOG_CRASH, LOGP_DBUG, "\n");
			FPLogmsg(LOG_CRASH, LOGP_DBUG, "                   ");
		}
	}
	FPLogmsg(LOG_CRASH, LOGP_DBUG, "\n");

	FPLogmsg(LOG_CRASH, LOGP_DBUG,
		"prevEntry/2:  %X   OS state:  %X   Stack low water:  %.8lX\n",
		cr->prevEntry/2, cr->osState, cr->stackLowWater);

	FPLogmsg(LOG_CRASH, LOGP_DBUG,
		"startupFlags:  %.8lX   boxState:  %.8lX   lastBoxState:  %.8lX\n",
		cr->startupFlags, cr->boxState, cr->lastBoxState);
	
	FPLogmsg(LOG_CRASH, LOGP_DBUG,
		"Box id's:  Set [ %ld, %ld ]  Cold [ %ld, %ld ]  Warm [ %ld, %ld ] \n",
		cr->setBoxID.box, cr->setBoxID.region, 
		cr->coldBoxID.box, cr->coldBoxID.region, 
		cr->warmBoxID.box, cr->warmBoxID.region);

	if (blockSize != sizeof(BoxRestartInfo)) {
		FPLogmsg(LOG_CRASH, LOGP_DBUG, "--- extra junk: ----\n");
		FLoghexdump(LOG_CRASH, ((unsigned char *)cr) + sizeof(BoxRestartInfo),
			blockSize - sizeof(BoxRestartInfo));
	}
	return (0);
}


// Stuff to help Josh interpret crash records
//
#ifndef NO_OS_STRINGS
# include "Server_sn07_OSNumbers.h"
# include "Server_sj01_OSNumbers.h"
#endif

#define kSNESHistorySize (16)

typedef struct {
	unsigned short	AReg;			// 65816 register values at crash time
	unsigned short	XReg;
	unsigned short	YReg;
	unsigned short	DReg;			// Data Bank register
	unsigned short	SReg;
	unsigned short	PCReg;
	unsigned char	PBR;
	unsigned char	DBR;
	unsigned char	PReg;			// Status register
	unsigned char	crashType;		// 1-3 native mode, 4-7 emulated mode
	
			 long	unstablePC;		// last PC who set OSUnstable
	unsigned long	startupFlags;	// set by the startup code
	
	short	histCallNums[kSNESHistorySize];
	long	histCallers[kSNESHistorySize];
	short	prevEntry;

	short	osState;				// set by various routines

	BoxSerialNumber	setBoxID;		// the one set by _SetBoxSerialNumber
	BoxSerialNumber	coldBoxID;		// boxID at cold boot time
	BoxSerialNumber	warmBoxID;		// boxID at end of StartupSega
	
	unsigned long	stackLowWater;	// deepest stack depth (keep location in sync with CRuntime.aii)
	unsigned long	interruptedPC;	// NMI handler blasts the PC here
	
	long			boxState;		// copies of same from BoxSer
	long			lastBoxState;

	unsigned char	instructions[8];// instructions we were executing at the time
	unsigned long	dispatchVector;
	unsigned long	vblHandler;
	unsigned long	hblHandler;
	unsigned long	location0;
	unsigned short	uiState;		// what screen were we on
	short			heapNumber;
	unsigned short	maxFreeMemory;
	unsigned short	totalFreeMemory;
	unsigned short	blockSizeWanted;
	unsigned short	sparcStationsSuck;	// and need cheezy alignment crapola
	unsigned long	initFlags;		// the init flags passed into StartupSega
	unsigned long	startupFlags2;	// more space for these
} SNESRestartInfo;


//
// Patterns to match against specific crash records.
//
static const unsigned char newSNESCrashRecord[] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x84, 0x06, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 
	0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};

static const unsigned char mindwipeSNESCrashRecord[] = {
	0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x4A, 0x6F, 0x73, 0x68, 
	0x68, 0x73, 0x6F, 0x4A, 0x00, 0x84, 0x06, 0xC6, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 
	0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 
	0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 
	0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 
	0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 
	0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 
	0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x6F, 0x4A, 0x68, 0x73, 0x68, 0x73, 0x6F, 0x4A, 
	0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0xFF, 0xFF, 0xFF, 0xFF, 
	0xFF, 0xFF, 0xFF, 0xFF, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 
	0x68, 0x73, 0x6F, 0x4A, 0x4A, 0x6F, 0x73, 0x68, 0x4A, 0x6F, 0x73, 0x68, 0x68, 0x73, 0x6F, 0x4A, 
	0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x6F, 0x4A, 0x68, 0x73, 
	0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x68, 0x73, 0x6F, 0x4A, 0x68, 0x73, 0x6F, 0x4A 
};


PRIVATE int
Server_snes_PrintCrashRecord(ServerState *state,
	unsigned char *data, long blockSize)
{
	SNESRestartInfo *cr;
	long			dispNum;
	int				count;
	char			**dispCallStrs;
	int				maxDisp;

	cr = (SNESRestartInfo *)data;

	if (state->platformID == kPlatformSJNES) {
		dispCallStrs = (char **)sj01_dispCallStrs;
		maxDisp = NELEM(sj01_dispCallStrs);
	} else {
		dispCallStrs = (char **)sn07_dispCallStrs;
		maxDisp = NELEM(sn07_dispCallStrs);
	}

	if (blockSize != sizeof(SNESRestartInfo)) {
		// If what we got is smaller than the struct, dump it and bail.
		// If it's larger, assume it's Shannon adding junk to the end,
		// and show the normal dump, plus the extra stuff in hex.
		//
		FPLogmsg(LOG_CRASH, LOGP_DBUG,
			"WARNING: blockSize = %ld, sizeof(SNESRestartInfo) = %ld\n",
			blockSize, sizeof(SNESRestartInfo));
		if (blockSize < sizeof(SNESRestartInfo)) {
			FLoghexdump(LOG_CRASH, (unsigned char *)cr, blockSize);
			return (0);
		}
	}

	// temporary measure
	//FPLogmsg(LOG_CRASH, LOGP_DBUG, "--- full hex dump, as a sanity check ---\n");
	//FLoghexdump(LOG_CRASH, data, blockSize);

	// OK, I'm going to see if this is a "special" crash record or not.
	// Basically, there are two "special" crash records - filled with 0's,
	// and filled with 'Josh' strings (some endian-flipped)
	//
	// I just compare the crash record with binary dumps of these two crash
	// records, stored in static arrays.
	//
	if (memcmp((char *)cr, newSNESCrashRecord, sizeof(SNESRestartInfo)) == 0)
	{
		FPLogmsg(LOG_CRASH, LOGP_DBUG,
			"--- Factory-fresh SNES box crash-record detected ---\n");
		return (0);
	}
	if (memcmp((char *)cr, mindwipeSNESCrashRecord, sizeof(SNESRestartInfo)) == 0)
	{
		FLogmsg(LOG_CRASH,
			"--- SNES full mindwipe crash-record (%ld,%ld) ---\n",
			state->loginData.userID.box.box,
			state->loginData.userID.box.region);
		return (0);
	}


	FPLogmsg(LOG_CRASH, LOGP_DBUG,
		"A:   0x%.4X    X:   0x%.4X      Y:   0x%.4X   DP:   0x%.4X\n",
		cr->AReg, cr->XReg, cr->YReg, cr->DReg);
					
	FPLogmsg(LOG_CRASH, LOGP_DBUG,
		"S:   0x%.4X    PC:  %.2X/%.4X     DB:  0x%.2X     P:    0x%.2X\n",
		cr->SReg, cr->PBR, cr->PCReg, cr->DBR, cr->PReg);
			
	FPLogmsg(LOG_CRASH, LOGP_DBUG, "Type: 0x%.2X%s\n", cr->crashType,
			(cr->crashType & 0x80) ? "  *** SIMULATOR ***" : "");

	FPLogmsg(LOG_CRASH, LOGP_DBUG, "dispatched calls (%.4s):\n",
		(char *)&state->platformID);
	for (count = 0; count < kSNESHistorySize; ++count)
	{
		if ( count == cr->prevEntry )
		{
			FPLogmsg(LOG_CRASH, LOGP_DBUG, "---> %4d %-8.6lX",
				cr->histCallNums[count], cr->histCallers[count]);
		}
		else
		{
			FPLogmsg(LOG_CRASH, LOGP_DBUG, "     %4d %-8.6lX",
				cr->histCallNums[count], cr->histCallers[count]);
		}
#ifdef NO_OS_STRINGS
		FPLogmsg(LOG_CRASH, LOGP_DBUG, "    (??)\n");
#else
		dispNum = cr->histCallNums[count];
		FPLogmsg(LOG_CRASH, LOGP_DBUG, "    %s\n",
			(dispNum >= 0 && dispNum < maxDisp) ?
				dispCallStrs[dispNum] : "(invalid)");
#endif
	}

	FPLogmsg(LOG_CRASH, LOGP_DBUG,
		"prevEntry:   0x%X    OS state:    0x%X    Stack low water: 0x%.8lX\n",
		cr->prevEntry, cr->osState, cr->stackLowWater );

	FPLogmsg(LOG_CRASH, LOGP_DBUG,
		"UnstablePC:   0x%.8lX   startupFlags:  0x%.8lX\n",
		cr->unstablePC, cr->startupFlags);

	FPLogmsg(LOG_CRASH, LOGP_DBUG,
		"interruptedPC:  0x%.8lX   boxState:  0x%.8lX   lastBoxState:  0x%.8lX\n",
		cr->interruptedPC, cr->boxState, cr->lastBoxState);

	FPLogmsg(LOG_CRASH, LOGP_DBUG, "Instructions: ");
	for (count = 0; count < 8; count++ )
	{
		FPLogmsg(LOG_CRASH, LOGP_DBUG, "%.2X ", cr->instructions[count]);
	}
	FPLogmsg(LOG_CRASH, LOGP_DBUG, "\n");

	FPLogmsg(LOG_CRASH, LOGP_DBUG,
		"dispatchVector:  0x%.8lX   vblHandler:  0x%.8lX   hblHandler:  0x%.8lX\n",
		cr->dispatchVector, cr->vblHandler, cr->hblHandler);

	FPLogmsg(LOG_CRASH, LOGP_DBUG,
		"location0:  0x%.8lX   initFlags:  0x%.8lX   startupFlags2:  0x%.8lX\n",
		cr->location0, cr->initFlags, cr->startupFlags2);

	FPLogmsg(LOG_CRASH, LOGP_DBUG,
		"uiState:  %d   heapNumber:  %d   maxFreeMemory:  0x%.4X\n",
		cr->uiState, cr->heapNumber, cr->maxFreeMemory);

	FPLogmsg(LOG_CRASH, LOGP_DBUG,
		"totalFreeMemory:  0x%.4X   blockSizeWanted:  0x%.4X   sparcStationsRule:  0x%.4X\n",
		cr->totalFreeMemory, cr->blockSizeWanted, cr->sparcStationsSuck);

	FPLogmsg(LOG_CRASH, LOGP_DBUG,
		"Box id's:  Set [ %ld, %ld ]  Cold [ %ld, %ld ]  Warm [ %ld, %ld ] \n",
		cr->setBoxID.box, cr->setBoxID.region,
		cr->coldBoxID.box, cr->coldBoxID.region,
		cr->warmBoxID.box, cr->warmBoxID.region);

	if (blockSize != sizeof(SNESRestartInfo)) {
		FPLogmsg(LOG_CRASH, LOGP_DBUG, "--- extra junk: ----\n");
		FLoghexdump(LOG_CRASH, ((unsigned char *)cr) + sizeof(SNESRestartInfo),
			blockSize - sizeof(SNESRestartInfo));
	}
	return (0);
}


//
// Unknown platform, just dump it in hex.
//
PRIVATE int
Server_any_PrintCrashRecord(ServerState *state,
	unsigned char *data, long blockSize)
{
	BoxRestartInfo	*cr;

	cr = (BoxRestartInfo *)data;
	
	FLoghexdump(LOG_CRASH, (unsigned char *)cr, blockSize);
	return (0);
}


//
// What fucking ever.
//
void
Server_GenericRecordSQDebugging(ServerState *state, int theID, void *data, int size)
{
SQSaveTuple		*sqs;

	sqs = (SQSaveTuple *)malloc(sizeof(SQSaveTuple));
	if (sqs) {
		sqs->id = theID;
		sqs->data = data;
		sqs->size = size;
		sqs->next = state->SQSHead;
		state->SQSHead = sqs;
	}
}

#define kMaxPeerConnects 40
#define kMaxPeerSeconds (4*60*60)

PRIVATE void Server_SanityCheckPTEst(ServerState *state)
{
	long maxPossibleSeconds;
	long revised = 0;
	
// display what box uploaded
	
	Logmsg("kPeerTimeQElement: connects=%d duration=%02lu:%02lu:%02lu "
		"(%ld secs) {%.4s}\n",
		state->peerConnects,
		state->peerSeconds/3600,
		(state->peerSeconds / 60) % 60,
		state->peerSeconds % 60,
		state->peerSeconds,
		(char *)&state->boxType);

// sanity check peer connects

	if (state->peerConnects > kMaxPeerConnects)
	{
		PLogmsg(LOGP_NOTICE,"Sanity check of peerConnects %ld > %ld.\n",
			state->peerConnects, kMaxPeerConnects);
		state->peerConnects = kMaxPeerConnects;
		revised = 1;
	}
	else if (state->peerConnects < 0)
	{
		PLogmsg(LOGP_NOTICE,"Sanity check of peerConnects < 0!\n");
		state->peerConnects = 0;
		revised = 1;
	}
	
// sanity check peer seconds
	
	maxPossibleSeconds = state->timeOfThisConnect - state->account->boxAccount.lastMatchup.when;
	if (maxPossibleSeconds > kMaxPeerSeconds)
		maxPossibleSeconds = kMaxPeerSeconds;

	if (state->peerSeconds > maxPossibleSeconds)
	{
		PLogmsg(LOGP_NOTICE,"Sanity check of peerSeconds %ld > %ld.\n",
			state->peerSeconds, maxPossibleSeconds);
		state->peerSeconds = maxPossibleSeconds;
		revised = 1;
	}
	else if (state->peerSeconds < 0)
	{
		PLogmsg(LOGP_NOTICE,"Sanity check of peerSeconds < 0!\n");
		state->peerSeconds = 0;
		revised = 1;
	}

// display what box uploaded

	if (revised) {
		Logmsg("kPeerTimeQElement(cropped): connects=%d duration=%02lu:%02lu:%02lu "
			"(%ld secs) {%.4s}\n",
			state->peerConnects,
			state->peerSeconds/3600,
			(state->peerSeconds / 60) % 60,
			state->peerSeconds % 60,
			state->peerSeconds,
			(char *)&state->boxType);
	}
}
