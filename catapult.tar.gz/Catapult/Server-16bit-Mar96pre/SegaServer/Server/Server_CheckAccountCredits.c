/*
 * Copyright: @ 1995 Catapult Entertainment Inc., all rights reserved
 *
 *
 *	$Id: Server_CheckAccountCredits.c,v 1.25 1996/01/25 17:51:43 hufft Exp $
 *
 *	$Log: Server_CheckAccountCredits.c,v $
 * Revision 1.25  1996/01/25  17:51:43  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.24  1996/01/15  16:45:02  davej
 * Allow accounts in free first month to log on regardless of their credit
 * counters.  This was needed for Instant Access policy, as the 250-credit
 * people are now starting off with usedCredits=0, and could not connect in
 * their free month (credits were being checked before dates).
 *
 * Revision 1.23  1996/01/05  18:22:51  felix
 * Added decimal representation of smartCard serial numbers to PLog's
 *
 * Revision 1.22  1995/11/13  17:08:26  jhsia
 * changed customer service phone number to 408-777-1500
 *
 * Revision 1.21  1995/11/06  02:45:03  felix
 * Moved Server_SendDebitSmartcard, Server_SendCreditToken functions to
 * Server_SmartCards.c, and changed Server_DeductCredit so if useDebitCardOnly
 * is set, decrement state->creditDebitInfo.currentCredits
 *
 * Revision 1.20  1995/10/27  19:43:32  steveb
 * Just did some long needed housecleaning.  No new code.
 *
 * Revision 1.19  1995/09/13  14:24:23  ted
 * Fixed warnings.
 *
 * Revision 1.18  1995/08/03  15:14:59  davej
 * Modified definition of "free first month" to be a calendar month rather
 * than 30 days.  Changed Server_IsFreeMonth to call new function
 * Server_AddMonth which does all the figgerin'.
 *
 * Revision 1.17  1995/07/10  20:57:39  rich
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.16  1995/07/05  18:00:01  davej
 * Modified Server_IsFreeMonth to reflect new policy: free period is always
 * first 30 days following activationDate.
 *
 * Revision 1.15  1995/06/16  19:28:34  davej
 * Check for credits = (0,0,0) bug.  If we find it, set kBoxFlag_CreditsBroken
 * bit (new for this fix).  If the bit is set, let the account play regardless
 * of credits settings.  When deducting credits, don't if that bit is set.
 * Finally, if the bit is set and credits are no longer (0,0,0), clear bit.
 *
 * Revision 1.14  1995/06/12  17:13:06  fadden
 * Changed 800-X4-XBAND to 1-800-X4-XBAND to make Joey happy.
 *
 * Revision 1.13  1995/06/05  16:28:12  davej
 * Fixed off-by-one credit counting bug: Server_IsFreeMonth now checks
 * dateLastConnect, not time(NULL), for deciding whether IsFreeMonth or not.
 *
 * Revision 1.12  1995/05/26  23:46:03  jhsia
 * switch to rcs keywords
 *
 * Revision 1.11  1995/05/26  19:04:10  davej
 * Added a NASTY POO-POO HACK to track credits used during a customer's free
 * first month period; using usedFreeCredits field to keep this value.
 *
 * Revision 1.10  1995/05/25  22:41:16  davej
 * Oops...added Id and Log lines to header.
 *
 *
 *
 */

// Let everyone play for free in Jan 95.
// 12.27.94
// Turned this off -- we're charging now!
// 5.24.95 davej
//#define FREE_JANUARY


//
// Barfy hack that lets everyone play, regardless of whether their account is open.
// 12.3.94.  dj
//
// Disabled on 2/22/95.  Now you must have an open active account to play.  Yay!  dj
//
// #define FREEHACK
//



//#define TESTACCOUNTSHIT		// turn this off before final!!
/*
	File:		Server_CheckAccountCredits.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<22>	12/15/94	DJ		Tweak to the 52 all-you-can-eat.
		<21>	 12/5/94	DJ		Added FREEHACK to allow people with suspended accounts to login.
		<20>	 12/2/94	HEC		Added Server_PenalizeCreditCreditOther.
		<19>	 12/1/94	DJ		Dealing with billingType.  Turned off some BETA hacks.  Added
									the startFreeCredits barf hack.
		<18>	11/30/94	DJ		Turned off box disablewithpassword when account closed.
		<17>	11/29/94	DJ		Printing smartcard serialnum in hex.
		<16>	11/29/94	DJ		Clear the boxpassword if there is one or if csUpdatedFlags
									clearboxpassword bit is set.
		<15>	11/22/94	DJ		Will use freeCredits if it can.  Yuck!
		<14>	11/17/94	DJ		Added cheeze to make FCS customers work until Portal gets the
									credit stuff sent properly from UCA.
		<13>	11/17/94	KD		Updated dialog text (doug/kon).
		<12>	11/17/94	KD		Updated dialog box wording (doug/kon).
		<11>	11/15/94	DJ		fixing a dialog.
		<10>	11/15/94	DJ		Added proper FCS crediting (no smarcards, all you can eat, etc).
		 <9>	 11/9/94	DJ		Renamed some DB routines to DataBaseUtil_ and also to WrapperDB_
									(for Oracle).
		 <8>	 11/9/94	ATM		Added missing '\n' to end of a logmsg.
		 <7>	 11/6/94	ATM		Implemented refund/penalize functions.  Tweaked credit stuff.
		 <6>	 11/2/94	ATM		New recredit stuff (declared but not yet implemented).
		 <5>	10/24/94	DJ		Set kServerValidFlag_CheckAccountCredits to avoid checking
									credits twice (in case of boxrestore).
		 <4>	10/22/94	ATM		Let Server_SendDialog() do the log messages.
		 <3>	10/22/94	ATM		Put "dialog" (all caps) after a bunch of dialogs that didn't
									have it.
		 <2>	10/21/94	ATM		Changed "naughty" to "bad".
		 <1>	10/20/94	DJ		first checked in

	To Do:
*/



#include "ServerCore.h"
#include "Server.h"
#include "ServerState.h"
#include "Messages.h"
#include "UsrConfg.h"
#include "ServerDataBase.h"
#include "Common_ReadConf.h"
#include "Common_Missing.h"

#include "SegaIn.h"
#include "DBConstants.h"
#include "StringDB.h"
#include "DBTypes.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include <sys/types.h>
#include <sys/time.h>
#include <time.h>


int Server_IsAccountOpen(ServerState *state);
int Server_ValidateCreditStuff(ServerState *state);
int Server_IsFreeMonth(Account *account);

static time_t Server_AddMonth(const time_t date);
static void Server_AddCredits(Account *account, int credits);
static void Server_SubtractCredits(Account *account, int credits);

int Server_CheckAccountCredits(ServerState *state)
{
Err	err;


	PLogmsg(LOGP_PROGRESS, "Server_CheckAccountCredits\n");

	ASSERT(state->validFlags & kServerValidFlag_CreditDebitInfo);

	// Don't check the account twice (can happen if we restore a box, cuz DoRestore checks it).
	//

	if(state->validFlags & kServerValidFlag_CheckAccountCredits)
		return(kServerFuncOK);
	state->validFlags |= kServerValidFlag_CheckAccountCredits;

	// This doesn't need to get called for an 800 connect.
	// ATM 950314
	//
	if (state->abandonShip)
		return (kServerFuncOK);

	if (state->loginData.rentalCardSerialNum) {
		// User has a rental card installed.  Figure out if the card is still
		// valid.  They expire one week from their first use.
		//
		err = Server_IsRentalValid(state);
		if (err != kServerFuncOK)
			return(err);

	} else if (state->account) {
		//
		// Check if the account is open, closed, pending, or suspended.
		//
		err = Server_IsAccountOpen(state);
		if (err != kServerFuncOK)
			return(err);
	
		//
		// Do account credit lookup
		//
		if(!state->disallowAllService)
		{
			err = Server_ValidateCreditStuff(state);
			if (err != kServerFuncOK)
				return(err);
		}
	}


	PLogmsg(LOGP_PROGRESS, "Server_CheckAccountCredits done\n");
	return(kServerFuncOK);
}


//
// Check if the account is open, closed, pending, or suspended.
//
// Returns kServerFuncOK if the user should be allowed to log in,
// kServerFuncEnd if not.  Appropriate dialogs are sent.
//
int Server_IsAccountOpen(ServerState *state)
{
char		msg[256], tbuf[256];

startIsOpen:

	if( state->account->userAccount.accountStatus == CAT_ACCT_STATUS_ACTIVE || state->account->userAccount.accountStatus == CAT_ACCT_STATUS_BETA || state->account->userAccount.accountStatus == CAT_ACCT_STATUS_GUEST )
	{
		// Account is Open!  Set the activation date if this is a new account.
		//
		if(state->accountCreated)
		{
			state->account->userAccount.dateFirstConnect = state->timeOfThisConnect;
			state->account->userModified |= kUA_dateFirstConnect;
		}

		// If they have a box password, but managed to dial into the server,
		// then they must've typed the password in.
		//
		if(state->account->boxAccount.password[0])
			Server_ClearBoxPassword(state);
		return(kServerFuncOK);
	}
	
	else



#ifdef FREEHACK
//
// Barfy hack that lets everyone play, regardless of whether their account is open.
// 12.3.94.  dj
//

//
// Now refusing CLOSED accounts.
//
	if(state->account->userAccount.accountStatus == CAT_ACCT_STATUS_CLOSED)
	{
		BoxSerialNumber newBoxSer;

		// account is closed.  bounce them.  if they keep trying, lock them out.
		// need a lockout counter!
		Server_SendDialog(state, gettext("Your XBAND Account is closed.  Please call 408-777-1500 to re-open your account."), true);	/* DIALOG */

		state->disallowAllService = true;
//
// Man, this causes more customer service complaints than anything.  Don't do it!
//
//		Server_DisableBoxWithPassword(state, NULL);		// set box password so they can't log in again without calling Customer Service.


		// 12.19.94   
		// Since we will never reopen a closed account, may as well make the box "new"
		// again when the account gets closed.  That way it will look for a new
		// account.
		//
		newBoxSer.box = -1;
		newBoxSer.region = -1;
		Server_SendNewBoxSerialNumber(state, &newBoxSer);

		Logmsg("Server_CheckAccountCredits: CLOSED account %ld, %ld (boxid will now be -1, -1)\n", state->account->boxAccount.box.box, state->account->boxAccount.box.region);


		return(kServerFuncEnd);
	}

	if(1)
	{
		printf("FREEHACK.  Letting in account with status %ld\n", state->account->userAccount.accountStatus);
		if(state->accountCreated)
		{
			state->account->userAccount.dateFirstConnect = state->timeOfThisConnect;
			state->account->userModified |= kUA_dateFirstConnect;
		}

		return(kServerFuncOK);
	}
	else
#endif

	if(state->account->userAccount.accountStatus == CAT_ACCT_STATUS_PENDING)
	{

		// Account is pending.  Can be pending for activation date (eg. Christmas day) or payment verification.
		//
		if(state->account->userAccount.accountFlags &  CAT_ACCT_STATFLAG_PENDING_ACTIVATE)
		{
			// Account is open if today is after the activation date.
			//
			if(state->timeOfThisConnect >= state->account->userAccount.activationDate)
			{
				state->account->userAccount.dateFirstConnect = state->timeOfThisConnect;
				state->account->userModified |= kUA_dateFirstConnect;
				
				state->account->userAccount.accountFlags &= ~CAT_ACCT_STATFLAG_PENDING_ACTIVATE;
				state->account->userModified |= kUA_accountFlags;

				if(state->account->userAccount.accountFlags == 0)
				{
					state->account->userAccount.accountStatus = CAT_ACCT_STATUS_ACTIVE;
					state->account->userModified |= kUA_accountStatus;

					Logmsg("Server_IsAccountOpen: Your XBAND Account is now past its pending date.  It is open!  Have fun.\n");
				}
				else
					goto startIsOpen;	/* hmmm. there are more accountFlags, so can't just set account to open.  See what else is the problem. */
			}
			else
			{
				if(!strftime(tbuf, 256, "%A %B %d %Y", localtime(&state->account->userAccount.activationDate)))
					// I18N Appears:  When player tries to log in before the account 
					//           pending date has been reached.		
					// Solution: Player should wait until the pending date that 
					//           was chosen when the account was setup (usually happens 
					//           around Christmas time to naughty kids who open their
					//           presents early).
					//
					strcpy(msg, gettext("Your XBAND Account is not open yet.  Please try again later."));	/* DIALOG */
				else
					sprintf(msg, gettext("Your XBAND Account is not available for use until %s.  Please try again on that day."), tbuf);	/* DIALOG */

				Server_SendDialog(state, msg, true);
				
				state->disallowAllService = true;
				
				return(kServerFuncEnd);
			}
		}
		else
		if(state->account->userAccount.accountFlags &  CAT_ACCT_STATFLAG_PENDING_CREDIT)
		{
			// I18N Appears:  When new customer logs in but we have not 
			//           verified their credit card yet.  This should only happen if 
			//           the link from Portal to Litle is down.
			// Solution: UCA should notify Portal that Litle link may be down.
			//
			Server_SendDialog(state, gettext("Your XBAND Account is not open yet, pending payment verification.  Please try again later."), true);	/* DIALOG */
			state->disallowAllService = true;
			return(kServerFuncEnd);
		}
		else
		{
			// I18N Appears:  When player tries to log in before pending date arrives.
			// Solution: See above.  Player should wait until pending date.
			//
			Server_SendDialog(state, gettext("Your XBAND Account is not open yet.  Please try again later."), true);	/* DIALOG */
			Logmsg("Server_IsAccountOpen: Your XBAND Account is not open yet (unknown pending flag %ld).  Please try again later.\n", (long)state->account->userAccount.accountFlags);
			state->disallowAllService = true;
			return(kServerFuncEnd);
		}
	}
	
	else
	
	if(state->account->userAccount.accountStatus == CAT_ACCT_STATUS_SUSPENDED)
	{
		// Account is suspended (credit non-pay, bad behaviour, or at your parents' request).
		//
		if(state->account->userAccount.accountFlags &  CAT_ACCT_STATFLAG_SUSPEND_CREDIT)
		{
			// I18N Appears:  Either when the credit card billing failed or they 
			//           were suspended by Catapult for foul language on the Network.
			// Solution: If suspended for credit, they should give UCA a 
			//           new credit card number and UCA should try and Rebill 
			//           the account.  If suspended for bad behaviour, UCA should
			//           call Catapult.
			//
			Server_SendDialog(state, gettext("Your XBAND Account has been suspended.  Please call XBAND Customer Support at 716-871-HELP."), true);	/* DIALOG */
			state->disallowAllService = true;
			return(kServerFuncEnd);
		}
		else
		if(state->account->userAccount.accountFlags &  CAT_ACCT_STATFLAG_SUSPEND_BEHAVIOR)
		{
			Server_SendDialog(state, gettext("Your XBAND Account has been suspended.  Please call XBAND Customer Support at 716-871-HELP."), true);	/* DIALOG */
			state->disallowAllService = true;
			return(kServerFuncEnd);
		}
		else
		if(state->account->userAccount.accountFlags &  CAT_ACCT_STATFLAG_SUSPEND_REQUEST)
		{
			// I18N Appears:  If customer has previously called UCA to 
			//           suspend the account (perhaps they were going on holiday?).
			// Solution: As of 2/21/95 this has yet to be implemented by 
			//           UCA, so it shouldn't ever appear.  If it does, and UCA in 
			//           fact did suspend the account on the customer's request, 
			//           UCA should verify the access code and the open the account.
			//
			Server_SendDialog(state, gettext("Your XBAND Account has been suspended by request.  Please call XBAND Customer Support at 716-871-HELP."), true);	/* DIALOG */
			state->disallowAllService = true;
			return(kServerFuncEnd);
		}
		else
		{
			Server_SendDialog(state, gettext("Your XBAND Account has been suspended.  Please call XBAND Customer Support at 716-871-HELP."), true);	/* DIALOG */
			Logmsg("Server_IsAccountOpen: Your XBAND Account has been suspended (unknown suspend flag %ld).  Please try again later.\n", (long)state->account->userAccount.accountFlags);
			state->disallowAllService = true;
			return(kServerFuncEnd);
		}
	}
	
	else
	
	if(state->account->userAccount.accountStatus == CAT_ACCT_STATUS_CLOSED)
	{
		BoxSerialNumber newBoxSer;


		// account is closed.  bounce them.  if they keep trying, lock them out.
		// need a lockout counter!
		// I18N Appears:  When player logs in but their account is closed.
		// Solution: Customer should set up a new account.
		//
		Server_SendDialog(state, gettext("Your XBAND Account is closed.  Please setup call 408-777-1500 to re-open your account."), true);	/* DIALOG */

		state->disallowAllService = true;
//
// Man, this causes more customer service complaints than anything.  Don't do it!
//
//		Server_DisableBoxWithPassword(state, NULL);		// set box password so they can't log in again without calling Customer Service.


		// 12.19.94   
		// Since we will never reopen a closed account, may as well make the box "new"
		// again when the account gets closed.  That way it will look for a new
		// account.
		//
		newBoxSer.box = -1;
		newBoxSer.region = -1;
		Server_SendNewBoxSerialNumber(state, &newBoxSer);
		//
		// We should probably wipe the box's brain out too, so resold units look new.
		//

		Logmsg("Server_CheckAccountCredits: CLOSED account %ld, %ld (boxid will now be -1, -1)\n", state->account->boxAccount.box.box, state->account->boxAccount.box.region);


		return(kServerFuncEnd);
	}

	else
		Logmsg("Server_IsAccountOpen: Unknown account status value = %ld.\n", state->account->userAccount.accountStatus);

	return(kServerFuncOK);
}







//
// normal users should have infinite credits
// user "card" should have no credits, so lockout the box
// user "free" should get free games all the time (its a free day!)
// user "debit" will debit the smartcard again via the debit message.
//
// clear out the magic token each time.  this really only needs to be done if we sent a magic free token on the last
// connect (cuz that dumb old box doesn't clear it out).  But it is simpler to just clear that fucker out each time.
//

//
// For the initial ship in November 94, only accept credit accounts, no smartcards.
// So smartcards goto useCreditCardsOnly.
//

int Server_ValidateCreditStuff(ServerState *state)
{
userIdentification 	*userID;
Err					err;
char 				msg[300], blob[500];
#ifdef TESTACCOUNTSHIT
int					glarfErr = kServerFuncOK;
#endif

	userID = &state->loginData.userID;

	ASSERT(state->validFlags & kServerValidFlag_CreditDebitInfo);
	ASSERT(state->validFlags & kServerValidFlag_Account);

	// DEBUG message -- get rid of this later
	//
	PLogmsg(LOGP_DBUG, "CREDIT STATUS 1: used=%ld  start=%ld  max=%ld\n",
		state->account->boxAccount.usedCredits,
		state->account->boxAccount.startCredits,
		state->account->boxAccount.maxCredits);

#ifdef NOTUSINGTHISPOOP
/***** 
 * May need to add the check for using creditcard versus smartcard when we are handling smartcards.
 * The case I'm speaking of is if we disable the guy's account with a boxpassword, yet we still want
 * him to log in cuz he's using a smartcard (using a smartcard gets you around the box password),
 * but not clear the password out.
 *
 * Esoteric, maybe....   dj
 *
 *
 * Instead, clear the box password out if he ever gets this far and it is set in his account (cuz he must have
 * used it to log in).  See the code in the else of NOTUSINGTHISPOOP.

 **********/
	//
	// Rest here if the box has been disabled.  If so, and you logged in, it must be because
	// you either used a smartcard (or token) or you used the password.
	// If you used the password (ie. state->creditDebitInfo.usingType == kUsingCreditCard)
	// then we will turn off the password.
	//
	if(/* state->creditDebitInfo.usingType == kUsingCreditCard && */ state->account->boxAccount.password[0])
	{
		err = Server_ClearBoxPassword(state);
		if(err != kServerFuncOK)
			return(err);
	}
#else

 	//
	// If there is a box password, clear it.  Doing the flag check allows us to force a clear even if the database
	// thinks he has no password (there are very rare cases where the box thinks it has a password but the server may not.
	// Generally this only happens if there is a crash somewhere and the box loses its account or something... but it
	// has happened, so here's the flag).  11/29/94  dj
	//
	if(state->account->boxAccount.password[0] ||
		(state->account->boxAccount.csUpdatedFlags & kCSUpdatedFlag_ClearBoxPassword) )
	{
		err = Server_ClearBoxPassword(state);		// if there's a box password, clear it. 
		if(err != kServerFuncOK)
			return(err);
		
		
		if(state->account->boxAccount.csUpdatedFlags & kCSUpdatedFlag_ClearBoxPassword)
		{
			state->account->boxAccount.csUpdatedFlags &= ~kCSUpdatedFlag_ClearBoxPassword;
			state->account->boxModified |= kBA_csUpdatedFlags;
		}

	}

#endif



	//
	// If your account was just created, then we set your accounts to infinite if you are a beta tester.
	// otherwise the account credits should have been setup by UCA.
	//
	if(state->accountCreated)
	{
		// Give them infinite free credits for Beta
		//
		if(state->account->userAccount.accountStatus == CAT_ACCT_STATUS_BETA  || state->account->userAccount.billingType == CAT_ACCT_BILL_BETA)
		{
			char buf[512];

			state->account->boxAccount.maxCredits = kUnlimitedXBandCredits;	/* unlimited credits */	/* was: kFreeXBandCredits */
			state->account->boxModified |= kBA_credits;
			// I18N Appears:  Very rarely!  Usually only for Beta testers.
			// Solution: Enjoy!
			//
			sprintf(buf, gettext("You have been given unlimited free XBAND credits.  Enjoy!"),	/* DIALOG */
				(long)kFreeXBandCredits);
			Server_SendDialog(state, buf, true);
		}
	}

#ifdef FREE_JANUARY
	// Let everyone play for free in January 95.
	//
	return(kServerFuncOK);
#endif

	// Allow free play if use_credit_counting is FALSE
	//
	PLogmsg(LOGP_DBUG,
		"Server_ValidateCreditStuff: use_credit_counting is %s\n",
		gConfig.useCreditCounting ? "TRUE" : "FALSE");

	if (!gConfig.useCreditCounting)
		return(kServerFuncOK);
	

	//
	// Now do the real account maintainance
	//
	switch(state->creditDebitInfo.usingType)
	{
		// ATM 950130: I don't know exactly what this stuff is supposed to
		// do, but here it is.  We're no longer doing the "deduct now,
		// refund later" policy, and I'm not sure how this stuff will be
		// affected.  Doesn't look like we're using, so I'm going to leave
		// it alone.
		//
		case kUsingCreditToken:
				if(state->creditDebitInfo.debitCardInfo.problem)
				{
					switch(state->creditDebitInfo.debitCardInfo.problem)
					{
						case kNoDialtoneInServerConnectCardProb: strcpy(msg, "kNoDialtoneInServerConnectCardProb");
							break;
						case kSomeErrorInServerConnectCardProb: strcpy(msg, "kSomeErrorInServerConnectCardProb");
							break;
						case kLineBusyInServerConnectCardProb: strcpy(msg, "kLineBusyInServerConnectCardProb");
							break;
						case kServerConnectRetryDoneCardProb: strcpy(msg, "kServerConnectRetryDoneCardProb");
							break;
						case kServerCommErrorCardProb: strcpy(msg, "kServerCommErrorCardProb");
							break;
						case kGameFreeTimeOverCardProb: strcpy(msg, "kGameFreeTimeOverCardProb");
							break;
						case kPeerToPeerConnectCardProb: strcpy(msg, "kPeerToPeerConnectCardProb");
							break;
						case kSlaveTimedOutCardProb: strcpy(msg, "kSlaveTimedOutCardProb");
							break;
						default: sprintf(msg, "Unknown Problem Type %d!!!", state->creditDebitInfo.debitCardInfo.problem);
							break;
					}
#ifdef GRATUITOUS
					sprintf(blob, "(DEBUG) Using Problem Token = %ld, Type = '%s'\n", state->creditDebitInfo.debitCardInfo.token, msg); /* DIALOG */
					Server_SendLargeDialog(state, blob, true);
#endif
					Logmsg("Server_ValidateCreditStuff: Using Problem Token = %ld, Type = %s\n", state->creditDebitInfo.debitCardInfo.token, msg);
				}
				else
				{
#ifdef GRATUITOUS
					sprintf(blob, "(DEBUG) Using Credit Token = %ld.", state->creditDebitInfo.debitCardInfo.token); /* DIALOG */
					Server_SendLargeDialog(state, blob, true);
#endif
					Logmsg("Server_ValidateCreditStuff: Using Credit Token = %ld.\n", state->creditDebitInfo.debitCardInfo.token);
				}
				
				//
				// For FCS, support only credit cards.
				//
				goto useCreditCardsOnly;
				
			break;

		case kUsingDebitCard:
#ifdef GRATUITOUS
				sprintf(blob, "(DEBUG) Using Debit Card: serialno: %ld, credits left: %ld, recharges left: %ld.", /* DIALOG */
						state->creditDebitInfo.debitCardInfo.serialNumber,
						(long)state->creditDebitInfo.debitCardInfo.creditsLeft,
						(long)state->creditDebitInfo.debitCardInfo.rechargesLeft);
				Server_SendLargeDialog(state, blob, true);
#endif
				Logmsg("Using Debit Card: serialno: %ld, credits left: %ld, recharges left: %ld.\n",
						state->creditDebitInfo.debitCardInfo.serialNumber,
						(long)state->creditDebitInfo.debitCardInfo.creditsLeft,
						(long)state->creditDebitInfo.debitCardInfo.rechargesLeft);

				//
				// Even if gConfig.useDebitCardOnly is set, we use the same debiting
				// model as credit cards.
				//
				goto useCreditCardsOnly;

			break;
		
		case kUsingCreditCard:
//
// For the initial ship in November 94, only accept credit accounts, no smartcards.
// So smartcards goto useCreditCardsOnly.
//
useCreditCardsOnly:

				Logmsg("Using credit card account... used = %ld start = %ld max = %ld\n",
					state->account->boxAccount.usedCredits,
					state->account->boxAccount.startCredits,
					state->account->boxAccount.maxCredits);

				// HACK to tag accounts with broken credits and let them play anyway
				// See also Server_AddCredits and Server_SubtractCredits -- 6/16/95 davej
				//
				if ((state->account->boxAccount.startCredits == 0) &&
				    (state->account->boxAccount.usedCredits == 0) &&
				    (state->account->boxAccount.maxCredits == 0)) {
					PLogmsg(LOGP_NOTICE,
						"CREDITSBROKEN: setting kBoxFlag_CreditsBroken flag.\n");
					state->account->boxAccount.boxFlags |= kBoxFlag_CreditsBroken;
					state->account->boxModified |= kBA_boxFlags;
				}
				else
				if (state->account->boxAccount.boxFlags & kBoxFlag_CreditsBroken) {
					//
					// Account credits were "broken", but now they're no longer
					// set to (0,0,0) -- reset the bit.
					//
					PLogmsg(LOGP_NOTICE,
						"CREDITSBROKEN: clearing kBoxFlag_CreditsBroken.\n");
					state->account->boxAccount.boxFlags &= ~kBoxFlag_CreditsBroken;
					state->account->boxModified |= kBA_boxFlags;
				}

#ifdef USE_FREE_CREDITS
				if(state->account->boxAccount.usedFreeCredits < state->account->boxAccount.maxFreeCredits)
				{
					// If there are free credits, use them instead of real credits.
					// NOTE: freecredits don't get given back if we don't match you, etc.  Really, free credits should
					// be done by decrementing usedCredits.   11.22.94.  dj
					//
#ifdef DEDUCT_NOW
#error "You gotta fix it in Server_GameResults too"
					state->account->boxAccount.usedFreeCredits++;
					state->account->boxModified |= kBA_credits;
					Logmsg("Using Free Credit!  Remaining XBAND freeCredits now == %ld. (usedFree = %ld, maxFree = %ld).\n", 
						state->account->boxAccount.maxFreeCredits - state->account->boxAccount.usedFreeCredits,
						state->account->boxAccount.usedFreeCredits, state->account->boxAccount.maxFreeCredits);
#endif
				}
				else
#endif /* USE_FREE_CREDITS */
				if (state->account->boxAccount.boxFlags & kBoxFlag_CreditsBroken) {
					// HACK: just let them connect to keep them happy
					PLogmsg(LOGP_NOTICE,
						"CREDITSBROKEN: allowing connect for (0,0,0) account.\n");
				}
				else
				//
				// If account is in free first month, don't bother checking
				// credit counters.
				//
				if (Server_IsFreeMonth(state->account)) {
					Logmsg("Account is within free first month.  Accept login regardless of credits.\n");
				}
				else
				if(state->account->boxAccount.maxCredits != kUnlimitedXBandCredits)
				{
					if(state->account->boxAccount.usedCredits < state->account->boxAccount.maxCredits)
					{
#ifdef DEDUCT_NOW
						state->account->boxAccount.startFreeCredits++;	// this disgusting hack tracks how many credits used this month.  See SendAccountInfo.c
						state->account->boxAccount.usedCredits++;
						state->account->boxModified |= kBA_credits;
						Logmsg("Remaining XBAND credits now == %ld.\n", state->account->boxAccount.maxCredits - state->account->boxAccount.usedCredits);
#endif	/*DEDUCT_NOW*/
					}
					else
					{
						//
						// If this is a beta account, then give them more credits.  Else, the billing system must do it.  Just turn 'em away!
						//
						if(state->account->userAccount.accountStatus == CAT_ACCT_STATUS_BETA  || state->account->userAccount.billingType == CAT_ACCT_BILL_BETA)
						{
							Logmsg("your account is empty!  This connect will be turned away.\n");
							Logmsg("start=%d, used=%d, max=%d\n",
								state->account->boxAccount.startCredits,
								state->account->boxAccount.usedCredits,
								state->account->boxAccount.maxCredits);
							Logmsg("(OR NOT!)\n");
							// I18N Appears:  For Beta testers only.
							// Solution: Have fun!
							//
							Server_SendDialog(state, gettext("You have been given another 1000 XBAND credits.  Enjoy!"), true);	/* DIALOG */
							state->account->boxAccount.startCredits = -1000;
							state->account->boxAccount.usedCredits = -1000;
							state->account->boxAccount.maxCredits = 0;
							state->account->boxModified |= kBA_credits;
						}
						else
#ifdef USE_ALL_YOU_CAN_EAT
						if(state->account->boxAccount.maxCredits >= kAllYouCanEatCredits)
						{
							//
							// This is a big BRAIN DAMAGE hack that should be removed by Jan 1, 95.
							// This basically allows anyone who has a spending cap over the basic $7.95 plan to keep on playing
							// past their limit.  This is because we're going to give them "all you can eat" until Jan 95
							// because Compuserve is giving us the connect time at a flat rate till then.  Yahoo!  More traffic!
							// See also Server_SendAccountInfo.c
							// 11/15/94/dj
							//
#ifdef DEDUCT_NOW
							state->account->boxAccount.usedCredits++;
							state->account->boxAccount.startFreeCredits++;	// this disgusting hack tracks how many credits used this month.  See SendAccountInfo.c
							state->account->boxModified |= kBA_credits;
#endif	/*DEDUCT_NOW*/


							if(state->account->boxAccount.usedCredits == kAllYouCanEatCredits)
								Server_SendLargeDialog(state, gettext("You will not be charged for any additional connect credits this month."), true);	// send it only once.  /* DIALOG */

							
							Logmsg("Using all you can eat privileges.  usedCredits = %ld, maxCredits = %ld\n",
								state->account->boxAccount.usedCredits,
								state->account->boxAccount.maxCredits);
						}
						else
#endif /* USE_ALL_YOU_CAN_EAT */
						{
							Logmsg("your account is empty!  This connect will be turned away.\n");
							Logmsg("start=%d, used=%d, max=%d\n",
								state->account->boxAccount.startCredits,
								state->account->boxAccount.usedCredits,
								state->account->boxAccount.maxCredits);
						
							Server_SendLargeDialog(state, gettext("You have run out of credits for this month.  To increase your Spending Cap, call XBAND Customer Support at 716-871-HELP."), true);	/* DIALOG */
							
							state->disallowGameConnect = true;
							state->disallowAllService = true;
							return(kServerFuncEnd);		// goodbye!
							// return(Server_DisableBoxWithPassword(state, "Your account has been disabled because your credit card account is empty.  Call Catapult at (408) 366-1735 to re-enable your account."));	/* DIALOG */
						}
					}
				}
				else
				{
					/* unlimited credits */

					Logmsg("Credits are unlimited.  You have used: %ld\n", state->account->boxAccount.usedCredits - state->account->boxAccount.startCredits);

#ifdef DEDUCT_NOW
					state->account->boxAccount.usedCredits++;			/* how many you've used */
					state->account->boxAccount.startFreeCredits++;		// this disgusting hack tracks how many credits used this month.  See SendAccountInfo.c
					state->account->boxModified |= kBA_credits;
#endif	/*DEDUCT_NOW*/
				}

			break;
		
		default:
				sprintf(blob, "(DEBUG) Unknown creditDebit usingType #%d!  Server will kill the connection.\n", state->creditDebitInfo.usingType); /* DIALOG */
				PLogmsg(LOGP_FLAW,
					"Unknown usingType #%ld!  Kill the connection.\n",
					state->creditDebitInfo.usingType);

				goto useCreditCardsOnly;	// BARF!

				Server_SendLargeDialog(state, blob, true);
				return(kServerFuncAbort);
			break;
	}






#ifdef TESTACCOUNTSHIT

	//
	// Check if the user is "card".  If so, turn off the box if he's not using a smartcard!
	//
	if(!strncmp( userID->userName,  "card", strlen("card")))
	{
	
		glarfErr = Server_SendCreditToken(state, 0);	// clear out the magic token

		if(state->creditDebitInfo.usingType != kUsingCreditCard)
			return(glarfErr);

		// I18N Appears: NEVER.
		//
		return(Server_DisableBoxWithPassword(state, gettext("Your account has been disabled because you don't have a credit card account, you bum.  Call Catapult to get your password.  (Hint: it is ABBABB).")));  // BRAIN DAMAGE, bad message DIALOG

	}

	if(!strncmp( userID->userName,  "free", strlen("free")))
	{
		if(state->creditDebitInfo.usingType == kUsingCreditToken)
		{
			sprintf(msg, "Today is a free day!  You will not be charged a credit for this game. (DEBUG) [got magic token from you. new token = %ld]", /*DIALOG*/
						(long)state->creditDebitInfo.debitCardInfo.token + 1L);
			Server_SendLargeDialog(state, msg, false);
			return(Server_SendCreditToken(state, state->creditDebitInfo.debitCardInfo.token + 1));
		}
		if(state->creditDebitInfo.usingType == kUsingDebitCard)
		{
			sprintf(msg, "Today is a free day!  You will not be charged a credit for this game.  (DEBUG)[card #%ld, new token = %ld]", /*DIALOG*/
				(long)state->creditDebitInfo.debitCardInfo.serialNumber, 444L);
			Server_SendLargeDialog(state, msg, false);
			return(Server_SendCreditToken(state, 444L));
		}
		if(state->creditDebitInfo.usingType == kUsingCreditCard)
		{
			// I18N Appears: NEVER.
			//
			Server_SendDialog(state, gettext("Today is a free day!  You will not be charged a credit for this game."), false); /*DIALOG*/
			return(Server_SendCreditToken(state, 0));	// clear out the magic token
		}
		
		//
		// This is very bad because Server_ReceiveCreditDebitInfo should have already caught this and killed the connection.
		//
		PLogmsg(LOGP_FLAW, "Unknown usingType #%ld!  Kill the connection.\n",
			(long)state->creditDebitInfo.usingType);
		ASSERT_MESG(0, "Implementation error.  Server_ReceiveCreditDebitInfo should have already caught this.");
		return(kServerFuncAbort);
	}

	if(!strncmp( userID->userName,  "debit", strlen("debit")))
	{
		if(state->creditDebitInfo.usingType == kUsingCreditCard)
		{
			Server_SendDialog(state, "(DEBUG) Server can't debit your smartcard via message if you connect without one!", true); /*DIALOG*/
			return(kServerFuncOK);
		}

		if(state->creditDebitInfo.usingType == kUsingCreditToken)
		{
			sprintf(msg, "(DEBUG) Got magic token from you = %ld]", /* DIALOG */
						(long)state->creditDebitInfo.debitCardInfo.token);
			Server_SendLargeDialog(state, msg, false);
		}
		
		//
		// Must clear out the magic token, or the card will not debit!
		//
		Server_SendCreditToken(state, 0);
		
		return(Server_SendDebitSmartcard(state, 4));
	}
	
		
#endif TESTACCOUNTSHIT

	// DEBUG message -- take this out later...
	//
	PLogmsg(LOGP_DBUG, "CREDIT STATUS 2: used=%ld  start=%ld  max=%ld\n",
		state->account->boxAccount.usedCredits,
		state->account->boxAccount.startCredits,
		state->account->boxAccount.maxCredits);

	// ATM 950130: dunno how this relates to whether we deduct a credit
	// now or do it when examining game results.  Currently ignoring the
	// issue, which is probably a bad idea when dealing with smartcards.
	//
	return(Server_SendCreditToken(state, 0));	// clear out the magic token
}

// ===========================================================================
//		Credit manipulation
// ===========================================================================

//
// Refund a credit to current box.
//
Err Server_RefundCredit(ServerState *state)
{
	Server_AddCredits(state->account, 1);
	return (kNoError);
}

//
// Refund a credit to some other box.
//
Err Server_RefundCreditOther(ServerState *state, BoxSerialNumber *box)
{
	Account *account;
	userIdentification tmpUserID;

#ifdef FREE_JANUARY
	return (kNoError);
#endif

	// Allow free play if use_credit_counting is FALSE
	//
	if (!gConfig.useCreditCounting)
		return(kNoError);

	tmpUserID.box.box = box->box;
	tmpUserID.box.region = box->region;
	tmpUserID.userID = 0;	// doesn't matter
	tmpUserID.userName[0] = '\0';
	if ((account = WrapperDB_GetAccount(&tmpUserID)) == NULL) {
		FLogmsg(LOGP_FLAW, "Unable to recredit (%ld,%ld), GetAccount failed\n",
			box->box, box->region);
		return (kFucked);
	}

	Server_AddCredits(account, 1);

	WrapperDB_UpdateAccount(account);
	DataBaseUtil_FreeAccount(account);

	return (kNoError);
}

//
// Penalize credits from another box.
//
Err Server_DeductCreditOther(ServerState *state, BoxSerialNumber *box)
{
	Account *account;
	userIdentification tmpUserID;

#ifdef FREE_JANUARY
	return (kNoError);
#endif

	// Allow free play if use_credit_counting is FALSE
	//
	if (!gConfig.useCreditCounting)
		return(kNoError);

	tmpUserID.box.box = box->box;
	tmpUserID.box.region = box->region;
	tmpUserID.userID = 0;	// doesn't matter
	tmpUserID.userName[0] = '\0';
	if ((account = WrapperDB_GetAccount(&tmpUserID)) == NULL) {
		FLogmsg(LOGP_FLAW, "Unable to penalize (%ld,%ld), GetAccount failed\n",
			box->box, box->region);
		return (kFucked);
	}

	Server_SubtractCredits(account, 1);

	WrapperDB_UpdateAccount(account);
	DataBaseUtil_FreeAccount(account);

	return (kNoError);
}

//
// Penalize a credit from the current box.
//
Err Server_DeductCredit(ServerState *state)
{

    if (gConfig.useDebitCardOnly) {
		// 
		// Deduct credits from the smartcard; Ignore account credits.
		// 
		Logmsg("Server_DeductCredit: Deducting credit from debit card\n");
		state->creditDebitInfo.currentCredits--;
    } else
		Server_SubtractCredits(state->account, 1);

	return (kNoError);
}

//
// Given a time_t, return the time_t which is one calendar month later.
// For example, Jan 1 --> Feb 1; Jan 31 1995 --> Feb 28 1995;
// Jan 31 1996 (leap year) --> Feb 29 1995, etc...
//
static time_t Server_AddMonth(const time_t date)
{
	static char	daysInMonth[12]
			= {31, 28, 31, 30, 31, 30,
			   31, 31, 30, 31, 30, 31};
	char		daysInNextMonth, deltaDays;
	struct tm	dateTm;
	struct tm	*dateTmP, *retDateTmP;
	time_t		retDate;
	u_int		nextMonth, year;

	// What month is it?
	//
	dateTmP = localtime(&date);
	dateTm  = *dateTmP;		// make copy of localtime buf
	dateTmP = &dateTm;		// drop ptr to localtime buf

	nextMonth = (dateTm.tm_mon + 1) % 12;

	// Figger the number of days between the input date
	// and the same day of the following month, unless the
	// input date falls on a date which does not exist in
	// the following month (e.g., Jan 31st).  In this case we
	// count up to the last valid day of the following month.
	//
	if (dateTm.tm_mday <= daysInMonth[nextMonth])
		deltaDays = daysInMonth[dateTm.tm_mon];
	else {
		// Special case: the input date day-of-month
		// doesn't exist next month (e.g., Jan. 31st)
		//
		daysInNextMonth = daysInMonth[nextMonth];
		//
		// Another special case: adjust for Feb. 29th in leap years
		//
		if (nextMonth == 1) {	// February
			year = dateTm.tm_year + 1900;
			if (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0))
				//
				// Next month is a leap February!
				//
				daysInNextMonth = 29;
		}
		deltaDays = daysInNextMonth + (daysInMonth[dateTm.tm_mon] - dateTm.tm_mday);
	}
		
	// Calculate tentative return date
	//
	retDate = date + deltaDays*24*60*60;

	// One last weirdo case: did we switch to/from DST between
	// the input date and the return date?  If so, adjust.
	//
	retDateTmP = localtime(&retDate);
	if ((dateTm.tm_isdst >= 0) && (retDateTmP->tm_isdst >= 0))
		if (dateTm.tm_isdst && !retDateTmP->tm_isdst)
			//
			// Switch from DST during free month
			//
			retDate += 1*60*60;
		else if (!dateTm.tm_isdst && retDateTmP->tm_isdst)
			//
			// Switch to DST during free month
			//
			retDate -= 1*60*60;
	
	return retDate;
}


//
// See if the account's last connect was in its "free month" period.
//
int
Server_IsFreeMonth(Account *account)
{
	struct tm	*conntm;
	time_t		payDay;
	int		ret_val;
	char		tbuf[256];
	char		*payDayStr;

	//
	// If no activationDate is present, what to do?  Return FALSE.
	//
	if (!account->userAccount.activationDate) {
		//
		// Make log message same priority as CreditDeduct messages
		// (in Server_GameResults)
		//
		Logmsg("Server_IsFreeMonth: activationDate is NULL; returning FALSE.\n");
		return(FALSE);
	}

	// Add one calendar month to activationDate, giving
	// date & time when we start counting credits
	//
	payDay = Server_AddMonth(account->userAccount.activationDate);

	//
	// Compare beginning of paid period with date of *last* connect,
	// since the code that calls us always deducts for connect 'n'
	// on connect 'n+1'.  We need to know if the last connect, not
	// the current connect, was during the free period.
	//
	ret_val = (account->userAccount.dateLastConnect < payDay);

	conntm = localtime(&account->userAccount.dateLastConnect);
	strftime(tbuf, 256, "%d %b %y", conntm);
	Logmsg("Server_IsFreeMonth: last connect (%s)%s within free month period.\n",
		tbuf, ret_val ? "" : " not");

	payDayStr = strdup(ctime(&payDay));
	Logmsg("Server_IsFreeMonth: free month expire%s %s",
		ret_val ? "s" : "d", payDayStr);
	free(payDayStr);

	return(ret_val);
}


//
// Add a credit to the specified account.
//
// Minor brain damage: if he's currently working his way through "free"
// credits, this will still add it to "normal" credits.  Not sure if this
// matters.
//
static void
Server_AddCredits(Account *account, int credits)
{
#ifdef FREE_JANUARY
	return;
#endif

	// HACK: don't change credits for accounts with "broken" credits (0,0,0)
	//
	if (account->boxAccount.boxFlags & kBoxFlag_CreditsBroken) {
		PLogmsg(LOGP_NOTICE,
			"CREDITSBROKEN: skipping AddCredits, kBoxFlag_CreditsBroken is set.\n");
		return;
	}
	
	// Don't change credits if use_credit_counting is FALSE
	//
	if (!gConfig.useCreditCounting)
		return;

	if (credits <= 0) {
		PLogmsg(LOGP_FLAW, "ERROR: AddCredits with credits=%d\n", credits);
		return;
	}
	Logmsg("CREDIT: Refunding %d credit%s to (%ld,%ld)\n",
		credits, (credits == 1) ? "" : "s",
		account->boxAccount.box.box, account->boxAccount.box.region);

	//
	// Don't mess with credits unless the config switch is on.
	//
	if (gConfig.useCreditCounting)
		//
		// Bump usedCredits unless they're in their first free month.
		//
		if (!Server_IsFreeMonth(account))
			account->boxAccount.usedCredits -= credits;
		//
		// HACK ALERT * HACK ALERT * HACK ALERT * HACK ALERT
		//
		// We're stealing the usedFreeCredits field, currently unused, to
		// keep track of how many credits a customer uses during their
		// free first month period.  CS might want to know...  --davej
		//
		else
			account->boxAccount.usedFreeCredits -= credits;
		//
		// END HACK * END HACK * END HACK * END HACK
		//

#ifdef DISGUSTING_HACK
	account->boxAccount.startFreeCredits -= credits;	// this disgusting hack tracks how many credits used this month.  See SendAccountInfo.c
#endif /* DISGUSTING_HACK */

	account->boxModified |= kBA_credits;

	Logmsg("  Remaining credits now %ld%s\n",
#ifdef USE_FREE_CREDITS
		(account->boxAccount.maxFreeCredits -
			account->boxAccount.usedFreeCredits) +
#endif
		(account->boxAccount.maxCredits -
			account->boxAccount.usedCredits),
		(account->boxAccount.maxCredits == kUnlimitedXBandCredits) ?
			" [unlimited]" : "" );
}

//
// Subtract credits from the specified account.
//
// Use free credits if they exist; if not, deduct real credits.
//
// (Haven't thoroughly tested it with credits != 1, since nothing calls it
// that way yet.  Caveat emptor.)
//
static void
Server_SubtractCredits(Account *account, int credits)
{
#ifdef FREE_JANUARY
	return;
#endif

	// HACK: don't change credits for accounts with "broken" credits (0,0,0)
	//
	if (account->boxAccount.boxFlags & kBoxFlag_CreditsBroken) {
		PLogmsg(LOGP_NOTICE,
			"CREDITSBROKEN: skipping SubtractCredits, kBoxFlag_CreditsBroken is set.\n");
		return;
	}
	
	// Allow free play if use_credit_counting is FALSE
	//
	if (!gConfig.useCreditCounting)
		return;

	if (credits <= 0) {
		PLogmsg(LOGP_FLAW, "ERROR: SubtractCredits with credits=%d\n", credits);
		return;
	}
	Logmsg("CREDIT: Deducting %d credit%s from (%ld,%ld)\n",
		credits, (credits == 1) ? "" : "s",
		account->boxAccount.box.box, account->boxAccount.box.region);

#ifdef USE_FREE_CREDITS
	// If there are free credits, use them instead of real credits.
	//
	// If "credits" != 1, we may have to subtract a few from free and the
	// rest from real.
	//
	if (account->boxAccount.usedFreeCredits < account->boxAccount.maxFreeCredits)
	{
		// Use "free" credits.
		//
		long remaining;		// how many free credits we have left

		remaining = account->boxAccount.maxFreeCredits -
			account->boxAccount.usedFreeCredits;

		if (remaining > credits) {
			account->boxAccount.usedFreeCredits += credits;
			account->boxModified |= kBA_credits;
			Logmsg("Using %ld free credit, %ld remaining (usedFree=%ld, maxFree=%ld).\n", 
				account->boxAccount.maxFreeCredits - account->boxAccount.usedFreeCredits,
				account->boxAccount.usedFreeCredits, account->boxAccount.maxFreeCredits);
		} else {
			account->boxAccount.usedFreeCredits += remaining;
			account->boxAccount.usedCredits += credits - remaining;
			account->boxAccount.startFreeCredits += credits - remaining;	// this disgusting hack tracks how many credits used this month.  See SendAccountInfo.c
			account->boxModified |= kBA_credits;

			Logmsg("Split %ld free credit, %ld remaining (usedFree=%ld, maxFree=%ld).\n", 
				credits,
				account->boxAccount.maxFreeCredits - account->boxAccount.usedFreeCredits,
				account->boxAccount.usedFreeCredits, account->boxAccount.maxFreeCredits);
			Logmsg("Split %ld real credit\n", credits - remaining);
		}

	} else {
		// Use "real" credits.
		//
		account->boxAccount.usedCredits += credits;
		account->boxAccount.startFreeCredits += credits;	// this disgusting hack tracks how many credits used this month.  See SendAccountInfo.c
	}

#else  /* !USE_FREE_CREDITS */

	//
	// Don't mess with credits unless the config switch is on.
	//
	if (gConfig.useCreditCounting)
		//
		// Deduct the credits only if they're not in their first free month.
		//
		if (!Server_IsFreeMonth(account))
			account->boxAccount.usedCredits += credits;
		//
		// HACK ALERT * HACK ALERT * HACK ALERT * HACK ALERT
		//
		// We're stealing the usedFreeCredits field, currently unused, to
		// keep track of how many credits a customer uses during their
		// free first month period.  CS might want to know...  --davej
		//
		else
			account->boxAccount.usedFreeCredits += credits;
		//
		// END HACK * END HACK * END HACK * END HACK
		//

#endif /* USE_FREE_CREDITS */

	account->boxModified |= kBA_credits;

	Logmsg("  Remaining credits now %ld%s\n",
#ifdef USE_FREE_CREDITS
		(account->boxAccount.maxFreeCredits -
			account->boxAccount.usedFreeCredits) +
#endif
		(account->boxAccount.maxCredits -
			account->boxAccount.usedCredits),
		(account->boxAccount.maxCredits == kUnlimitedXBandCredits) ?
			" [unlimited]" : "" );
}

