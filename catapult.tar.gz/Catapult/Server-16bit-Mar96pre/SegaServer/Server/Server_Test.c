//#define DO_SLOW_TESTS
/*
 * Catapult Entertainment, Inc.
 *
 * $Id: Server_Test.c,v 1.13 1996/01/25 17:52:04 hufft Exp $
 *
 * $Log: Server_Test.c,v $
 * Revision 1.13  1996/01/25  17:52:04  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.12  1995/09/13  14:24:48  ted
 * Fixed warnings.
 *
 * Revision 1.11  1995/05/11  05:48:43  fadden
 * Moved most of the "useful" functions out, #ifdefed out the other tests
 * (the ROM is frozen now).  Still one item left to fix.
 *
 */

/*
	File:		Server_Test.c

	Contains:	Various tests of server messages

	Written by:	Josh Horwich

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <7>	10/10/94	DJ		changing some TWriteDataSyncs to Server_TWriteDataSync
		 <6>	 9/19/94	ATM		PLogmsg stuff.
		 <5>	 8/12/94	ATM		Converted to Logmsg.
		 <4>	  8/2/94	DJ		commented out rankings for now (they've changed all to hell)
		 <3>	 7/31/94	DJ		no writeable strings anymore
		 <2>	 7/21/94	JBH		Added a bunch of nasty comm test code.
		 <1>	 7/19/94	DJ		first checked in
	To Do:
*/
#include <stdio.h>

#include "Server.h"
#include "Common.h"
#include "Common_Log.h"
#include "Messages.h"
#include "Options.h"
#include "DBConstants.h"

#ifdef UNUSED
PRIVATE int Server_snes_TestWriteableString(ServerState *state, char *msg, DBID idx);
PRIVATE int Server_snes_Test4PackedStrings(ServerState *state, char *msg[4], DBID idx);
PRIVATE int Server_snes_TestLoadedGameInfo(ServerState *state);
PRIVATE int Server_snes_TestClearNetOpponent(ServerState *state);
PRIVATE int Server_snes_TestBoxMemStats(ServerState *state);
PRIVATE int Server_snes_TestReceiveRentalSN(ServerState *state);
PRIVATE int Server_snes_TestReceiveNewsIndex(ServerState *state);
PRIVATE int Server_snes_TestReceiveBoxNastyLong(ServerState *state);
PRIVATE int Server_snes_TestNewRestrictions(ServerState *state);
#endif UNUSED

//
// Test various SNES messages.
//
int
Server_snes_SendTests(ServerState *state)
{
	DBID	id;
	long	val;

	PLogmsg(LOGP_DBUG, "-----> SENDING TEST MESSAGES TO '%.4s' <-----\n",
		(char *)&state->platformID);

	//
	// Send down some writeable strings to see if it works.
	//
#ifdef DO_SLOW_TESTS
	{
		char *addrs[4] = {
		"Fallen & Can't Get Up",
		"Shannon",
		"Life is Nifty on XBAND",
		"whassup?",
		};
		Server_snes_TestWriteableString(state, "The first real-time video game network!", 192);
		Server_snes_TestWriteableString(state, "Hello, happy campers!", 193);
		Server_snes_Test4PackedStrings(state, addrs, 1);
	
		//id = 254 /*kSpecialModeFlagsConst*/;
		//val = 0x80;
		//if (Server_SendDBConstants(state, 1, &id, &val) != kServerFuncOK)
		//	return (kServerFuncAbort);
	}
#endif

	// Set kUpdateRankingsConst to 1 always.
	//
	id = kUpdateRankingsConst;
	val = 1;
	if (Server_SendDBConstants(state, 1, &id, &val) != kServerFuncOK)
		return (kServerFuncAbort);

#ifdef NOT_NOW
	{
		DBID	twoid[2];
		long	twoval[2];
		// Set the news version constants.
		//
		twoid[0] = kBANDWIDTHVersion;
		twoid[1] = kXBANDNewsVersion;
		twoval[0] = 0x12345678;
		twoval[1] = 0x99887766;
		if (Server_SendDBConstants(state, 2, twoid, twoval) != kServerFuncOK)
			return (kServerFuncAbort);
	}
#endif

#ifdef DO_SLOW_TESTS
	if (Server_snes_TestNewRestrictions(state) != kServerFuncOK)
		return (kServerFuncAbort);
#endif

#ifdef NOT_NOW
	// Try the (relatively) new messages out.
	//
	if (Server_snes_TestLoadedGameInfo(state) != kServerFuncOK)
		return (kServerFuncAbort);
	if (Server_snes_TestClearNetOpponent(state) != kServerFuncOK)
		return (kServerFuncAbort);
	if (Server_snes_TestBoxMemStats(state) != kServerFuncOK)
		return (kServerFuncAbort);
	//if (Server_snes_TestReceiveRentalSN(state) != kServerFuncOK)
	//	return (kServerFuncAbort);
	if (Server_snes_TestReceiveNewsIndex(state) != kServerFuncOK)
		return (kServerFuncAbort);
	if (Server_snes_TestReceiveBoxNastyLong(state) != kServerFuncOK)
		return (kServerFuncAbort);

	PLogmsg(LOGP_DBUG,
		"Setting kRespectFifoSemaphores | kFixFifoUnderflowInSTIdle\n");
	id = kSpecialModeFlagsConst;
	if (Server_GetDBConstant(state, id, &val) != kServerFuncOK)
		return (kServerFuncAbort);
	if (val == -1)
		val = 0;
	val |= kRespectFifoSemaphores | kFixFifoUnderflowInSTIdle;
	if (Server_SendDBConstants(state, 1, &id, &val) != kServerFuncOK)
		return (kServerFuncAbort);
#endif

	PLogmsg(LOGP_DBUG, "-----> END OF TEST MESSAGES <-----\n");
	PLogmsg(LOGP_PROGRESS, "Server_snes_SendTests done\n");

	return (kServerFuncOK);
}

#ifdef UNUSED
PRIVATE int
Server_snes_TestWriteableString(ServerState *state, char *msg, DBID idx)
{
	unsigned char 	opCode;
	long			length;

	PLogmsg(LOGP_PROGRESS, "Server_snes_TestWriteableString('%s', %d)\n",
		msg, idx);

	opCode = msReceiveWriteableString;
	if(Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode) != noErr)
		return(kServerFuncAbort);

	if(Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &idx) != noErr)
		return(kServerFuncAbort);

	length = strlen( msg ) + 1;
	if(Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length) != noErr)
		return(kServerFuncAbort);

	if(Server_TWriteDataSync(state->session, length, (Ptr) msg) != noErr)
		return(kServerFuncAbort);

	return (kServerFuncOK);
}

//
// Use id 0 to REPLACE the to-XBAND-mail-subject-line-strings, use id 1 to
// APPEND to the strings.
//
PRIVATE int
Server_snes_Test4PackedStrings(ServerState *state, char *msg[4], DBID idx)
{
	char *cp, bigbuf[1024];
	int i;
	unsigned char 	opCode;
	long			length;

	cp = bigbuf;

	for (i = 0; i < 4; i++) {
		strcpy(cp, msg[i]);
		cp += strlen(cp) +1;
	}
	*cp++ = '\0';		// two consecutive '\0's at the end
	length = cp - bigbuf;

	PLogmsg(LOGP_DBUG, "Sending 4 strings (idx=%d):\n", idx);
	Loghexdump(bigbuf, length);

	opCode = msReceiveWriteableString;
	if(Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode) != noErr)
		return(kServerFuncAbort);

	if(Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &idx) != noErr)
		return(kServerFuncAbort);

	if(Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length) != noErr)
		return(kServerFuncAbort);

	if(Server_TWriteDataSync(state->session, length, (Ptr) bigbuf) != noErr)
		return(kServerFuncAbort);

	return (kServerFuncOK);
}

// test 66
PRIVATE int
Server_snes_TestLoadedGameInfo(ServerState *state)
{
	unsigned char	opCode;
	long gameID, version;

	PLogmsg(LOGP_PROGRESS, "Server_snes_TestLoadedGameInfo\n");

	opCode = msGetLoadedGameInfo;
	if(Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode) != noErr)
		return(kServerFuncAbort);

	// receive a msGameIDAndPatchVersion, just like during login
	//
	Server_TReadDataSync( state->session, 1, (Ptr)&opCode );
	if(Server_TCheckError() != noErr)
		return(kServerFuncAbort);
	
	if(opCode != msGameIDAndPatchVersion)
	{
		PLogmsg(LOGP_FLAW, "ERROR: box responded to msGetLoadedGameInfo with %d\n",
			opCode);
		return(kServerFuncAbort);
	}
	Server_TReadDataSync( state->session, sizeof(long), (Ptr) &gameID );
	Server_TReadDataSync( state->session, sizeof(long), (Ptr) &version );
	if(Server_TCheckError() != noErr)
		return(kServerFuncAbort);

	Logmsg("TEST got game 0x%.8lx, version %d\n", gameID, version);

	return (kServerFuncOK);
}

// test 67
PRIVATE int
Server_snes_TestClearNetOpponent(ServerState *state)
{
	unsigned char	opCode;

	PLogmsg(LOGP_PROGRESS, "Server_snes_TestClearNetOpponent\n");

	opCode = msClearNetOpponent;
	if(Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode) != noErr)
		return(kServerFuncAbort);

	// No reply from box.
	//

	return (kServerFuncOK);
}

// test 68
PRIVATE int
Server_snes_TestBoxMemStats(ServerState *state)
{
	unsigned char	opCode;
	unsigned short	sizeReport[4];

	PLogmsg(LOGP_PROGRESS, "Server_snes_TestBoxMemStats\n");

	opCode = msGetBoxMemStats;
	if(Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode) != noErr)
		return(kServerFuncAbort);

	// read result
	//
	Server_TReadDataSync( state->session, 1, (Ptr)&opCode );
	if(Server_TCheckError() != noErr)
		return(kServerFuncAbort);
	
	if(opCode != msSendBoxMemStats)
	{
		PLogmsg(LOGP_FLAW, "ERROR: box responded to msGetBoxMemStats with %d\n",
			opCode);
		return(kServerFuncAbort);
	}
	Server_TReadDataSync( state->session, sizeof(sizeReport), (Ptr) &sizeReport[0] );
	if(Server_TCheckError() != noErr)
		return(kServerFuncAbort);

	Logmsg("TEST Size report: %d %d %d %d\n", sizeReport[0], sizeReport[1],
		sizeReport[2], sizeReport[3]);
	return (kServerFuncOK);
}

// test 69
PRIVATE int
Server_snes_TestReceiveRentalSN(ServerState *state)
{
	unsigned char	opCode;
	unsigned long	newsn;

	PLogmsg(LOGP_PROGRESS, "Server_snes_TestReceiveRentalSN\n");

	opCode = msReceiveRentalSerialNumber;
	if(Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode) != noErr)
		return(kServerFuncAbort);

	//newsn = 0xfeedfadd;		// this makes me a rental box
	newsn = 0;					// this de-rentalizes me
	if(Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &newsn) != noErr)
		return(kServerFuncAbort);

	return (kServerFuncOK);
}

// test 70
PRIVATE int
Server_snes_TestReceiveNewsIndex(ServerState *state)
{
#ifdef FUBAR		// tested by Chortles(tm)
	unsigned char	opCode;
	int i;

	PLogmsg(LOGP_PROGRESS, "Server_snes_TestReceiveNewsIndex\n");

	opCode = msReceiveNewsIndex;
	if(Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode) != noErr)
		return(kServerFuncAbort);

	// set the indices for each user
	//
	for (i = 0; i < 4; i++) {
		byte = 1;
	}
#endif

	return (kServerFuncOK);
}

// test 71
PRIVATE int
Server_snes_TestReceiveBoxNastyLong(ServerState *state)
{
	unsigned char	opCode;
	unsigned long	val;

	PLogmsg(LOGP_PROGRESS, "Server_snes_TestReceiveBoxNastyLong\n");

	opCode = msReceieveBoxNastyLong;
	if(Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode) != noErr)
		return(kServerFuncAbort);

	val = 0xd50000aa;
	if(Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &val) != noErr)
		return(kServerFuncAbort);

	return (kServerFuncOK);
}


//
// Send down a new REST resource, and fill in the blanks.
//
PRIVATE int
Server_snes_TestNewRestrictions(ServerState *state)
{
	unsigned char	opCode;
	snes_RestrictionsRecord resRec = {
		{ 3, 4, 30, 23 }, 0, 7
	};
	StringRecord strRecs[7] = {
		{ 100 /*156*/, 129, 0x6c, 93 },	// (obligatory crap)
		{ 0, 0, 0x2C, 80 },		// GUESS WHAT?
		{ 10, 20, 0x12, 81 },	// now
		{ 15, 40, 0x33, 82 },	// you're
		{ 20, 60, 0x44, 83 },	// playing
		{ 25, 80, 0x55, 84 },	// for
		{ 35, 105, 0x5a, 85 },	// REAL!
	};
	int structSize;
	short theSize;

	PLogmsg(LOGP_PROGRESS, "Server_snes_TestNewRestrictions\n");

	//if (state->boxOSState.boxType < 'sn06') {
	//	Logmsg("Box too young for TestNewRestrictions\n");
	//	return (kServerFuncOK);
	//}

	opCode = msReceiveRestrictions;
	if(Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode) != noErr)
		return(kServerFuncAbort);

	structSize = ((unsigned char *)&resRec.text) - ((unsigned char *)&resRec);
	theSize = structSize + sizeof(strRecs);
	Logmsg("     DBUG  --> structSize=%d, theSize=%d\n", structSize, theSize);

	// Send down a size (short), then that many bytes.
	//
	if(Server_TWriteDataSync(state->session, sizeof(short), (Ptr) &theSize) != noErr)
		return(kServerFuncAbort);

	Loghexdump((char *)&resRec, structSize);
	if(Server_TWriteDataSync(state->session, structSize, (Ptr) &resRec) != noErr)
		return(kServerFuncAbort);
	Loghexdump((char *)&strRecs, sizeof(strRecs));
	if(Server_TWriteDataSync(state->session, sizeof(strRecs), (Ptr) &strRecs) != noErr)
		return(kServerFuncAbort);


	// Now send down the writeable strings that make up the message.
	//
	Server_snes_TestWriteableString(state, "GUESS WHAT?", 80);
	Server_snes_TestWriteableString(state, "Now", 81);
	Server_snes_TestWriteableString(state, "you're", 82);
	Server_snes_TestWriteableString(state, "playing", 83);
	Server_snes_TestWriteableString(state, "for", 84);
	Server_snes_TestWriteableString(state, "REAL!", 85);

	return (kServerFuncOK);
}
#endif UNUSED


#ifdef OLD_SEGA_STUFF		// ------------------------------------------------

#include "ServerCore.h"
#include "Server.h"
#include "ServerState.h"
#include "ServerDataBase.h"
#include "DBTypes.h"
#include "Mail.h"
#include "SendQ.h"
#include "BoxSer.h"
#include "RankingMgr.h"

#include "Messages.h"
#include "PlayerDB.h"
#include "TransportLayer.h"

#include <stdio.h>
#include <string.h>


static int DoRankingTests(ServerState *state);
static int DoDBTests(ServerState *state);
static int DoDBConstTests(ServerState *state);

int Server_SendTests(ServerState *state)
{

	DBID	theID;
	long length;
	char newString[40] = "help me test this.\0";
	unsigned char 	opCode;

	PLogmsg(LOGP_PROGRESS, "Server_SendTests\n");


//
// Delete writeable strings is no more.  no need to delete them on the box, says kon.
//  7/31/94
//
#if 0
	Logmsg("Testing DeleteWriteableString\n");

	opCode = msDeleteWriteableString;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);

	theID = 3;

	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
#endif

	
	Logmsg("Testing ReceiveWriteableString\n");
	opCode = msReceiveWriteableString;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode);
	
	theID = 128;		/* override the thank-you message */
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);

	
	length = strlen( newString ) + 1;
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length);
	
	Server_TWriteDataSync(state->session, length, (Ptr) newString);

	PLogmsg(LOGP_PROGRESS, "Server_SendTests done\n");

//	if(Server_TCheckError() != noErr)
//		return(kServerFuncAbort);


	return (DoRankingTests(state));
}

static int DoRankingTests(ServerState *state)
{
	DBID theID;
	unsigned char opCode;
	short numRankings;
	RankingType	rankings;

#ifdef JOEBROKETHIS

	Logmsg("----------------------\n");
	Logmsg("DoRankingTests\n");
	Logmsg("DoDeleteRanking\n");
	
	opCode = msDeleteRanking;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode);
	
	theID = 1;			/* user 0 MK rank */
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
	
	Logmsg("DoGetNumRankings\n");
	opCode = msGetNumRankings;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode);

	if(Server_TReadDataSync(state->session, sizeof(short), (Ptr)&numRankings) != noErr)
		return(kServerFuncAbort);

	Logmsg("Num Rankings is %d\n", numRankings);
	
	// we expect 1 ranking to be in place from the server. Let's add another to make the next
	// tests interesting
	
	Logmsg("DoReceiveRankings\n");
	rankings.gameID = kMortalKombatGameID;
	rankings.userID	= 2;
	strcpy(rankings.gameName, "Mortal Kombat II");
	strcpy(rankings.curLevelString, "Black Belt");
	strcpy(rankings.curPointsString, "69");
	strcpy(rankings.nextLevelString, "No Belt");
	strcpy(rankings.nextPointsString, "200");
	theID = 1;	// BRAIN DAMAGE.  Each game should have its own DBID for rankings

	opCode = msReceiveRanking;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&theID);
	Server_TWriteDataSync(state->session, sizeof(RankingType), (Ptr)&rankings);
	
	// OK, now we expect 2 rankings
	opCode = msGetNumRankings;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode);

	if(Server_TReadDataSync(state->session, sizeof(short), (Ptr)&numRankings) != noErr)
		return(kServerFuncAbort);

	Logmsg("Num Rankings is now %d\n", numRankings);
	
	Logmsg("DoGetFirstRankingID.\n");
	
	opCode = msGetFirstRankingID;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	if(Server_TReadDataSync(state->session, sizeof(DBID), (Ptr)&theID) != noErr)
		return(kServerFuncAbort);

	numRankings = theID;
	Logmsg("First Ranking ID is %d\n", numRankings);
	
	if (theID != 1)
		Logmsg("***ERROR*** expected ID 1.\n");
	
	
	Logmsg("DoGetNextRankingID.\n");
	opCode = msGetNextRankingID;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
	
	if(Server_TReadDataSync(state->session, sizeof(DBID), (Ptr)&theID) != noErr)
		return(kServerFuncAbort);

	numRankings = theID;
	Logmsg("Next Ranking ID is %d\n", numRankings);
	
	if (theID != 0)
		Logmsg("***ERROR*** expected ID 0.\n");
		
		
	Logmsg("DoGetRankingData\n");
	opCode = msGetRankingData;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	theID = 1;
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);

	rankings.userID = 10;		/* dummy value */
	strcpy(rankings.curLevelString, "<<nothing>>");

	if(Server_TReadDataSync(state->session, sizeof(RankingType), (Ptr)&rankings) != noErr)
		return(kServerFuncAbort);

	if (rankings.userID != 2)
		Logmsg("***ERROR*** wrong userID in ranking.\n");

	Logmsg("curLevelString is %s\n", rankings.curLevelString);
	
	Logmsg("----------------------\n");
	
//	if (Server_TCheckError() != noErr)
//		return (kServerFuncAbort);
	
	return ( DoDBTests( state ) );

#else
	return(kServerFuncOK);
#endif JOEBROKETHIS

}

static int DoDBTests( ServerState *state )
{
	DBID theID;
	DBType theType;
	Ptr inDataPtr, outDataPtr;
	char inBuffer[200], outBuffer[200];
	unsigned char opCode;
	long length;
	Boolean shitHappened = false;		// not yet !!
	
	Logmsg("Beginning DB Tests.\n");
	
	Logmsg("Adding 2 DB items.\n");
	theType = 200;		/* some unused DB type, we hope! */
	inDataPtr = (Ptr ) inBuffer;	/* some space! */
	outDataPtr = (Ptr ) outBuffer;	/* some space! */
	
	*inDataPtr++ = 'H';
	*inDataPtr++ = 'e';
	*inDataPtr++ = 'l';
	*inDataPtr++ = 'l';
	*inDataPtr++ = 'o';
	*inDataPtr++ = 0;
	inDataPtr = (Ptr ) inBuffer;

	// write out a few new db items	
	opCode = msAddItemToDB;
	
	theID = 1;
	length = strlen(inBuffer) + 1;
	
	{
		short smallSize = length;
		Logmsg("SENDING SIZE is %d\n", smallSize);
	}
	
	if (length != 6)
		Logmsg("***ERROR*** 000000 I can't even call strlen right!\n");
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length);
	Server_TWriteDataSync(state->session, length, inDataPtr);
	
	theID = 2;
	*inDataPtr++ = 'B';
	*inDataPtr++ = 'y';
	*inDataPtr++ = 'e';
	*inDataPtr++ = '!';
	*inDataPtr++ = 0;
	inDataPtr = (Ptr ) inBuffer;
	
	length = strlen(inBuffer) + 1;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length);
	Server_TWriteDataSync(state->session, length, inDataPtr);

	// now let's see if we can query the id's from the db
	
	opCode = msGetTypeIDsFromDB;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
	
	{
		short count;
		short iii, temp;
		
		if(Server_TReadDataSync(state->session, sizeof(short), (Ptr)&count) != noErr)
			return(kServerFuncAbort);
			
		Logmsg("%d ID's in the database.\n", count);
		
		for (iii=0;iii<count;iii++) {
			if(Server_TReadDataSync(state->session, sizeof(DBID), (Ptr)&theID) != noErr)
				return(kServerFuncAbort);
			
			temp = theID;
			Logmsg("entry #%d is ID %d.\n", iii, temp);
		}
	}
	
	// now let's read individual item ID's from the DB
	
	Logmsg("Testing GetFirstItemIDFromDB.\n");
	opCode = msGetFirstItemIDFromDB;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
	
	if(Server_TReadDataSync(state->session, sizeof(DBID), (Ptr)&theID) != noErr)
		return(kServerFuncAbort);
		
	if (theID == 2)
		Logmsg("Received ID 2 as expected.\n");
	else {
		Logmsg("***ERROR*** 11111 received ID %d.\n", theID);
		shitHappened = true;
	}
	
	Logmsg("Testing GetNextItemIDFromDB.\n");
	opCode = msGetNextItemIDFromDB;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
	
	if(Server_TReadDataSync(state->session, sizeof(DBID), (Ptr)&theID) != noErr)
		return(kServerFuncAbort);
		
	if (theID == 1)
		Logmsg("Received ID 1 as expected.\n");
	else {
		Logmsg("***ERROR*** 22222received ID %d.\n", theID);
		shitHappened = true;
	}
	
	// now let's grab an item from the DB
	Logmsg("Testing GetItemFromDB.\n");
	opCode = msGetItemFromDB;
	theType = 200;
	theID = 1;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
	
	{
		long size;
		if(Server_TReadDataSync(state->session, sizeof(long), (Ptr)&size) != noErr)
			return(kServerFuncAbort);
			
		if (size==6) {
			Logmsg("Item length is 6, as expected.\n");
		} else {
			short smallSize = size;
			Logmsg("***ERROR*** 33333 item length is %d.\n", smallSize);
			shitHappened = true;
		}
		
		if(Server_TReadDataSync(state->session, size, outDataPtr) != noErr)
			return(kServerFuncAbort);
			
		Logmsg("Entry is %s\n", outBuffer);
	}
	
	// now let's grab an item from the DB
	Logmsg("Testing GetItemFromDB.\n");
	opCode = msGetItemFromDB;
	theType = 200;
	theID = 2;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
	
	{
		long size;
		if(Server_TReadDataSync(state->session, sizeof(long), (Ptr)&size) != noErr)
			return(kServerFuncAbort);
			
		if (size==5) {
			Logmsg("Item length is 5, as expected.\n");
		} else {
			short smallSize = size;
			Logmsg("***ERROR*** 33333 item length is %d.\n", smallSize);
			shitHappened = true;
		}
		
		if(Server_TReadDataSync(state->session, size, outDataPtr) != noErr)
			return(kServerFuncAbort);
			
		Logmsg("Entry is %s\n", outBuffer);
	}
	
	// now let's delete our crap
	Logmsg("Testing DoDeleteItemFromDB.\n");
	opCode = msDeleteItemFromDB;
	theID = 2;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);

	// there's one left. 

	opCode = msGetTypeIDsFromDB;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
	
	{
		short count;
		short iii, temp;
		
		if(Server_TReadDataSync(state->session, sizeof(short), (Ptr)&count) != noErr)
			return(kServerFuncAbort);
			
		Logmsg("%d ID's in the database.\n", count);
		
		if (count != 1) {
			Logmsg("***ERROR*** 44444should only be one left.\n");
			shitHappened = true;
		}
		
		for (iii=0;iii<count;iii++) {
			if(Server_TReadDataSync(state->session, sizeof(DBID), (Ptr)&theID) != noErr)
				return(kServerFuncAbort);
			
			temp = theID;
			Logmsg("entry #%d is ID %d.\n", iii, temp);
		}
	}
	
	opCode = msDeleteItemFromDB;
	theID = 1;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
	
	// and then there were 0. Let's count again.
	opCode = msGetTypeIDsFromDB;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
	{
		short count;
		short iii, temp;
		
		if(Server_TReadDataSync(state->session, sizeof(short), (Ptr)&count) != noErr)
			return(kServerFuncAbort);
			
		Logmsg("%d ID's in the database.\n", count);
		
		if (count != 0) {
			Logmsg("***ERROR*** 55555 should only be 0, there are %d left.\n", count);
			shitHappened = true;
		}

		for (iii=0;iii<count;iii++) {
			if(Server_TReadDataSync(state->session, sizeof(DBID), (Ptr)&theID) != noErr)
				return(kServerFuncAbort);
			
			temp = theID;
			Logmsg("entry #%d is ID %d.\n", iii, temp);
		}
	}
	
	if (shitHappened)
		Logmsg("***********ERROR*************");
	else
		Logmsg("Done testing DB stuff, all's OK.\n");
		
	return (DoDBConstTests(state));
}

static int DoDBConstTests( ServerState *state )
{
	DBID theID;
	unsigned char opCode;
	Boolean shitHappened = false;		// not yet !!
	long count = 5;
	DBID theIDs[5];
	long	theConsts[5];
	short i;
	long readConstant;

	for (i=0;i<5;i++) {
		theIDs[i] = i*20 + 100;		// 100, 120, 140, 160, 180
		theConsts[i] = i*i*i;		// 0, 1, 8, 27, 64, 125
	}
	
	Logmsg("-----------------------\nTesting DoReceiveConstants.\n");

	opCode = msSetConstants;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &count);
	Server_TWriteDataSync(state->session, sizeof(DBID) * count, (Ptr) theIDs);
	Server_TWriteDataSync(state->session, sizeof(long) * count, (Ptr) theConsts);

	Logmsg("Constants added. Checking.\n");
	
	// now let's grab an item from the DB
	Logmsg("Testing GetItemFromDB.\n");
	for (i=0;i<6;i++) {
		opCode = msGetConstant;
		theID = 100+i*20;
		Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
		Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
		
		{
			
			if(Server_TReadDataSync(state->session, sizeof(long), (Ptr) &readConstant) != noErr)
				return(kServerFuncAbort);
				
			if ((readConstant == i*i*i) || (i==5 && readConstant == -1L))
				Logmsg("Constant is correct result.\n");
			else
				Logmsg("***ERROR*** wrong constant value.\n");
		}
	}
	
	if (shitHappened)
		Logmsg("***********ERROR*************");
	else
		Logmsg("Done testing DBConstants stuff, all's OK.\n");

	return (kServerFuncOK);
}

#endif /*OLD_SEGA_STUFF*/	// ------------------------------------------------
