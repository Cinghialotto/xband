/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_SendXmailToInet.c,v 1.23 1996/02/08 21:35:30 roxon Exp $
 *
 * $Log: Server_SendXmailToInet.c,v $
 * Revision 1.23  1996/02/08  21:35:30  roxon
 * Typo fix.
 *
 * Revision 1.22  1996/02/08  21:32:27  roxon
 * onvert XBand Subject from EUC to JIS for transmission.
 *
 * Revision 1.21  1996/02/08  19:58:48  roxon
 * Ops. Errors in the previous check-in.
 *
 * Revision 1.20  1996/02/08  19:52:01  roxon
 * "xband.com" in Xmail header is configurable with gettext().
 *
 * Revision 1.19  1995/11/08  18:48:38  jhsia
 * Do something with gConfig.internetMail flag.  Added note about Kanji '.'
 * vs Roman '.'.
 *
 * Revision 1.18  1995/10/12  19:35:17  roxon
 * Eliminate warning messages in compilation.
 *
 * Revision 1.17  1995/10/07  14:44:54  roxon
 * Add euc2jis conversion for outgoing mails to internet.
 *
 * Revision 1.16  1995/09/13  14:24:43  ted
 * Fixed warnings.
 *
 * Revision 1.15  1995/05/31  19:07:08  chs
 * Be a little more careful about which messages we include
 * the boxid and phonenumber in.
 *
 * Revision 1.14  1995/05/26  23:46:58  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_SendXmailToInet.c

	Contains:	xxx put contents here xxx

	Written by:	Brian Topping


	Change History (most recent first):

		 <1>	12/15/94	BET		first checked in

	To Do:
*/


#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/time.h>
#include <time.h>
#include <ctype.h>
#include <malloc.h>

#include "ServerCore.h"
#include "Server.h"
#include "ServerState.h"
#include "Mail.h"
#include "Common.h"
#include "Common_ReadConf.h"
#include "Common_Missing.h"

void euc2jis(u_char	*, u_char *);

#define kCharBufSize 100

int Server_SendXmailToInet(Mail *mail, ServerState *state, char *recipient, Boolean inclBoxPh)
{
	char 					charBuf[kCharBufSize];
	time_t					timeNow;
	struct tm				*tm;
	FILE					*fp;
	char 					fromname[1024], *cp;

	PLogmsg(LOGP_PROGRESS, "Server_SendXmailToInet\n");

	if (!gConfig.internetMail) {
		Server_SendDialog(state,
			gettext("Sorry, mail to the Internet is not currently available."),
			true);
		return (kServerFuncOK);
	}

	// The Kanji '.' character is \241\243 (0xA1 0xA3).  We may want to
	// convert this to an ASCII period.


	// Check for catapent.com address.  The noise here is necessary to
	// avoid using "fadden%netcom.com@catapent.com" or UUCP routing tricks
	// to get the Secret Data.
	//
	for (cp = recipient;
	     isalnum(*cp) || *cp == '-' || *cp == '.' || *cp == '_';
	     cp++) ;

	if (!strcasecmp(cp, "@catapent.com")) {
	    inclBoxPh = true;
	}

	if ((fp = popen("/usr/lib/sendmail -bs > /dev/null", "w")) == NULL) {
		PLogmsg(LOGP_FLAW, "Unable to popen /usr/lib/sendmail\n");
		return -1;
	}

	sprintf(fromname, "U_%ld_%ld_%c@%s",
		DataBaseUtil_ScrambleBoxID(state->loginData.userID.box.box,
					   false),
		state->loginData.userID.box.region,
		state->loginData.userID.userID + 'A',
		gettext("xband.com"));

	// first do sendmail connect cheeze
	fprintf(fp, "HELO\n");
	fprintf(fp, "MAIL From: %s\n", fromname);
	fprintf(fp, "RCPT To: %s\n", recipient);
	fprintf(fp, "DATA\n");
				
	// now do mail header cheeze
	timeNow = time(NULL);
	tm = localtime(&timeNow);
	strftime(charBuf, kCharBufSize, "%a, %e %h %y %X %Z", tm);
	fprintf(fp, "Date: %s\n", charBuf);
	
	// 1/2/95 2:23:42 PM (BET): strip the trash from the handle
	// that will confuse the mailer.
	// this should be just the parentheses characters.
	if (strpbrk(mail->from.userName, "()")) 
		fprintf(fp, "From: %s (Unparseable User Handle)\n", fromname);
	else
		fprintf(fp, "From: %s (%s@%s)\n", fromname,
			mail->from.userName, gettext("xband.com"));

	fprintf(fp, "To: %s\n", recipient);
	fprintf(fp, "Subject: %s\n\n", mail->title);

	if (!inclBoxPh) {
		fprintf(fp, "XBAND From: '%s' (%s)\n",
			mail->from.userName, fromname);
	} else {
		fprintf(fp, "XBAND From: '%s', BoxID (%ld,%ld,%d) Ph#: %s\n",
			mail->from.userName,
			state->account->boxAccount.box.box,
			state->account->boxAccount.box.region,
			state->account->playerAccount.player,
			state->account->boxAccount.gamePhone.phoneNumber);
		fprintf(fp,
			"            Game currently installed: %s (%.4s-0x%.8lx)\n",
			Common_GameName(state->platformID,
					state->gameIDData.gameID),
			(char *)&state->platformID,
			state->gameIDData.gameID);
	}
	fprintf(fp, "XBAND To  : \"%s\"\n", recipient);
	if ( LOCALE_PHONE_JA() ) { 
		// 4 times bigger -- because each char may need an ESC seqnence
		u_char  jistitle[4096];

		euc2jis(jistitle, (u_char *)mail->title);
		fprintf(fp, "XBAND Subj: \"%s\"\n", (char *)jistitle);
	} else
		fprintf(fp, "XBAND Subj: \"%s\"\n", mail->title);

	fprintf(fp, "XBAND Date: %ld %ld %ld %2d:%.2d%s %s\n",
		(mail->date & kYearMask) >> kYearShift,
		((mail->date & kMonthMask) >> kMonthShift) +1,
		(mail->date & kDayMask) >> kDayShift,
		(tm->tm_hour > 12) ? (tm->tm_hour - 12) : tm->tm_hour,
		tm->tm_min,
		(tm->tm_hour > 12) ? "PM" : "AM",
	(tm->tm_isdst) ? "PDT" : "PST");
	fprintf(fp, "\n");

	if ( LOCALE_PHONE_JA() ) {
		// 4 times bigger -- because each char may need an ESC seqnence
		u_char  *jismsg = (u_char *)malloc(strlen(mail->message) * 4 + 1);

		euc2jis(jismsg, (u_char *)mail->message);
		fprintf(fp, "Message: %s\n", jismsg);
		free(jismsg);
	} else
		fprintf(fp, "Message: %s\n", mail->message);

	if (!inclBoxPh)		// don't put .sig on internal-only mail
		fprintf(fp, "\n-- \nSent from the XBAND Video Game Network -=*=- info@%s\n\n", gettext("xband.com"));
	fprintf(fp, ".\n");
	fprintf(fp, "QUIT\n");
	if (pclose(fp) < 0) {
		PLogmsg(LOGP_FLAW, "Failed pclose\n");
		return(-1);
	}

	return (kServerFuncOK);
}

void
euc2jis(s1, s2)
u_char	*s1, *s2;
{
	int	state = 0;
	u_char	*ss1 = s1, *ss2 = s2;

	while ( *ss2 != '\0' ) {
		if ( *ss2 > 0x80 ) {
			if ( state == 0 ) {
				/* ESC$B - into Codeset 1 */
				*ss1 = 0x1b;
				ss1++;
				*ss1 = 0x24;
				ss1++;
				*ss1 = 0x42;
				ss1++;

				state = 1;
			}

			*ss1 = *ss2 & 0x7f;
			ss1++; ss2++;
			*ss1 = *ss2 & 0x7f;
			ss1++; ss2++;
		} else if ( *ss2 < 0x80 ) {
			if ( state == 1 ) {
				/* ESC(J - into Codeset 0 */
				*ss1 = 0x1b;
				ss1++;
				*ss1 = 0x28;
				ss1++;
				*ss1 = 0x4a;
				ss1++;
				state = 0;
			}

			*ss1 = *ss2;
			ss1++; ss2++;
		}
	}

	if ( state == 1 ) {
		state = 0;
		/* ESC(J - into Codeset 0 */
		*ss1 = 0x1b;
		ss1++;
		*ss1 = 0x28;
		ss1++;
		*ss1 = 0x4a;
		ss1++;
	}

	*ss1 = '\0';

}
