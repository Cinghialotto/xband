/*
 * Copyright:	� 1995 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_MiscPrefs.c,v 1.6 1996/01/25 17:51:51 hufft Exp $
 *
 * $Log: Server_MiscPrefs.c,v $
 * Revision 1.6  1996/01/25  17:51:51  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.5  1995/11/08  18:41:10  jhsia
 * Reduced the priority on a couple of logmsgs. (fadden)
 *
 * Revision 1.4  1995/09/13  14:24:34  ted
 * Fixed warnings.
 *
 * Revision 1.3  1995/07/11  14:19:30  fadden
 * Added kMiscPrefsSNESBasicValid support.  Left in some XXX messages for now.
 *
 * Revision 1.2  1995/07/10  21:01:29  rich
 * Added Japanese SNES platform (kPlatformSJNES).
 *
 * Revision 1.1  1995/07/07  20:47:54  fadden
 * Initial revision.  Moved MiscSettings calls in here from RestoreBox.c and
 * renamed them, and added UpdateMiscPrefs.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include "Server.h"
#include "ServerDataBase.h"

#include "Common.h"
#include "Common_Log.h"
#include "Common_PlatformID.h"

#include "SegaTypes.h"
#include "DBConstants.h"

//
// Local prototypes
//
PRIVATE Err Server_sega_RestoreMiscPrefs(ServerState *state, Account *account);
PRIVATE Err Server_snes_RestoreMiscPrefs(ServerState *state, Account *account);
PRIVATE Err Server_any_RestoreMiscPrefs(ServerState *state, Account *account);


//
// Mask of "interesting" values for kXBANDOptions1Const.
//
#define kXBopt1Mask	( kXB_User0AcceptsChallenges \
					| kXB_User1AcceptsChallenges \
					| kXB_User2AcceptsChallenges \
					| kXB_User3AcceptsChallenges \
					| kXB_User0QWERTYKeyboard \
					| kXB_User1QWERTYKeyboard \
					| kXB_User2QWERTYKeyboard \
					| kXB_User3QWERTYKeyboard \
					| kXB_User0CallWaitingOn \
					| kXB_User1CallWaitingOn \
					| kXB_User2CallWaitingOn \
					| kXB_User3CallWaitingOn )



// ===========================================================================
//		Initialize/update settings
// ===========================================================================

//
// Update the MiscPreferences section of the box account on a Genesis.
//
// This is pretty simple.
//
int
Server_sega_UpdateMiscPrefs(ServerState *state)
{
	MiscPreferences *mp;
	long newopt;

	PLogmsg(LOGP_PROGRESS, "Server_sega_UpdateMiscPrefs\n");

	ASSERT(state->validFlags & kServerValidFlag_Account);
	if (state->boxRestored) {
		// The values in NiftyInfo won't reflect what we just sent back down
		// to the box.  Catch their stuff on the next connect.
		//
		return (kServerFuncOK);
	}

	mp = &state->account->boxAccount.miscPreferences;
	if (mp->valid < kMiscPrefsOptions1Valid) {
		// Initialize.
		//
		Logmsg("Initializing '%.4s' misc preferences\n",
			(char *)&state->account->boxAccount.platformID);
		mp->xbandOptions1 = (state->niftyInfo.any.xbandOptions1 & kXBopt1Mask);
		mp->valid = kMiscPrefsOptions1Valid;
		state->account->boxModified |= kBA_miscPreferences;
	} else {
		// Update.
		//
		newopt = state->niftyInfo.any.xbandOptions1 & kXBopt1Mask;
		if (newopt != mp->xbandOptions1) {
			mp->xbandOptions1 = newopt;
			state->account->boxModified |= kBA_miscPreferences;
		}
	}
	if (state->account->boxModified & kBA_miscPreferences) {
		//Logmsg("HHH xbopt1 now 0x%.8lx (src=0x%.8lx)\n", mp->xbandOptions1,
		//	state->niftyInfo.any.xbandOptions1);
	}

	return (kServerFuncOK);
}

//
// Update the MiscPreferences section of the box account on a SNES.
//
// This is somewhat complicated; there are several longwords that we
// need to update parts of.
//
int
Server_snes_UpdateMiscPrefs(ServerState *state)
{
	MiscPreferences *mp;
	unsigned char opCode;
	DBID id;
	long newopt, *lp;

	PLogmsg(LOGP_PROGRESS, "Server_snes_UpdateMiscPrefs\n");

	ASSERT(state->validFlags & kServerValidFlag_Account);
	if (state->boxRestored) {
		// The values in NiftyInfo won't reflect what we just sent back down
		// to the box.  Catch their stuff on the next connect.
		//
		return (kServerFuncOK);
	}

	mp = &state->account->boxAccount.miscPreferences;
	if (mp->valid < kMiscPrefsOptions1Valid) {
		// Initialize from NiftyInfo.
		//
		Logmsg("Initializing '%.4s' misc preferences (xbandOptions1)\n",
			(char *)&state->account->boxAccount.platformID);
		mp->xbandOptions1 = (state->niftyInfo.any.xbandOptions1 & kXBopt1Mask);
		mp->valid = kMiscPrefsOptions1Valid;
		state->account->boxModified |= kBA_miscPreferences;
	} else {
		// Update.
		//
		newopt = state->niftyInfo.any.xbandOptions1 & kXBopt1Mask;
		if (newopt != mp->xbandOptions1) {
			mp->xbandOptions1 = newopt;
			state->account->boxModified |= kBA_miscPreferences;
		}
	}

	if (mp->valid < kMiscPrefsSNESBasicValid) {
		// Initialize by requesting the constants from the box.  We've got
		// the phoneOptions in the IDBC, but the rest have to be requested
		// directly.
		//
		// This is slow, but only has to be done once.
		//
		Logmsg("Initializing '%.4s' misc preferences (SNESBasic)\n",
			(char *)&state->account->boxAccount.platformID);

		// Send requests.
		//
		opCode = msGetConstant;
		Server_SetTransportHold(state->session, true);
		id = kPhoneOptionsConst;
		Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr)&opCode);
		Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&id);
		id = kUser0WaitTimeConst;
		Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr)&opCode);
		Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&id);
		id = kUser1WaitTimeConst;
		Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr)&opCode);
		Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&id);
		id = kUser2WaitTimeConst;
		Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr)&opCode);
		Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&id);
		id = kUser3WaitTimeConst;
		Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr)&opCode);
		Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&id);
		id = kSoundOptionsConst;
		Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr)&opCode);
		Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr)&id);
		Server_SetTransportHold(state->session, false);

		// Receive replies.
		//
		Server_TReadDataSync(state->session, sizeof(long),
			(Ptr)&mp->phoneOptions);
		Server_TReadDataSync(state->session, sizeof(long),
			(Ptr)&mp->user0WaitTime);
		Server_TReadDataSync(state->session, sizeof(long),
			(Ptr)&mp->user1WaitTime);
		Server_TReadDataSync(state->session, sizeof(long),
			(Ptr)&mp->user2WaitTime);
		Server_TReadDataSync(state->session, sizeof(long),
			(Ptr)&mp->user3WaitTime);
		Server_TReadDataSync(state->session, sizeof(long),
			(Ptr)&mp->soundOptions);
		mp->valid = kMiscPrefsSNESBasicValid;
		state->account->boxModified |= kBA_miscPreferences;
		PLogmsg(LOGP_PROGRESS, "SNESBasic miscPrefs done\n");
	} else {
		// Update.
		//
		// phoneOptions
		//
		if (mp->phoneOptions != state->niftyInfo.snes.phoneOptions) {
			mp->phoneOptions = state->niftyInfo.snes.phoneOptions;
			state->account->boxModified |= kBA_miscPreferences;
		}

		// waitTime
		//
		// Could use pointer arith, but somebody's gonna hose it someday.
		//
		switch (state->loginData.userID.userID) {
		case 0: lp = &mp->user0WaitTime; break;
		case 1: lp = &mp->user1WaitTime; break;
		case 2: lp = &mp->user2WaitTime; break;
		case 3: lp = &mp->user3WaitTime; break;
		default:
			PLogmsg(LOGP_FLAW, "ERROR: bogus playerNum (%d) in MiscPrefs\n",
				state->loginData.userID.userID);
			return (kServerFuncAbort);
		}
		if (*lp != (long)state->niftyInfo.snes.waitTime) {
			*lp = (long)state->niftyInfo.snes.waitTime;
			state->account->boxModified |= kBA_miscPreferences;
		}

		// soundOptions (part of RRD, not IDBC)
		//
		if (mp->soundOptions != state->niftyInfo.snes.soundOptions) {
			mp->soundOptions = state->niftyInfo.snes.soundOptions;
			state->account->boxModified |= kBA_miscPreferences;
		}
	}

/* ***
	if (state->account->boxModified & kBA_miscPreferences) {
		Logmsg("HHH xbopt1        : 0x%.8lx (src=0x%.8lx)\n",
			mp->xbandOptions1, state->niftyInfo.any.xbandOptions1);
		Logmsg("HHH phoneOptions  : 0x%.8lx (src=0x%.8lx)\n",
			mp->phoneOptions, state->niftyInfo.snes.phoneOptions);
		Logmsg("HHH soundOptions  : 0x%.8lx (src=0x%.8lx)\n",
			mp->soundOptions, state->niftyInfo.snes.soundOptions);
		Logmsg("HHH user0WaitTime : 0x%.8lx\n",
			mp->user0WaitTime);
		Logmsg("HHH user1WaitTime : 0x%.8lx\n",
			mp->user1WaitTime);
		Logmsg("HHH user2WaitTime : 0x%.8lx\n",
			mp->user2WaitTime);
		Logmsg("HHH user3WaitTime : 0x%.8lx\n",
			mp->user3WaitTime);
	}
*** */

	return (kServerFuncOK);
}



// ===========================================================================
//		Restore settings
// ===========================================================================

//
// Restore miscellaneous box settings, like call waiting and keyboard type.
// The SNES has many more options than Genesis.
//
Err
Server_RestoreMiscPrefs(ServerState *state, Account *account)
{
	SubDispatcher subDisp[] = {
		{ kPlatformGenesis,	kPlatformGenesisMask,	(INT_FUNC_PTR) Server_sega_RestoreMiscPrefs },
		{ kPlatformSNES,	kPlatformSNESMask,		(INT_FUNC_PTR) Server_snes_RestoreMiscPrefs },
		{ kPlatformSJNES,	kPlatformSJNESMask,		(INT_FUNC_PTR) Server_snes_RestoreMiscPrefs },
		{ kPlatformAny,		0,						(INT_FUNC_PTR) Server_any_RestoreMiscPrefs },
		{ 0,				0,						NULL },		// foosh!
	};

	return ( (Err)(Common_SubDispatch(state->boxOSState.boxType, subDisp))(
		state, account) );

	return (kNoError);
}

PRIVATE Err
Server_common_RestoreMiscPrefs(ServerState *state, Account *account)
{
	DBID id;
	long data;

	// Restore the following:
	//
	//	kXBANDOptions1Const
	//	  kXB_User0AcceptsChallenges      0x10
	//	  kXB_User1AcceptsChallenges      0x20
	//	  kXB_User2AcceptsChallenges      0x40
	//	  kXB_User3AcceptsChallenges      0x80
	//	  kXB_User0QWERTYKeyboard         0x100
	//	  kXB_User1QWERTYKeyboard         0x200
	//	  kXB_User2QWERTYKeyboard         0x400
	//	  kXB_User3QWERTYKeyboard         0x800
	//	  kXB_User0CallWaitingOn          0x1000
	//	  kXB_User1CallWaitingOn          0x2000
	//	  kXB_User2CallWaitingOn          0x4000
	//	  kXB_User3CallWaitingOn          0x8000
	//	  (there are other bits here which MUST NOT be altered)
	//
	if (account->boxAccount.miscPreferences.valid == kMiscPrefsInvalid) {
		Logmsg("BR: miscPreferences not valid, not restoring them (common)\n");
		return (kNoError);
	}

	// Restore to previous values.
	//
	id = kXBANDOptions1Const;
	data = state->niftyInfo.any.xbandOptions1 & ~kXBopt1Mask;
	data |= account->boxAccount.miscPreferences.xbandOptions1;
	PLogmsg(LOGP_DETAIL, "Restoring const=%d, val=0x%.8lx\n", id, data);

	if (Server_SendDBConstants(state, 1, &id, &data) != kServerFuncOK)
		return (kServerFuncAbort);

	return (kNoError);
}

PRIVATE Err
Server_sega_RestoreMiscPrefs(ServerState *state, Account *account)
{
	Err err;

	PLogmsg(LOGP_PROGRESS, "Server_sega_RestoreMiscPrefs\n");

	if ((err = Server_common_RestoreMiscPrefs(state, account)) != kNoError)
		return (err);

	// (nothing further to do)
	//

	return (kNoError);
}

PRIVATE Err
Server_snes_RestoreMiscPrefs(ServerState *state, Account *account)
{
	Err err;
	DBID idArray[6];
	long dataArray[6];

	PLogmsg(LOGP_PROGRESS, "Server_snes_RestoreMiscPrefs\n");

	if ((err = Server_common_RestoreMiscPrefs(state, account)) != kNoError)
		return (err);

	// Restore the following:
	//
	//	kPhoneOptionsConst
	//	  (all)
	//
	//	kUser0WaitTimeConst
	//	kUser1WaitTimeConst
	//	kUser2WaitTimeConst
	//	kUser3WaitTimeConst
	//	  (all)
	//
	//	kSoundOptionsConst
	//	  (all)
	//
	// To be fancy we could also restore:
	//	kUser0ButtonOptionsConst
	//	kUser0ButtonOptionsConst
	//	kUser0ButtonOptionsConst
	//	kUser0ButtonOptionsConst
	//	  (all)
	//
	if (account->boxAccount.miscPreferences.valid < kMiscPrefsSNESBasicValid) {
		Logmsg("BR: SNESBasic miscPreferences not valid, not restoring them\n");
		return (kNoError);
	}

	idArray[0] = kPhoneOptionsConst;
	dataArray[0] = account->boxAccount.miscPreferences.phoneOptions;
	idArray[1] = kUser0WaitTimeConst;
	dataArray[1] = account->boxAccount.miscPreferences.user0WaitTime;
	idArray[2] = kUser1WaitTimeConst;
	dataArray[2] = account->boxAccount.miscPreferences.user1WaitTime;
	idArray[3] = kUser2WaitTimeConst;
	dataArray[3] = account->boxAccount.miscPreferences.user2WaitTime;
	idArray[4] = kUser3WaitTimeConst;
	dataArray[4] = account->boxAccount.miscPreferences.user3WaitTime;
	idArray[5] = kSoundOptionsConst;
	dataArray[5] = account->boxAccount.miscPreferences.soundOptions;

	{
		int i;

		for (i = 0; i < 6; i++) {
			PLogmsg(LOGP_DETAIL,
				"Restoring const=%d, val=0x%.8lx\n", idArray[i], dataArray[i]);
		}
	}
	if (Server_SendDBConstants(state, 6, idArray, dataArray) != kServerFuncOK)
		return (kServerFuncAbort);

	return (kNoError);
}

PRIVATE Err
Server_any_RestoreMiscPrefs(ServerState *state, Account *account)
{
	PLogmsg(LOGP_PROGRESS, "Server_any_RestoreMiscPrefs\n");

	// Dunno what to restore, just quietly exit.
	//
	return (kNoError);
}

