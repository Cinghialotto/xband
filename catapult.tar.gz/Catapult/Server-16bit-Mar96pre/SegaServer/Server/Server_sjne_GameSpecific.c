/*
 * Copyright:   � 1995 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_sjne_GameSpecific.c,v 1.5 1996/01/09 20:02:03 ansell Exp $
 *
 * $Log: Server_sjne_GameSpecific.c,v $
 * Revision 1.5  1996/01/09  20:02:03  ansell
 * Added jump table entry for SJNE game Super Fire ProWrestling X.
 *
 * Revision 1.4  1996/01/05  18:17:27  ansell
 * Changed Super Mario Kart gameID to the real one.
 *
 * Revision 1.3  1995/12/06  23:01:18  ansell
 * Added jumptable entry for Puyopuyo and removed stuff for games not supported
 * by Japanese server.
 *
 * Revision 1.2  1995/10/09  18:28:45  ansell
 * Added jump table entry for SJNE Super Street Fighter II.
 *
 * Revision 1.1  1995/10/02  17:35:41  ansell
 * Clone of Server_snes_GameSpecific.c for now.  Will revamp when we have the
 * "real" games for SJNES.
 *
 */

/*
	File:		Server_sjne_GameSpecific.c

	Contains:	Game-specific code for SJNES ('sjne').

	Written by:	Steve Ansell

*/


#include <sys/types.h>
#include <time.h>

#include "Server.h"
#include "Server_GameSpecific.h"
#include "Common.h"

#include "Errors.h"

// This entire file is just a complete clone of the SNES stuff.  It will
// be completely replaced once we have the "real" games for SJNES.  It is
// here mainly to show the structure to use and for testing purposes.
//

//
// Local function.
//
PRIVATE Err SJNES_MK2_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SJNES_NBAJamTE_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SJNES_SSF2_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SJNES_NHL95_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SJNES_Madden95_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SJNES_Zelda_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SJNES_KillerInstinct_Resolver( NewGameResult *gameErrorResult );
PRIVATE Err SJNES_KGBaseball_Resolver( NewGameResult *gameErrorResult );


//
// Known SJNES games (see Common_GameInfo.c for definitive list):
//
//	0x00000000	(game patch not entered)
//	0x0000000?	(test patch, could be anything)
//	0x0000029a	Simulator
//	0x0a2c238a	Super Mario Kart
//	0x55ce0daf	Zelda (maze game)
//	0xd8222103	SSF2 
//	0x8442c640	Puyopuyo
//	0x925b41fc	Super Fire ProWrestling X
//
static GameSpecificJumpTable gameSpecific[] = {
	{ 0x0000029a, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL },
	{ 0x0a2c238a, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL },
	{ 0x55ce0daf, NULL, NULL, NULL,
		NULL, NULL, NULL, SJNES_Zelda_Resolver },
	{ 0xd8222103, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL },
	{ 0x8442c640, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL },
	{ 0x925b41fc, NULL, NULL, NULL,
		NULL, NULL, NULL, NULL },
};


//
// Look up a game.
//
// Returns a pointer to the appropriate gameSpecific entry via gsjtpp.
//
SEMI_PRIVATE int
Server_sjne_LookupGameSpecific(const long gameID, GameSpecificJumpTable **gsjtpp)
{
	int i;

	*gsjtpp = NULL;
	for (i = 0; i < NELEM(gameSpecific); i++) {
		if (gameSpecific[i].gameID == gameID) {
			*gsjtpp = &gameSpecific[i];
			return (0);
		}
	}
	return (0);
}



// ===========================================================================
//		CompleteEnough stuff (from Josh)
// ===========================================================================

typedef struct SJNES_Zelda_GameData {
	// is there really anything here?
	unsigned short dummy;
} SJNES_Zelda_GameData;

PRIVATE Err
SJNES_Zelda_Resolver( NewGameResult *gameErrorResult )
{
#ifdef UNUSED
SJNES_Zelda_GameData *zeldaData = (SJNES_Zelda_GameData *) gameErrorResult->gameReserved;
#endif
WinAnalysis winAnal;
unsigned long player1Points;
unsigned long player2Points;

#ifdef UNUSED		// right now, we don't look at any game-specific data
	if ( zeldaData->dataVersion != kSJNES_Zelda_VersionIExpect )
	{
		// I haven't a clue what I'm looking at, so do nothing!
		return (kNotEnoughCompletedTie);
	}
#endif

	Server_AnalyzeWin(gameErrorResult, &winAnal);
	player1Points = winAnal.pointsFor;
	player2Points = winAnal.pointsAgainst;

	// Oh, just assume there isn't enough.  This is here for testing, really.
	return (kNotEnoughCompletedTie);

	//return (kEnoughCompletedLocalWinner);
	//return (kEnoughCompletedRemoteWinner);
	//return (kEnoughCompletedTie);
}

