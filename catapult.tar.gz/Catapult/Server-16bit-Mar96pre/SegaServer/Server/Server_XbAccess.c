/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_XbAccess.c,v 1.14 1996/03/01 19:21:04 roxon Exp $
 *
 * $Log: Server_XbAccess.c,v $
 * Revision 1.14  1996/03/01  19:21:04  roxon
 * Change smart quotes to normal quotes 39 (').
 *
 * Revision 1.13  1996/01/29  21:59:07  hufft
 * correct dialog errors
 *
 * Revision 1.12  1996/01/25  17:52:11  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.11  1996/01/15  19:49:22  hufft
 * japan GamePhone update
 *
 * Revision 1.10  1996/01/12  16:13:47  hufft
 * don't lookup account for 800 connect
 *
 * Revision 1.9  1996/01/12  13:40:22  hufft
 * don't restore 800 accounts. In Server_popUpdate()
 *
 * Revision 1.8  1996/01/10  18:22:19  hufft
 * changed suspended message
 *
 * Revision 1.7  1996/01/10  18:13:54  hufft
 * set dateLastChanged to 0 for 800 connects
 *
 * Revision 1.6  1996/01/10  14:49:27  hufft
 * changed to use libphonedb
 *
 * Revision 1.5  1996/01/09  18:57:38  hufft
 * check for pop_override flag, without data
 *
 * Revision 1.4  1996/01/09  16:26:21  hufft
 * added Joey's wording changes for pop mail
 *
 * Revision 1.3  1996/01/08  18:31:17  hufft
 * dialog wording
 *
 * Revision 1.2  1996/01/08  18:17:48  hufft
 * corected mail messages
 *
 * Revision 1.1  1996/01/04  22:54:23  hufft
 * added pop mail
 *
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <memory.h>
#include <sys/types.h>
#include <sys/time.h>
#include <strings.h>

#include "Server.h"
#include "ServerCore.h"
#include "ServerState.h"
#include "ServerDataBase.h"
#include "Server_Pop.h"
#include "PhoneDB.h"

#include "Common.h"
#include "Common_Missing.h"
#include "Common_Log.h"
#include "Common_ReadConf.h"

static	void Server_XbSendPopMail(ServerState *state, phoneNumber* boxPhone_p, LOOKUP_POP_P pop_choices_p, char **argv, int argc, int x25);
#if	0
static	void	Server_NukeOutGoingMail(ServerState *state);
#endif
static	void Server_PatchPopDial(ServerState * state, phoneNumber *popPhone, phoneNumber *altPhone);
static Err	Server_XbAccessParse(ServerState *state, phoneNumber *boxPhone_p, int x25, short max_pops, LOOKUP_POP_P lookup_p, LOOKUP_POP_P pop_choices_p, char **argv, int *argc_p, int *pop_test);
static	Err	Server_XbAccessMail(ServerState *state, phoneNumber *boxPhone_p, int x25, LOOKUP_POP_P lookup_p, LOOKUP_POP_P pop_choices_p, long *override, int *redial, int *pop_test);
static	Err Server_PopList(phoneNumber *boxPhone_p, LOOKUP_POP_P lookup_p);
static	int Server_ApplyOverride(Account*account, BoxAccount*box_ac_p, int new_override, LOOKUP_POP_P pop_choices_p, phoneNumber*boxPhone_p, phoneNumber*popPhone_p, phoneNumber*altPopPhone_p, phoneNumber*overridePOP1_p, phoneNumber*overridePOP2_p);

//
// Process any XBAND-ACCESS mail messages
//
#define	kXBAND_ACCESS			"XBAND-ACCESS"
#define	kXBAND_ACCESS_INSTRUCT	"XBAND-ACCESS INSTRUCTIONS"
#define	kXBAND_ACCESS_ERROR		"XBAND-ACCESS ERROR"
#define	kXBAND_NUMBER_LIST		"XBAND-NUMBER-LIST"
#define	kMaxMailPopNum			100
#define kXbAccessMailErr		667
#define kXbAccessMailSN			668
#define kXbAccessPopListSN		669
#define	kXbAccessMaxTries		20
#define	kMaxPops				2
#define	kQuoteL					39
#define	kQuoteR					39

//
// Check to see if we need a new POP for this account. We pass in the current POPs
// so rpc.segad can compare to the new pops.
//
Err Server_PopUpdate(ServerState *state, Account *account, userIdentification *userID, phoneNumber *boxPhone_p, phoneNumber *popPhone_p, int x25, int redial)
{
Err					err;
LOOKUP_POP			lookup;
LOOKUP_POP			pop_choices;
phoneNumber 		popPhone;
phoneNumber			altPopPhone;
phoneNumber			overridePOP1;
phoneNumber			overridePOP2;
Hometown			town;
Account				*account_sav = 0;
BoxAccount			*box_ac_p = 0;
BoxSerialNumber		*boxp = &state->loginData.userID.box;
ulong				dateLastConnect;
long				override;
long				new_override;
int					pop_test = 0;			// for special test pops out of pop list

	//
	// initialization
	//
	if (!popPhone_p)
	{
		popPhone_p = &popPhone;
		memset(popPhone_p, 0, sizeof(popPhone));
	}
	if (!account)
	{
		account = state->account;
		if (!account)
		{
			if (gConfig.xbAccessMode)
			{
				//
				// Okay, we are doing the undesireable here, that is getting
				// the account on an 800 number connect. UGLY UGLY, but
				// Okay according to DJ. This is done because we want CS to be
				// able to set an Override via catadmin. And have it processed
				// on an 800 connect. This is for our customers that just
				// can't enter two phone numbers correctly, no matter what!!!!!!!
				//
				if (x25)
				{
					if ((err = Server_ValidateAccount(state)) != kNoError)
					{
						return(err);
					}
				}
				account = state->account;
			}
		}
	}
	else
	{
		account_sav = state->account;
		state->account = account;
	}
	if (x25)
	{
	    if (!account)
		{
			if (boxPhone_p)
			{
				PLogmsg(LOGP_NOTICE, "Server_PopUpdate:no account:%s (%d,%d)\n",
					boxPhone_p->phoneNumber, boxp->box, boxp->region);
			}
			else
			{
				PLogmsg(LOGP_NOTICE, "Server_PopUpdate:no account (%d,%d)\n",
					boxp->box, boxp->region);
			}
			return(kServerFuncAbort);
		}
	}
	if (account)
	{
		box_ac_p = &account->boxAccount;
		//
		// there should be a boxPhone_p only when called from Server_MakeNewPhoneNumber
		//
		if (boxPhone_p)
		{
			Server_GamePhoneUpdate(state, account, boxPhone_p);
		}
		else
		{
			//
			// if no boxPhone, use current gamePhone
			//
			boxPhone_p = &box_ac_p->gamePhone;
		}
		//
		// If originalGamePhone not set by UCA, then set it.
		//
		if (state->accountCreated)
		{
			//
			// if currently empty
			//
			if(box_ac_p->originalGamePhone.phoneNumber[0] == '\0')
			{
				PLogmsg(LOGP_DBUG, "Server_PopUpdate:originalGamePhone changed:%s (%d,%d)\n",
					boxPhone_p->phoneNumber, boxp->box, boxp->region);
				box_ac_p->originalGamePhone = *boxPhone_p;
				account->boxModified |= kBA_gamePhone;
			}
		}
		*popPhone_p = box_ac_p->popPhone;
		altPopPhone = box_ac_p->altPopPhone;
		if (x25)
		{
	    	dateLastConnect = account->userAccount.dateLastConnect;
		}
		else
		{
			dateLastConnect = 0;
		}

		if (!userID)
		{
			userID = &state->loginData.userID;
		}
	    /*
	     * if the account is suspended,
	     * keep them suspended without letting the playeraccount be created.
	     */
	    if (account->userAccount.accountStatus == CAT_ACCT_STATUS_SUSPENDED)
		{
			Server_SendDialog(state, gettext("Your account is suspended . Please call XBAND Customer Support at 408-777-1500."), true);	/* DIALOG */
#if	0
			PLogmsg(LOGP_DBUG, "XXX:%s", 
				gettext("You have NOT correctly completed XBAND-ACCESS mail. Please call XBAND Customer Support at 408-777-1500."));
#endif
			PLogmsg(LOGP_NOTICE, "Server_PopUpdate:CAT_ACCT_STATUS_SUSPENDED:%s (%d,%d)\n",
				boxPhone_p->phoneNumber, boxp->box, boxp->region);
			return(kServerFuncAbort);
	    }    
	
	    /* if the account isn't open, fall thru to whatever the normal result is */
	    if (account->userAccount.accountStatus != CAT_ACCT_STATUS_ACTIVE)
		{
			PLogmsg(LOGP_DBUG, "Server_PopUpdate:!CAT_ACCT_STATUS_ACTIVE:%s (%d,%d)\n",
				boxPhone_p->phoneNumber, boxp->box, boxp->region);
			return(kServerFuncAbort);
	    }
		if (x25)
		{
			//
			// clear any failed800PopConnects
			//
			if (box_ac_p->failed800PopConnects)
			{
				box_ac_p->failed800PopConnects = 0;
	    		account->boxModified |= (kBA_failed800PopConnects | kBA_boxFlags);
			}
		}
	}
	else
	//
	// 800 connect, no account, grab new pops
	//
	{
		memset(popPhone_p, 0, sizeof(popPhone));
		memset(&altPopPhone, 0, sizeof(altPopPhone));
		dateLastConnect = 0;
	}
    PLogmsg(LOGP_PROGRESS, "Server_PopUpdate:%s (%d,%d)\n",
		boxPhone_p->phoneNumber, boxp->box, boxp->region);
	if (account)
	{
		//
		// if the kCSUpdatedFlag_PopOverRide flag is set, we clear it and
		// set kBA_overridePhone. This lets CS know that the override
		// has been applied
		//
		if (box_ac_p->csUpdatedFlags & kCSUpdatedFlag_PopOverRide)
		{
			PLogmsg(LOGP_DBUG, "Server_PopUpdate:kCSUpdatedFlag_PopOverRide %s (%d,%d)\n",
				boxPhone_p->phoneNumber, boxp->box, boxp->region);
			box_ac_p->csUpdatedFlags &= ~kCSUpdatedFlag_PopOverRide;
			box_ac_p->boxFlags |= kBoxFlag_PopOverRide;
			account->boxModified |= (kBA_overridePhone | kBA_csUpdatedFlags | kBA_boxFlags);
		}
	}
	//
	// See if we have any pop override mail
	//
	memset(&lookup, 0, sizeof(lookup));
	memset(&pop_choices, 0, sizeof(pop_choices));
	err = Server_XbAccessMail(state, boxPhone_p, x25, &lookup, &pop_choices, &override, &redial, &pop_test);
	if (override)
	{
		overridePOP1 = lookup.pop[0].phone;
		switch (lookup.num_pops)
		{
		case	1:
			overridePOP2 = overridePOP1;
			break;
		default:
			overridePOP2 = lookup.pop[1].phone;
			break;
		}
		overridePOP1.length = 0;
		overridePOP2.length = 0;
		PLogmsg(LOGP_DBUG, "Server_PopUpdate:popOverride from Mail:%s (%d,%d) %s [%d] %s [%d]\n",
			boxPhone_p->phoneNumber, boxp->box, boxp->region,
				overridePOP1.phoneNumber,
				overridePOP1.scriptID,
				overridePOP2.phoneNumber,
				overridePOP2.scriptID);
		//
		// assign
		//
		memcpy(town, lookup.homeTown, sizeof(lookup.homeTown));
		//
		// update the account stuff
		//
		if (account)
		{
			box_ac_p->boxFlags |= kBoxFlag_PopOverRide;
			//
			// we have a special test pop
			//
			if (pop_test)
			{
				box_ac_p->boxFlags |= kBoxFlag_PopOverRideTest;
			}
			account->boxModified |= (kBA_overridePhone | kBA_boxFlags);
			/*
			 * Bump the counter of how many times this guy has tried
			 * to set pops by mail, and suspend his account if he 
			 * goes over the limit.
			 */
			if (++box_ac_p->failed800PopConnects > kXbAccessMaxTries)
			{
				account->userAccount.accountStatus = CAT_ACCT_STATUS_SUSPENDED;
				account->userModified |= kUA_accountStatus;
			   	account->boxModified |= (kBA_failed800PopConnects | kBA_boxFlags);
			
				Logmsg("XBAND-ACCESS: box %d suspended for too many attempts\n", boxp->box);
				Server_SendDialog(state, gettext("You have NOT correctly completed XBAND-ACCESS mail. Please call XBAND Customer Support at 408-777-1500."), true);	/* DIALOG */
	#if	0
				PLogmsg(LOGP_DBUG, "XXX:%s",
					gettext("You have NOT correctly completed XBAND-ACCESS mail. Please call XBAND Customer Support at 408-777-1500."));	/* DIALOG */
	#endif
				return(kServerFuncAbort);
			}
		}
#if	0
		else
		{
			//
			// 800 connect, update the account
			//
			PLogmsg(LOGP_NOTICE, "Server_PopUpdate:unable to get account:%s (%d, %d)\n",
				boxPhone_p->phoneNumber, boxp->box, boxp->region);
		}
#endif
		err = kNoError;
		//
		// This is a new override, sent by mail
		//
		new_override = true;
	}
	else if (account)
	{
		new_override = false;
		//
		// if our override flag is set by other means
		//
		if (box_ac_p->boxFlags & kBoxFlag_PopOverRide)
		{
			memcpy(&overridePOP1, &box_ac_p->overridePOP1, sizeof(overridePOP1));
			memcpy(&overridePOP2, &box_ac_p->overridePOP2, sizeof(overridePOP2));
			override = true;
		}
		else
		{
			memset(&overridePOP1, 0, sizeof(overridePOP1));
			memset(&overridePOP2, 0, sizeof(overridePOP2));
		}
	}
	else
	{
		new_override = false;
		memset(&overridePOP1, 0, sizeof(overridePOP1));
		memset(&overridePOP2, 0, sizeof(overridePOP2));
	}
	//
	// see if we force a mail to user
	//
	if (account)
	{
		//
		// kCSUpdatedFlag_SendXBAccessMail, force a send pop xmail choices, then clear it
		//
		if (box_ac_p->csUpdatedFlags & kCSUpdatedFlag_SendXBAccessMail)
		{
			Server_XbSendPopMail(state, boxPhone_p, &pop_choices, 0, 0, x25);
			box_ac_p->csUpdatedFlags &= ~kCSUpdatedFlag_SendXBAccessMail;
			account->boxModified |= kBA_csUpdatedFlags;
		}
	}
	//
	// if we have an override, then don't do quick lookup
	//
	if (override)
	{
		dateLastConnect = 0;
	}
	//
	// Do a POP lookup to get the access phone numbers and city/state.
	//
	PLogmsg(LOGP_PROGRESS, "Server_PopUpdate:%s (%d,%d) get pops from rpc.segad\n",
			boxPhone_p->phoneNumber, boxp->box, boxp->region);
	err = Server_LookupPops(kLookupPop, boxPhone_p, popPhone_p, &altPopPhone, town,
		kPopSelect16, dateLastConnect);
	//
	// process the results
	//
	//
	// if an override is in effect
	//
	if (override)
	{
		PLogmsg(LOGP_PROGRESS, "Server_PopUpdate:using overrides\n");
		override = Server_ApplyOverride(account, box_ac_p, new_override,
			&pop_choices, boxPhone_p, popPhone_p, &altPopPhone, &overridePOP1, &overridePOP2);
	}
	switch (err)
	{
	case	kPOPFileIsUpToDate:
		if (!override)
		{
			PLogmsg(LOGP_DBUG, "Server_PopUpdate:kPOPFileIsUpToDate:no overrides\n");
			break;
		}
		//
		// Fall through to handle the override part
		//
	case	kNoError:
		PLogmsg(LOGP_NOTICE,
			"New phone info: box='%s', pop='%s'[%d], altPop='%s'[%d], town='%s'\n",
			boxPhone_p->phoneNumber,
			popPhone_p->phoneNumber, popPhone_p->scriptID,
			altPopPhone.phoneNumber, altPopPhone.scriptID,
			town);

		if (account)
		{
			if (x25)
			{
				PLogmsg(LOGP_PROGRESS, "Server_PopUpdate:X25:it's update time\n");
			}
			else
			{
				PLogmsg(LOGP_PROGRESS, "Server_PopUpdate:800:it's update time\n");
			}
			Server_SetBoxAccountPops(state, popPhone_p, &altPopPhone);
		
			//
			// The POP file changed since the last login by this box.
			//
			Server_AddPBX_Dial9(state, popPhone_p, &altPopPhone);
	
			/* false == don't force a redial */
			Server_SendSetLocalAccessPhoneNumber(state, popPhone_p, &altPopPhone, redial);

			Server_WhichTown(state, town);
	
			strncpy(userID->userTown, town, kUserTownSize);		// not necessary

			Server_SendNewBoxHometown(state, town);
		}
		else
		//
		// 800 connect mode
		//
		{
			PLogmsg(LOGP_PROGRESS, "Server_PopUpdate:800:it's update time\n");

			Server_PatchPopDial(state, popPhone_p, &altPopPhone);
			//
			// Set the POP newBoxPhone numbers, force a redial.
			//
			Server_SendSetLocalAccessPhoneNumber(state, popPhone_p, &altPopPhone, redial);

			Server_SendNewBoxHometown(state, town);
		}
		err = kNoError;
		break;
	default:
		//
		// This shouldn't happen.
		//	
		PLogmsg(LOGP_FLAW, "WARNING: POP lookup failed for '%s' (%d)\n",
			boxPhone_p->phoneNumber, err);
		err = kServerFuncAbort;
	}
	//
	// restore any saved account
	//
	if (account_sav)
	{
		state->account = account_sav;
	}
	return(err);
}
//
// test for legal local access in pop list
//
Err	Server_ValidatePop(char *raw, LOOKUP_POP_P lookup_p, DBID *scriptID_p)
{
	long	i;
	char	buf[256];
	int		pattern;

	if ((pattern = Common_PhonePattern(raw)) < 0)
	{
		return(0);
	}
	for (i = 0; i < lookup_p->num_pops; i++)
	{
		Common_PhoneFormatDialString(lookup_p->pop[i].phone.phoneNumber, buf, pattern);
		if (!Common_PhoneCompareNumbers(raw, buf))
		{
			*scriptID_p = lookup_p->pop[i].phone.scriptID;
			return(1);
		}
		PLogmsg(LOGP_DBUG, "Server_ValidatePop:'%s' != '%s'\n", raw, buf);
	}
	return(0);
}
/*
 * Check for the access mail
 */
static	Err	Server_XbAccessMail(ServerState *state, phoneNumber *boxPhone_p, int x25, LOOKUP_POP_P lookup_p, LOOKUP_POP_P pop_choices_p, long *override, int *redial, int *pop_test)
{
	Err				err;
	char			buf[1024];
	char			phone1[20];
	char			phone2[20];
    long			statusFlags;
	char			*argv[kMaxMailPopNum];
	int				argc;
    BoxSerialNumber *boxp;

	*override = false;
    /*
     * if we're not in xbAccessMode, ignore
     */
    if (!gConfig.xbAccessMode)
	{
		return(kNoError);
	}
	PLogmsg(LOGP_PROGRESS, "Server_XbAccess:start\n");

    boxp = &state->loginData.userID.box;
    statusFlags = 0;
	if ((err = Server_XbAccessParse(
		state, boxPhone_p, x25, Common_NumPops(kPopSelect16), lookup_p, pop_choices_p,
		argv, &argc, pop_test)))
	{
		if (err != kErrNoPopMail)
		{
			Server_XbSendPopMail(state,  boxPhone_p, pop_choices_p, 0, 0, x25);
			*redial = false;
		}
		return(kNoError);
	}
	
	switch(lookup_p->num_pops)
	{
	case	1:
		Common_PhoneFormatDisplay(lookup_p->pop[0].phone.phoneNumber, phone1);
		PLogmsg(LOGP_DBUG, "XBAND-ACCESS: box %d changed local access number to %s\n",
			boxp->box, phone1);
		sprintf(buf, gettext("You have changed your local access numbers to %s."), phone1);
		break;
	case	2:
		Common_PhoneFormatDisplay(lookup_p->pop[0].phone.phoneNumber, phone1);
		Common_PhoneFormatDisplay(lookup_p->pop[1].phone.phoneNumber, phone2);
		PLogmsg(LOGP_DBUG, "XBAND-ACCESS: box %d changed local access number to %s and %s\n",
			boxp->box, phone1, phone2);
		sprintf(buf, gettext("You have changed your local access numbers to %s and %s."),
			phone1, phone2);
		break;
	default:
		//
		// something was wrong with the mail, notify the user, but continue
		// processing.
		//
		if (argc)
		{
			sprintf(buf, gettext("We are unable to find any valid local access numbers in your %s X-Mail. Please read the %c%s%c X-Mail for more information.\n"),
			gettext(kXBAND_ACCESS), kQuoteL,  gettext(kXBAND_ACCESS_ERROR), kQuoteR);
		}
		else
		{
			sprintf(buf, gettext("To use the %s feature, please first read the %c%s%c Mail.\n"),
				gettext(kXBAND_ACCESS), kQuoteL, gettext(kXBAND_ACCESS_INSTRUCT),
				kQuoteR);
		}
#if	0
		PLogmsg(LOGP_DBUG, "XXX:%s", buf);
#endif
		Server_SendDialog(state, buf, true);	/* DIALOG */
		Server_XbSendPopMail(state, boxPhone_p, pop_choices_p, argv, argc, x25);
		*redial = false;
		return(kNoError);
	}
	if (x25 != kX25_FIRST_CONNECT)
	{
#if	0
		PLogmsg(LOGP_DBUG, "XXX:%s", buf);
#endif
		Server_SendDialog(state, buf, true);	/* DIALOG */
	}
	
	*override = true;

#if	0
    if (Server_SyncWithBox(state) != kServerFuncOK)
	{
		/* box is gone, we'll be SIGHUPing shortly, no doubt... */
	
		Logmsg("XBAND-ACCESS: SyncWithBox failed\n");
    }
#endif
    return kNoError;
}
static Err	Server_XbAccessParse(ServerState *state, phoneNumber *boxPhone_p, int x25, short max_pops, LOOKUP_POP_P lookup_p, LOOKUP_POP_P pop_choices_p, char **argv, int *argc_p, int *pop_test)
{
	Err				err;
	int				argc;
	SuperPhone		phone[kMaxMailPopNum];
	phoneNumber		nums[kMaxMailPopNum];
	phoneNumber		failed[kMaxMailPopNum];
	char			raw[kPhoneNumberSize];
    char			c;
	char			*cp;
	char			*dp;
	char			buf[1024];
	int				i;
	long			found_xband_access;
	long			found_numbers;
	long			found_failed;
	long			full_pop_search = false;
	long			in_digits = false;
    BoxSerialNumber *boxp = &state->loginData.userID.box;
	Mail 			*mail;
	SuperPhone		boxSuper;

	found_xband_access = false;
	//
	// mail processes newest to oldest,
	//
    for (i = 0; i < state->incomingMail.count; i++)
	{
		mail = state->incomingMail.mailItems[i].mail;
	
		PLogmsg(LOGP_DBUG, "Server_XbAccessMail:Xmail:%s\n", mail->to.userName);
		if (DataBaseUtil_CompareStrings(mail->to.userName, kXBAND_ACCESS) == 0)
		{
			//
			// only process the newest one
			//
	
		    PLogmsg(LOGP_DBUG, "XBAND-ACCESS: box %d mail title = %s, body = %s\n",
			   boxp->box, mail->title, mail->message);
	
			//
			// For XBAND-ACCESS, this is unsolicited, ie not a reply.
			// or we don't care if it is a reply.
			//
			// If no valid pop phoneNumbers are included in the Title/Body,
			// then we treat this the same as the failure case, send the list
			// of pops to the customer. Ask them to provide the number.
			//
			sprintf(buf, "%s %s", mail->title, mail->message);
			found_xband_access = true;
			break;
		}
	}
	lookup_p->err = kNoError;
	if (!found_xband_access)
	{
		return (kErrNoPopMail);
	}
    PLogmsg(LOGP_DBUG, "XBAND-ACCESS: box:%d mail:%s\n", boxp->box, buf);
	
	if ((err = Server_PopList(boxPhone_p, pop_choices_p)) != kNoError)
	{
    	PLogmsg(LOGP_NOTICE, "XBAND-ACCESS: box phone:%s Server_PopList lookup failed\n",
			boxPhone_p->phoneNumber);
		lookup_p->err = err;
		return(err);
	}
	else if (!pop_choices_p->num_pops)
	{
    	PLogmsg(LOGP_FLAW, "XBAND-ACCESS: box phone:%s Server_PopList lookup failed\n",
			boxPhone_p->phoneNumber);
		lookup_p->err = err;
		return(err);
	}
    dp = cp = buf;
	//
	// Clear out everything but numerics, or potential phone chars
	//
	in_digits = false;
	while ((c = *cp))
	{
		if (!isdigit(c))
		{
			//
			// see if they are the sort of chars that people
			// typically stick in phone numbers, event though
			// you told them not to. If they are, leave them for
			// phone number processing. Otherwise blank them out.
			//
			switch (c)
			{
			case	'	':
			case	',':
			case	' ':
				*dp++ = ' ';
				in_digits = false;
				break;
			case	'-':
				if (in_digits)
				{
					*dp++ = c;
				}
				break;
			case	'*':
				*dp++ = ' ';
				full_pop_search = true;
				break;
			default:
				if (!in_digits)
				{
					*dp++ = ' ';
				}
			}
		}
		else
		{
			*dp++ = c;
			in_digits = true;
		}
		cp++;
	}
	*dp = c;
	//
	// Get the list of legal local access for this number 
	//
	//
	// Convert the contents into an arg list
	//
	argc = Common_ArgList(kMaxMailPopNum-1, argv, buf);
	*argc_p = argc;
	//
	// parse all of the possible numbers
	//
	found_numbers = false;
	for (i = 0; i < argc; i++)
	{
		if (Common_PhoneParseDefault(argv[i], &phone[found_numbers]) == kNoError)
		{
			PLogmsg(LOGP_DBUG, "Server_XbAccessMail:argv[%d]:%s\n", i, argv[i]);
			Common_PhoneFormatSuperToRaw(&phone[found_numbers], raw);
			if (Server_ValidatePop(raw, pop_choices_p, &nums[found_numbers].scriptID))
			{
				strcpy(nums[found_numbers++].phoneNumber, raw);
			}
			else if (!full_pop_search)
			{
				PLogmsg(LOGP_NOTICE, "Server_XbAccessMail:%s:not in pop_list\n", raw);
				strcpy(failed[found_failed++].phoneNumber, raw);
			}
			else
			{
				strcpy(nums[found_numbers].phoneNumber, raw);
				strcpy(failed[found_failed].phoneNumber, raw);
				//
				// if we don't have an NPA, extract from game phone. Build the
				// normalized phone number.
				//
				if (!phone[found_numbers].npa_len)
				{
					Common_PhoneParseDefault(boxPhone_p->phoneNumber, &boxSuper);
					boxSuper.nxx = phone[found_numbers].nxx;
					boxSuper.yyyy = phone[found_numbers].yyyy;
					boxSuper.leading_0 = false;
					boxSuper.leading_1 = false;
					Common_PhoneFormatSuperToRaw(&boxSuper, raw);
					PLogmsg(LOGP_DBUG, "Server_XbAccessMail:created %s from %s\n",
						raw, phone[found_numbers].p.phoneNumber);
					if (!Server_ValidatePopAny(raw, &nums[found_numbers].scriptID))
					{
						found_numbers++;
						*pop_test = true;
					}
					else
					{
						found_failed++;
						PLogmsg(LOGP_NOTICE,
							"Server_XbAccessMail:%s: Server_ValidatePopAny Failed\n", raw);
					}
				}
				else if (!Server_ValidatePopAny(phone[found_numbers].p.phoneNumber,
					&nums[found_numbers].scriptID))
				{
					found_numbers++;
					*pop_test = true;
				}
				else
				{
					found_failed++;
					PLogmsg(LOGP_NOTICE, "Server_XbAccessMail:%s: Server_ValidatePopAny Failed\n",
						phone[found_numbers].p.phoneNumber);
				}
			}
		}
	}
	memset(&lookup_p->pop, 0, sizeof(lookup_p->pop));
	if (found_numbers)
	{
		for (i = 0; (i < found_numbers) && (i < max_pops); i++)
		{
			memcpy(&lookup_p->pop[i].phone, &nums[i], sizeof(phoneNumber));
		}
		lookup_p->num_pops = i;
	}
	else
	{
		lookup_p->num_pops = 0;
	}
	return(kNoError);
}
//
// Send the pop mail, explaining the process
//
static	void Server_XbSendPopMail(ServerState *state, phoneNumber* boxPhone_p, LOOKUP_POP_P pop_choices_p, char **argv, int argc, int x25)
{
	int			line1 = true;
	int			line2 = true;
	int			line3 = true;
	Err			err;
	int			len;
	int			sent;
	int			i,j,k;
	char		mbuf[1024];
	char		title[128];
	char		number[20];
	
	//
	// don't repeat the mail for the first x25 connect,
	// already done by 800 connect.
	//
	if (x25 == kX25_FIRST_CONNECT)
	{
		return;
	}
    /*
     * Send down the PopMail mail if it's not on the box already.
     */
    for (i = 0; i < state->loginData.numMailsInBox; i++)
	{
		switch (state->loginData.mailSerialNumbers[i])
		{
		case kXbAccessMailSN:
			line1 = false;
		    break;
		case kXbAccessPopListSN:
			line2 = false;
		    break;
		case (kXbAccessPopListSN+1):
			line3 = false;
		    break;
		}
	}
    if (i == state->loginData.numMailsInBox)
	{
		if (argc)
		{
		    strcpy(mbuf, 
				gettext("Sorry, we are unable to find a valid local access number in the following list:"));
			for (i = 0; i < argc; i++)
			{
				sprintf(&mbuf[strlen(mbuf)], " %s", argv[i]);
			}
			sprintf(&mbuf[strlen(mbuf)], gettext(" Please try again. You must select a number from one of the %c%s%c X-Mails."), kQuoteL, gettext(kXBAND_NUMBER_LIST), kQuoteR);
			if (x25)
			{
				Server_SendMailFromXBAND(state, gettext(kXBAND_ACCESS), gettext(kXBAND_ACCESS_ERROR),
					mbuf, kXbAccessMailErr);
			}
			else
			{
				Server_SendMailRaw(state, gettext(kXBAND_ACCESS), gettext(kXBAND_ACCESS_ERROR),
					mbuf, kXbAccessMailErr, &sent);
			}
		}
		if (line1)
		{
		    sprintf(mbuf, 
				gettext("Select 1 or 2 local access numbers from the %c%s%c X-Mails. Reply and enter local access number(s) EXACTLY as you would dial them from your home phone.  This includes or excludes %c1%c and the area code."),
				kQuoteL, gettext(kXBAND_NUMBER_LIST), kQuoteR, kQuoteL, kQuoteR);
			if (x25)
			{
				Server_SendMailFromXBAND(state, gettext(kXBAND_ACCESS), gettext(kXBAND_ACCESS_INSTRUCT),
					mbuf, kXbAccessMailSN);
			}
			else
			{
				Server_SendMailRaw(state, gettext(kXBAND_ACCESS), gettext(kXBAND_ACCESS_INSTRUCT),
					mbuf, kXbAccessMailSN, &sent);
			}
		}
		//
		// at this point if we haven't already accessed the list, do it
		//
		if (!pop_choices_p->num_pops)
		{
			if ((err = Server_PopList(boxPhone_p, pop_choices_p)) != kNoError)
			{
		    	PLogmsg(LOGP_FLAW, "XBAND-ACCESS: box phone:%s Server_PopList lookup failed:err %d\n",
					boxPhone_p->phoneNumber, err);
			}
		}
	
		j = 0;
		i = 0;
		while (j < pop_choices_p->num_pops)
		{
			i++;
			mbuf[0] = '\0';
			for (k = 0; (k < 5) && (j < pop_choices_p->num_pops); k++, j++)
			{
				len = strlen(mbuf);
				Common_PhoneFormatDisplay(pop_choices_p->pop[j].phone.phoneNumber, number);
				sprintf(&(mbuf[len]), gettext("%s in %s "), number, pop_choices_p->pop_town[j]);
			}
	    	strcat(mbuf, gettext("\n"));
			sprintf(title, "%s %d", gettext(kXBAND_NUMBER_LIST), i);
			if ((line2 && !i) || (line3 && i))
			{
				if (x25)
				{
					Server_SendMailFromXBAND(state, gettext(kXBAND_ACCESS), title,
						mbuf, kXbAccessPopListSN + i);
				}
				else
				{
					Server_SendMailRaw(state, gettext(kXBAND_ACCESS), title,
						mbuf, kXbAccessPopListSN + i, &sent);
				}
			}
		}
		PLogmsg(LOGP_PROGRESS, "XBAND-ACCESS: sending mail\n");
    }
    else
	{
		PLogmsg(LOGP_PROGRESS, "XBAND-ACCESS: not re-sending the mail\n");
    }
}
static	void Server_PatchPopDial(ServerState * state, phoneNumber *popPhone, phoneNumber *altPhone)
{
	// If the boxid looks good then try looking up the account to determine
	// if it needs a dial9 patch to the POP.  Server_AddPBX_Dial9 will
	// prepend a "9," to the popphones if the boxAccount->debug[1] == dial9
	// bit.
	//
	// Not needed on SJNES/SNES, since that has support built in.
	//
	// (Remember that we're handling a 0120 (1-800) connect, so this connect is
	// about to bail... unless someday we support a full connect on 800.)
	//
	if (state->platformID == kPlatformGenesis) {
		if ((state->loginData.userID.box.box > 0) && (state->loginData.userID.box.region > 0))
		{
			PLogmsg(LOGP_DBUG, "Looking up account to check dial 9 flag\n");
			if (WrapperDB_FindAccount(&state->loginData.userID, &state->account) == kNoError)
			{
				// Found the account, set the dial 9 stuff if needed.
				//
				Server_AddPBX_Dial9(state, popPhone, altPhone);
				DataBaseUtil_FreeAccount(state->account);
				state->account = NULL;
			}
		}
	}
}
//
// prepend "9," if the dial 9 flag is set in the boxAccount.
//
void Server_AddPBX_Dial9(ServerState *state, phoneNumber *popPhone, phoneNumber *altPhone)
{
	//
	// Genesis platforms only
	//
	if (state->platformID != kPlatformGenesis)
	{
		return;
	}

	if (state->account && (state->account->boxAccount.debug[1] &  kBA_debug_dial9))
    {
	phoneNumber tmpPhone;

		// prepend to the POPphone only if it's not already overridden to already have the dial9 prefix
		//
		if(popPhone->phoneNumber[0] != '\0' && strncmp(popPhone->phoneNumber, "9,", 2))
		{
			strcpy(tmpPhone.phoneNumber, popPhone->phoneNumber);
			strcpy(popPhone->phoneNumber, "9,");
			strcat(popPhone->phoneNumber, tmpPhone.phoneNumber);
		}

		// and the alt phone, too
		if(altPhone->phoneNumber[0] != '\0' && strncmp(altPhone->phoneNumber, "9,", 2))
		{
			strcpy(tmpPhone.phoneNumber, altPhone->phoneNumber);
			strcpy(altPhone->phoneNumber, "9,");
			strcat(altPhone->phoneNumber, tmpPhone.phoneNumber);
		}
	}
}
//
// Client side get list of all possible pops
//
static	Err Server_PopList(phoneNumber *boxPhone_p, LOOKUP_POP_P lookup_p)
{
Err			err;

	err = PhoneDB_GetPops(kLookupPop, boxPhone_p, false, kPopSelect16List, 0, lookup_p);
	return(err);
}
static	int Server_ApplyOverride(Account*account, BoxAccount*box_ac_p, int new_override, LOOKUP_POP_P pop_choices_p, phoneNumber*boxPhone_p, phoneNumber*popPhone_p, phoneNumber*altPopPhone_p, phoneNumber*overridePOP1_p, phoneNumber*overridePOP2_p)
{
	int				override;
	int				failed_pop;
	DBID			scriptID;

	//
	// see if our overrides and our defaults match exactly
	//
	if ((!strcmp(popPhone_p->phoneNumber, overridePOP1_p->phoneNumber)) &&
		(!strcmp(altPopPhone_p->phoneNumber, overridePOP2_p->phoneNumber)))
	{
		override = false;
	}
	else if ((!strcmp(popPhone_p->phoneNumber, overridePOP2_p->phoneNumber)) &&
		(!strcmp(altPopPhone_p->phoneNumber, overridePOP1_p->phoneNumber)))
	{
		override = false;
	}
	else
	{
		//
		// we've got an override coming
		//
		override = true;
	}
	if (account)
	{
		if (new_override)
		{
			memcpy(&box_ac_p->overridePOP1, overridePOP1_p, sizeof(box_ac_p->overridePOP1));
			memcpy(&box_ac_p->overridePOP2, overridePOP2_p, sizeof(box_ac_p->overridePOP2));
			memcpy(&box_ac_p->overrideANI1, boxPhone_p, sizeof(box_ac_p->overrideANI1));
			//
			// save the override info, but clear the flag
			//
			if (!override)
			{
				PLogmsg(LOGP_DBUG, "Server_ApplyOverride:%s override cancelled: %s %s\n",
					boxPhone_p->phoneNumber, popPhone_p->phoneNumber, altPopPhone_p->phoneNumber);
				if (box_ac_p->boxFlags & kBoxFlag_PopOverRideTest)
				{
					box_ac_p->boxFlags &= ~kBoxFlag_PopOverRideTest;
				}
				box_ac_p->boxFlags &= ~kBoxFlag_PopOverRide;
				account->boxModified |= (kBA_overridePhone | kBA_boxFlags);
			}
		}
		else if (strcmp(box_ac_p->overrideANI1.phoneNumber, boxPhone_p->phoneNumber))
		{
		//
		// existing override data, if our phone number, != the override number,
		// then we just ignore it
		//
			override = false;
		}
		else if (!override)
		{
			//
			// existing override, matches current defaults, clear the override flag
			//
			PLogmsg(LOGP_DBUG, "Server_ApplyOverride:%s override cancelled: %s %s\n",
				boxPhone_p->phoneNumber, popPhone_p->phoneNumber, altPopPhone_p->phoneNumber);
			box_ac_p->boxFlags &= ~kBoxFlag_PopOverRide;
			account->boxModified |= (kBA_overridePhone | kBA_boxFlags);
		}
	}
	//
	// lets use those override pops
	//
	if (override)
	{
		if (account)
		{
			if (!(box_ac_p->boxFlags & kBoxFlag_PopOverRideTest))
			{
				if (!pop_choices_p->num_pops)
				{
					if ((Server_PopList(boxPhone_p, pop_choices_p) != kNoError) ||
						(!pop_choices_p->num_pops))
					{
				    	PLogmsg(LOGP_NOTICE, "XBAND-ACCESS: box phone:%s Server_PopList lookup failed\n",
							boxPhone_p->phoneNumber);
					}
				}
				if (pop_choices_p->num_pops)
				{
					failed_pop = 0;
					if (!Server_ValidatePop(overridePOP1_p->phoneNumber, pop_choices_p, &scriptID))
					{
						failed_pop += 1;
					}
					if (!Server_ValidatePop(overridePOP2_p->phoneNumber, pop_choices_p, &scriptID))
					{
						failed_pop += 2;
					}
					switch (failed_pop)
					{
					case	1:
						PLogmsg(LOGP_NOTICE, "XBAND-ACCESS: box phone:%s:pop %s no longer validi\n",
							boxPhone_p->phoneNumber, overridePOP1_p->phoneNumber);
							overridePOP1_p = overridePOP2_p;
						break;
					case	2:
						PLogmsg(LOGP_NOTICE, "XBAND-ACCESS: box phone:%s:pop %s no longer validi\n",
							boxPhone_p->phoneNumber, overridePOP2_p->phoneNumber);
							overridePOP2_p = overridePOP1_p;
						break;
					case	3:
						//
						// existing override, matches current defaults, clear the override flag
						//
						PLogmsg(LOGP_DBUG, "Server_ApplyOverride:%s override cancelled: %s %s\n",
							boxPhone_p->phoneNumber, overridePOP1_p->phoneNumber,
							overridePOP2_p->phoneNumber);
						box_ac_p->boxFlags &= ~kBoxFlag_PopOverRide;
						account->boxModified |= (kBA_overridePhone | kBA_boxFlags);
						override = false;
						break;
					}
				}
			}
		}
		if (strlen(overridePOP1_p->phoneNumber) && strlen(overridePOP2_p->phoneNumber))
		{
			memcpy(popPhone_p, overridePOP1_p, sizeof(*popPhone_p));
			memcpy(altPopPhone_p, overridePOP2_p, sizeof(*altPopPhone_p));
			PLogmsg(LOGP_DBUG, "Server_ApplyOverride:%s use override pops %s %s\n",
				boxPhone_p->phoneNumber, popPhone_p->phoneNumber, altPopPhone_p->phoneNumber);
		}
		else
		{
			override = false;
		}
	}
	return(override);
}
//
// update the gamePhone, if needed.
//
void	Server_GamePhoneUpdate(ServerState *state, Account *account, phoneNumber *boxPhone_p)
{
	BoxAccount		*box_ac_p = &account->boxAccount;
	BoxSerialNumber	*boxp = &state->loginData.userID.box;
	//
	// check that phone numbers match and replace if not.
	//
	if (Common_PhoneCompareNumbers(box_ac_p->gamePhone.phoneNumber, boxPhone_p->phoneNumber))
	{
		PLogmsg(LOGP_DBUG, "Server_GamePhoneUpdate:gamePhone changed:%s (%d,%d)\n",
			boxPhone_p->phoneNumber, boxp->box, boxp->region);
		box_ac_p->dateLastChangedGamePhone = state->timeOfThisConnect;
		box_ac_p->gamePhone = *boxPhone_p;
		account->boxModified |= kBA_gamePhone;
	}
}
#if	0
static	void	Server_NukeOutGoingMail(ServerState *state)
{
    messOut			opCode;
    BoxSerialNumber *boxp;
    /*
     * He didn't send the correct mail.
     * Nuke the box's outgoing mail,
     * bump his legal-counter and suspend his account if necessary,
     * replace the initial mail if necessary,
     * send him a dialog about the mail and news.
     */

    if (state->incomingMail.count)
	{
		long controlFlags;
	
		PLogmsg(LOGP_NOTICE, "Server_XbAccess:Nuke Mail\n");
		opCode = msServerMiscControl;
		Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
		controlFlags = kDeleteAllAoutBoxMailFlag;
		Server_TWriteDataSync(state->session, sizeof(long),(Ptr)&controlFlags);
		PLogmsg(LOGP_PROGRESS, "XBAND-ACCESS: nuked his outgoing mail\n");
    }
    else
	{
		Logmsg("XBAND-ACCESS: box %d had no outgoing mail\n", boxp->box);
    }
}
#endif
