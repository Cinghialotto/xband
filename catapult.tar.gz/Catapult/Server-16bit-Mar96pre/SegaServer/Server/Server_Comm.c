/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Comm.c,v 1.12 1996/01/31 18:02:24 hufft Exp $
 *
 * $Log: Server_Comm.c,v $
 * Revision 1.12  1996/01/31  18:02:24  hufft
 * UDP socket changes
 *
 * Revision 1.11  1996/01/30  01:37:40  fadden
 * Set gTLayerReading so we'll block waiting for I/O inside TReadData.
 *
 * Revision 1.10  1996/01/29  21:59:49  hufft
 * upd packet changes
 *
 * Revision 1.9  1996/01/25  17:51:44  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.8  1995/11/13  17:36:48  ansell
 * Modified magnify_debug stuff so that we write to the record file for each
 * piece of data the box sends up so we will have a record in cases where the
 * server dies or the connection prematurely aborts.
 *
 * Revision 1.7  1995/09/15  15:56:59  ansell
 * Changed to only track read data for the box in "magnify debug" mode.
 *
 * Revision 1.6  1995/09/13  14:24:24  ted
 * Fixed warnings.
 *
 * Revision 1.5  1995/07/26  23:01:01  fadden
 * Added SERVER_RECORDFROMBOX stuff (part of magnifyDebug).
 *
 * Revision 1.4  1995/07/07  20:46:54  fadden
 * Added some notes about Server_SetTransportHold.
 *
 * Revision 1.3  1995/06/01  15:05:21  fadden
 * Track total bytes read/written.
 *
 * Revision 1.2  1995/05/26  23:46:06  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_Comm.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans

	Change History (most recent first):

		<12>	 9/19/94	ATM		PLogmsg stuff.
		<11>	 9/16/94	ATM		Add a prototype.
		<10>	 9/16/94	ATM		Whoops.
		 <9>	 9/16/94	ATM		Add SERVER_SIMULATE_DELAY stuff.
		 <8>	 8/12/94	ATM		Converted to Logmsg.
		 <7>	  8/2/94	DJ		fixed setransphold bug when in readfromfile
		 <6>	  8/2/94	DJ		added Server_SetTransportHold
		 <5>	 7/27/94	DJ		fixing NULL pBlock
		 <4>	 7/27/94	DJ		made Server_TNetIdle set pBlock to kConnOpen if doing File input
									instead of com layer.
		 <3>	 7/26/94	BET		Add #ifndef unix to Server_PListen.  Our priceless unix
									compilers are not smart enough to dead code strip on link.
		 <2>	 7/25/94	DJ		using async write now
		 <1>	 7/20/94	DJ		first checked in

	To Do:
*/


// define this to read/write from a file instead of from the modem
//#define SERVER_READFROMINPUTFILE	1

// define this to write data to a tee file
#define SERVER_WRITE_TEE	1
#define SERVER_READ_TEE		1

// If we're reading from an input file, we can only write to a file (modem can't run)
#ifdef SERVER_READFROMINPUTFILE
#define SERVER_WRITE_TEE	1
#endif

#ifdef SERVER_READFROMINPUTFILE
// Add delays to simulate a 200 cps modem when reading from a file.  Makes
// the simulated runs more representative of the real thing, by spacing
// the database calls out to appropriate intervals, and keeping the
// server front-end alive for a longer time.
//
// Makes little sense to do this if we're not reading from a file.
//
#define SERVER_SIMULATE_DELAY	1
#ifdef SERVER_SIMULATE_DELAY
# define ONE_MILLION	1000000
# define SERVER_CHAR_DELAY	(ONE_MILLION/200)		// 5000 usec per character
static int writeDelay = 0;	// fake async writes by doing them all at TClose
void Server_SimulateDelay(int nchars);
#endif
#endif /*SERVER_READFROMINPUTFILE*/

#include <stdio.h>
#include <memory.h>
#include <fcntl.h>
#include <malloc.h>
#include <unistd.h>
#include <poll.h>
#include "PhysicalLayer.h"
#include "Server.h"
#include "Common_Missing.h"

static FILE *writeTee, *readTee;
#ifdef SERVER_READFROMINPUTFILE
static FILE *inTee;
#endif

#define SERVER_RECORDFROMBOX
#ifdef SERVER_RECORDFROMBOX

#include "ServerDataBase.h"
#define kMaxRecordBuf	2048
static char recordBuf[kMaxRecordBuf];
static int recordBufOffset = 0;
static int recordfd = -1;

extern ServerState *boxState;
#endif


extern long	gDebugReadCount;
extern long	gDebugWriteCount;

static	OSErr	Server_ReadUdpStream(StreamRec_P rec_p, Ptr address, u_long length);
static	OSErr	Server_ReadUdpPacket(StreamRec_P rec_p);
static	OSErr	Server_WriteUdpStream(StreamRec_P rec_p, Ptr address, u_long length);
static	OSErr	Server_WriteUdpPacket(StreamRec_P rec_p);
static	OSErr	Server_AckUdpPacket(StreamRec_P rec_p, u_char seq);
static	OSErr	Server_RespondUdpPacket(StreamRec_P rec_p, UDP_PK_TYPE type, u_char seq);

int Server_OpenDataTee(char *writefilename, char *readfilename, char *infilename)
{
#ifdef SERVER_WRITE_TEE
	writeTee = fopen(writefilename, "wb");
	if(!writeTee)
		return(-1);
#endif

#ifdef SERVER_READ_TEE
	readTee = fopen(readfilename, "wb");
	if(!readTee)
		return(-1);
#endif

#ifdef SERVER_READFROMINPUTFILE
	inTee = fopen(infilename, "rb");
	if(!inTee)
		return(-1);
#endif

#ifdef SERVER_RECORDFROMBOX
	memset(recordBuf, 0, kMaxRecordBuf);
	recordBufOffset = 0;
#endif

	return(0);
}

int Server_CloseDataTee()
{
#ifdef SERVER_WRITE_TEE
	if(writeTee)
		fclose(writeTee);
#endif

#ifdef SERVER_READ_TEE
	if(readTee)
		fclose(readTee);
#endif

#ifdef SERVER_READFROMINPUTFILE
	if(inTee)
		fclose(inTee);
#endif

#ifdef SERVER_RECORDFROMBOX
	if (boxState->magnifyMode) {
		if (recordfd != -1)
			close(recordfd);
	}
#endif

	return(0);
}


//
// Change the transport layer "hold" value.
//
// When set to "false", data is immediately packetized and queued up for
// transmission.  When set to "true", data is buffered up until the hold
// is turned off again.
//
// The transport layer adds 18 bytes of overhead to a 1-byte packet, so
// liberal use of this is encouraged.  ++ATM 950707
//
void Server_SetTransportHold(ConnSession_P s, Boolean hold)
{
	// If you want to watch messages go down synchronously instead of in
	// batches, un-comment the "return" statement below.
	//
	// return;

#ifndef SERVER_READFROMINPUTFILE
	if (s->type == SESSION_ADSP)
	{
		TSetTransportHold(hold);
	}
	else
	{
		s->rec.stream.buffer = hold;
	}
#endif
}
#define	UDP_PACKET_SIZE	(sizeof(UdpPacket)+4096)
#define	UDP_OUT_TRIES	20
static	OSErr	Server_ReadUdpStream(StreamRec_P rec_p, Ptr address, u_long length)
{
	OSErr			err = 0;
	UdpPacket_P		in_p;

	while (length)
	{
		if (!rec_p->q_in_p)
		{
			if ((err = Server_ReadUdpPacket(rec_p)))
			{
				return(-1);
			}
		}
		else if (!rec_p->q_in_p->length)
		{
			in_p = rec_p->q_in_p;
			rec_p->q_in_p = in_p->q.next;
			free(in_p);
		}
		else
		{
			*address++ = *rec_p->q_in_p->data_p++;
			rec_p->q_in_p->length--;
			length--;
		}
	}
	return (0);
}
#define	UDP_PACKET_HDR_SIZE	(offsetof(UdpPacket,data) - offsetof(UdpPacket,type))
static	OSErr	Server_ReadUdpPacket(StreamRec_P rec_p)
{
	OSErr			err = 0;
	UdpPacket_P		in_p = rec_p->in_p;
	u_char			seq;
	int				i;

	//
	// if we don't have a udp buffer yet
	//
	if (!in_p)
	{
		rec_p->in_p = in_p = (UdpPacket_P)calloc(UDP_PACKET_SIZE, 1);
	}
	rec_p->sockaddr_len = sizeof(rec_p->sockaddr_in);
	err = recv_dg(rec_p->infd, (char*)&in_p->type, UDP_PACKET_SIZE,
		(SOCKADDR_P)&rec_p->sockaddr_in, &rec_p->sockaddr_len, rec_p->in_timeout);
	if (err < (OSErr)UDP_PACKET_HDR_SIZE)
	{
		rec_p->error = kSessionClosedErr;
		PLogmsg(LOGP_FLAW,
			"Server_ReadUdpPacket:partial hdr packet:len:%d:expected:%d:errno:%ld\n",
			err, UDP_PACKET_HDR_SIZE, errno);
		return(-1);
	}
	if ((in_p->length + UDP_PACKET_HDR_SIZE) != err)
	{
		PLogmsg(LOGP_FLAW,
			"Server_ReadUdpPacket:partial data packet:len:%d:expected:%d:errno:%ld\n",
			err, in_p->length, errno);
		return(-1);
	}
	seq = rec_p->in_seq;									// expected sequence
	//
	// if it's not an ack from client, then ack it
	// 
	switch (in_p->type)
	{
	case	UDP_PK_TYPE_DATA:
		Server_AckUdpPacket(rec_p, in_p->seq);
//		PLogmsg(LOGP_DBUG, "Server_ReadUdpPacket:type:DATA:seq:%d\n", in_p->seq);
		if (seq != in_p->seq)
		{
			PLogmsg(LOGP_DBUG, "Server_ReadUdpPacket:type:DATA:bad:seq:%d:expected:%d\n",
				in_p->seq, seq);
		}
		else
		{
			in_p->data_p = in_p->data;
			if (in_p->length)
			{
				in_p->q.prev = 0;
				if (rec_p->q_in_p)
				{
					in_p->q.next = rec_p->q_in_p;
				}
				else
				{
					in_p->q.next = 0;
				}
				rec_p->q_in_p = in_p;
				rec_p->in_p = 0;
			}
		}
		break;
	case	UDP_PK_TYPE_HELLO:
		Server_AckUdpPacket(rec_p, in_p->seq);
//		PLogmsg(LOGP_DBUG, "Server_ReadUdpPacket:type:HELLO:seq:%d\n", in_p->seq);
		if (seq != in_p->seq)
		{
			PLogmsg(LOGP_DBUG, "Server_ReadUdpPacket:type:HELLO:bad:seq:%d:expected:%d\n",
				in_p->seq, seq);
		}
		break;
	case	UDP_PK_TYPE_BYE:
		if (!rec_p->closed)
		{
			PLogmsg(LOGP_DBUG, "Server_ReadUdpPacket:type:BYE:\n");
			rec_p->in_timeout = 5000;
			rec_p->closed++;
			rec_p->error = kSessionClosedErr;
			for (i = 0; i < 5; i++)
			{
				Server_RespondUdpPacket(rec_p, UDP_PK_TYPE_BYE, in_p->seq);
			}
		}
		return(-1);
		break;
	case	UDP_PK_TYPE_ACK:
//		PLogmsg(LOGP_DBUG, "Server_ReadUdpPacket:type:ACK:seq:%d\n", in_p->seq);
		if (rec_p->out_seq != in_p->seq)
		{
			PLogmsg(LOGP_DBUG, "Server_ReadUdpPacket:type:ACK:bad:seq:%d:expected:%d\n",
				in_p->seq, rec_p->out_seq);
		}
		else
		{
			rec_p->out_seq++;
		}
		break;
	}
	return(0);
}
static	OSErr	Server_AckUdpPacket(StreamRec_P rec_p, u_char seq)
{
	return(Server_RespondUdpPacket(rec_p, UDP_PK_TYPE_ACK, seq));
}
static	OSErr	Server_RespondUdpPacket(StreamRec_P rec_p, UDP_PK_TYPE type, u_char seq)
{
	long			i;
	UdpPacket		ack;
	OSErr			err;
	//
	// we got the expected packet, acknowledge it.
	//
	memset(&ack, 0, sizeof(ack));
	ack.type = type;
	ack.seq	= seq;
	for (i = 0; i < UDP_OUT_TRIES; i++)
	{
		err = send_dg(rec_p->outfd, &ack.type, UDP_PACKET_HDR_SIZE,
			(SOCKADDR_P)&rec_p->sockaddr_in, rec_p->sockaddr_len);
		if (err == (OSErr)UDP_PACKET_HDR_SIZE)
		{
			if (seq == rec_p->in_seq)
			{
				rec_p->in_seq++;
			}
			return(0);
		}
		//
		// couldn't do the ackknowledge
		//
		PLogmsg(LOGP_FLAW, "Server_RespondUdpPacket:write ACK:%d failed:%ld\n", seq, errno);
	}
	return(-1);
}
//
// These are wrappers for TransportLayer TReadDataSync and TWriteDataSync
//

OSErr	Server_TReadDataSync(ConnSession_P s, u_long length, Ptr address)
{
	extern int gTLayerReading;
	OSErr err;

	err = 0;
	#ifdef SERVER_READFROMINPUTFILE
	if(fread(address, length, 1, inTee) != 1)
	{
		err = -1;
	}
	#else
	if (s->type == SESSION_ADSP)
	{
		// Tell PUProcessIdle that we want to block waiting for data from
		// the box.  The only other place this flag is altered is in TListen,
		// which had better be over and done with by now!
		//
		gTLayerReading = true;
		err = TReadDataSync(&s->rec.adsp, length, address);
		gTLayerReading = false;
	}
	else
	{
		err = Server_ReadUdpStream(&s->rec.stream, address, length);
	}
	#endif

#ifdef SERVER_SIMULATE_DELAY
	Server_SimulateDelay(length);
#endif

#ifdef SERVER_READ_TEE
	if(!err && readTee)
	{
		fwrite(address, length, 1, readTee);
	}
#endif

#ifdef SERVER_RECORDFROMBOX
	// Save data for everyone until we receive login data then only
	// save if we are in "magnify debug" mode for this box.
	//
	if (!err)
	{
		if (!(boxState->validFlags & kServerValidFlag_Login)) {
			if (recordBufOffset + length < kMaxRecordBuf) {
				memcpy(recordBuf+recordBufOffset, address, length);
				recordBufOffset += length;
			} else {
				PLogmsg(LOGP_FLAW, "ERROR: recordBuf overflow (%d)\n",
					recordBufOffset);
			}
		} else if (boxState->magnifyMode) {
			if (recordfd == -1) {
				char name[32];

				sprintf(name, "record.%ld", 
					boxState->loginData.userID.box.box);
				if ((recordfd = open(name, O_WRONLY|O_CREAT|O_TRUNC, 0666)) 
					== -1) {
					PLogmsg(LOGP_FLAW,
						"WARNING: unable to open data log to '%s'\n", 
						name);
				} else {
					write(recordfd, recordBuf, recordBufOffset);
				}
			}
			write(recordfd, address, length);
			fsync(recordfd);
		}
	}
#endif

	if (!err)
	{
		gDebugReadCount += length;
	}
	return(err);
}

static	OSErr	Server_WriteUdpStream(StreamRec_P rec_p, Ptr address, u_long length)
{
	OSErr		err;
	UdpPacket_P	out_p = rec_p->out_p;

	//
	// if we don't have a udp buffer yet
	//
	if (!out_p)
	{
		rec_p->out_p = out_p = (UdpPacket_P)calloc(UDP_PACKET_SIZE, 1);
	}
	memcpy(&out_p->data[out_p->length], address, length);
	out_p->length += length;
	//
	// buffer and return
	//
	if (rec_p->buffer)
	{
		return(0);
	}
	err = Server_WriteUdpPacket(rec_p);
	out_p->length = 0;
	return(err);
}
static	OSErr	Server_WriteUdpPacket(StreamRec_P rec_p)
{
	OSErr			err = 0;
	long			i;
	UdpPacket_P		out_p = rec_p->out_p;
	long			size = UDP_PACKET_HDR_SIZE + out_p->length;
	u_char			out_seq = rec_p->out_seq;

	out_p->type = UDP_PK_TYPE_DATA;
	out_p->crc = 0;
	for (i = 0; (i < UDP_OUT_TRIES) && !rec_p->error; i++)
	{
		err = send_dg(rec_p->outfd, &out_p->type, size ,
			(SOCKADDR_P)&rec_p->sockaddr_in, rec_p->sockaddr_len);
		if (err == size)
		{
			if (poll_dg(0, rec_p->out_timeout) == 1)
			{
				//
				// try the read, and check for the ack
				//
				Server_ReadUdpPacket(rec_p);
				if (out_seq != rec_p->out_seq)
				{
					memset(out_p, 0, size);
					return(out_p->length);
				}
			}
		}
		else
		{
			PLogmsg(LOGP_FLAW, "Server_WriteUdpPacket:%d packet failed:errno:%ld,n", i, errno);
		}
	}
	return(-1);
}
OSErr	Server_TWriteDataSync(ConnSession_P s, u_long length, Ptr address)
{
OSErr err;

	err = 0;
#ifndef SERVER_READFROMINPUTFILE
	if (s->type == SESSION_ADSP)
	{
	//	err = TWriteDataSync(&s->rec.adsp, length, address);
		err = TWriteDataASync(&s->rec.adsp, length, address);
	}
	else
	{
		err = Server_WriteUdpStream(&s->rec.stream, address, length);	
	}
#endif

#ifdef SERVER_SIMULATE_DELAY
	writeDelay += length;
#endif

#ifdef SERVER_WRITE_TEE
	if(!err && writeTee)
		fwrite(address, length, 1, writeTee);
#endif

	if (!err)
		gDebugWriteCount += length;
	return(err);
}

OSErr Server_TCheckError(ConnSession_P s)
{
OSErr	err;
err = 0;
#ifndef SERVER_READFROMINPUTFILE
	if (s->type == SESSION_ADSP)
	{
		err = TCheckError();
		if(err != noErr)
			PLogmsg(LOGP_NOTICE, "*** Server_TCheckError: err = %ld\n", (long)err);
	}
	else
	{
		return(s->rec.stream.error);
	}
#endif
	return(err);
}


OSErr	Server_TListen(ConnSession_P s, PortT localPort, PortT remPort, u_long timeout)
{
OSErr	err;

	err = 0;
#ifndef SERVER_READFROMINPUTFILE
	if (s->type == SESSION_ADSP)
	{
		err = TListen(&s->rec.adsp, localPort, remPort, timeout);
	}
#endif

	return(err);
}

OSErr	Server_TClose(ConnSession_P s)
{
OSErr	err;

	err = 0;
#ifndef SERVER_READFROMINPUTFILE
	if (s->type == SESSION_ADSP)
	{
		err = TClose(&s->rec.adsp);
	}
#endif

#ifdef SERVER_SIMULATE_DELAY
	Server_SimulateDelay(writeDelay);
	writeDelay = 0;
#endif

	return(err);
}

short 	Server_TNetIdle(SessionType type, NetParamBlock *pBlock)
{
#ifndef SERVER_READFROMINPUTFILE
	if (type == SESSION_ADSP)
	{
		return(TNetIdle(pBlock));
	}
	else if(pBlock)
	{
		pBlock->ioPhysNetState = kConnOpen;
	}
	return(0);
#else
	if(pBlock)
	{
		pBlock->ioPhysNetState = kConnOpen;
	}
	return(0);
#endif
}


void	Server_TInit(SessionType type)
{
#ifndef SERVER_READFROMINPUTFILE
	if (type == SESSION_ADSP)
	{
		TInit();
	}
#endif
}

//
// Physical layer stuff
//

OSErr	Server_PListen(SessionType type, char *config, long flags)
{
OSErr	err;

	err = 0;
#ifndef SERVER_READFROMINPUTFILE
	if (type == SESSION_ADSP)
	{
		err = PListen(config, flags);
	}
#endif
	return(err);
}

#ifndef unix
OSErr	Server_PListenAsync(SessionType type, char *config, long flags)
{
OSErr	err;

	err = 0;
#ifndef SERVER_READFROMINPUTFILE
	if (type == SESSION_ADSP)
	{
		err = PListenAsync(config, flags);
	}
#endif
	return(err);
}
#endif

OSErr	Server_PClose(ConnSession_P connect_p)
{
OSErr	err = 0;

	if (connect_p->type == SESSION_ADSP)
	{
#ifndef SERVER_READFROMINPUTFILE
		err = PClose();
#endif
	}
	return(err);
}

OSErr	Server_PCheckError(ConnSession_P connect_p)
{
OSErr	err = 0;

	if (connect_p->type == SESSION_ADSP)
	{
#ifndef SERVER_READFROMINPUTFILE
		err = PCheckError();
#endif
	}
	return(err);
}


#ifdef SERVER_SIMULATE_DELAY
void Server_SimulateDelay(int nchars)
{
	u_long usec;

	//Logmsg("SLEEP %d chars", nchars);

	usec = nchars * SERVER_CHAR_DELAY;		// overflow at 4294 seconds
	if (usec > ONE_MILLION) {
		//Logmsg(" (%ld sec)", usec / ONE_MILLION);
		sleep(usec / ONE_MILLION);
		usec = usec % ONE_MILLION;
	}
	//Logmsg(" (%ld usec)", usec);
	if (usec)
		usleep(usec);
	//Logmsg("\n");
}
#endif


int	send_dg(int sockfd, char *data, int n, SOCKADDR_P to_addr_p, int to_len)
{
	if (sendto(sockfd, data, n, 0, to_addr_p, to_len) != n)
	{
		PLogmsg(LOGP_FLAW, "send_dg:failed to send packet:%d\n", errno);
		return(-1);
	}
	return(n);
}
int	poll_dg(int sockfd, int delay)
{
	int				err;
	struct pollfd	pfd[1];

	memset(&pfd, 0, sizeof(pfd));
	pfd[0].fd = sockfd;
	pfd[0].events = (POLLNVAL | POLLPRI | POLLIN | POLLERR | POLLHUP);
	while ((err = poll(pfd, 1, delay)) == -1)
	{
		switch(err)
		{
		case	EAGAIN:		// Allocation  of   internal   data   structures
							// failed,  but  the request shoud be attempted again.
			PLogmsg(LOGP_FLAW, "poll_dg:EAGAIN:fd:%d:errno:%d:\n", pfd[0].fd, errno);
			break;
		case	EFAULT: 	// Some argument points  outside  the  allocated
							// address space.
			PLogmsg(LOGP_FLAW, "poll_dg:EFAULT:fd:%d:errno:%d:\n", pfd[0].fd, errno);
			return(-1);
		case	EINTR:		// A signal was caught during the poll() system call.
			PLogmsg(LOGP_FLAW, "poll_dg:EINTR:fd:%d:errno:%d:\n", pfd[0].fd, errno);
			break;
		case	EINVAL:		// The argument nfds is less than zero.
							// nfds is greater than the system limit of open files.
			PLogmsg(LOGP_FLAW, "poll_dg:EINVAL:fd:%d:errno:%d\n", pfd[0].fd, errno);
			return(-1);
		}
	}
	if (err)
	{
		if (pfd[0].revents & POLLNVAL)
		{
			PLogmsg(LOGP_FLAW, "poll_dg:POLLNVAL:fd:%d:errno:%d\n", pfd[0].fd, errno);
			return(-1);
		}
		if (pfd[0].revents & POLLERR)
		{
			PLogmsg(LOGP_FLAW, "poll_dg:POLLERR:fd:%d:errno:%d\n", pfd[0].fd, errno);
			return(-1);
		}
		if (pfd[0].revents & POLLHUP)
		{
			PLogmsg(LOGP_FLAW, "poll_dg:POLLHUP:fd:%d:errno:%d\n", pfd[0].fd, errno);
			return(-1);
		}
		if (pfd[0].revents & POLLPRI) 
		{
//			PLogmsg(LOGP_DBUG, "poll_dg:POLLPRI:fd:%d\n", pfd[0].fd);
			return(1);
		}
		if (pfd[0].revents & POLLIN)
		{
//			PLogmsg(LOGP_DBUG, "poll_dg:POLLIN:fd:%d\n", pfd[0].fd);
			return(1);
		}
		return(0);
	}
	else					// timeout
	{
		return(0);
	}
}
int	recv_dg(int sockfd, char *data, int max_n, SOCKADDR_P from_addr_p, int *from_len, int timeout)
{
	int	n;

	if ((n = poll_dg(sockfd, timeout)) <= 0)
	{
		if (!n)
		{
			PLogmsg(LOGP_DBUG, "recv_dg:timed out waiting for packet:%d\n", errno);
		}
		return(n);
	}

	if ((n = recvfrom(sockfd, data, max_n, 0, from_addr_p, from_len)) < 0)
	{
		PLogmsg(LOGP_FLAW, "recv_dg:failed to recv packet:%d\n", errno);
	}
	return(n);
}
