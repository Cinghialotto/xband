/*
 * Copyright:	� 1995 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Tournament.c,v 1.27 1996/01/04 22:54:22 hufft Exp $
 *
 * $Log: Server_Tournament.c,v $
 * Revision 1.27  1996/01/04  22:54:22  hufft
 * added pop mail
 *
 * Revision 1.26  1995/12/13  19:08:22  chs
 * Added timestamps to SEtourney matchup and result structs.
 * Detect when an SEtourney box comes in on the wrong player
 * and send a dialog telling which player they should be using.
 *
 * Revision 1.25  1995/12/11  23:13:10  chs
 * Fix my stupid bug that made automatch tourneys not work.
 * When telling the user how long until the SEtourney starts,
 * assume it starts when the deadzone period ends instead of
 * at the next hour boundary.
 *
 * Revision 1.24  1995/12/07  22:03:35  chs
 * Fix Server_TourneyRedirectChallenge.
 * Add newlines at the ends of Logmsgs.
 *
 * Revision 1.23  1995/12/06  20:32:50  chs
 * In Server_IsTourneyConnection(), only say we're in a specific-match tourney
 * if we are really playing a tourney round Right Now.
 * Fix function names in Logmsg's.
 * Add "deadzone" tag to tourney-spec file.
 *
 * Revision 1.22  1995/12/05  16:35:02  chs
 * Only do tourney stuff if a tourney is running.
 * Mail+dialog text changes from Eliza.
 *
 * Revision 1.21  1995/12/04  16:37:41  chs
 * Added support for specific-match (currently single-elimination) tourneys.
 *
 * Revision 1.20  1995/11/01  10:29:15  chs
 * Split tourney "debug" flag into "nomatcher" and "nogamepatch" flags,
 * to allow selective disabling of the various pieces of a tourney.
 *
 * Revision 1.19  1995/10/16  14:29:45  sriram
 * Cleaned up old tourney stuff. Modifications for new tourney format.
 *
 * Revision 1.18  1995/09/13  14:24:49  ted
 * Fixed warnings.
 *
 * Revision 1.17  1995/08/25  17:45:21  fadden
 * Use WinAnalysis struct instead of computing stuff directly.  Dunno if
 * any of the code affected is actually used anymore; changes not tested.
 *
 * Revision 1.16  1995/07/10  21:10:53  rich
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.15  1995/05/26  23:47:11  jhsia
 * switch to rcs keywords
 *
 */

#include <memory.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>

#include "Common_Missing.h"
#include "Challnge.h"
#include "Server.h"
#include "ServerState.h"
#include "Server_Tournament.h"
#include "ServerWrapperDB.h"
#include "Common_ReadConf.h"
#include "Common_PlatformID.h"
#include "Common_OpaqueStore.h"
#include "OpaqueStoreKeys.h"

#define kWhiteSpace 		" \t\n"
#define MY_MAX_MAIL_MESG_SIZE  	512

// local prototypes
int 	Server_GetTourneyType(char	*);
long 	Server_GetTourneyTime(char*);
int 	Server_ReadTourneyData(char*, TourneyData**);
Boolean Server_IsTourneyConnection(ServerState *, TourneyData *);
Err 	Server_InitializeTourneyData(ServerState *);
void 	Server_SetTourneyOptional(TourneyData*, char*);
int 	Server_GetTourneyPlatform(char*);


int
Server_GetTourneyPlatform(
    char	*str
)
{
    int	platformID;

    PLogmsg(LOGP_PROGRESS, "Server_GetTourneyPlatform\n");

    if (str == NULL)
	return(-1);

    // skip leading white space
    while (*str == ' ')
	++str;

    memcpy(&platformID, str, sizeof(long));

    if ((platformID != kBoxType_segb) && (platformID != kBoxType_sn07)) {
        PLogmsg(LOGP_FLAW, 
	    "Server_GetTourneyPlatform: '%s' - unknown platform\n", str);
	return(-1);
    }

    return(platformID);
}


int
Server_GetTourneyType(
    char	*str
)
{
    PLogmsg(LOGP_PROGRESS, "Server_GetTourneyType\n");

    if (str == NULL)
	return(-1);

    // skip leading white space
    while (*str == ' ')
	++str;

    if (!strcasecmp(str, kTourneyAutoMatchTag))
	return(kTourneyAutoMatch);
    else if (!strcasecmp(str, kTourneySpecificMatchTag))
	return(kTourneySpecificMatch);

    PLogmsg(LOGP_FLAW, 
	"Server_GetTourneyType: '%s' - unknown tourney type\n", str);

    return(-1);
}


// 
// This function converts a string specifying tournament times
// to UTC. The functions returns -1 upon error.
//
long
Server_GetTourneyTime(
    char	*str
)
{
    int 	conv;
    struct tm	tm;
    long	when;

    PLogmsg(LOGP_PROGRESS, "Server_GetTourneyTime\n");

    if (str == NULL)
	return(-1);

    // skip leading white space
    while (*str == ' ')
	++str;

    // A time is specified as mm/dd/yy=hh:mm
    // mm [1,12], dd [1,31], hh [0,23], mm[0,59]
    //
    memset(&tm, 0, sizeof(struct tm));
    conv = sscanf(str, "%d/%d/%d=%d:%d",
		&tm.tm_mon,
		&tm.tm_mday,
		&tm.tm_year,
		&tm.tm_hour,
		&tm.tm_min);
    if (conv != 5)
	return(-1);

    tm.tm_mon -= 1;                 // months go from 0-11
    when = timelocal(&tm);

    return(when);
}


void
Server_SetTourneyOptional(
    TourneyData	*tourneyData,
    char	*str
)
{
    PLogmsg(LOGP_PROGRESS, "Server_SetTourneyOptional\n");

    if (str == NULL)
	return;

    // skip leading white space
    while (*str == ' ')
	++str;
    
    if (!strcmp(str, kTourneyNoGamePatchTag))
	tourneyData->flags |= kTourneyNoGamePatchFlag;
    else
    if (!strcmp(str, kTourneyNoMatcherTag))
	tourneyData->flags |= kTourneyNoMatcherFlag;
    else
    if (!strcmp(str, kTourneyDeadzoneTag))
	tourneyData->flags |= kTourneyDeadzoneFlag;
    else
	 PLogmsg(LOGP_PROGRESS, "Server_SetTourneyOptional: '%s' unknown\n", str);
}


// 
// This function opens the tournament schedule file and reads in the 
// list of tournaments currently scheduled. The caller is responsible
// for freeing the array of returned schedules.
//
int 
Server_ReadTourneyData(
    char 	*fileName,
    TourneyData	**schedules
)
{
    FILE        	*fp;
    char		buf[512];
    int			numTourneys;
    char		*str;
    char		*ptr;
    TourneyData		entry;
    int			line;

    PLogmsg(LOGP_PROGRESS, "Server_ReadTourneyData\n");

    *schedules  = NULL;
    numTourneys = 0;


    fp = fopen(fileName, "r");
    if (fp == NULL) {
	PLogmsg(LOGP_PROGRESS,
	    "Server_ReadTourneyData: '%s' not found\n",
	    fileName);
	return(0);
    }


    //
    // File Format:
    //	<platformID> <gameID> <start-time> <end-time> <type> <optional>
    //
    line = 0;
    while (fgets(buf, 512, fp) != 0) {
	++line;

        // skip leading white space
	str = buf;
        while (*str == ' ')
	    ++str;

	// skip comments and blank lines
	if ((*str == '#') || (*str == '\n'))
	    continue;

	memset(&entry, 0, sizeof(TourneyData));

	ptr = strtok(str, kWhiteSpace);
	if (!ptr || ((entry.platformID = Server_GetTourneyPlatform(ptr)) == -1)) {
	    PLogmsg(LOGP_FLAW, 
		"Server_ReadTourneyData: line %d - unable to read platformID\n",
		line);
	    continue;
	}

	ptr = strtok(NULL, kWhiteSpace);
	if (!ptr) {
	    PLogmsg(LOGP_FLAW, 
		"Server_ReadTourneyData: line %d - unable to read gameID\n",
		line);
	    continue;
	}
	entry.gameID = strtol(ptr, (char **)NULL, 16);

	ptr = strtok(NULL, kWhiteSpace); 
	if (!ptr || ((entry.startTime = Server_GetTourneyTime(ptr)) == -1)) {
	    PLogmsg(LOGP_FLAW, 
		"Server_ReadTourneyData: line %d - unable to read startTime\n",
		line);
	    continue;
	}

	ptr = strtok(NULL, kWhiteSpace); 
	if (!ptr || ((entry.endTime = Server_GetTourneyTime(ptr)) == -1)) {
	    PLogmsg(LOGP_FLAW, 
		"Server_ReadTourneyData: line %d - unable to read endTime\n",
		line);
	    continue;
	}

	ptr = strtok(NULL, kWhiteSpace); 
	if (!ptr || ((entry.type = Server_GetTourneyType(ptr)) == -1)) {
	    PLogmsg(LOGP_FLAW, 
		"Server_ReadTourneyData: line %d - unable to read tourney type\n",
		line);
	    continue;
	}

	// treat the remainder of the string as containing optional tokens
	ptr = strtok(NULL, kWhiteSpace);
	while (ptr != NULL) {
    	    Server_SetTourneyOptional(&entry, ptr);
	    ptr = strtok(NULL, kWhiteSpace); 
	}

	PLogmsg(LOGP_DETAIL, 
	    "TRNY DATA: [%.4s][%#x][%d][%d][%d][%d]\n",
	    &entry.platformID,
	    entry.gameID,
	    entry.startTime,
	    entry.endTime,
	    entry.type,
	    entry.flags);

	++numTourneys;

	if (*schedules == NULL)
	    *schedules = (TourneyData *)malloc(sizeof(TourneyData));
	else
	    *schedules = (TourneyData *)realloc(*schedules, 
				numTourneys * sizeof(TourneyData));
	    
	(*schedules)[numTourneys - 1] = entry;
    }

    return(numTourneys);
}


// 
// This functions detects if this connection is a tournament connection.
// It returns true if a tourney connection, false if not.
// 
// TODO: call the booth here ?
//
Boolean
Server_IsTourneyConnection(
    ServerState *state,
    TourneyData *tourneyData
)
{
	Err err;
    time_t now;
	TourneySEInfo seinfo;

    PLogmsg(LOGP_PROGRESS, "Server_IsTourneyConnection\n");

    // is this the correct platform ?
    if (tourneyData->platformID != state->boxOSState.boxType)
	return(false);

    // mail only connections dont count during tourneys
    if (state->challengeData.userID.box.box == kDownloadOnlyMailSerialNumber)
	return(false);

    // did the user come in with the right tourney game ?
    if (state->gameIDData.gameID != tourneyData->gameID)
	return(false);

    // is the tournament on at this very moment ?
    now = time(0);
    if ((now < tourneyData->startTime) || (now > tourneyData->endTime))
	return(false);

    switch (tourneyData->type) {
	  case kTourneyAutoMatch:
		/*
		 * If this a "automatch" tourney round, any specific challenge
		 * requests are not tourney connects.
		 */
		return (state->challengeData.userID.box.box
				== kFindNetworkOpponentSerialNumber);
	  case kTourneySpecificMatch:
		err = Server_TourneyGetSEInfo(state->account, &seinfo);
		return (err == kNoError && seinfo.state == kTourneySEState_Play);
	  default:
    	return(false);
    }
}

//
// This function reads the current tournament schedule and determines
// if this box is playing in a tourney on this connect.
// NOTE:
// Currently this function always returns kServerFuncOK. However, for future 
// tournaments if we detect some error condition (eg: user came in on a mail
// connect when he was scheduled to play etc) we may decide to terminate 
// the connection by returning kServerFuncEnd.
Err
Server_InitializeTourneyData(
    ServerState *state
)
{
    TourneyData	*tourneys;
    int		numTourneys;
    int		count;

    PLogmsg(LOGP_PROGRESS, "Server_InitializeTourneyData\n");

    state->tourneyData = NULL;

    numTourneys = Server_ReadTourneyData(gConfig.tourneyDataFile, &tourneys);
    if ((numTourneys <= 0) || (tourneys == NULL))
	return(kServerFuncOK);
    else {
	for(count = 0; count < numTourneys; count++) {
	    if (Server_IsTourneyConnection(state, &tourneys[count]) == true) {
		state->tourneyData = (TourneyData *)malloc(sizeof(TourneyData));
		*(state->tourneyData) = tourneys[count];
		break;
	    }
	}

        if (state->tourneyData) {
            Logmsg("Tourney connection: '%s' [%ld,%ld](%d)\n",
	        state->account->playerAccount.userName,
	        state->account->boxAccount.box.box,
	        state->account->boxAccount.box.region,
	        (int)state->account->playerAccount.player);
        }
    }

    return(kServerFuncOK);
}


/*
 * Fetch the tourney blob from the given account.
 */
int Server_TourneyGetSEInfo(Account *account, TourneySEInfo *seinfo)
{
    Err err;
	u_int ossize = -1;
	OpaqueStore *os = &account->boxAccount.opaqueStore;
	OpaqueStoreValue osv;

	/* make sure it's the right size */
    err = OpqStore_GetValueSize(os, kSingleEliminationTourneyKey, &ossize);
    if (err != kOpqNoError) {
		PLogmsg(LOGP_PROGRESS, "TourneyGetSEInfo: not in tourney\n");
		return err;
	}
	if (ossize != sizeof(*seinfo)) {
		PLogmsg(LOGP_FLAW, "TourneyGetSEInfo: info wrong size (%d vs %d)\n",
				ossize, sizeof(TourneySEInfo));
		return kFucked;
	}

	osv.buf = (char *)seinfo;
	osv.numMaxBytes = osv.numBytes = sizeof(*seinfo);
    err = OpqStore_GetKeyValue(os, kSingleEliminationTourneyKey, &osv);
    if (err != kOpqNoError) {
		PLogmsg(LOGP_FLAW, "TourneyGetSEInfo: opaquestore not there??: %d\n",
				err);
		return err;
	}

	return 0;
}


/*
 * Update the tourney blob in the given account.
 */
int Server_TourneySetSEInfo(Account *account, TourneySEInfo *seinfo)
{
    Err err;
	OpaqueStore *os = &account->boxAccount.opaqueStore;
	OpaqueStoreValue osv;

	osv.buf = (char *)seinfo;
	osv.numMaxBytes = osv.numBytes = sizeof(*seinfo);
    err = OpqStore_SetKeyValue(os, kSingleEliminationTourneyKey, &osv);
    if (err)
		err = OpqStore_NewKeyValue(os, kSingleEliminationTourneyKey, &osv);
    if (err != kOpqNoError) {
		PLogmsg(LOGP_FLAW, "TourneySetSEInfo: couldn't set opaquestore\n");
		return err;
	}

	account->boxModified = kBA_opaqueStore;
	return kNoError;
}



/*
 * If we should play a single-elimination toureny round now,
 * transform the matcher input into a specific challenge against
 * our tourney opponent.  Return 1 if we do so.
 */
int Server_TourneyRedirectChallenge(ServerState *state)
{
    Err err;
	TourneySEInfo seinfo;
	ChallengeData *cd = &state->challengeData;

	err = Server_TourneyGetSEInfo(state->account, &seinfo);
	if (err) {
		PLogmsg(LOGP_PROGRESS, "tourney-redirect: no tourney info\n");
		return 0;
	}
	if (seinfo.state != kTourneySEState_Play) {
		PLogmsg(LOGP_PROGRESS, "tourney-redirect: no tourney round now\n");
		return 0;
	}

	cd->challengeType = kSpecificChallenge;
	cd->userID.box = seinfo.oppbox;
	cd->userID.userID = seinfo.oppplayer;

	PLogmsg(LOGP_NOTICE, "tourney-redirect: "
			"forcing specific-challenge with (%ld,%ld,%d)\n",
			seinfo.oppbox.box, seinfo.oppbox.region, seinfo.oppplayer);

	return 1;
}


/*
 * Store matchup structs in the tourney blob.
 */
void Server_TourneyProcessMatchup(ServerState *state)
{
	int i;
	Err err;
	TourneySEInfo seinfo;

	err = Server_TourneyGetSEInfo(state->account, &seinfo);
	if (err) {
		PLogmsg(LOGP_PROGRESS, "TourneyProcessMatchup: no SEinfo\n");
		return;
	}

	if (seinfo.state != kTourneySEState_Play) {
		PLogmsg(LOGP_PROGRESS,
				"TourneyProcessMatchup: not expecting results");
		return;
	}

	i = seinfo.matchupcount;
	if (i >= kMaxTourneySEMatchups) {
		PLogmsg(LOGP_NOTICE, "TourneyProcessMatchup: too many SEtourney matchups\n");
		return;
	}

	seinfo.matchups[i].time = time(NULL);
	seinfo.matchups[i].matchup = *state->matchup;
	seinfo.matchupcount++;

	err = Server_TourneySetSEInfo(state->account, &seinfo);
	if (err) {
		PLogmsg(LOGP_FLAW, "TourneyProcessMatchup: storing SEinfo failed: %d\n", err);
		return;
	}

	PLogmsg(LOGP_PROGRESS, "TourneyProcessMatchup: stored matchup\n");
}


/*
 * Store game results in the tourney blob.
 * Called from Server_ExamineGameResults() if regurg has tourney bit set.
 * 
 * This is also where we will automatically decide winners someday.
 */
void Server_TourneyProcessGameResults(Account *account,
									 MatchupRegurg *regurg,
									 NewGameResult *result,
									 NewGameResult *eresult)
{
	int i;
	Err err;
	TourneySEInfo seinfo;
	TourneySEResult *res;

	err = Server_TourneyGetSEInfo(account, &seinfo);
	if (err) {
		PLogmsg(LOGP_PROGRESS, "TourneyProcessGameResults: no SEinfo\n");
		return;
	}

	if (seinfo.state != kTourneySEState_Play || seinfo.matchupcount == 0) {
		PLogmsg(LOGP_PROGRESS,
				"TourneyProcessGameResults: not expecting results\n");
		return;
	}

	i = seinfo.resultcount;
	if (i >= kMaxTourneySEResults) {
		PLogmsg(LOGP_NOTICE, "TourneyProcessGameResults: too many SEresults\n");
		return;
	}

	res = &seinfo.results[i];
	res->time = time(NULL);
	res->valid = 0;
	if (regurg) {
		res->regurg = *regurg;
		res->valid |= kTourneySEResult_regurgValid;
	}
	if (result) {
		res->result = *result;
		res->valid |= kTourneySEResult_resultValid;
	}
	if (eresult) {
		res->eresult = *eresult;
		res->valid |= kTourneySEResult_eresultValid;
	}
	seinfo.resultcount++;

	seinfo.state = kTourneySEState_NoDecision;
	PLogmsg(LOGP_NOTICE,
			"TourneyProcessGameResults: changed state to NODECISION\n");

	err = Server_TourneySetSEInfo(account, &seinfo);
	if (err) {
		PLogmsg(LOGP_FLAW, "TourneyProcessGameResults: storing SEinfo failed: %d\n", err);
		return;
	}

	PLogmsg(LOGP_PROGRESS, "TourneyProcessGameResults: stored SEresult\n");
}


/*
 * Decide whether to allow someone in a single-elimination tourney
 * to play right now.
 */
Boolean Server_TourneyDisallowMatch(ServerState *state)
{
	Err err;
	TourneySEInfo seinfo;
	int mailconnect =
		state->challengeData.userID.box.box == kDownloadOnlyMailSerialNumber;

	err = Server_TourneyGetSEInfo(state->account, &seinfo);
	if (err) {
		PLogmsg(LOGP_PROGRESS, "Server_TourneyDisallowMatch: not in tourney\n");
		return false;
	}

	if (state->tourneyData &&
		state->tourneyData->type == kTourneySpecificMatch &&
		state->tourneyData->flags & kTourneyDeadzoneFlag) {
		int waittime;
		char buf[1024];

		waittime = (state->tourneyData->endTime - time(NULL) + 59) / 60;

		sprintf(buf, "Your tournament round does not start "
				"for another %d minute%s.  Wait that long and "
				"challenge again to register for your tournament "
				"game.",  waittime, (waittime == 1) ? "" : "s");

		Server_SendDialog(state, buf, true);
		return true;
	}

	switch (seinfo.state) {
	  case kTourneySEState_NoDecision:
		return !mailconnect;
	  case kTourneySEState_Play:
		if (seinfo.player != state->account->playerAccount.player) {
			Account *account = NULL;
			userIdentification uid;
			char buf[1024];

			uid.box = state->account->boxAccount.box;
			uid.userID = seinfo.player;
			WrapperDB_FindAccount(&uid, &account);

			sprintf(buf, "Another player on your modem (%s) is supposed "
					"to be playing a tournament game now.  Please switch "
					"to that player and challenge again.",
					account ? account->playerAccount.userName :
						"name unavailable");
			Server_SendDialog(state, buf, true);

			if (account) {
				DataBaseUtil_FreeAccount(account);
			}
			return true;
		}

	  default:
		return false;
	}
}


/*
 * Send mail to an SEtourney contestant telling him what his
 * status in the tourney is.
 */
void Server_TourneySendAutoMail(ServerState *state)
{
	Err err;
	TourneySEInfo seinfo;

	err = Server_TourneyGetSEInfo(state->account, &seinfo);
	if (err) {
		PLogmsg(LOGP_PROGRESS, "Server_TourneySendAutoMail: not in tourney\n");
		return;
	}

	if (seinfo.state == kTourneySEState_NoDecision) {
		Server_SendMailFromXBAND(state, "XBAND", "Tournament results",
			"No decision has been reached yet for your most recent "
			"tournament match. Please wait 5 minutes and connect again.", 0);
		Server_SendDialog(state, "Check your X-Mail for info "
						  "regarding your tournament match.", true);
	}
}
