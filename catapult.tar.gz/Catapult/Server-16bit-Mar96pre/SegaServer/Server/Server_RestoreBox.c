/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_RestoreBox.c,v 1.48 1996/02/23 19:52:34 jhsia Exp $
 *
 * $Log: Server_RestoreBox.c,v $
 * Revision 1.48  1996/02/23  19:52:34  jhsia
 * wrapped 2 strings in gettext()
 *
 * Revision 1.47  1996/02/20  17:14:23  ted
 * Do not send box "kOnlyAllowConnectWithSmartCardConst" DBCONSTANT. We decided it
 * was safer to allow the user to connect to the server without a valid smartcard
 * in case we need to update the box with a patch...
 *
 * Revision 1.46  1996/02/12  15:01:08  fadden
 * Use gettext() around kXBANDReplacementStr.
 *
 * Revision 1.45  1996/02/09  22:06:27  jhsia
 * gettext() "Replacement modem?"
 *
 * Revision 1.44  1996/02/05  15:38:54  fadden
 * Make Server_DoRestore return kNoSuchUserAccount if the player account that
 * the player is logging in on doesn't exist.
 *
 * Revision 1.43  1996/02/05  13:23:31  fadden
 * Check return value of SendAllRankings in DoRestorePlayerAccount, then check
 * return value of DoRestorePlayerAccount in DoRestore.  Problem was a flurry
 * of TLayer errors that went undetected.
 *
 * Revision 1.42  1996/02/02  15:43:15  chs
 * use gConfig.catapultTown everywhere.
 *
 * Revision 1.41  1996/01/25  17:51:57  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.40  1996/01/04  22:54:19  hufft
 * added pop mail
 *
 * Revision 1.39  1995/12/15  16:33:08  fadden
 * Changed replacement modem mail message for Japan autocreate (it now matches
 * the USA non-production message).
 *
 * Revision 1.38  1995/11/15  18:48:55  jhsia
 * changed "customer service" to "Customer Support"
 *
 * Revision 1.37  1995/11/13  19:44:39  hufft
 * pop lookup interface changes, rpc returns a list of pops, and dial patterns
 *
 * Revision 1.36  1995/11/13  17:10:32  jhsia
 * changed customer service phone number to be 408-777-1500
 *
 * Revision 1.35  1995/11/08  18:46:53  jhsia
 * Re-enabled box restores by phone number for Japanese locale.  Corrected         several comments about restores in Japan.  Accept locale-specific               responses to replacement modem mail.  Changed it to create new account in       production environment if we're in Japan and auto-creating accounts.            Added Server_SetRandomThings, moved some stuff out of RecvComplete.  Added
 * setting of "only allow connect with smartcard" for sj01 boxes.  Look up
 * POP numbers instead of just restoring them blindly from account.
 *
 * Revision 1.34  1995/10/24  20:03:28  ansell
 * Changed logic so that when we find a matching hwid with a closed account and
 * then find a matching phone number we ask the user if this is a replacement
 * modem rather than return the closed account.
 *
 * Revision 1.33  1995/10/07  15:02:39  roxon
 * Use "vNewMaxInBoxEntries" (8/10 - depending on paltformID) instead of
 * kMaxInBoxEntries (10).
 *
 * Revision 1.32  1995/09/27  18:23:29  hufft
 * added Common_Phone_Code
 *
 * Revision 1.31  1995/09/13  14:24:42  ted
 * Fixed warnings.
 *
 * Revision 1.30  1995/09/11  15:36:58  chs
 * Made Server_DBIsValid() non-static.
 *
 * Revision 1.29  1995/08/26  11:07:23  roxon
 * Replace Common_PhoneLocale with LOCALE_PHONE_xxx.
 *
 * Revision 1.28  1995/08/24  19:26:39  rich
 * Don't do box restores by phone number in Japan.
 *
 * Revision 1.27  1995/07/25  23:04:31  ted
 * Added RestoreModemStuff routines which download call waiting dbconstant to
 * SNES for now.
 *
 * Revision 1.26  1995/07/10  21:07:46  rich
 * Added Japanese SNES platform (kPlatformSJNES).
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.25  1995/07/10  11:41:09  ted
 * Server_SendSetLocalAccessPhoneNumber takes one less argument now.
 *
 * Revision 1.24  1995/07/07  20:52:14  fadden
 * Move MiscSettings routines out to MiscPrefs.c.  Move most of the useful
 * stuff from Server_BoxSentValidHWID into Common_IsValidHWID.
 *
 * Revision 1.23  1995/07/04  22:51:57  fadden
 * Changed Common_CompareHardwareID calls.
 *
 * Revision 1.22  1995/06/19  20:42:23  fadden
 * Many changes, mostly surrounding addition of HardwareID support for SNES.
 * - Wrote Server_FindRestoreByHWID.
 * - Added code to maintain hwid in account.
 * - Added account lookup to validate "valid" serials.
 * - Implemented sending of mail to verify that a modem is meant to
 *   replace an earlier one.
 * - Added marking box DB valid immediately after restore.
 * - Enabled credit check before restore.
 * - Added Server_SyncWithBox.
 *
 * Revision 1.21  1995/06/03  19:45:08  fadden
 * Now using struct HardwareID in ServerState.  Moved the SNES simulator
 * check over to Server_ReceiveLogin.c.
 *
 * Revision 1.20  1995/06/01  15:07:01  fadden
 * Merge in from newbr.
 * -> Complete rewrite.
 *
 * Revision 1.19  1995/05/26  23:46:54  jhsia
 * switch to rcs keywords
 *
 * Revision 1.18.2.5  1995/05/31  17:20:36  fadden
 * Don't try to nuke the current player.  Added notes about the current
 * player's icon and NukePlayer.
 *
 * Revision 1.18.2.4  1995/05/27  00:16:10  fadden
 * Added a bunch of stuff to check for SNES sim by hwid.
 *
 * Revision 1.18.2.3  1995/05/26  18:06:02  fadden
 * Lots of code shuffling.  Added more detail to RestoreMiscSettings.
 *
 * Revision 1.18.2.2  1995/05/24  01:19:14  fadden
 * Changed some logmsgs around.  Don't check credit status before restore.
 *
 * Revision 1.18.2.1  1995/05/22  03:22:04  fadden
 * Total rewrite.
 * First cut at new restore stuff; needs much testing and some features.
 *
 */

/*
	File:		Server_RestoreBox.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<40>	11/30/94	DJ		Can now handle a replacementModem.
		<39>	11/29/94	DJ		Cleaned up some comments in the code.
		<38>	11/17/94	KD		Updated more dialog box wording (doug/kon).
		<37>	11/17/94	KD		Updated dialog box wording (doug/kon).
		<36>	11/15/94	DJ		Farting around with allowing new boxes in.... NOT!
		<35>	11/13/94	ATM		Shift the pretty phone stuff down.
		<34>	11/12/94	DJ		Just some debugging.
		<33>	 11/9/94	DJ		Fixed bug in checking crashrec execCode.
		<32>	 11/9/94	DJ		Renamed some DB routines to DataBaseUtil_ and also to WrapperDB_
									(for Oracle).
		<31>	 11/8/94	DJ		Don't be setting connect800 to true, you idiot!
		<30>	 11/8/94	DJ		Checking if crashrecord is from a game crash not O/S crash.
		<29>	 11/8/94	DJ		If boxid == -2 -2 then force restorebyphonenumber.  this is
									triggered by validatelogin if 2 boxes share an account.
		<28>	 11/7/94	DJ		Added Server_SendPasswordEraseCode.
		<27>	 11/7/94	ATM		Added Server_SendAllRankings to list of stuff to do.
		<26>	 11/7/94	DJ		If no account matching boxnum, then try restore by phonenumber.
		<25>	 11/2/94	DJ		Removed extraneous GetHIddenSerialNums
		<24>	10/26/94	DJ		Server_DoRestore sets the boxserialnum before checking for
									credits.
		<23>	10/26/94	DJ		Added Server_SendAddressBook.
		<22>	10/24/94	DJ		Call Server_CheckAccountCredits before doing a restore.
		<21>	10/22/94	ATM		Let Server_SendDialog() do the log messages.
		<20>	10/20/94	DJ		More tweaks to see if boxIDs are ok.
		<19>	10/20/94	DJ		Added "dialog" in caps comment on same line as server dialogs
									(useful for greping).
		<18>	10/20/94	DJ		Added Andy's treatly hack to try and scavenge a valid boxID from
									the coldBoxID and hiddenSerialNum.1
		<17>	10/19/94	DJ		DoRestore calls Server_ValidateInitialSystemPatch.
		<16>	10/17/94	DJ		DoRestore increments boxAccount-> numberOfBoxCrashes and also
									clears the bindLostModem flag in userAccount if it is set.
		<15>	10/17/94	DJ		Just cleaned up some stuff.
		<14>	10/17/94	DJ		Don't compare against hiddenserialnumber 2, because it is buggy
									on the box.  #1 is ok though.
		<13>	10/14/94	DJ		Changed a printf.
		<12>	10/14/94	DJ		Fixed bug in GetHIddenSerials
		<11>	10/14/94	DJ		Added print of hidden serial numbers.
		<10>	10/14/94	DJ		Setting boxRestored to true.
		 <9>	10/13/94	DJ		Fixed something.
		 <8>	10/13/94	DJ		Trouncing on news debug[2] that stores the date of last news.
									This forces news to be sent when restoring.
		 <7>	10/13/94	DJ		Searching by phone number, restoring Personification info.
		 <6>	10/12/94	DJ		Trying to restore if you lose your OS or DB.  Trying to get
									hidden serial numbers too.
		 <5>	 9/19/94	ATM		PLogmsg stuff.
		 <4>	 9/16/94	ATM		boxFlags->boxModified, playerFlags->playerModified,
									acceptChallenges->playerFlags.
		 <3>	  9/9/94	DJ		added comments and pseudocode about what this routine should do
		 <2>	 8/27/94	ATM		De-cheesed.
		 <1>	 8/21/94	DJ		first checked in

	To Do:
*/

#include <stdio.h>
#include <memory.h>
#include <stdlib.h>
#include <strings.h>
#include <time.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/time.h>

#include "Server.h"
#include "ServerDataBase.h"
#include "Server_Pop.h"
#include "Server_Personification.h"

#include "Common.h"
#include "Common_Log.h"
#include "Common_ReadConf.h"
#include "Common_PlatformID.h"
#include "Common_Missing.h"

#include "SegaTypes.h"
#include "DBConstants.h"
#include "SNESHardwareID.h"

Boolean Server_IsRestoreNecessary(ServerState *state);
Err Server_RestoreAccount(ServerState *state, BoxSerialNumber *boxp);

//
// Prototypes
//
PRIVATE Boolean Server_BoxidIsValid(ServerState *state);
PRIVATE Boolean Server_sega_DBIsValid(ServerState *state);
PRIVATE Boolean Server_snes_DBIsValid(ServerState *state);
PRIVATE Boolean Server_any_DBIsValid(ServerState *state);
PRIVATE Err Server_sega_MarkBoxDBValid(ServerState *state);
PRIVATE Err Server_snes_MarkBoxDBValid(ServerState *state);
PRIVATE Err Server_any_MarkBoxDBValid(ServerState *state);
//
PRIVATE Err Server_FindAccountToRestore(ServerState *state, BoxSerialNumber *boxp);
PRIVATE Err Server_FindRestoreByHWID(ServerState *state, BoxSerialNumber *boxp);
PRIVATE Boolean Server_GetCallerPhone(ServerState *state, phoneNumber *phnump);
PRIVATE Err Server_ForceRedial800(ServerState *state);
PRIVATE Boolean Server_ScroungeHiddenSerials(ServerState *state, BoxSerialNumber *boxp);
PRIVATE Boolean Server_sega_ScroungeHiddenSerials(ServerState *state, BoxSerialNumber *boxp);
PRIVATE Boolean Server_snes_ScroungeHiddenSerials(ServerState *state, BoxSerialNumber *boxp);
PRIVATE Boolean Server_any_ScroungeHiddenSerials(ServerState *state, BoxSerialNumber *boxp);
PRIVATE Boolean Server_BoxLooksNew(ServerState *state);
PRIVATE Boolean Server_sega_BoxLooksNew(ServerState *state);
PRIVATE Boolean Server_snes_BoxLooksNew(ServerState *state);
PRIVATE Boolean Server_any_BoxLooksNew(ServerState *state);
//
PRIVATE Err Server_ValidateReplacementAccount(ServerState *state, BoxSerialNumber *boxp);
PRIVATE Err Server_SendReplValidationReq(ServerState *state, const char *fromName);
PRIVATE int Server_CheckReplacementReply(ServerState *state, const Mail *mail, const char *fromName);
//
PRIVATE Err Server_DoRestore(ServerState *state, BoxSerialNumber *boxp);
PRIVATE Err Server_NukePlayer(ServerState *state, int boxidWasValid, int dbWasValid);
PRIVATE Err Server_DoRestoreBoxAccount(ServerState *state, Account *account);
PRIVATE Err Server_DoRestorePlayerAccount(ServerState *state, Account *account, char playerNum);
//
PRIVATE Err Server_sega_RestoreModemStuff(ServerState *state, Account *account);
PRIVATE Err Server_snes_RestoreModemStuff(ServerState *state, Account *account);
PRIVATE Err Server_any_RestoreModemStuff(ServerState *state, Account *account);
//
PRIVATE Err Server_sn07_SetRandomThings(ServerState *state, Account *account);
PRIVATE Err Server_sjne_SetRandomThings(ServerState *state, Account *account);


//#define TESTING_BOX_RESTORE
#ifdef TESTING_BOX_RESTORE
PRIVATE int Server_TestCRR(ServerState *state);
#endif



// ===========================================================================
//		Determine if a restore is needed
// ===========================================================================

//
// Determine whether or not a restore needs to be done, based on the
// status of the box.
//
// Figuring out whether or not the database got trashed is done in a
// platform-dependent manner.
//
Boolean
Server_IsRestoreNecessary(ServerState *state)
{
	PLogmsg(LOGP_PROGRESS, "BR: Server_IsRestoreNecessary\n");

#ifdef TESTING_BOX_RESTORE
	Server_TestCRR(state);
#endif

	if (state->platformID == kPlatformIntel) {
		PLogmsg(LOGP_NOTICE, "BR: NOTE: will not attempt restore on '%.4s'\n",
			(char *)&state->platformID);
		return (false);
	}

	if (!Server_DBIsValid(state) || !Server_BoxidIsValid(state)) {
		PLogmsg(LOGP_DBUG, "BR: restore needed\n");
		return (true);
	}

	PLogmsg(LOGP_DBUG, "BR: restore not needed\n");
	return (false);
}


//
// Figure out if the caller's BoxIDs are valid.
//
PRIVATE Boolean
Server_BoxidIsValid(ServerState *state)
{
	userIdentification	*userID;

	PLogmsg(LOGP_PROGRESS, "BR: Server_BoxidIsValid\n");

	userID = &state->loginData.userID;

	// This is the usual case for a fully crashed box.
	//
	if (userID->box.box == -1 && userID->box.region == -1) {
		PLogmsg(LOGP_DBUG, "BR: boxIDs are -1,-1, invalid\n");
		return (false);
	}

	// This shouldn't happen.
	//
	if (userID->box.box <= 0 || userID->box.region <= 0) {
		PLogmsg(LOGP_NOTICE, "BR: boxIDs are weird (%ld,%ld), invalid\n",
			userID->box.box, userID->box.region);
		return (false);
	}

	PLogmsg(LOGP_DBUG, "BR: boxIDs are valid\n");
	return (true);
}


//
// Figure out if the caller's DB is valid.
//
Boolean
Server_DBIsValid(ServerState *state)
{
	SubDispatcher subDisp[] = {
		{ kPlatformGenesis,	kPlatformGenesisMask,	(INT_FUNC_PTR) Server_sega_DBIsValid },
		{ kPlatformSNES,	kPlatformSNESMask,		(INT_FUNC_PTR) Server_snes_DBIsValid },
		{ kPlatformSJNES,	kPlatformSJNESMask,		(INT_FUNC_PTR) Server_snes_DBIsValid },
		{ kPlatformAny,		0,						(INT_FUNC_PTR) Server_any_DBIsValid },
		{ 0,				0,						NULL },		// doink!
	};

	return ( (Boolean)(Common_SubDispatch(state->boxOSState.boxType, subDisp))(
		state) );
}

PRIVATE Boolean
Server_sega_DBIsValid(ServerState *state)
{
	PLogmsg(LOGP_PROGRESS, "BR: Server_sega_DBIsValid\n");

	if (state->NGPVersion <= 1) {
		PLogmsg(LOGP_DBUG, "BR: sega: NGPVersion=%d, DB invalid\n",
			state->NGPVersion);
		return (false);
	}

	return (true);
}

PRIVATE Boolean
Server_snes_DBIsValid(ServerState *state)
{
	unsigned long stable;
	
	PLogmsg(LOGP_PROGRESS, "BR: Server_snes_DBIsValid\n");

	stable = state->boxOSState.osFree >> 16;
	if (!stable) {
		PLogmsg(LOGP_DBUG, "BR: snes: JoshIsStable=%d, DB invalid\n", stable);
		return (false);
	}

	return (true);
}

PRIVATE Boolean
Server_any_DBIsValid(ServerState *state)
{
	PLogmsg(LOGP_PROGRESS, "BR: Server_any_DBIsValid\n");

	// There's no way to tell if the DB is trashed, since we don't know
	// what we're dealing with.  Assume it's fine.
	//
	PLogmsg(LOGP_NOTICE, "NOTE: Server_any_DBIsValid on '%.4s'\n",
		(char *)&state->platformID);
	return (true);
}


//
// Mark the box's DB as valid, so we don't try to restore it again.
//
// Whatever this does should parallel what the "DBIsValid" routine does
// to determine whether or not the box DB is valid.  This calls DBIsValid
// first to make sure we don't waste time doing it twice.
//
Err
Server_MarkBoxDBValid(ServerState *state)
{
	SubDispatcher subDisp[] = {
		{ kPlatformGenesis,	kPlatformGenesisMask,	(INT_FUNC_PTR) Server_sega_MarkBoxDBValid },
		{ kPlatformSNES,	kPlatformSNESMask,		(INT_FUNC_PTR) Server_snes_MarkBoxDBValid },
		{ kPlatformSJNES,	kPlatformSJNESMask,		(INT_FUNC_PTR) Server_snes_MarkBoxDBValid },
		{ kPlatformAny,		0,						(INT_FUNC_PTR) Server_any_MarkBoxDBValid },
		{ 0,				0,						NULL },		// voink!
	};

	if (Server_DBIsValid(state)) {
		// DB is valid, don't hit it again.
		//
		PLogmsg(LOGP_PROGRESS, "BR: Server_MarkBoxDBValid: DB already valid\n");
		return (kNoError);
	}

	return ( (Err)(Common_SubDispatch(state->boxOSState.boxType, subDisp))(
		state) );
}

PRIVATE Err
Server_sega_MarkBoxDBValid(ServerState *state)
{
	static unsigned char magic[] = {	// magic NGP list junk (big-endian)
		msNewNGPList,
		0, 40,		// size of below
			0, 2,		// 0-based count (== 3)
			0, 2,		// version # (must be > 1!)
			0xab,0x63,0x48,0xe9,
			0, 0, 0, 0,
			0, 0, 0, 1,
			0xe3,0x0c,0x29,0x6e,
			0, 0, 0, 0,
			0, 0, 0, 1,
			0x39,0x67,0x7b,0xdb,
			0, 0, 0, 0,
			0, 0, 0, 1,
		0, 6,		// size of below
			0x2a, 0,
			0x2a, 0,
			0x2a, 0
	};

	PLogmsg(LOGP_PROGRESS, "BR: Server_sega_MarkBoxDBValid\n");

	// Send them a temporary fake NGP list.
	//
	// Not sending the full NGP list now, since someday we may want to patch
	// that out to avoid sending all the extra junk that goes down, and at
	// this point we haven't sent the system patch yet.
	//
	// This NGP list is equivalent to the one in the ROM (except it doesn't
	// have the names, which we don't use until after a server connect has
	// completed anyway), and we only send it down if they don't already
	// have a better one.
	//
	// (Probably ought to steal a DBConstant instead... this is annoying.)
	//
	Server_TWriteDataSync(state->session, sizeof(magic), (Ptr)magic);
	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	state->NGPVersion = 2;		// once only please

	PLogmsg(LOGP_PROGRESS, "BR: temporary NGP sent [%d bytes]\n",
		sizeof(magic));
	return (kNoError);
}

PRIVATE Err
Server_snes_MarkBoxDBValid(ServerState *state)
{
	DBID	id = kServerBlessedDatabaseConst;
	unsigned long stable;

	PLogmsg(LOGP_PROGRESS, "BR: Server_snes_MarkBoxDBValid\n");

	// The "stable" flag should be zero, or we wouldn't be here.
	//
	stable = state->boxOSState.osFree >> 16;
	if (stable < 65535)
		stable++;
	PLogmsg(LOGP_DBUG, "BR: Sending JoshIsStable(%d)\n", stable);
	Server_SendDBConstants(state, 1, &id, &stable);

	return (kNoError);
}

PRIVATE Err
Server_any_MarkBoxDBValid(ServerState *state)
{
	PLogmsg(LOGP_PROGRESS, "BR: Server_any_MarkBoxDBValid\n");

	// (do nothing)

	return (kNoError);
}



// ===========================================================================
//		Find account to restore from
// ===========================================================================

//
// Find the account to restore from.
//
// Basic philosophy: valid box serials are best, hardwareID is a close
// second (only because hwid requires a DB lookup), ANI is dead last.
// Hidden serials are a somewhat iffy proposition at best.
//
// Fascinating facts: no hardwareID on existing Genesis boxes, but no ANI
// will be available in Japan.  Replacement box strategy in Japan will
// have to use the number entered by the individual if the hardwareID
// match fails.
//
PRIVATE Err
Server_FindAccountToRestore(ServerState *state, BoxSerialNumber *boxp)
{
	Account 	*tmpAccount = NULL;
	userIdentification	*userID, tmpUserID;
	phoneNumber	phnum;
	Err			err;

	PLogmsg(LOGP_PROGRESS, "BR: Server_FindAccountToRestore\n");

	// Init return value.  They should already be this way; if not, we
	// shouldn't be here.
	//
	boxp->box = -1;
	boxp->region = -1;

	// Figure out if the box passed up something useful.
	//
	userID = &state->loginData.userID;
	if (userID->box.box != -1 && userID->box.region != -1) {
		// Hey, this is easy.
		//
		*boxp = userID->box;
		PLogmsg(LOGP_DBUG, "BR: using box's IDs (%ld,%ld)\n", boxp->box,
			boxp->region);

		// Catch somebody switching from a test server (i.e. one with
		// a different region).
		//
		// (This is probably unnecessary now that we look up the box account
		// below.)
		//
		if (userID->box.region != gConfig.happyRegion) {
			Logmsg("BR: Region not happy, resetting state->boxID to (-1,-1)\n");
			userID->box.box = -1;
			userID->box.region = -1;
			goto continue_onward;	// skip account lookup
		} else {
			return (kNoError);
		}

		// Look up the account now.  Sort of a waste since it's an extra
		// database call, but there are some things we really want to know
		// right now:
		//
		//	- are the serial numbers valid (i.e. does an account exist for
		//	  them on this server)?  If not, we need to restore by hwid
		//	  or phone number (probably a switch from a test server).
		//	- does the hardwareID on the box match what's in the account?
		//	  If not, we need to use hwid or phone number.  (This prevents
		//	  us from having to restore the account twice if the HWID doesn't
		//	  match.)
		//
		// (We could try to hang onto this until we get to the actual restore
		// code, but all we really want here is a copy of the box account.)
		//
		tmpUserID.box = userID->box;
		tmpUserID.userID = 0;
		// (foo, should use FindAccountBySerial here)
		err = WrapperDB_NewFindAccount(&tmpUserID, &tmpAccount);
		if (err == kNoError) {
			// Found it, so serials are good.  Check the hardwareID (if any).
			// Note we're not guaranteed to have a valid playerAccount.
			//
			if (!Server_BoxSentValidHWID(state)) {
				// No HWID, nothing to check.
				//
				DataBaseUtil_FreeAccount(tmpAccount);
				return (kNoError);
			}
			if (Common_CompareHardwareID(&tmpAccount->boxAccount.hardwareID,
				&state->loginData.hardwareID) == 0)
			{
				// Matching HWID, yay.
				//
				DataBaseUtil_FreeAccount(tmpAccount);
				return (kNoError);
			}

			// Failed.  Fall through to alternative methods.
			//
			Logmsg("BR: account found but HWID doesn't match:\n");
			Logmsg("BR: Box    : ");
			Common_LogHardwareID(&state->loginData.hardwareID);
			Logmsg("BR: Account: ");
			Common_LogHardwareID(&state->account->boxAccount.hardwareID);

			DataBaseUtil_FreeAccount(tmpAccount);

		} else {
			// Account wasn't found, box serials are garbage.  Reset local
			// copy of serials and keep going.
			//
			Logmsg("BR: account (%ld,%ld) not found, resetting state->boxID)\n",
				userID->box.box, userID->box.region);
			userID->box.box = -1;
			userID->box.region = -1;
		}
continue_onward:		// only jump here if region numbers mismatched above
	}

	// Check for rental card serial numbers.  The rental cards act like
	// a removable hardwareID; they override everything else if they exist.
	//
	// (do me)

	// Check for hardwareID.
	//
	if (Server_BoxSentValidHWID(state)) {
		PLogmsg(LOGP_DBUG, "BR: valid hardwareID info found (type %d)\n",
			state->loginData.hardwareID.hardwareIDtype);

		// Lots to do here.
		//
		return (Server_FindRestoreByHWID(state, boxp));
	}

	// Try to scrounge serials out of "hidden" serials, crash records,
	// whatever.
	//
	if (Server_ScroungeHiddenSerials(state, boxp)) {
		PLogmsg(LOGP_DBUG, "BR: successful scrounge, returning (%ld,%ld)\n",
			boxp->box, boxp->region);
		// (should we look up acct here to validate serials?)
		return (kNoError);
	}

	// No luck, do the lookup by phone number.  Remember that we won't get
	// here at all if the box posted a valid hardwareID, so for 'snes' and
	// 'sjne' boxes we should be done.
	//
	// (Note that the hardwareID code falls back on restores by phone
	// number under certain circumstances, like replacement modem detection,
	// so stopping now won't kill restore-by-phone.)
	//
	// We can get here if the hardwareID is hosed or if the user is dialing
	// in with a simulator.
	//
	if (LOCALE_PHONE_JA()) {
		//return (kNoSuchBoxAccount);
		PLogmsg(LOGP_NOTICE, "NOTE: doing restore by phone in ja locale\n");
	}

	if (!Server_GetCallerPhone(state, &phnum)) {
		// Phone number not available, because this isn't an ANI call.  Force
		// them to redial 1-800 by zeroing out their POP number.
		//
		Logmsg("BR: forcing 1-800 redial\n");
		return (Server_ForceRedial800(state));
	}
	PLogmsg(LOGP_DBUG, "BR: box calling from '%s'\n", phnum.phoneNumber);

	if (Server_BoxLooksNew(state)) {
		// Either a brand-new modem or a replacement modem.  Want to give
		// priority to those two cases.
		//
		//	(1) replacment
		//	(2) new
		//	(3) any used
		//
		// (Will also get here if we're transferring from a server with
		// a different region number.)
		//
		if (WrapperDB_FindSerialByPhone(&phnum, kPhoneLookupReplacement,
			state->platformID, boxp) == kNoError)
		{
			PLogmsg(LOGP_DBUG, "BR: found phone/new/replacement\n");
			return (kReplacementAccount);
		}
		if (WrapperDB_FindSerialByPhone(&phnum, kPhoneLookupNew,
			state->platformID, boxp) == kNoError)
		{
			PLogmsg(LOGP_DBUG, "BR: found phone/new/new\n");
			return (kNewAccount);
		}
		if (WrapperDB_FindSerialByPhone(&phnum, kPhoneLookupAnyUsed,
			state->platformID, boxp) == kNoError)
		{
			PLogmsg(LOGP_DBUG, "BR: found phone/new/anyused\n");
			return (kNoError);
		}
		PLogmsg(LOGP_DBUG, "BR: phone not found (pri=new)\n");
		return (kNoSuchBoxAccount);

	} else {
		// Just a crashed modem.  Could be old or new.
		//
		//	(1) replacment
		//	(2) any used account that's not closed
		//	(3) new
		//	(4) any used (which can only be a closed account)
		//
		if (WrapperDB_FindSerialByPhone(&phnum, kPhoneLookupReplacement,
			state->platformID, boxp) == kNoError)
		{
			PLogmsg(LOGP_DBUG, "BR: found phone/any/replacement\n");
			return (kReplacementAccount);
		}
		if (WrapperDB_FindSerialByPhone(&phnum, kPhoneLookupAnyOpenUsed,
			state->platformID, boxp) == kNoError)
		{
			PLogmsg(LOGP_DBUG, "BR: found phone/any/anyopenused\n");
			return (kNoError);
		}
		if (WrapperDB_FindSerialByPhone(&phnum, kPhoneLookupNew,
			state->platformID, boxp) == kNoError)
		{
			PLogmsg(LOGP_DBUG, "BR: found phone/any/new\n");
			return (kNewAccount);
		}
		if (WrapperDB_FindSerialByPhone(&phnum, kPhoneLookupAnyUsed,
			state->platformID, boxp) == kNoError)
		{
			PLogmsg(LOGP_DBUG, "BR: found phone/any/anyused\n");
			return (kNoError);
		}
		PLogmsg(LOGP_DBUG, "BR: phone not found (pri=any)\n");
		return (kNoSuchBoxAccount);
	}

	/*NOTREACHED*/
}


//
// Find the account to restore by doing a lookup by hardwareID.
//
// Reverts to a lookup by phone if the box's hwid isn't found.
//
PRIVATE Err
Server_FindRestoreByHWID(ServerState *state, BoxSerialNumber *boxp)
{
	BoxSerialNumber	newBox;
	phoneNumber		phnum;
	Account			*tmpAccount;
	Err				err, okErr;
	long			statusFlags;

	if ((err = WrapperDB_FindSerialByHWID(&state->loginData.hardwareID,
		state->platformID, boxp)) == kNoError)
	{
		// Possibilities:
		//	- Active account returned.  This should be the usual case.
		//	  Return kNoError.
		//
		//	- New account returned.  Can't happen in USA (no hwid in unused
		//	  accounts) or Japan.  Return kNewAccount.
		//
		//	- Closed account returned.  Could be that a new account was
		//	  later opened for them, or somebody was de-incesting and
		//	  erased the hwid from their current account, so we found a
		//	  much older account.  So:
		//	  - Look for a new account by phone.  Return kNewAcct if found.
		//	  - Look for a used account by phone.  If the account doesn't
		//	    have a hwid in it, return kNoError.  Otherwise, since
		//	    the hwid can't match unless the hwid lookup is broken,
		//	    return the closed account.
		//
		// (All this is if the lookup *succeeds*.  See below for what happens
		// when the lookup by hwid *fails*.)
		//

		// Get the account so we can take a look at the status.
		//
		err = WrapperDB_FindAccountBySerial(boxp,
			state->loginData.userID.userID, &statusFlags, &tmpAccount);

		if (tmpAccount == NULL || err == kNoSuchBoxAccount) {
			// Very weird, box serials returned by hwid search are invalid.
			// This should be impossible.
			//
			PLogmsg(LOGP_FLAW,
				"BR: GLITCH: hwid 2nd search failed (%ld/%ld/0x%.8lx)\n",
				err, statusFlags, tmpAccount);
			if (tmpAccount != NULL) {
				DataBaseUtil_FreeAccount(tmpAccount);
				tmpAccount = NULL;
			}
			return (kServerFuncAbort);
		}

		// Don't need account, just statusFlags, so free it now.
		//
		DataBaseUtil_FreeAccount(tmpAccount);
		tmpAccount = NULL;

		if (statusFlags & kFindAccountStatusNew) {
			// CEJ only.
			//
			Logmsg("BR: hwid 2nd: found new account with hwid!\n");
			return (kNewAccount);
		}
		if (statusFlags & kFindAccountStatusClosed) {
			// Rats, only found a closed one.
			//
			Logmsg("BR: hwid 2nd: found closed account, probing by phone\n");
			if (!Server_GetCallerPhone(state, &phnum)) {
				Logmsg("BR: hwid 2nd: forcing 1-800 redial\n");
				return (Server_ForceRedial800(state));
			}
			PLogmsg(LOGP_DBUG, "BR: hwid 2nd: box calling from '%s'\n",
				phnum.phoneNumber);

			okErr = kFucked;

			// Try phone lookups, putting the serials found into newBox.
			// "okErr" gets the value that we'll return if the newBox
			// serials are what we really want to use.
			//
			if (WrapperDB_FindSerialByPhone(&phnum, kPhoneLookupNew,
				state->platformID, &newBox) == kNoError)
			{
				PLogmsg(LOGP_DBUG, "BR: found phone/hwid2nd/new\n");
				okErr = kNewAccount;
			} else
			if (WrapperDB_FindSerialByPhone(&phnum, kPhoneLookupAnyOpenUsed,
				state->platformID, &newBox) == kNoError)
			{
				PLogmsg(LOGP_DBUG, "BR: found phone/hwid2nd/anyopenused\n");
				okErr = kNoError;
				// (Why not kReplacementModem?  Well, we're going to be
				// restoring to an account that either has no hwid or has
				// a matching hwid, so either way it looks like the way has
				// been paved to make this a replacement... just go ahead
				// and do it.  Not entirely convinced this is correct. :-(  )
			}

			if (okErr == kFucked) {
				// No match by phone, return original (closed) account.
				//
				Logmsg("BR: hwid 2nd: no secondary match, returning (%ld,%ld)\n",
					boxp->box, boxp->region);
				return (kNoError);
			}
			if (boxp->box == newBox.box && boxp->region == newBox.region) {
				// Lookup by phone found the same closed account?  This isn't
				// possible.
				//
				PLogmsg(LOGP_FLAW,
					"BR: hwid 2nd: GLITCH: same account found (%ld,%ld)\n",
					boxp->box, boxp->region);
				return (kNoError);
			}

			// Found a match, make sure there's either no hwid in the
			// account or what's there matches what we've got (the latter
			// case would be very surprising unless it's a new account and
			// we have some sort of tell-hwid-to-UCA-when-registering thing).
			//
			// Yes, another account lookup.
			//
			err = WrapperDB_FindAccountBySerial(&newBox,
				state->loginData.userID.userID, &statusFlags, &tmpAccount);
			if (tmpAccount == NULL || err == kNoSuchBoxAccount) {
				// Very weird, box serials returned by phone search are
				// invalid.  This should be impossible.
				//
				PLogmsg(LOGP_FLAW,
					"BR: GLITCH: hwid 3rd search failed (%ld/%ld/0x%.8lx)\n",
					err, statusFlags, tmpAccount);
				if (tmpAccount != NULL) {
					DataBaseUtil_FreeAccount(tmpAccount);
					tmpAccount = NULL;
				}
				return (kServerFuncAbort);
			}
			if (tmpAccount->boxAccount.hardwareID.hardwareIDtype == kHWID_NoHWID)
			{
				// Found account has no hwid, yay.
				//
				*boxp = newBox;
				PLogmsg(LOGP_DBUG,
					"BR: hwid 2nd: no hwid in acct, using (%ld,%ld) (%d)\n",
					boxp->box, boxp->region, okErr);
				return (okErr);
			} else if (Common_CompareHardwareID(
				&tmpAccount->boxAccount.hardwareID,
				&state->loginData.hardwareID) == 0)
			{
				// Found hwid matches.  Weird.
				//
				*boxp = newBox;
				PLogmsg(LOGP_DBUG,
					"BR: hwid 2nd: hwid in acct matches, using (%ld,%ld) (%d)\n",
					boxp->box, boxp->region, okErr);
				return (okErr);
			} else {
				// Account has hwid, doesn't match, assume replacement modem.
				// (We get here if the replacement modem is a modem that
				// used to be owned by somebody else, but was returned
				// because they weren't happy with it or something.)
				//
				*boxp = newBox;
				PLogmsg(LOGP_DBUG,
					"BR: hwid 2nd: hwid in found != current, replacement modem?\n");
				return (kReplacementAccount);
			}
			/*NOTREACHED*/
		}

		// Otherwise, we've got a normal, non-closed account.
		//
		Logmsg("BR: hardwareID lookup found (%ld,%ld)\n", boxp->box,
			boxp->region);
		return (kNoError);
	}

	// HardwareID lookup failed.  This must be a new box or a replacement
	// modem (or somehow we just failed to write the hardwareID info
	// out last time around).
	//
	if (!Server_GetCallerPhone(state, &phnum)) {
		// Phone number not available, because this isn't an ANI call.
		// Force them to redial 1-800 by zeroing out their POP number.
		//
		Logmsg("BR: forcing 1-800 redial (no hwid match)\n");
		return (Server_ForceRedial800(state));
	}
	PLogmsg(LOGP_DBUG, "BR: box calling from '%s' (no hwid match)\n",
		phnum.phoneNumber);

	// Either a brand-new modem or a replacement modem.  Want to give
	// priority to those two cases.  Could also be the case that customer
	// service wiped the hardwareID out of the account in an attempt to
	// de-incest some modems, in which case asking if it's a replacement
	// doesn't entirely make sense, but isn't a bad thing.
	//
	//	(1) replacment
	//	(2) new
	//	(3) any used
	//
	if (WrapperDB_FindSerialByPhone(&phnum, kPhoneLookupReplacement,
		state->platformID, boxp) == kNoError)
	{
		PLogmsg(LOGP_DBUG, "BR: found phone/nohwid/replacement\n");
		return (kReplacementAccount);
	}
	if (WrapperDB_FindSerialByPhone(&phnum, kPhoneLookupNew,
		state->platformID, boxp) == kNoError)
	{
		PLogmsg(LOGP_DBUG, "BR: found phone/nohwid/new\n");
		return (kNewAccount);
	}
	if (WrapperDB_FindSerialByPhone(&phnum, kPhoneLookupAnyUsed,
		state->platformID, boxp) == kNoError)
	{
		PLogmsg(LOGP_DBUG, "BR: found phone/nohwid/anyused\n");
		return (kReplacementAccount);	// yes, kReplacementAccount
	}

	// No hardwareID match, no phone match, they must not have an
	// account.
	//
	PLogmsg(LOGP_DBUG, "BR: phone not found (pri=nohwid)\n");
	return (kNoSuchBoxAccount);
}


//
// Determine the caller's phone number.
//
// Three possibilities here:
//	- this is a post-800 connect, so we have the 10-digit info from ANI
//	- the caller showed up with an 11-digit number (hack for simulators)
//	- the caller showed up with a 7-digit (well, 8-digit) number, so we
//	  need to force him to redial on the 800 number.
//
// Returns true if the full number is available (e.g. 10 digits in USA),
// false if not.
//
PRIVATE Boolean
Server_GetCallerPhone(ServerState *state, phoneNumber *phnump)
{
	SuperPhone	phone;
	Err			err;

	PLogmsg(LOGP_PROGRESS, "BR: Server_GetCallerPhone\n");
	if ((err = Common_PhoneParseDefault(state->boxPhoneNumber.phoneNumber, &phone)) == kNoError)
	{
		if (phone.npa_len)
		{
			strcpy(phnump->phoneNumber, phone.p.phoneNumber);
			return(true);
		}
		return(false);
	}
	PLogmsg(LOGP_FLAW, "BR: strange ph num '%s' in GetCallerPhone:err:%d\n",
		state->boxPhoneNumber.phoneNumber, err);
	return(false);
	/*NOTREACHED*/
}


//
// Force the box (which has presumably dialed in on X.25) to call back via
// 1-800.  Should never be called in Japan.
//
// Always returns kServerFuncEnd.
//
PRIVATE Err
Server_ForceRedial800(ServerState *state)
{
	phoneNumber pop;

	PLogmsg(LOGP_PROGRESS, "BR: Server_ForceRedial800\n");

	if (LOCALE_PHONE_JA() && !gConfig.ustest) {
		PLogmsg(LOGP_FLAW,
			"ERROR: Server_ForceRedial800 called in JA locale\n");
		return (kServerFuncAbort);
	}

	memset(&pop, 0, sizeof(phoneNumber));
	Server_SendSetLocalAccessPhoneNumber(state, &pop, &pop, true);
	state->abandonShip = true;

	// I18N Appears:  When player's modem has "crashed".  XBAND will
	//           try and restore your account information (players, 
	//           rankings, and player list).
	// Solution: This does happen occasionally.  If it continually
	//           happens it could be possible that the battery in 
	//           the player's modem is dead.  UCA should file an 
	//           escalation report to Catapult for Catapult to investigate 
	//           why the  modem is crashing frequently.
	//
	Server_SendDialog(state,
		gettext("XBAND is trying to recover your Account Info."),	/*DIALOG*/
		false);
	return (kServerFuncEnd);
}


//
// Try to scrounge the serials out of "alternative" locations, like the
// hidden serials or crash records.  Sort of risky, but probably more
// accurate than guessing by phone number (less chance of incest).  Will
// return false if the hidden serials don't match the happy region.
//
// This is platform-specific, mainly because the second set of hidden
// serials is worthless on the Genesis unless the box has been patched.
//
// Returns true if the serials were scrounged, false if not.
//
PRIVATE Boolean
Server_ScroungeHiddenSerials(ServerState *state, BoxSerialNumber *boxp)
{
	SubDispatcher subDisp[] = {
		{ kPlatformGenesis,	kPlatformGenesisMask,	(INT_FUNC_PTR) Server_sega_ScroungeHiddenSerials },
		{ kPlatformSNES,	kPlatformSNESMask,		(INT_FUNC_PTR) Server_snes_ScroungeHiddenSerials },
		{ kPlatformSJNES,	kPlatformSJNESMask,		(INT_FUNC_PTR) Server_snes_ScroungeHiddenSerials },
		{ kPlatformAny,		0,						(INT_FUNC_PTR) Server_any_ScroungeHiddenSerials },
		{ 0,				0,						NULL },		// koink!
	};

	return ( (Boolean)(Common_SubDispatch(state->boxOSState.boxType, subDisp))(
		state, boxp) );
}

PRIVATE Boolean
Server_sega_ScroungeHiddenSerials(ServerState *state, BoxSerialNumber *boxp)
{
	PLogmsg(LOGP_PROGRESS, "BR: Server_sega_ScroungeHiddenSerials\n");

#ifdef DO_SEGA_SCROUNGE
	PLogmsg(LOGP_DBUG,
		"BR: scrounge: cr=0x%.8lx, hidden1=(%ld,%ld), hidden2=(%ld,%ld)\n",
		state->crashRecord,
		state->niftyInfo.any.hidden1.box, state->niftyInfo.any.hidden1.region,
		state->niftyInfo.any.hidden2.box, state->niftyInfo.any.hidden2.region);

	// For Genesis, use the *first* set of hidden serials if:
	//	- box serials are (-1,-1)
	//	- 1st set of hidden serials are NOT (-1,-1)
	//	- a crash record exists
	//	- crash record warm serials are (-1,-1)
	//	- crash record cold serials match 1st set of hidden serials
	//
	if (!state->crashRecord)
		return (false);
	if ( (state->loginData.userID.box.box != -1 ||
		  state->loginData.userID.box.region != -1) ||	// valid box OR
		 (state->niftyInfo.any.hidden1.box <= 0 ||
		  state->niftyInfo.any.hidden1.region <= 0) ||	// invalid hidden OR
		 (state->crashRecord->warmBoxID.box != -1 ||
		  state->crashRecord->warmBoxID.region != -1)	// valid warm OR
	   )
	{
		return (false);									// fail & bail
	}

	if ((state->niftyInfo.any.hidden1.box !=
			state->crashRecord->coldBoxID.box) &&
		(state->niftyInfo.any.hidden1.region !=
			state->crashRecord->coldBoxID.region))
	{
		return (false);
	}

	// Sanity check.
	//
	if (state->niftyInfo.any.hidden1.box <= 0 ||
		state->niftyInfo.any.hidden1.region <= 0 ||
		state->niftyInfo.any.hidden1.region != gConfig.happyRegion)
	{
		PLogmsg(LOGP_DBUG, "BR: scrounge passed all but sanity check\n");
		return (false);
	}

	// All conditions met, use these.
	//
	*boxp = state->niftyInfo.any.hidden1;
	PLogmsg(LOGP_DBUG, "BR: scrounged (%ld,%ld) out of hidden\n",
		state->niftyInfo.any.hidden1.box,
		state->niftyInfo.any.hidden1.region);

	return (true);
#else
	PLogmsg(LOGP_DBUG, "BR: sega scrounge disabled\n");
	return (false);
#endif	/*DO_SEGA_SCROUNGE*/
}

PRIVATE Boolean
Server_snes_ScroungeHiddenSerials(ServerState *state, BoxSerialNumber *boxp)
{
	PLogmsg(LOGP_PROGRESS, "BR: Server_snes_ScroungeHiddenSerials\n");

#ifdef DO_SNES_SCROUNGE
	PLogmsg(LOGP_DBUG,
		"BR: scrounge: cr=0x%.8lx, hidden1=(%ld,%ld), hidden2=(%ld,%ld)\n",
		state->crashRecord,
		state->niftyInfo.any.hidden1.box, state->niftyInfo.any.hidden1.region,
		state->niftyInfo.any.hidden2.box, state->niftyInfo.any.hidden2.region);

	// For SNES, use the hidden serials if they match and are sane.
	//
	if ((state->niftyInfo.any.hidden1.box ==
			state->niftyInfo.any.hidden2.box) &&
		(state->niftyInfo.any.hidden1.region ==
			state->niftyInfo.any.hidden2.region) &&
		(state->niftyInfo.any.hidden1.box > 0) &&
		(state->niftyInfo.any.hidden2.region > 0) &&
		(state->niftyInfo.any.hidden2.region == gConfig.happyRegion))
	{
		PLogmsg(LOGP_DBUG, "BR: scrounged (%ld,%ld) out of hidden\n",
			state->niftyInfo.any.hidden1.box,
			state->niftyInfo.any.hidden1.region);
		*boxp = state->niftyInfo.any.hidden1;
		return (true);
	}
	return (false);
#else
	PLogmsg(LOGP_DBUG, "BR: snes scrounge disabled\n");
	return (false);
#endif	/*DO_SNES_SCROUNGE*/
}

PRIVATE Boolean
Server_any_ScroungeHiddenSerials(ServerState *state, BoxSerialNumber *boxp)
{
	PLogmsg(LOGP_PROGRESS, "BR: Server_any_ScroungeHiddenSerials\n");

	// Unknown platform, no idea how to scrounge.
	//
	return (false);
}


//
// Determine if the box looks like a new one.
//
// This is dependent on how it's manufactured.  At the moment, a box showing
// (-1,-1) serials with no crash record is a new box.
//
PRIVATE Boolean
Server_BoxLooksNew(ServerState *state)
{
	SubDispatcher subDisp[] = {
		{ kPlatformGenesis,	kPlatformGenesisMask,	(INT_FUNC_PTR) Server_sega_BoxLooksNew },
		{ kPlatformSNES,	kPlatformSNESMask,		(INT_FUNC_PTR) Server_snes_BoxLooksNew },
		{ kPlatformSJNES,	kPlatformSJNESMask,		(INT_FUNC_PTR) Server_snes_BoxLooksNew },
		{ kPlatformAny,		0,						(INT_FUNC_PTR) Server_any_BoxLooksNew },
		{ 0,				0,						NULL },		// foink!
	};

	return ( (Boolean)(Common_SubDispatch(state->boxOSState.boxType, subDisp))(
		state) );
}

PRIVATE Boolean
Server_sega_BoxLooksNew(ServerState *state)
{
	BoxSerialNumber *boxp;

	PLogmsg(LOGP_PROGRESS, "BR: Server_sega_BoxLooksNew\n");

	boxp = &state->loginData.userID.box;

	if (boxp->box != -1 || boxp->region != -1)
		return (false);
	if (state->crashRecord != NULL)
		return (false);
	return (true);
}

PRIVATE Boolean
Server_snes_BoxLooksNew(ServerState *state)
{
	BoxSerialNumber *boxp;

	PLogmsg(LOGP_PROGRESS, "BR: Server_snes_BoxLooksNew\n");

	boxp = &state->loginData.userID.box;

	if (boxp->box != -1 || boxp->region != -1)
		return (false);
	if (state->crashRecord != NULL)
		return (false);
	return (false);
}

PRIVATE Boolean
Server_any_BoxLooksNew(ServerState *state)
{
	PLogmsg(LOGP_PROGRESS, "BR: Server_any_BoxLooksNew\n");

	// Unknown platforms never look new.  Safest path is to not make any
	// assumptions; assuming it's not new is best.
	//
	return (false);
}



// ===========================================================================
//		Prepare to do the restore
// ===========================================================================

//
// Restore the account.
//
// If *boxp is (-1,-1), this uses the information uploaded by the box to
// try to figure out which account to restore from.  If *boxp is a valid
// box serial number, that account will be used.
//
// NOTE: don't pass in a pointer to state->loginData.userID.box for boxp.
// They'll get stepped in before the code below has a chance to examine them.
//
Err
Server_RestoreAccount(ServerState *state, BoxSerialNumber *boxp)
{
	Err findErr, replErr, restErr;

	PLogmsg(LOGP_PROGRESS, "BR: Server_RestoreAccount (%ld,%ld) --------\n",
		boxp->box, boxp->region);

	// If *boxp is (-1,-1), go find the account to restore from.
	//
	if (boxp->box == -1 && boxp->region == -1) {
		findErr = Server_FindAccountToRestore(state, boxp);
		if (findErr == kNoError) {
			// Great.  Fall through to restore.

		} else if (findErr == kReplacementAccount) {
			// This will be a replacement account; make sure we actually
			// want to put it here.
			//
			replErr = Server_ValidateReplacementAccount(state, boxp);
			if (replErr != kNoError) {
				PLogmsg(LOGP_DBUG, "BR: repl validate failed, returning %d\n",
					replErr);
				return (replErr);
			}
			// Fall through to restore.

		} else {
			// Something went sour.  Could be a "happy" failure (we determined
			// that this is a brand-new user, so we need to do an account
			// create rather than a restore), or an "unhappy" failure (we
			// can't find the guy's account).  Whatever it is, return it.
			//
			PLogmsg(LOGP_DBUG, "BR: RestoreAccount returning %d\n", findErr);
			return (findErr);
		}
	}

	// Now we've got the account to restore in *boxp.  Call DoRestore to
	// do the actual restore.
	//
	PLogmsg(LOGP_DBUG, "BR: restore will be on account (%ld,%ld)\n",
		boxp->box, boxp->region);
	restErr = Server_DoRestore(state, boxp);

	PLogmsg(LOGP_PROGRESS,
		"BR: Server_RestoreAccount done (ret=%d) --------\n", restErr);
	return (restErr);
}


#define kReplReplyToOther		-2
#define kReplReplyGarbage		-1
#define kReplReplyNegative		0
#define kReplReplyAffirmative	1
#define kXBANDReplacementStr	"XBAND.Replacement"
//
// We've found a replacement modem (i.e. the account had the "replacement
// modem" bit set).
//
// Verify that this modem is the one that will replace the previous one.
// Try to match up the player name of the player logging in... if it matches,
// great.  If not, send mail asking if this is the replacement modem for
// the account.
//
// Returns kNoError if this is the correct account, kReplacementAccount if
// we're not sure and want the server to exit gracefully after our dialogs
// and mail messages get posted.
//
// On a non-production server, this will return kNoSuchBoxAccount if the
// user wants to create a new account.
//
// This should NOT require translation for CEJ, since the whole "is this a
// replacement modem" issue shouldn't exist.
//
PRIVATE Err
Server_ValidateReplacementAccount(ServerState *state, BoxSerialNumber *boxp)
{
	const char *replFrom = gettext(kXBANDReplacementStr);
	Account	*account;
	Boolean	requireMail = false;
	Mail	*mail;
	long	statusFlags;
	Err		err;
	int		i, reply;

	PLogmsg(LOGP_PROGRESS, "BR: Server_ValidateReplacementAccount\n");

	// Try to look up the playerAccount to get the user name.
	//
	err = WrapperDB_FindAccountBySerial(boxp, state->loginData.userID.userID,
		&statusFlags, &account);
	if (account == NULL || err != kNoError) {
		requireMail = true;
		Logmsg("BR: unable to lookup repl account (err %d)\n", err);
		if (account != NULL) {
			DataBaseUtil_FreeAccount(account);
			account = NULL;
		}
	}
	PLogmsg(LOGP_DETAIL, "BR: Checking modem as replacement for (%ld,%ld)\n",
		boxp->box, boxp->region);

	// If we successfully found the account, figure out if the login name
	// matches.
	//
	if (account != NULL) {
		if (DataBaseUtil_CompareStrings(state->loginData.userID.userName,
			account->playerAccount.userName) == 0)
		{
			Logmsg("BR: user names match, accepting as replacement\n");
			DataBaseUtil_FreeAccount(account);
			return (kNoError);		// replace immediately
		} else {
			requireMail = true;
		}
	}
	if (account != NULL) {
		DataBaseUtil_FreeAccount(account);
		account = NULL;
	}


	// We need a mail message confirming that this is or isn't a replacement
	// account ("isn't" is really only useful for test servers).
	//
	// See if he sent one up.  Stop when we find the first one.
	//
	reply = kReplReplyToOther;
	for (i = 0; i < state->incomingMail.count; i++) {
		mail = state->incomingMail.mailItems[i].mail;
		if ((reply = Server_CheckReplacementReply(state, mail, replFrom)) >= 0)
		{
			break;
		}
	}

	if (reply == kReplReplyAffirmative) {
		// Affirmative response, go ahead with restore.
		//
		Logmsg("BR: ReplacementReply affirmative\n");
		return (kNoError);
	} else if (reply == kReplReplyNegative) {
		// Negative response.  On non-production servers, create a new
		// account.  On production servers, they have to call UCA to
		// straighten things out.  Unless we're in japan and creating
		// accounts automatically, in which case we want to create a new
		// account for them, which could possibly cause somebody to get
		// disconnected from their previous account.  Mumble.
		//
		Logmsg("BR: ReplacementReply negative\n");
		if (!gConfig.isProduction ||
			(LOCALE_PHONE_JA() && gConfig.jaAutoCreateAccount))
		{
			return (kNoSuchBoxAccount);		// create new one
		} else {
			Server_SendDialog(state,
				gettext("Please call XBAND Customer Support at 408-777-1500."),	/*DIALOG*/
				true);
			return (kServerFuncEnd);
		}
	} else if (reply == kReplReplyGarbage) {
		// Garbage response.  They replied to it, but we couldn't figure it
		// out.  Yell at them, then send the message again in case they
		// lost it.
		//
		messOut		opCode;
		long		controlFlags;
		char		msgbuf[256];

		sprintf(msgbuf,
			gettext("We couldn't understand your mail to %s.  Please put \"yes\" or \"no\" in the body of the message."),
			gettext(kXBANDReplacementStr));
		Server_SendDialog(state, msgbuf, true);

		// Nuke their incoming mail queue so we don't get the same
		// hosed reply every time.
		//
		Logmsg("BR: Zapping incoming mail\n");
		opCode = msServerMiscControl;
		Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
		controlFlags = kDeleteAllAoutBoxMailFlag;
		Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&controlFlags);
	} else if (reply == kReplReplyToOther) {
		// Reply hazy, try again later.  Most likely this is simply the first
		// time they've connected, and they're getting the mail for the first
		// time.
		//
		// (nothing to do)
	} else {
		// Whoops.
		//
		PLogmsg(LOGP_FLAW, "BR: GLITCH: bizarre reply %d to CheckReplReply\n",
			reply);
		return (kServerFuncAbort);
	}


	// Send the mail message to the user.
	//
	// Whether this fails or succeeds, we're still going to exit.
	// kReplacementAccount and kServerFuncEnd yield identical results.
	//
	Server_SendReplValidationReq(state, replFrom);

	return (kReplacementAccount);	// exit nicely
}


#define kMaxReplWordLen	16
//
// Determine whether or not the mail message is a valid response to the
// replacement modem query.
//
// Return values are -2 if the reply isn't meant for us, -1 if the reply is
// for us but isn't comprehensible, 0 if the reply is in the negative,
// and 1 if it's in the affirmative.
//
// (Some analogy about a shack comes to mind... hmm.)
//
PRIVATE int
Server_CheckReplacementReply(ServerState *state, const Mail *mail,
	const char *fromName)
{
	static char *affirmative[] = {	// "local-yes" gets replaced by gettext
		"local-yes", "yes", "\"yes\"", "yup", "yeah", "okay" };
	static char *negative[] = {		// "local-no" gets replaced by gettext
		"local-no", "no", "\"no\"", "nope", "dont", "don't" };
	const char	*cp;
	char	*dp, buf[kMaxReplWordLen];
	int		i;

	// See if it's from the right place.
	//
	if (DataBaseUtil_CompareStrings(mail->to.userName, fromName) != 0)
		return (kReplReplyToOther);

	// Grab at most 15 chars from the first word once we've eaten
	// any leading whitespace.  Strip off trailing punctuation.
	//
	memset(buf, 0, kMaxReplWordLen);
	dp = buf;
	for (i = 0,cp = mail->message; (i < kMaxReplWordLen-1) && (*cp); cp++)
	{
		if (*cp == ' ') {
			if (dp != buf)	// are we copying chars?
				break;		// yup, end of word, break;
			else
				continue;	// nothing but spaces yet, cont
		}
		if (!isalpha(*cp) && *cp != '\"' && *cp != '\'')
			break;			// I brake for punctuation

		*dp++ = *cp;
		i++;
	}
	*dp = '\0';

	affirmative[0] = gettext("yes");
	negative[0] = gettext("no");
	for (i = 0; i < NELEM(affirmative); i++) {
		if (strcasecmp((char *)affirmative[i], buf) == 0)
			return (kReplReplyAffirmative);
	}
	for (i = 0; i < NELEM(negative); i++) {
		if (strcasecmp((char *)negative[i], buf) == 0)
			return (kReplReplyNegative);
	}

	PLogmsg(LOGP_DBUG,
		"BR: CheckReplacementReply: no match on '%s' (from '%s')\n",
		buf, mail->message);
	return (kReplReplyGarbage);
}

#ifdef TESTING_BOX_RESTORE
PRIVATE int
Server_TestCRR(ServerState *state)
{
	static const char *tests[] = {
		// affirmative
			"yes", "\"yes\"", "yup", "okay", "yes!", "yes, please", "YES",
			"     yup!  ",
		// negative
			"no", "nope", "dont", "don't", "no.", "NoPe", "\"no\"",
		// not comprehensible
			"yyyyyyyyyyyyyyyyyyyy",
			"                    ",
			"y          es",
			"nodontdothat", "negatory",
			"!no!",
	};
	Mail	mm;
	int		i, reply;

	PLogmsg(LOGP_PROGRESS, "BR: Server_TestCRR\n");

	strcpy(mm.to.userName, "XBAND.Testing");
	for (i = 0; i < NELEM(tests); i++) {
		strcpy(mm.message, tests[i]);
		reply = Server_CheckReplacementReply(state, &mm, "XBAND.Testing");
		Logmsg("BR: Test %d <-- '%s'\n", reply, tests[i]);
	}

	return (kNoError);
}
#endif	/*TESTING_BOX_RESTORE*/


#define kMaxMailMessageSize	512
//
// Send the replacement modem validation request to the user.
//
// Returns kNoError if the message was sent successfully, kFucked otherwise
// (could be a network error or just not enough room in the mailbox to hold
// another message).
//
PRIVATE Err
Server_SendReplValidationReq(ServerState *state, const char *fromName)
{
	userIdentification catapult = { {-1, 0}, 0, 0, kXBANDPlayerIcon};
	phoneNumber	phn;
	Mail		*mail = NULL;
	char		msgBuf[256];
	messOut		opCode;
	short 		numMails;

	strcpy(catapult.userTown, gConfig.catapultTown);
	PLogmsg(LOGP_PROGRESS, "BR: Server_SendReplValidationReq\n");

	// Check the #of messages on the box to be sure there's room for the
	// message.  Shouldn't normally be a problem since we're doing a box
	// restore now.
	//
//
#define vNewMaxInBoxEntries ((state->platformID == kPlatformSJNES)?8:10)
//
	if (state->loginData.numMailsInBox >= vNewMaxInBoxEntries) {
//
#undef vNewMaxInBoxEntries
//
		Server_SendDialog(state,
			gettext("You have important mail from XBAND, please make room in your mailbox!"),	/*DIALOG*/
			true);
		return (kFucked);
	}

	sprintf(msgBuf, 
		gettext("This looks like a replacement modem, but we're not sure. Please read and reply to the X-Mail from %s."),	/*DIALOG*/
		fromName);
	Server_SendDialog(state, msgBuf, true);


	if ((mail = (Mail *)malloc(sizeof(Mail) + kMaxMailMessageSize)) == NULL) {
		PLogmsg(LOGP_FLAW, "BR: ERROR: malloc (%d) failed in ReplValidReq\n",
			sizeof(Mail) + kMaxMailMessageSize);
		Common_Abort();
	}

	// Make the phone number look nice.
	//
	{
		SuperPhone	phone;

		phn = state->boxPhoneNumber;
		Common_PhoneParseDefault(state->boxPhoneNumber.phoneNumber, &phone);
		if (phone.npa_len && (LOCALE_PHONE_C() || gConfig.ustest))
		{
			// Strip dashes out, copy the bottom 7 digits to make the dialog
			// like nicer.
			//
			strcpy(phn.phoneNumber, phone.p.phoneNumber + phone.npa_len);
		}
	}
	Common_PhoneFormatDisplay(phn.phoneNumber, phn.phoneNumber);

	// Send down the mail message.  If the server is non-production, or
	// it's production AND we're in Japan AND we're in auto-create mode,
	// responding with "no" will get them a new account.
	//
	if (gConfig.isProduction) {
		if (LOCALE_PHONE_JA() && gConfig.jaAutoCreateAccount) {
			// (note this message is identical to the one after next)
			sprintf(mail->message,
				gettext("This modem looks like a replacement for another at this number (%s). If this is the case, reply to this message with the word \"yes\". Otherwise, respond with \"no\"."),	/*DIALOG - mail*/
				phn.phoneNumber);
		} else {
			sprintf(mail->message,
				gettext("This modem looks like a replacement for another at this number (%s). If this is the case, reply to this message with the word \"yes\". Otherwise, call Customer Support at 408-777-1500."),	/*DIALOG - mail*/
				phn.phoneNumber);
		}
	} else {
		sprintf(mail->message,
			gettext("This modem looks like a replacement for another at this number (%s). If this is the case, reply to this message with the word \"yes\". Otherwise, respond with \"no\"."),	/*DIALOG - mail*/
			phn.phoneNumber);
	}

	mail->from = catapult;
	strcpy(mail->from.userName, fromName);
	mail->to.userName[0] = '\0';
	mail->to.box = state->loginData.userID.box;
	mail->to.userID = state->loginData.userID.userID;
	strcpy(mail->title, gettext("Replacement modem?"));
	mail->date = Server_GetSegaDate();
	
	// Send the mail.
	//
	opCode = msReceiveMail;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	numMails = 1;
	Server_TWriteDataSync(state->session, sizeof(short), (Ptr)&numMails);
	Server_SendMailBody(state, mail);

	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	free(mail);
	return (kNoError);
}



// ===========================================================================
//		Do the restore
// ===========================================================================

//
// It all comes down to this.
//
// Find the account data, verify that the account isn't closed, and then
// start shoveling the data.
//
PRIVATE Err
Server_DoRestore(ServerState *state, BoxSerialNumber *boxp)
{
	userIdentification userID;
	Boolean	boxidWasValid=false, dbWasValid=false, currentPlayerNew=false;
	Account	*account;
	Err		err;
	int		i, first;

	PLogmsg(LOGP_PROGRESS, "BR: Server_DoRestore\n");

	// Figure out if the boxID and DB are valid, so we can nuke them if
	// necessary.
	//
	boxidWasValid = Server_BoxidIsValid(state);
	dbWasValid = Server_DBIsValid(state);
	if (boxidWasValid || dbWasValid) {
		PLogmsg(LOGP_DBUG, "BR: boxidWasValid=%d, dbWasValid=%d\n",
			boxidWasValid, dbWasValid);
	}

	// Send the initial system patch if necessary.  This fixes things like
	// bugs in the transport layer.
	//
	Server_ValidateInitialSystemPatch(state);

	// Try to find all 4 player accounts.  Restore any that are found.
	//
	userID.box = *boxp;
	userID.userName[0] = '\0';
	for (first = 1, i = 0; i < 4; i++) {
		userID.userID = i;
		if ((err = WrapperDB_FindAccount(&userID, &account)) == kNoError) {
			// Found one.  If it's the first we've found, twiddle bits
			// in the BoxAccount.
			//
			PLogmsg(LOGP_DBUG, "BR: restore on (%ld,%ld)[%d]\n",
				boxp->box, boxp->region, i);
			Server_SendSetCurrentUserNumber(state, (unsigned char) i);

			if (first) {
				first = 0;
				if ((err = Server_DoRestoreBoxAccount(state, account))
					!= kNoError)
				{
					// Most likely event is a closed/suspended/zero-credit
					// account.
					//
					PLogmsg(LOGP_PROGRESS,
						"BR: Server_DoRestore bailing after box acct (%d)\n",
						err);
					return (err);
				}
			}

			// If this is the account of the current user, copy the account
			// userName into the login userName.
			//
			// Attempting to override the uploaded icon won't work; it
			// gets received in Server_Personification.c.  It's up to that
			// code to avoid overwriting the account's icon with the new
			// personfication stuff.
			//
			if (state->loginData.userID.userID == i) {
				strcpy(state->loginData.userID.userName,
					account->playerAccount.userName);
			}

			if (Server_DoRestorePlayerAccount(state, account, i) != kServerFuncOK)
			{
				PLogmsg(LOGP_FLAW,
					"DoRestorePlayerAccount failed, DoRestore bailing\n");
				return (kServerFuncAbort);
			}
		} else {
			PLogmsg(LOGP_PROGRESS, "BR: FindAccount (%ld,%ld)[%d] err=%d\n",
				boxp->box, boxp->region, i, err);

			// If it returned kNoSuchBoxAccount instead of kNoSuchUserAccount,
			// there isn't even a box account there.  This should only be
			// possible if the box was programmed with hosed boxIDs or the
			// database actually lost the data.
			//
			// Since we KNOW that the boxIDs are invalid, we want to reset
			// them to (-1,-1).  We may want to try a restore by phone
			// number, but that could leave us in an infinite loop if the
			// database is tweaked.
			//
			if (err == kNoSuchBoxAccount) {
				BoxSerialNumber m1b;
				phoneNumber pop;

				PLogmsg(LOGP_FLAW, "BR: No such box (%ld,%ld), account lost?\n",
					boxp->box, boxp->region);

				// This resets the boxIDs to (-1,-1) and nukes the POP
				// number, but does NOT cause an immediate redial.  The next
				// time they show up they'll do a restore by phone, which
				// may or may not land them right back here again.
				//
				m1b.box = m1b.region = -1;
				Server_SendNewBoxSerialNumber(state, &m1b);
				Server_SendSetLocalAccessPhoneNumber(state, &pop, &pop, false);

				Server_SendDialog(state,
					gettext("XBAND is having trouble getting your Account Info. Please try again later."),	/*DIALOG*/
					true);		// not quite true
				return (kServerFuncEnd);
			}

			// Shouldn't be anybody in this slot, so nuke them off the box.
			// This could have adverse side effects if they set up two
			// players, crash, then log in with one the server hasn't seen...
			// we may not want to do this at all.
			//
			// At any rate, don't nuke the player currently logging in!
			// If they don't exist, we need to return kNoSuchUserAccount
			// so that (way back in GetAccount) we will create the player
			// account instead of assuming that it exists.
			//
			// (This is useful when de-incesting a box.)
			//
			if (state->loginData.userID.userID != i) {
				if ((err = Server_NukePlayer(state, boxidWasValid, dbWasValid))
					!= kNoError)
				{
					return (err);
				}
			} else {
				currentPlayerNew = true;
			}
		}
	}
	if (first) {
		// Didn't find any users to restore!  Most likely probability is
		// that the guy SIGHUPed partway through the initial connection
		// (or the database lost all 4 player accounts).  Either way,
		// best bet is to create a new player account on the existing
		// box account... no data left to recover.
		//
		PLogmsg(LOGP_NOTICE, "BR: found NO player accounts on (%ld,%ld)!\n",
			boxp->box, boxp->region);
		return (kNewAccount);
	}

	// Change the current user back to the actual current user.
	//
	Server_SendSetCurrentUserNumber(state, state->loginData.userID.userID);

	// Give 'em the good news.
	//
	Server_SendDialog(state,
		// Appears: When XBAND has restored the player's account 
		//          information after the modem has crashed.
		//
		gettext("XBAND has restored your Account Info."),	/* DIALOG */
		false);
	state->boxRestored = true;


	PLogmsg(LOGP_PROGRESS, "BR: Server_DoRestore COMPLETE%s\n",
		currentPlayerNew ? " (new)" : "");
	if (currentPlayerNew)
		return (kNoSuchUserAccount);
	else
		return (kNoError);
}


//
// We're doing a restore on a box that has a live database or boxIDs.  We
// want to nuke the stuff that exists on players that aren't in the account
// in case this is a de-incestization.
//
// The box's "current player" setting should already be set.  (We may
// need to pass the player num in anyway... depends on implementation.)
//
// This could hose somebody who has set up a player but never logged in
// with it.  We may not want to do this... hmm.
//
// ----- josh says:
// No, there's no simple way of doing it. You'd have to send appropriate
// messages to kill all their DB items (address book, rankings, taunt, mail,
// etc.), and also their player ID itself - there's a particular icon number
// that tells the Chooseplayer.c code that the account needs to be created
// (actually, it just gets a code name and an icon)
//
// Also, it'll be tricky discovering all the player-specific stuff that's in
// things like DB constants (intertwined with other people's). Yum yum.
// -----
//
PRIVATE Err
Server_NukePlayer(ServerState *state, int boxidWasValid, int dbWasValid)
{
	PLogmsg(LOGP_PROGRESS, "BR: Server_NukePlayer\n");

	Logmsg("BR: NukePlayer not implemented\n");		// do me

	return (kNoError);
}


//
// Modify stuff in state according to the contents of the BoxAccount, and
// modify the BoxAccount to reflect the fact that we're doing a restore.
//
PRIVATE Err
Server_DoRestoreBoxAccount(ServerState *state, Account *account)
{
	Err err;

	PLogmsg(LOGP_PROGRESS, "BR: Server_DoRestoreBoxAccount\n");
	ASSERT(account);

	if (account->boxAccount.platformID != state->platformID) {
		PLogmsg(LOGP_FLAW, "GLITCH: restoring '%.4s' box to '%.4s' account\n",
			(char *)&state->platformID,(char *)&account->boxAccount.platformID);
		// (now what?)
	}

	// Whether we check credits or not, we do NOT want to restore an
	// account that's closed.  At the end of the connect (either in
	// ValidateLogin or CheckAccountCredits, depending on what's where
	// these days) we're going to set the serials to (-1,-1), which will
	// cause yet another restore on the next connect.
	//
	// It turns out the cleanest way to go about this is to just call
	// CheckAccountCredits (it sends the appropriate dialogs, etc).
	//
#define CHECK_CREDITS_BEFORE_RESTORE
#ifdef CHECK_CREDITS_BEFORE_RESTORE
	// Do some cheese in order to check that the account is open and has
	// credits.
	//
	if (!state->account) {
		state->account = account;
		account = NULL;
		// Set flag so Server_ValidateCreditStuff won't complain
		//
		state->validFlags |= kServerValidFlag_Account;
	}

	// Check credits.
	//
	if ((err = Server_CheckAccountCredits(state)) != kServerFuncOK)
		return (err);

	// Put it back.
	//
	if (!account) {
		account = state->account;
		state->account = NULL;
		state->validFlags &= ~kServerValidFlag_Account;
	}
#endif	/*CHECK_CREDITS_BEFORE_RESTORE*/


	// Send the box its serial number.
	//
	Server_SendNewBoxSerialNumber(state, &account->boxAccount.box);

	// On the Genesis, set the news "last sent" date to zero, since any sort
	// of crash would have nuked the news.  Not necessary on SNES, which
	// keeps the versions in the box DB.
	//
	// (950522: this probably isn't necessary)
	//
	if (state->platformID == kPlatformGenesis) {
		account->boxAccount.debug[2] = 0;
		account->boxModified |= kBA_debug;
	}
	
	// Update some interesting counters.
	//
	account->boxAccount.numberOfBoxCrashes++;
	account->boxAccount.dateOfLastBoxCrash = time(0);
	account->boxModified |= kBA_crashes;
	
	// Clear magic flags for finding replacement modems and so on.
	//
	if (account->boxAccount.csUpdatedFlags & kCSUpdatedFlag_BindLostModem) {
		account->boxAccount.csUpdatedFlags &= ~kCSUpdatedFlag_BindLostModem;
		account->boxModified |= kBA_csUpdatedFlags;
	}

	if (account->boxAccount.csUpdatedFlags & kCSUpdatedFlag_ReplacementModem) {
		account->boxAccount.csUpdatedFlags &= ~kCSUpdatedFlag_ReplacementModem;
		account->boxModified |= kBA_csUpdatedFlags;
	}
	
	// If the hardwareIDs don't match, we want to stuff the current hwid
	// into the account (the restore code wouldn't have restored from a
	// mismatched hwid unless it was treating the new box as a replacement
	// for the old).
	//
	// If we don't update it now, ValidateHardwareID is going to go nuts
	// and throw us into a loop.  If the account doesn't have a hwid, we
	// don't need to do anything (handled later).  If the account DOES have
	// a hwid and we don't, we're probably just logging in with a simulator
	// on our regular account, so leave the hwid alone.
	//
	// Rotate the existing hardwareID into prevHardwareID, so we know what
	// it is we just did.
	//
	if ((Common_IsValidHWID(&state->loginData.hardwareID)) &&
		(account->boxAccount.hardwareID.hardwareIDtype != kHWID_NoHWID) &&
		(Common_CompareHardwareID(&state->loginData.hardwareID,
			&account->boxAccount.hardwareID) != 0))
	{
		PLogmsg(LOGP_NOTICE, "REPLACING old hwid with new on (%ld,%ld)\n",
			account->boxAccount.box.box, account->boxAccount.box.region);
		Logmsg("OLD: ");
		Common_LogHardwareID(&account->boxAccount.hardwareID);
		Logmsg("NEW: ");
		Common_LogHardwareID(&state->loginData.hardwareID);

		account->boxAccount.prevHardwareID = account->boxAccount.hardwareID;
		account->boxAccount.hardwareID = state->loginData.hardwareID;
		account->boxModified |= kBA_hardwareID;
	}

	// Save changes to our DB.
	//
	if ((err = WrapperDB_UpdateAccount(account)) != kNoError) {
		PLogmsg(LOGP_FLAW, "ERROR: UpdateAccount failed in restore (%d)\n",
			err);
		return (kServerFuncAbort);
	}


	// We want to send the POP number down to the box.  Not entirely sure
	// why we're doing it here.  This used to just blindly restore whatever
	// was in the account, but if that got screwed up then the box got
	// really confused.
	//
	// update the box pops, town, true x25, false redial
	//
	Server_PopUpdate(state, account, 0, 0, 0, kX25_OTHER_CONNECT, false);

	// Turn off the box password.  Naaaah.
	//
	//Server_ClearBoxPassword(state);

	// Restore settings for call waiting, keyboard type, etc.
	//
	Server_RestoreMiscPrefs(state, account);

	// Restore settings for Rockwell modem.
	//
	Server_RestoreModemStuff(state, account);

	// Restore some random things.  These are constants that only need
	// to be set once and go away whenever the DB is lost, like the
	// "only connect with a smartcard" thing for 'sjne'.
	//
	Server_SetRandomThings(state, account);

	// Play games with the validation token.
	//
	// (do me)

	return (kNoError);
}


//
// Restore the contents of a single player's account on the current box.
//
// Expects the box's "current user" setting to already have been changed.
// (Don't really need to pass in playerNum, but it makes the logs pretty.)
//
PRIVATE Err
Server_DoRestorePlayerAccount(ServerState *state, Account *account, char playerNum)
{
	const unsigned char restoreFlags = kPersonificationPassword |
		kPersonificationTauntText | kPersonificationAboutText |
		kPersonificationROMIconID | kPersonificationRAMIcon |
		kPersonificationROMClutID;

	PLogmsg(LOGP_PROGRESS, "BR: Server_DoRestorePlayerAccount (%d) '%s'\n",
		playerNum, account->playerAccount.userName);

	if (account == NULL) {
		PLogmsg(LOGP_FLAW,
			"ERROR: DoRestorePlayerAccount called with NULL account\n");
		return (kFucked);
	}

	Logmsg("BR: DoRestorePlayerAccount (%ld,%ld)[%d] '%s'\n",
		account->boxAccount.box.box, account->boxAccount.box.region,
		playerNum, account->playerAccount.userName);

	// Ship it.
	//
	Server_SendNewCurrentUserName(state, account->playerAccount.userName);
	Server_SendPersonification(state, &account->playerAccount, restoreFlags);
	Server_SendPasswordEraseCode(state, account);
	Server_SendAddressBook(state, account);
	if (Server_SendAllRankings(state, account) != kServerFuncOK)
		return (kFucked);

	// Must send mail too.
	// (someday)

	PLogmsg(LOGP_PROGRESS, "BR: Server_DoRestorePlayerAccount done\n");
	return (kNoError);
}



// ===========================================================================
//		Miscellaneous routines
// ===========================================================================

//
// Check to see if the box sent up any hardwareID info, and if they did
// make sure it's valid.
//
// The hardwareID of a simulator should have been nuked before getting
// to this routine (currently done in ReceiveLogin).
//
// Returns true if the hwid uploaded is usable.
//
Boolean
Server_BoxSentValidHWID(ServerState *state)
{
	PLogmsg(LOGP_PROGRESS, "BR: Server_BoxSentValidHWID (%d)\n",
		state->loginData.hardwareID.hardwareIDtype);

	// Pull these out for the log.
	//
	if ((state->loginData.hardwareID.hardwareIDtype == kHWID_DallasTouch) &&
		(state->loginData.hardwareID.hwid.snesHWID.snesHardwareIDerror))
	{
		PLogmsg(LOGP_NOTICE,
			"BR: ERROR: bad DT hardwareID on (%ld,%ld) (%s)\n",
			state->loginData.userID.box.box,
			state->loginData.userID.box.region,
			state->boxPhoneNumber.phoneNumber);
		return (false);
	}

	return (Common_IsValidHWID(&state->loginData.hardwareID));
}


//
// Change the current user on the box to a different user.  Useful for box
// restores.
//
Err
Server_SendSetCurrentUserNumber(ServerState *state, unsigned char userNum)
{
	messOut	opCode;

	PLogmsg(LOGP_PROGRESS, "Server_SendSetCurrentUserNumber\n");

	if (Server_DebugService(state) != kServerFuncOK)
		return (kServerFuncAbort);

	opCode = msSetCurrentUserNumber;
	Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(unsigned char), (Ptr)&userNum);

	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	PLogmsg(LOGP_PROGRESS, "Server_SendSetCurrentUserNumber done\n");
	return (kServerFuncOK);
}


//
// Get the hidden serial numbers from the box.
//
// Most often used for synchronizing box and server.
//
Err
Server_GetHiddenSerials(ServerState *state, BoxSerialNumber *s1, BoxSerialNumber *s2)
{
	messOut	opCode;
	char	numHidden;

	PLogmsg(LOGP_PROGRESS, "Server_GetHiddenSerials\n");

	if (Server_DebugService(state) != kServerFuncOK)
		return (kServerFuncAbort);

	opCode = msGetHiddenSerials;
	Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr)&opCode);

	Server_TReadDataSync( state->session, 1, (Ptr)&opCode );
	if (opCode != msSendHiddenSerials) {
		PLogmsg(LOGP_FLAW,
			"Error: Box didn't respond to msGetHiddenSerials with msSendHiddenSerials\n");
		PLogmsg(LOGP_FLAW,
			"Error: wanted %d, got %d\n", msSendHiddenSerials, opCode);
		return (kServerFuncAbort);
	}

	Server_TReadDataSync( state->session, 1, (Ptr)&numHidden );
	if (numHidden != 2) {
		PLogmsg(LOGP_FLAW,
			"Error: msSendHiddenSerials didn't send 2 boxserialnumbers (%d)\n",
			numHidden);
		return (kServerFuncAbort);
	}

	Server_TReadDataSync( state->session, sizeof(BoxSerialNumber), (Ptr)s1 );
	Server_TReadDataSync( state->session, sizeof(BoxSerialNumber), (Ptr)s2 );

	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	Logmsg("GetHiddenSerials: (%d,%d) and (%d,%d)\n",
		s1->box, s1->region, s2->box, s2->region);

	PLogmsg(LOGP_PROGRESS, "Server_GetHiddenSerials done\n");
	return(kServerFuncOK);
}


//
// Synchronize the connection with the box.  This is currently done by
// calling GetHiddenSerials.
//
Err
Server_SyncWithBox(ServerState *state)
{
	BoxSerialNumber		s1, s2;

	PLogmsg(LOGP_PROGRESS, "Server_SyncWithBox\n");

	Server_SetTransportHold(state->session, false);		// make sure it's running!

	PLogmsg(LOGP_DBUG, "Synchronizing box and server...\n");
	return (Server_GetHiddenSerials(state, &s1, &s2));
}



// ===========================================================================
//		Restore Modem Settings
// ===========================================================================

//
// Restore Rockwell modem overrides (call waiting, etc.)
//
Err
Server_RestoreModemStuff(ServerState *state, Account *account)
{
	SubDispatcher subDisp[] = {
		{ kPlatformGenesis,	kPlatformGenesisMask,	(INT_FUNC_PTR) Server_sega_RestoreModemStuff },
		{ kPlatformSNES,	kPlatformSNESMask,		(INT_FUNC_PTR) Server_snes_RestoreModemStuff },
		{ kPlatformSJNES,	kPlatformSJNESMask,		(INT_FUNC_PTR) Server_snes_RestoreModemStuff },
		{ kPlatformAny,		0,						(INT_FUNC_PTR) Server_any_RestoreModemStuff },
		{ 0,				0,						NULL },		// foosh!
	};

	return ( (Err)(Common_SubDispatch(state->boxOSState.boxType, subDisp))(
		state, account) );

	return (kNoError);
}

PRIVATE Err
Server_sega_RestoreModemStuff(ServerState *state, Account *account)
{
	PLogmsg(LOGP_PROGRESS, "Server_sega_RestoreModemStuff\n");

	// (nothing to do)
	//

	return (kNoError);
}

PRIVATE Err
Server_snes_RestoreModemStuff(ServerState *state, Account *account)
{
	DBID id = 103;	// Box's kCWToneABTHDConst
	unsigned long thd = 0x0A002400;

	PLogmsg(LOGP_PROGRESS, "Server_snes_RestoreModemStuff\n");
	
	// Only download DBConstant for fixing call waiting on SNES if the modemVersion
	// is known to be the "old" one (2324)
	//
	if (account->boxAccount.modemVersion[0] == kRockwell2324)
	{
		PLogmsg(LOGP_DBUG, "BR: Sending kCWToneABTHDConst(0x%08lX)\n", thd);
		Server_SendDBConstants(state, 1, &id, &thd);
	}
	// (nothing else to do)
	//

	return (kNoError);
}

PRIVATE Err
Server_any_RestoreModemStuff(ServerState *state, Account *account)
{
	PLogmsg(LOGP_PROGRESS, "Server_any_RestoreModemStuff\n");

	// Dunno what to restore, just quietly exit.
	//
	return (kNoError);
}


//
// Set some random things on the box.  Should be called on the first
// successful X.25 connect, and whenever the box DB is gone.
//
// This is useful for DB constants that need to be set once, like "only
// allow server connects with a smartcard installed" for 'sjne', or "don't
// do the auto-title stuff" on 'snes'.
//
// This would NOT be an appropriate place for the SNES specialModeFlags
// stuff currently done in Server_snes_RecvComplete, because this won't
// get called until the X.25 connect.
//
// No danger from SIGHUPs during a box restore, because marking the DB
// as valid doesn't happen until the restore completes.  Could conceivably
// leave half the job done on an account create connect, but this happens
// early enough that the box and the account will be pretty screwed up
// anyway and will probably be done over again on the next connect.
//
Err
Server_SetRandomThings(ServerState *state, Account *account)
{
	SubDispatcher subDisp[] = {
		{ kBoxType_sn07,	0xffffffff,				(INT_FUNC_PTR) Server_sn07_SetRandomThings },
		{ kPlatformSJNES,	kPlatformSJNESMask,		(INT_FUNC_PTR) Server_sjne_SetRandomThings },
		{ kPlatformAny,		0,						kNoFunction },
		{ 0,				0,						NULL },		// krunky!
	};

	PLogmsg(LOGP_PROGRESS, "Server_SetRandomThings\n");

	return ( (Err)(Common_SubDispatch(state->boxOSState.boxType, subDisp))(
		state, account) );

	return (kNoError);
}

//
// Do some bug fixes and adjustments for the 'sn07' ROM.
//
PRIVATE Err
Server_sn07_SetRandomThings(ServerState *state, Account *account)
{
	char twozero[2] = { 0, 0 };
	unsigned char opCode;
	long length;
	DBID id;

	// Quick hack to turn off the auto-title-string stuff.
	//
	opCode = msReceiveWriteableString;	// overloaded operator...
	id = 0;		// nuke the basic set
	length = 2;
	Server_SetTransportHold(state->session, true);
	Server_TWriteDataSync(state->session, sizeof(opCode), (Ptr) &opCode);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &id);
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length);
	Server_TWriteDataSync(state->session, length, (Ptr) twozero);
	Server_SetTransportHold(state->session, false);
	if (Server_TCheckError(state->session) != noErr)
		return (kServerFuncAbort);

	// Bug fix for 'sn07'.  We could just send this down with the OS patch,
	// but first we need to make sure all the SNES boxes have it (damn
	// things don't crash often enough!)
	//
	// From Josh, 950913: const 72 should be 0x00060004, not 0x000600F0.
	// This makes the FAX detect 4 seconds long instead of 4 minutes long;
	// useful for peer connects.
	//
	if (state->boxOSState.boxType == kBoxType_sn07) {
		DBID ids[1] = { kFAXTimeoutConst };
		long vals[1] = { 0x00060004L };

		Server_SendDBConstants(state, 1, ids, vals);
	}

	return (kServerFuncOK);
}

//
// Do stuff for the 'sjne' boxes.
//
PRIVATE Err
Server_sjne_SetRandomThings(ServerState *state, Account *account)
{
#if 0
	DBID ids[1] = { kOnlyAllowConnectWithSmartCardConst };
	long vals[1] = { 1 };

	// Don't allow them to dial the server without a smartcard installed
	// after this connect.  Not sure if bad things will happen if we do
	// this on the ANI connect, but that doesn't matter since this only
	// happens on the X.25 connect.
	//
	return (Server_SendDBConstants(state, 1, ids, vals));
#else
	// We decided that it's much safer to always allow the box to connect
	// with or withou;a smartcard installed with positive credits. Reason,
	// other than trusting people not to abuse the system (NOT!) is that
	// we need to allow people to connect to receive a box system patch if
	// we ever need to add a new smartcard type to the table of recognized
	// cards. 
	return noErr;
#endif
}

