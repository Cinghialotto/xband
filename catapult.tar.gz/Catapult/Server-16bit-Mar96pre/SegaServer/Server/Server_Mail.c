/*
 * Copyright � 1996 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Mail.c,v 1.3 1996/03/09 18:32:10 fadden Exp $
 *
 * $Log: Server_Mail.c,v $
 * Revision 1.3  1996/03/09 18:32:10  fadden
 * Added Server_HandleCustomIconRequest, moved the icon stuff there.
 *
 * Revision 1.2  1996/03/08 17:14:53  fadden
 * Moved special mail target checks into three functions, one for "user"
 * targets, one for "restricted" targets, and one for "misc" targets.  Added
 * cheesy access control for "restricted" targets.
 *
 * Revision 1.1  1996/03/08 13:43:21  fadden
 * Moved mail processing out of Server_ProcessSendQ.c.
 *
 *
 * (Earlier comments may be found in Server_ProcessSendQ.c)
 */
#include <stdio.h>
#include <ctype.h>
#include <memory.h>
#include <string.h>
#include <malloc.h>
#include <errno.h>

#include "DBConstants.h"
#include "DBTypes.h"
#include "Mail.h"
#include "StringDB.h"

#include "Common.h"
#include "Common_PlatformID.h"
#include "Common_ReadConf.h"
#include "Common_Missing.h"
#include "FilterHandle.h"

#include "Server.h"
#include "ServerDataBase.h"
#include "Server_Personification.h"


//
// External prototypes.
//
Boolean Server_CheckXbandAlias(char *inAddr, char *outAddr, int outAddrLen);

//
// Local prototypes.
//
static void Server_HandlePatchMail(ServerState *state, char *message);
static Boolean Server_HandleGameIDPatch(ServerState *state, char *message);
static char *Server_SecurePath(ServerState *state, char *path, char *prefix);
static Boolean Server_SpecialUserMail(ServerState *state, Mail *mail);
static Boolean Server_SpecialRestrictedMail(ServerState *state, Mail *mail);
static Boolean Server_SpecialMiscMail(ServerState *state, Mail *mail);
static void Server_HandleCustomIconRequest(ServerState *state, char *message);


// String to replace to change to a test server is different on 'sjne'.
#define CHAT_STRING	( \
	((state->platformID == kPlatformSJNES && !gConfig.ustest)) ? \
	142 : kCompuserveReturn1)


//
// Grand central station for mail processing.
//
int
Server_ProcessIncomingMail(ServerState *state)
{
short 				i;
int					mailSent = 0;
Mail				*mail;
char 				bomb[1000];
userIdentification	tmpUserID, foundUserID;
Boolean				disallowedMail = false;
char				address[256];

	PLogmsg(LOGP_PROGRESS, "Server_ProcessIncomingMail\n");

	ASSERT(state->validFlags & kServerValidFlag_IncomingMail);
	ASSERT(state->validFlags & kServerValidFlag_Account);

	for(i = 0; i < state->incomingMail.count; i++)
	{
		mail = state->incomingMail.mailItems[i].mail;
		//mail->from = state->loginData.userID;		// create the from addr (it is not sent from the box)
		if (state->loginData.userID.userID == mail->from.userID) {
			mail->from = state->loginData.userID;
			PLogmsg(LOGP_DBUG,
				"IncomingMail: sender userID matches from userID (%d)\n",
				mail->from.userID);
		} else {
			PLogmsg(LOGP_DBUG,
				"IncomingMail: sender userID (%d) != from userID (%d)\n",
				state->loginData.userID.userID, mail->from.userID);
			tmpUserID = state->loginData.userID;	// start with box ID
			tmpUserID.userID = mail->from.userID;	// use actual player #
			if (WrapperDB_FindUserIdentification(&tmpUserID, &foundUserID) != kNoError) {
				// This happens if you create a new account, write mail,
				// then send it from another account... the first account
				// has never logged in, so it doesn't seem to exist.
				PLogmsg(LOGP_NOTICE,
					"NOTE: ProcessIncomingMail can't find sender (%ld,%ld)[%ld], skipping\n",
					tmpUserID.box.box, tmpUserID.box.region, tmpUserID.userID);
				// I18N Appears:  When a player on the modem sends mail but 
				//           has never connected to XBAND from that player (note
				//           there can be up to 4 players per modem).
				// Solution: Resend the XMail from the player.
				//
				sprintf(bomb, gettext("Player %d has not connected to XBAND.  Mail could not be sent.\n"),			/* DIALOG */
					tmpUserID.userID);
				Server_SendDialog(state, bomb, false);
				continue;	// next!
			} else {
				// success!
				if (mail->from.userID != foundUserID.userID) {
					PLogmsg(LOGP_FLAW,
						"ERROR: FindUserIdentification fucked us!!\n");
					strcpy(foundUserID.userName, "(unknown--blorch)");
				}
				mail->from = foundUserID;
			}
		}

		mail->date = Server_GetSegaDate();
		PLogmsg(LOGP_DETAIL, "Incoming Mail Item:\n");
		PLogmsg(LOGP_DETAIL, "  FROM ");
		ServerState_PrintUserIdentification(&mail->from);
		PLogmsg(LOGP_DETAIL, "  TO   ");
		ServerState_PrintUserIdentification(&mail->to);
		PLogmsg(LOGP_DETAIL, "  Serial number = %ld\n",
			(long)mail->serialNumber);
		PLogmsg(LOGP_DETAIL, "  Date = %ld %ld %ld (0x%.8lx)\n",
			(mail->date & kYearMask) >> kYearShift,
			((mail->date & kMonthMask) >> kMonthShift) +1,
			(mail->date & kDayMask) >> kDayShift,
			mail->date);
		PLogmsg(LOGP_DETAIL, "  hasThisMailBeenRead = %d\n",
			mail->hasThisMailBeenRead);
		PLogmsg(LOGP_DETAIL, "  Title = '%s'\n", mail->title);
#ifdef OPTIONAL
		Loghexdump((unsigned char *)mail->message, strlen(mail->message));
#else
		PLogmsg(LOGP_DETAIL, "Body = '%s'\n",  mail->message);
#endif


		//
		// Check to see if it's going to one of the "special" targets.
		// If so, no further processing is necessary.
		//
		if (Server_SpecialUserMail(state, mail) ||
			Server_SpecialRestrictedMail(state, mail) ||
			Server_SpecialMiscMail(state, mail))
		{
			Logmsg("Handled special mail, to='%s'\n", mail->to.userName);
			continue;
		}

		//
		// Catch mail sent to addresses beginning with "xband" and
		// forward to the mail processing machine for auto-mail
		// processing.
		//
		// If the "to" line isn't recognized, a reject will come back
		// from the mailer daemon.
		//
		// ... unless we're specifying a file for it to go to,
		// in which case we send it off to segad like normal.
		// This is for Japan.
		//
		if (Server_CheckXbandAlias(mail->to.userName, address, 256)
			&& gConfig.xbandMailFile[0] == 0) 
		{
			/*
			 * special hack for XBAND-legal:
			 * only allow mail to go out on the connect where
			 * he makes it past the Terms+Conditions.
			 * This helps keep crap out of the file on mgate
			 * where the responses are stored.
			 *
			 * [ I don't know why this is here instead of with the rest
			 *   of the "misc" targets, so I'm going to leave it alone.
			 *   ++ATM 960308 ]
			 */

			if (DataBaseUtil_CompareStrings(mail->to.userName,
					"xband-legal") == 0 && state->firstRealConnect == false)
			{
				PLogmsg(LOGP_DETAIL,
					"dropped mail to XBAND-legal\n");
			}
			else {
				Server_SendXmailToInet(mail, state, address, true);
				mailSent++;
			}
			Logmsg("Sent mail to XBAND generic, to='%s'\n", mail->to.userName);
		}
		else
		{
			Err err;
			char *cp;

			//
			// Toss the mail if sending mail has been disabled (eg. for excess profanity).
			//
			if(state->disallowOutgoingMail)
			{
				if(!disallowedMail)
				{
					disallowedMail = true;
					Server_SendDialog(state, gettext("You are not allowed to send mail.  Your mail will not be delivered."), false);
				}
				continue;
			}
			

			// handle internet mail:
			// any "to" address with an '@' goes to internet
			// we also send internet mail to the database below
			// so that it gets logged there.
			// the database knows to toss such mail after logging.
			// 
			// .. except if it's to something @xband.com,
			// in which case we short-circuit it back into
			// the non-internet case.

			cp = strchr(mail->to.userName, '@');
			if (cp && !strcasecmp(cp, "@xband.com")) {
				*cp = 0;
				cp = NULL;
			}

			if (cp) {
				Server_SendXmailToInet(mail, state, mail->to.userName, false);
			}

			// add this to the inboxes of the recipients.
			// put error or confirmations in the sendQ to the box.
			if ((err = WrapperDB_AddMailToIncoming(mail)) == kNoError) {
				Logmsg("Successfully sent to DB, to='%s'\n", mail->to.userName);
				mailSent++;

				// The above call may take a couple seconds to complete,
				// especially when the system is heavily loaded.  If a user
				// sends more than two dozen mail messages, there's a good
				// chance the box's 30 second timer will expire and bail
				// on the server.
				//
				// This call is intended to avoid the problem by giving the
				// TLayer a chance to send keepalives to the box.
				//
				// ATM 950118
				//
				Server_TNetIdle(state->session->type, nil);
			} else {
			
				if(err == kMailNotDelivered_AccountClosed)
				{
					// I18N Appears:  When player sends mail to a player who's 
					//           account is closed.
					// Solution: None.  You can not send mail to a closed account.
					//
					sprintf(bomb, gettext("Sorry, the XBAND account belonging to \"%s\" is closed.  Mail not sent."), mail->to.userName);	/* DIALOG */
				}
				else
				if(err == kMailNotDelivered_IncomingMailDisabled)
				{
					// I18N Appears:  When player sends mail to a player who is 
					//           restricted from receiving XMail.
					// Solution: None.  You cannot send XMail to players who 
					//           are  not allowed to receive XMail.
					//
					sprintf(bomb, gettext("Sorry, \"%s\" is not allowed to receive XMail.  Mail not sent."), mail->to.userName);	/* DIALOG */
				}
				else
				if(err == kMailNotDelivered_OutgoingMailDisabled)
				{
					// I18N Appears:  When player is restricted from sending XMail.
					// Solution: UCA should call Catapult about this customer.
					//
					sprintf(bomb, gettext("Sorry, this XBAND account is not allowed to send XMail.  Mail not sent."), mail->to.userName);	/* DIALOG */
				}
				else
				if(err == kMailNotDelivered_TooManyMails)
				{
					// I18N Appears:  When player sends mail to a player who's 
					//           mailbox is full.  A player can only have 25 messages 
					//           waiting to be delivered to his or her modem.
					// Solution: Player should wait until the addressee has read 
					//           his or her XMail, and then try and resend the XMail to the 
					//           addressee.
					sprintf(bomb, gettext("Sorry, the XMail mailbox for \"%s\" is full.  Mail not sent."), mail->to.userName);	/* DIALOG */
				}
				else
				if(err == kMailNotDelivered_IncomingMailBlocked)
				{
					sprintf(bomb, gettext("\"%s\" has blocked you and cannot receive your mail. Mail not sent."), mail->to.userName);
				}
				else
				if(err == kMailNotDelivered_OutgoingMailBlocked)
				{
					sprintf(bomb, gettext("You cannot send mail to \"%s\" since he is on your block list. Mail not sent."), mail->to.userName);
				}
				else
				{
					// I18N Appears:  When player sends mail to a player who does 
					//           not have an account on XBAND.
					// Solution: Try sending mail to another player name, as 
					//           the addressee may have changed his or her player name.
					//
					sprintf(bomb, gettext("Sorry, we can't find \"%s\" on XBAND.  Mail not sent."), mail->to.userName);	/* DIALOG */
				}

				Server_SendDialog(state, bomb, false);

				//
				// BRAIN DAMAGE
				// Server_SendBouncedMail(mail);
			}
		}

	}	/* for loop */

	//if(state->incomingMail.count > 0)
	if (mailSent > 0) {
		if (mailSent == 1)
			// I18N Appears: When player sends one mail message.	
			//
			sprintf(bomb, gettext("One outgoing mail message was sent."));	/* DIALOG */
		else
			// I18N Appears: When player sends more than one mail message.
			//
			sprintf(bomb, gettext("%ld outgoing mail messages were sent."),	/* DIALOG */
				mailSent /*state->incomingMail.count*/);
		Server_SendDialog(state, bomb, false);
	}

	return(kServerFuncOK);
}




//
// Check to see if the mail is being sent to a special "user" target.
//
// These are mail targets that users are expected to send mail to, for
// doing things like setting their POPs or buying things from the "XBAND
// store".
//
// Returns "true" if we handled the mail, "false" otherwise.
//
static Boolean
Server_SpecialUserMail(ServerState *state, Mail *mail)
{
	char	bomb[1000];

	if(!DataBaseUtil_CompareStrings(mail->to.userName, "XBAND-AREA"))
	{
		// check to see if bum is long distance enabled, otherwise
		// this mail target is useless to him. Send dialog to rub it in.
		if (!(state->account->boxAccount.restrictArea &
		(kRestrictArea_dialLongDistance|kRestrictArea_temporaryDialLongDistance
		|kRestrictArea_XBNLongDistance)))
		{
			Server_SendDialog(state,gettext("Sorry, you are not enabled for long distance so you can't change your challenge area."), true); /* DIALOG */
		}
		else
		if (!DataBaseUtil_CompareStrings(mail->title, "local"))
		{
			state->account->boxAccount.restrictArea |= 
				kRestrictArea_dialLocalPreferred;
			state->account->boxModified |= kBA_restrictInfo;
			Server_SendDialog(state,gettext("Your challenge area is now local."),false);	/* DIALOG */
		}
		else
		if (!DataBaseUtil_CompareStrings(mail->title,"long") ||
			!DataBaseUtil_CompareStrings(mail->title,"ld"))
		{
			state->account->boxAccount.restrictArea &=
				~kRestrictArea_dialLocalPreferred;
			state->account->boxModified |= kBA_restrictInfo;
			Server_SendDialog(state,gettext("Your challenge is now long distance."), false);	/* DIALOG */
		}
		else
		{
			Server_SendDialog(state,gettext("XBAND-AREA did not understand your mail. Your challenge area has not been changed. Please resend with a title of LOCAL, LD, or LONG."), true);	/* DIALOG */
		}
	}
	else
#if 0
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "XBAND.ZIPCODE"))
	{
	long			zip;
	Hometown		town;
	Err				err;

		if(sscanf(mail->title, "%5ld", &zip) == 1)
		{
			err = DataBase_GetZipTown(zip, town);
			if (err)
			{
				// I18N Appears: NEVER.
				//
				sprintf(bomb, gettext("Your zip code is unheard of. Try again."), zip);	/* DIALOG */
				Server_SendDialog(state, bomb, false);
			} else {
				sprintf(bomb, gettext("Your zip code has been changed to %05ld. Your home town is now '%s'. How was the move?"), zip, town);	/* DIALOG */
				Server_SendDialog(state, bomb, false);

				sprintf(bomb, "%05ld", zip);
				strncpy(state->account->userAccount.zipCode, bomb, kZipCodeSize-1);
				state->account->userAccount.zipCode[kZipCodeSize-1] = 0;
				state->account->userModified |= kUA_zipCode;
				
				Server_SendNewBoxHometown(state, town);
				strcpy(state->account->boxAccount.homeTown, town);
				state->account->boxModified |= kBA_homeTown;
			}
		}
		else
		{
			Server_SendDialog(state, gettext("XBAND.ZIPCODE could not read your zip code from the To box of your mail message. Your zip code has not been changed."), true); /* DIALOG */
		}
	}
	else
#endif
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "XBand.filtermail"))
	{
		state->account->boxAccount.boxFlags ^= kBoxFlag_FilterMail;
		// I18N Appears: NEVER.
		//
		sprintf(bomb, gettext("Profanity filter for your mail is now %s."), (state->account->boxAccount.boxFlags & kBoxFlag_FilterMail) ? gettext("on") : gettext("off"));	/* DIALOG */
		state->account->boxModified |= kBA_boxFlags;
		Server_SendDialog(state, bomb, true);
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "XBand.restrict"))
	{
	int start1, end1, start2, end2;
	
		if(sscanf(mail->message, "%d %d %d %d", &start1, &end1, &start2, &end2) == 4)
		{
			if (!DataBaseUtil_CompareStrings(mail->title, "long"))
				state->account->boxAccount.restrictArea = kRestrictArea_dialLongDistance;
			else if (!DataBaseUtil_CompareStrings(mail->title, "local"))
				state->account->boxAccount.restrictArea = kRestrictArea_dialLocal;

			state->account->boxAccount.restrictInfo[0].start = (short)start1;
			state->account->boxAccount.restrictInfo[0].end = (short)end1;
			state->account->boxAccount.restrictInfo[1].start = (short)start2;
			state->account->boxAccount.restrictInfo[1].end = (short)end2;
			state->account->boxModified |= kBA_restrictInfo;
			
			state->account->boxAccount.csUpdatedFlags |= kCSUpdatedFlag_UpdatedRestrictions;
			state->account->boxModified |= kBA_csUpdatedFlags;
			
			sprintf(bomb, gettext("(SERVER) Your restrictions are now: %d - %d, %d - %d. Calling area is %s"), /* DIALOG */
				start1, end1, start2, end2, state->account->boxAccount.restrictArea ? gettext("long distance"):gettext("local")); /* DIALOG */
			Server_SendDialog(state, bomb, true);
		}
		else
			Server_SendDialog(state, gettext("(SERVER) Could not parse your restrict settings.  They remain unchanged."), true);
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "xband-store"))
	{
		Server_HandleSalesMail(state, mail);
	}
	else
	{
		return (false);
	}

	return (true);
}


//
// Check to see if the mail is being sent to a special "restricted" target.
//
// This is for things that should be internal to Catapult only.  This
// includes stuff for testing that would be dangerous were it widely known,
// such as "assumebynum".
//
// Returns "true" if we handled the mail, "false" otherwise.
//
static Boolean
Server_SpecialRestrictedMail(ServerState *state, Mail *mail)
{
	char	bomb[1000];
	long	poperr;
	int		i;
	Boolean	access;

	//
	// Cheesy access control.  We determine whether or not they can use
	// any of these targets immediately, but we still have to do all the
	// compares to determine if we want to trap the mail message.  So
	// we have to check access in every target, which sucks.
	//
	// Actually, this whole if-then-else thing sucks, but it's not worth
	// fixing at this time (960308).
	//
	// For now, allow access if they're on a Catapult internal phone
	// number or we're allowing general access to the restricted targets
	// (this is a "just in case" feature).
	//
	access = false;
	if ((Server_GetSpecialPhone(state) & kSpecialCatapult) ||
		(gConfig.allowRestrMailTargets))
	{
		access = true;
	}


	if(!DataBaseUtil_CompareStrings(mail->to.userName, "XBAND.MINDWIPE"))
	{
		if (!access) goto noaccess;
		Server_SendBoxWipeMind(state);
		Server_SendDialog(state,
			gettext("Your mind has been wiped."), true); /* DIALOG */
	}
	else
	if (!DataBaseUtil_CompareStrings(mail->to.userName, "phone"))
	{
		// BRAIN DAMAGE.  here is a nice little hack to allow us to change
		// phone numbers without 1-800 ANI.
		//
		// Send mail to 'phone' and the body of the msg is the new phone number.
		//
		// Should not allow this for anyone who can use ANI; creates some
		// potential for abuse.
		//
		// [ I believe this has been superseded by "XBAND.PhoneNumber". ++ATM ]
		//
		phoneNumber newBoxPhoneNumber, newAccessPhoneNumber, altAccessPhoneNumber;
		Hometown town;

		if (!access) goto noaccess;
	
		Logmsg("PhoneMail: changing (%d,%d) from '%s' to '%s' (+ '%s')\n",
			state->loginData.userID.box.box,
			state->loginData.userID.box.region,
			state->account->boxAccount.gamePhone.phoneNumber,
			mail->message,
			mail->title);
		strncpy(newBoxPhoneNumber.phoneNumber, mail->message, kPhoneNumberSize);
		DataBaseUtil_UpdateUserPhoneNumber(state->account, &newBoxPhoneNumber);

		state->account->boxAccount.gamePhone = newBoxPhoneNumber;
		state->account->boxModified |= kBA_gamePhone;

		Common_PhoneFormatDisplay(newBoxPhoneNumber.phoneNumber,
			newBoxPhoneNumber.phoneNumber);
		Server_SendSetBoxPhoneNumber(state, &newBoxPhoneNumber);
		//state->extractedPhoneNumber = newBoxPhoneNumber;
		state->boxPhoneNumber = newBoxPhoneNumber;
		sprintf(bomb, gettext("PHONE: Your modem phone number has been changed to %s."), /* DIALOG */
			newBoxPhoneNumber.phoneNumber);
		Server_SendDialog(state, bomb, false);

		// If they really moved, we have to update POP as well.
		//
		poperr = Server_LookupPops(kLookupPop, &state->account->boxAccount.gamePhone,
			&newAccessPhoneNumber, &altAccessPhoneNumber, town, kPopSelect16, 0);
		if (mail->title[0] == '#')
		{
			state->account->boxAccount.debug[1] |= kBA_debug_dial9;
			state->account->boxModified |= kBA_debug;

			Server_AddPBX_Dial9(state, &newAccessPhoneNumber, &altAccessPhoneNumber);

			// Should change the 1-800 number on the box here to have the "9," prefix.
			// This involves changing a dbitem...?

		} else {
			// clear the "dial 9" flag if it's set
			if (state->account->boxAccount.debug[1] & kBA_debug_dial9) {
				state->account->boxAccount.debug[1] &= ~kBA_debug_dial9;
				state->account->boxModified |= kBA_debug;
				Logmsg("Cleared the dial 9 Flag\n");

				// Should change the 1-800 number on the box here to not have the "9," prefix.
				// This involves deleting the overriding dbitem?  (see above where it is set).

			}
		}

		Server_SetBoxAccountPops(state,&newAccessPhoneNumber,&altAccessPhoneNumber);

		Server_SendSetLocalAccessPhoneNumber(state,
			&newAccessPhoneNumber, &altAccessPhoneNumber, false);	// don't redial.

		Common_PhoneFormatDisplay(newAccessPhoneNumber.phoneNumber,
			newAccessPhoneNumber.phoneNumber);
		Common_PhoneFormatDisplay(altAccessPhoneNumber.phoneNumber,
			altAccessPhoneNumber.phoneNumber);
		sprintf(bomb, gettext("PHONE: Your server phone number has been set to %s."), /* DIALOG */
			newAccessPhoneNumber.phoneNumber);
		Server_SendDialog(state, bomb, false);

		Server_WhichTown(state, town);
		Server_SendNewBoxHometown(state, town);
		//strcpy(state->account->boxAccount.homeTown, town);
		//Don't change account's hometown since this is the master string entered by UCA.
		//state->account->boxModified |= kBA_homeTown;


		Logmsg("PhoneMail: phone '%s', popPhone '%s' (alt '%s'), town '%s'\n",
			newBoxPhoneNumber.phoneNumber,
			newAccessPhoneNumber.phoneNumber,
			altAccessPhoneNumber.phoneNumber, town);
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "server"))
	{
		phoneNumber newAccessPhoneNumber, altAccessPhoneNumber;
		Hometown town;

		if (!access) goto noaccess;

		// Do a normal lookup first to get the scriptID.
		//
		poperr = Server_LookupPops(kLookupPop, &state->account->boxAccount.gamePhone,
			&newAccessPhoneNumber, &altAccessPhoneNumber, town, kPopSelect16, 0);

		// Then set the phoneNumber from the mail message.
		//
		strncpy(newAccessPhoneNumber.phoneNumber, mail->message, kPhoneNumberSize);
		strncpy(altAccessPhoneNumber.phoneNumber, mail->message, kPhoneNumberSize);

		Server_AddPBX_Dial9(state, &newAccessPhoneNumber, &altAccessPhoneNumber);

		// extract the scriptID if set.  (eg. title = #5 sets scriptID to 5).
		//
		if (mail->title[0] == '#') {
		unsigned long scriptID;

			if(sscanf(mail->title+1, "%ld", &scriptID) == 1)
			{
				newAccessPhoneNumber.scriptID = (unsigned char)scriptID;
				altAccessPhoneNumber.scriptID = (unsigned char)scriptID;
			}
		}

		Server_SetBoxAccountPops(state,&newAccessPhoneNumber,&altAccessPhoneNumber);

		Server_SendSetLocalAccessPhoneNumber(state, &newAccessPhoneNumber,
			&altAccessPhoneNumber, false);

		sprintf(bomb, gettext("(SERVER) Your server phone number has been changed to %s, scriptID = %ld."), /* DIALOG */
				newAccessPhoneNumber.phoneNumber, newAccessPhoneNumber.scriptID);
		Server_SendDialog(state, bomb, false);
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "redial"))
	{
		long	numLoops;
		long	val;
		DBID	id;

		if (!access) goto noaccess;
	
		if(sscanf(mail->message, "%ld", &numLoops) == 1)
		{
			// sends this dialog in the closing update which drives the loop (ServerCore.c)
//				sprintf(bomb, "You will redial the server %ld times.", numLoops);
//				Server_SendDialog(state, bomb, false);
	
			// now stuff this into the account.
			state->account->playerAccount.debug[0] = numLoops;
			state->account->playerModified |= kPA_debug;

			// If we're using a SNES, set the screen saver to go off
			// after a week of inactivity.
			//
			if (state->platformID == kPlatformSNES || state->platformID == kPlatformSJNES) {
				PLogmsg(LOGP_PROGRESS, "Changing screen saver delay\n");
				id = kScreenSaverDelayConst;
				val = 60L*60*60*24*7;		// time is in ticks
				if (Server_SendDBConstants(state, 1, &id, &val) != kServerFuncOK)
					return (kServerFuncAbort);
			}
		}
		else
		{
			Server_SendDialog(state, gettext("(CHEESE) Could not do redial loop because could not parse numLoops from mail body"), false); /* DIALOG */
			// set it in the account to zero.
			state->account->playerAccount.debug[0] = 0;
			state->account->playerModified |= kPA_debug;

			// If we're using a SNES, change the screen saver delay back.
			//
			if (state->platformID == kPlatformSNES ||
				state->platformID == kPlatformSJNES)
			{
				PLogmsg(LOGP_PROGRESS, "Resetting screen saver delay\n");
				id = kScreenSaverDelayConst;
				val = 60L*60*15;		// default is 15 minutes
				if (Server_SendDBConstants(state, 1, &id, &val) != kServerFuncOK)
					return (kServerFuncAbort);
			}
		}
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "testpops"))
	{
		if (!access) goto noaccess;

		// Make the modem dial every pop in the country.
		//
		if(!strcmp("off", mail->title))
		{
			state->account->playerAccount.debug[1] = 0;	// turn it off
			state->account->playerAccount.debug[2] = 0;
		}
		else
		{
			state->account->playerAccount.debug[1] = 1;
			state->account->playerAccount.debug[2] = 0;
		}
		state->account->playerModified |= kPA_debug;
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "XBAND.latency"))
	{
		BoxSerialNumber 		s1, s2;
		unsigned long			t1;

		if (!access) goto noaccess;
	
		t1 = time(0);
		for(i = 0; i < 50; i++)
		{
			Server_GetHiddenSerials(state, &s1, &s2);
		}
		t1 = time(0) - t1;
		sprintf(bomb, gettext("(SERVER) Latency tester: %ld roundtrips took %ld seconds indicates %lf sec roundtrip latency."), 50L, t1, (double)t1/50.0); /* DIALOG */
		Server_SendDialog(state, bomb, true);
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "loop"))
	{
		if (!access) goto noaccess;
		Server_SendLoopback(state, 10000, true);
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "bigloop"))
	{
		if (!access) goto noaccess;
#ifdef unix
		alarm(0);	// turn off the evil alarm.
#endif
		for(i = 0; i < 10; i++)
			if(Server_SendLoopback(state, 10000, true) != kServerFuncOK)
				break;
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "rattlepatch"))
	{
		if (!access) goto noaccess;

		Server_SendDialog(state,
			gettext("(YO) RattlePatch mode enabled for next connection!"), false); /* DIALOG */
		state->account->boxAccount.debug[1] |= kBA_debug_RattlePatch;
		state->account->boxModified |= kBA_debug;
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "systempatch"))
	{
		if (!access) goto noaccess;

		Server_SendDialog(state, gettext("(YO) RattlePatch mode is now off."),false); /* DIALOG */
		state->account->boxAccount.debug[1] &= ~kBA_debug_RattlePatch;
		state->account->boxModified |= kBA_debug;
	}
	else
	if (DataBaseUtil_CompareStrings(mail->to.userName, "whichserver") == 0)
	{
		char buffer[64];

		if (!access) goto noaccess;

		// Change the writeable string so it chooses the specified server.
		//
		if (strlen(mail->message) > (64 - 12)) {
			Server_SendDialog(state,
				"(SERVER) chat string mail message was too long!",
				false);
		} else {
			// Replace either the last component or the whole thing.
			//
			if (strchr(mail->message, ',') || strchr(mail->message, '&')) {
				sprintf(buffer, "%s\r", mail->message);
				if (LOCALE_PHONE_JA()) {
					// no '*' on the keyboard!
					char *cp = strchr(buffer, '&');
					if (cp != NULL)
						*cp = '*';
				}
			} else {
				sprintf(buffer, "CATAPULT,%s\r", mail->message);
			}

			// Send new string.  Default is "CATAPULT,SEGA\r".
			//
			Server_SendXYString(state, buffer, kStringType,
				CHAT_STRING);

			sprintf(bomb,
				"(SERVER) Your server chat string has been changed to: %s.",
				buffer);
			Server_SendDialog(state, bomb, false);
		}
	}
	else
	if (DataBaseUtil_CompareStrings(mail->to.userName, "catapentserver") == 0 ||
		DataBaseUtil_CompareStrings(mail->to.userName, "testserver") == 0)
	{
		// Change the writeable string so it chooses the testserver (SG06 on
		// catapent).  10/13/94  dj
		//
		unsigned char opCode;
		unsigned long length;
		char buffer[1000];
		xyString	*xystr;
		DBID		theID;
		DBType		theType;
	
		if (!access) goto noaccess;

		opCode = msAddItemToDB;
		Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode);
		
		xystr = (xyString *)buffer;
		xystr->xPos = 0;
		xystr->yPos = 0;
		sprintf(xystr->cString, "CATAPULT,XB11\r");
		length = sizeof(xyString) + strlen( xystr->cString );	// no need for +1 cuz xyString.cString[1] already
	
		theID = CHAT_STRING;	/* default for this str is 'CATAPULT,SEGA\r'  */
		theType = kStringType;
		
		Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
		Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
		Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length);
		Server_TWriteDataSync(state->session, length, (Ptr) xystr);

		sprintf(bomb, gettext("(SERVER) Future X25 connections will be through the Server on catapent (%s)."), xystr->cString); /* DIALOG */
		Server_SendDialog(state, bomb, false);
	}
	else
	if (DataBaseUtil_CompareStrings(mail->to.userName, "newaccount") == 0)
	{
		phoneNumber newAccessPhoneNumber;
		BoxSerialNumber box;

		if (!access) goto noaccess;

		// set box serial number to -1, -1 and force a redial.
		//
		box.box = -1;
		box.region = -1;
		Server_SendNewBoxSerialNumber(state, &box);

		newAccessPhoneNumber = state->account->boxAccount.popPhone;

		Server_SendSetLocalAccessPhoneNumber(state, &newAccessPhoneNumber,
			&newAccessPhoneNumber, true);
		sprintf(bomb, gettext("(SERVER) Your box serial number has been set to -1, -1.")); /* DIALOG */
		Server_SendDialog(state, bomb, false);
	}
	else
	if (DataBaseUtil_CompareStrings(mail->to.userName, "assumebynum") == 0)
	{
		Account			*accounts[4];
		register long	a;
		userIdentification	userID;
		Err				err;

		if (!access) goto noaccess;
	
		// nasty doorway.  hee hee.
		//
		if (sscanf(mail->message, "%ld, %ld",
			&userID.box.box, &userID.box.region) == 2)
		{	
			for(a = 0; a < 4; a++)
				accounts[a] = NULL;

			userID.userID = state->loginData.userID.userID;
			//err = DataBaseUtil_FindAllPlayerAccounts(&userID, accounts);
			err = Server_RestoreAccount(state, &userID.box);
			if(err == kNoError)
			{
				//Server_DoRestore(state, accounts, false);

				sprintf(bomb,
					gettext("(SERVER) Your box has assumed the identity of box %ld, %ld."),
					userID.box.box, userID.box.region);
				Server_SendDialog(state, bomb, false);
			}
			else
			{
				//sprintf(bomb,
				//	"(SERVER) No account registered for box %ld, %ld.",
				//	userID.box.box, userID.box.region);
				sprintf(bomb, gettext("(SERVER) Restore to %ld,%ld failed (%d)\n"),
					userID.box.box, userID.box.region, err);
				Server_SendDialog(state, bomb, false);
			}
		}
		else
		{
			Server_SendDialog(state, gettext("(SERVER) Could not parse your assume numbers."), false); /* DIALOG */
		}
	}
	else
	if (DataBaseUtil_CompareStrings(mail->to.userName, "mainserver") == 0)
	{
		// Change the writeable string so it chooses the mainserver (SEGA
		// on cm1).  9/28/94  dj
		//
		unsigned char opCode;
		unsigned long length;
		char buffer[1000];
		xyString	*xystr;
		DBID		theID;
		DBType		theType;

		if (!access) goto noaccess;
	
		opCode = msAddItemToDB;
		Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr) &opCode);
		
		xystr = (xyString *)buffer;
		xystr->xPos = 0;
		xystr->yPos = 0;
		if (LOCALE_PHONE_JA() && !gConfig.ustest)
			sprintf(xystr->cString, ".CATAPULT*SJNE\r");
		else
			sprintf(xystr->cString, "CATAPULT,SEGA\r");
		length = sizeof(xyString) + strlen( xystr->cString );	// no need for +1 cuz xyString.cString[1] already
	
		theID = CHAT_STRING;	/* default for this str is 'CATAPULT,SEGA\r'  */
		theType = kStringType;
		
		Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
		Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
		Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length);
		Server_TWriteDataSync(state->session, length, (Ptr) xystr);

		sprintf(bomb, gettext("(SERVER) Future X25 connections will be through the MainServer on fe1 (%s)."), xystr->cString); /* DIALOG */
		Server_SendDialog(state, bomb, false);
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "XBAND.icon"))
	{
		if (!access) goto noaccess;

		Server_HandleCustomIconRequest(state, mail->message);
	}
	else
	if (!DataBaseUtil_CompareStrings(mail->to.userName, "XBAND.clearicon") ||
		!DataBaseUtil_CompareStrings(mail->to.userName, "XBAND.noicon"))
	{
		if (!access) goto noaccess;

		Server_ClearCustomIcon(state);
		Server_SendPersonification(state, &state->account->playerAccount,
			kPersonificationRAMIcon);
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "XBAND.clearcredits"))
	{
		if (!access) goto noaccess;

		// Since credits start at -32 per month and count up to 0 (thanks Portal, you cheezeballs!)
		// this sets your credits to 0 and if maxCredits == 0 then you just ate yer month up.  which 
		// is perfect for testing boxlockout etc.
		//
		state->account->boxAccount.usedCredits = 0;
		state->account->boxAccount.maxCredits = 1;
		state->account->boxModified |= kBA_credits;
		Server_SendDialog(state, gettext("(CHEESE) Set your usedcredits = 0, maxcredits = 1."), true); /* DIALOG */
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "patch"))
	{
		if (!access) goto noaccess;

		if (!Server_HandleGameIDPatch(state, mail->message))
			Server_HandlePatchMail(state, mail->message);
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "crashlog"))
	{
		if (!access) goto noaccess;

		Crashmsg("CRASH MAIL MESSAGE: %s\n", mail->message);
		Server_SendDialog(state,
			gettext("(CHEESE) Added your crash message to the crashlog."), /* DIALOG */
			true);
	}
	else
	{
		return (false);
	}

	if (!access) {
		PLogmsg(LOGP_FLAW, "HEY: security hole in mail stuff! (to='%s')\n",
			mail->to.userName);
	}
	return (true);


noaccess:
	//
	// We get here if they tried to access a restricted target.
	//
	PLogmsg(LOGP_NOTICE,
		"Attempt to use restricted mail '%s' by (%ld,%ld)[%d]\n",
		mail->to.userName,
		state->loginData.userID.box.box,
		state->loginData.userID.box.region,
		state->loginData.userID.userID);
	sprintf(bomb, "Sorry, your mail to %s could not be delivered.\n",
		mail->to.userName);
	Server_SendDialog(state, bomb, true);
	return (true);
}


//
// Check to see if the mail is being sent to a special "misc" target.
//
// This includes targets that are handled elsewhere, but we don't want
// the user to get a "no such user" mail or have the message end up in
// customer service.
//
// Returns "true" if we handled the mail, "false" otherwise.
//
static Boolean
Server_SpecialMiscMail(ServerState *state, Mail *mail)
{
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "XBAND.MATCHER"))
	{
		// ignore this message here to prevent it being sent to "XBAND"
		// this is read by Server_StartGamePlay to affect matches
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "XBAND.PHONENUMBER"))
	{
		// ignore this message during normal operation
		// only acceptable during 800 connects when ANI doesn't work
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, gettext("XBAND.Replacement")))
	{
		// reply to "is this a replacement modem?" message; ignore it
		Logmsg("Ignoring mail sent to %s\n", gettext("XBAND.Replacement"));
	}
	else
	if(!DataBaseUtil_CompareStrings(mail->to.userName, "XBAND-ACCESS"))
	{
		// ignore this mail, processed earlier during
		// validate login
	}
	else
	{
		return (false);
	}

	return (true);
}


//
// By convention, anything beginning with "xband" indicates that the
// mail message is being sent to an internal alias probably for auto-mail
// processing. This routine tries to catch some common misspellings of
// "xband". 
//
Boolean
Server_CheckXbandAlias(char *inAddr, char *outAddr, int outAddrLen)
{
    int		flag = false;
    char	buf[256];
    char	*cp, *cp1;
    Boolean	errorMsg = false;

    // First, check if the message is being sent to any of the 
    // hard-coded XBAND addresses and redirect accordingly.
    if ((DataBaseUtil_CompareStrings(inAddr, kMailXbandFaxScan) == 0) ||
	    (DataBaseUtil_CompareStrings(inAddr, kMailXbandResetScan) == 0) ||
	    (DataBaseUtil_CompareStrings(inAddr, kMailXbandCallScan) == 0)) {
	
	if ((strlen(kMailXbandSupport) + strlen(kMailXbandSupportDomain))
		<= (outAddrLen - 1)) {
	    strcpy(outAddr, kMailXbandSupport);
	    strcat(outAddr, kMailXbandSupportDomain);
	    flag = true;
	} else {
	    errorMsg = true;
	}
    } else {
	// remove any spaces in the incoming address
	cp  = buf;
	cp1 = inAddr;
	while (*cp1 != NULL) {
	    if (!isspace(*cp1))
		*cp++ = *cp1;
	    cp1++;
	}
	*cp = NULL;

        if (strncasecmp(buf, "xband", 5) == 0) {
	    if ((strlen(buf) + strlen(kMailXbandSupportDomain)) 
			<= (outAddrLen - 1)) {
	        strcpy(outAddr, buf);
		strcat(outAddr, kMailXbandSupportDomain);
                flag = true;
	    } else {
		errorMsg = true; 
	    }
        } else if (strncasecmp(inAddr, "x-band", 6) == 0) {
	    if ((5 + strlen(buf+6) + strlen(kMailXbandSupportDomain)) 
			<= (outAddrLen - 1)) {
	        strcpy(outAddr, "xband");
	        strcat(outAddr, buf+6);
		strcat(outAddr, kMailXbandSupportDomain);
                flag = true;
	    } else {
		errorMsg = true;
	    }
        }
    }

    if (errorMsg == true) {
	PLogmsg(LOGP_FLAW, 
	    "Server_CheckXbandAlias: not enough buffer space to rewrite XBAND alias\n");
    }

    return(flag);
}


//
// Handle a mailed-in request for a custom icon.
//
// TO DO: use SecurePath to prevent them from grabbing /etc/passwd, make
// sure they're not getting "." (i.e. a directory), and maybe require a
// (configurable) password in the subject line so that we can allow some
// customers to have access to custom icons.
//
static void
Server_HandleCustomIconRequest(ServerState *state, char *message)
{
	char bomb[1000];

	if (Server_ReadCustomIcon(state, message) == kNoError) {
		Server_SendPersonification(state,
			&state->account->playerAccount, kPersonificationRAMIcon);
	} else {
		sprintf(bomb,
			"(SERVER) Unable to read custom icon '%s'.", message);
		Server_SendDialog(state, bomb, false);
	}
}


//
// Handle a mailed-in request for a blob of code.
//
static void
Server_HandlePatchMail(ServerState *state, char *message)
{
	PreformedMessage *pre;
	char *tmpc, *configc;
	char msgbuf[256];

	// Force them to read out of "/tmp" or patchDirectory.  Try both.
	//
	tmpc = Server_SecurePath(state, message, "/tmp");
	configc = Server_SecurePath(state, message, gConfig.patchDirectory);
	if (tmpc == NULL && configc == NULL) {
		PLogmsg(LOGP_NOTICE, "NOTE: SecurePath '%s' '%s' failed\n",
			message, gConfig.patchDirectory);
	} else {
		pre = NULL;
		if (configc != NULL)
			pre = PreformedMessage_ReadFromFile(configc);
		if (pre == NULL && tmpc != NULL)
			pre = PreformedMessage_ReadFromFile(tmpc);

		if (pre != NULL) {
			sprintf(msgbuf,
				gettext("(CHEESE) Downloaded your patch file: %s."), /* DIALOG */
				message);
			Server_SendDialog(state, msgbuf, true);
			Server_SendPreformedMessage(state, pre);
			PreformedMessage_Dispose(pre);
		} else {
			// expecting a valid value in errno here is optimistic
			sprintf(msgbuf,
				gettext("(CHEESE) Could not read your patch file: %s (err %d)."),
				message, errno);
			Server_SendDialog(state, msgbuf, true);
		}
	}

	if (tmpc != NULL)
		free(tmpc);
	if (configc != NULL)
		free(configc);
}

//
// Handle mail sent to "patch" requesting one of the magic gameID changing
// patches.  These have the form "gpN", where "N" is a 1- or 2-digit number.
//
// If n==zero (e.g. "gp00"), the caller wants to have the forced gameID
// thing removed.  On the SNES and later platforms we just send down gameID
// zero, on the original Genesis it's a little fancier.
//
// The usual patch looks like  2D 00 00 00 01 FF WW XX YY ZZ , which is
// just an msSetConstants on one item, replacing ID #255 with 0xWWXXYYZZ.
// Turning it off on Genesis uses  13 60 FF , which is msDeleteItemFromDB
// on element 255 in the DBType for DB constants.
//
// (It's possible that doing the normal patch with -1 as the final
// component would work, since a GetDBConstant on a nonexistent item
// returns -1... but it's a shorter message anyway.)
//
// Returns "true" if the message parsed as a gameID request.  Returns "false"
// if it was a request for some other patch.
//
static Boolean
Server_HandleGameIDPatch(ServerState *state, char *message)
{
	DBID ids[1] = { kForceGameIDConst };
	long vals[1];
	char msgbuf[256];
	extern int atoi(char *);

	if (message == NULL || strlen(message) < 3 || strlen(message) > 4)
		return (false);

	if (strncasecmp(message, "gp", 2) != 0)
		return (false);

	if (!isdigit(message[2]) || (strlen(message) == 4 && !isdigit(message[3])))
		return (false);

	vals[0] = atoi(message+2);

	PLogmsg(LOGP_DETAIL, "Server_HandleGameIDPatch %d\n", vals[0]);
	if (!vals[0] && state->boxOSState.boxType == kBoxType_segb) {
		Server_DeleteDBItem(state, kConstantsDBType, kForceGameIDConst);
	} else {
		Server_SendDBConstants(state, 1, ids, vals);
	}

	if (!vals[0])
		strcpy(msgbuf,
			gettext("(SERVER) Forced gameID value cleared."));	/*DIALOG*/
	else
		sprintf(msgbuf,
			gettext("(SERVER) Your gameID will be forced to 0x%.8lx."),	/*DIALOG*/
			vals[0]);
	Server_SendDialog(state, msgbuf, true);

	return (true);
}

//
// Prepend "path" with "prefix", and make sure there aren't any ".."
// components in the path to mess with us.  This is system-dependent
// (in fact, it's filesystem-dependent).
//
// Returns a pointer to a buffer allocated with malloc on success; it's
// up to the caller to free it.  Returns NULL on failure (usually malloc
// failure or a path with ".." in it).
//
static char *
Server_SecurePath(ServerState *state, char *path, char *prefix)
{
	char *buf;

	PLogmsg(LOGP_PROGRESS, "Server_SecurePath ('%s' '%s')\n", path, prefix);

	if ((buf = (char *)malloc(strlen(path) + strlen(prefix) + 2)) == NULL) {
		PLogmsg(LOGP_FLAW, "ERROR: out of memory in Server_SecurePath mail\n");
		Common_Abort();
	}
	strcpy(buf, prefix);
	strcat(buf, "/");
	strcat(buf, path);
	if (strstr(buf, "/../")) {
		Server_SendDialog(state,
			gettext("No, silly, \"..\" won't work."), true); /* DIALOG */
		return (NULL);
	}

	//Logmsg("dbug: len=%d, alloc=%d\n", strlen(buf),
	//	strlen(path) + strlen(prefix) + 2);

	return (buf);
}

