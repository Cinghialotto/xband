#ifndef	__Server_Pop_h
#define	__Server_Pop_h
#define	k800_CONNECT		0
#define	kX25_FIRST_CONNECT	1
#define	kX25_OTHER_CONNECT	2
Err Server_PopUpdate(ServerState *state, Account *account, userIdentification *userID, phoneNumber *boxPhone_p, phoneNumber *popPhone_p, int x25, int redial);
Err	Server_ValidatePop(char *raw, LOOKUP_POP_P lookup_p, DBID *scriptID_p);
Err	Server_ValidatePopAny(char *raw, DBID *scriptID_p);
int	Server_ValidateAccount(ServerState *state);
void	Server_GamePhoneUpdate(ServerState *state, Account *account, phoneNumber *boxPhone_p);
#endif
