/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_ValidateLogin.c,v 1.107 1996/03/09 18:33:03 fadden Exp $
 *
 * $Log: Server_ValidateLogin.c,v $
 * Revision 1.107  1996/03/09 18:33:03  fadden
 * Added Server_CheckMindWipeFlag.  If set, the box has its OS and DB blow away.
 *
 * Revision 1.106  1996/03/07 14:08:52  fadden
 * Fixed a logmsg in Server_DetermineRestoreAccount.
 *
 * Revision 1.105  1996/02/21  15:17:18  ansell
 * Changed 800 number.
 *
 * Revision 1.104  1996/02/05  15:36:49  fadden
 * Added lots of comments and vertical whitespace to GetAccount and
 * DetermineRestoreAccount while tracking down a bug.  No code changes.
 *
 * Revision 1.103  1996/02/02  15:43:20  chs
 * use gConfig.catapultTown everywhere.
 *
 * Revision 1.102  1996/01/29  17:02:51  ted
 * For CEJ: 1. default to local matching, 2. set customerServiceID to boxid.
 *
 * Revision 1.101  1996/01/25  17:52:08  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.100  1996/01/17  15:37:01  felix
 * Took out 'This smartCard has run out of credits' message and moved it into
 * Server_SmartCards.c
 *
 * Revision 1.99  1996/01/15  19:49:19  hufft
 * japan GamePhone update
 *
 * Revision 1.98  1996/01/15  12:22:40  chs
 * Added code to try to prevent people getting stuck in tourney mode:
 * when we put the box in tourney mode, update the boxflags
 * in segad immediately to minimize the window during which a SIGHUP
 * will cause problems.
 * Also added a gConfig flag to force clearing tourney mode in the box.
 *
 * Revision 1.97  1996/01/10  14:49:24  hufft
 * changed to use libphonedb
 *
 * Revision 1.96  1996/01/05  18:25:03  felix
 * Added support for trustCardOverDB and smartCardFraudOkay gConfig vars
 *
 * Revision 1.95  1996/01/05  17:33:06  jhsia
 * modified two dialogs, according to Eliza
 *
 * Revision 1.94  1996/01/04  22:42:08  hufft
 * added pop mail functions
 *
 * Revision 1.93  1996/01/04  16:35:46  felix
 * Changed args sent to Database_GetDebitCardInfo
 *
 * Revision 1.92  1996/01/03  18:45:11  jhsia
 * modified dialog on line 483 from "need to" to "must"
 *
 * Revision 1.91  1995/12/11  18:00:39  ansell
 * Moved some PLogmsg()s from DBUG up to higher priority since they represented
 * error conditions.
 *
 * Revision 1.90  1995/11/17  19:34:09  felix
 * Access boxAccount.prevSmartCardSerialNumber _after_ boxAccount filled.
 *
 * Revision 1.89  1995/11/15  18:51:39  jhsia
 * changed "customer support" to "Customer Support"
 *
 * Revision 1.88  1995/11/13  19:44:44  hufft
 * pop lookup interface changes, rpc returns a list of pops, and dial patterns
 *
 * Revision 1.87  1995/11/13  18:00:31  felix
 * turned off sticky flag for smartcard dialogs
 *
 * Revision 1.86  1995/11/13  17:16:40  jhsia
 * changed customer service phone number to 408-777-1500
 *
 * Revision 1.85  1995/11/09  17:14:06  jhsia
 * Killed JAPAN_NO_X25 define.  Fixed some bugs in the smartcard stuff, then
 * gave up and added FORCE_DEBIT stuff.
 *
 * Revision 1.84  1995/11/08  21:26:23  jhsia
 * fixed log history
 *
 * Revision 1.83  1995/11/08  18:52:57  jhsia
 * heck the return value on ValidateJX25Connect.  Print some dialogs when
 * we're rejecting their connection.  Added call to SetRandomThings.  Removed
 * T+C ifdef (hey, there's a config option for that).  Put gettext calls
 * around the T+C dialogs.
 *
 * Revision 1.82  1995/11/06  02:56:40  felix
 * Various things to do if gConfig.useDebitCardOnly set: Boot people off who
 * have no debit card installed, get card data from debit card database, boot
 * people off if card expired, boot people off if no credits left, fraud check
 *
 * Revision 1.81  1995/11/01  16:42:46  ansell
 * When we are looping through the terms&conditions mail messages removing "yes"
 * we don't want to decrement our string length variable each time through the
 * loop.
 *
 * Revision 1.80  1995/10/30  17:54:12  jhsia
 * For JAPAN_TESTING, don't do the terms & conditions stuff
 *
 * Revision 1.79  1995/10/30  16:46:14  steveb
 * Environment variables read are now XBAND_ANI and XBAND_X25_ADDRESS.
 *
 * Revision 1.78  1995/10/27  19:43:43  steveb
 * Just did some long needed housecleaning.  No new code.
 *
 * Revision 1.77  1995/10/27  16:14:58  ted
 * Fixed GetBoxTimeZone to correct for DST differences during transitional DST period.
 *
 * Revision 1.76  1995/10/26  17:19:00  ted
 * Fixed DST problem in Server_GetBoxTimeZone.
 *
 * Revision 1.75  1995/10/26  03:39:13  jhsia
 * Added JAPAN_NO_X25 stuff so we can have make-believe ANI connects.  Fixed
 * the translation testing stuff so it doesn't catch on \" embedded in
 * strings.  Added comments with my interpretation of the auto-create logic.
 *
 * Revision 1.74  1995/10/24  16:54:19  ted
 * Japan Account Creation Changes. Ignore CSID in Japan for Terms and Conditions.
 * Added gettext for T+C's mail title and "yes" response.
 *
 * Revision 1.73  1995/10/23  15:10:00  chs
 * Give people 20 tries to agree to the Terms+Conditions instead of 10.
 *
 * Revision 1.72  1995/10/19  22:26:53  hufft
 * Japan Database Changes
 *
 * Revision 1.71  1995/10/17  18:27:16  chs
 * If the account is suspended for T+C failures,
 * don't let the playeraccount be created.
 *
 * Revision 1.70  1995/10/12  19:55:52  roxon
 * Eliminate warning messages in compilation.
 *
 * Revision 1.69  1995/10/12  19:48:46  felix
 * Added initialization of state->origLastMatchup
 *
 * Revision 1.68  1995/10/02  17:50:23  chs
 * Check return value from Server_UpdateBoxDocument().
 *
 * Revision 1.67  1995/10/01  14:38:03  roxon
 * Add translation verification in Server_ValidateLogin().
 *
 * Revision 1.66  1995/09/28  16:42:09  steveb
 * Added the platformID to the message complaining about an unknown cart.
 *
 * Revision 1.65  1995/09/28  15:38:35  hufft
 * Corrected return code filter function
 *
 * Revision 1.64  1995/09/28  14:41:01  hufft
 * Changed to match Catapults RPC convention
 *
 * Revision 1.63  1995/09/27  18:38:34  hufft
 * added Common_Phone support for Japan Server
 *
 * Revision 1.62  1995/09/27  15:50:00  chs
 * Changed FindAccessCode to FindUCAInfo.
 *
 * Revision 1.61  1995/09/20  10:58:47  chs
 * Made Server_AgreeToTermsAndConditions() return a special error code
 * to indicate to its caller that this is not a real error.
 * Made T+C mail-parsing code return better error messages to the user.
 * Use the new flag in ServerState to indicate that a connect is the one
 * on which the user made it past the T+C check.
 * Change the T+C success Logmsg to include the number of tries it took.
 * Add the boxID to all T+C Logmsg's that didn't already have it.
 *
 * Revision 1.60  1995/09/18  14:04:04  chs
 * Add the boxID to the T+C Logmsg's that didn't already have it.
 *
 * Revision 1.59  1995/09/17  21:50:37  fadden
 * Added call to Server_CheckInvalidChallenge.
 *
 * Revision 1.58  1995/09/13  14:24:53  ted
 * Fixed warnings.
 *
 * Revision 1.57  1995/09/12  14:57:40  chs
 * Change the T+C X-Mail message for sega.
 *
 * Revision 1.56  1995/09/11  15:38:00  chs
 * Added Terms+Conditions code.
 *
 * Revision 1.55  1995/08/31  20:52:18  hufft
 * Another off by one for japan phone numbers, patched but not happy.
 *
 * Revision 1.54  1995/08/30  19:37:44  hufft
 * Offbby 1 error in VAlidate JX25 code. Wasn't dropping 'S' from simulator
 *
 * Revision 1.53  1995/08/28  17:04:43  hufft
 * Added test for Jap SNES machine, before doing "-" test
 *
 * Revision 1.52  1995/08/28  16:40:00  hufft
 * Removed dead variables, corrected missing exit condition in Server_ValidateJX25Connect.
 *
 * Revision 1.51  1995/08/26  11:20:50  roxon
 * Replace Common_PhoneLocale() with LOCALE_PHONE_xxx().
 *
 * Revision 1.50  1995/08/25  17:36:06  ted
 * Fixed some Rich bugs.
 *
 *
 * Revision 1.49  1995/08/24  19:30:37  rich
 * Added Japan phone validation code: Server_ValidateJX25Connect() and
 * Server_ValidateJ0120Connect().  The LATA database call is stubbed out, though.
 *
 * Revision 1.48  1995/08/21  16:03:56  ansell
 * Put in hack to force intel boxes to allow longdistance.
 *
 * Revision 1.47  1995/07/28  16:58:38  rich
 * Re-fixed my re-screwup with smart quotes, gettext(), default info + taunt.
 *
 * Revision 1.46  1995/07/27  19:53:07  rich
 * Fixed my screwup with smart quotes, gettext(), and default info and taunt.
 *
 * Revision 1.45  1995/07/27  16:47:42  fadden
 * Put the smart quotes back into GetDefaultTauntAndInfo.  Removed the
 * gettext() calls.  The 'sjne' version needs to be internationalized.
 *
 * Revision 1.44  1995/07/20  13:49:14  ted
 * Read box's challenge area toggle state regardless of area restrictions set up.
 *
 * Revision 1.43  1995/07/17  18:40:47  fadden
 * Hmm, make that DO_LOG_NETERRS.
 *
 * Revision 1.42  1995/07/17  18:39:29  fadden
 * LRA: changed some logmsgs to LOGP_DETAIL.
 *
 * Revision 1.41  1995/07/17  15:45:11  fadden
 * Added a few comments.
 *
 * Revision 1.40  1995/07/10  21:13:10  rich
 * Added Japanese SNES platform (kPlatformSJNES).
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.39  1995/07/10  10:46:07  ted
 * Call Server_SetBoxAccountPops to update pops.
 *
 * Revision 1.38  1995/07/04  22:53:58  fadden
 * Changed the Common_CompareHardwareID calls.
 *
 * Revision 1.37  1995/06/19  20:49:47  fadden
 * Changes to GetAccount & friends to support HardwareID restores.  Added
 * Server_NukeTheWorld.  Don't do "munge dial 9" account lookup on non-Genesis.
 * Avoid sending 7-digit number to closed accounts, to avoid extra 800/X.25
 * bounces should we decide to restore them.
 *
 * Revision 1.36  1995/06/19  11:19:24  ted
 * Observe snes box's challenge area!
 *
 * Revision 1.35  1995/06/15  17:04:44  ted
 * Fixed ascii output for server vs. local time.
 *
 * Revision 1.34  1995/06/15  15:22:39  fadden
 * Removed RELOCATE_USERS #define.
 *
 * Revision 1.33  1995/06/12  17:13:05  fadden
 * Changed 800-X4-XBAND to 1-800-X4-XBAND to make Joey happy.
 *
 * Revision 1.32  1995/06/10  23:16:32  fadden
 * Enable RELOCATE_USERS on 1-800 connects.
 *
 * Revision 1.31  1995/06/08  11:14:14  ted
 * Get time zone info from rpc.segad for state->localConnectTime.
 *
 * Revision 1.30  1995/06/07  14:01:17  fadden
 * Added (commented out) code to force all SNES boxes connecting to 1-800
 * to use CATAPULT,SEGA.
 *
 * Revision 1.29  1995/06/03  19:45:39  fadden
 * Added Server_ValidateHardwareID.
 *
 * Revision 1.28  1995/06/02  20:56:57  fadden
 * Use the actual random value instead of TEMP_RANDOM.
 *
 * Revision 1.27  1995/06/01  15:08:31  fadden
 * Merge in from newbr.
 * -> Significant changes to the way accounts are looked up and initialized.
 *
 * Revision 1.26  1995/05/23  16:40:18  ted
 * XBAND Nationwide. Read box accept challenge flag and interpret as challenge area
 * for Sega if gConfig.overrideSegaAcceptChallenges is set.
 *
 * Revision 1.25.2.6  1995/05/31  17:20:58  fadden
 * Added another test case.
 *
 * Revision 1.25.2.5  1995/05/27  00:16:51  fadden
 * Rearranged GetAccount so that it tries to get the account immediately,
 * then falls into the restore stuff if there was a failure.
 *
 * Revision 1.25.2.4  1995/05/26  18:06:39  fadden
 * Added more test cases.
 *
 * Revision 1.25.2.3  1995/05/24  01:20:22  fadden
 * Implemented NonUCACreate.
 *
 * Revision 1.25.2.2  1995/05/22  03:23:47  fadden
 * (Another) serious rewrite of the way account lookups are done.
 * First cut at new restore stuff; needs much testing and some features.
 *
 * Revision 1.25.2.1  1995/05/18  06:08:45  fadden
 * Busily thrashing the code.
 *
 * Revision 1.25  1995/05/11  05:49:45  fadden
 * Moved NoLogin check, Cookie grab, and Server_IsXBANDOnline function to
 * ServerCore.c.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <memory.h>
#include <sys/types.h>
#include <sys/time.h>

#include <strings.h>

#include "Server.h"
#include "ServerCore.h"
#include "ServerState.h"
#include "ServerDataBase.h"
#include "Server_Pop.h"
#include "PhoneDB.h"
#include "SvrNews_Interface.h"

#include "Messages.h"
#include "UsrConfg.h"
#include "Challnge.h"
#include "SegaIn.h"
#include "DBConstants.h"
#include "StringDB.h"
#include "DBTypes.h"

#include "FilterHandle.h"

#include "Common.h"
#include "Common_Missing.h"
#include "Common_Log.h"
#include "Common_ReadConf.h"

//
// Local prototypes.
//
static	Err Server_ValidateLoginExit(Err err);
static Err Server_AgreeToTermsAndConditions(ServerState *state);
static	void	Server_MakeNewPhoneNumber(ServerState *state, userIdentification *userID, SuperPhone_P newBoxPhone_p, phoneNumber * newAccessPhoneNumber);
static	Err	Server_ValidateNumberIfChanged(ServerState *state, SuperPhone_P newBoxPhone_p, int *newPhoneFlag);
static	void	Server_IntelCallingAreaHACK(ServerState *state);
static	void	Server_SetSNES_CallingArea(ServerState *state);
static	void	Server_UnNeededDB_Wipe(ServerState *state);
static	Err	Server_DetermineRestoreAccount(ServerState *state, userIdentification *userID, Account **accountp, long *statusFlags,BoxSerialNumber *box, Err *findErr);
static	Err	Server_SharedPhoneNumber(ServerState *state, char *buf_p);
static Err Server_GetAccount(ServerState *state, Account **accountp);
static Err Server_NonUCACreate(ServerState *state, BoxSerialNumber *boxp);
static Err Server_PrepareNewAccount(ServerState *state);
static Boolean Server_FilterHandle(ServerState *state);
static Err Server_SendChangedHandle(ServerState *state, userIdentification *oldID, int didUniquify);
static Err Server_InitTauntAndInfo(ServerState *state);
static int Server_sega_GetDefaultTauntAndInfo(ServerState *state, char **tauntp, char **infop);
static int Server_snes_GetDefaultTauntAndInfo(ServerState *state, char **tauntp, char **infop);
static int Server_sjne_GetDefaultTauntAndInfo(ServerState *state, char **tauntp, char **infop);
static int Server_any_GetDefaultTauntAndInfo(ServerState *state, char **tauntp, char **infop);
static Err Server_ValidateHardwareID(ServerState *state);
static Err Server_ValidateJ0120Connect(ServerState *state, userIdentification *userID);
static Err Server_ValidateJX25Connect(ServerState *state, SuperPhone_P newBoxPhone_p);
static void MarkBoxPhoneBad(char *phone);
static	int	Server_CheckAccountPhoneNumber(ServerState *state, SuperPhone_P newBoxPhone_p);
static	void	Server_ValidateX25Connect(ServerState *state, SuperPhone_P newBoxPhone_p, int *newPhoneFlag);
static	int	Server_Validate800Connect(ServerState *state, char *ani_cp);
static	int	Server_Validate800ANI(ServerState *state, char **ani_cp, SuperPhone_P phone_p);
static	int	Server_HandleInvalidConnectNumber(ServerState *state, Boolean found_mail, SuperPhone_P newBoxPhone_p, userIdentification *catapult);
static	int	Server_DefaultX25(ServerState *state, userIdentification *userID, SuperPhone_P newBoxPhone_p, phoneNumber * newAccessPhoneNumber);
static	void	Server_CheckPlayerQueStatus(ServerState *state);
static	void Server_SetPlayerChallenges(ServerState *state);
static	void   Server_ForceBoxRedial(ServerState *state, long tell_user);
static Err Server_SetupJapanAccount(ServerState *state, Account *account);
static Err Server_DownloadPOP800Connect(ServerState *state, SuperPhone *newBoxPhone);
static int Server_CheckMindWipeFlag(ServerState *state);
#ifdef DO_LOG_NETERRS
static	void	Server_LogNetErrs(ServerState *state, userIdentification *userID, char *ani_cp);
#endif

void translation_verification(ServerState *);

//
#ifdef NUKE_THE_WORLD
static Err Server_NukeTheWorld(ServerState *state);
#endif
//#define TESTING_BOX_RESTORE
#ifdef TESTING_BOX_RESTORE
static Err Server_MangleLogin(ServerState *state);
#endif

// #ifdef T9N_VERIFY
//
// It may need to be ifdef'ed for less distraction to real running.
// However, the performance penality should be very small - an extra
// function call and a system call. That's it.
//
void
translation_verification(state)
ServerState *state;
{
	char    msgbuf[2048];
	char    allmsg[128][2048];
	FILE    *fd;
	int     len = 0;
	int     msgnum = 0;
	char    c;
	int     i;
	char    *head, *tail;

	fd = fopen("/tmp/xxx_sunsega_msg_t9n_verify.po", "r");
	if ( fd == NULL ) { // No message file to test. Go back to normal
		return;
	}

	memset(msgbuf, 0, 2048);

	strcpy(allmsg[0], "Start translation verification");
	msgnum++;

	while (msgnum < 126) {
		c = getc(fd);
		if (c == EOF) break;
		if ( c == 0x0a || c == 0x20 || c == 0x09 ) continue;

		msgbuf[0] = c;
		len = 1;

		while (1) {
			c = getc(fd);
			if (  c == 0x0a || c == EOF ) {
				msgbuf[len] = 0;
				break;
			}

			msgbuf[len++] = c;
		}

		if ( strncmp(msgbuf, "msgstr", 6) )
			continue;

		// Find the leading quote.
		head = msgbuf + 6;
		while (1) {
			if ( *head == 0x22 ) {
				head++;
				break;
			}
			head++;
		}

		// Find the trailing quote.  Don't be fooled by \" .
		tail = head;
		while (1) {
			if ( (*tail == 0x22) && (*(tail-1) != '\\') ) {
				break;
			}
			tail++;
		}

		strncpy(allmsg[msgnum], head, tail - head);
		allmsg[msgnum][tail - head + 1] = 0;
		msgnum++;
	}

	fclose(fd);

	if ( msgnum == 126 ) {
		strcpy(allmsg[1], "Your message file for verification has too many messages in it. Please try again after splitting it with no more than 100 msgstr'd in each.");
		msgnum = 2;
	}

	strcpy(allmsg[msgnum], "End translation verification");

	for (i = msgnum; i >= 0; i--) {
		Server_SendDialog(state, allmsg[i], true);
	}
}
// #endif



// ===========================================================================
//		Login processing
// ===========================================================================

//
// Validate the incoming user.
//
// For a while this was called before all data was received from the box,
// but that is no longer the case.  We still need to use "abandonShip",
// because not sending any news will screw new Genesis boxes up.
//
int
Server_ValidateLogin(ServerState *state)
{
userIdentification 	*userID;
Err					err;
phoneNumber 		newAccessPhoneNumber;
int					newPhoneFlag = false;
char				*ani_cp;
SuperPhone			newBoxPhone;

	PLogmsg(LOGP_PROGRESS, "Server_ValidateLogin\n");
	ASSERT(state->validFlags & kServerValidFlag_BoxPhoneNumber);
	ASSERT(state->validFlags & kServerValidFlag_Login);
	ASSERT(state->validFlags & kServerValidFlag_platformID);

	userID = &state->loginData.userID;

	state->accountCreated = false;
	state->playerCreated = false;

#ifdef NUKE_THE_WORLD
	return (Server_NukeTheWorld(state));
#endif


#ifdef FORCE_DEBIT
	if (!gConfig.useDebitCardOnly) {
		Logmsg("Forcing 1 debit\n");
		Server_SendDebitSmartcard(state, 1);
	}
#endif

	if (gConfig.useDebitCardOnly) {

    //
    // Deny service if we're in debit-card-only mode and no debit card installed
    //

		if (state->creditDebitInfo.usingType != kUsingDebitCard) {
        	PLogmsg(LOGP_PROGRESS, "DebitCardOnly set, but state->creditDebitInfo.usingType != kUsingDebitCard, bailing\n");
        	Server_SendDialog(state,
            	gettext("You must have an XBAND SmartCard installed to use XBAND."), /* DIALOG */
            	false);
        	return (kServerFuncEnd);
		}

	state->currentCard = malloc(sizeof(DebitCardDBInfo));
	memset(state->currentCard, 0, sizeof(DebitCardDBInfo));

	//
	// Get info from debit card database about the card currently installed
	//

	PLogmsg(LOGP_PROGRESS, "SmartCard serial number %d\n",state->creditDebitInfo.debitCardInfo.serialNumber);
		if ((err = 
			Database_GetDebitCardInfo(state, 
				state->creditDebitInfo.debitCardInfo.serialNumber,
				state->currentCard)) != kNoError) 
				return(Server_ValidateLoginExit(err));

	// see if current card expired.

		if ((state->currentCard->timeExpired < time(NULL)) &&
			(state->currentCard->timeExpired != 0)) {
        	Server_SendDialog(state,
            	gettext("Time for a new XBAND SmartCard! This one has expired."), true); /* DIALOG */
        	return (kServerFuncEnd);
			}

	// see if card has fewer credits than database.
	// (...Ignored, unless trustCardOverDB is set)

		if (gConfig.trustCardOverDB && 
			state->creditDebitInfo.debitCardInfo.creditsLeft < 
				state->currentCard->actualBalance ) {
			unsigned char	status;

			PLogmsg(LOGP_PROGRESS, "SmartCard has %d credits, actualBalance %ld credits -- updating actualBalance to match card\n",state->creditDebitInfo.debitCardInfo.creditsLeft, state->currentCard->actualBalance);

			// debit down database to match card balance

			status = SmartCardDBDebit(
				state->creditDebitInfo.debitCardInfo.serialNumber,
				state->currentCard->actualBalance -
				state->creditDebitInfo.debitCardInfo.creditsLeft);

			if (status != kAck)  {
				PLogmsg(LOGP_FLAW,
					"Server_ValidateLogin: Unknown ret code (%d) from SmartCardUpdateFormerBalance\n", status);
					return(kServerFuncEnd);
			}

			// update current balance to match card balance
			// update former balance as well, to avoid fraud-o-sensor

			state->creditDebitInfo.currentCredits =
			state->currentCard->formerBalance =
				state->creditDebitInfo.debitCardInfo.creditsLeft;
		}

	// see if current card out of credits

		if (state->currentCard->actualBalance <= 0) {
			state->currentCard->actualBalance = 0;
			Server_UpdateDebitCard(state);
        	return (kServerFuncEnd);
			}
	}

	// See if we have ANI via 1-800.  Sometimes we get bogus data, so
	// do a sanity-check on it to be sure.
	//
	state->connect800 = false;
	ani_cp = getenv("XBAND_ANI");
	if (ani_cp != NULL)
		PLogmsg(LOGP_DETAIL, "XBAND_ANI='%s'\n", ani_cp);

#ifdef JAPAN_NO_X25
	if (ani_cp == NULL && (state->boxOSState.boxFlags & kCurUserMoved)) {
		PLogmsg(LOGP_NOTICE, "OHAYO: kCurUserMoved, pretending ANI\n");
		ani_cp = "fake ANI";
	}
#endif	/*JAPAN_NO_X25*/

	// #ifdef T9N_VERIFY
	// do message translation verification
	// it will simply return if there is no po file to be tested.
	// It is just an extra function call and a system call for real run.
	//
	translation_verification(state);
	// done
	// #endif

	if (LOCALE_PHONE_JA())
	{
		// Handle Japanese connects.  If the XBAND_ANI env var is set to
		// anything at all, then it was an 800 connect.  The actual value
		// of XBAND_ANI is irrelevant.
		//
		if (ani_cp != NULL)
		{
			return(Server_ValidateLoginExit(Server_ValidateJ0120Connect(state, userID)));
		}

		// XBAND_ANI was not set, so it was an X.25 connection.  Handle both
		// cases: 1) initial X.25 connect after 800 connect, and 2) all
		// subsequent X.25 connects.  Fall through all the way down to
		// account verification.
		//
		if (Server_ValidateJX25Connect(state, &newBoxPhone) != kNoError)
			return(kServerFuncEnd);
		if ((err = Server_ValidateAccount(state)) != kNoError) {
			return(Server_ValidateLoginExit(err));
		}
		// When account is first created, phone number *is* different than NULL
		if (state->accountCreated)
			newPhoneFlag = true;
	}
	else if (ani_cp != NULL)
	{
		return(Server_ValidateLoginExit(Server_Validate800Connect(state, ani_cp)));
	}
	else
	{
		Server_ValidateX25Connect(state, &newBoxPhone, &newPhoneFlag);
		if ((err = Server_ValidateAccount(state)) != kNoError)
		{
			return(Server_ValidateLoginExit(err));
		}
	}

	//
	// [ At this point, state->account should be valid for all cases. ++ATM ]
	//

	if ((err = Server_ValidateNumberIfChanged(state, &newBoxPhone, &newPhoneFlag)) != kNoError)
	{
		Logmsg("Server_ValidateNumberIfChanged error:%d\n", err);
		return(Server_ValidateLoginExit(err));
	}

	//
	// If this was an ANI call, set their box phone number, POP phone number,
	// and home town.
	//
	// We can't just set the box phone number if it's changed, since we now
	// strip the area code off and can't do a clean comparison.  These aren't
	// exactly huge bandwidth wasters anyway.
	//
	//	newPhoneFlag is true when US X.25 calls with a 10-digit number
	// (apparently it is now also true on an X.25 connect in Japan when an
	// account is created)
	//
	if (newPhoneFlag)
	{	
		Server_MakeNewPhoneNumber(state, userID, &newBoxPhone, &newAccessPhoneNumber);
	}
	else
	{
		err = Server_DefaultX25(state, userID, &newBoxPhone, &newAccessPhoneNumber);
		if (err != kNoError)
		{
			return(Server_ValidateLoginExit(err));
		}
	}

	if ((err = Server_CheckAccountPhoneNumber(state, &newBoxPhone)) != kNoError)
	{
		return(Server_ValidateLoginExit(err));
	}

#ifdef DO_LOG_NETERRS
	Server_LogNetErrs(state, userID, ani_cp);
#endif	/*DO_LOG_NETERRS*/

	//
	// Now that all the phone crap is out of the way, let's see if we want
	// to wipe this guy's mind.
	//
	if ((err = Server_CheckMindWipeFlag(state)) != kServerFuncOK)
		return (err);
 
#define	INTEL_HACK
#ifdef	INTEL_HACK
	Server_IntelCallingAreaHACK(state);
#endif

	Server_SetPlayerChallenges(state);

	Server_SetSNES_CallingArea(state);

	Server_CheckPlayerQueStatus(state);

	// At this point, boxAccount has been populated.

	if (gConfig.useDebitCardOnly) {

	//
	// If card used on last successful connect is the same as the card used on
	// the current connect, assingn prevCard to point to currentCard.
	// Otherwise, get info from debit card database about previous card.
	//

		PLogmsg(LOGP_PROGRESS, "Previous SmartCard Serial Number == %ld\n",
			state->account->boxAccount.prevSmartCardSerialNumber);

		if ((state->creditDebitInfo.debitCardInfo.serialNumber ==
			state->account->boxAccount.prevSmartCardSerialNumber) ||
			(state->account->boxAccount.prevSmartCardSerialNumber == 0))

			state->prevCard = state->currentCard;     

		else {
			state->prevCard = malloc(sizeof(DebitCardDBInfo));
			memset(state->prevCard, 0, sizeof(DebitCardDBInfo));
			if ((err = Database_GetDebitCardInfo(state, 
				state->account->boxAccount.prevSmartCardSerialNumber,
				state->prevCard)) != kNoError) 
			{
				return(Server_ValidateLoginExit(err));
			}
 		}

	//
	// Fraud check:  If card has more credits now than it did on last connect,
	// send fraud dialog and terminate the connection.
	//

		if (state->currentCard->formerBalance < 
			state->creditDebitInfo.debitCardInfo.creditsLeft) {

	        char buf[1024];
			if (gConfig.smartCardFraudOkay) {
				sprintf(buf,"Smartcard fraud detected, but ignored -- Card Number %ld, Credits %d, Credits on last login %ld\n", 
					state->creditDebitInfo.debitCardInfo.serialNumber,
					state->creditDebitInfo.debitCardInfo.creditsLeft,
					state->currentCard->formerBalance);
        		PLogmsg(LOGP_PROGRESS, buf);
			} else {
				sprintf(buf,"XBAND SMARTCARD FRAUD -- Card Number %ld, Credits %d, Credits on last login %ld\n", 
					state->creditDebitInfo.debitCardInfo.serialNumber,
					state->creditDebitInfo.debitCardInfo.creditsLeft,
					state->currentCard->formerBalance);
        		PLogmsg(LOGP_PROGRESS, buf);
	
        		Server_SendDialog(state,
            		gettext("There is something wrong with your XBAND SmartCard.  Please call Customer Service."), true); /* DIALOG */
        		return (kServerFuncEnd);
			}

		}

	// Update 'former balance' for current card for fraud checking on next connect.

		state->currentCard->formerBalance =
			state->creditDebitInfo.debitCardInfo.creditsLeft;

	// Initialize currentCredits.  currentCredits is the variable debited until 
	// it's certain that this is a successful connect, at which time 
	// prevCard->actual balance is updated.

		state->creditDebitInfo.currentCredits = state->prevCard->actualBalance;

    } 

	// Store the original account lastMatchup info in state, because the 
	// lastMatchup info in account can change during the course of the connect

	state->origLastMatchup = malloc(sizeof(LastMatchup));
	ASSERT(state->origLastMatchup);
	memcpy(state->origLastMatchup,
		&state->account->boxAccount.lastMatchup,
		sizeof(LastMatchup));

	// If this isn't a Sega Genesis 1.0 ROM, we don't need to deal with this
	// abandonShip stuff.  (Of course, several different places in the code
	// set abandonShip and then return, so this statement doesn't always
	// catch stuff... still need to trap it in SendKoolStuff.)
	//
	if ((state->platformID != kPlatformGenesis) && state->abandonShip) {
		Logmsg("Abandon ship (in VL)!\n");
		return (kServerFuncEnd);
	}

	Server_UnNeededDB_Wipe(state);

	// At this point we have a valid account->boxAccount.gamePhone.
	// Get the time zone of the caller based on this phone number.
	Server_GetBoxTimeZone(state);
	

	// If we can't charge a credit to people who do "challenge" requests
	// with an invalid cartridge, don't let them on at all.
	//
	if (Server_CheckInvalidChallenge(state)) {
        Logmsg("'%.4s' Terminating invalid challenge connect\n",
            (char *)&state->platformID);
		return (kServerFuncEnd);
	}

	/* hack to prevent boxes from getting stuck in tourney-mode */
	state->origBoxFlags = state->account->boxAccount.boxFlags;

	PLogmsg(LOGP_PROGRESS, "Server_ValidateLogin done\n");
	return(kServerFuncOK);
}



//
// Convert any errors into legal exit error codes
//
// [ This is stupid, fix the guys passing the bad error codes. ++ATM ]
//
static	Err Server_ValidateLoginExit(Err err)
{
	switch(err)
	{
	case	kNoError:
	case	kServerFuncAbort:
		return(err);
	default:
		PLogmsg(LOGP_FLAW, "WARNING: Odd vl exit code %d\n", err);
		return(kServerFuncEnd);
	}
}
//
// HUFFT	if we got the account, then we need to compare the new number with the old
//			number, and do a lata validate if it's different 
//
static	Err	Server_ValidateNumberIfChanged(ServerState *state, SuperPhone_P newBoxPhone_p, int *newPhoneFlag)
{
	Err err;

	//
	// needs an npa to compare with anything
	//
	if (newBoxPhone_p->npa)
	{
		//
		// NOTE: if they previously sent up "3-55734371", and now they
		// send up "03-55734371", the server won't notice the change
		// because the compare function ignores the leading zero.  So
		// it is up to the server to ensure that the leading zero is
		// prepended wherever necessary.  ++ATM 951031
		//
		if (Common_PhoneCompareNumbers(state->account->boxAccount.gamePhone.phoneNumber,
			newBoxPhone_p->p.phoneNumber))
		{
			*newPhoneFlag = true; // new b/c phone number is different
			PLogmsg(LOGP_NOTICE, "Server_ValidateNumberIfChanged:account:%s:box:%s\n",
				state->account->boxAccount.gamePhone.phoneNumber,newBoxPhone_p->p.phoneNumber);
			err = PhoneDB_ValidateNumber(newBoxPhone_p);
			if (err != kNoError) {
				Server_SendDialog(state,
					gettext("Your phone number does not appear to be valid as entered. Please verify that it was entered correctly."),	/* DIALOG */
					true);
				return (kServerFuncEnd);
			}
			//
			// for Japan, force GamePhone update
			//
			if (LOCALE_PHONE_JA())
			{
				Server_GamePhoneUpdate(state, state->account, &newBoxPhone_p->p);
			}
		}
	}
	return(kNoError);
}
#ifdef	INTEL_HACK
static	void	Server_IntelCallingAreaHACK(ServerState *state)
{
	// Really disgusting hack to make sure all 'intl' (Intel) boxes
	// have long distance enabled.
	//
	if (state->platformID == kPlatformIntel) {
		PLogmsg(LOGP_NOTICE, "Forcing long distance enable for Intel box\n");
		state->account->boxAccount.restrictArea |= kRestrictArea_dialLongDistance;
		state->account->boxModified |= kBA_restrictInfo;
	}
}
#endif
static	void	Server_SetSNES_CallingArea(ServerState *state)
{
	int old;
	int new;

	if (state->platformID == kPlatformSNES || state->platformID == kPlatformSJNES)
	{
		old = state->account->boxAccount.restrictArea & kRestrictArea_dialLocalPreferred;
		new = (state->niftyInfo.snes.callingArea != 0) * kRestrictArea_dialLocalPreferred;
		if (old != new)
		{
			if (new)
			{
				state->account->boxAccount.restrictArea |= kRestrictArea_dialLocalPreferred;
			}
			else
			{
				state->account->boxAccount.restrictArea &= ~kRestrictArea_dialLocalPreferred;
			}
			state->account->boxModified |= kBA_restrictInfo;
			Logmsg("New preference for challenge area (%s)\n", 
				state->account->boxAccount.restrictArea & kRestrictArea_dialLocalPreferred
				? "local" : "long" );
		}
	}
}
//
// According to Andy McFadden,
// this harmless, sometimes useful.
//
static	void	Server_UnNeededDB_Wipe(ServerState *state)
{
	// Minor bit of fun to count the #of successful server connects between
	// DB wipes.  This is no longer necessary.
	//
	if (!state->abandonShip && (state->platformID == kPlatformSNES ||
			state->platformID == kPlatformSJNES)) {
		unsigned long stable = state->boxOSState.osFree >> 16;
		DBID id = kServerBlessedDatabaseConst;
		if (stable < 65535)
			stable++;
		PLogmsg(LOGP_DBUG, "Sending JoshIsStable(%d)\n", stable);
		Server_SendDBConstants(state, 1, &id, &stable);
	}
}
// ===========================================================================
//		Account retrieval/restore/initialization
// ===========================================================================

/*
My read of the code, for a server in Japan:

is_production FALSE, auto_ja_create_acct FALSE:
	"Not a production server, so allowing account creations" code
	"/xband/unlimitedcredits/monthly" in Server_NonUCACreate

is_production FALSE, auto_ja_create_acct TRUE:
	"Creating new CEJ server account."
	"/xband/unlimitedcredits/monthly"

is_production TRUE, auto_ja_create_acct FALSE:
	"You do not have an account with XBAND.  Please call 800-700-8266 to set up your account."

is_production TRUE, auto_ja_create_acct TRUE:
	"Creating new CEJ server account."
	"/xband/smartcard/ja" + Server_SetupJapanAccount()
*/

//
// Look up the account.
//
// If the box needs to be restored, restore it.
// If the account needs to be created, create and initialize it.
// If the account doesn't exist, yell at the user and bail.
//
// Either returns kNoError with the found account in *account, or
// returns an appropriate error status.
//
static	Err
Server_GetAccount(ServerState *state, Account **accountp)
{
	userIdentification	*userID, oldID;
	BoxSerialNumber		box;
	Boolean				handleWasFiltered;
	Err					err, restoreErr, findErr;
	long				result, statusFlags;
	int					startOverCount = 0;

	PLogmsg(LOGP_PROGRESS, "Server_GetAccount\n");

#ifdef TESTING_BOX_RESTORE
	if (!gConfig.isProduction || (!LOCALE_PHONE_JA())) {
		Server_MangleLogin(state);
	}
#endif

start_over:		// for hardwareID mismatch only
	// Sanity check to avoid infinite loops.
	//
	if (startOverCount > 1) {
		PLogmsg(LOGP_FLAW, "ERROR: start_over repeated; fail\n");
		return (kServerFuncAbort);
	}
	startOverCount++;


	userID = &state->loginData.userID;
	*accountp = NULL;
	findErr = 0;

	//
	// Look up the account, doing a restore if necessary.
	//
	restoreErr = Server_DetermineRestoreAccount(state, userID, accountp,
		&statusFlags, &box, &findErr);

	// If we failed to find the account, inform them and bail now.
	//
	if (restoreErr == kServerFuncAbort || restoreErr == kServerFuncEnd) {
		return (restoreErr);

	} else if (restoreErr == kNoSuchBoxAccount) {
need_call_uca:
		if (LOCALE_PHONE_JA() && gConfig.jaAutoCreateAccount)
		{
			// In Japan, accounts are created automagically regardless of
			// production state.
			Logmsg("Creating new CEJ server account.\n");
			if (Server_NonUCACreate(state, &box) != kNoError) {
				Server_SendDialog(state,
					gettext("Sorry, unable to create a new account for you. "
					"Please call XBAND Customer Service."), /* DIALOG */
					true);
				return (kServerFuncEnd);
			}
			Server_SendDialog(state,gettext("XBAND has created a new account for you! "
				"If this is unexpected, please contact Customer Support."), true);
			restoreErr = kNewAccount;	// act like we found a UCA-created acct
		}
		// otherwise, default is U.S. Server
		else if (gConfig.isProduction)
		{
			// They need to set up an account with UCA.
			Server_SendDialog(state,
				gettext("You do not have an account with XBAND.  Please call 800-700-8266 to set up your account."), /* DIALOG */
				true);
			return (kServerFuncEnd);
		}
		else
		{
			// Not a production server, create an account.  Box serials will
			// be placed into "box".
			//
			Logmsg("Not a production server, so allowing account creations.\n");
			if (Server_NonUCACreate(state, &box) != kNoError)
			{
				Server_SendDialog(state,
					gettext("Sorry, unable to create a new (non-production) account for you."), /* DIALOG */
					true);
				return (kServerFuncEnd);
			}
			restoreErr = kNewAccount;	// act like we found a UCA-created acct
#ifdef TESTING_BOX_RESTORE
			//PLogmsg(LOGP_FLAW, "Exiting after new account create\n");
			//exit(5);
#endif
		}

	} else if (restoreErr == kReplacementAccount) {
		// This happens after we send them a "are you sure you want to
		// use this account on your modem?" mail.
		//
		PLogmsg(LOGP_PROGRESS, "GetAccount: got kReplacementAccount,bailing\n");
		return (kServerFuncEnd);
	}

	// Sanity check.
	//
	if (restoreErr != kNoError && restoreErr != kNewAccount &&
		restoreErr != kNoSuchUserAccount && restoreErr != kNoSuchBoxAccount)
	{
		PLogmsg(LOGP_FLAW, "Unexpected restoreErr value %d\n", restoreErr);
		return (kServerFuncAbort);
	}


	// This gets executed if we did a restore, since we only have the serials
	// and not the account.
	//
	findErr = restoreErr;
	if (*accountp == NULL) {
		// Look up the account and see what we get.
		//
		// (NOTE: if restoreErr == kNewAccount, the FindAccount call will
		// find the UCA stub box account but not the player account, so it'll
		// be treated like kNoSuchUserAccount, but "statusFlags" will have
		// kFindAccountStatusNew set.)
		//
		Logmsg("Looking up account by serials(B) (%ld,%ld)[%d]\n",
			box.box, box.region, state->loginData.userID.userID);
		findErr = WrapperDB_FindAccountBySerial(&box,
			state->loginData.userID.userID, &statusFlags, accountp);
		if (statusFlags & kFindAccountStatusBoxOnly) {
			// Changed semantics: instead of returning kNoSuchUserAccount
			// and no account, it now returns just the boxAccount.
			//
			if (*accountp != NULL)
				DataBaseUtil_FreeAccount(*accountp);
			*accountp = NULL;
		}
	}

	// Some calls want a userID (i.e. the structure, not a playerNum) as an
	// argument.  Stuff the values from box into state->loginData.userId.box
	// so we can use that.  (This is either a no-op, or we're overwriting
	// (-1,-1) with the real value after a restore... the restore code might
	// not touch loginData.)
	//
	state->loginData.userID.box = box;

	// Three simple cases (which is what we had after the roto-rooter job
	// of 94/09/07... let's try to keep it from expanding to 400+ lines
	// this time).
	//
	switch (findErr) {
	case kNoError:
		// Box and player both existed, yay!
		//
		state->validFlags |= kServerValidFlag_Account;

		// If he changed his handle, filter it and update the DB.  Note this
		// is NOT a CompareStrings (which should be "CompareHandles" or
		// something equally meaningful), though we don't have to re-uniqify
		// it if the CompareStrings matches.  (We want to restore and
		// display their player names to be exactly what they were before.)
		//
		if (strcmp(userID->userName, state->account->playerAccount.userName) != 0)
		{
			handleWasFiltered = Server_FilterHandle(state);
			oldID = *userID;	// grab it after filtering

			// Update the DB with the (possibly filtered) handle.  The DB will
			// attempt to uniquify it.
			//
			// 950717: NewUpdateUserHandle is actually just UpdateUserHandle.
			//
			if ((err = WrapperDB_NewUpdateUserHandle(userID, state->platformID,
				state->account, &result)) != kNoError)
			{
				PLogmsg(LOGP_FLAW,
					"ERROR: Found account, but unable to UpdateUserHandle (%d)\n",
					err);
				PLogmsg(LOGP_FLAW, "       Had (%ld,%ld)[%d] '%s'\n",
					userID->box.box, userID->box.region, userID->userID,
					userID->userName);
				return (kServerFuncAbort);
			}

			if (handleWasFiltered || (result & kUserNameUniquified)) {
				if ((err = Server_SendChangedHandle(state, &oldID,	// yes, old
					result & kUserNameUniquified)) != kNoError)
				{
					return (err);
				}
			}
		}
		break;

	case kNoSuchUserAccount:
		// use CreatePlayerAccount or CreateBoxAndPlayerAccount to set it up,
		// then initialize stuff
		//
		if (statusFlags & kFindAccountStatusNew) {
			// The UCA-created box account stub exists.  We need to finish
			// setting up the box account and create a player account.
			//
			if ((err = Server_PrepareNewAccount(state)) != kNoError) {
			    if (err != kServerFuncEndTerms) {
				PLogmsg(LOGP_FLAW,
					"ERROR: unable to create new account (%ld,%ld)[%d] - (%d)\n",
					userID->box.box, userID->box.region, userID->userID, err);
			    }
			    return (kServerFuncEnd);
			}
			state->accountCreated = true;
			state->playerCreated = true;
		} else {
			// The box account and (hopefully) at least one player account
			// already exists.  Just create a new player account.
			//
			handleWasFiltered = Server_FilterHandle(state);
			oldID = *userID;	// catch it after filtering; for dialog

			Logmsg("Creating player %d on (%ld,%ld)\n", userID->userID,
				userID->box.box, userID->box.region);
			if ((err = WrapperDB_CreatePlayerAccount(userID, state->platformID,
				&result, &state->account)) != kNoError)
			{
				PLogmsg(LOGP_FLAW,
					"ERROR: unable to create player account (%ld,%ld)[%d] - (%d)\n",
					userID->box.box, userID->box.region, userID->userID, err);
				return (kServerFuncAbort);
			}
			if (handleWasFiltered || (result & kUserNameUniquified)) {
				if ((err = Server_SendChangedHandle(state, &oldID,
					result & kUserNameUniquified)) != kNoError)
				{
					return (err);
				}
			}
			state->playerCreated = true;
		}
		state->validFlags |= kServerValidFlag_Account;
		break;

	case kNoSuchBoxAccount:
		if (gConfig.isProduction) {
			goto need_call_uca;		// well, it's this or copy the code
		} else {
			// Shouldn't get here; we're not production, so the account
			// should've been created.
			//
			PLogmsg(LOGP_FLAW, "Somehow !isProduction create failed\n");
			Server_SendDialog(state,
				gettext("Non-production acct creation error (nuts)."), true);  /*DIALOG*/
			return (kServerFuncEnd);
		}

	default:
		PLogmsg(LOGP_FLAW,
			"GetAccount: ended up in weird state %d in switch\n", findErr);
		return (kServerFuncAbort);
	}

	// Sanity check.
	//
	if (!(state->validFlags & kServerValidFlag_Account)) {
		PLogmsg(LOGP_FLAW, "ERROR: successful exit w/o valid account?\n");
		return (kServerFuncAbort);
	}

	// All is happy.  If we created a new box account or player account,
	// set up the initial taunt and info to match the defaults on the box,
	// and send down a password erase code.
	//
	if (state->playerCreated || state->accountCreated) {
		Server_InitTauntAndInfo(state);
		Server_GenerateAndSendPasswordEraseCode(state);

		// Print a statusmsg.
		//
		if (state->accountCreated) {
			Statusmsg("SunSega: Created account '%s'  (%ld,%ld)[%ld]\n",
				userID->userName,
				userID->box.box, userID->box.region, (long)userID->userID);

		} else if (state->playerCreated) {
			Statusmsg("SunSega: Created new player '%s' on existing account  (%ld,%ld)[%ld]\n",
				userID->userName,
				userID->box.box, userID->box.region, (long)userID->userID);
		}
	}


	// Make sure the HardwareID makes sense.
	//
	// This shouldn't cause us to do the full restore twice, because the
	// restore code should check to see if the hardwareID values match
	// before restoring the account.
	//
	if ((err = Server_ValidateHardwareID(state)) != kNoError) {
		// Mismatch.  Need to wipe the local copy of the boxIDs and do a
		// restore.  Also want to blow away the copy of the account we
		// have hanging around.
		//
		userID->box.box = -1;
		userID->box.region = -1;
		if (state->account != NULL) {		// should never be NULL, actually
			DataBaseUtil_FreeAccount(state->account);
			state->account = NULL;
		}
		state->validFlags &= ~(kServerValidFlag_Account);

		Logmsg("Restarting GetAccount\n");
		goto start_over;		// damn, a goto
	}

	// Make sure the "DB stable" flag is set.  This needs to happen on
	// accounts that got restored and on new accounts, so we don't do
	// another restore on the very next server connect.
	//
	Server_MarkBoxDBValid(state);

	PLogmsg(LOGP_PROGRESS, "Server_GetAccount done\n");
	return (kNoError);
}


//
// Figure out if we need to restore the account.  If we do, restore it.
// This used to be part of GetAccount.
//
// On return:
//
// "accountp" will have an account pointer if both the box and player
// accounts were found.
//
// "statusFlags" has the flags returned by FindAccountBySerial (these tell
// us if the account was new, or if only the player account was found).
//
// "box" gets the box number found.
//
// "findErr" gets the result of the find, which is irrelevant since the
// value isn't used by the caller.
//
// The return value is the result of the restore (if one was necessary)
// or the account lookup (if one wasn't).
//
static	Err
Server_DetermineRestoreAccount(ServerState *state, userIdentification *userID,
	Account **accountp, long *statusFlags, BoxSerialNumber *box, Err *findErr)
{
	Err	restoreErr;
	int	restoreNecessary;


	// Do we need to restore the account?
	// (We may change our minds depending on what we see, which is why
	// it's if-then/if-then instead of if-then-else.)
	//
	restoreNecessary = Server_IsRestoreNecessary(state);
	if (!restoreNecessary) {
		// No restore necessary, use the serials from the login data.  Do
		// the lookup immediately so we can be sure they're valid.
		//
		*box = state->loginData.userID.box;
		Logmsg("Looking up account by serials(A) (%ld,%ld)[%d]\n",
			box->box, box->region, state->loginData.userID.userID);
		*findErr = WrapperDB_FindAccountBySerial(box,
			state->loginData.userID.userID, statusFlags, accountp);

		if (*statusFlags & kFindAccountStatusBoxOnly) {
			// Changed semantics: instead of returning kNoSuchUserAccount
			// and no account, it now returns just the boxAccount.
			//
			if (*accountp != NULL)
				DataBaseUtil_FreeAccount(*accountp);
			*accountp = NULL;
		}

		// If we weren't able to find the box, we need to reset the boxIDs
		// to (-1,-1) and search by phone number.
		//
		if (*findErr == kNoSuchBoxAccount) {
			PLogmsg(LOGP_NOTICE,
				"GLITCH: FindAccountBySerial on valid serials (%ld,%ld) failed (%d)\n",
				box->box, box->region, *findErr);
			userID->box.box = -1;
			userID->box.region = -1;
			restoreNecessary = true;
		}
	}
	restoreErr = *findErr;		// return this if we don't need to do a restore

	if (restoreNecessary) {
		// Restore needed, go to work.
		//
		// Server_RestoreAccount wants a place to put the box serials found
		// into.  Don't pass a pointer to state->loginData.userID.box, it
		// gets examined later.
		//
		box->box = -1;
		box->region = -1;
		restoreErr = Server_RestoreAccount(state, box);
	}

	// Return the result of the find or the result of the restore.
	//
	return (restoreErr);
}


//
// This parses and validates a number, for the login file
//
static	Err	Server_PhoneParseAndValidate(ServerState *state, SuperPhone_P phone_p, PHONE_CONNECT_ENUM connect_type)
{
	Err	err;

	err = Common_PhoneParse(phone_p, state->boxPhoneNumber.phoneNumber, connect_type,
		kPhoneCarrierUndefined, state->boxType, "9", 0);
	if (err != kNoError) {
		return(err);
	}
	return(PhoneDB_ValidateNumber(phone_p));
}

//
//	IN JAPAN PRODUCTION SERVER WILL CREATE ACCOUNT IF NONE WAS CREATED ALREADY
//
// For non-production servers, create accounts without the aid of UCA.  This
// makes the RPC calls that UCA would have made.
//
// Must have a full phone number in state->phoneNumber. For CEJ, this number
// is taken directly from what the user entered on the box.
//
// Returns kNoError on success, with the serial number of the new account
// in *boxp.
//
static Err Server_NonUCACreate(ServerState *state, BoxSerialNumber *boxp)
{
	Account *account;
	//UCAAccount *ucaAccount;
	SuperPhone	phone;
	Err err;

	PLogmsg(LOGP_PROGRESS, "Server_NonUCACreate\n");

	err = Server_PhoneParseAndValidate(state, &phone, kPhoneConnect800);

	if (err != kNoError)
	{
		PLogmsg(LOGP_FLAW, "Server_NonUCACreate: (%s) failed: phoneNumber='%s':err=%d\n",
			gConfig.locale_phone, state->boxPhoneNumber.phoneNumber, err);
		return (err);
	}

	if (gConfig.isProduction && LOCALE_PHONE_JA())
	{
		// Call NonUCACreateNewAccount (which eventually calls the UCA version).
		// Use csid==0, prodstr="/xband/smartcard/ja", billingType=
		// CAT_ACCT_BILL_SMARTC.  Call will create an Account and a UCAAccount
		// in the database.
		//
		if ((err = WrapperDB_NonUCACreateNewAccount(0, &phone.p,
			state->platformID, "/xband/smartcard/ja",
			CAT_ACCT_BILL_SMARTC, &account)) != kNoError)
		{
			PLogmsg(LOGP_NOTICE,
				"WrapperDB_NonUCACreateNewAccount failed (%d) for JA\n", err);
			return (err);
		}
		Server_SetupJapanAccount(state,account);
		WrapperDB_UpdateAccount(account);
	}
	else // default US locale
	{
		// Call NonUCACreateNewAccount (which eventually calls the UCA version).
		// Use csid==0, prodstr="/xband/unlimitedcredits/monthly", billingType=
		// CAT_ACCT_BILL_INTERNAL.  Call will create an Account and a UCAAccount
		// in the database.
		//
		if ((err = WrapperDB_NonUCACreateNewAccount(0, &phone.p,
			state->platformID, "/xband/unlimitedcredits/monthly",
			CAT_ACCT_BILL_INTERNAL, &account /*, &ucaAccount*/)) != kNoError)
		{
			PLogmsg(LOGP_NOTICE,
				"WrapperDB_NonUCACreateNewAccount failed (%d)\n", err);
			return (err);
		}
	}
	// Pull out the boxIDs and free up what we got.  The account just
	// created will be marked as "new" in the database.
	//
	*boxp = account->boxAccount.box;

	DataBaseUtil_FreeAccount(account);

	// This is probably a new box, so make sure he gets the random things
	// whether his DB is wiped or not.
	//
	Server_SetRandomThings(state, account);

	PLogmsg(LOGP_DBUG, "NonUCACreate created account (%ld,%ld)\n",
		boxp->box, boxp->region);
	return (kNoError);
}

static Err Server_SetupJapanAccount(ServerState *state, Account *account)
{
#if 0	// SET TO 1 TO ENABLE TRADITIONAL LONG DISTANCE AS DEFAULT
	// Set traditional long distance capable and update restrictions on box
	account->boxAccount.restrictArea |= kRestrictArea_dialLongDistance;
	account->boxAccount.csUpdatedFlags |= kCSUpdatedFlag_UpdatedRestrictions;
	account->boxModified |= kBA_csUpdatedFlags | kBA_restrictInfo;
#endif

	account->boxAccount.boxFlags |= kBoxFlag_FilterMail;
	account->boxModified |= kBA_boxFlags;

	account->userAccount.activationDate = state->timeOfThisConnect;
	account->userAccount.customerServiceID = account->boxAccount.box.box;
	account->userModified |= kUA_activationDate | kUA_customerServiceID;
	return kServerFuncOK;
}


#define kTermsMailSender "XBAND-legal"
#define kTermsMailSN 666
#define kAccessCodeSize 4
#define	kTermsMaxTries 20

/* XXX should be in a header file */
void    *SvrNews_OpenConnection(void);

static Err
Server_AgreeToTermsAndConditions(ServerState *state)
{
    int err, i, rv;
    long statusFlags;
    messOut opCode;
    UCAInfo *ucainfo;
    userIdentification catapult = { {-1, 0}, 0, 0, kXBANDPlayerIcon,
					"", kTermsMailSender };
    Account *account;
    BoxSerialNumber *boxp;
    void *newsServer;

    strcpy(catapult.userTown, gConfig.catapultTown);

    rv = kServerFuncEndTerms;
    account = NULL;
    ucainfo = NULL;

    /*
     * if we're not production, let everyone in!
     */
    if (!gProduction || !gConfig.require_terms)
	return 0;

    if (state->account) {
	PLogmsg(LOGP_NOTICE, "warning: Server_AgreeToTermsAndConditions"
	       "has non-null state->account\n");
    }

    boxp = &state->loginData.userID.box;
    PLogmsg(LOGP_PROGRESS, "TERMS: serials = %d,%d\n",
	    boxp->box, boxp->region);

    /* fetch the guy's account */
    statusFlags = 0;
    err = WrapperDB_FindAccountBySerial(boxp, state->loginData.userID.userID,
					&statusFlags, &account);
    if (account == NULL) {
	PLogmsg(LOGP_FLAW, "TERMS: FindAccountBySerial gave null account"
		", err %d\n", err);

	Server_SendDialog(state, gettext("We are having trouble finding your account. Please call XBAND Customer Support at 408-777-1500."), true);	/* DIALOG */
	return rv;
    }

    /* if he agreed to the terms over the phone, let him in */
    if (account->userAccount.accountFlags &
	CAT_ACCT_STATFLAG_AGREED_TO_TERMS) {

	Logmsg("TERMS: AGREED_TO_TERMS flag set on box %d\n", boxp->box);
	rv = 0;
	goto out;
    }

    /*
     * if the account is suspended,
     * keep them suspended without letting the playeraccount be created.
     */
    if (account->userAccount.accountStatus == CAT_ACCT_STATUS_SUSPENDED) {
	goto we_are_suspended;
    }    

    /* if the account isn't open, fall thru to whatever the normal result is */
    if (account->userAccount.accountStatus != CAT_ACCT_STATUS_ACTIVE) {
	rv = 0;
	goto out;
    }

	if (!LOCALE_PHONE_JA())
	{
	    err = WrapperDB_FindUCAInfoByCSID(account->userAccount.customerServiceID,
					      &ucainfo);
	    if (err) {
		PLogmsg(LOGP_FLAW, "box %d: FindUCAInfoByCSID(%d) -> %d\n",
			account->boxAccount.box.box,
			account->userAccount.customerServiceID,
			err);
	
		Server_SendDialog(state, gettext("We are having trouble finding your account. Please call XBAND Customer Support at 408-777-1500."), true);	/* DIALOG */
		goto out;
	    }
	}

    /*
     * Check for the agreement mail
     */
    for (i = 0; i < state->incomingMail.count; i++) {
	Mail *mail = state->incomingMail.mailItems[i].mail;

	if (DataBaseUtil_CompareStrings(mail->to.userName, kTermsMailSender) == 0) {
	    char *cp, buf[1024];
	    int said_yes, gave_code, extra_words;
	    char *yesp;
	    int yeslen, count;

	    Logmsg("TERMS: box %d mail title = %s, body = %s\n",
		   boxp->box, mail->title, mail->message);

	    said_yes = gave_code = extra_words = false;

	    /*
	     * sega vs. snes bogosity.
	     * snes fills in the title of replies automatically, sega doesn't.
	     * try to do the right thing.
	     * Ted 10/23/95: for japan, it's easier to just check for substring
	     * in title of intl version of title than check for "Re:" in front.
	     */
	    if (strstr(mail->title, gettext("Legal Terms and Conditions")))
	    {
			buf[0] = 0;
	    } else {
			strcpy(buf, mail->title);
	    }
	    strcat(buf, mail->message);
	    cp = buf;

	    /* zap occurrances of "yes" */
	    yesp = gettext("yes");
	    yeslen = strlen(yesp);
	    for (;;) {
			count = yeslen;
			cp = strcasestr(buf, yesp);
			if (cp == NULL)
			    break;
	
			said_yes = true;
			for(;count--;)
				cp[count] = ' ';
	    }

		if (LOCALE_PHONE_JA())
		{
	    	gave_code = true;
		}
		else
		{
		    /* zap occurrances of the access code */
		    for (;;)
		    {
				cp = strcasestr(buf, ucainfo->access_code);
				if (cp == NULL)
				    break;
				gave_code = true;
				cp[0] = cp[1] = cp[2] = cp[3] = ' ';
			}
	    }
	    /*
	     * See what's left in the buffer.
	     * Spaces and some punctuation are ok.
	     */
	    extra_words = (strspn(buf, " .-_,") != strlen(buf));

	    if (said_yes && gave_code && !extra_words) {
		/* he agreed to the Terms correctly, let him in! */
		Logmsg("TERMS: box %d agreed to the terms in %d tries\n",
			boxp->box, account->boxAccount.totalServerConnects);

		Server_SendDialog(state, gettext("You have agreed to the terms and conditions of XBAND's Members Policy. Your account is now ACTIVE."), true);	/* DIALOG */

		account->boxAccount.newsChannels[kBandwidthChannel]
		    .lastArticleRead = 0;
		account->boxModified |= kBA_newsChannels;
		state->firstRealConnect = true;

		rv = 0;
		goto out;
	    }

	    if (!said_yes) {
		Logmsg("TERMS: box %d didn't say yes\n", boxp->box);

		Server_SendDialog(state, gettext("You forgot to enter the\nword YES in your reply. Please try again."), true);	/* DIALOG */
	    }
	    else if (!gave_code) {
		Logmsg("TERMS: box %d said yes but no code\n", boxp->box);

		Server_SendDialog(state, gettext("You failed to enter the correct\nfour-digit Access Code in your reply. Please try again."), true);	/* DIALOG */
	    }
	    else if (extra_words) {
		Logmsg("TERMS: box %d had extra words (%s)\n", boxp->box, buf);

		Server_SendDialog(state, gettext("Please enter ONLY the word YES and your four-digit Access Code if you agree to the terms. Please try again."), true);	/* DIALOG */
	    }
	}
    }

    PLogmsg(LOGP_DETAIL, "TERMS: box %d,%d failed to agree to the terms\n",
	    boxp->box, boxp->region);

    /*
     * He didn't send the correct mail.
     * Nuke the box's outgoing mail,
     * bump his legal-counter and suspend his account if necessary,
     * replace the initial mail if necessary,
     * send him a dialog about the mail and news.
     */

    if (state->incomingMail.count) {
	long controlFlags;

	opCode = msServerMiscControl;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	controlFlags = kDeleteAllAoutBoxMailFlag;
	Server_TWriteDataSync(state->session, sizeof(long),(Ptr)&controlFlags);
	PLogmsg(LOGP_PROGRESS, "TERMS: nuked his outgoing mail\n");
    }
    else {
	Logmsg("TERMS: box %d had no outgoing mail\n", boxp->box);
    }

    /* Send down the TERMS news */
    newsServer = SvrNews_OpenConnection();
    if (newsServer) {
	/*
	 * Server_UpdateBoxDocument uses state->account,
	 * but that's always NULL at this point.
	 * We temporarily set it to the account we fetched.
	 */
	state->account = account;
	err = Server_UpdateBoxDocument(state, kBandwidthChannel,
				       newsServer, kTermsAndConditionsID, &i);
	state->account = NULL;

	if ((err & (kSvrNewsRealSent|kSvrNewsBoxUptoDate)) == 0) {
	    PLogmsg(LOGP_NOTICE, "TERMS: box %d failed to get the news\n",
		    boxp->box);
	    goto temp_trouble;
	}
    }
    else {
	PLogmsg(LOGP_FLAW, "TERMS: box %d couldn't contact newsserver!\n",
		boxp->box);

      temp_trouble:
	Server_SendDialog(state, gettext("There is a temporary problem with activating new accounts.  Please try again in a few minutes."), true);	/* DIALOG */
	goto out;
    }

    /*
     * Bump the counter of how many times this guy has tried
     * to agree to the terms, and suspend his account if he
     * goes over the limit.
     */
    if (++account->boxAccount.totalServerConnects > kTermsMaxTries) {
		account->userAccount.accountStatus = CAT_ACCT_STATUS_SUSPENDED;
		account->userAccount.accountFlags |= CAT_ACCT_STATFLAG_TERMS_NOT_SIGNED;
		account->userModified |= kUA_accountStatus | kUA_accountFlags;
	
		Logmsg("TERMS: box %d suspended for too many attempts\n", boxp->box);
    }
    account->boxModified |= kBA_totalServerConnects;

    
    /*
     * Send down the agree-to-terms mail if it's not on the box already.
     */
    for (i = 0; i < state->loginData.numMailsInBox; i++)
	if(state->loginData.mailSerialNumbers[i] == kTermsMailSN)
	    break;
    if (i == state->loginData.numMailsInBox) {
	Mail *m;
	short num;

	m = (Mail *)malloc(sizeof(Mail) + 512);
	ASSERT(m);

	if (state->platformID == kPlatformGenesis) {
	    strcpy(m->message, gettext("If you agree to the terms of XBAND's Members Policy, enter YES in the \"Title:\" box and your four-digit Access Code in the message area. Send ONE reply. Your account will NOT be activated until you agree to the terms stated."));
	}
	else {
	    strcpy(m->message, gettext("If you agree to the terms of XBAND's Mem-\nbers Policy, reply YES and enter your four-\ndigit Access Code. Send ONE reply. Your account will NOT be activated until you agree to the terms stated."));
	}

	m->date = Server_GetSegaDate();
	strcpy(m->title, gettext("Legal Terms and Conditions"));
	m->to.box = state->loginData.userID.box;
	m->to.userID = state->loginData.userID.userID;
	m->from = catapult;
	m->serialNumber = kTermsMailSN;

	opCode = msReceiveMail;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	num = 1;
	Server_TWriteDataSync(state->session, sizeof(short), (Ptr)&num);

	Server_SendMailBody(state, m);
	free(m);

	PLogmsg(LOGP_PROGRESS, "TERMS: sending mail\n");
    }
    else {
	PLogmsg(LOGP_PROGRESS, "TERMS: not re-sending the mail\n");
    }

    if (account->userAccount.accountStatus == CAT_ACCT_STATUS_SUSPENDED) {
      we_are_suspended:
	Server_SendDialog(state, gettext("You have NOT agreed to the terms and conditions of XBAND's Members Policy. Your account will NOT be activated. Please call 408-777-1500."), true);	/* DIALOG */
    }
    else {
	Server_SendDialog(state, gettext("After you have read every\npage of BANDWIDTH, please go to X-Mail and look for a message from XBAND."), true);	/* DIALOG */
    }

    if (Server_SyncWithBox(state) != kServerFuncOK) {
	/* box is gone, we'll be SIGHUPing shortly, no doubt... */

	Logmsg("TERMS: SyncWithBox failed\n");
    }

  out:
    WrapperDB_UpdateAccount(account);
    DataBaseUtil_FreeAccount(account);
    if (ucainfo) {
	/* Server_FreeUCA(ucainfo); */
    }

    return rv;
}
//
// Only the UCA-created stub exists.  Prepare some remaining fields in the
// box account and set up the first player account.
//
// state->loginData.userID should have had the actual box serials stuffed
// in by now.
//
// Fun question: what phone number do we use to create the account with?
// The number in state->boxPhoneNumber *should* be a 10-digit (or possibly
// 11-digit) number, since we should only be doing an account create after
// a 1-800 call.  The fake ANI stuff boots the user out after setting the
// phone to a 10-digit number, so there's no chance of something leaking
// through that way.
//
// It's certainly possible than an 8-digit (7-digit with a dash) number
// could sneak in.  If we see that, all we can do is boot them out to the
// 1-800 number.
//
static Err Server_PrepareNewAccount(ServerState *state)
{
	userIdentification	*userID, oldID;
	Err					err;
	Boolean				handleWasFiltered;
	long				result;

	PLogmsg(LOGP_PROGRESS, "Server_PrepareNewAccount (%ld,%ld)\n",
		state->loginData.userID.box.box, state->loginData.userID.box.region);

	userID = &state->loginData.userID;

	// Filter handle for nastiness.
	//
	handleWasFiltered = Server_FilterHandle(state);
	oldID = *userID;
	/*
	 * make sure the guy has agreed to the legal terms.
	 */
	
	if ((err = Server_AgreeToTermsAndConditions(state))) {
	    return err;
	}


	// Create the fucker.
	//
	if ((err = WrapperDB_CreateBoxAndPlayerAccount(userID,
		&state->boxPhoneNumber, state->platformID, &result,
		&state->account)) != kNoError)
	{
		if (err == kNoPrecreatedBoxAccount) {
			// I'm not convinced this can still happen.  Well, deal
			// with it anyway.  (We used to reset them back to the
			// 1-800 number here, but no longer do.)
			//
			// 950523: I just changed CreateBoxAndPlayer so this CAN'T
			// happen.  Leave it in just in case somebody changes it back.
			//
			state->abandonShip = true;
			Server_SendDialog(state,
				gettext("You do not have an account with XBAND.  Please call 800-700-8266 to set up your account."),	/*DIALOG*/
				true);
			return (kServerFuncEnd);
		}
		PLogmsg(LOGP_FLAW, "ERROR: CreateBoxAndPlayerAccount failed\n");
		return (kServerFuncAbort);
	}

	// If we filtered or uniquified the handle, send it back down to the box.
	//
	if (handleWasFiltered || (result & kUserNameUniquified)) {
		if ((err = Server_SendChangedHandle(state, &oldID,
			result & kUserNameUniquified)) != kNoError)
		{
			return (err);
		}
	}

	// Send the box its unique serial number, which was retrieved by
	// CreateBoxAndPlayerAccount.
	//
	if (Server_SendNewBoxSerialNumber(state, &state->account->boxAccount.box)
		!= kNoError)
	{
		return (kServerFuncAbort);
	}
	userID->box = state->account->boxAccount.box;


	//
	// Initial credit allocation for Beta testers is given in
	// Server_ValidateCreditStuff.  For normal users the account will be
	// created with the correct number of credits by UCA.
	//

	state->accountCreated = true;
	
	Logmsg("Server_PrepareNewAccount: created a new %s account.\n", 
		(state->account->userAccount.billingType == CAT_ACCT_BILL_BETA) ? "BETA" :
		((state->account->userAccount.billingType == CAT_ACCT_BILL_GUEST) ? "GUEST" : 
		((state->account->userAccount.billingType == CAT_ACCT_BILL_INTERNAL) ? "EMPLOYEE" : "CUSTOMER")));

	return (kNoError);
}


//
// Filter the user's handle for profanity and reserved words.
//
// Returns true if it had to update the handle.  This will update
// state->userID->userName in place.
//
static Boolean
Server_FilterHandle(ServerState *state)
{
	userIdentification 	*userID, oldID;
	Boolean				handleWasFiltered = false;
	char				buf[256];

	PLogmsg(LOGP_PROGRESS, "Server_FilterHandle ('%s')\n",
		state->loginData.userID.userName);

	userID = &state->loginData.userID;
	oldID = *userID;

	if (FilterTextObscene(userID->userName)) {
		sprintf(buf,
			// I18N Appears:  When XBAND detects that the player has used 
			//           vulgar language in his or her player name.
			// Solution: Do not use vulgarity on XBAND
			//
			gettext("Your Code Name '%s' contains inappropriate language.  It has been changed to '%s'."),	/* DIALOG */
			oldID.userName, userID->userName);
		Server_SendDialog(state, buf, false);
		handleWasFiltered = true;
	}

	if (FilterTextReserved(userID->userName)) {
		sprintf(buf,
			// I18N Appears:  When XBAND detects that the player has used 
			//           an XBAND reserved word in their player name.
			// Solution: Some words are reserved for use by XBAND. 
			//
			gettext("Your Code Name '%s' contains an XBAND reserved word.  It has been changed to '%s'."),	/* DIALOG */
			oldID.userName, userID->userName);
		Server_SendDialog(state, buf, false);
		handleWasFiltered = true;
	}

	if (filterString(userID->userName, ILLEGALCHARS,
		"*****************************************"))
	{
		sprintf(buf,
			// I18N Appears:  When player uses XBAND reserved characters
			//           in his or her codename.
			// Solution: Some characters are reserved for use by
			//           XBAND.  The player should not use those characters in
			//           his or her code name.
			//
			gettext("Your Code Name '%s' cannot have these characters in it: '%s'.  It has been changed to '%s'."),	/* DIALOG */
			oldID.userName, ILLEGALCHARS, userID->userName);
		if (handleWasFiltered == false)
			Server_SendDialog(state, buf, false);
		handleWasFiltered = true;
	}

	return (handleWasFiltered);
}


//
// After filtering and/or uniquification, we need to tell the box what
// it's handle is going to be.  This sends the handle down.
//
// Need "didUniquify" to determine what dialog to send, and "oldID" to
// make the dialog interesting (so oldID should represent what the handle
// was after filtering but before uniquification).
//
static Err
Server_SendChangedHandle(ServerState *state, userIdentification *oldID,
	int didUniquify)
{
	userIdentification 	*userID;
	char	buf[256];

	PLogmsg(LOGP_PROGRESS, "Server_SendChangedHandle\n");

	userID = &state->loginData.userID;

	// If UpdateUserHandle uniqified the userName field or we had to
	// filter it, notify the box.
	//
	Server_SendNewCurrentUserName(state, userID->userName);

	if (didUniquify) {
		Logmsg("SendChangedHandle: handle changed from '%s' to '%s'\n",
			oldID->userName, userID->userName);
		sprintf(buf,
			// I18N Appears:  When player changes his or her code name to 
			//           one that is already being used on XBAND.  XBAND will 
			//           append a number at the end of the name to ensure that
			//           all code names are unique.
			// Solution: Choose a different code name, or be happy with
			//           what you've got!
			//
			gettext("The Code Name '%s' is being used.  Your Code Name has been changed to '%s'."),	/* DIALOG */
			oldID->userName, userID->userName);
		Server_SendDialog(state, buf, false);
	} else {
		Logmsg("SendChangedHandle: sent filtered handle '%s'\n", userID->userName);
	}
	//
	// If we altered the userName above, make sure it gets copied into our
	// local copy of playerAccount.userName for display purposes during the
	// rest of this connection.
	//
	if (strcmp(state->account->playerAccount.userName, userID->userName) != 0) {
		Logmsg("Updating local copy of userName from %s to %s\n",
			state->account->playerAccount.userName, userID->userName);
		strncpy(state->account->playerAccount.userName, userID->userName, kUserNameSize);
	}
	return (kNoError);
}


//
// Initialize the account's copy of the taunt and personal info to the
// defaults for that box.
//
static Err
Server_InitTauntAndInfo(ServerState *state)
{
	char *defaultTaunt = NULL, *defaultInfo = NULL;

	PLogmsg(LOGP_PROGRESS, "Server_InitTauntAndInfo\n");

	Server_GetDefaultTauntAndInfo(state, &defaultTaunt, &defaultInfo);
	if (defaultTaunt == NULL || defaultInfo == NULL) {
		PLogmsg(LOGP_NOTICE, "WARNING: no default taunt/info for '%.4s'\n",
			(char *)&state->platformID);
		return (kFucked);
	}
	PLogmsg(LOGP_DBUG, "Default taunt='%s', info='%s'\n", defaultTaunt,
		defaultInfo);

	if (state->account->playerAccount.openTaunt != NULL)
		free(state->account->playerAccount.openTaunt);
	state->account->playerAccount.openTaunt = malloc(strlen(defaultTaunt) + 1);
	strcpy(state->account->playerAccount.openTaunt, defaultTaunt);
	state->account->playerModified |= kPA_openTaunt;
	
	if (state->account->playerAccount.personInfo)
		free(state->account->playerAccount.personInfo);
	state->account->playerAccount.personInfo = malloc(strlen(defaultInfo) + 1);
	strcpy(state->account->playerAccount.personInfo, defaultInfo);
	state->account->playerModified |= kPA_personInfo;

	return (kNoError);
}


//
// Get default taunt and personal info.  Places pointers to static strings
// in *tauntp and *infop.
//
// DO NOT internationalize these strings.  They need to match what is
// built into the ROM on the box.
//
Err
Server_GetDefaultTauntAndInfo(ServerState *state, char **tauntp, char **infop)
{
	SubDispatcher subDisp[] = {
		{ kPlatformGenesis,	kPlatformGenesisMask,	Server_sega_GetDefaultTauntAndInfo },
		{ kPlatformSNES,	kPlatformSNESMask,		Server_snes_GetDefaultTauntAndInfo },
		{ kPlatformSJNES,	kPlatformSJNESMask,		Server_sjne_GetDefaultTauntAndInfo },
		{ kPlatformAny,		0,						Server_any_GetDefaultTauntAndInfo },
		{ 0,				0,						NULL },		// trink!
	};

	return ( (Err)(Common_SubDispatch(state->boxOSState.boxType, subDisp))(
		state, tauntp, infop) );
}

static int
Server_sega_GetDefaultTauntAndInfo(ServerState *state, char **tauntp, char **infop)
{
	PLogmsg(LOGP_PROGRESS, "Server_sega_GetDefaultTauntAndInfo\n");

	*tauntp = "Pick on me! I haven�t got a taunt!";
	*infop = "I�m a new player!";

	return (kNoError);
}

static int
Server_snes_GetDefaultTauntAndInfo(ServerState *state, char **tauntp, char **infop)
{
	PLogmsg(LOGP_PROGRESS, "Server_snes_GetDefaultTauntAndInfo\n");

	*tauntp = "I can�t think of a taunt!";
	*infop = "I�m a new player!";

	return (kNoError);
}

static int
Server_sjne_GetDefaultTauntAndInfo(ServerState *state, char **tauntp, char **infop)
{
	PLogmsg(LOGP_PROGRESS, "Server_sjne_GetDefaultTauntAndInfo\n");

	// I18N Note: The following "DEFAULT_TAUNT" msgid string should not
	// be changed.  It should be put in the SunSega.po file exactly as it
	// appears here.  Please only translate the msgstr for this message.
	// The English msgstr for this msgid is:
	//    msgid  "DEFAULT_TAUNT"
	//    msgstr "Pick on me! I haven't got a taunt!" (translate to Japanese)
	//
	*tauntp = gettext("DEFAULT_TAUNT");

	// I18N Note: The following "DEFAULT_PERSON_INFO" msgid string should not
	// be changed.  It should be put in the SunSega.po file exactly as it
	// appears here.  Please only translate the msgstr for this message.
	// The English msgstr for this msgid is:
	//    msgid  "DEFAULT_PERSON_INFO"
	//    msgstr "I'm a new player!" (translate to Japanese)
	//
	*infop = gettext("DEFAULT_PERSON_INFO");

	return (kNoError);
}

static int
Server_any_GetDefaultTauntAndInfo(ServerState *state, char **tauntp, char **infop)
{
	PLogmsg(LOGP_PROGRESS, "Server_any_GetDefaultTauntAndInfo\n");

	PLogmsg(LOGP_NOTICE, "NOTE: no default taunt/info for '%.4s'\n",
		(char *)&state->platformID);
	*tauntp = NULL;
	*infop = NULL;
	return (kNoError);
}


//
// Check to make sure the account's hwid matches the box's hwid.  If there's
// no hwid in the account, set it.
//
// Returns kNoError if there weren't any problems.  Not having a hardwareID
// at all is fine (all current 'sega').  Having a hardwareID with an error
// in it is not fine, but there's not much we can do about it except yell.
//
// If they don't match, life is very strange.  Possible reasons why this
// could occur:
//
//	1. modem incest
//	2. broken server code restored to the wrong account
//	3. customer service trying to fix a situation by shuffling hwids around
//	4. this is a replacement modem for the original one
//	5. temporary insanity caused the same hwid to end up in two accounts
//
// In the first three cases, the only workable approach is to fry the boxIDs
// and do a restore by hardwareID (i.e. the hwid on the box, not the hwid
// in the account).
//
// The fourth one should've been dealt with before we got here (either
// the account should've been updated with the new info, or the box
// should've been thrown out for lack of an account).  So treating it like
// the previous case is fine.
//
// The fifth case could cause the legitimate account owner to be unable
// to reattach to the account.  In that case (which should be rare --
// trampling hwids is not something to take lightly), customer service can
// set the replacement bit.  (More likely is they'll create a new account.)
//
// Anyway.  If they don't match, return kFucked.  Otherwise return kNoError.
//
static Err
Server_ValidateHardwareID(ServerState *state)
{
//	HardwareID *boxhwid, *accthwid;

	PLogmsg(LOGP_PROGRESS, "Server_ValidateHardwareID\n");

	if (!Server_BoxSentValidHWID(state)) {
		// No hardwareID, or hwid has an error.
		//
		return (kNoError);
	}

	// Put a copy of the HWID into the account if it isn't there already.
	// We should never put a copy of it in the account if it has an error,
	// but that was checked for above.
	//
	if (state->account->boxAccount.hardwareID.hardwareIDtype == kHWID_NoHWID) {
		// Account doesn't have hwid yet.
		//
		state->account->boxAccount.hardwareID = state->loginData.hardwareID;
		state->account->boxModified |= kBA_hardwareID;

		Logmsg("Set hwid on (%ld,%ld) ",
			state->account->boxAccount.box.box,
			state->account->boxAccount.box.region);
		Common_LogHardwareID(&state->account->boxAccount.hardwareID);
		return (kNoError);
	}

	// We've got a hwid, check it.
	//
	if (Common_CompareHardwareID(&state->account->boxAccount.hardwareID,
		&state->loginData.hardwareID) != 0)
	{
		PLogmsg(LOGP_FLAW, "GLITCH: mismatched HardwareID values:\n");
		Logmsg("Box    : ");
		Common_LogHardwareID(&state->loginData.hardwareID);
		Logmsg("Account: ");
		Common_LogHardwareID(&state->account->boxAccount.hardwareID);

		return (kFucked);
	}

	return (kNoError);
}


// POP home town is passed in.  Change it if necessary.
// Update the account in Japan.
//
void Server_WhichTown(ServerState *state, Hometown town)
{
	if (LOCALE_PHONE_JA())
	{
		// In Japan, the POP town *IS* the home town. Store this in the account.
		strcpy(state->account->boxAccount.homeTown, town);
		state->account->boxModified |= kBA_homeTown;
	}
	else
	{
		// If the gamePhone is different than the originalGamePhone, then use the
		// POP town.  Otherwise if hometown was set by UCA, use it instead of the
		// POPLookup's hometown.
		if (!strlen(state->account->boxAccount.originalGamePhone.phoneNumber))
		{
			return;		// leave town the same since we can't compare phone nums.
		}
		//
		if (Common_PhoneCompareNumbers(state->account->boxAccount.originalGamePhone.phoneNumber,
			state->account->boxAccount.gamePhone.phoneNumber) != 0)
		{
			return;		// phone are different, so use the POP town
		}
		if (strlen(state->account->boxAccount.homeTown) != 0)
		{
			strcpy(town, state->account->boxAccount.homeTown);
		}
	}
}


#ifdef NUKE_THE_WORLD
//
// You almost certainly don't want to do this.
//
// Blow away everyone who calls in.
//
Err
Server_NukeTheWorld(ServerState *state)
{
	phoneNumber pop;
	BoxSerialNumber bsn;

	PLogmsg(LOGP_NOTICE, "******************\n");
	PLogmsg(LOGP_NOTICE, "***            ***\n");
	PLogmsg(LOGP_NOTICE, "***   (boom)   ***\n");
	PLogmsg(LOGP_NOTICE, "***            ***\n");
	PLogmsg(LOGP_NOTICE, "******************\n");

	// Trash the pop so they redial 1-800.
	//
	memset(&pop, 0, sizeof(phoneNumber));
	Server_SendSetLocalAccessPhoneNumber(state, &pop, &pop, true);

	// Trash the box serials so they get restored by phone or hwid.
	//
	bsn.box = bsn.region = -1;
	Server_SendNewBoxSerialNumber(state, &bsn);

	// Trash the DB and OS.
	//
	Server_SendBoxWipeMind(state);

	// If they're still alive, make them go away.
	//
	return (kServerFuncEnd);
}
#endif	/*NUKE_THE_WORLD*/


//
// Check to see if the "wipe his brain on the next connect" flag is set
// in the boxAccount.  If it is, get everybody synchronized and then
// blow his proverbial bag off.
//
// This is currently set up to fry DB and OS but not boxIDs.  Probably
// ought to make this configurable somehow.
//
static int
Server_CheckMindWipeFlag(ServerState *state)
{
	static const unsigned char osdb_wipe_sega[] = {
		0x09, 0x00, 0x00, 0x00, 0x04, 0xFF, 0xFF, 0x4e, 0x75
	};
	static const unsigned char osdb_wipe_snes[] = {
		0x09, 0x00, 0x00, 0x00, 0x34, 0xE2, 0x30, 0xA9,
		0x00, 0x8F, 0x00, 0x42, 0x00, 0x8F, 0xF2, 0xC0,
		0xFB, 0xC2, 0x30, 0xA9, 0x41, 0x6E, 0x8D, 0x00,
		0x00, 0xA9, 0x64, 0x79, 0x8D, 0x02, 0x00, 0xA2,
		0x00, 0x00, 0xA0, 0x04, 0x00, 0xA9, 0xFB,  0x7F, // <--
		0x54, 0xE0, 0xE0, 0x5C, 0x00, 0x00, 0xD0, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00
	};	// changing the 0x7f to 0xff will wipe the boxIDs as well
	PreformedMessage pm;

	PLogmsg(LOGP_PROGRESS, "Server_CheckMindWipeFlag\n");

	if (state->platformID != kPlatformGenesis &&
		state->platformID != kPlatformSNES)
	{
		PLogmsg(LOGP_FLAW, "GLITCH: mindwipe flag set on %.4s platform\n",
			(char *)&state->platformID);
		return (kServerFuncOK);
	}

	if (state->account->boxAccount.boxFlags & kBoxFlag_MindWipe) {
		// Sync with box.
		//
		if (Server_SyncWithBox(state) != kServerFuncOK) {
			Logmsg("Sync failed, not wiping box\n");
			return (kServerFuncOK);
		}

		// Clear the wipe bit and sync with server.
		//
		state->account->boxAccount.boxFlags &= ~kBoxFlag_MindWipe;
		state->account->boxModified |= kBA_boxFlags;
		Server_UpdateDataBaseAccount(state);

		// Party time.
		//
		switch (state->platformID) {
		case kPlatformGenesis:
			pm.message = (unsigned char *)osdb_wipe_sega;
			pm.length = sizeof(osdb_wipe_sega);
			break;
		case kPlatformSNES:
			pm.message = (unsigned char *)osdb_wipe_snes;
			pm.length = sizeof(osdb_wipe_snes);
			break;
		}
		PLogmsg(LOGP_NOTICE, "MindWipe %.4s box (%ld,%ld)[%d] (len=%d)\n",
			(char *)&state->platformID,
			state->account->boxAccount.box.box,
			state->account->boxAccount.box.region,
			state->account->playerAccount.player,
			pm.length);

		// Hasta la vista.  If for some reason it lives long enough to
		// complete the connection, end it anyway.
		//
		Server_SendPreformedMessage(state, &pm);

		return (kServerFuncEnd);
	}

	return (kServerFuncOK);
}


#define HOUR (60*60)
void Server_GetBoxTimeZone(ServerState *state)
{
	Err err = 0;
	long timezone;
	long boxobs;
	long boxdst;
	long svrdst;
	struct tm tm;
	time_t svrtime, boxtime;
	char town[kUserTownSize];
	char tstr[64];

	svrtime = state->localConnectTime = state->timeOfThisConnect;
	if (!LOCALE_PHONE_C())
		return;	// if we're not US, currently nothing to do.

	err = DataBase_GetExchangeInfo(&state->account->boxAccount.gamePhone, town, &timezone, &boxobs);
	if (err)
	{
		PLogmsg(LOGP_FLAW,"Error %ld returned from DataBase_GetExchangeInfo\n", err);
		return;
	}
	boxobs = (boxobs != 0);	// make sure it's 1 or 0

	Logmsg("Town: (%s)  timezone: %lu  obsdst: %lu\n",
		town, timezone, boxobs);

	// adjust for basic timezone difference
	boxtime = svrtime + (timezone-kTZPacific)*HOUR;
	
	// DST in server's time?
	tm = *localtime(&svrtime);
	svrdst = (tm.tm_isdst != 0);
	
	// DST in box's time?
	tm = *localtime(&boxtime);
	boxdst = (tm.tm_isdst != 0);
	
	// Now adjust for Daylight Savings Time
	// The following comes from a fabulous Karnaugh map!
	
	if (!boxdst && svrdst)
		boxtime -= HOUR;
	else if (boxdst && (boxobs ^ svrdst))
		boxtime += (boxobs - svrdst) * HOUR;

	// Display the amazing results!
	strcpy(tstr,ctime(&svrtime));
	PLogmsg(LOGP_DETAIL, "Server time: (%lu) %s", svrtime, tstr);

	strcpy(tstr,ctime(&boxtime));
	PLogmsg(LOGP_DETAIL, "Local time:  (%lu) %s", boxtime, tstr);
	state->localConnectTime = boxtime;
}

#ifdef TESTING_BOX_RESTORE
//
// For testing, mangle the loginData to simulate various kinds of box
// restore situations.
//
static Err
Server_MangleLogin(ServerState *state)
{
	int mode = 0;
	static char *happyPhone = "14087778642";	// make it look like 1-800

	// This determines what happens next.
	//
	mode = 0;

	Logmsg("BR: Server_MangleLogin doing dirty deeds (dirt cheap) %d\n", mode);

	switch (mode) {
	case 0:
		// Do nothing.
		//
		break;
	case 1:
		// Nuke the DB (Genesis only).  Requires valid boxIDs.
		// (tests valid boxIDs, bad DB)
		//
		state->NGPVersion = 1;
		break;
	case 2:
		// Give us a different region.  Requires valid boxIDs.
		// (tests valid boxIDs with different region from test server)
		//
		state->loginData.userID.box.region = gConfig.hap)pyRegion - 1;
		if (strlen(state->boxPhoneNumber.phoneNumber) < kPhoneLongDistUS)
			strcpy(state->boxPhoneNumber.phoneNumber, happyPhone);
		break;
	case 3:
		// Nuke the DB, give us a different region.  Requires valid boxIDs.
		// (behaves like switch to test server with DB crash during switch)
		//
		state->NGPVersion = 1;
		state->loginData.userID.box.region = gConfig.happyRegion - 1;
		if (strlen(state->boxPhoneNumber.phoneNumber) < kPhoneLongDistUS)
			strcpy(state->boxPhoneNumber.phoneNumber, happyPhone);
		break;
	case 4:
		// Nuke the DB, give us a different box #.  Requires valid boxIDs.
		// (tests valid boxIDs with unknown serial number)
		//
		state->NGPVersion = 1;
		state->loginData.userID.box.box = 6000;
		if (strlen(state->boxPhoneNumber.phoneNumber) < kPhoneLongDistUS)
			strcpy(state->boxPhoneNumber.phoneNumber, happyPhone);
		break;
	case 5:
		// Set boxIDs to (-1,-1), clear the crashRecord, set the phone
		// number.
		// (makes the box look like a brand-new Genesis)
		//
		state->loginData.userID.box.box = -1;
		state->loginData.userID.box.region = -1;
		state->NGPVersion = 1;
		state->crashRecord = NULL;
		strcpy(state->boxPhoneNumber.phoneNumber, happyPhone);
		break;
	case 6:
		// Set boxIDs to (-1,-1), set the phone number.
		// (makes the box look like a brand-new Genesis that crashed)
		//
		state->loginData.userID.box.box = -1;
		state->loginData.userID.box.region = -1;
		state->NGPVersion = 1;
		strcpy(state->boxPhoneNumber.phoneNumber, happyPhone);
		break;
	case 10:
		// Tweak the hwid.
		// (test incested box showing up with right box serials but wrong
		// hwid)
		//
		state->loginData.hardwareID.hwid.snesHWID.snesHardwareID.serialNumber[0]++;
		break;
	case 11:
		// Tweak the hwid, copy happyPhone, hose the boxIDs.
		// (set the replacement modem bit on another box with the same
		// phone number but a different hwid, and make sure there's no account
		// with this hwid.  Tests overwriting of hwid with a replacement
		// modem's hwid.)
		//
		state->loginData.hardwareID.hwid.snesHWID.snesHardwareID.serialNumber[0] -= 3;
		state->loginData.userID.box.box = -1;
		state->loginData.userID.box.region = -1;
		if (strlen(state->boxPhoneNumber.phoneNumber) < kPhoneLongDistUS)
			strcpy(state->boxPhoneNumber.phoneNumber, happyPhone);
		break;
	case 12:
		// Set boxIDs to (-1,-1), clear the crashRecord, set the phone
		// number, tweak the hwid.
		// (test hardwareID restore on non-existent hwid, plus handling
		// of box hwid != acct hwid)
		//
		state->loginData.userID.box.box = -1;
		state->loginData.userID.box.region = -1;
		state->NGPVersion = 1;
		state->crashRecord = NULL;
		strcpy(state->boxPhoneNumber.phoneNumber, happyPhone);
		state->loginData.hardwareID.hwid.snesHWID.snesHardwareID.serialNumber[0]++;
		break;
	case 20:
		// Make this look like a post-ANI connect from some random phone
		// number.  We hose the boxIDs, DB, and stuff in happyPhone after
		// scrambling the last 4 digits (so it'll create a new account
		// instead of restoring to an older one).
		// (tests unknown folks showing up)
		//
		state->loginData.userID.box.box = -1;
		state->loginData.userID.box.region = -1;
		state->NGPVersion = 1;
		srandom(time(0) ^ (getpid() << 16));
		strcpy(state->boxPhoneNumber.phoneNumber, happyPhone);
		sprintf(state->boxPhoneNumber.phoneNumber+7, "%.4d",
			random() % 10000);
		Logmsg("Mangle: using random phone '%s'\n",
			state->boxPhoneNumber.phoneNumber);
		break;
	default:
		// Egad!
		//
		PLogmsg(LOGP_FLAW, "Wanted to mangle, nobody home (%d).\n", mode);
		break;
	}

	return (kNoError);
}
#endif

//
// Server_ValidatJ0120Connect:
//
static Err Server_ValidateJ0120Connect(ServerState *state, userIdentification *userID)
{
	SuperPhone	newBoxPhone;
	//phoneNumber	newAccessPhoneNumber;
	Err			err;

	// We have received a Japanese 800 connect from the switcher.
	//
	// At this point we know that the local phone number (without area code)
	// is a legal phone number.  The box has called this number and gotten
	// a busy signal, so there is a good chance that this is really the box's
	// phone number.  Now we have to validate the number.
	//
	Logmsg("Server_ValidateJ0120Connect\n");
	err = Server_PhoneParseAndValidate(state, &newBoxPhone, kPhoneConnect800);

	if (err != kNoError)
	{
		switch (err)
		{
		case kErrPhoneBannedNumber:
			Server_SendDialog(state,
				gettext("XBAND has determined that your phone number is invalid.  Please contact Customer Support."), false);
			break;

		case kErrPhoneBadNPA:
		case kErrPhoneBadNXX:
		case kErrPhoneBadNumber:
		default: 
			Server_SendDialog(state,
				gettext("XBAND could not verify your number.  Please try entering your phone number again."), false);
			break;
		}

		// Send box the phone number with 'X' prepended to indicate error.
		//
		MarkBoxPhoneBad(newBoxPhone.p.phoneNumber);
		Server_SendSetBoxPhoneNumber(state, &newBoxPhone.p);
		return(kServerFuncEnd);
	}

	state->connect800 = true;
	state->disallowGameConnect = true;
	state->abandonShip = true;

	Server_DownloadPOP800Connect(state, &newBoxPhone);
	return(kServerFuncOK);
}
	
static Err
Server_ValidateJX25Connect(ServerState *state, SuperPhone_P newBoxPhone_p)
{
	Err			err;

	//
	// X25 connection. Parse/Normalize/Validate
	//
	PLogmsg(LOGP_PROGRESS, "Server_ValidateJX25Connect\n");

	err = Common_PhoneParse(newBoxPhone_p, state->boxPhoneNumber.phoneNumber,
		kPhoneConnectX25, kPhoneCarrierUndefined, state->boxType, "9", 0);
	Logmsg("Server_ValidateJX25Connect returning %d\n", err);

	// Another copy of this dialog.  This should be consolidated with others.
	//
	if (err != kNoError) {
		Server_SendDialog(state,
			gettext("Your phone number does not appear to be valid as entered. Please verify that it was entered correctly."),	/* DIALOG */
			true);
	}
	return(err);
}

static void
MarkBoxPhoneBad(char *phone)
{
	char	*cp, temp[kPhoneNumberSize];

	for (cp = phone; *cp; cp++) {
		ASSERT(*cp != '-');

		if (!isalpha(*cp))
			break;
	}

	ASSERT(cp);

	temp[0] = 'X';
	temp[1] = NULL;
	strcat(temp, cp);
	strcpy(phone, temp);
}
//
// Check for a mailed for number to replace a failed ANI.
//
static	Err	Server_LookForXmailedPhoneNumber(ServerState *state, SuperPhone_P newBoxPhone_p, PHONE_CONNECT_ENUM connect_type)
{
	Err					err;
	char				buf[256];
	Boolean 			found_mail = false;
	long 				i;
	Mail 				*mail;
	phoneNumber 		tempPhone;
	userIdentification catapult = {
		{-1, 0}, 0, 0, kXBANDPlayerIcon, "", "XBAND.PhoneNumber" };

	strcpy(catapult.userTown, gConfig.catapultTown);

	// First we check to see if the dude has sent us mail with his phone number
	// since he may have called before and we sent him mail/dialog informing him ANI failed.

	for(i = 0; i < state->incomingMail.count; i++)
	{
		mail = state->incomingMail.mailItems[i].mail;
		if(!DataBaseUtil_CompareStrings(mail->to.userName, "XBAND.PhoneNumber"))
		{
			// found message sent for us!
			// ignore title. phone number is in the message
			found_mail = true;
			err = Common_PhoneParse(newBoxPhone_p, mail->message, connect_type,
				kPhoneCarrierUndefined, state->boxType, "9", 0);
			if (err == kNoError) {
				if (PhoneDB_ValidateNumber(newBoxPhone_p) == kNoError)
				{
					Common_PhoneFormatDisplay(newBoxPhone_p->p.phoneNumber, tempPhone.phoneNumber);
					sprintf(buf, gettext("Your phone number has been set to %s."),
						tempPhone.phoneNumber);
					Server_SendDialog(state, buf, true);
					return(kNoError);
				}
			}
		}
		
	}
	return(Server_HandleInvalidConnectNumber(state, found_mail, newBoxPhone_p, &catapult));
}
//
// Validate the the incoming ani is okay
//
static	int	Server_Validate800ANI(ServerState *state, char **ani_cpp, SuperPhone_P phone_p)
{
	char				buf[256];
	char				*ani_cp = *ani_cpp;
	Err					err;

	if ( strlen(ani_cp) < kPhoneMaxLenUS ) {
		PLogmsg(LOGP_FLAW, "WHOA: bad ANI '%s'.\n", ani_cp);
		*ani_cpp = NULL;
	
		return(kErrPhoneInvalidAni);
	}

	//
	// ANI is valid, pull the data out
	//
	err = Common_PhoneParse(phone_p, ani_cp, kPhoneConnect800,
		kPhoneCarrierUndefined, state->boxType, "9", 0);

	if (err != kNoError)
	{
		Logmsg("ANI says caller is '%s'\n", ani_cp);
		PLogmsg(LOGP_FLAW, "GLITCH: value from ANI (%s) is hosed\n", ani_cp);
		
		//
		// Should bail here somehow.  Tell him to reconnect.
		//
		sprintf(buf,
		  gettext("We are having trouble finding the number you are calling from. Please call XBAND Customer Support at 408-777-1500.")); /* DIALOG */
		Server_SendDialog(state, buf, true);
		return (kServerFuncAbort);
	}
	return(kNoError);
}
static	int	Server_HandleInvalidConnectNumber(ServerState *state, Boolean found_mail, SuperPhone_P newBoxPhone_p, userIdentification *catapult)
{
	Mail*		mail;
	messOut		opCode;
	short 		numMails;
	long		controlFlags;
	char		buf[256];

	//
	// Send Dialog
	//
	if (found_mail)	// invalid phone
	{
		// send dialog asking for user to re-send mail since phone number was not understood.
		PLogmsg(LOGP_FLAW, "      (got invalid phone number '%s', sending dialog.)\n",
			newBoxPhone_p->p.phoneNumber);
		sprintf(buf, gettext("We couldn't make out the phone number you sent us. Please resend your phone number to XBAND.PhoneNumber.")); /* DIALOG */
		Server_SendDialog(state, buf, true);
	}
	else
	{
		PLogmsg(LOGP_FLAW, "      (sending dialog and mail to get user phone number)\n");
		sprintf(buf, gettext("We can't determine your phone number. Go to your MailBox. Please read and reply to the message from XBAND.PhoneNumber.")); /* DIALOG */
		Server_SendDialog(state, buf, true);
	}				
	//
	// Send Mail
	//
	mail = (Mail *)malloc(sizeof(Mail) + 512);
	if (mail == NULL)
	{
		PLogmsg(LOGP_FLAW, "No memory to alloc mail to send to NOANI customer.\n");
		Common_Abort();
	}
	strcpy(mail->message, gettext("Please reply to this message and enter your 10 digit area code and phone number into the message box, like this: 408-777-1500")); /* DIALOG - automail */
	mail->from = *catapult;
	strcpy(mail->to.userName, "");
	mail->to.box = state->loginData.userID.box;
	mail->to.userID = state->loginData.userID.userID;
	strcpy(mail->title, gettext("Send us your phone number!"));
	mail->date = Server_GetSegaDate();
	
	//
	// Send the mail
	//
	opCode = msReceiveMail;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	numMails = 1;
	Server_TWriteDataSync(state->session, sizeof(short), (Ptr)&numMails);
	Server_SendMailBody(state, mail);

	//
	// to be safe you might wanna clear out his mailq here.  doit.
	//
	// (Does it make sense to do this in any case other than
	// after receiving mail to XBAND.PhoneNumber that we can't
	// parse?  ++ATM950616)
	//
	opCode = msServerMiscControl;
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	controlFlags = kDeleteAllAoutBoxMailFlag;
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr)&controlFlags);

	free(mail);

	return (kServerFuncEnd);
}
static	int	Server_Validate800Connect(ServerState *state, char *ani_cp)
{
Err					err;
SuperPhone			newBoxPhone;

	//
	// Validate the ANI,
	//
	Logmsg("Server_Validate800Connect\n");
	if ((err = Server_Validate800ANI(state, &ani_cp, &newBoxPhone)) != kNoError)
	{
		//
		// if invalid, test mail for uploaded, newBoxPhone number change in mail.
		//
		if (err == kErrPhoneInvalidAni)
		{
			err = Server_LookForXmailedPhoneNumber(state, &newBoxPhone, kPhoneConnect800);
			if (err != kNoError)
			{
				return(err);
			}
		}
		else
		{
			return(err);
		}
	}
	//
	// The new (10/10/94) scheme is that 800 number connections do not
	// process an entire connection.  We must keep the connection brief,
	// so we simply look up his local access POP, program the box with
	// his newBoxPhone number and POP number, send him the "Welcome To XBAND
	// News", and tell him to redial us on X25.
	//
	// We do a nasty trick.  We set the box newBoxPhone number to include its
	// area code (10 digits in length).  When the box reconnects via X25,
	// if the newBoxPhone number is 10 digits in length, then we know it just
	// came from 1-800.  This is because normally the box has an 8-digit
	// newBoxPhone number (336-1735)).
	//
	state->connect800 = true;
	state->disallowGameConnect = true;
	state->abandonShip = true;
	return(Server_DownloadPOP800Connect(state, &newBoxPhone));
}
static Err	Server_DownloadPOP800Connect(ServerState *state, SuperPhone *newBoxPhone)
{
	// Do not put parens or dashes in the number, or
	// Server_SendSetBoxPhoneNumber will strip off the area code.  Very
	// baaaad, as we must send it a 10 digit number so the next X25
	// connect can determine that it just came from 1-800.  Note that the
	// only prob with this scheme is that we lookup the guy's POP twice
	// (one on 800, once on X25).  Sigh.
	//

	// give the box a 10-digit number. eg. 4083361735
	//
	Server_SendSetBoxPhoneNumber(state, &newBoxPhone->p);

	//
	// lookup, update pops, update box, 800 connect, redial
	//
    return(Server_PopUpdate(state, 0, 0, &newBoxPhone->p, 0, k800_CONNECT, true));

#ifdef RELOCATE_USERS
	// We may need to force certain kinds of boxes to connect to a
	// particular server (e.g. make SNES boxes log into the production
	// server before we get CATAPULT,SNES switched over).
	//
	if (state->platformID == kPlatformSNES) {
		PLogmsg(LOGP_NOTICE, "Forcing '%.4s' to CATAPULT,SEGA\n",
			(char *)&state->platformID);
		Server_SendXYString(state, "CATAPULT,SEGA\r", kStringType,
			kCompuserveReturn1);
	}
#endif	/*RELOCATE_USERS*/
	return (kServerFuncEnd);
}
static	void	Server_ValidateX25Connect(ServerState *state, SuperPhone_P newBoxPhone_p, int *newPhoneFlag)
{
	Err			err;
	//
	// X25 connection.  Check if long boxphone number.  if so, last connect
	// was through 1-800.
	//
	Logmsg("Server_ValidateX25Connect\n");
	err = Common_PhoneParse(newBoxPhone_p, state->boxPhoneNumber.phoneNumber, kPhoneConnectX25,
		kPhoneCarrierUndefined, state->boxType, "9", 0);

	if (err == kNoError)
	{
	
		Logmsg("Server_ValidateX25Connect:len:%d:simulator:%d\n",
			newBoxPhone_p->length, newBoxPhone_p->simulator);
		switch(newBoxPhone_p->length)
		{
		case	kPhoneMaxLenUS:
			if (!newBoxPhone_p->simulator)
			{
				*newPhoneFlag = true; // new b/c user dialed 800 number
				state->firstX25Connect = true;
			}
			break;
		case	(kPhoneLocalUS):
			// else it is just another normal X25 connection.
			break;
		default:
			ASSERT_MESG(0, "Phone number on X25 connect isn't 7 or 10 or 11 in length!\n");
			// hmmm. if not, should force a redial?
			//
			// if the phone number isn't 8 or 10 or 11 digits in length and
			// this isn't a 1-800 ANI connect, then something is seriously
			// wrong.  Perhaps it's a hacker?  What should we do?  11.17.94 dj
			//
		}
	}
}
//
// Does not create, just checks to see if it is there!!!!!!
// [ Um, GetAccount creates the account, so by association calling this
// routine WILL result in an account being created. ]
//
int	Server_ValidateAccount(ServerState *state)
{
	Err	err;
	//
	// Look up the account.
	//
	state->account = NULL;
	err = Server_GetAccount(state, &state->account);
	if (err != kNoError) {
		PLogmsg(LOGP_PROGRESS, "Server_ValidateLogin bailing (%d)\n", err);
		return (err);
	}
	if (state->account == NULL) {
		PLogmsg(LOGP_FLAW, "Successful return from GetAccount but NULL acct\n");
		Server_SendDialog(state,
			gettext("XBAND is having difficulties.  Please try again later."), /* DIALOG */
			false);
		return (kServerFuncEnd);
	}


	//
	// Make sure the account has a platformID in it.  (This should no
	// longer be necessary - ATM 950520.)
	//
	// Two possibilities: it has never been set (and is therefore zero), or
	// it was set to the wrong thing (possibly because the server is hosed
	// and restored us to the wrong account).
	//
	// If it's zero, set it.  If it's nonzero... I dunno.
	//
	if (state->account->boxAccount.platformID != state->platformID) {
		Logmsg("NOTE: account has platformID 0x%.8lx, box says it's '%.4s'\n",
			state->account->boxAccount.platformID, (char *)&state->platformID);
		if (state->account->boxAccount.platformID == 0) {
			Logmsg("Updating account to match box (%.4s)\n",
				(char *)&state->platformID);
			state->account->boxAccount.platformID = state->platformID;
			state->account->boxModified |= kBA_platformID;
		} else {
			PLogmsg(LOGP_FLAW,
				"ERROR: mismatched platformIDs 0x%.8lx vs 0x%.8lx\n",
				state->account->boxAccount.platformID, state->platformID);
			// now what?
		}
	}
	return(kNoError);
}
static	void	Server_MakeNewPhoneNumber(ServerState *state, userIdentification *userID, SuperPhone_P newBoxPhone_p, phoneNumber * newAccessPhoneNumber)
{
phoneNumber			dl;						// download number
Err					syncErr;
phoneNumber			*boxPhone_p;			// used for first X25 connect
int					x25;					// what type of x25 connect
	// (we're forcing a box update here)
	// (lastGamePhone no longer set here)

	// Set the boxPhoneNumber.  Server_SendSetBoxPhoneNumber will strip
	// off the area code from newBoxPhone and will send an 8 digit
	// number (e.g 123-4567), no area code.  Note that newBoxPhone
	// will be uncorrupted (good, cuz we gotta store it in their account).
	//
	// 950609: we do NOT want to do this if the account is closed;
	// otherwise they'll have to go back and get ANI after we fry their
	// boxIDs.
	//
	if (state->account->userAccount.accountStatus != CAT_ACCT_STATUS_CLOSED)
	{
		Common_PhoneFormatDisplay(newBoxPhone_p->p.phoneNumber, dl.phoneNumber);
		Server_SendSetBoxPhoneNumber(state, &dl);
	} else {
		PLogmsg(LOGP_NOTICE,
			"NOTE: not sending stripped number to CLOSED box\n");
	}
	if (state->firstX25Connect) {
		// At this point box has been reprogrammed with the new box
		// phone number. Explicitly synchronize with the box to make
		// sure that the server and the box agree on its box number.
		//
		// (This is an incremental improvement... it's still possible
		// for us to get a SIGHUP either before or after the box
		// receives the data, in which case the UpdateUserPhoneNumber
		// call doesn't get made.  However, the margin of failure
		// is smaller.  ++ATM)
		//
		//syncErr = Server_GetHiddenSerials(state, &s1, &s2);
		syncErr = Server_SyncWithBox(state);
		if (syncErr == kServerFuncOK)
		{
			state->boxPhoneSyncDone = true;
		}
		boxPhone_p = &newBoxPhone_p->p;
		x25 = kX25_FIRST_CONNECT;
	}
	else
	{
		boxPhone_p = 0;
		x25 = kX25_OTHER_CONNECT;
	}
	//
	// record the new box phone
	//
	strcpy(state->boxPhoneNumber.phoneNumber, newBoxPhone_p->p.phoneNumber);

	//
	// update pop, town, x25, no redial
	//
    Server_PopUpdate(state, 0, userID, boxPhone_p, newAccessPhoneNumber, x25, false);
}

//
// This is the default X25 processing.
//
static	int	Server_DefaultX25(ServerState *state, userIdentification *userID, SuperPhone_P newBoxPhone_p, phoneNumber * newAccessPhoneNumber)
{

	// If this was a brand-new account, and they didn't come in on 1-800,
	// it's either a confused box or a hacker.  Do something?
	//

	if (state->boxOSState.boxFlags & kCurUserMoved) {
		// Just log it for now.  Probably a simulator.
		//
		PLogmsg(LOGP_NOTICE, "Neat trick, user hit New Number but no ANI.\n");
	}

	// If we just created an account, but they didn't come in over ANI,
	// something is screwed up.  Since we don't send them an area code
	// anymore, there's no way to get their full phone number.  We have
	// to force a 1-800 redial.
	//
	// HOWEVER, this sucks when we're debugging.  As a kluge, if the
	// box has a full 11-digit number, don't force a redial.  Instead,
	// pretend we got ANI data and do it again.
	//
	if (state->accountCreated) {
		if (newBoxPhone_p->simulator)
		{
			PLogmsg(LOGP_DBUG, "No account info, faking ANI with (%s)\n",
				state->boxPhoneNumber.phoneNumber);
			// want the last 10 digits, since that's what ANI gives us
			Server_MakeNewPhoneNumber(state, userID, newBoxPhone_p, newAccessPhoneNumber);
			return(kNoError);
		}
		else if (LOCALE_PHONE_C())
		{
			PLogmsg(LOGP_NOTICE, "No account info, no ANI, forcing redial\n");
				Server_ForceBoxRedial(state, true);
		}
		else if (LOCALE_PHONE_JA())
		{
			//PLogmsg(LOGP_DBUG, "Japan, only creates ACCOUNTS on 0120 connects, why are we here\n");
		}
		return(kServerFuncOK);
	}

	Logmsg("Old phone info: box='%s', pop='%s'[%d], altPop='%s'[%d], town='%s'\n",
		state->account->boxAccount.gamePhone.phoneNumber,
		state->account->boxAccount.popPhone.phoneNumber,
			state->account->boxAccount.popPhone.scriptID,
		state->account->boxAccount.altPopPhone.phoneNumber,
			state->account->boxAccount.altPopPhone.scriptID,
		state->account->boxAccount.homeTown);

	//
	// Do happy, happy, pop joy
	//
    Server_PopUpdate(state, 0, 0, 0, newAccessPhoneNumber, kX25_OTHER_CONNECT, false);

	// Okay, we're in through X.25.  Do we have a phone number in
	// the account struct?  (Improper creation can get us an account
	// with a blank phone number.)  We don't want to check this for
	// ALL connects, since we could throw a non-800 call into infinite
	// redial.
	//
	// (Which we might be doing ANYWAY.  Wait and see.)
	//
	if (LOCALE_PHONE_C())
	{
		if (strlen(state->account->boxAccount.gamePhone.phoneNumber) < kPhoneLongDistUS) {
			PLogmsg(LOGP_NOTICE, "No gamePhone set, forcing 800 redial\n");
			Server_ForceBoxRedial(state, true);
			return(kServerFuncOK);
		}
	}
	return(kNoError);
}
static	void   Server_ForceBoxRedial(ServerState *state, long tell_user)
{
	phoneNumber	redialNumber;
	char		buf[256];

	memset(&redialNumber, 0, sizeof(redialNumber));
	Server_SendSetLocalAccessPhoneNumber(state, &redialNumber, &redialNumber, true);
	state->disallowGameConnect = true;
	state->abandonShip = true;
	// I18N Appears:  When XBAND thinks that you are dialing from 
	//           a new number, but haven't selected New Number.
	// Solution: If the problem persists, it is possible that 2 
	//           modems are sharing one account.  This should be 
	//           escalated to Catapult.
	// 
	if (tell_user)
	{
		sprintf(buf, gettext("We don't seem to have your phone number.  You will automatically redial XBAND's 800 number.")); /* DIALOG */
		Server_SendDialog(state, buf, false);
	}
}

// Make sure their box phone matches what's in the account.  This can
// get hosed if two boxes are clones of each other.  Just make them
// dial new number.
//
// If the box has a xxx-yyyy number, copy the last 7 digits of the
// boxAccount.gamePhone into "buf" to compare against.  Otherwise
// it must have the 10 digit number after a recent ANI (or the 11 digit
// number after a fake ANI from a sim).
//
static	int	Server_CheckAccountPhoneNumber(ServerState *state, SuperPhone_P newBoxPhone_p)
{
char		*buf_p;

	if 	(LOCALE_PHONE_JA())
	{
		return(kNoError);
	}

	if (newBoxPhone_p->length == (kPhoneLocalUS+1))
	{
		buf_p = state->account->boxAccount.gamePhone.phoneNumber;
	} else {
		buf_p = state->boxPhoneNumber.phoneNumber;
	}

	if (Common_PhoneCompareNumbers(buf_p, newBoxPhone_p->p.phoneNumber) != 0)
	{
		return(Server_SharedPhoneNumber(state, buf_p));
	}
	return(kNoError);
}
//
// 4.10.95
// If UCA or our internal customer support detects 2 modems on the
// same account, they must set the splitModemIncest bit in the
// boxAccount->csUpdatedFlags.  They must also ensure that
// originalGamePhone is set to the boxPhone of the real owner of the
// account.  Then, if some box dials in on the account from a
// different phone number, it will get its boxid set to -1, -1, and
// bounced off to find its own damned account!
//
// To make this bulletproof, we should really have something
// somewhere in the account that tells us that the last server login
// was completed successfully (ie. no SIGHUP), so we can be sure this
// isn't a spurious example of a moved box and a sighup.  But this
// here ought to take care of it pretty darned well.
// 4.10.95  DJ
//
static	Err	Server_SharedPhoneNumber(ServerState *state, char *buf_p)
{
	char			buf[256];
	BoxSerialNumber boxsernum;

	PLogmsg(LOGP_NOTICE, "Box's phone (%s) != gamePhone (%s).  Redialing for a restorebyphonenumber.\n",
		state->boxPhoneNumber.phoneNumber, buf_p);
	Server_ForceBoxRedial(state, false);
	
#if	0
	Server_SharedPhoneDeadCode();
#endif
	if((state->account->boxAccount.csUpdatedFlags & kCSUpdatedFlag_SplitModemIncest) &&
	   Common_PhoneCompareNumbers(state->account->boxAccount.originalGamePhone.phoneNumber, buf_p))
	{
		state->account->boxAccount.csUpdatedFlags &= ~kCSUpdatedFlag_SplitModemIncest;
		state->account->boxModified |= kBA_csUpdatedFlags;

		boxsernum.box = -1;
		boxsernum.region = -1;
		Server_SendNewBoxSerialNumber(state, &boxsernum);

		sprintf(buf, gettext("We have detected 2 modems sharing the same account.  You will redial XBAND to try and find your correct account."));  	/* DIALOG */
	}
	else
	{
		// I18N Appears:  When XBAND thinks that you are dialing from 
		//           a new number, but haven't selected New Number.
		// Solution: If the problem persists, it is possible that 2
		//           modems are sharing one account.  This should be
		//           escalated to Catapult.
		//
		sprintf(buf, gettext("We're not sure what number you're dialing from.  You will automatically redial XBAND's 800 number.")); /* DIALOG */
	}
	Server_SendDialog(state, buf, false);
	return(kServerFuncOK);
}
// If they call in within this many seconds of being added to the
// purgatory queue, then chances are they are about to be dialed or
// were being dialed as they connected to the server.  This is Very Bad.
// They should be charged a credit and not put on the queue.
//
// The value should be less than the amount of time it takes for the
// master to complete his server connect and dial the slave, and for
// the slave to subsequently reconnect to the server (presumably after
// a failed peer-to-peer connect).  So the value is equal to the total
// server connect time plus the peer connect time.
//
// Assume 15 seconds to navigate X.25 provider (currently 30), 10 seconds of
// actual server conversation (currently 10 to 90), 15 seconds for the
// peer-to-peer connect with all its retries (currently a lot more),
// call it 40 seconds.  [Hitting "redial" on a box the instant the master
// gets matched causes the slave to arrive 35 seconds after being placed
// on purgatory; the slave will exit just in time to get called (though
// this will change if they reduce the retry count on the peer connects).
// So sending it out much later than 35 seconds is futile, because the
// master will have given up already.]
//
// Tweak as necessary, but *be* *conservative*.
//
static	void	Server_CheckPlayerQueStatus(ServerState *state)
{
#	define kMinReregisterDelay	40		// no longer lives in matching header

	//
	// (We want to do this as early as possible, to avoid hosed matches.)
	//
	// If they're currently on a wait queue for a different game, knock
	// them off.  The handling of this for credit penalties and general
	// yelling is done in other places.
	//
	if (Server_IsPlayerOnQueue(state)) {
		if (state->gameIDData.gameID !=
			state->account->boxAccount.lastSlaveInfo.gameID)
		{
			Logmsg("Player is on queue, for different game!\n");
			Server_DequeuePlayer(state,
				state->account->boxAccount.lastSlaveInfo.gameID);
		} else {
			//Logmsg("Rereg last matchup %d seconds ago\n",
			//	time(0) - state->account->boxAccount.lastMatchup.when);
			if (state->challengeData.userID.box.box ==
				kDownloadOnlyMailSerialNumber)
			{
				Logmsg("Player is on queue, and now doing a mail-only connect.\n");
				Server_DequeuePlayer(state,
					state->account->boxAccount.lastSlaveInfo.gameID);
			} else {
				Logmsg("Player is on queue, and is re-registering.\n");
				// Let the matcher deal with it from here?  Unless he needs
				// a new game patch, system patch, or news... but those
				// should be rare.
			}
		}
	} else {
		// They weren't on a queue.  Normally this is a good thing, but if
		// they were matched up just a few seconds ago, they're about to be
		// dialed by their opponent.
		//
		// Determine if they were matched up recently enough that there's
		// some hope of the match completing.  If so, we want to drop them
		// as quickly as possible after putting them back into the "wait for
		// peer" state.
		//
		// If now > lastMatchup.when + kMin, then it's too late.
		// If now < lastMatchup.when + kMin, we're in time.
		// If now < lastMatchup.when, we've beamed out through chronotons.
		//
		if (time(0) <
			state->account->boxAccount.lastMatchup.when + kMinReregisterDelay)
		{
			Logmsg("Player is being called (%d ago), will use id %d\n",
				time(0) - state->account->boxAccount.lastMatchup.when,
				state->account->boxAccount.lastSlaveInfo.contestantID);
			Server_SendDialog(state,
				gettext("Your opponent was dialing you, or is dialing now!  Don't connect to the XBAND Network while waiting for an opponent!"), true); /* DIALOG */
			if (Server_SendWaitForOpponent(state,
				state->account->boxAccount.lastSlaveInfo.contestantID,
				state->account->boxAccount.lastSlaveInfo.randomVal) != kNoError)
			{
				PLogmsg(LOGP_FLAW, "SendWaitForOpponent failed!\n");
			}
			Statusmsg(
				"SunSega: '%s' (%s) Rejected because opponent is dialing!\n",
				state->account->playerAccount.userName,
				state->account->boxAccount.gamePhone.phoneNumber);
			// Can't just abort; have to send some news or the box will
			// explode.  Question is, do we need to charge them a credit
			// here?
			//
			state->abandonShip = true;
		}
	}
}
static	void Server_SetPlayerChallenges(ServerState *state)
{
	//
	// Do stuff with the box flags.
	// (NOTE: Override Sega's accept challenges radio button to challenge area.)
	//
	if (gConfig.overrideSegaAcceptChallenges && (state->platformID == kPlatformGenesis))
	{
		// Invert the logic on ChallengeArea, and update if changed
		int tmp = kRestrictArea_dialLocalPreferred *
			((state->boxOSState.boxFlags & kCurUserAcceptsChallenges) != 0);
		if ((state->account->boxAccount.restrictArea & kRestrictArea_dialLocalPreferred) != tmp)
		{
			state->account->boxAccount.restrictArea &= ~kRestrictArea_dialLocalPreferred;
			state->account->boxAccount.restrictArea |= tmp;
			state->account->boxModified |= kBA_restrictInfo;
			Logmsg("New preference for challenge area (%s)\n", 
				tmp ? "local" : "long");
		}
	}
	else // Don't override, delete existing db items
	{
		// Invert the logic on AcceptChallenges, and update if changed
		//
		int tmp = kPlayerFlags_acceptChallenges *
			((state->boxOSState.boxFlags & kCurUserAcceptsChallenges) == 0);
		if (state->account->playerAccount.playerFlags != tmp) {
			state->account->playerAccount.playerFlags &= ~kPlayerFlags_acceptChallenges;
			state->account->playerAccount.playerFlags |= tmp;
			state->account->playerModified |= kPA_playerFlags;
			Logmsg("New value for acceptChallenges (%s)\n", tmp ? "on" : "off");
		}
	}
}
#ifdef DO_LOG_NETERRS
static	void	Server_LogNetErrs(ServerState *state, userIdentification *userID, char *ani_cp)
{
	//
	// Print some info so DJ can identify us in the net error stuff.
	//
	{
		SuperPhone	phone1, phone2;
		phoneNumber tmpPhone;
		char *cp;

		FPLogmsg(LOG_NETERR, LOGP_DBUG,
			"box=(%ld,%ld)[%ld] boxPhone=%s popPhone=",
			userID->box.box, userID->box.region, userID->userID,
			state->account->boxAccount.gamePhone.phoneNumber);

		// Print the POP phone numbers with the area code on them.
		Common_PhoneParseDefault(state->account->boxAccount.popPhone.phoneNumber, &phone1);
		if (!phone1.npa_len)
		{
			Common_PhoneParseDefault(state->account->boxAccount.gamePhone.phoneNumber, &phone2);
			sprintf(tmpPhone.phoneNumber, "%d%s", phone2.npa, phone1.p.phoneNumber);
			cp = tmpPhone.phoneNumber;
		}
		else
		{
			cp = phone1.p.phoneNumber;
		}
		FPLogmsg(LOG_NETERR, LOGP_DBUG, "%s", cp);

		FPLogmsg(LOG_NETERR, LOGP_DBUG, " altPopPhone=");
		Common_PhoneParseDefault(state->account->boxAccount.altPopPhone.phoneNumber, &phone1);
		if (!phone1.npa_len)
		{
			Common_PhoneParseDefault(state->account->boxAccount.gamePhone.phoneNumber, &phone2);
			sprintf(tmpPhone.phoneNumber, "%d%s", phone2.npa, phone1.p.phoneNumber);
			cp = tmpPhone.phoneNumber;
		}
		else
		{
			cp = phone1.p.phoneNumber;
		}
		FPLogmsg(LOG_NETERR, LOGP_DBUG, "%s", cp);

		FPLogmsg(LOG_NETERR, LOGP_DBUG, " %s\n",
			((ani_cp == NULL) || (strlen(ani_cp) == kPhoneLongDistUS)) ? "X25" : "ANI");
	}
}
#endif	/*DO_LOG_NETERRS*/
#if	0
static	void	Server_SharedPhoneDeadCode()
{
/***********
*
* Turned off 11/30/94  dj.
*
		//
		// Actually, if we get a box with a different idea of its phonenum
		// from the database, then there are probably 2 boxes with the same
		// phone num.  we could use boxAccount.lastGamePhone to help (it
		// *might* have the other number in it?).  The other possibility is
		// he died thru a post800 x25 connect, and box didn't get programmed
		// but the db got updated.
		//
		// * Anyway, what we'll do is set boxsernum to something illegal
		// (-2,-2) and force a redial thru 800. BoxRestore will see the -2, -2
		// and force a restore by phonenum.  If no account at that phone,
		// then will create one.  *
		//
*
* If we detect what looks like 2 boxes on the same account we'll simply force a redial through 1-800.
* The reason this was disabled was that sometimes a single box would get a different idea of its
* phone number from the server if the connection to the server drops halfway through a NewNumber
* connection.... the box gets the new number.... the server SIGHUPS and doesn't update its database.
*
* So, to deal with duplicate boxes at the same phonenumber... what will we do?   I think we should have
* UCA set the splitModemIncest bit in csUpdatedFlags.  When a box logs in with non-matching phone numbers
* we force an 800 dial.  If the number that comes in is different from the originalGamePhone, then we
* kick that box to -1,-1 and it must find its own account.
*
*		boxsernum.box = -2;
*		boxsernum.region = -2;
*		Server_SendNewBoxSerialNumber(state, &boxsernum);
**************/
}
#endif
