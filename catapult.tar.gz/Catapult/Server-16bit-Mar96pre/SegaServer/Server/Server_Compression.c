/*
 * Copyright:	� 1995 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Compression.c,v 1.13 1996/02/27 21:57:02 fadden Exp $
 *
 * $Log: Server_Compression.c,v $
 * Revision 1.13  1996/02/27  21:57:02  fadden
 * Restored changes from revision 1.11.
 *
 * Revision 1.12  1996/01/25  17:51:46  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.10  1995/10/03  16:39:11  fadden
 * Fixed a logmsg.
 *
 * Revision 1.9  1995/09/13  14:24:25  ted
 * Fixed warnings.
 *
 * Revision 1.8  1995/09/11  18:07:49  fadden
 * Changed temporary buffer size to be 2x source.
 *
 * Revision 1.7  1995/09/08  11:50:10  fadden
 * Changed the _Digram routines to be _Encoded, and taught the compress side
 * to try JRHuff instead of Digram.
 *
 * Revision 1.6  1995/07/28  19:49:24  rich
 * Restored digram compression for SJNES box, thx to fadden's Compress() fix.
 *
 * Revision 1.5  1995/07/27  17:34:55  rich
 * For SJNES box: changed from digram to plain compression on send and receive
 * because Server_Digram_SendOptCompressedString() doesn't handle EUC multi-byte
 * characters well.  This should probably be fixed in the future.
 *
 * Revision 1.4  1995/07/10  20:58:48  rich
 * Added Japanese SNES platform (kPlatformSJNES).
 *
 * Revision 1.3  1995/05/26  23:46:12  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_Compression.c

	Contains:	High-level compressed I/O handling.

	Written by: Andy McFadden


*/
#include <stdio.h>
#include <malloc.h>

#include "Common.h"
#include "Common_Log.h"
#include "Common_PlatformID.h"
#include "MegaPack.h"
#include "Common_Missing.h"

PRIVATE int Server_Plain_SendOptCompressedString(ServerState *state, char *string);
PRIVATE int Server_Plain_ReceiveOptCompressedString(ServerState *state, short *sizePtr, char **bufPtr);
PRIVATE int Server_Encoded_SendOptCompressedString(ServerState *state, char *string);
PRIVATE int Server_Encoded_ReceiveOptCompressedString(ServerState *state, short *sizePtr, char **bufPtr);


//
// Send an optionally compressed string.  A string is "optionally" compressed
// if it's compressed on a SNES but not on a Sega.
//
// Kind of cheesy; this should have more arguments directing how the
// work is to be done.
//
// If compression is not used, "string" is sent to the modem, preceeded by
// a short length word.  If compression is used, Digram+RLE or JRHuff is done,
// and the result is sent down preceeded by a short length word.  In both
// cases the string's terminating NULL is included.
//
// Returns success or failure.
//
int
Server_SendOptCompressedString(ServerState *state, char *string)
{
	SubDispatcher subdisp[] = {
		{ kPlatformSNES,	kPlatformSNESMask,	Server_Encoded_SendOptCompressedString },
		{ kPlatformSJNES,	kPlatformSJNESMask,	Server_Encoded_SendOptCompressedString },
		{ kPlatformAny,		0,					Server_Plain_SendOptCompressedString },
		{ 0,				0,					NULL },		// steeeeerike 1!
	};

	return ( (Common_SubDispatch(state->boxOSState.boxType, subdisp))(
		state, string) );
}

//
// Receive an optionally compressed string.
//
// If compression is not used, a short length word is read, and that many
// characters are read into buf.  If compression is used, the string is
// expanded into buf.  The char* pointed to by bufPtr will get a pointer
// to a newly malloc()ed piece of memory of the appropriate size, and sizePtr
// will get the (uncompressed) size of the data read.
//
int
Server_ReceiveOptCompressedString(ServerState *state, short *sizePtr, char **bufPtr)
{
	SubDispatcher subdisp[] = {
		{ kPlatformSNES,	kPlatformSNESMask,	Server_Encoded_ReceiveOptCompressedString },
		{ kPlatformSJNES,	kPlatformSJNESMask,	Server_Encoded_ReceiveOptCompressedString },
		{ kPlatformAny,		0,					Server_Plain_ReceiveOptCompressedString },
		{ 0,				0,					NULL },		// steeeeerike 2!
	};

	return ( (Common_SubDispatch(state->boxOSState.boxType, subdisp))(
		state, sizePtr, bufPtr) );
}


//
// For the Genesis, just send it down plain.
//
PRIVATE int
Server_Plain_SendOptCompressedString(ServerState *state, char *string)
{
	short	size;

	PLogmsg(LOGP_PROGRESS, " Server_Plain_SendOptCompressedString\n");

	size = strlen(string) +1;
	if (Server_TWriteDataSync(state->session, sizeof(short), (Ptr)&size) != noErr)
	{
		return (kServerFuncAbort);
	}
	if (Server_TWriteDataSync(state->session, (long)size, (Ptr)string) != noErr)
	{
		return (kServerFuncAbort);
	}

	return (kServerFuncOK);
}

//
// For the Genesis, just receive it plain.
//
PRIVATE int
Server_Plain_ReceiveOptCompressedString(ServerState *state, short *sizePtr, char **bufPtr)
{
	short	size;

	PLogmsg(LOGP_PROGRESS, " Server_Plain_ReceiveOptCompressedString\n");
	*sizePtr = 0;

	if (Server_TReadDataSync(state->session, sizeof(short), (Ptr)&size) != noErr)
	{
		return (kServerFuncAbort);
	}

	if ((*bufPtr = (char *)malloc(size)) == NULL) {
		PLogmsg(LOGP_FLAW,
			"Out of mem in Server_Plain_ReceiveOptCompressedString (%d)\n",
			size);
		return (kServerFuncAbort);
	}
	if (Server_TReadDataSync(state->session, (long)size, (Ptr)*bufPtr) != noErr)
	{
		return (kServerFuncAbort);
	}

	*sizePtr = size;
	return (kServerFuncOK);
}


//
// For the SNES, compress it with Digram+RLE and then send it down.  For
// SJNES, use JRHuff instead.
//
PRIVATE int
Server_Encoded_SendOptCompressedString(ServerState *state, char *string)
{
	short stringSize, compressedSize;
	char *tmpBuf;
	unsigned long flags;

	PLogmsg(LOGP_PROGRESS, " Server_Encoded_SendOptCompressedString\n");

	// String size does need to include the final NULL byte, so that when
	// the string is expanded it's properly NULL terminated.
	//
	stringSize = strlen(string) +1;

	// Alloc a temporary buffer to hold the compressed string.  For Digram
	// the max expansion is kMPdigramMaxExpansion, but for JRHuff it's
	// the standard MegaPack 2x factor.
	//
	if ((tmpBuf = (char *)malloc(stringSize * 2 + kMPheaderExpansion)) == NULL)
	{
		PLogmsg(LOGP_FLAW, "Out of mem in SendMailMessage (%d)\n",
			stringSize * 2 + kMPheaderExpansion);
		return (kServerFuncAbort);
	}

	// Pick the set of compression methods to try.  We can save some time
	// here by selecting either Digram or JRHuff based on the platformID.
	//
	flags = 0x00000000
		| kMPtryNone
		| kMPuseRLE
		| kMPincludeCRC
		;
	if (state->platformID == kPlatformSJNES)
		flags |= kMPtryJRHuff;					// Japanese
	else
		flags |= kMPtryDigram | kMPremapText;	// English

	if ((compressedSize = Compress(string, tmpBuf, stringSize, flags)) <= 0) {
		PLogmsg(LOGP_FLAW,
			"Compression failed in Server_Encoded_SendOptCompressedString(%d)\n",
			compressedSize);
		free(tmpBuf);
		return (kServerFuncAbort);
	}
	PLogmsg(LOGP_DBUG, " OUTGOING COMPRESSED STRING (%d bytes):\n",
		compressedSize);
	Loghexdump(tmpBuf, compressedSize);

	// Success.
	//
	if (!(tmpBuf[1] & 0x0f)) {
		PLogmsg(LOGP_DBUG,
			"  Outgoing compressed string: only RLE (%d-->%d)\n",
			stringSize, compressedSize);
	} else if ((tmpBuf[1] & 0x0f) == kMPjrHuff) {
		PLogmsg(LOGP_DBUG,
			"  Outgoing compressed string: JRHuff (%d-->%d)\n",
			stringSize, compressedSize);
	} else if ((tmpBuf[1] & 0x0f) == kMPdigram) {
		PLogmsg(LOGP_DBUG,
			"  Outgoing compressed string: Digram table %c %d-->%d (%.2f%%)\n",
			tmpBuf[6], stringSize, compressedSize,
			((float)stringSize - (float)compressedSize) /
				(float)stringSize * 100.0);
	} else {
		PLogmsg(LOGP_DBUG,
			"  Outgoing compressed string: did something? (%d-->%d)\n",
			stringSize, compressedSize);
	}

	Server_TWriteDataSync(state->session, sizeof(short), (Ptr)&compressedSize);
	Server_TWriteDataSync(state->session, (long)compressedSize, (Ptr)tmpBuf);

	free(tmpBuf);
	return (kServerFuncOK);
}


//
// For the SNES, expand it as it comes up.  The actual method used isn't
// important.
//
PRIVATE int
Server_Encoded_ReceiveOptCompressedString(ServerState *state, short *sizePtr, char **bufPtr)
{
	short compressedSize, stringSize;
	char *tmpBuf;

	PLogmsg(LOGP_PROGRESS, " Server_Encoded_ReceiveOptCompressedString\n");

	*sizePtr = 0;

	if (Server_TReadDataSync(	state->session,
								sizeof(short),
								(Ptr)&compressedSize) != noErr)
		return(kServerFuncAbort);

	if ((tmpBuf = (char *)malloc(compressedSize)) == NULL) {
		PLogmsg(LOGP_FLAW, "Out of memory (%d)\n", compressedSize);
		return (kServerFuncAbort);
	}

	// Read in the compressed message body.
	//
	if (Server_TReadDataSync(state->session, (long)compressedSize, (Ptr)tmpBuf)
		!= noErr)
	{
		free(tmpBuf);
		return (kServerFuncAbort);
	}
	PLogmsg(LOGP_DBUG, " INCOMING COMPRESSED STRING:\n");
	Loghexdump(tmpBuf, compressedSize);

	if ((stringSize = GetExpandedSize(tmpBuf)) <= 0) {
		PLogmsg(LOGP_FLAW, "SERVER GLITCH: expanded size = %ld\n", stringSize);
		// We don't *need* to drop the connection, but it will make bugs
		// stand out in a big way.
		//
		free(tmpBuf);
		return (kServerFuncAbort);
	}
	if (stringSize > 1024) {
		// This is probably a box bug.
		PLogmsg(LOGP_FLAW,
			"WARNING: large (%d byte) compressed chunk coming up\n",stringSize);
	}

	// Assume the size of the uncompressed data already includes the final
	// NULL byte.  (The terminating NULL should always be included for both
	// send and receive.)
	//
	if ((*bufPtr = (char *)malloc(stringSize)) == NULL) {
		PLogmsg(LOGP_FLAW,
			"Out of memory in Server_Encoded_ReceiveOptCompressedString (%d)\n",
			stringSize);
		free(tmpBuf);
		return (kServerFuncAbort);
	}

	// Expand the compressed data into the temp buffer.
	//
	if (Expand(tmpBuf, *bufPtr, compressedSize) <= 0) {
		PLogmsg(LOGP_FLAW, "Expand failed\n");
		free(tmpBuf);
		free(*bufPtr);
		return(kServerFuncAbort);
	}

	// Success.  We've already set *bufPtr; set *sizePtr to the length of
	// the uncompressed string.  Not sure if the box actually uses RLE with
	// "none".
	//
	// Nah, this format won't change.  (Actually, it works for both Digram
	// and JRHuff... what more could you ask for.)
	//
	if (!(tmpBuf[1] & 0x0f)) {
		PLogmsg(LOGP_DBUG,
			"  Incoming compressed string: only RLE (%d<--%d)\n",
			stringSize, compressedSize);
	} else {
		PLogmsg(LOGP_DBUG,
			"  Incoming compressed string: table %c %d<--%d (%.2f%%)\n",
			tmpBuf[6], stringSize, compressedSize,
			((float)stringSize-(float)compressedSize)/(float)stringSize*100.0);
	}

	free(tmpBuf);

	*sizePtr = stringSize;
	return (kServerFuncOK);
}

