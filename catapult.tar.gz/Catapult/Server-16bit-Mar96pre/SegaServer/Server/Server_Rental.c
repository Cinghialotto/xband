/*
 * Copyright:	� 1995 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Rental.c,v 1.3 1995/07/10 21:06:11 rich Exp $
 *
 * $Log: Server_Rental.c,v $
 * Revision 1.3  1995/07/10  21:06:11  rich
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.2  1995/05/26  23:46:50  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_Rental.c

	Contains:	Rental program stuff

	Written by: Andy McFadden


*/
#include <stdio.h>

#include "Server.h"
#include "Common.h"
#include "Common_Log.h"
#include "Common_OpaqueStore.h"
#include "OpaqueStoreKeys.h"
#include "Common_PlatformID.h"

//
// One of these per rental smartcard.
//
// We can either allocate them as the cards appear, or grab a bunch as
// we burn smartcards.
//
typedef struct RentalDBEntry {
	int foo;		// define later, when bored
} RentalDBEntry;


//
// Determine whether or not state->loginData.rentalCardSerialNum is a
// valid card.  There are three possibilities:
//
//	- the card is valid
//	- the card has expired
//	- the card was forged and the user is in trouble
//
// Returns kServerFuncEnd if the card is unacceptable, kServerFuncOK if
// the card is valid.
//
int
Server_IsRentalValid(ServerState *state)
{
	if (!state->loginData.rentalCardSerialNum) {
		PLogmsg(LOGP_FLAW,
			"GLITCH: Server_IsRentalValid called with zero rental\n");
		Common_Abort();
		//return (kServerFuncOK);
	}
	if (state->loginData.rentalCardSerialNum == 0xdeadbeef) {
		Server_SendDialog(state,
			gettext("This rental card has expired.  Please contact the store where you rented it for a new one."),	/* DIALOG */
			true);
		return (kServerFuncEnd);
	} else {
		Server_SendDialog(state,
			gettext("Thank you for participating in the BlockBuster XBAND Rental Program!"),	/* DIALOG */
			true);
	}

	return (kServerFuncOK);
}

