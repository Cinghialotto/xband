/*
 * Catapult Entertainment, Inc.
 *
 * $Id: Server_Password.c,v 1.7 1996/01/25 17:51:52 hufft Exp $
 *
 * $Log: Server_Password.c,v $
 * Revision 1.7  1996/01/25  17:51:52  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.6  1995/09/13  14:24:36  ted
 * Fixed warnings.
 *
 * Revision 1.5  1995/07/10  21:03:18  rich
 * Added Japanese SNES platform (kPlatformSJNES).
 *
 * Revision 1.4  1995/07/07  20:48:14  fadden
 * Added Server_SetTransportHold around one routine.
 *
 * Revision 1.3  1995/05/11  05:46:35  fadden
 * Fixed platformID print in Server_no_GenerateRandomPassword.
 *
 */

/*
	File:		Server_Password.c

	Contains:	Password manipulation routines

	Written by: Andy McFadden

	Copyright:	� 1995 by Catapult Entertainment, Inc., all rights reserved.

*/
#include <stdio.h>

#include "Common.h"
#include "Common_Log.h"
#include "Common_PlatformID.h"

#include "Server.h"

#include "SegaIn.h"
#include "DBConstants.h"
#include "StringDB.h"
#include "DBTypes.h"


// ===========================================================================
//		Password erase code stuff
// ===========================================================================

PRIVATE int Server_sega_GenerateRandomPassword(ServerState *state, Password passwd);
PRIVATE int Server_snes_GenerateRandomPassword(ServerState *state, Password passwd);
PRIVATE int Server_no_GenerateRandomPassword(ServerState *state, Password passwd);

int
Server_GenerateAndSendPasswordEraseCode(ServerState *state)
{
	ASSERT(state->account);

	Server_GenerateRandomPassword(state, state->account->playerAccount.passwordEraseCode);
	Logmsg("Server_GenerateAndSendPasswordEraseCode: passwordEraseCode = '%.8s'\n",
		state->account->playerAccount.passwordEraseCode);
	state->account->playerModified |= kPA_erasePassword;
	return (Server_SendPasswordEraseCode(state, state->account));
}

// **************************************************************************
//
// Here are the internals on how the password blaster will work.
// [ This was written for the Genesis, but is still generally applicable. ]
// 
// 1.  Box must have latest patch loaded (this feature will appear in #30)
// 
// 2.  Server downloads a DBItem - type #22, id #0.  This was a reserved type
//     which I appropriated (see DBTypes.h)
// 
// 2a.  That item is a 32 byte binary - actually, it's an array of 4 8byte
//      strings.  Each is one user's secret password.
// 
// 2b.  The construction of those strings is that each byte represents
//      one key.  0x40 = 'A', 0x10 = 'B', 0x20 = 'C'   so for example,
//      0x4010402040101010 is 'ABACABBB'
// 
// 2c.  Using a simple loop you should be able to generate 4, 8byte random
//      passwords any time a box needs a new set.  And, you need to store
//      them in your DB somewhere so a UCA rep can read them off.
// 
// 3.  If the user uses one of them to break in, you will receive a SendQ
//     message on your next connect.  It will be id#22 (IS THIS OK??), and it
//     will be a single byte.  Its very existence tells you that a secret
//     password was used (and therefore compromised) and therefore the
//     entire set needs to be reloaded.
// 
// 3a.  If you care, that byte is actually the player # times 8 - so, if
//      player number 2 broke in, you'll get a single byte value 16.  I don't
//      know if this is necessary, but I had the number in a register* so you
//      get it for free.  Whatever.
// 
//
// **************************************************************************

int Server_SendPasswordEraseCode(ServerState *state, Account *account)
{
DBID theID;
DBType theType;
unsigned char opCode;
long length;
long consts[2];	/* 2 longs per passwd */
#ifdef FUBAR
long button, leftshift, a, b, len;
#endif

	PLogmsg(LOGP_PROGRESS, "Server_SendPasswordEraseCode\n");

	if (!account->playerAccountValid) {
		Logmsg("Server_SendPasswordEraseCode: there is no valid playerAccount.\n");
		return(kServerFuncOK);
	}

#ifdef FUBAR
	len = strlen(account->playerAccount.passwordEraseCode);
	if (len > 8)
		len = 8;
	leftshift = 24;
	consts[0] = consts[1] = 0;
	for(a = b = 0; a < len; a++) {
		if(account->playerAccount.passwordEraseCode[a] == 'A')
			button = (long)kButtonA;
		else
		if(account->playerAccount.passwordEraseCode[a] == 'B')
			button = (long)kButtonB;
		else
			button = (long)kButtonC;

		consts[b] |= (button << leftshift);

		leftshift -= 8;
		if (leftshift < 0) {
			b++;
			leftshift = 24;
		}
	}
#endif

	Common_PasswordAsciiToConsts(state->boxOSState.boxType,
		account->playerAccount.passwordEraseCode, &consts[0], &consts[1]);

	theType = 22;
	theID = account->playerAccount.player;	// 0 thru 3 depending on which player.
	length = 2 * sizeof(long);

	opCode = msAddItemToDB;
	Server_SetTransportHold(state->session, true);
	Server_TWriteDataSync(state->session, sizeof(messOut), (Ptr)&opCode);
	Server_TWriteDataSync(state->session, sizeof(DBType), (Ptr) &theType);
	Server_TWriteDataSync(state->session, sizeof(DBID), (Ptr) &theID);
	Server_TWriteDataSync(state->session, sizeof(long), (Ptr) &length);
	Server_TWriteDataSync(state->session, length, (Ptr)consts);
	Server_SetTransportHold(state->session, false);

	PLogmsg(LOGP_PROGRESS, "Server_SendPasswordEraseCode done\n");
	return(kServerFuncOK);
}


//
// Generate a random password suitable for the current platform.  Password
// is placed into "passwd".
//
void
Server_GenerateRandomPassword(ServerState *state, Password passwd)
{
	SubDispatcher subDisp[] = {
		{ kPlatformGenesis,	kPlatformGenesisMask,	Server_sega_GenerateRandomPassword },
		{ kPlatformSNES,	kPlatformSNESMask,		Server_snes_GenerateRandomPassword },
		{ kPlatformSJNES,	kPlatformSJNESMask,		Server_snes_GenerateRandomPassword },
		{ kPlatformAny,		0,						Server_no_GenerateRandomPassword },
		{ 0,				0,						NULL }		// sproing!
	};

	(Common_SubDispatch(state->boxOSState.boxType, subDisp))(state, passwd);
}

//
// Generate random password for a Genesis.  "random" function is lousy, but
// it doesn't matter.  To be fully random, the length of the password should
// be determined by a random function too.
//
// We only use 7 buttons, for no very good reason.
//
PRIVATE int
Server_sega_GenerateRandomPassword(ServerState *state, Password passwd)
{
	long 	a;
	long	ran;

	ran = state->timeOfThisConnect;
	for (a = 0; a < kPWLen-1; a++) {
		passwd[a] = 'A' + (ran % 3);
		ran >>= 2;
	}
	passwd[a] = 0;
	return 0;
}

//
// Generate random password for a SNES.  Works a lot like the Genesis one.
//
PRIVATE int
Server_snes_GenerateRandomPassword(ServerState *state, Password passwd)
{
	long 	a;
	long	ran;
	static char snesKeys[] = "ABXY";

	ran = state->timeOfThisConnect;
	for (a = 0; a < kPWLen-1; a++) {
		passwd[a] = *(snesKeys + (ran & 3));
		ran >>= 2;
	}
	passwd[a] = 0;
	return 0;
}

//
// If it's not a Genesis or SNES, generate a zero password.
//
PRIVATE int
Server_no_GenerateRandomPassword(ServerState *state, Password passwd)
{
	PLogmsg(LOGP_NOTICE, "NOTE: no password generated for '%.4s'\n",
		(char *)&state->platformID);
	passwd[0] = 0;
	return 0;
}


// ===========================================================================
//		Box password stuff
// ===========================================================================


//
// Disable box passwd info is in SegaIn.h, but here are the useful values:
// 
//   #define       kButtonB        0x10            // note B & C are reversed
//   #define       kButtonC        0x20
//   #define       kButtonA        0x40
// 
// So for example, the password  A B C  would be stored as the string
// 
//   $ 4010200000000000
// 
// And you would program this by setting
// 
//   kConnectPasswordHiConst  to   40102000
//   kConnectPasswordLoConst  to   00000000
//
int Server_DisableBoxWithPassword(ServerState *state, char *reason)
{
Password	srcpw;
long		consts[2];
DBID		ids[2];

	PLogmsg(LOGP_PROGRESS, "Server_DisableBoxWithPassword\n");

	ids[0] = kConnectPasswordHiConst;
	ids[1] = kConnectPasswordLoConst;

#ifdef FUBAR
	consts[0] = ((long)kButtonA << 24) | ((long)kButtonB << 16) | ((long)kButtonC << 8) | ((long)kButtonA);
	consts[1] = ((long)kButtonB << 24) | ((long)kButtonC << 16);
#endif
	strcpy(srcpw, "ABBABB");		// works on SNES and Genesis
	if (Common_PasswordAsciiToConsts(state->boxOSState.boxType, srcpw,
		&consts[0], &consts[1]) != kNoError)
	{
		PLogmsg(LOGP_FLAW, "ERROR: unable to convert box disable pw\n");
		// consts will be zeroed, go ahead and send them to err on safe side
	}
	Logmsg("DisableBox: converted '%.8s' to 0x%.8lx 0x%.8lx\n",
		srcpw, consts[0], consts[1]);

	Server_SendDBConstants(state, 2, ids, consts);

	if(reason)
		Server_SendLargeDialog(state, reason, true);

	strcpy(state->account->boxAccount.password, "ABBABB");
	state->account->boxModified |= kBA_password;

	state->disallowGameConnect = true;
	state->disallowAllService = true;

	return(kServerFuncEnd);

//	return(kServerFuncOK);
// BRAIN DAMAGE.  This should return some kind of status to the box so that it doesn't flush mail, addr book, sendq, or whatever.
}

//
// Clear the box password.
//
int Server_ClearBoxPassword(ServerState *state)
{
long				consts[2];
DBID				ids[2];

	PLogmsg(LOGP_PROGRESS, "Server_ClearBoxPassword\n");

	ids[0] = kConnectPasswordHiConst;
	ids[1] = kConnectPasswordLoConst;
	consts[0] = consts[1] = 0;
	Server_SendDBConstants(state, 2, ids, consts);
	
	state->account->boxAccount.password[0] = 0;
	state->account->boxModified |= kBA_password;

	return(kServerFuncOK);
}

