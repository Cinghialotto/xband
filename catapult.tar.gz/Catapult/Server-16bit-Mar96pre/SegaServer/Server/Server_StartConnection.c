/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_StartConnection.c,v 1.6 1995/10/27 19:43:40 steveb Exp $
 *
 * $Log: Server_StartConnection.c,v $
 * Revision 1.6  1995/10/27  19:43:40  steveb
 * Just did some long needed housecleaning.  No new code.
 *
 * Revision 1.5  1995/05/26  23:47:08  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_StartConnection.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		 <2>	 11/2/94	DJ		Moved printing of env vars to ServerCore.c
		 <1>	10/20/94	DJ		first checked in

	To Do:
*/

#include "ServerCore.h"
#include "Server.h"
#include "ServerState.h"
#include "ServerDataBase.h"

int Server_StartConnection(ServerState *state)
{
	/* What's the point? */
	return( kServerFuncOK );
}

