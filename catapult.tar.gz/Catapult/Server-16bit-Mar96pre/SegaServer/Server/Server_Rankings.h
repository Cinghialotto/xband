/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Rankings.h,v 1.3 1995/08/25 17:44:37 fadden Exp $
 *
 * $Log: Server_Rankings.h,v $
 * Revision 1.3  1995/08/25  17:44:37  fadden
 * Tweaked a proto.
 *
 * Revision 1.2  1995/05/26  23:46:48  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_Rankings.h

	Contains:	Declarations for KON's beloved rating stuff

	Written by:	KON


	Change History (most recent first):

		 <2>	12/13/94	ATM		Changed xpoints to be unsigned.
		 <1>	10/17/94	ATM		Moved here from DataBase_Rankings.h.
		 <6>	10/16/94	ATM		It's a bird!  It's a plane!  No, it's kProvisionalGameCount back
									to 5!
		 <5>	10/15/94	ATM		Changed kProvisionalWinCount back to 0.
		 <4>	10/14/94	ATM		Renamed a constant.
		 <3>	10/14/94	ATM		Changed kProvisionalGameCount from 0 to 5.
		 <2>	10/10/94	ATM		Added gameID to InitializePlayerRankings prototype.
		 <1>	 10/1/94	ATM		Checked into server source tree.
		 <6>	 9/27/94	KON		Added GetNextLevelPoints function.
		 <5>	 9/27/94	KON		Added function to return match point values.
		 <4>	 9/25/94	KON		Change starting rating to 3000 to make sure ratings never go
									negative.
		 <3>	 9/24/94	KON		Added a bunch of reserved fields in the ranking struct so we
									don't have to translate the DB the first time the ranking stuff
									changes.
		 <2>	 9/24/94	KON		First checked in.

	To Do:
*/


#define kProvisionalGameCount 5
#define kProvisionalRating	3000
#define	kMinimumRating	1600
#define	kLevelStandardDeviation	200
 
/*
typedef struct
{
	long	rating;				//managed by CalculateContinuousRankings
	long	numOpponentsPlayed;	//0 through kProvisional means unrated
	long	totalWinsTimesTwo;
	long	totalLossesTimesTwo;
	long	totalXBandPoints;
	long	reserved1;
	long	reserved2;
	long	reserved3;
	long	reserved4;
	long	reserved5;
	long	reserved6;
	long	reserved7;
	long	reserved8;
	long	reserved9;
} Ranking;
*/


void InitializePlayerRankings( RankingInfo *rank, long gameID );
void CalculateContinuousRankings( RankingInfo *r1, RankingInfo *r2,
	long p1Wins, long p2Wins, Boolean forfeitOnly );
unsigned long GetMatchPointValueForP1( RankingInfo *p1Rank, RankingInfo *p2Rank );
unsigned long GetNextLevelPoints( RankingInfo *p1Rank );
long GetCurrentLevel( RankingInfo *p1Rank );

short GetNormalFunctionWin( long rankDelta );


