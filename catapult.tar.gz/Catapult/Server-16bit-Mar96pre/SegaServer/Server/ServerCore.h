/*
 * Catapult Entertainment, Inc.
 *
 * $Id: ServerCore.h,v 1.17 1996/01/25 17:51:37 hufft Exp $
 *
 * $Log: ServerCore.h,v $
 * Revision 1.17  1996/01/25  17:51:37  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.16  1995/11/06  02:40:26  felix
 * Added dispatcher call to Server_UpdateDebitCard, following Server_ClearMiscQueues
 *
 * Revision 1.15  1995/07/07  20:41:05  fadden
 * Added kServerUpdateMiscPrefs.
 *
 * Revision 1.14  1995/05/16  02:16:46  fadden
 * Move kServerUpdateNGPVersion earlier on (will be used to determine validity
 * of DB on sega).
 *
 * Revision 1.13  1995/05/11  05:45:27  fadden
 * Added kServerSendRequestData/kServerReceiveRequestedData to action list.
 * Removed old kSegaIdentification stuff.
 *
 */

/*
	File:		ServerCore.h

	Contains:	Server Core Entry Points

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<40>	10/20/94	DJ		Added kServerStartConnection and kServerCheckAccountCredits
		<39>	10/19/94	DJ		Added kServerValidateInitialSystemPatch and
									kServerGeneralBoxUpdate
		<38>	10/17/94	DJ		Added kNoLoginFile
		<37>	10/10/94	ATM		Added kServerUpdateGameResults to dispatcher table.  Rearranged
									so that ValidateLogin comes after RecvComplete, followed by
									KoolStuff.
		<36>	 10/6/94	ATM		Move box matchup timeout values to Matching.h.
		<35>	 9/28/94	DJ		added kMessageOfTheDayFile
		<34>	 9/26/94	ATM		Added RecvComplete.
		<33>	 9/22/94	ATM		Reorganized table of actions so that ValidateLogin comes before
									SendKoolStuff.
		<32>	 9/14/94	ATM		Added a comment about StartGamePlay.
		<31>	 8/28/94	ATM		Changes for segb.
		<30>	 8/27/94	ATM		seg9 stuff.
		<29>	 8/25/94	BET		Add support for multiple NetErrorRecord types for both X25 and
									800 services.
		<28>	 8/25/94	ATM		Updated to seg7 for f2 ROMs.
		<27>	 8/21/94	DJ		new OS version (seg6)
		<26>	 8/20/94	DJ		oops
		<25>	 8/17/94	DJ		receiveloginversion2
		<24>	 8/16/94	DJ		senddateandtime
		<23>	 8/13/94	DJ		forceend
		<22>	 8/13/94	BET		Add kServerReceiveNetErrors.
		<21>	 8/12/94	DJ		calling validatesystem
		<20>	 8/12/94	DJ		supports multiple ROM versions
		<19>	 8/12/94	DJ		personification done right after validatelogin
		<18>	 8/11/94	DJ		made news send immediately
		<17>	 8/10/94	ATM		Changed timeout back to 10 minutes.
		<16>	 8/10/94	DJ		consuonancitoa
		<15>	  8/6/94	DJ		annaina
		<14>	  8/6/94	DJ		b�ggler
		<13>	 7/26/94	DJ		timeout set to 5 mins
		<12>	 7/25/94	DJ		moved enum here instead of in server.h
		<11>	 7/20/94	DJ		removed configstr from serverstate
		<10>	  7/3/94	DJ		param to CloseServerConnection to avoid TClose (cuz it can hang
									in error case)
		 <9>	 6/10/94	DJ		cheese
		 <8>	  6/5/94	BET		Make it multisession
		 <7>	  6/5/94	BET		Change interfaces
		 <6>	  6/4/94	DJ		just printfing around
		 <5>	  6/1/94	BET		printf
		 <4>	  6/1/94	BET		printf
		 <3>	 5/31/94	BET		Add printf hack
		 <2>	 5/26/94	BET		Update generation of __SERVER__
		 <3>	 5/25/94	DJ		A starting point?
		 <2>	 5/23/94	BET		A starting point?
		 <1>	 5/23/94	BET		Possible poo for you

	To Do:
*/

#ifndef __ServerCore__
#define __ServerCore__

#include "ServerState.h"
#include "Common_PlatformID.h"


#if !defined(__SERVER__) && defined(__MWERKS__)
#define __SERVER__
#endif

//
// This file can have a single line of text that is sent as the opening
// server dialog when you connect.  Generally unused, but can be used on
// a test server to let folks know they are on the test server.
//
#define kMessageOfTheDayFile "MOTD.sunsega"
//
// If this file is present, the connection will be terminated, and a dialog
// box will be sent with the contents of the file.
//
#define kNoLoginFile "NoLogin.sunsega"


// prototypes
Boolean DoCommand(ServerState *boxState);
ServerState *InitServer(char connect_type, char *config);
Boolean KillServer(ServerState *boxState);

Boolean CloseServerConnection(ServerState *boxState);
int InitServerConnection(ServerState *boxState);


//
// This enum drives the server.  The dispatcher entries corresponding to
// the constants are executed in the order that these appear in.  Take
// great care when reorganizing this list.
//
enum
{
	kServerStartConnection = 0,
	kServerReceiveBoxType,
	kServerSendRequestData,		// replies to these are read in ReceiveReqData
	kServerReceiveLogin,
	kServerReceiveCreditDebitInfo,
	kServerReceiveGameID,
	kServerReceiveSystemVersion,
	kServerReceiveCompetitiveChallenge,
	kServerReceiveInterestingDBConstants,
	kServerReceiveNGP,
	kServerReceiveSendQ,
	kServerReceiveAddressBookValidationQueries,
	kServerReceiveMail,
	kServerReceiveGameResults,
	kServerReceiveGameErrorResults,
	kServerReceiveNetErrors,
	kServerReceivePersonification,
	kServerReceiveBoxLogs,
	kServerReceiveRequestedData, // MUST come after all automatic box messages

	kServerRecvComplete,		// <-- this MUST come after all kServerReceive entries

	kServerValidateLogin,
	kServerCheckAccountCredits,
	kServerValidateInitialSystemPatch,
	kServerDownloadKoolStuff,
	kServerValidateSystem,
	kServerUpdateNGPVersion,
	kServerUpdateMiscPrefs,
	kServerGeneralBoxUpdate,	// update changed info in your account like POP, custom icon, 
	kServerProcessAddrBookValidations,
	kServerUpdateGameResults,
	kServerProcessPersonifications,
	kServerUpdateGamePatch,
	kServerProcessSendQ,
	kServerProcessIncomingMail,
	kServerSendMail,
	kServerSendClearSendQ,
	kServerUpdateDebitCard,		// live-debit the debitcard after clearing queues
	kServerSendAccountInfo,
	kServerSendRanking,
	kServerSendDateAndTime,

	kServerTests,					// 34 -- not used?
	
	// Ought to synchronize here, so we don't queue or match people who
	// failed halfway through the connection.
	kServerStartGamePlay,
	kServerSendProblemToken,
	kServerSendValidationToken,
	kServerUpdateDataBaseAccount,
	kServerEndCommunication,
	
	kServerLastAction
};


//
// Dispatcher table definition.
//
typedef struct MessageDispatcher {
	long boxType;	// this is where the kSegaIdentification is stored.
	
	int  (*functions[kServerLastAction])(ServerState *state);
} MessageDispatcher;


/************************************************

kSegaIdentification is defined in Messages.h.  It is built into the ROM of
each box.  We change it for each new version of the ROM.  The starting
value was a long == 'sega'.

We maintain a message dispatch table for each version of the ROM.  It is
important with this cheesy scheme that you don't reorder the message enum
(you can add to it anywhere, but swapping the order of existing messages
will break it.  You would have to create new enums for versions with the
swapped IDs).

Server_ReceiveBoxType (in Server_ReceiveLogin.c) is the first message
received by the server.  It receives the kSegaIdentification into
state->boxOSState.boxType.  It will call
	Server_SwapMessageDispatcher(state->boxOSState.boxType)
to change the dispatcher, if required.

*************************************************/

//
// One of these for every platform we have.  At present this is a relatively
// private struct to ServerCore.c.
//
// The platformID is a 4-character identifier used everywhere (so don't use
// spaces or non-alphanumeric characters).  Some parts of it must appear in
// every ROM ID; for example, all Sega Genesis boxes start with "seg", as
// in "seg1", "seg2", and so on.  The platformIDMask identifies the characters
// that should be stripped away before the comparison is done.
//
// It's possible that we will want a different set of driver enums for
// each platform.  Does not appear to be needed yet.
//
typedef struct Platform {
	char	*platformName;		// string identifier, for happy logs
	long	platformID;			// identifier, like 'sega' or 'snes'
	long	platformIDMask;		// mask for unique parts, to get "seg" or "sn"
	int		numDispatchers;		// how many dispatchers for this platform
	long	*boxTypes;			// supported ROM versions
	MessageDispatcher *dispatchers;	// dispatcher tables, one per box type
	void	(*dispInitFunc)(MessageDispatcher *, long);	// init routine
} Platform;


int Server_SwapMessageDispatcher(ServerState *state, long boxType);
void Server_LoadMessageDispatchers(void);

#endif

