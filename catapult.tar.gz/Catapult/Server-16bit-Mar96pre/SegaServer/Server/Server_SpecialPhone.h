/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_SpecialPhone.h,v 1.5 1995/10/10 10:34:46 ted Exp $
 *
 * $Log: Server_SpecialPhone.h,v $
 * Revision 1.5  1995/10/10  10:34:46  ted
 * Added kSpecialTournamentTest.
 *
 * Revision 1.4  1995/10/03  12:14:36  ted
 * Added kSpecialLookLongFirst flag ($).
 *
 * Revision 1.3  1995/05/26  23:47:06  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_SpecialPhone.h

	Contains:	Declarations for SpecialPhone stuff

	Written by:	Andy McFadden


	Change History (most recent first):

		 <6>	11/27/94	ATM		Added 'W' (short wait) flag.
		 <5>	 11/9/94	ATM		Added 'F' (fucker) flag.
		 <4>	 11/5/94	HEC		Added Medium flag.
		 <3>	 11/3/94	ATM		Added VIP flag.
		 <2>	10/28/94	ATM		Added kSpecialNewGames.
		 <1>	10/28/94	ATM		first checked in

	To Do:
*/


//
// File to read from.
//
#define kSpecialPhoneFile 	"SpecialPhone"

//
// Flags that can be set.
//
#define kSpecialCatapult		(1L)		// Catapult internal phones ONLY
#define kSpecialLongDistance	(1L<<1)		// box can dial long distance
#define kSpecialNewGames		(1L<<2)		// access to beta game patches
#define kSpecialVIPTester		(1L<<3)		// we're paying for their LD calls
#define kSpecialMediumDistance	(1L<<4)		// box can dial within same area code
#define kSpecialFucker			(1L<<5)		// special box we're testing on
#define kSpecialShortWait		(1L<<6)		// give 'em a short wait
#define kSpecialCallingCard		(1L<<7)		// has a calling card for long distance calls
#define kSpecialLookLongFirst	(1L<<8)		// look for long dist match before local
#define kSpecialTournamentTest	(1L<<9)		// tell the matcher player is a tourney one

typedef struct SpecialPhone {
	char	phoneNumber[kPhoneNumberSize];
	long	flags;
	char	callingcard[64];
} SpecialPhone;


Err Server_LoadSpecialPhoneFile(ServerState *state);
long Server_GetSpecialPhone(ServerState *state);
long Server_GetSpecialCallingCard(ServerState *state, char *in, char *out);


