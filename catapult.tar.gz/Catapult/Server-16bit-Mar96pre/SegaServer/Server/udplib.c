#include	"inet.h"
#include	<poll.h>
#include	<memory.h>
int	send_dg(int sockfd, char *data, int n, SOCKADDR_P to_addr_p, int to_len)
{
	if (sendto(sockfd, data, n, 0, to_addr_p, to_len) != n)
	{
		printf("send_dg:failed to send packet:%d\n", errno);
		return(-1);
	}
	return(n);
}
int	poll_dg(int sockfd, int delay)
{
	int				err;
	struct pollfd	pfd[1];

	memset(&pfd, 0, sizeof(pfd));
	pfd[0].fd = sockfd;
	pfd[0].events = (POLLNVAL | POLLPRI | POLLIN | POLLERR | POLLHUP);
	while ((err = poll(pfd, 1, delay)) == -1)
	{
		switch(err)
		{
		case	EAGAIN:		// Allocation  of   internal   data   structures
							// failed,  but  the request shoud be attempted again.
			break;
		case	EFAULT: 	// Some argument points  outside  the  allocated
							// address space.
			printf("poll_dg:EFAULT:fd:%d:errno:%d:\n", pfd[0].fd, errno);
			return(-1);
		case	EINTR:		// A signal was caught during the poll() system call.
			break;
		case	EINVAL:		// The argument nfds is less than zero.
							// nfds is greater than the system limit of open files.
			printf("poll_dg:EINVAL:fd:%d:errno:%d\n", pfd[0].fd, errno);
			return(-1);
		}
	}
	if (err)
	{
		if (pfd[0].revents & POLLNVAL)
		{
			printf("poll_dg:POLLNVAL:fd:%d:errno:%d\n", pfd[0].fd, errno);
			return(-1);
		}
		if (pfd[0].revents & POLLERR)
		{
			printf("poll_dg:POLLERR:fd:%d:errno:%d\n", pfd[0].fd, errno);
			return(-1);
		}
		if (pfd[0].revents & POLLHUP)
		{
			printf("poll_dg:POLLHUP:fd:%d:errno:%d\n", pfd[0].fd, errno);
			return(-1);
		}
		if ((pfd[0].revents & POLLPRI) || (pfd[0].revents & POLLIN))
		{
			return(1);
		}
	}
	else
	{
		return(0);
	}
}
int	recv_dg(int sockfd, char *data, int max_n, SOCKADDR_P from_addr_p, int *from_len)
{
	int	n;

	if ((n = recvfrom(sockfd, data, max_n, 0, from_addr_p, from_len)) < 0)
	{
		printf("recv_dg:failed to recv packet:%d\n", errno);
		return(-1);
	}
	return(n);
}
