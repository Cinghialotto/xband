/*
 * Copyright:	� 1995 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Tournament.h,v 1.20 1995/12/13 19:08:24 chs Exp $
 *
 * $Log: Server_Tournament.h,v $
 * Revision 1.20  1995/12/13  19:08:24  chs
 * Added timestamps to SEtourney matchup and result structs.
 * Detect when an SEtourney box comes in on the wrong player
 * and send a dialog telling which player they should be using.
 *
 * Revision 1.19  1995/12/07  22:02:40  chs
 * Update proto for Server_TourneyRedirectChallenge().
 *
 * Revision 1.18  1995/12/06  20:32:52  chs
 * In Server_IsTourneyConnection(), only say we're in a specific-match tourney
 * if we are really playing a tourney round Right Now.
 * Fix function names in Logmsg's.
 * Add "deadzone" tag to tourney-spec file.
 *
 * Revision 1.17  1995/12/04  16:37:43  chs
 * Added support for specific-match (currently single-elimination) tourneys.
 *
 * Revision 1.16  1995/11/01  10:29:17  chs
 * Split tourney "debug" flag into "nomatcher" and "nogamepatch" flags,
 * to allow selective disabling of the various pieces of a tourney.
 *
 * Revision 1.15  1995/10/16  14:29:46  sriram
 * Cleaned up old tourney stuff. Modifications for new tourney format.
 *
 * Revision 1.14  1995/05/26  23:47:14  jhsia
 * switch to rcs keywords
 *
 */


#ifndef _Server_Tournament_
#define _Server_Tournament_

#include "DataBase_Match.h"

// Tourney Types:
//	kTourneyAutoMatch 	
//		specifies qualifying rounds. 
//	kTourneySpecificMatch	
//		specifies single-elimination rounds.
//
enum {
    kTourneyAutoMatch = 1,
    kTourneySpecificMatch
};

#define kTourneyAutoMatchTag		"auto"
#define kTourneySpecificMatchTag 	"specific"
#define kTourneyNoGamePatchTag		"nogamepatch"
#define kTourneyNoMatcherTag		"nomatcher"
#define kTourneyDeadzoneTag			"deadzone"

#define kTourneyNoGamePatchFlag		(1<<0)
#define kTourneyNoMatcherFlag		(1<<1)
#define kTourneyDeadzoneFlag		(1<<2)

typedef struct TourneyData {
    long	platformID;
    long	gameID;
    long        startTime;
    long	endTime;
    int		type;
    int		flags;
} TourneyData;


//
// Tourney result status:
//
// Misc. status indicators for tournament results
// kTourneyCallWaitingHoser  - Winning/tied player got call
// kTourneyCallWaitingFucker - Losing player got call
//
#define kTourneyUnknownError			(1<<0)
#define kTourneyResetMaybe			(1<<1)
#define kTourneyResetDefinite	  		(1<<2)
#define kTourneyCordPullFucker			(1<<3)
#define kTourneyCallWaitingHoser		(1<<4)
#define kTourneyCallWaitingFucker		(1<<5)
#define kTourneyNotEnoughCompletedTie		(1<<6)
#define kTourneyEnoughCompletedTie		(1<<7)
#define kTourneyEnoughCompletedLocalWinner	(1<<8)
#define kTourneyEnoughCompletedRemoteWinner	(1<<9)

typedef struct TourneyResult {
    int		flags;
} TourneyResult;


/*
 * Single-elimination tourney data (in opaquestore)
 */
#define kTourneySEResult_regurgValid	(1<<0)
#define kTourneySEResult_resultValid	(1<<1)
#define kTourneySEResult_eresultValid	(1<<2)

typedef struct TourneySEResult {
	time_t			time;
	int				valid;
	MatchupRegurg	regurg;
	NewGameResult	result;
	NewGameResult	eresult;
} TourneySEResult;

typedef struct TourneySEMatchup {
	time_t			time;
	Matchup			matchup;
} TourneySEMatchup;

#define kMaxTourneySEMatchups 10
#define kMaxTourneySEResults 10

typedef struct TourneySEInfo {
	int					state;
	int					player;
	BoxSerialNumber		oppbox;
	int					oppplayer;
	int					matchupcount;
	TourneySEMatchup	matchups[kMaxTourneySEMatchups];
	int					resultcount;
	TourneySEResult		results[kMaxTourneySEResults];
} TourneySEInfo;

enum TourneyStates {
	kTourneySEState_Play,
	kTourneySEState_NoDecision,
	kTourneySEState_Winner,
	kTourneySEState_Loser,
	kTourneySEState_Done,
};

// function prototypes
int  	Server_GetTourneyType(char *);
long 	Server_GetTourneyTime(char *);
int  	Server_ReadTourneyData(char*, TourneyData**);
Boolean Server_IsTourneyConnection(ServerState*, TourneyData*);
Err	Server_InitializeTourneyData(ServerState*);
int		Server_TourneyRedirectChallenge(ServerState *);
int		Server_TourneyGetSEInfo(Account *, TourneySEInfo *);
int		Server_TourneySetSEInfo(Account *, TourneySEInfo *);
void	Server_TourneyProcessMatchup(ServerState *);
void	Server_TourneyProcessGameResults(Account *, MatchupRegurg *,
										 NewGameResult *, NewGameResult *);
void	Server_TourneySendAutoMail(ServerState *state);
Boolean	Server_TourneyDisallowMatch(ServerState *state);

#endif _Server_Tournament_
