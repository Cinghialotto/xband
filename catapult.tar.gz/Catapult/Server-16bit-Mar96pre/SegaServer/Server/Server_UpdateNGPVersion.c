/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_UpdateNGPVersion.c,v 1.15 1996/02/13 20:28:40 fadden Exp $
 *
 * $Log: Server_UpdateNGPVersion.c,v $
 * Revision 1.15  1996/02/13  20:28:40  fadden
 * Declare some read-only tables and their pointers as "const".
 *
 * Revision 1.14  1995/10/23  17:16:53  ansell
 * Changed the NGP version stuff to be signed so we don't think that a -1 is
 * a newer NGP value.
 *
 * Revision 1.13  1995/10/05  02:51:07  ansell
 * Send the aliased name down to the box for NGP list so it won't show stuff
 * like "New Mortal Combat" or "Ken Griffy Baseball-A" to the user.
 *
 * Revision 1.12  1995/09/13  14:24:51  ted
 * Fixed warnings.
 *
 * Revision 1.11  1995/09/11  23:30:53  fadden
 * Moved NGP list generation routines in here (from DataBase_NGPVersion.c).
 *
 * Revision 1.10  1995/08/27  18:53:14  fadden
 * Added support for kGIFlagVIPAndGameTester.
 *
 * Revision 1.9  1995/07/10  21:12:19  rich
 * Added Japanese SNES platform (kPlatformSJNES).
 *
 * Revision 1.8  1995/06/08  11:10:52  ted
 * Refer to kBoxFlag_VIP.
 *
 * Revision 1.7  1995/05/26  23:47:20  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_UpdateNGPVersion.c

	Contains:	xxx put contents here xxx

	Written by:	David Jevans


	Change History (most recent first):

		 <4>	11/17/94	ATM		New arg to NGP routines.
		 <3>	 9/29/94	ATM		Changed the way GetLatestNGP works.
		 <2>	  7/1/94	DJ		making server handle errors in Comm layer
		 <1>	 5/27/94	DJ		first checked in

	To Do:
*/

#include <stdio.h>
#include <malloc.h>
#include "Server.h"
#include "ServerCore.h"
#include "ServerState.h"
#include "ServerDataBase.h"

#include "PreformedMessage.h"
#include "Messages.h"
#include "StringDB.h"
#include "Challnge.h"

//
// Local prototypes.
//
PRIVATE int Server_SendGameName(ServerState *state);
PRIVATE int Server_DoNothing(void);
PRIVATE PreformedMessage *Server_GetLatestNGP(long boxType, short boxVersion, long special);



int
Server_UpdateNGPVersion(ServerState *state)
{
	PreformedMessage	*mesg;
	long				special;
	SubDispatcher		subdisp[] = {
		{ kPlatformSNES,	kPlatformSNESMask,	Server_SendGameName },
		{ kPlatformSJNES,	kPlatformSJNESMask,	Server_SendGameName },
		{ kPlatformAny,		0,					Server_DoNothing },
	};

	// If this is a SNES, the game names aren't in the NGP list, so we
	// need to send down a string that will be used on the versus screen.
	// This is as good a time as any.
	//
	// Don't need to send it down for a mail-only connect.
	//
	if (state->challengeData.userID.box.box != kDownloadOnlyMailSerialNumber) {
		(Common_SubDispatch(state->boxOSState.boxType, subdisp))(state);
	}


	// Set "special" to the set of bits in the GameInfoFlags that hold for
	// them.  Right now the interesting bits are 'G' and 'V'.
	//
	special = 0;
	if (Server_GetSpecialPhone(state) & kSpecialNewGames)
		special |= kGIFlagNotAvailable;
	if ((Server_GetSpecialPhone(state) & kSpecialVIPTester) ||
		(state->account->boxAccount.boxFlags & kBoxFlag_VIP))
		special |= kGIFlagVIPOnly;
	if (state->account->boxAccount.boxFlags & kBoxFlag_GameTester)
		special |= kGIFlagVIPAndGameTester;

	// Retrieve NGP version and data, if what the server has is newer than
	// what we have.
	//
	// UPDATE 950911: doesn't come out of rpc.segad any more (and there was
	// much rejoicing).
	//
	//mesg = DataBase_GetLatestNGP(state->boxOSState.boxType, state->NGPVersion,
	//	special);
	mesg = Server_GetLatestNGP(state->boxOSState.boxType, state->NGPVersion,
		special);
	if (mesg == NULL) {
		Logmsg("UpdateNGPVersion: looks like NGP v%d is newest\n",
			state->NGPVersion);
		return (kServerFuncOK);
	}
	Logmsg("UpdateNGP: box had '%.4s' v%d, sending newer [%d bytes]\n",
		(char *)&state->boxOSState.boxType, state->NGPVersion, mesg->length);
	//Loghexdump(mesg->message, mesg->length);

	return (Server_SendPreformedMessage(state, mesg));
}

int Server_DoNothing(void) { return(0); };

//
// For a SNES (or anything else with the stripped-down NGP list), send
// the name of the current game down.
//
int
Server_SendGameName(ServerState *state)
{
	char *name;

	PLogmsg(LOGP_PROGRESS, "Server_SendGameName\n");

	name = Common_AliasedGameName(state->platformID, state->gameIDData.gameID);
	if (name == NULL) {
		Logmsg("Unable to send down game name for %.4s-0x%.8lx\n",
			(char *)&state->platformID, state->gameIDData.gameID);
		return (-1);
	}
	Server_SendWritableString(state, name, kCurrentGameNameString);

	PLogmsg(LOGP_PROGRESS, "Server_SendGameName done\n");
	return (0);
}



// ===========================================================================
//		NGP list generation (formerly in DataBase_NGPVersion.c)
// ===========================================================================

/*
(The interesting remnant of the change history.)

	Change History (most recent first):

		<10>	11/26/94	ATM		NHL '95 is back.
		 <9>	11/22/94	ATM		Up to NGP 8, removed NHL '95.
		 <8>	11/17/94	ATM		New arg to NGP routines.
		 <7>	11/10/94	ATM		Increment NGP after adding more test games.
		 <6>	 11/9/94	ATM		Update NGP version to 5 (added Madden '95).
		 <5>	 11/3/94	ATM		Incremented NGP version to pick up (R) and (TM) changes.
		 <4>	10/20/94	ATM		Incremented NGP version for MK II.
		 <3>	 9/29/94	ATM		Implemented.  Scary thought, as we're two days into beta.
		 <2>	 7/16/94	dwh		#ifndef unix to the Debugger in the apparently unused routine
									below.  (This whole file looks unused, why is it even here?)
		 <1>	 5/27/94	DJ		first checked in
*/



PRIVATE PreformedMessage *Server_segb_GetLatestNGP(short serverVersion, short boxVersion, long special);
PRIVATE PreformedMessage *Server_snes_GetLatestNGP(short serverVersion, short boxVersion, long special);
PRIVATE PreformedMessage *Server_any_GetLatestNGP(short serverVersion, short boxVersion, long special);


//
// Generate a preformed message with the NGP list in it.  Call with the
// box's current NGP version; this will return an NGP list if what we have
// is newer, NULL if not.
//
// Return value is a pointer to a statically allocated PreformedMessage.
// The data pointed to by the PM is allocated with malloc and should be
// freed by the caller.
//
// "special" is a boolean set if the guy is allowed to play games that
// aren't officially available yet.
//
// NOTE to server folks: while all 'sega' ROMs will (probably) see the same
// set of games, the format of the NGP list may be different for each, so
// it's possible that a different NGP routine will be needed for each ROM
// version.
//
PRIVATE PreformedMessage *
Server_GetLatestNGP(long boxType, short boxVersion, long special)
{
	short serverVersion;
	SubDispatcher subdisp[] = {
		{ kBoxType_segb,	0xffffffff,			(INT_FUNC_PTR)Server_segb_GetLatestNGP },
		{ kPlatformSNES,	kPlatformSNESMask,	(INT_FUNC_PTR)Server_snes_GetLatestNGP },
		{ kPlatformSJNES,	kPlatformSJNESMask,	(INT_FUNC_PTR)Server_snes_GetLatestNGP },
		{ kPlatformAny,		0,					(INT_FUNC_PTR)Server_any_GetLatestNGP },
		{ 0,				0,					NULL },		// ka-sploosh!
	};

	serverVersion = Common_GetNGPVersion(boxType);

	return ( (PreformedMessage *)
		(Common_SubDispatch(boxType, subdisp))(serverVersion, boxVersion, special) );
}


//
// Get here for unknown platforms.
//
PRIVATE PreformedMessage *
Server_any_GetLatestNGP(short serverVersion, short boxVersion, long special)
{
	PLogmsg(LOGP_NOTICE, "NOTE: GetLatestNGP for unknown boxType\n");
	return (NULL);
}


//
// Generate an NGP list for a 'segb' Genesis ROM.
//
// Format is:
//		char	msNewNGPList
//		short	size of first part
//		  NGPData
//		  gameInfo[#of games]
//		short	size of second part
//		  char *gameNames[#of games]
//
PRIVATE PreformedMessage *
Server_segb_GetLatestNGP(short serverVersion, short boxVersion, long special)
{
	static PreformedMessage pm;
	segb_NGPData *ngpd;
	segb_gameInfo *gi;			// this is why C coding standards exist
	const GameInfo *gInfo;		// arrrrgh
	long numGames, gameCount;
	unsigned char *ucp, *tmpbuf;
	long size0, size1;
	short tmp;
	int i, j;

	// For the time being, having any one of the "special" criteria will
	// get the game in your NGP list.  FIX me.
	//
	if (special)
		special = 1;

	if (boxVersion >= (serverVersion*2) + special) {
		// He's got the most recent NGP list, don't send anything.
		//
		return (NULL);
	}

	if ((gInfo = Common_GetGameInfo(&numGames)) == NULL) {
		PLogmsg(LOGP_FLAW, "GetGameInfo failed in GetLatestNGP\n");
		return (NULL);
	}
	if (!numGames) {
		PLogmsg(LOGP_NOTICE, "GetGameInfo returned 0 games, no NGP sent\n");
		Common_FreeGameInfo(gInfo);
		return (NULL);
	}

	// Compute sizes of first and second parts.  Want to chase aliases
	// in game names to present a consistent interface.
	//
	size1 = sizeof(short);
	for (gameCount = 0, i = 0; i < numGames; i++) {
		if ((gInfo[i].platformID != kPlatformGenesis) &&
			(gInfo[i].platformID != kPlatformAny))
		{
			continue;
		}
		if (gInfo[i].alias) {
			for (j = 0; j < numGames; j++)
				if (gInfo[j].gameID == gInfo[i].alias) {
					size1 += strlen(gInfo[j].gameName) +1;
					break;
				}
			if (j == numGames) {
				// weird... couldn't find alias reference
				PLogmsg(LOGP_FLAW,
					"NGP Couldn't resolve game alias 0x%.8lx:0x%.8lx\n",
					gInfo[i].gameID, gInfo[i].alias);
				size1 += strlen(gInfo[i].gameName) +1;
			}
		} else {
			size1 += strlen(gInfo[i].gameName) +1;
		}
		gameCount++;
	}
	size0 = sizeof(char) + sizeof(short) +
		(sizeof(segb_NGPData) - sizeof(segb_gameInfo)) +
		sizeof(segb_gameInfo) * gameCount;

	// To avoid problems with longword alignment, we do all the work in a
	// separately allocated buffer, then copy it over when we're done.
	//
	// An alternative is to allocate three extra bytes and skip the first
	// three, but that requires whoever frees it to remember to back up three
	// bytes.
	//
	ucp = (unsigned char *)malloc(size0 + size1);
	tmpbuf = (unsigned char *)malloc(size0);

	pm.message = ucp;
	pm.length = size0 + size1;

	// First comes a size word (short), followed by the NGPData header.
	//
	ngpd = (segb_NGPData *)tmpbuf;
	ngpd->count = gameCount - 1;		// what's with this "0-based" stuff?
	ngpd->version = (serverVersion*2) + special;

	// Next comes an array of gameInfo structs, one per game.  Note that
	// writing into "gi" writes into tmpbuf, which we later copy.
	//
	// With the current implementation, the patchVersion will be set to zero
	// at the time we get here.  This is bad, since the box ROM has version
	// 1 built in (and version 0 might be an invalid value).  If we're
	// seeing 0, change it to 1.
	//
	// KLUGE ALERT: to avoid reporting games we don't allow them to play
	// as available, whack the gameID.  Would be best to omit the game
	// entirely, but it's a bit late to be doing something careful (and the
	// @#$^! test server doesn't work).
	//
	gi = (segb_gameInfo *)&ngpd->gameInfo;
	for (i = 0; i < numGames; i++) {
		if ((gInfo[i].platformID != kPlatformGenesis) &&
			(gInfo[i].platformID != kPlatformAny))
		{
			continue;
		}
		gi->gameID = gInfo[i].gameID;
		if (!special && (gInfo[i].gameInfoFlags & kGIFlagRestrictedMask)) {
			//PLogmsg(LOGP_DBUG, "NGP: player not allowed for 0x%.8lx\n",
			//	gi->gameID);
			gi->gameID = 0xffffffff;
		}
		gi->gameFlags = gInfo[i].gameFlags;
		gi->patchVersion = gInfo[i].patchVersion ? gInfo[i].patchVersion : 1;
		gi++;
	}

	// Copy it over.  Set the message #, the size of the data, and then
	// copy the data itself.
	//
	*ucp++ = msNewNGPList;
	tmp = (short) size0 - (sizeof(short) + sizeof(char));
	memcpy(ucp, &tmp, sizeof(short));
	ucp += sizeof(short);
	memcpy(ucp, tmpbuf, size0 - (sizeof(char) + sizeof(short)));
	free(tmpbuf);

	// Finally comes a size word (short), followed by the gameNames.
	//
	ucp += size0 - (sizeof(char) + sizeof(short));
	tmp = (short) size1 - sizeof(short);
	memcpy(ucp, &tmp, sizeof(short));
	ucp += sizeof(short);

	for (i = 0; i < numGames; i++) {
		if ((gInfo[i].platformID != kPlatformGenesis) &&
			(gInfo[i].platformID != kPlatformAny))
		{
			continue;
		}
		if (gInfo[i].alias) {
			// The box should print the same string for all versions
			// of the game.
			for (j = 0; j < numGames; j++)
				if (gInfo[j].gameID == gInfo[i].alias) {
					strcpy(ucp, gInfo[j].gameName);
					ucp += strlen(gInfo[j].gameName) +1;
					break;
				}
			if (j == numGames) {
				// weird... couldn't find alias reference
				strcpy(ucp, gInfo[i].gameName);
				ucp += strlen(gInfo[i].gameName) +1;
			}
		} else {
			strcpy(ucp, gInfo[i].gameName);
			ucp += strlen(gInfo[i].gameName) +1;
		}
	}

	if (ucp - (unsigned char *)pm.message != size0 + size1) {
		PLogmsg(LOGP_FLAW, "Whoops, NGP created %d bytes, should be %d\n",
			ucp - (unsigned char *)pm.message, size0 + size1);
		Loghexdump(pm.message, pm.length);
		free(pm.message);
		Common_FreeGameInfo(gInfo);
		return (NULL);
	}

	Common_FreeGameInfo(gInfo);
	return (&pm);
}


//
// Send the SNES NGP list down.
//
// Format is:
//		char	msNewNGPList
//		short	size of first part
//		  NGPData
//		  gameInfo[#of games]
//
PRIVATE PreformedMessage *
Server_snes_GetLatestNGP(short serverVersion, short boxVersion, long special)
{
	static PreformedMessage pm;
	snes_NGPData *ngpd;
	snes_gameInfo *gi;		// this is why C coding standards exist
	const GameInfo *gInfo;	// arrrrgh
	long numGames, gameCount;
	unsigned char *ucp, *tmpbuf;
	long size0;
	short tmp;
	int i;

	if (special)
		special = 1;

	if (boxVersion >= (serverVersion*2) + special) {
		// He's got the most recent NGP list, don't send anything.
		//
		return (NULL);
	}

	if ((gInfo = Common_GetGameInfo(&numGames)) == NULL) {
		PLogmsg(LOGP_FLAW, "GetGameInfo failed in GetLatestNGP\n");
		return (NULL);
	}
	if (!numGames) {
		PLogmsg(LOGP_NOTICE, "GetGameInfo returned 0 games, no NGP sent\n");
		Common_FreeGameInfo(gInfo);
		return (NULL);
	}

	// Compute sizes of first (and only) part.
	//
	for (gameCount = 0, i = 0; i < numGames; i++) {
		if ((gInfo[i].platformID != kPlatformSNES) &&
			(gInfo[i].platformID != kPlatformSJNES) &&
			(gInfo[i].platformID != kPlatformAny))
		{
			continue;
		}
		gameCount++;
	}
	size0 = sizeof(char) + sizeof(short) +
		(sizeof(snes_NGPData) - sizeof(snes_gameInfo)) +
		sizeof(snes_gameInfo) * gameCount;

	// To avoid problems with longword alignment, we do all the work in a
	// separately allocated buffer, then copy it over when we're done.
	//
	// An alternative is to allocate three extra bytes and skip the first
	// three, but that requires whoever frees it to remember to back up three
	// bytes.
	//
	ucp = (unsigned char *)malloc(size0);
	tmpbuf = (unsigned char *)malloc(size0);

	pm.message = ucp;
	pm.length = size0;

	// First comes a size word (short), followed by the NGPData header.
	//
	ngpd = (snes_NGPData *)tmpbuf;
	ngpd->count = gameCount - 1;		// what's with this "0-based" stuff?
	ngpd->version = (serverVersion*2) + special;

	// Next comes an array of gameInfo structs, one per game.  Note that
	// writing into "gi" writes into tmpbuf, which we later copy.
	//
	// With the current implementation, the patchVersion will be set to zero
	// at the time we get here.  This is bad, since the box ROM has version
	// 1 built in (and version 0 might be an invalid value).  If we're
	// seeing 0, change it to 1.
	//
	// KLUGE ALERT: to avoid reporting games we don't allow them to play
	// as available, whack the gameID.  Would be best to omit the game
	// entirely, but it's a bit late to be doing something careful (and the
	// @#$^! test server doesn't work).
	//
	gi = (snes_gameInfo *)&ngpd->gameInfo;
	for (i = 0; i < numGames; i++) {
		if ((gInfo[i].platformID != kPlatformSNES) &&
			(gInfo[i].platformID != kPlatformSJNES) &&
			(gInfo[i].platformID != kPlatformAny))
		{
			continue;
		}
		gi->gameID = gInfo[i].gameID;
		if (!special && (gInfo[i].gameInfoFlags & kGIFlagRestrictedMask)) {
			//PLogmsg(LOGP_DBUG, "NGP: player not allowed for 0x%.8lx\n",
			//	gi->gameID);
			gi->gameID = 0xffffffff;
		}
		//gi->gameFlags = gInfo[i].gameFlags;
		//gi->patchVersion = gInfo[i].patchVersion ? gInfo[i].patchVersion : 1;
		gi++;
	}

	// Copy it over.  Set the message #, the size of the data, and then
	// copy the data itself.
	//
	*ucp++ = msNewNGPList;
	tmp = (short) size0 - (sizeof(short) + sizeof(char));
	memcpy(ucp, &tmp, sizeof(short));
	ucp += sizeof(short);
	memcpy(ucp, tmpbuf, size0 - (sizeof(char) + sizeof(short)));
	ucp += size0 - (sizeof(char) + sizeof(short));
	free(tmpbuf);

	if (ucp - (unsigned char *)pm.message != size0) {
		PLogmsg(LOGP_FLAW, "Whoops, NGP created %d bytes, should be %d\n",
			ucp - (unsigned char *)pm.message, size0);
		Loghexdump(pm.message, pm.length);
		free(pm.message);
		Common_FreeGameInfo(gInfo);
		return (NULL);
	}

	Common_FreeGameInfo(gInfo);
	return (&pm);
}

