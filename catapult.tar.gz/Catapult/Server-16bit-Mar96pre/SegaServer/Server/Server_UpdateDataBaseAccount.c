/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_UpdateDataBaseAccount.c,v 1.25 1996/01/25 17:52:05 hufft Exp $
 *
 * $Log: Server_UpdateDataBaseAccount.c,v $
 * Revision 1.25  1996/01/25  17:52:05  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.24  1996/01/10  14:49:21  hufft
 * changed to use libphonedb
 *
 * Revision 1.23  1995/11/13  19:44:41  hufft
 * pop lookup interface changes, rpc returns a list of pops, and dial patterns
 *
 * Revision 1.22  1995/11/06  02:54:16  felix
 * Added calls to Server_DoDebitCardDBUpdate following account update
 *
 * Revision 1.21  1995/10/30  16:46:12  steveb
 * Environment variables read are now XBAND_ANI and XBAND_X25_ADDRESS.
 *
 * Revision 1.20  1995/10/27  19:43:41  steveb
 * Just did some long needed housecleaning.  No new code.
 *
 * Revision 1.19  1995/10/24  16:52:36  ted
 * Clear kCSUpdatedFlag_UpdatedRestrictions if set at end of successful connect.
 *
 * Revision 1.18  1995/10/19  22:26:27  hufft
 * Japan Database Changes
 *
 * Revision 1.16  1995/09/27  18:38:25  hufft
 * added Common_Phone support for Japan Server
 *
 * Revision 1.15  1995/09/13  14:24:50  ted
 * Fixed warnings.
 *
 * Revision 1.14  1995/07/26  14:05:05  ansell
 * Renamed failedServerConnects to totalServerConnects.
 *
 * Revision 1.13  1995/07/17  17:18:02  fadden
 * Major overhaul of Server_UpdateDataBaseAccount().  Split into two pieces,
 * one does the account updating, the other does all the miscellaneous crap
 * that got dumped into the original routine.  Added some extra checks on
 * whether or not the connection is alive to avoid core dumps down in the
 * transport layer.  Removed some long-dead stuff.
 *
 * Revision 1.12  1995/07/10  21:11:23  rich
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.11  1995/07/10  10:45:33  ted
 * Server_SendSetLocalAccessPhoneNumber takes one less argument now.
 *
 * Revision 1.10  1995/06/28  18:12:04  fadden
 * Add a note about sending the MOTD so I don't get confused when DJ gets
 * silly in the middle of the night.
 *
 * Revision 1.9  1995/06/03  17:43:28  fadden
 * Added some ramblings about partial updates (ClearMiscQueues is the key).
 *
 * Revision 1.8  1995/05/26  23:47:16  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_UpdateDataBaseAccount.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		<15>	12/14/94	DJ		portal funny-o-gram
		<14>	12/11/94	ATM		Fix the "type last connect" stuff.
		<13>	 12/6/94	ATM		Added support for kConnTypeHosedSpecificMatch.  Needed because
									we want to refund money after a failed specific match under
									certain circumstances.
		<12>	 12/1/94	DJ		Turned off old stuff from October that clears out neterrors
									based on activation date.
		<11>	11/30/94	SR		Partial DB update on early connect termination
		<10>	11/11/94	ATM		Added support for kConnTypeHosedAutoMatch.
		 <9>	 11/9/94	DJ		If passwordEraseCode used, mark that it cost them 4 extra
									credits in conninfo.
		 <8>	 11/9/94	DJ		Renamed some DB routines to DataBaseUtil_ and also to WrapperDB_
									(for Oracle).
		 <7>	 11/8/94	DJ		Don't send the MOTD on 800 number connects.
		 <6>	 11/7/94	HEC		#include "DataBase_Match.h"
		 <5>	 11/2/94	ATM		Use new connect types enum.
		 <4>	10/25/94	ATM		Add "unused" fields to net error totals.  Change
									kUA_dateLastConnect to kUA_lastConnect, add typeLastConnect.
		 <3>	10/24/94	DJ		added Server_CreateConnectInfo.
		 <2>	10/22/94	ATM		Let Server_SendDialog() do the log messages.
		 <1>	10/20/94	DJ		first checked in

	To Do:
*/

#include <stdio.h>
#include <memory.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "ServerCore.h"
#include "Server.h"
#include "ServerState.h"
#include "ServerDataBase.h"
#include "DataBase_Match.h"
#include "Challnge.h"
#include "Server_Tournament.h"
#include "Common.h"
#include "Common_Missing.h"
#include "PhoneDB.h"

//
// Local prototypes
//
PRIVATE int Server_DoAccountUpdate(ServerState *state);
PRIVATE int Server_DoMiscellaneousStuff(ServerState *state);
PRIVATE	void Server_PrintDebugStatsLine(ServerState *state);

extern long gHangupOkay;

//
// Completely worthless function. ++ATM 950717
//
void Server_CreateConnectInfo(ServerState *state)
{
ConnectInfo	conn;
char		*cp;


	PLogmsg(LOGP_PROGRESS, "Server_CreateConnectInfo\n");

	if (!(state->validFlags & kServerValidFlag_Account))
		return;
	
	ASSERT((state->validFlags & kServerValidFlag_Account));
	ASSERT((state->validFlags & kServerValidFlag_ChallengeOrCompete));
	ASSERT( state->validFlags & kServerValidFlag_TimeOfThisConnect );


	memset(&conn, 0, sizeof(ConnectInfo));


	conn.playerNum = state->account->playerAccount.player;
	conn.date = state->timeOfThisConnect;
	conn.length = (unsigned long)time(0) - state->timeOfThisConnect;	// length of the call (should really be set at last possible second).


	if(state->challengeData.userID.box.box == kDownloadOnlyMailSerialNumber)
		conn.connectType = CAT_SCCONN_TYPE_MAILONLY;
	else
	if (state->challengeData.userID.box.box == kFindNetworkOpponentSerialNumber)
		conn.connectType = CAT_SCCONN_TYPE_CHALLENGE;
	else
		conn.connectType = CAT_SCCONN_TYPE_PLAYERLIST;


	// Store the X25 source node address if applicable.
	//
	if ((cp = getenv("XBAND_X25_ADDRESS")) != NULL)
		strncpy(conn.x25Address, cp, kX25AddressSize);

	if(state->matchup)
		strncpy(conn.phoneNumber, state->matchup->oppPhoneNumber.phoneNumber, kPhoneNumberSize);


	//
	// Now figure out if this connect costs you anything.
	//
	conn.cost = 1;

	//
	// Andy's credit recrediting must be checked here.
	//
	
	if(state->passwordEraseCodeWasUsed)
	{
		conn.cost += kCreditsChargedForPasswordErase;
		// also mark some flag saying password erase was used.
	}
	
	
/*******
	//
	// if no game results and lastconnect was a game connect and state->matchup->warning == kMWarnNone then...
	// we didn't find you an opponent, so you get a refund!
	//
	if (!(state->validFlags & kServerValidFlag_GameResults) && !(state->validFlags & kServerValidFlag_GameErrorResults))
	switch (state->matchup->warning)
	{
		case kMWarnNone:
			break;
		case kMWarnSpecificToAuto:
		case kMWarnSpecificToSpecific:
		case kMWarnAutoChangedGame:
		case kMWarnAutoChangedPlayer:
		case kMWarnAutoToSpecific:
		case kMWarnAutoToAuto:
			break;
	}
*********/

	conn.lastGameStatus = 0;	// should be set properly from state->gameResult.


	PLogmsg(LOGP_PROGRESS, "Server_CreateConnectInfo done\n");
}



//
// Called before EndCommunication to update Account and do things.  Also
// called within SIGHUP signal handler under certain circumstances.
//
int Server_UpdateDataBaseAccount(ServerState *state)
{
	PLogmsg(LOGP_PROGRESS, "Server_UpdateDataBaseAccount\n");

	// Both "halves" of this routine need stuff from the account struct.
	// Make sure the world is sane.
	//
	if (state == NULL) {
		PLogmsg(LOGP_FLAW, "My life is very strange: state == NULL in UDBA\n");
		return (kServerFuncAbort);
	}
	if (!(state->validFlags & kServerValidFlag_Account)) {
		// Canna do this; get here if we ServerFuncEnd early.
		//
		PLogmsg(LOGP_NOTICE,
			"Unable to update account, Account doesn't exist yet\n");
		FPLogmsg(LOG_STATISTICS, LOGP_STATISTICS,
			"# (no account, can't do stats)\n");
		return (kServerFuncOK);
	}


	// If gHangupOkay is set, the connection to the box is either dying or
	// dead, and we shouldn't be trying to send more data down.  (There's
	// probably a better way to do this, but being here at all when
	// gHangupOkay is set is highly questionable.  Fuck, just so the damn
	// thing works...  ++ATM 950717)
	//
	if (!gHangupOkay) {
		Server_DoMiscellaneousStuff(state);
	} else {
		Logmsg("gHangupOkay set, not calling DoMiscellaneousStuff\n");
	}

	// It's possible we could get hit from a signal handler because of a
	// SIGHUP.  Make sure we don't do the update twice.

	// The debit card database is updated here, because:
	// a) It's the end of the connection.
	// b) It shouldn't be updated twice in the case of a SIGHUP.
	//
	if (!state->updateDatabaseDone) {
		Server_DoAccountUpdate(state);
		Server_DoDebitCardDBUpdate(state);
	} else {
		Logmsg("updateDatabaseDone set, not calling DoAccountUpdate\n");
	}

	PLogmsg(LOGP_PROGRESS, "Server_UpdateDataBaseAccount done\n");
	return(kServerFuncOK);
}


//
// Formerly the first and last part of Server_UpdateDataBaseAccount().
//
// This part deals exclusively with updating the user's account in the
// database.  Things like the date and time of this connect, net errors,
// and connect counters.
//
// Does not currently free the account after UpdateAccount.  Since we may
// want persistent SunSegas someday, we should avoid accessing the account
// after this routine is called.
//
PRIVATE int
Server_DoAccountUpdate(ServerState *state)
{
	if (state->updateDatabaseDone) {
		PLogmsg(LOGP_FLAW, "ERROR: DoAccountUpdate called twice?\n");
		return (kServerFuncOK);		// quit it
	}


	Server_CreateConnectInfo(state);


	//
	// Store the date & time of this connect.
	//
	ASSERT(state->validFlags & kServerValidFlag_TimeOfThisConnect);
	state->account->userAccount.dateLastConnect = state->timeOfThisConnect;
	if (state->challengeData.userID.box.box == kDownloadOnlyMailSerialNumber)
	{
		state->account->userAccount.typeLastConnect =
			kConnTypeMailOnly;
	} else if (state->challengeData.userID.box.box == kFindNetworkOpponentSerialNumber)
	{
		if (state->disallowGameConnect)
			state->account->userAccount.typeLastConnect =
				kConnTypeHosedAutoMatch;
		else
			state->account->userAccount.typeLastConnect =
				kConnTypeAutoMatch;
	} else {
		if (state->disallowGameConnect)
			state->account->userAccount.typeLastConnect =
				kConnTypeHosedSpecificMatch;
		else
			state->account->userAccount.typeLastConnect =
				kConnTypeSpecificMatch;
	}
	state->account->userModified |= kUA_lastConnect;


	//
	// Actually, this is now counting serverconnects, not failures (cuz
	// those are already in the neterrors sort of.
	//
	state->account->boxAccount.totalServerConnects++;
	state->account->boxModified |= kBA_totalServerConnects;


	//
	// We really need to distinquish between a server connect that
	// completes OK (ie. EndCommunication exits OK) and when the
	// connection gets dropped during server connect.  This means that
	// Server_UpdateDataBaseAccount should happen after EndCommunication,
	// and we should call it even if we get SIGHUPed cuz the connection
	// drops.  If we get dropped we should increment totalServerConnects
	// and clear out unprocessed BoxFlags for stuff that we aren't sure
	// we should update in the Database (eg. debited credits).
	//
	// We should also not send mail to anyone (although we must verify
	// their addresses in Server_ProcessIncomingMail) until we get through
	// EndCommunication successfully.
	//
	// 9/27/94 dj

	if (state->boxOSState.boxFlags & kBoxIDTrashed)
		FLogmsg(LOG_NETERR,
			"BoxID trashed, looks brand new, not totalling net errs.\n");

	//
	// Total up the neterrors.  (should only be done if successful server
	// connect).
	//
	// Also, don't do it if it's a brand-new box.
	//
	if(state->validFlags & kServerValidFlag_NetErrors800 &&
		!(state->boxOSState.boxFlags & kBoxIDTrashed) && !state->crashRecord)
	{
		state->account->boxAccount.netErrorTotals.serverConnects += state->boxNetErrors800.serverConnects;
		state->account->boxAccount.netErrorTotals.peerConnects += state->boxNetErrors800.peerConnects;
		state->account->boxAccount.netErrorTotals.framingError += state->boxNetErrors800.framingError;
		state->account->boxAccount.netErrorTotals.overrunError += state->boxNetErrors800.overrunError;
		state->account->boxAccount.netErrorTotals.packetError += state->boxNetErrors800.packetError;
		state->account->boxAccount.netErrorTotals.packetRetransError += state->boxNetErrors800.packetRetransError;
		state->account->boxAccount.netErrorTotals.callWaitingInterrupt += state->boxNetErrors800.callWaitingInterrupt;
		state->account->boxAccount.netErrorTotals.noDialtoneError += state->boxNetErrors800.noDialtoneError;
		state->account->boxAccount.netErrorTotals.serverBusyError += state->boxNetErrors800.serverBusyError;
		state->account->boxAccount.netErrorTotals.peerBusyError += state->boxNetErrors800.peerBusyError;
		state->account->boxAccount.netErrorTotals.serverDisconnectError += state->boxNetErrors800.serverDisconnectError;
		state->account->boxAccount.netErrorTotals.peerDisconnectError += state->boxNetErrors800.peerDisconnectError;
		state->account->boxAccount.netErrorTotals.serverAbortError += state->boxNetErrors800.serverAbortError;
		state->account->boxAccount.netErrorTotals.peerAbortError += state->boxNetErrors800.peerAbortError;
		state->account->boxAccount.netErrorTotals.serverNoAnswerError += state->boxNetErrors800.serverNoAnswerError;
		state->account->boxAccount.netErrorTotals.peerNoAnswerError += state->boxNetErrors800.peerNoAnswerError;
		state->account->boxAccount.netErrorTotals.serverHandshakeError += state->boxNetErrors800.serverHandshakeError;
		state->account->boxAccount.netErrorTotals.peerHandshakeError += state->boxNetErrors800.peerHandshakeError;
		state->account->boxAccount.netErrorTotals.serverX25NoServiceError += state->boxNetErrors800.serverX25NoServiceError;
		state->account->boxAccount.netErrorTotals.callWaitingError += state->boxNetErrors800.callWaitingError;
		state->account->boxAccount.netErrorTotals.remoteCallWaitingError += state->boxNetErrors800.remoteCallWaitingError;
		state->account->boxAccount.netErrorTotals.scriptLoginError += state->boxNetErrors800.scriptLoginError;
	}
	if(state->validFlags & kServerValidFlag_NetErrorsX25 &&
		!(state->boxOSState.boxFlags & kBoxIDTrashed) && !state->crashRecord)
	{
		state->account->boxAccount.netErrorTotals.serverConnects += state->boxNetErrorsX25.serverConnects;
		state->account->boxAccount.netErrorTotals.peerConnects += state->boxNetErrorsX25.peerConnects;
		state->account->boxAccount.netErrorTotals.framingError += state->boxNetErrorsX25.framingError;
		state->account->boxAccount.netErrorTotals.overrunError += state->boxNetErrorsX25.overrunError;
		state->account->boxAccount.netErrorTotals.packetError += state->boxNetErrorsX25.packetError;
		state->account->boxAccount.netErrorTotals.packetRetransError += state->boxNetErrorsX25.packetRetransError;
		state->account->boxAccount.netErrorTotals.callWaitingInterrupt += state->boxNetErrorsX25.callWaitingInterrupt;
		state->account->boxAccount.netErrorTotals.noDialtoneError += state->boxNetErrorsX25.noDialtoneError;
		state->account->boxAccount.netErrorTotals.serverBusyError += state->boxNetErrorsX25.serverBusyError;
		state->account->boxAccount.netErrorTotals.peerBusyError += state->boxNetErrorsX25.peerBusyError;
		state->account->boxAccount.netErrorTotals.serverDisconnectError += state->boxNetErrorsX25.serverDisconnectError;
		state->account->boxAccount.netErrorTotals.peerDisconnectError += state->boxNetErrorsX25.peerDisconnectError;
		state->account->boxAccount.netErrorTotals.serverAbortError += state->boxNetErrorsX25.serverAbortError;
		state->account->boxAccount.netErrorTotals.peerAbortError += state->boxNetErrorsX25.peerAbortError;
		state->account->boxAccount.netErrorTotals.serverNoAnswerError += state->boxNetErrorsX25.serverNoAnswerError;
		state->account->boxAccount.netErrorTotals.peerNoAnswerError += state->boxNetErrorsX25.peerNoAnswerError;
		state->account->boxAccount.netErrorTotals.serverHandshakeError += state->boxNetErrorsX25.serverHandshakeError;
		state->account->boxAccount.netErrorTotals.peerHandshakeError += state->boxNetErrorsX25.peerHandshakeError;
		state->account->boxAccount.netErrorTotals.serverX25NoServiceError += state->boxNetErrorsX25.serverX25NoServiceError;
		state->account->boxAccount.netErrorTotals.callWaitingError += state->boxNetErrorsX25.callWaitingError;
		state->account->boxAccount.netErrorTotals.remoteCallWaitingError += state->boxNetErrorsX25.remoteCallWaitingError;
		state->account->boxAccount.netErrorTotals.scriptLoginError += state->boxNetErrorsX25.scriptLoginError;
	}

	//
	// The moment everyone has been waiting for.
	//
	if(state->account->playerModified || state->account->boxModified || state->account->userModified)
	{
		PLogmsg(LOGP_PROGRESS, "updating your account\n");
		WrapperDB_UpdateAccount(state->account);
	}

	state->updateDatabaseDone = true;

	return (kServerFuncOK);
}


//
// Formerly the middle part of Server_UpdateDataBaseAccount().
//
// This does a bunch of random things that were piled into
// UpdateDataBaseAccount because it happens last.  Some of these change
// data in the account (mainly debug fields), and may try to send things
// down to the box.
//
PRIVATE int
Server_DoMiscellaneousStuff(ServerState *state)
{
	FILE	*motdFP;
	char 	linebuf[1000];

	// Dial all POPs
	if(state->account->playerAccount.debug[1] > 0)
	{
	char 		msg[200];
	Hometown	homeTown;
	Err			err;
	
		err = Server_LookupPops(state->account->playerAccount.debug[2], &state->account->boxAccount.gamePhone, &state->account->boxAccount.popPhone, &state->account->boxAccount.altPopPhone, homeTown, kPopSelect16,  state->account->userAccount.dateLastConnect);

		if (err)
		{
			state->account->playerAccount.debug[1] = 0;	// all done.
		}
		else
		{
			state->account->playerAccount.debug[2]++;
			// Like, you're dialing all POPs in the country from your hotel room.  Sure.
			// Oh well, prepend the dial9 just in case it is so!  DJ  5/9/95
			//
			Server_AddPBX_Dial9(state, &state->account->boxAccount.popPhone, &state->account->boxAccount.altPopPhone);
	
			sprintf(msg, gettext("(SERVER) You will redial the server through %s at %s."),
				homeTown, state->account->boxAccount.popPhone.phoneNumber); /* DIALOG */
			Server_SendDialog(state, msg, false);
	
			state->account->playerModified 	|= 	kPA_debug;
			state->account->boxModified 	|= 	kBA_popPhone;
			
			Server_SendSetLocalAccessPhoneNumber(state, &state->account->boxAccount.popPhone,
				&state->account->boxAccount.popPhone, true);	// trigger a redial to us.
		}
	}		

	//
	// Redial loop.
	//
	if(state->account->playerAccount.debug[0] > 0)
	{
	char msg[200];
	
		// auto redial loop
		//
		sprintf(msg, gettext("You will redial the server %ld times."), /* DIALOG */
			state->account->playerAccount.debug[0]);
		Server_SendDialog(state, msg, false);

		state->account->playerAccount.debug[0]--;
		state->account->playerModified |= kPA_debug;
		Server_SendSetLocalAccessPhoneNumber(state, &state->account->boxAccount.popPhone,
			&state->account->boxAccount.popPhone, true);	// trigger a redial to us.
	}
	
	Server_PrintDebugStatsLine(state);

	//
	// If there is an "MOTD.sunsega" file, read it and send as first dialog
	// to the box.  Don't send the MOTD on 1-800 connects.
	//
	if(!state->connect800 && (motdFP = fopen(kMessageOfTheDayFile, "rb")))
	{
		fgets(linebuf, 1000, motdFP);
		linebuf[999] = 0;
		
		if (!feof(motdFP) && !ferror(motdFP))
		{
			PLogmsg(LOGP_DBUG, "Sending MOTD dialog\n");
			Server_SendLargeDialog(state, linebuf, false);
		}
		
		fclose(motdFP);
	}
	
	//
	// If C.S. updated the restrictions, mark 'em as unchanged.
	// Clear kCSUpdatedFlag_UpdatedRestrictions if set. Do this here so that restrictions
	// will be sent again until server connection succeeds.
	//
	if(!state->connect800 &&
	state->account->boxAccount.csUpdatedFlags & kCSUpdatedFlag_UpdatedRestrictions)
	{
		state->account->boxAccount.csUpdatedFlags &= ~kCSUpdatedFlag_UpdatedRestrictions;
		state->account->boxModified |= kBA_csUpdatedFlags;
	}
	return(kServerFuncOK);
}


//
// Print a line of statistics for later perusal.
//
// This is meant to be machine-readable, not easily parsable by wetware.
// 
// This has rewritten by hufft to support Japan as well as the US.
// This means using the Common_Phone functions for parsing and formatting.
//
// Fields are, from left to right:
//	when connected		(UNIX time format, 8 hex digits)
//	boxSerialNumber		(box,region,player)
//	boxPhoneNumber		(10 digits)
//	popPhoneNumber		(10 digits)
//	altPopPhoneNumber	(10 digits)
//	ANI flag			(1=ANI, 0=X.25)
//	Kind of connect		(M=mail only, A=auto-match, S=specific challenge)
//	GameID				(8 hex digits)
//
PRIVATE	void	Server_PrintDebugStatsLine(ServerState *state)
{
	phoneNumber BoxPhone, PopPhone, AltPhone;
	int aniFlag = 0;
	char ck, *cp, *num_p, *pop, *alt;

	if ((cp = getenv("XBAND_ANI")) != NULL)
			aniFlag++;

	// If we had the "no ANI, no account info, redialing" thing, then
	// these phone numbers will all be blank.  Give us something to
	// parse.
	//
	if (!strlen(state->account->boxAccount.gamePhone.phoneNumber))
	{
		Common_PhoneFormatDummyNumber(state->account->boxAccount.gamePhone.phoneNumber);
	}
	if (!strlen(state->account->boxAccount.popPhone.phoneNumber))
	{
		Common_PhoneFormatDummyNumber(state->account->boxAccount.popPhone.phoneNumber);
	}
	if (!strlen(state->account->boxAccount.altPopPhone.phoneNumber))
	{
		Common_PhoneFormatDummyNumber(state->account->boxAccount.altPopPhone.phoneNumber);
	}

	num_p = BoxPhone.phoneNumber;
	pop = PopPhone.phoneNumber;
	alt = AltPhone.phoneNumber;
	Common_PhoneFormatDisplay(state->account->boxAccount.gamePhone.phoneNumber, num_p);
	Common_PhoneFormatDisplay(state->account->boxAccount.popPhone.phoneNumber, pop);
	Common_PhoneFormatDisplay(state->account->boxAccount.altPopPhone.phoneNumber, alt);

	if (state->challengeData.userID.box.box == kDownloadOnlyMailSerialNumber)
	{
		ck = 'M';
	}
	else if (state->challengeData.userID.box.box == kFindNetworkOpponentSerialNumber)
	{
		ck = 'A';
	}
	else
	{
		ck = 'S';
	}

	FPLogmsg(LOG_STATISTICS, LOGP_STATISTICS,
		"%.8lx %ld,%ld,%ld %s %s %s %d %c %.8lx\n",
		gStartTime,
		state->loginData.userID.box.box,
		state->loginData.userID.box.region,
		state->loginData.userID.userID,
		BoxPhone.phoneNumber,
		pop,
		alt,
		aniFlag,
		ck,
		state->gameIDData.gameID);
}

//
// This function is called whenever the connection terminates prematurely
// because of a timeout, SIGHUP etc. It updates select fields in the database.
// We should do a more complete job of checkpointing and storing the 
// state of the connection in the future. 
//
// NOTES:
//	- if we get to ClearMiscQueues, this should save off things like
//	  game results and mail.  However we'll be hosed if we get a SIGHUP
//	  after we send it but before they receive it.
//	- not all fields should be written out on a SIGHUP; sometimes we
//	  WANT to do things every time until we're sure they've got it.
//
void
Server_UpdateDataBaseAccountPartial(ServerState *state)
{
    long	playerModified;
    long	userModified;
    long	boxModified;

    PLogmsg(LOGP_PROGRESS, "Server_UpdateDataBaseAccountPartial\n");

    if ((state == NULL) || (state->account == NULL) ||
		!(state->validFlags & kServerValidFlag_Account)) {	
		PLogmsg(LOGP_NOTICE, "No account to update\n");
		return;
    }

    // check if the connection got dropped after Server_UpdateDataBaseAccount
    // updated the database
    if (state->updateDatabaseDone == true) {
		PLogmsg(LOGP_PROGRESS, 
			"Server_UpdateDataBaseAccountPartial called after Server_UpdateDataBaseAccount - ignoring\n");
		return;
	}

    playerModified = state->account->playerModified;
    userModified   = state->account->userModified;
    boxModified	   = state->account->boxModified;
    state->account->playerModified = 0;
    state->account->userModified   = 0;
    state->account->boxModified	   = 0;

    if ((state->firstX25Connect == true) && (state->boxPhoneSyncDone == true)) {
		state->account->boxModified |= (boxModified & kBA_gamePhone);

		state->account->boxAccount.totalServerConnects++;
		state->account->boxModified |= kBA_totalServerConnects;
    }


    if(state->account->playerModified || state->account->boxModified || 
		state->account->userModified) {
	PLogmsg(LOGP_PROGRESS, 
	    "Server_UpdateDataBaseAccountPartial: updating your account\n");
       	WrapperDB_UpdateAccount(state->account);
    }

	//
	// The debit card database is updated here because we want to 
	// bill the customer for services provided even if a SIGHUP occurs.
	// Example:  If we delivered mail, and a SIGHUP happens just after we clear 
	// the mail queue, we'll end up here, and appropriately debit the database.
	//
	Server_DoDebitCardDBUpdate(state);

}

