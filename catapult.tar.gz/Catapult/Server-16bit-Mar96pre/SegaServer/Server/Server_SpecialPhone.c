/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_SpecialPhone.c,v 1.12 1996/01/30 22:26:07 fadden Exp $
 *
 * $Log: Server_SpecialPhone.c,v $
 * Revision 1.12  1996/01/30  22:26:07  fadden
 * Hacked GetSpecialPhone so that it doesn't do the lookup again if the
 * number we want is the same one we looked up last time.
 *
 * Revision 1.11  1995/10/10  10:34:13  ted
 * Added kSpecialTournamentTest.
 *
 * Revision 1.10  1995/10/03  12:14:35  ted
 * Added kSpecialLookLongFirst flag ($).
 *
 * Revision 1.9  1995/09/27  18:38:04  hufft
 * added Common_Phone support for Japan Server
 *
 * Revision 1.8  1995/09/13  14:24:44  ted
 * Fixed warnings.
 *
 * Revision 1.7  1995/08/21  16:03:22  ansell
 * Removed forcing of longdistance flag for intel box as it is now done in
 * Server_ValidateLogin.
 *
 * Revision 1.6  1995/06/01  22:31:25  fadden
 * Force kSpecialLongDistance on for Intel boxes.
 *
 * Revision 1.5  1995/05/26  23:47:02  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_SpecialPhone.c

	Contains:	Routines to deal with the SpecialPhone file

	Written by:	Andy McFadden


	Change History (most recent first):
	
		<10>	11/27/94	ATM		Added 'W' flag for short waits.
		 <9>	11/14/94	ATM		Pulled an ASSERT out of GetSpecialPhone... not needed.
		 <8>	 11/9/94	DJ		Checking if there is indeed an account in GetSpecialPhone.
		 <7>	 11/9/94	DJ		Renamed some DB routines to DataBaseUtil_ and also to WrapperDB_
									(for Oracle).
		 <6>	 11/9/94	ATM		Added 'F' (fucker) flag for testing, and handling of '#'.
		 <5>	 11/5/94	HEC		Added Medium flag.
		 <4>	 11/3/94	ATM		Add VIP flag.
		 <3>	10/31/94	ATM		Deal with file not found.
		 <2>	10/28/94	ATM		Added kSpecialNewGames.
		 <1>	10/28/94	ATM		first checked in

	To Do:
*/


#include <ctype.h>
#include <string.h>
#include <malloc.h>
#include <errno.h>
#include "Common.h"
#include "Common_PlatformID.h"
#include "Common_Missing.h"

//
// Translate the characters in the SpecialPhone file to flag values.
//
static long CharToFlag(char c)
{
	static struct {
		char	c;
		long	flag;
	} xlate[] = {
		{ 'C',	kSpecialCatapult },
		{ 'F',	kSpecialFucker },
		{ 'G',	kSpecialNewGames },
		{ 'L',	kSpecialLongDistance },
		{ 'M',	kSpecialMediumDistance },
		{ 'V',	kSpecialVIPTester },
		{ 'W',	kSpecialShortWait },
		{ 'N',	kSpecialCallingCard },
		{ '$',	kSpecialLookLongFirst },
		{ 'T',	kSpecialTournamentTest },
	};
	int i;

	for (i = 0; i < NELEM(xlate); i++) {
		if (toupper(c) == toupper(xlate[i].c))
			return (xlate[i].flag);
	}
	Logmsg("WARNING: flag '%c' in SpecialPhone file not recognized\n", c);
	return (0);
}

#define MAX_LINE_LENGTH		256
#define WHITESPACE			" \t\n"

//
// Read in the "blessed" phone numbers, and the tokens that describe
// what special abilities have been granted.
//
// Sets a pointer in "state".
//
Err Server_LoadSpecialPhoneFile(ServerState *state)
{
	FILE 		*fp;
	ListNode	*lnode;
	SpecialPhone *spcl;
	char 		linebuf[MAX_LINE_LENGTH];
	char 		boxPhone[kPhoneNumberSize];
	char 		*cp;


	PLogmsg(LOGP_PROGRESS, "Server_LoadSpecialPhoneFile\n");

	if ((fp = fopen(kSpecialPhoneFile, "r")) == NULL) {
		PLogmsg(LOGP_FLAW,
			"Unable to open special phone file '%s' (errno=%d)\n",
			kSpecialPhoneFile, errno);
		return (kFucked);
	}

	state->specialPhone = NewList();

	while (1) {
		fgets(linebuf, MAX_LINE_LENGTH, fp);
		if (feof(fp) || ferror(fp))
			break;

		if (linebuf[strlen(linebuf)-1] == '\n')
			linebuf[strlen(linebuf)-1] = '\0';
		if (linebuf[0] == '\0' || linebuf[0] == '#')
			continue;

		if ((cp = strtok(linebuf, WHITESPACE)) == NULL)
			continue;
		strncpy(boxPhone, cp, kPhoneNumberSize-1);
		boxPhone[kPhoneNumberSize-1] = '\0';

		spcl = (SpecialPhone *)malloc(sizeof(SpecialPhone));
		Assertmsg(spcl != NULL,"Could not malloc spcl");

		strcpy(spcl->phoneNumber, boxPhone);
		spcl->flags = 0;
		strcpy(spcl->callingcard, "?");
		if ((cp = strtok(NULL, WHITESPACE)) != NULL) {
			while (*cp) {
				if (*cp == '#')
					break;
				if (strchr(WHITESPACE, *cp) == NULL)	// if *cp not whitespace
					spcl->flags |= CharToFlag(*cp);
				cp++;
			}
			if ((spcl->flags & kSpecialCallingCard) && ((cp = strtok(NULL, WHITESPACE)) != NULL))
			{
				if (strpbrk(cp,WHITESPACE) == NULL)
					strcpy(spcl->callingcard, cp);
			}
		}
		//PLogmsg(LOGP_DBUG, "Special: '%s' 0x%.4lx Calling Card: %s.\n", spcl->phoneNumber, spcl->flags, spcl->callingcard);
		lnode = NewListNode((Ptr) spcl);
		AddListNodeToList(state->specialPhone, lnode);
	}
	fclose(fp);

	PLogmsg(LOGP_PROGRESS, "Server_LoadSpecialPhoneFile done\n");
	return (kNoError);
}


//
// See if our phone is in the "special" file.  If so, return the flags
// set for it.
//
// Returns 0 (no flags set) if the phone number isn't listed.
//
long
Server_GetSpecialPhone(ServerState *state)
{
	ListNode *lnode;
	SpecialPhone *spcl;
	static phoneNumber last_phone;
	static int have_result = false;
	static long result = 0;

    PLogmsg(LOGP_PROGRESS, "Server_GetSpecialPhone\n");

	// If the previous call was for the same phone number, don't do
	// the lookup again.  It turns out the lookup is very expensive,
	// because Common_PhoneCompareNumbers parses the phone numbers
	// into a canonical format with sscanf().
	//
	// I don't think there's a case where last_phone won't be the same
	// as the current phone, but it's best to be careful.
	//
	if (have_result && strcmp(last_phone.phoneNumber,
		state->account->boxAccount.gamePhone.phoneNumber) == 0)
	{
		PLogmsg(LOGP_DETAIL,
			"Returning cached SpecialPhone value (0x%.8lx)\n", result);
		return (result);
	}

	// This only happens on 1-800 connections, where the special phone
	// stuff shouldn't matter anyway.  If needed we could pull it out of
	// the env var.
	//
    if (!(state->validFlags & kServerValidFlag_Account)) {
		Logmsg("Couldn't check SpecialPhone, no account\n");
        return (0);
	}

	// This is kind of annoying.  I wanted it to load when SunSega
	// started up, but "boxState" gets cleared a couple of times, so
	// the pointer was getting zapped.
	//
	if (state->specialPhone == NULL) {
		if (Server_LoadSpecialPhoneFile(state) != kNoError)
			return (0);
	}

	have_result = true;
	strcpy(last_phone.phoneNumber,
		state->account->boxAccount.gamePhone.phoneNumber);

	for (lnode = GetFirstListNode(state->specialPhone); lnode != NULL;
		lnode = GetNextListNode(lnode))
	{
		spcl = (SpecialPhone *)GetListNodeData(lnode);
		if (Common_PhoneCompareNumbers(spcl->phoneNumber,
			state->account->boxAccount.gamePhone.phoneNumber) == 0)
		{
			result = spcl->flags;
			return (result);
		}
	}

	return (0);
}


//
// See if a phone is in the "special" file.  If so, return the flags
// set for it.
//
// Returns 0 (no flags set) if the phone number isn't listed.
//
// If a calling card is present, return the full string to dial given the full input
// phone number (of the form 4083661735). Caller supplies both input and output strings.
//
long Server_GetSpecialCallingCard(ServerState *state, char *in, char *out)
{
	char *cp;
	ListNode *lnode;
	SpecialPhone *spcl;

    PLogmsg(LOGP_PROGRESS, "Server_GetSpecialCallingCard\n");

	// This only happens on 1-800 connections, where the special phone
	// stuff shouldn't matter anyway.  If needed we could pull it out of
	// the env var.
	//
    if (!(state->validFlags & kServerValidFlag_Account)) {
		Logmsg("Couldn't check SpecialPhone, no account\n");
        return (0);
	}

	// This is kind of annoying.  I wanted it to load when SunSega
	// started up, but "boxState" gets cleared a couple of times, so
	// the pointer was getting zapped.
	//
	if (state->specialPhone == NULL) {
		if (Server_LoadSpecialPhoneFile(state) != kNoError)
			return (0);
	}

	for (lnode = GetFirstListNode(state->specialPhone); lnode != NULL;
		lnode = GetNextListNode(lnode))
	{
		spcl = (SpecialPhone *)GetListNodeData(lnode);
		if (Common_PhoneCompareNumbers(spcl->phoneNumber,
			state->account->boxAccount.gamePhone.phoneNumber) == 0)
		{
			if (!(spcl->flags & kSpecialCallingCard))
			{
				return (spcl->flags);
			}

			// insert phone into the calling card string
			cp = strtok(spcl->callingcard,"?");
			if (cp)
			{
				Common_PhoneFormatCallingCard(cp, in, out);
				return (spcl->flags);
			}
			else
			{
				out[0] = '\0';
				PLogmsg(LOGP_FLAW, "GetSpecialCallingCard: card specified, but invalid card string for (%s)\n",spcl->phoneNumber);
				return (spcl->flags & ~kSpecialCallingCard);
			}
		}
	}
	return (0);
}

