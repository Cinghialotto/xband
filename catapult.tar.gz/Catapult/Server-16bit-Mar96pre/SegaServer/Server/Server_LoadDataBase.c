/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_LoadDataBase.c,v 1.2 1995/05/26 23:46:25 jhsia Exp $
 *
 * $Log: Server_LoadDataBase.c,v $
 * Revision 1.2  1995/05/26  23:46:25  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_LoadDataBase.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans


	Change History (most recent first):

		<26>	 9/18/94	ATM		It's gone.  Really.
		<25>	  9/2/94	DJ		changed stimulator game name to mortal kombat for KON doing
									screenshots
		<24>	 8/19/94	ATM		THIS FILE IS OBSOLETE.  Removed last interesting function into
									DataBase_GamePatch.c.
		<23>	 8/17/94	DJ		doesn't blow up if no Patches.smsg file
		<22>	 8/16/94	ATM		Added KnownGames stuff.
		<20>	 8/16/94	ATM		New game patch stuff.
		<19>	 8/12/94	ATM		Converted to Logmsg.
		<18>	 8/10/94	DJ		mk ver1 patch
		<17>	 8/10/94	DJ		mk ver1 patch
		<16>	  8/4/94	ATM		Removed Server_SetupAccounts (which just created some broadcast
									mail).
		<15>	 7/27/94	DJ		loading and creating gamepatch for NBAJam rev 2
		<14>	 7/26/94	DJ		creating and downloading NBAJam2.smsg
		<13>	 7/26/94	DJ		supporting NBAJam rev2
		<12>	 7/25/94	DJ		new mail
		<11>	 7/19/94	DJ		gameName is now just a char*
		<10>	 7/19/94	DJ		new useridentification string
		 <9>	 7/18/94	DJ		gamenames are 1 string now
		 <8>	 7/12/94	DJ		added 666 game
		 <7>	  7/8/94	DJ		wacky mails
		 <6>	  7/3/94	DJ		no iconref in mail
		 <5>	 6/30/94	DJ		broadcast mail from catapult
		 <4>	 6/29/94	BET		(Really DJ) Clean up after KON.
		 <3>	 6/14/94	HEC		Things to do, people to see.
		 <2>	 6/12/94	DJ		history is the shockwave of the eschaton
		 <1>	 6/11/94	DJ		first checked in

	To Do: This stuff belongs in ServerDataBase/
*/

// All gone!


