/*
 * Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
 *
 * $Id: Server_Personification.c,v 1.20 1996/01/25 17:51:53 hufft Exp $
 *
 * $Log: Server_Personification.c,v $
 * Revision 1.20  1996/01/25  17:51:53  hufft
 * added UDP based stream processing itf.
 *
 * Revision 1.19  1995/11/08  18:42:43  jhsia
 * Tweaked a logmsg (fadden)
 *
 * Revision 1.18  1995/09/13  14:24:37  ted
 * Fixed warnings.
 *
 * Revision 1.17  1995/08/17  14:48:27  fadden
 * Put the platformID check on the endian-flip kluge here instead of in
 * the macro.
 *
 * Revision 1.16  1995/07/28  16:59:26  rich
 * Re-fixed my re-screwup with smart quotes, gettext(), default info + taunt.
 *
 * Revision 1.15  1995/07/27  19:54:08  rich
 * Fixed my screwup with smart quotes, gettext(), and default info and taunt.
 *
 * Revision 1.14  1995/07/27  16:43:06  fadden
 * Put the smart quotes back into the default defaults.  Changed the
 * gettext("string constant") calls back into what they were before.
 *
 * Revision 1.13  1995/07/26  13:55:33  ansell
 * Set lastPersonInfoChange field when user updates personal info.
 *
 * Revision 1.12  1995/07/10  21:04:09  rich
 * Wrapped server dialog strings with gettext() for message catalog lookup.
 *
 * Revision 1.11  1995/07/07  20:48:55  fadden
 * Added Server_SetTransportHold calls around one routine.
 *
 * Revision 1.10  1995/06/19  20:33:05  fadden
 * Use Server_GetDefaultTauntAndInfo instead of #defines.  Added error
 * checking and reporting to Server_ReadCustomIcon.
 *
 * Revision 1.9  1995/06/01  15:06:06  fadden
 * Merge in from newbr.
 * -> On restore, don't overwrite account's icon/hue with box's.
 *
 * Revision 1.8  1995/05/26  23:46:35  jhsia
 * switch to rcs keywords
 *
 */

/*
	File:		Server_Personification.c

	Contains:	Pretty pink flowers.  If you don't like pink then they are blue.  

	Stolen by:	Brian Topping


	Change History (most recent first):

		<29>	11/21/94	DJ		Added Server_ReadCustomIcon.
		<28>	11/17/94	KD		Updated dialog box wording (doug/kon).
		<27>	 11/7/94	DJ		Avoids resetting taunt and personinfo to defaults after crashed
									box restore.
		<26>	10/24/94	ATM		Need to alloc userIDData if either ROMIconID or ROMClutID is
									used.
		<25>	10/20/94	DJ		Added "dialog" in caps comment on same line as server dialogs
									(useful for greping).
		<24>	10/13/94	DJ		Made Server_SendPersonification callable from Server_RestoreBox.
		<23>	 9/27/94	DJ		filtering taunt & info for obscenity
		<22>	 9/19/94	ATM		PLogmsg stuff.
		<21>	 9/16/94	ATM		boxFlags->boxModified, playerFlags->playerModified,
									acceptChallenges->playerFlags.
		<20>	 8/30/94	ATM		Converted accountChangedMask references to Account flags.
		<19>	 8/28/94	ATM		Put quotes around some logmsg strings to see trailing spaces
									(esp password).
		<18>	 8/25/94	ATM		Had a weird problem.  Added an ASSERT.
		<17>	 8/21/94	DJ		bug
		<16>	 8/21/94	DJ		added kPersonificationRAMIcon
		<15>	 8/20/94	DJ		dont' receive RAM icon, don't send handle
		<14>	 8/20/94	DJ		added more logmsgs
		<13>	 8/20/94	ATM		Added some ASSERTs around the malloc/free stuff.
		<12>	 8/18/94	DJ		testing custom icons
		<11>	 8/17/94	ATM		Changed UpdateUserHandle call.
		<10>	 8/16/94	DJ		fixed double uniquification
		 <9>	 8/16/94	DJ		glogs
		 <8>	 8/15/94	DJ		new sendpersonification
		 <7>	 8/12/94	DJ		update to handle new ramicon
		 <6>	 8/12/94	DJ		wont change your name to itself
		 <5>	 8/12/94	DJ		fixing barf
		 <4>	 8/12/94	DJ		fixing barf
		 <3>	 8/11/94	DJ		new personifuckation
		 <2>	 8/10/94	DJ		process peer, receive peer.  fix wire routines.
		 <1>	  8/4/94	BET		first checked in

	To Do:
*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "Server.h"
#include "ServerDataBase.h"
#include "Server_Personification.h"
#include "Common.h"
#include "Common_PlatformID.h"
#include "Common_Missing.h"
#include "FilterHandle.h"


// Defaults for Genesis and SNES.
//
#define kDefaultTaunt 		"Pick on me! I haven�t got a taunt!"
#define kDefaultPersonInfo	"I�m a new player!"


// For testing:
//
// FILTERFIELDS changes the fields of the personification.
// TEST_CUSTOM_ICON will download the sheep icon (works if FILTERFIELDS  is on).
//
// #define FILTERFIELDS
// #define TEST_CUSTOM_ICON
//

int Server_ProcessPersonifications(ServerState *state)
{
PlayerAccount			*player;
PersonificationSetupRec	*pers;
userIdentification		*uid;
unsigned char			flags;
char					*defaultTaunt = NULL, *defaultInfo = NULL;

	PLogmsg(LOGP_PROGRESS, "Server_ProcessPersonifications\n");

	ASSERT(state->validFlags & kServerValidFlag_Personifications);
	ASSERT(state->validFlags & kServerValidFlag_Account);

	if (state->account == NULL) {
		PLogmsg(LOGP_FLAW, "Why is this happening?\n");
		Common_Abort();
	}

	uid = &state->loginData.userID;
	player = &state->account->playerAccount;
	pers = &state->userPersonification;

	// Note that GetDefaultTauntAndInfo will do whatever translation is
	// necessary on the default taunt info, so it is NOT necessary to do
	// it again here.
	//
	Server_GetDefaultTauntAndInfo(state, &defaultTaunt, &defaultInfo);
	if (defaultTaunt == NULL || defaultInfo == NULL) {
		PLogmsg(LOGP_NOTICE, "WARNING: no default taunt/info for '%.4s'\n",
			(char *)&state->platformID);
		defaultTaunt = kDefaultTaunt;
		defaultInfo = kDefaultPersonInfo;
	}


	if(state->personificationFlags)
	{

		if(state->personificationFlags & kPersonificationPassword )
		{
			strncpy(player->password, pers->pwData, kMaxPWLength);
			state->account->playerModified |= kPA_password;

			Logmsg("	Personification password changed.\n");
		}

		if( state->personificationFlags & kPersonificationTauntText )
		{
			if(state->boxRestored && !state->playerCreated &&
				!strcmp(pers->TauntTextData, defaultTaunt))
			{
				Logmsg("Server_ProcessPersonifications: avoiding overwriting taunt with the cheesy old default.\n");
			} else
			{
				ASSERT(player->openTaunt);
				free(player->openTaunt);
				player->openTaunt = (char *)malloc(strlen(pers->TauntTextData)+1);
				ASSERT(player->openTaunt);
				strcpy(player->openTaunt, pers->TauntTextData);
	
				if(FilterTextObscene(player->openTaunt))
				{
					// I18N Appears:  When XBAND detects vulgarity in your taunt.
					// Solution: Don't use vulgar language on XBAND.
					//
					Server_SendDialog(state, gettext("Your Taunt is not appropriate for XBAND and has been changed."), false);	/* DIALOG */
					Logmsg("	Taunt was filtered.  Was: '%s'.\n", pers->TauntTextData);
				}
	
				state->account->playerModified |= kPA_openTaunt;
	
				Logmsg("	Personification taunt = '%s'\n",  player->openTaunt);
			}
		}

		if( state->personificationFlags & kPersonificationAboutText )
		{
			if(state->boxRestored && !state->playerCreated &&
				!strcmp(pers->InfoTextData, defaultInfo))
			{
				Logmsg("Server_ProcessPersonifications: avoiding overwriting personinfo with the cheesy old default.\n");
			} else
			{
				ASSERT(player->personInfo);
				free(player->personInfo);
				player->personInfo = (char *)malloc(strlen(pers->InfoTextData)+1);
				ASSERT(player->personInfo);
				strcpy(player->personInfo, pers->InfoTextData);
	
				if(FilterTextObscene(player->personInfo))
				{
					// I18N Appears:  When XBAND detects vulgarity in your player info.
					// Solution:  Don't use vulgar language on XBAND.
					//
					Server_SendDialog(state, gettext("Your Player Info is not appropriate for XBAND and has been changed."), false);	/* DIALOG */
					Logmsg("	Personification info  was filtered.  Was: '%s'.\n", pers->InfoTextData);
				}
				else
					Logmsg("	Personification info = '%s'\n",  player->personInfo);
	
				player->lastPersonInfoChange = state->timeOfThisConnect;
				state->account->playerModified |= 
					(kPA_personInfo | kPA_lastPersonInfoChange);
			}
		}

		if(state->personificationFlags & kPersonificationROMIconID )
		{
			if (state->boxRestored) {
				Logmsg("	Personification ROMIconID = (not changed for restore)\n");
			} else {
				player->iconID = (short)pers->userIDData->ROMIconID;
				state->account->playerModified |= kPA_iconID;
				Logmsg("	Personification ROMIconID = %ld\n",
					(long)player->iconID);
			}
		}

		if(state->personificationFlags & kPersonificationROMClutID )
		{
			if (state->boxRestored) {
				Logmsg("	Personification colorTableID = (not changed for restore)\n");
			} else {
				player->colorTableID = (short)pers->userIDData->colorTableID;
				state->account->playerModified |= kPA_colorTableID;
				Logmsg("	Personification colorTableID = %ld\n",
					(long)player->colorTableID);
			}
		}

#ifdef FILTERFIELDS

		// Mess around with Ted's personification and icon.
		//
		if(!strncmp( state->loginData.userID.userName,  "ted", strlen("ted")))
		{
		register long a;
		unsigned char *bugger = "censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult \
		censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult \
		censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult \
		censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult censored by catapult ";
		
			for(a = 0; a < strlen(player->personInfo); a++)
				player->personInfo[a] = bugger[a];
			state->personificationFlagsEditedByServer |= kPersonificationAboutText;
			state->account->playerModified |= kPA_personInfo;

			for(a = 0; a < strlen(player->openTaunt); a++)
				player->openTaunt[a] = bugger[a];
			state->personificationFlagsEditedByServer |= kPersonificationTauntText;
			state->account->playerModified |= kPA_openTaunt;


#ifdef TEST_CUSTOM_ICON	// download a custom icon for you!

			Server_ReadCustomIcon(state, "Sheep.icon");

#endif

		}
#endif

	}


	flags = state->personificationFlags | state->personificationFlagsEditedByServer;
	if(flags)
		Server_SendPersonification(state, &state->account->playerAccount, flags);


	return(kServerFuncOK);
}

void Server_ClearCustomIcon(ServerState *state)
{
	ASSERT(state->account);
	ASSERT(state->account->playerAccountValid);
	if(!state->account->playerAccountValid)
		return;

	if(state->account->playerAccount.customIcon)
		free ( state->account->playerAccount.customIcon );
	state->account->playerAccount.customIcon = NULL;
	state->account->playerAccount.customIconSize = 0;
	state->account->playerModified |= kPA_customIcon;

	state->personificationFlagsEditedByServer |= kPersonificationRAMIcon;
}


//
// Read a custom icon in.
//
// Returns kNoError on success, kFucked on error.
//
Err Server_ReadCustomIcon(ServerState *state, char *iconFile)
{
RAMIconBitMapPtr	ram;
PreformedMessage	*pre;
PlayerAccount		*player;


	ASSERT(state->account);
	ASSERT(state->account->playerAccountValid);
	if(!state->account->playerAccountValid)
		return kFucked;

	player = &state->account->playerAccount;

	pre = PreformedMessage_ReadFromFile(iconFile);
	if (pre) {
		Logmsg("Read '%s' custom icon.\n", iconFile);

		ram = (RAMIconBitMapPtr)pre->message;
		ram->box = state->account->boxAccount.box;
		ram->userID = player->player;

		if (state->platformID == kPlatformSNES) {
			// sn07 only, I hope.
			//
			ram->box.box = FLIP_LONG(ram->box.box);
			ram->box.region = FLIP_LONG(ram->box.region);
		}

		if(player->customIcon)
			free ( player->customIcon );
		player->customIcon = malloc(pre->length);
		ASSERT_MESG(player->customIcon, "Out of mems reading in custom icon.");
		if(!player->customIcon)
			goto OutOfMemory;

		player->customIconSize = pre->length;
		bcopy(pre->message, player->customIcon, player->customIconSize);

		state->personificationFlagsEditedByServer |= kPersonificationRAMIcon;
		state->account->playerModified |= kPA_customIcon;

OutOfMemory:
		PreformedMessage_Dispose(pre);

		return (kNoError);

	} else {
		Logmsg("Custom icon '%s' read failed\n", iconFile);
		return (kFucked);
	}

	/*NOTREACHED*/
	return (kNoError);
}

int Server_ReceivePersonification(ServerState *state)
{
unsigned char 			opCode;
PersonificationSetupRec	*pers;
int						retVal;

	PLogmsg(LOGP_PROGRESS, "Server_ReceivePersonification\n");

	if(Server_TReadDataSync( state->session, 1, (Ptr)&opCode ) != noErr)
		return(kServerFuncAbort);

	if(opCode != msSendInvalidPers){
		// fucked
		return(kServerFuncAbort);
	}

	state->personificationFlags = 0;

	if(Server_TReadDataSync( state->session, sizeof(unsigned char), (Ptr)&state->personificationFlags ) != noErr)
		return(kServerFuncAbort);

	retVal = Server_GetPersonificationFromWire(state, &state->userPersonification, state->personificationFlags);

	if(retVal != kServerFuncOK)
		return(retVal);

	pers = &state->userPersonification;
	Logmsg("Personification received:\n");
	if(state->personificationFlags & kPersonificationPassword ) {
		Logmsg("    password: '%.8s'\n", pers->pwData);
	}
	if( state->personificationFlags & kPersonificationTauntText )
		Logmsg("    taunt: '%s'\n", pers->TauntTextData);
	if( state->personificationFlags & kPersonificationAboutText )
		Logmsg("    info: '%s'\n", pers->InfoTextData);
	if(state->personificationFlags & kPersonificationROMIconID )
		Logmsg("    ROMIconID: %ld\n", (long)pers->userIDData->ROMIconID);
	if(state->personificationFlags  & kPersonificationROMClutID )
		Logmsg("	clutID: %ld\n", (long)pers->userIDData->colorTableID);

	state->validFlags |= kServerValidFlag_Personifications;

	PLogmsg(LOGP_PROGRESS, "Server_ReceivePersonification done\n");

	return(kServerFuncOK);
}

void Server_DeletePersonification( PersonificationSetupRec *OPers )
{
	ASSERT(OPers);

	if ( OPers->userIDData )
		free( (Ptr)OPers->userIDData );
	if ( OPers->TauntTextData )
		free( (Ptr)OPers->TauntTextData );
	if ( OPers->InfoTextData )
		free( (Ptr)OPers->InfoTextData );
	if ( OPers->RAICData )
		free( (Ptr)OPers->RAICData );
}


// %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
// Server <-> Box Personification Xfer

// The info exchanged looks like this:
//
//				         	  		           			  Taunt	  	  Info	    Custom Icon
//	opcode	[userID][ROMIconID][Town][Handle][Password][size:Text][size:Text][size:ISEG][IDSC]
//			\_______________________________________________________________/\_______________/
//					  	          		Mandatory				        	  	  Optional
//
// If the sender doesn't have a Custom Icon, he sends 0 for the ISEG size, then no more.
//
// The IDSC is just the framerate (a short) for an animated icon.  If the sender's custom
//  icon is static, 0 is sent.
//
// The receiver must always accept all 6 (4 with no Custom Icon) resources.
// He doesn't necessarily have to keep the Icon.
//
// string sizes are unsigned chars, icon size is a short.

int Server_GetPersonificationFromWire( ServerState *state, PersonificationSetupRec *OPers, unsigned char flags )
{
int					result;
short				theSize;


	result = kServerFuncOK;

	OPers->userIDData = 0;
	OPers->TauntTextData = 0;
	OPers->InfoTextData = 0;
	OPers->RAICData = 0;
	OPers->RAICDataSize = 0;

	PLogmsg(LOGP_PROGRESS,
		"  Server_GetPersonificationFromWire (flags 0x%.2x)\n", flags);

	if((flags & kPersonificationROMIconID) || (flags & kPersonificationROMClutID))
		OPers->userIDData = (userIdentification *)malloc( sizeof(userIdentification) );

// get [Password]

	if(flags & kPersonificationPassword )
	{
		Server_TReadDataSync( state->session, sizeof(Password), (Ptr)&(OPers->pwData) );
		Common_PasswordBinaryToAscii(state->boxOSState.boxType, OPers->pwData,
			OPers->pwData);
		if(Server_TCheckError(state->session) != noErr)
			goto abort;
	}

// get [size:Taunt]

	if( flags & kPersonificationTauntText )
	{
		Server_TReadDataSync( state->session, sizeof(short), (Ptr)&theSize );
		if(Server_TCheckError(state->session) != noErr)
			goto abort;

		if (theSize >= 128)
			PLogmsg(LOGP_PROGRESS, "WARNING: huge taunt (%d bytes)\n", theSize);

		OPers->TauntTextData = malloc( theSize );
		Server_TReadDataSync( state->session, theSize, OPers->TauntTextData );
		if(Server_TCheckError(state->session) != noErr)
			goto abort;
	}

// get [size:Info]

	if( flags & kPersonificationAboutText )
	{
		Server_TReadDataSync( state->session, sizeof(short), (Ptr)&theSize );
		if(Server_TCheckError(state->session) != noErr)
			goto abort;

		if (theSize >= 512)
			PLogmsg(LOGP_PROGRESS, "WARNING: huge info (%d bytes)\n", theSize);

		OPers->InfoTextData = malloc( theSize );
		Server_TReadDataSync( state->session, theSize, OPers->InfoTextData );
		if(Server_TCheckError(state->session) != noErr)
			goto abort;
#ifdef NOT_USED
		if (Server_ReceiveOptCompressedString(state, &theSize,
			&OPers->InfoTextData) != kServerFuncOK)
		{
			goto abort;
		}
#endif
	}

	if(flags & kPersonificationROMIconID )
	{
	// get [ROMIconID]

		Server_TReadDataSync( state->session, sizeof(DBID), (Ptr)&(OPers->userIDData->ROMIconID) );
		if(Server_TCheckError(state->session) != noErr)
			goto abort;
	
		OPers->RAICDataSize = 0;	// box never sends custom icon back up to the server, silly!
		(OPers->IDSCData).frameDelay = 0;
		OPers->RAICData = 0L;
	}

	if(flags & kPersonificationROMClutID )
	{
	// get [kPersonificationROMClutID]

		Server_TReadDataSync( state->session, sizeof(DBID), (Ptr)&(OPers->userIDData->colorTableID) );
		if(Server_TCheckError(state->session) != noErr)
			goto abort;
	}

	// box doesn't send its custom icon (kPersonificationRAMIcon), cuz they always originate on the server.


	PLogmsg(LOGP_PROGRESS,
		"  Server_GetPersonificationFromWire done\n");
	return (result);

abort:
	result = kServerFuncAbort;
	Server_DeletePersonification(OPers);
	return (result);
}


void Server_SendPersonification(ServerState *state, PlayerAccount *player, unsigned char flags)
{
short			theSize;
DBID			iconID;
unsigned char	opCode;
Password		binpw;


	PLogmsg(LOGP_PROGRESS, "Server_SendPersonification\n");

//	ASSERT(state->validFlags & kServerValidFlag_Personifications);


	opCode = msReceiveValidPers;

	// Don't do an early return from this routine!
	//
	Server_SetTransportHold(state->session, true);

	Server_TWriteDataSync( state->session, sizeof(unsigned char), (Ptr)&opCode );

	Server_TWriteDataSync( state->session, sizeof(unsigned char), (Ptr)&flags );

	if(flags & kPersonificationPassword )
	{
		Common_PasswordAsciiToBinary(state->boxOSState.boxType,
			player->password, binpw);
		//PLogmsg(LOGP_DBUG, "DBUG: SENDING PASSWD\n");
		//Loghexdump((char *)binpw, sizeof(Password));
		Server_TWriteDataSync( state->session, sizeof(Password), (Ptr)binpw );
	}

	if( flags & kPersonificationTauntText )
	{
		theSize = strlen( player->openTaunt ) + 1;
		Server_TWriteDataSync( state->session, sizeof(short), (Ptr)&theSize );
		Server_TWriteDataSync( state->session, theSize, player->openTaunt );
	}

	if( flags & kPersonificationAboutText )
	{
		theSize = strlen( player->personInfo ) + 1;
		Server_TWriteDataSync( state->session, sizeof(short), (Ptr)&theSize );
		Server_TWriteDataSync( state->session, theSize, player->personInfo );
#ifdef NOT_USED
		Server_SendOptCompressedString(state, player->personInfo);
#endif
	}

	if(flags & kPersonificationROMIconID )
	{
		iconID = (DBID)player->iconID;
		Server_TWriteDataSync( state->session, sizeof(DBID), (Ptr)&iconID );
	}
	
	if(flags & kPersonificationRAMIcon )
	{
		theSize = (short)player->customIconSize;
		Server_TWriteDataSync( state->session, sizeof(short), (Ptr)&theSize );

		if(theSize)
		{
		IconSetup			ramIconIDSC;

			Server_TWriteDataSync( state->session, (long)theSize, (Ptr)player->customIcon );
			//Loghexdump((char *)player->customIcon, theSize);
			ramIconIDSC.frameDelay = 0;
			Server_TWriteDataSync( state->session, sizeof(IconSetup), (Ptr)&ramIconIDSC );
		}
	}

	if(flags & kPersonificationROMClutID )
	{
		iconID = (DBID)player->colorTableID;
		Server_TWriteDataSync( state->session, sizeof(DBID), (Ptr)&iconID );
	}


	// Clean up & bail.
	//
	Server_SetTransportHold(state->session, false);
}


#ifdef NOT_USED
// The info exchanged looks like this:
//
//				         	  		           			  Taunt	  	  Info	    Custom Icon
//	opcode	[userID][ROMIconID][Town][Handle][Password][size:Text][size:Text][size:ISEG][IDSC]
//			\_______________________________________________________________/\_______________/
//					  	          		Mandatory				        	  	  Optional
//
// string sizes are unsigned chars, icon size is a short.

void Server_PutPersonificationOnWire( ServerState *state, PersonificationSetupRec *PSR )
{
userIdentification	*theUserIdentification;
//IconRefStruct		*theIREF;
IconSetup			*theIDSC;
Ptr					shit;
short				theSize;
long				opponentVerificationTag;


#if 0

// send [userID]

	Server_TWriteDataSync( state->session, sizeof(unsigned char), (Ptr)&PSR->userIDData->userID );

// send [ROMIconID]

//	theIREF = (IconRefStruct *)PSR;
	
	Server_TWriteDataSync( state->session, sizeof(DBID), (Ptr)&PSR->ROMIconID );

// send [Town]

	Server_TWriteDataSync( state->session, sizeof(Hometown), PSR->userIDData->userTown );

// send [Handle]

	Server_TWriteDataSync( state->session, sizeof(UserName), PSR->userIDData->userName );

// send [Password]

	Server_TWriteDataSync( state->session, sizeof(Password), PSR->pwData );

// send [size:Taunt]

	shit = PSR->TauntTextData;
	theSize = strlen( shit ) + 1;
	Server_TWriteDataSync( state->session, sizeof(short), (Ptr)&theSize );
	Server_TWriteDataSync( state->session, theSize, shit );

// send [size:Info]

	shit = PSR->InfoTextData;
	theSize = strlen( shit ) + 1;
	Server_TWriteDataSync( state->session, sizeof(short), (Ptr)&theSize );
	Server_TWriteDataSync( state->session, theSize, shit );


/*
*	8/4/94 7:03:39 PM (BET): I am guessing we don't need this...
* // send [size:ISEG][IDSC] (or 0 if there's no custom icon)
*	if ( DBGetItem( kIconBitMapType, theIREF->RAMID ) )
*	{
*		theSize = DBGetItemSize( kIconBitMapType, theIREF->RAMID );
*		Server_TWriteDataSync( state->session, sizeof(short), (Ptr)&theSize );				// send size
*
*		shit = DBGetItem( kIconBitMapType, theIREF->RAMID );
*		Server_TWriteDataSync( state->session, theSize, shit );								// send ISEG
*		
*		theIDSC = DBGetItem( kIconDescType, theIREF->RAMID );			// is it animated?
*		if ( theIDSC )
*			Server_TWriteDataSync( state->session, sizeof(IconSetup), (Ptr)theIDSC );		// send IDSC
*			else
*				Server_TWriteDataSync( state->session, sizeof(IconSetup), (Ptr)&theIDSC );	// send 0
*	}
*	else
*/
	{
		theSize = 0;										
		Server_TWriteDataSync( state->session, sizeof(short), (Ptr)&theSize );
	}
	
#endif

}
#endif	/*NOT_USED*/

