/*
 *	$Id: DiskTransport.h,v 1.2 1995/05/10 11:03:46 jhsia Exp $
 *
 *	$Log: DiskTransport.h,v $
 * Revision 1.2  1995/05/10  11:03:46  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		DiskTransport.h

	Contains:	GameTalk session layer header

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <3>	  7/8/94	ADS		Broken because interfaces changed
		 <2>	 5/26/94	BET		Fix some nitties
		 <1>	 5/26/94	BET		first checked in
		 <2>	 5/26/94	BET		Check in Shannon's start on changes for patchable managers, my
									changes for making work on the server.  Not verified yet on
									SegaOS.
*/

#ifndef __DiskTransport__
#define __DiskTransport__

#include "TransportStructs.h"
#include "NetStructs.h"
#include "OSManagers.h"
#include "Dispatcher.h"




OSErr		TOpen(SessionRec *s, PortT localPort, PortT remPort) =
					CallDispatchedFunction( kTOpen );
OSErr		TClose(SessionRec *s) =
					CallDispatchedFunction( kTClose );
char		TReadAByte( void ) =
					CallDispatchedFunction( kTReadAByte );
OSErr		TReadData(unsigned long length, Ptr address, Boolean async ) =
					CallDispatchedFunction( kTReadData );
short 		TNetIdle(NetParamBlock *pBlock) =
					CallDispatchedFunction( kTNetIdle );
short 		TNetError(void) =
					CallDispatchedFunction( kTNetError );
unsigned long	TReadBytesReady( unsigned long *amount ) =
					CallDispatchedFunction( kTReadBytesReady );
OSErr		TWriteAByte( char myByte ) =
					CallDispatchedFunction( kTWriteAByte );
OSErr		TWriteData(unsigned long length, Ptr address, Boolean async ) =
					CallDispatchedFunction( kTWriteData );



#endif // __DiskTransport__
