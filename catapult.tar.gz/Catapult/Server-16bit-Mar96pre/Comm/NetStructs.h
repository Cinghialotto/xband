/*
 *	$Id: NetStructs.h,v 1.2 1995/05/10 11:04:09 jhsia Exp $
 *
 *	$Log: NetStructs.h,v $
 * Revision 1.2  1995/05/10  11:04:09  jhsia
 * switch to cvs keywords
 *
 */

 /*
	File:		NetStructs.h

	Contains:	GameTalk common structure header

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<16>	 7/13/94	BET		unix-ise.
		<15>	 7/10/94	SAH		Moved NetErrorRecord to SegaTypes.h. Include SegaTypes now.
		<14>	  7/9/94	HEC		Added serverHandshakeError and peerHandshakeError fields.
		<13>	  7/7/94	BET		Add NetErrorRecord
		<12>	 6/30/94	BET		Add another state.  ***NOTE*** This is probably the last version
									that supports multisession.
		<11>	 6/19/94	BET		Add ioLastXXXError fields to net structs
		<10>	 6/18/94	BET		Restore Ted's state information to NetParamBlock.
		 <9>	 6/16/94	BET		Revert Ted's changes.
		 <8>	 6/15/94	BET		Make ioPhysNetState an unsigned short, not just unsigned
		 <7>	 6/15/94	HEC		ioPhysNetState added to NetParamBlock
		 <6>	 6/14/94	BET		Move kConnClosed to the top of the enum, this reflects default
									state of the connection records
		 <5>	 6/13/94	BET		Comment connection states.
		 <4>	 6/13/94	BET		Comment connection states.
		 <3>	  6/9/94	BET		Interface changesd
		 <2>	  6/2/94	BET		Add __SERVER__ assertion
		 <1>	 5/26/94	BET		first checked in
*/

#ifndef __NetStructs__
#define __NetStructs__

#if !defined(__SERVER__) && defined(__MWERKS__)
#define __SERVER__
#endif

#include "TransportStructs.h"
#include "PhysicalStructs.h"
#ifndef unix
#include "SegaTypes.h"
#endif

// NetIdle returns
enum {
	kNetIdle		= 0,								// (P|T) Nothing is happening
	kNetPrimed											// (P|T) Data is waiting in fifo on open connection
	};
	
// used for both phys and session layers
enum {
	kConnClosed = 0,									// (P|T) connection is closed
	kConnClosing,										// (T) shutting down the connection via local or remote
	kConnLocallyClosed,									// (T) going down on local request, next state is kConnClosing
	kConnOpen,											// (P|T) after sending open ack
	kConnOpening,										// (P|T) after sending first packet
	kConnListening,										// (P|T) listening for connection
	kConnFwdReset,										// (T) processing forward reset originated here
	kConnFwdResetAck,									// (T) recieved an ack on the forward reset we started
	kConnRecvDeny,										// (T) peer refused connection, cleared in TOpen
	kConnRecvReq,										// (T) recieved request
	kConnRecvReqAck										// (T) recieved req+ack
	};


typedef struct NetParamBlock {
	unsigned short			ioPhysNetState;				// connection state
	OSErr					ioLastTransportError;		// last transport error
	OSErr					ioLastPhysicalError;		// last physical error
	unsigned long			ioAvailable;				// rough amount available
	unsigned long			ioTotal;					// total bytes passed, not incl ioAvailable
} NetParamBlock;
	
#endif


