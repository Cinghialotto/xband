/*
 *	$Id: Testmodem.c,v 1.2 1995/05/10 11:04:27 jhsia Exp $
 *
 *	$Log: Testmodem.c,v $
 * Revision 1.2  1995/05/10  11:04:27  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		Testmodem.c

	Contains:	xxx put contents here xxx

	Written by:	xxx put writers here xxx

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <6>	 7/17/94	HEC		Stop funnin' me.
		 <5>	 6/29/94	HEC		New and exciting.
		 <4>	 6/20/94	HEC		The latest.
		 <3>	 6/18/94	HEC		Having fun now...
		 <1>	  6/9/94	HEC		first checked in

	To Do:
*/


#include "ModemPriv.h"
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include "Dispatcher.h"
#include "SegaOS.h"
#include "Errors.h"
#include "Time.h"
#include "ctype.h"

typedef struct {
	unsigned char r[20];
} ModemState;

void DTMFCreate(void);
void DetectAnything(void);
short CompareModemState(ModemState *a, ModemState *b);
void GetModemState(ModemState *s);
void PrintModemState(ModemState *s);
void DetectTones(void);
void SetTLVL(long);
void ToneMode(void);
void SetTone(long);
void printhelp(void);
char *confstr(short conf);
char *speedstr(short conf);
void DTMFListen(void);
void CallWaitingListen(void);
void SendByte(char c);
void SendString(char *s);
void ReadString(void);
void ShowRLSD(void);
void printregs(void);
short ListenBong(void);
short ALoopback(void);
short DLoopback(void);
void MasterCWHandler(void);
void Mark(void);
long Stop(void);
void SendCount(short n);
void AnalyzeDisturbance(void);
void ring(void);
void SetTDAMP(long amp);
void PrintTDAMP(void);
void ContHaveCallWaiting(void);
void CheckCallWaiting(void);
void TimeLatency(void);
void Loopback(void);
void CheckEQM(void);
void onhook(void);
void offhook(void);
void OrigTrial(char *);
void AnswerTrial(void);
void DataMode(void);
void SelfBusy(char *);

#define GetCurrentTime() TickCount()

long markTime;
char dtmfmap[] = {"147*2580369#ABCD"};
short fake = 0;

void printhelp()
{
	printf("help or ?	help page\n");
	printf("on		on hook\n");
	printf("off		off hook\n");
	printf("w			wait for call\n");
	printf("dial #		dial number\n");
	printf("call		dial number\n");
	printf("prog		put modem in call progress mode\n");
	printf("idle		put modem in idle mode\n");
	printf("tone		put modem in tone mode\n");
	printf("dtmf		listen for digits\n");
	printf("cw		listen for call waiting\n");
	printf("send (str)	send data\n");
	printf("read (str)	receive data\n");
	printf("rlsd		display status of RLSD reg\n");
}

void main(void)
{
	MODEMPTR;
	char line[128];
	char name[128];
	char string[128];
	short done;
	long amp,x;

	done = 0;
	printf("Catapult Modem Tester (? for help)\n\n");
	InitModem();
	modemPtr = REFGLOBAL(modem,modemPtr);
	printregs();
	while (!done)
	{
		printf("\n> ");
        gets(line);
		if (strncmp("tlvl",line,4) == 0)
		{
			sscanf(line,"%s %ld", name, &x);
			SetTLVL(x);
		}
		if (strcmp(line,"on") == 0)
		{
			onhook();
		}
		if (strcmp(line,"detany") == 0)
		{
			DetectAnything();
		}
		if (strcmp(line,"det") == 0)
		{
			DetectTones();
		}
		else if (strcmp(line,"off") == 0)
		{
			offhook();
		}
		else if (strcmp(line,"?") == 0 || strcmp(line,"help") == 0)
		{
			printhelp();
			continue;
		}
		else if (strcmp(line,"w") == 0)
		{
			_ModemAnswer(fake);
		}
		else if (strcmp(line,"atest") == 0)
		{
			AnswerTrial();
		}
		else if (strncmp("otest",line,4) == 0)
		{
			sscanf(line,"%s %s", name, string);
			OrigTrial(string);
		}
		else if (strncmp("ring",line,4) == 0)
		{
			sscanf(line,"%s %s", name, string);
			modemDial(string, true, 0);
		}
		else if (strncmp("dial",line,(size_t)4) == 0)
		{
			sscanf(line,"%s %s", name, string);
			printf("dialing %s\n", string);
			_ModemOriginate(string,fake);
		}
		else if (strncmp("self",line,(size_t)4) == 0)
		{
			sscanf(line,"%s %s", name, string);
			SelfBusy(string);
		}
		else if (strncmp("call",line,(size_t)4) == 0)
		{
			printf("Dialing %s\n",kPhoneNumber);
			ResetModem();
			MyDelayMS(2000);
			_ModemOriginate(kPhoneNumber,fake);
		}
		else if (strcmp(line,"prog") == 0)
		{
			SETCONF(kDialMode); NEWCONF;
		}
		else if (strcmp(line,"idle") == 0)
		{
			SETCONF(kV22bisMode); NEWCONF;
		}
		else if (strncmp("settone",line,7) == 0)
		{
			sscanf(line,"%s %ld", name, &x);
			SetTone(x);
		}
		else if (strcmp(line,"tone") == 0)
		{
			ToneMode();
		}
		else if (strcmp(line,"r") == 0)
		{
			ResetModem();
		}
		else if (strcmp(line,"dtmf") == 0)
		{
			DTMFCreate();
		}
		else if (strcmp(line,"dtmflisten") == 0)
		{
			DTMFListen();
		}
		else if (strcmp(line,"cw") == 0)
		{
			CallWaitingListen();
		}
		else if (strcmp(line,"send") == 0)
		{
			SendString("Hello There!\n");
		}
		else if (strcmp(line,"read") == 0)
		{
			ReadString();
		}
		else if (strcmp(line,"data") == 0)
		{
			DataMode();
		}
		else if (strcmp(line,"rlsd") == 0)
		{
			ShowRLSD();
		}
		else if (strcmp(line,"aloop") == 0)
		{
			ALoopback();
		}
		else if (strcmp(line,"dloop") == 0)
		{
			DLoopback();
		}
		else if (strcmp(line,"master") == 0)
		{
			MasterCWHandler();
		}
		else if (strcmp(line,"getamp") == 0)
		{
			PrintTDAMP();
		}
		else if (strcmp(line,"hcw") == 0)
		{
			CheckCallWaiting();
		}
		else if (strcmp(line,"chcw") == 0)
		{
			ContHaveCallWaiting();
		}
		else if (strcmp(line,"time") == 0)
		{
			TimeLatency();
		}
		else if (strcmp(line,"loop") == 0)
		{
			Loopback();
		}
		else if (strcmp(line,"eqm") == 0)
		{
			CheckEQM();
		}
		else if (strcmp(line,"fake") == 0)
		{
			fake = 1-fake;
			if (fake) printf("fake ON\n");
			if (!fake) printf("fake OFF\n");
		}
		else if (strncmp("setamp",line,(size_t)6) == 0)
		{
			sscanf(line,"%s %ld", name, &amp);
			printf("amp = %ld\n", amp);
			SetTDAMP(amp);
		}
		printregs();
	}
}

void ring(void)
{
	MODEMPTR;
	while (!Button())
	printf("%d",RI);

}

void SendString(char *string)
{
	for ( ; *string; ) {
		SendByte(*string++);	
	}
}

void SendByte(char c)
{
	MODEMPTR;
	while (!TDBE)
		;
	SETTBUFFER(c);
}

void ReadString(void)
{
	long rlsd = 1;
	long eqm;
	MODEMPTR;
	
	while (1) {
		if (RDBF)
			printf("%c", RBUFFER);
		if (Button())
			return;
#if 0
		if (rlsd != RLSD) {
			rlsd = RLSD;
			printf("RLSD = %d\n",rlsd);		
		}
		eqm = ReadXRAM(0x52,1);
		if (eqm > 15000) {
			printf("EQM = %ld\n",eqm);		
		}
#endif
	}
}

void AnalyzeDisturbance(void)
{
	MODEMPTR;
	short cw = 0;

	if (FE || !RLSD)					// Problem Occurs
	{
		cw = ListenBong();				// Check Call Waiting on Our end
		if (cw) {
			// We got call waiting, so tell the remote guy about it.
		
		
		}
	}
}

void DTMFCreate()
{
	MODEMPTR;
	DTMF1;
	SETCONF(kDialMode);
	NEWCONF;
	WriteXRAM(0x7e,0,0);	// indefinate duration
	SETTBUFFER(0x0B);
}

void DTMFListen(void)
{
	MODEMPTR;
	ToneMode();
	printf("listening for tones... knock yourself out. Hit mouse to end.\n");
	DTMFE1;
	while (!Button()) {
		if (!DTDET) continue;
		printf("%c\n", dtmfmap[DTDIG]);	
	}
}

char *confstr(short conf)
{
	switch(conf) {
		case kV22bisMode:
			return "V22bis Mode";
		case kV22Mode:
			return "V22 Mode";
		case kV21Mode:
			return "V21 Mode";
		case kDialMode:
			return "Call Mode";
		case kToneMode:
			return "Tone Mode";	
		case kBell103Mode:
			return "Bell103 Mode";	
	}
	return "Idle mode";
}

char *speedstr(short speed)
{
	switch(speed) {
		case 0:
			return "300 baud";
		case 1:
			return "600 baud";
		case 2:
			return "1200 baud";	
		case 3:
			return "2400 baud";	
	}
	return "unknown baud";
}

void ShowRLSD(void)
{
	short rlsd = -1;
	short news = -1;
	short cts = -1;
	short fe = -1;
	short oe = -1;
	short pe = -1;
	
	MODEMPTR;
	NEWS0;
	while (!Button()) {
		if (rlsd != RLSD) {
			rlsd = RLSD;
			printf("RLSD :%d\t", rlsd);
		}
		if (news != NEWS) {
			news = NEWS;
			printf("NEWS :%d\t", news);
			NEWS0;
		}
		if (cts != CTS) {
			cts = CTS;
			printf("CTS  :%d\t", cts);
		}
		if (fe != FE) {
			fe = FE;
			printf("FE   :%d\t", fe);
		}
		if (oe != OE) {
			oe = OE;
			printf("OE   :%d\t", oe);
		}
		if (pe != PE) {
			pe = PE;
			printf("PE   :%d\t", pe);
		}
	}
}

void printregs(void)
{
	MODEMPTR;
	printf("RING :%d\t", RI);
	printf("TONEA:%d\t", TONEA);
	printf("TONEB:%d\t", TONEB);
	printf("TONEC:%d\t", TONEC);
	printf("ATV25:%d\t", ATV25);
	printf("ATBEL:%d\t", ATBELL);
	printf("BELL :%d\n", BEL103);
	
	printf("NEWS :%d\t", NEWS);
	printf("NEWC :%d\t", NEWC);
	printf("DATA :%d\t", DATA);
	printf("ORG  :%d\t", ORG);
	printf("TDBE :%d\t", TDBE);
	printf("RDBF :%d\t", RDBF);
	printf("RA   :%d\n", RA);

	printf("CTS  :%d\t", CTS);
	printf("RTS  :%d\t", RTS);
	printf("DSR  :%d\t", DSR);
	printf("VOL  :%d\t", VOL);
	printf("RLSD :%d\t", RLSD);
	printf("TPDM :%d\t", TPDM);
	printf("SLEEP:%d\n", SLEEP);

	printf("ASYNC:%d\t", ASYNC);
	printf("SCR  :%d\t", SCR);
	printf("L2ACT:%d\t", L2ACT);
	printf("S1DET:%d\t", S1DET);
	printf("SADET:%d\t", SADET);
	printf("RTDET:%d\t", RTDET);
	printf("GTE  :%d\n", GTE);

	printf("WDSZ :%d\t", WDSZ);
	printf("PARSL:%d\t", PARSL);
	printf("PEN  :%d\t", PEN);
	printf("STB  :%d\t", STB);
	printf("FE   :%d\t", FE);
	printf("OE   :%d\t", OE);
	printf("LL   :%d\n", LL);

	printf("CONF:%02X (%s)\t", CONF, confstr(CONF));
	printf("SPEED:%d (%s)\n", SPEED, speedstr(SPEED));
}

void CallWaitingListen(void)
{
	MODEMPTR;
	short oldMode, lost = 0, oldORG;
	
	printf("Listening for Call Waiting\n");
	
	oldMode = CONF;
	oldORG = ORG;
	do{
		if (RLSD) continue;
		if (!lost) printf("Lost Carrier.\n");
		lost = 1;
		ORG1;
		SETTONE;
		MyDelay(2);
		if (TONEA) {
			printf("TONE A DECTECTED\n");
		}	
		if (TONEB) {
			printf("TONE B DECTECTED - Call Waiting Bong\n");
		}	
		if (TONEC) {
			printf("TONE C DECTECTED\n");
		}
		if (RLSD && lost) {
			printf("RLSD :1\n");
			lost = 0;
		}
		if (oldORG) ORG1; else ORG0; NEWCONF;
		SETCONF(oldMode);
		NEWCONF;
	} while (!Button());
	if (oldORG) ORG1; else ORG0; NEWCONF;
	SETCONF(oldMode);
	NEWCONF;
	printf("\n");
}

void SendCount(short n)
{
	char str[10];

	sprintf(str,"%d\n",n);
	SendString(str);
}

void PrintTDAMP(void)
{
	long amp1, amp2;
	MODEMPTR;
	
	SETXADDR(0x6E);
	XWT0;
	XCR0;
	XACC1;
	while(XACC);
	amp1 = XDATA;
	
	SETXADDR(0x6F);
	XWT0;
	XCR0;
	XACC1;
	while(XACC);
	amp2 = XDATA;
	
	printf("AMP1(6E)=%04X  AMP2(6F)=%04X\n", amp1, amp2);
}

void SetTDAMP(long amp)
{
	MODEMPTR;
	
	SETXDATA(amp);
	SETXADDR(0x6E);
	XWT1;
	XCR0;
	XACC1;
	while(XACC);
	
	SETXDATA(amp);
	SETXADDR(0x6F);
	XWT1;
	XCR0;
	XACC1;
	while(XACC);
	
	PrintTDAMP();
}


short DLoopback(void)
{
	MODEMPTR;
	char c = '0';

	SETDATA;
	ORG1;
	NEWCONF;
	SETCONF(kV22bisMode);
	NEWCONF;
	RLSD1;
	NEWCONF;
	CTS1;
	NEWCONF;
	DSR1;
	NEWCONF;
	L2ACT1;
	NEWCONF;
	RTS1;
	NEWCONF;
	while (!Button())
	{
		if (TDBE) SETTBUFFER(c++);
		if (RDBF) printf("%c\n",RBUFFER);
	}	
}


short ALoopback(void)
{
	MODEMPTR;
	char c = '0';

	SETDATA;
	ORG1;
	NEWCONF;
	SETCONF(kV22bisMode);
	NEWCONF;
	RLSD1;
	NEWCONF;
	CTS1;
	NEWCONF;
	DSR1;
	NEWCONF;
	L3ACT1;
	NEWCONF;
	RTS1;
	NEWCONF;
	while (!Button())
	{
		if (TDBE) SETTBUFFER(c++);
		if (RDBF) printf("%c\n",RBUFFER);
	}	
}

void Mark(void)
{
	markTime = GetCurrentTime();
}

long Stop(void)
{
	return GetCurrentTime() - markTime;
}

void ContHaveCallWaiting(void)
{
	short d, nd;
	
	d = nd = 0;
	do {
		if (HaveCallWaiting(false))
			d++;
		else
			nd++;
		printf("call waiting tries:  detected=%d  not detected=%d   \r", d, nd);
	} while (!Button());
}

void CheckCallWaiting(void)
{
	if (HaveCallWaiting(true))
		printf("Have call waiting\n");
	else
		printf("Do not have call waiting\n");
}

void Loopback(void)
{
	MODEMPTR;
	// sit here sending back data we've received until mouse button hit
	while (!Button()) {
		if (RDBF) {
			while (!TDBE);
			SETTBUFFER(RBUFFER);		
		}
	}
}

#define kMicroDelay ((long)60*1000*1000)
#define kEXPVALUE 0xA3

void TimeLatency(void)
{
	MODEMPTR;
	TMTask tm;
	long overhead, trip;
	long d, trips,total,count, avg;

	trips = 0;
	total = 0;
	avg = 0;
	tm.tmAddr = nil;
	InsTime((QElemPtr) &tm);
	PrimeTime((QElemPtr) &tm,-kMicroDelay);
	RmvTime((QElemPtr) &tm);
	overhead = kMicroDelay + tm.tmCount;	// remember: microseconds are negative
	printf("overhead is %ld us\n", overhead);
	while (!Button())
	{
		while (!TDBE);
		// send data
		SETTBUFFER(0xA3);
		PrimeTime((QElemPtr) &tm,-kMicroDelay);
		// wait for response
		while (!RDBF)
			if (Button()) {
				RmvTime((QElemPtr) &tm);
				return;
			}
		RmvTime((QElemPtr) &tm);
		trip = kMicroDelay + tm.tmCount - overhead;
		d = RBUFFER;
		if (d != kEXPVALUE)
			printf("received unexpected value\n");
		trips++;
		total += (trip/2);
		avg = total/trips;
		printf("%ld trips: round time: %ld us. oneway: %ld us, avg. oneway: %ld us\n",
			trips, trip,trip/2,avg);
	}
}

void CheckEQM(void)
{
	long eqm, i;

	while (!Button()) {
		eqm = ReadXRAM(0x52, 1);
		if (eqm > 1000) {
			printf("%8ld ",eqm);
			for (i=eqm/1000; i; i--)
				printf(".");
			printf("\n");
		}
	}
	printf("\n");
}

void SetTLVL(long x)
{
	MODEMPTR;
	SETTLVL(x);
	printf("Setting TLVL to %ld\n", x);
}

void SetTone(long hz)
{
	unsigned short x;
	MODEMPTR;
	WriteXRAM(0x6E,0,0x3000);
	WriteXRAM(0x6F,0,0);
	x = ((hz*360/7200)*32768)/180;
	printf("Tone is %ld Hz = 0x%04X\n", hz, x);
	WriteXRAM(0x6C, 0, x);
}

void DataMode(void)
{
	MODEMPTR;
	SETCONF(kV22bisMode);
	NEWCONF;
	LL1;
	NEWCONF;
	SETDATA;
}

void ToneMode(void)
{
	MODEMPTR;
	LL0;
	NEWCONF;
 	DATA0;
	NEWCONF;
 	SETCONF(kToneMode);
 	NEWCONF;
}

void DetectTones(void)
{
	MODEMPTR;
	long t=0;
	
	ToneMode();
	while (!Button()) {
		if (TONEA) {printf("A"); t=1;}
		if (TONEB) {printf("B"); t=1;}
		if (TONEC) {printf("C"); t=1;}
		if (t) printf("\n");
		t=0;
	}
}

void AnswerTrial(void)
{
	long g=0, t=0;

	while (!Button())
	{
		if (!_ModemAnswer(0))
			g++;
		t++;
		onhook();
		printf("good:%ld  bad:%ld  total:%ld\n",g,t-g,t);
	}
}

void OrigTrial(char *str)
{
	long g=0, t=0;

	while (!Button())
	{
		if (!_ModemOriginate(str, 0))
			g++;
		t++;
		ResetModem();
		printf("good:%ld  bad:%ld  total:%ld\n",g,t-g,t);
	}
}

void DetectAnything(void)
{
	ModemState n, s;
	
	GetModemState(&s);
	PrintModemState(&s);
	while (!Button()) {
		GetModemState(&n);
		if (CompareModemState(&n, &s)) {
			PrintModemState(&n);
		}
		s = n;
	}
}

void GetModemState(ModemState *s)
{
	MODEMPTR;
	short r;
	for (r = 0xA; r < 0x10; r++) {
		s->r[r] = READ_REG(r);
	}
}

void PrintModemState(ModemState *s)
{
	short r;
	for (r = 0xA; r < 0x10; r++) {
		printf("R(%2X)=%02X ", r, s->r[r]);
	}
	printf("\n");
}

short CompareModemState(ModemState *a, ModemState *b)
{
	short r;
	for (r = 0xA; r < 0x10; r++) {
		if (a->r[r] != b->r[r])
			return 1;
	}
	return 0;
}


void SelfBusy(char *num)
{
	long time;
	REFGLOBAL(modem,offtoon) = 0;
	REFGLOBAL(modem,noanswer) = 0;
	REFGLOBAL(modem,lastdet) = 0;
	REFGLOBAL(modem,ringtimer) = TickCount();
	modemDial(num, 1, 0);
	
	while (!Button()) {
		MyDelay(180);
		time = TickCount() + 60*3;
		while (time > TickCount())
		{
			switch(callprogress())
			{
			case kNothing:
			default:
				break;
			case kBusy:
				printf("Us!\n");
				goto exit;
			case kRing:
				printf("Not us!\n");
				goto exit;
			}	
		}
		printf("Timed out\n");
	exit:
		onhook();
		ResetModem();
	}
}

#define kEQMThreshold			2000
#define kEQMPeriod				240
#define kPreCWNoNoisePeriod		(60*4)
#define kCWDTMFPeriod			(60*5)	/* must be greater than kEQMPeriod */
#define kCWSendDTMFValue		0xB
#define kCWReceiveDTMFValue		0xC
#define kBongListenTimeout		20

void MasterCWHandler(void)
{
	MODEMPTR;
	long eqm;
	long time, timeout;
	long rlsd;
	short result;
	long lasteqmtime;
	
	/* wait for call waiting, then try and reestablish the connection */
	/* This only happens in the originate case, since the answer case */
	/* does not disturb carrier, just data integrity. */
	short c = 0;
	lasteqmtime = 0;
	time = GetCurrentTime();

	rlsd = RLSD;
	while (!Button()) {
		eqm = ReadXRAM(0x52,1);
		if ((RLSD) && (eqm > kEQMThreshold) && (GetCurrentTime() > time))
		{
			result = ListenBong();
			if (result == 1 && (lasteqmtime < GetCurrentTime()-kPreCWNoNoisePeriod))
			{
				long oldTONTME;
				printf("Call Waiting\n");
				oldTONTME = ReadXRAM(0x7E,0);

				DTMF1;
				SETCONF(kDialMode);
				NEWCONF;
				WriteXRAM(0x7e,0,0);
				SETTBUFFER(kCWSendDTMFValue);
				printf("DTMF is on.\n");
				timeout = GetCurrentTime() + kCWDTMFPeriod;
				while(GetCurrentTime() < timeout)
					;
				printf("DTMF is off.\n");
				WriteXRAM(0x7e,0,oldTONTME);
				return;
			}
			else if (result == 2)	// remote call waiting
			{
				return;
			}
			else	// Nothing detected
			{
				printf("Noise?\n");
				// Return to data mode
				SETCONF(kV22bisMode);
				NEWCONF;
				LL1;
				NEWCONF;
				SETDATA;
				RTRN1;
				printf("\nWaiting for retrain to finish\n");
				while (RTRN);
				printf("Retrain Finished\n");
			}
			lasteqmtime = GetCurrentTime();
			time = GetCurrentTime() + kEQMPeriod;
		}
		if (rlsd != RLSD) {
			rlsd = RLSD;
			printf("\nRLSD:%ld\n", rlsd);
		}
		// send byte
		if (RLSD && CTS) {
			SendByte('*');
		}
		// receive byte
		if (RDBF) {
			c = RBUFFER;
			if (isprint(c))
				printf("%c", c);
		}
	}
}


short ListenBong(void)
{
	MODEMPTR;
	long timeout;
	
	ToneMode();
	DTMFE1;
	MyDelay(3);
	timeout = GetCurrentTime() + kBongListenTimeout;
	while (timeout > GetCurrentTime()) {
		if (DTDET && (DTDIG == kCWReceiveDTMFValue)) {
			printf("\nRemote Call Waiting Detected (DTMF=0x%X)\n",DTDIG);
			return 2;
		}
		if (TONEB) {
			printf("\nTONE B DETECTED\n");
			return 1;
		}
	}	
	return 0;
}



