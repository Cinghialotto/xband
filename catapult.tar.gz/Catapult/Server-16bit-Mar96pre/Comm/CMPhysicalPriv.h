/*
 *	$Id: CMPhysicalPriv.h,v 1.2 1995/05/10 11:03:42 jhsia Exp $
 *
 *	$Log: CMPhysicalPriv.h,v $
 * Revision 1.2  1995/05/10  11:03:42  jhsia
 * switch to cvs keywords
 *
 */

 /*
	File:		CMPhysicalPriv.h

	Contains:	GameTalk physical layer header

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <9>	 6/15/94	BET		Add PHTotalIn and PHTotalOut, remove PHTotal.
		 <8>	 6/13/94	BET		Add GameTalk poo.  Last CMPhys checkin had this too, but I
									forgot it in the comment
		 <7>	  6/5/94	BET		Yet even more FUD
		 <5>	  6/3/94	BET		Add more FUD
		 <4>	  6/2/94	BET		Change the way globals are accessed
		 <3>	 5/31/94	BET		Changed PHCheckNext to PHPacketState
		 <2>	 5/26/94	BET		Check in Shannon's start on changes for patchable managers, my
									changes for making work on the server.  Not verified yet on
									SegaOS.
*/

#ifndef __PhysicalPriv__
#define __PhysicalPriv__


#define kMagicVal 'BET!'

#if defined(SIMULATOR) || defined(__SERVER__)
#define CHECKMAGIC(a) { if (a->PHMagic != kMagicVal) ASSERT_MESG(0, "PH Globals are bad!"); }
#else //#elif defined(SEGAONLY)
#define CHECKMAGIC(a) { if (a->PHMagic != kMagicVal) asm { dc.w 0xa003 }; }
#endif

typedef struct PGlobalType {
	ConnHandle				PHConnHandle;				// CommToolbox stuff
	ConnectionCompletionUPP	ReadCallbackUPP;			// Routine Descriptor for callback
	ConnectionCompletionUPP	WriteCallbackUPP;			// Routine Descriptor for callback
	RDS						*PHReadyBuffer;				// buffer that we are primed to put stuff into
	RDS						*PHFilledBuffer;			// buffer that we already put stuff into
	short					PHPacketState;				// state of the current packet (in framing, etc.)
	unsigned short			PHFrameSizAccum;			// accumulator for current frame length
	Fifo					PHLengthsFifo;				// fifo of packet lengths
	unsigned char			*PHLengthsBuf;				// buffer for the lengths
	Fifo					PHReadFifo;					// fifo information for physical fifo
	unsigned char			*PHReadDataBuf;				// circular buffer space
	Boolean					PHWriteActive;				// signals outstanding Async IO
	Fifo					PHWriteFifo;				// fifo information for physical fifo
	unsigned char			*PHWriteDataBuf;			// circular buffer space
	unsigned char			*PHStagingBuf; 				// circular buffer space

	unsigned long			PHTotalIn;					// sum of bytes passed
	unsigned long			PHTotalOut;					// sum of bytes passed
	Boolean					PHIndicating;				// PNetIdle is already threading an indication
	short					PHConnState;				// state of connection
	short					PHGameFifoR;				// read pointer of game fifo
	short					PHGameFifoW;				// write pointer of game fifo
	unsigned long			*PHGameFifoBuf;				// buffer for actual data
	short					PHGTPacketType;				// packet type we are currently processing
	long					PHMagic;					// Magic Cookie for testing
#ifdef DEBUG
	Fifo					testRead;
	Fifo					testWrite;
#endif
	} PGlobalType;

#ifdef	SIMULATOR
#define	MANAGERGLOBALTYPE		PGlobalType
#else
PGlobalType PGlobals;
#endif

#endif //  __PhysicalStructs__
