/*
 *	$Id: fifo.c,v 1.2 1995/05/10 11:04:38 jhsia Exp $
 *
 *	$Log: fifo.c,v $
 * Revision 1.2  1995/05/10  11:04:38  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		fifo.c

	Contains:	xxx put contents here xxx

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<19>	 8/13/94	BET		Add FifoPeekEnd.
		<18>	 7/19/94	BET		Fix ByteCopy macro
		<17>	 7/18/94	DJ		moved include TransportLayer.h to first.  this is important for
									MWerks build
		<16>	 7/18/94	JOE		(ADS) fix fifo globals
		<15>	 7/17/94	ADS		manager-ize
		<14>	 7/13/94	BET		unix-ise.
		<13>	 6/30/94	BET		Code review dust bunny cleanup.
		<12>	 6/19/94	BET		Big changes.  Just in time.  Remove FifoUAdjust, it was a stupid
									hack that didn't make any sense anyways.  Remove the frameAdjust
									parameters that linked it in.  Add new calls to record how much
									has been sucked off.
		<11>	 6/18/94	BET		Add a debugger to FifoUAdjust.  Want to see if anyone hits it.
		<10>	 6/15/94	BET		Fix a problems in FifoUnread and FifoUnwrite.  FifoUnread was
									the only real problem, FifoUnwrite was mostly an anal attack.
		 <9>	 6/10/94	BET		Add changes
		 <7>	  6/3/94	BET		FifoRead can get called from FifoSkip with a nil buffer.  I
									fixed this before, but it never got checked in apparently.
		 <6>	  6/2/94	SAH		(Really BET) Change BlockMove to ByteCopy from utils.c
		 <5>	 5/31/94	BET		Changed (char *)'s to (unsigned char *)
		 <4>	 5/29/94	BET		Remove a DebugStr
		 <3>	 5/29/94	BET		Fix up FifoUAdjust a bit
		 <2>	 5/26/94	BET		Remove obsolete references to GameTalk.h
		 <3>	 5/24/94	BET		Add a missing return value in FifoWrite
		 <2>	 5/24/94	BET		Add fifo pointer locking via setIntr() and resetIntr()
		 <1>	 5/18/94	BET		first checked in

	To Do:
*/

// ===========================================================================
//	fifo.c					�1994 Brian Topping All rights reserved.
// ===========================================================================

#include "TransportLayer.h"
#include "fifo.h"
#include "NetErrors.h"
#include "PhysicalStructs.h"
#include "ccitt.h"
#include "Errors.h"
#ifndef unix
#include "utils.h"
#endif

#ifdef unix
#define ByteCopy(a,b,c) memcpy(a,b,c)
#endif


#ifndef __SERVER__

typedef struct	FifoGlobals	{		// empty!!!!
	short	dummy;
} FifoGobals;

#ifndef SIMULATOR
FifoGobals gFifoGLobals;
#endif


long
_FifoControl ( short command, long data )
{
FifoGobals *globals;
long offset;
OSErr error;

	error = commandSelectorUnknown;

	switch ( command )
		{
		case kHardInitialize:
		
			/* allocate and initialize our globals */
			GETMGRGLOBALSOFFSET(gFifoGLobals,offset);
			
			error = AllocateGlobalSpace ( kFifoManager, offset, sizeof(FifoGobals), (Ptr *) &globals );
			if ( error != noErr )
				{
				return error;
				}
			
			/* install our selectors */
			SetDispatchedFunction ( kFifoInit,					kFifoManager,	_FifoInit );
			SetDispatchedFunction ( kFifoActive,				kFifoManager,	_FifoActive );
			SetDispatchedFunction ( kFifoWrite,					kFifoManager,	_FifoWrite );
			SetDispatchedFunction ( kFifoRead,					kFifoManager,	_FifoRead );
			SetDispatchedFunction ( kFifoPeek,					kFifoManager,	_FifoPeek );
			SetDispatchedFunction ( kFifoPeekEnd,				kFifoManager,	_FifoPeekEnd );
			SetDispatchedFunction ( kFifoAvailable,				kFifoManager,	_FifoAvailable );
			SetDispatchedFunction ( kFifoRemaining,				kFifoManager,	_FifoRemaining );
			SetDispatchedFunction ( kFifoSkip,					kFifoManager,	_FifoSkip );
			SetDispatchedFunction ( kFifoCopy,					kFifoManager,	_FifoCopy );
			SetDispatchedFunction ( kFifoChkSum,				kFifoManager,	_FifoChkSum );
			SetDispatchedFunction ( kGetFifoIn,					kFifoManager,	_GetFifoIn );
			SetDispatchedFunction ( kFifoLastCharIn,			kFifoManager,	_FifoLastCharIn );
			SetDispatchedFunction ( kFifoUnwrite,				kFifoManager,	_FifoUnwrite );
			SetDispatchedFunction ( kFifoSize,					kFifoManager,	_FifoSize);
			SetDispatchedFunction ( kFifoFlush,					kFifoManager,	_FifoFlush );
			SetDispatchedFunction ( kFifoUnread,				kFifoManager,	_FifoUnread );
			SetDispatchedFunction ( kFifoResetConsumption,		kFifoManager,	_FifoResetConsumption );
			SetDispatchedFunction ( kFifoAdjustConsumption,		kFifoManager,	_FifoAdjustConsumption );
			break;
		
		case kSoftInialize:
			error = noErr;
			break;
		
		case kHardClose:
			error = noErr;
			break;
		
		case kSoftClose:
			error = noErr;
			break;
					
		case kCodeBlockMoved:
			error = noErr;
			break;
					
		case kGlobalsMoved:
			error = noErr;
			break;
		}
		
	return error;
}

#endif


//////////////////////////////////////////////////////////////////////////
// BRAIN DAMAGE:  All code needs to be checked for unsigned long problems 
// 				  with subtract & compare operations
//////////////////////////////////////////////////////////////////////////

void _FifoInit(Fifo *f, unsigned char *bufStart, unsigned long length, short type)
{
	f->cache = f->input = f->output = f->bufStart = bufStart;
	f->bufEnd = bufStart + length;
	f->qType = type;
	SETFIFONODATA(f);
}

Boolean _FifoActive(Fifo *f)
{
	return (f->qType != kUnusedQ);
}

// add some data from linear array to the fifo
OSErr _FifoWrite(Fifo *f, unsigned char *inBuf, unsigned long length)
{
long			part1, part2;
unsigned char	*newInput;

	if (!length)
		return noErr;
		
	if (length > FifoRemaining(f)) {
		ERROR_MESG( "Attempted Overflow in FifoWrite");
		return kFifoOverflowErr;
		}
	// find what remains linearly in buffer
	part1 = f->bufEnd - f->input;
	if (part1 >= length) {
		// we can do linear to linear copy
		ByteCopy((Ptr)f->input, (Ptr)inBuf, length);
		newInput = f->input + length;
		}
	else {
		if (f->qType & kCircularQMask) {
			part2 = length - part1;
			// slice it in half
			ByteCopy((Ptr)f->input, (Ptr)inBuf, part1);
			ByteCopy((Ptr)f->bufStart, (Ptr)inBuf + part1, part2);
			newInput = f->bufStart + part2;
			}
		}
	
	f->input = newInput;
	SETFIFOHASDATA(f);
	
	return noErr;
}

// read some data from fifo to linear array
OSErr _FifoRead(Fifo *f, unsigned char *outBuf, unsigned long length)
{
long			part1, part2;
unsigned char	*newOutput;

	if (length > FifoAvailable(f))  {
//		ERROR_MESG( "Attempted Underflow in FifoRead");
		return kFifoUnderflowErr;
		}
	// find what remains linearly in fifo
	part1 = f->bufEnd - f->output;
	if (part1 >= length) {
		if (outBuf)
			// we can do linear to linear copy
			ByteCopy((Ptr)outBuf, (Ptr)f->output, length);
		newOutput = f->output + length;
		}
	else {
		if (f->qType & kCircularQMask) {
			part2 = length - part1;
			if (outBuf) {
				// slice it in half
				ByteCopy((Ptr)outBuf, (Ptr)f->output, part1);
				ByteCopy((Ptr)outBuf+part1, (Ptr)f->bufStart, part2);
				}
			newOutput = f->bufStart + part2;
			}
		}
		
	f->output = newOutput;
	if (f->input == f->output)
		SETFIFONODATA(f);
	f->consumption += length;
	
	return noErr;
}

// look at the first data in the fifo, but don't remove it
OSErr _FifoPeek(Fifo *f, unsigned char *outBuf, unsigned long length)
{
long	part1, part2;

	if (length > FifoAvailable(f))  {
		ERROR_MESG( "Underflow in FifoPeek");
		return kFifoUnderflowErr;
		}
	// find what remains linearly in fifo
	part1 = f->bufEnd - f->output;
	if (part1 >= length) {
		// we can do linear to linear copy
		ByteCopy((Ptr)outBuf, (Ptr)f->output, length);
		}
	else {
		if (f->qType & kCircularQMask) {
			part2 = length - part1;
			// slice it in half
			ByteCopy((Ptr)outBuf, (Ptr)f->output, part1);
			ByteCopy((Ptr)outBuf+part1, (Ptr)f->bufStart, part2);
			}
		}

	return noErr;
}


// look at the _last_ data in the fifo, but don't remove it
OSErr _FifoPeekEnd(Fifo *f, unsigned char *outBuf, unsigned long length)
{
long	part1, part2;

	if (length > FifoAvailable(f))  {
		return kFifoUnderflowErr;
		}
	// find what remains linearly in fifo at end
	part2 = f->input - f->bufStart;
	if (part2 >= length) {
		// we can do linear to linear copy
		ByteCopy((Ptr)outBuf, (Ptr)f->input - length, length);
		}
	else {
		if (f->qType & kCircularQMask) {
			part1 = length - part2;
			// slice it in half
			ByteCopy((Ptr)outBuf, (Ptr)f->bufEnd - part1, part1);
			ByteCopy((Ptr)outBuf+part1, (Ptr)f->bufStart, part2);
			}
		}

	return noErr;
}


// Ouch!  This MoFo copies data between fifos, taking into account whether they
// are circular or not, and if they are circular, dealing with the combinations
// of split buffer copies that are available.

OSErr _FifoCopy(Fifo *src, Fifo *dest, unsigned long inLength)
{
long 				part1;
#define kY 256
unsigned char		buf[kY];
unsigned long 		length;

	length = inLength;
	// first check for overflow on write
	if (length > FifoRemaining(dest)) {
		ERROR_MESG( "Dest Overflow in FifoCopy");
		return kFifoOverflowErr;
		}
	
	// next check for underflow on read
	if (length > FifoAvailable(src)) {
		ERROR_MESG( "Source underflow in FifoCopy");
		return kFifoUnderflowErr;
		}
	
	// if we are there, update read consumption tracking
	if (!((src->qType & kCircularQMask) || (dest->qType & kCircularQMask))) {
		// both buffers are linear, the easy case
		src->consumption += length;
		FifoWrite(dest, src->output, length);
		src->output += length;
		}
	else if ((src->qType & kCircularQMask) && (dest->qType & kCircularQMask)) {
		// both buffers are non-linear.  This case sucks
		// do the BRAIN DAMAGE thing to get it up, fix it later
		while (length) {
			if (length > kY)
				part1 = kY;
			else
				part1 = length;
			length -= part1;
			if (FifoRead(src, buf, part1)) {
				ERROR_MESG("Error from FifoRead in FifoCopy");
				}
			if (FifoWrite(dest, buf, part1)) {
				ERROR_MESG("Error from FifoWrite in FifoCopy");
				}
			}
		}
	// one or the other is non-circ
	else if (src->qType & kCircularQMask) {
		// this needs a buffer to make the original data non-circ
		// or a two part copy
		src->consumption += length;
		part1 = src->bufEnd - src->output;
		if (part1 >= length) {	
			// do it in one swipe
			FifoWrite(dest, src->output, length);
			src->output += length;
			}
		else {
			length -= part1;
			FifoWrite(dest, src->output, part1);
			FifoWrite(dest, src->bufStart, length);
			src->output = src->bufStart + length;
			}		
		}
	else {
		// dest is circ, that is also easy
		src->consumption += length;
		FifoWrite(dest, src->output, length);
		src->output += length;
		}
	
	// update flags
	if (inLength)
		SETFIFOHASDATA(dest);
	if (src->input == src->output)
		SETFIFONODATA(src);

	return noErr;
}

// how much is available to read from the fifo
unsigned long _FifoAvailable(Fifo *f)
{
unsigned long	length;
unsigned char	*bufEnd, *bufStart;

	if (f->qType == kUnusedQ)
		return 0;

	bufEnd = f->input;
	bufStart = f->output;
	
	// check for wraparound
	if (bufEnd < bufStart) 
		// data in buf is non-linear
		length = (f->bufEnd - bufStart) + (bufEnd - f->bufStart);
	else  {
		// data in buf is linear
		length = bufEnd - bufStart;
		}
		
	// if the length looks like zero but we know there is data, the buffer is full
	if ((!length) && (GETFIFOHASDATA(f)))
		length = f->bufEnd - f->bufStart;

	return length;
}

// how much is available for us to write into the fifo
unsigned long _FifoRemaining(Fifo *f)
{
unsigned long	length;
unsigned char	*bufEnd, *bufStart;

	if (f->qType == kUnusedQ)
		return 0;
	if (f->qType == kCachingQ)
		bufEnd = f->cache;
	else
		bufEnd = f->output;
	bufStart = f->input;
	
	// check for wraparound
	if (bufEnd < bufStart) 
		// data in buf is non-linear
		length = (f->bufEnd - bufStart) + (bufEnd - f->bufStart);
	else {
		// data in buf is linear or full
		length = bufEnd - bufStart;
		
		if ((!length) && (!GETFIFOHASDATA(f)))
			length = f->bufEnd - f->bufStart;
		}
	return length;
}

// skip some bytes
OSErr _FifoSkip(Fifo *f, unsigned long skip)
{
	return FifoRead(f, nil, skip);
}


// This is heavily dependent on the format of a physical frame in PhysicalLayer.h
unsigned short _FifoChkSum(Fifo *f, unsigned long length)
{
long			part1, part2;
unsigned short	crc;

	crc = 0xffff;
	if (length > FifoAvailable(f))  {
		ERROR_MESG( "Underflow in FifoChkSum");
		return kFifoUnderflowErr;
		}
	// find what remains linearly in fifo
	part1 = f->bufEnd - f->output;
	if (part1 >= length) {
		// we can do linear to linear copy
		crc = ccitt_updcrc(crc, f->output, length);
		}
	else {
		if (f->qType & kCircularQMask) {
			part2 = length - part1;
			// slice it in half
			crc = ccitt_updcrc(crc, f->output, part1);
			crc = ccitt_updcrc(crc, f->bufStart, part2);
			}
		}
	return crc;
}

// return the current fifo input ptr for DMA.  If doIncr is true, input ptr is
// incremented by length.  BRAIN DAMAGE:  This isn't correct if the frameEnd boundary
// is in the middle of the returned pointer
unsigned char * _GetFifoIn(Fifo *f, unsigned long length, Boolean doIncr)
{
unsigned char	*retVal;
long			overrun;
unsigned char	*newInput;

	retVal = f->input;
	if (doIncr) {
		newInput = f->input + length;
		overrun = newInput - f->bufEnd;
		if (overrun >= 0)
			newInput = f->bufStart + overrun;
			
		f->input = newInput;
		SETFIFOHASDATA(f);
		}
		
	return retVal;
}

// gets the last char from the fifo, assumes that there is no DMA in progress
unsigned char _FifoLastCharIn(Fifo *f)
{
	if (f->input == f->bufStart)
		return f->bufEnd[-1];
	else
		return f->input[-1];
}

// undo the last length bytes written to the fifo
// return the total size of the fifo
unsigned long _FifoSize(Fifo *f)
{
	return f->bufEnd - f->bufStart;
}

// caching queues need to be explicitly flushed.  Call this routine with the amount to flush
// or zero to flush as much as possible.  
OSErr _FifoFlush(Fifo *f, unsigned long length)
{
	if (f->qType != kCachingQ) {
		ERROR_MESG( "Can't FifoFlush a non-caching queue");
		return kFifoWrongType;
		}
	if (f->output >= f->cache) {
		// data is linear
		f->cache += length;
		if (f->cache > f->output)
			f->cache = f->output;
		}
	else {
		// data is non-linear
		f->cache += length;
		if (f->cache >= f->bufEnd) {
			f->cache = f->bufStart + (f->cache - f->bufEnd);
			if (f->cache > f->output) 
				f->cache = f->output;
			}
		}
	return noErr;
}

// undo the last length bytes read from the fifo, but not more than the cache holds
OSErr _FifoUnread(Fifo *f, unsigned long length)
{
unsigned char	*newOutput;

	if (f->qType != kCachingQ) {
		ERROR_MESG( "BRAIN DAMAGE in FifoUnread");
		return kFifoWrongType;
		}

	newOutput = f->output;
	if (newOutput > f->cache) {
		// data is linear
		newOutput -= length;
		if (newOutput < f->cache)
			return kFifoUnderflowErr;
		}
	else {
		// data is non-linear
		newOutput -= length;
		if (newOutput < f->bufStart) {
			newOutput = f->bufEnd - (f->bufStart - newOutput);
			if (newOutput < f->cache)
				return kFifoUnderflowErr;
			}
		}
	f->output = newOutput;
	f->consumption -= length;
	if (length)
		SETFIFOHASDATA(f);

	return noErr;
}


OSErr _FifoUnwrite(Fifo *f, unsigned long length)
{
long			underrun, avail;
unsigned char	*newInput;

	avail = FifoAvailable(f);
	if (length > avail) {
		ERROR_MESG("Underflow in FifoUnwrite");
		return kFifoUnderflowErr;
		}
		
	newInput = f->input - length;
	// if there is an underrun, it will be negative here
	underrun = newInput - f->bufStart;
	if (underrun < 0) 
		newInput = f->bufEnd + underrun;

	f->input = newInput;
	if (length == avail)
		SETFIFONODATA(f);
	return noErr;
}

OSErr _FifoResetConsumption(Fifo *f)
{
	f->consumption = 0;
	return noErr;
}

OSErr _FifoAdjustConsumption(Fifo *f, unsigned long amount)
{
	if (f->consumption != amount) {
		if (f->consumption < amount) 
			return FifoSkip(f, amount - f->consumption);
		else {
			ERROR_MESG("Tell Brian he is a fucker!");
			}
		f->consumption = amount;
		}
	return noErr;
}

		

