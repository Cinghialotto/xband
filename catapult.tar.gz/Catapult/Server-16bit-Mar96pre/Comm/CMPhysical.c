/*
 * 	$Id: CMPhysical.c,v 1.2 1995/05/10 11:03:40 jhsia Exp $
 *
 *	$Log: CMPhysical.c,v $
 * Revision 1.2  1995/05/10  11:03:40  jhsia
 * switch to cvs keywords
 *
 */

//#define TRASHPACKETS 1
#ifndef DEBUG
#define DEBUG 1
#endif

/*
	File:		CMPhysical.c

	Contains:	Physical layer via Comm Toolbox

	Written by:	Brian Topping, Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<56>	 7/24/94	BET		Update POpen interfaces
		<55>	 7/18/94	DJ		moved include TransportLayer.h to first.  this is important for
									mwerks build
		<54>	 7/15/94	HEC		Changed POpen/PListen server param to long flags for more
									general mode passing.
		<53>	  7/9/94	BET		Fix a mems leak when DEBUG is on.
		<52>	  7/6/94	DJ		add turdettes
		<51>	  7/6/94	JOE		Pull turdlets
		<50>	  7/5/94	BET		Update PInit to match new interfaces
		<49>	  7/3/94	HEC		Yeah
		<48>	  7/3/94	HEC		Added server param to PListen and PListenAsync
		<47>	  7/2/94	BET		Well, that doesn't work either for Metro.  Add the macro
									directly.
		<46>	  7/2/94	BET		Forgot to add "asm.h".
		<45>	  7/2/94	BET		Change POpen interfaces.  Change debug read fifo to new
									location.
		<44>	 6/30/94	BET		Change add 'k's for Kon.  Add packet masher macros for
									reliability testing.
		<43>	 6/20/94	BET		PUProcessIdle was managerized, but removed when the assembly was
									added.  This remanagerizes it.
		<42>	 6/20/94	BET		Match changes in rest of project
		<41>	 6/20/94	BET		Checkin changes for Fred2
		<40>	 6/19/94	BET		Fix a jizzler I found in the other source
		<39>	 6/19/94	BET		Did Shannon say fuck?
		<38>	 6/18/94	BET		Add state information to NetParamBlock.
		<37>	 6/18/94	BET		Add higher layer notification for closing connection
		<36>	 6/18/94	BET		Add time.h
		<35>	 6/17/94	BET		Wrap DEBU with conditional
		<34>	 6/17/94	BET		Fix a jizzler in the dispatcher
		<33>	 6/16/94	BET		Dwain Bamage
		<32>	 6/16/94	BET		Dwain Bamage
		<31>	 6/16/94	BET		Back out changes for Ted
		<30>	 6/16/94	BET		Add changes to simulate bad line (ifdefed         above) and add
									Ted's changes for line state
		<29>	 6/15/94	BET		Add changes to simulate bad line (ifdefed above) and add Ted's
									changes for line state
		<28>	 6/14/94	BET		Opening dialog changes seemed to work, additional GameTalk work
									now
		<27>	 6/13/94	BET		First round of changes for open dialog recovery.  This is to
									help the modem startup.
		<26>	  6/9/94	BET		ioNetUp is now ioPhysNetUp
		<25>	  6/5/94	BET		PInit should not check magic
		<24>	  6/5/94	BET		Add config string to TOpen and TListen
		<23>	  6/4/94	DJ		error checking and propogation (got killed by KON, so fuckit)
		<22>	  6/3/94	BET		Make it work on listen with serial tool
		<21>	  6/3/94	BET		Add more FUD
		<20>	  6/3/94	BET		I hate global variables.  And they hate me.  Hate is bad in this
									case.
		<19>	  6/3/94	DJ		(Really BET) Now work on the globals some
		<18>	  6/2/94	BET		A bunch of changes to make 2400 baud work (damn CTB!)
		<17>	  6/2/94	KON		Fix undefined GetGlobals reference. [BET]
		<16>	  6/2/94	BET		Do some more changes to align with SegaSerial
		<15>	  6/1/94	SAH		(Really BET) fix a prob with PUAsyncWriteFifoData not setting up
									A5 before calling dispatcher
		<14>	  6/1/94	BET		Fix a problem in propagating false errors
		<13>	  6/1/94	BET		Fix a bug in write completion.
		<12>	 5/31/94	BET		Fix new wierdness in ADSP
		<11>	 5/31/94	BET		Added architectural support for moving to sega, added game-game
									communication primitives.
		<10>	 5/29/94	BET		Change parameters passed to FifoRead on a packet with bad
									checksum.  Make some of the assertions more palatable for
									breakfast.
		 <8>	 5/27/94	BET		ASSERT_MESG is backwards from IfDEBUGStr
		 <7>	 5/27/94	BET		Remove a Debugger(), change some globals stuff to be more sane.
		 <6>	 5/27/94	BET		Fix globals not geting inited properly.  Bytes are being lost
									now, but it is much better than the last vers.
		 <5>	 5/26/94	SAH		Get the globals correctly at soft initialize time.
		 <4>	 5/26/94	SAH		KIlled some compile errors.
		 <3>	 5/26/94	BET		Check in Shannon's start on changes for patchable managers, my
									changes for making work on the server.  Not verified yet on
									SegaOS.
		 <2>	 5/25/94	BET		Fix a checkin messup

	To Do:
	�	The preproc define CORRECT is used where code should be changed before shipping
*/

#define kCloseTimeout	(60*12)

#include "PhysicalLayer.h"
#include "PhysicalStructs.h"
#include "CMPhysicalPriv.h"
#include "TransportLayer.h"
#include "ccitt.h"
#include "heaps.h"
#include "SegaOS.h"
#include "serial.h"
#include "NetErrors.h"
#include "Errors.h"
#include <CommResources.h>
#include <string.h>
#include "NetMisc.h"
#ifndef __SERVER__
#include "time.h"
#endif

#ifdef THINK_C
#define THINKSUCKS
#endif

#ifndef OFFSET
#define OFFSET(type, field)		((int) &((type *) 0)->field)
#endif


// extern protos
OSErr	_PInit(void);
OSErr	_POpen(char *config, long flags);
OSErr	_PListen(char *config, long flags);
OSErr	_PClose(void);
short	_PNetIdle(NetParamBlock *pBlock);
OSErr	_PWritePacketSync(WDS *sendBuffer);
OSErr	_PWritePacketASync(WDS *sendBuffer);
OSErr	_PUOpenPort(Boolean listen, char *config);
void	_PUClosePort(void);
OSErr	_PUAsyncReadData(long numBytes, unsigned char *dataBuf);
OSErr	_PUAsyncWriteFifoData(void);
void	PUAsyncReadDispatch(PGlobalType * glob, unsigned char prevChar);
OSErr	_PUProcessIdle(void);

// internal protos
short PUGetToolProcID(void);
pascal void PUAsyncWriteCompletion(ConnHandle hConn);
pascal void PUAsyncReadCompletion(ConnHandle hConn);


#ifdef __SERVER__
	#define	GetGlobals()	&PGlobals;
#ifdef THINK_C
#define GetCurrentTime() TickCount()
#else
	#define GetCurrentTime() LMGetTicks()
#endif
#else
	PGlobalType PGlobals;
	#define	GetGlobals()	((PGlobalType *) &REFGLOBAL(PGlobals,PHConnHandle))
#endif

#ifndef __SERVER__

long
_PhysicalLayerControl (short command, long data)
{
PGlobalType		*globals;
long			offset;
short			error;
short			count;
PubHeap			heap;

	error = commandSelectorUnknown;

	switch (command)
		{
		case kHardInitialize:
		
			/* allocate and initialize our globals */
			GETMGRGLOBALSOFFSET(PGlobals,offset);
			
			error = AllocateGlobalSpace (kPhysicalLayerManager, offset, sizeof(PGlobalType), (Ptr *) &globals);
			if (error != noErr)
				{
				return error;
				}
				
			/* install our selectors */
			SetDispatchedFunction (kPInit,					kPhysicalLayerManager,	_PInit);
			SetDispatchedFunction (kPOpen,					kPhysicalLayerManager,	_POpen);
			SetDispatchedFunction (kPListen,				kPhysicalLayerManager,	_PListen);
			SetDispatchedFunction (kPClose,					kPhysicalLayerManager,	_PClose);
			SetDispatchedFunction (kPNetIdle,				kPhysicalLayerManager,	_PNetIdle);
			SetDispatchedFunction (kPWritePacketSync,		kPhysicalLayerManager,	_PWritePacketSync);
			SetDispatchedFunction (kPWritePacketASync,		kPhysicalLayerManager,	_PWritePacketASync);
			SetDispatchedFunction (kPUOpenPort,				kPhysicalLayerManager,	_PUOpenPort);
			SetDispatchedFunction (kPUClosePort,			kPhysicalLayerManager,	_PUClosePort);
			SetDispatchedFunction (kPUAsyncReadData,		kPhysicalLayerManager,	_PUAsyncReadData);
			SetDispatchedFunction (kPUAsyncWriteFifoData,	kPhysicalLayerManager,	_PUAsyncWriteFifoData);
			SetDispatchedFunction (	kPUProcessIdle,			kPhysicalLayerManager,	_PUProcessIdle );
			break;
		
		case kSoftInialize:
			// clear out globals
			globals = GetGlobals();
			for (count = sizeof(PGlobalType)-1; count >= 0; count--)
				((char *)globals)[count] = 0;
			
			REFGLOBAL(PGlobals,PHMagic) = kMagicVal;
			// set up buffers
			REFGLOBAL(PGlobals,PHLengthsBuf) = NewMemory(kTemp, kFrameStartBufSiz);
			REFGLOBAL(PGlobals,PHReadDataBuf) = NewMemory(kTemp, kPhysBufferSize);
			REFGLOBAL(PGlobals,PHWriteDataBuf) = NewMemory(kTemp, kPhysBufferSize);
			REFGLOBAL(PGlobals,PHStagingBuf) = NewMemory(kTemp, kMaxPacket);
			
			error = noErr;
			break;
		
		case kHardClose:
			error = noErr;
			break;
		
		case kSoftClose:
			error = noErr;
			break;
					
		case kCodeBlockMoved:
			error = noErr;
			break;
					
		case kGlobalsMoved:
			error = noErr;
			break;
		}
		
	return error;
}

#endif


OSErr	_PCheckError(void)
{
	return(noErr);
}


OSErr _PInit(void)
{
PGlobalType		*glob = GetGlobals();

	// assume that the globals are clear by now!
#ifdef __SERVER__
	glob->PHLengthsBuf = (unsigned char *)NewPtr(kFrameStartBufSiz);
	glob->PHReadDataBuf = (unsigned char *)NewPtr(kPhysBufferSize);
	glob->PHWriteDataBuf = (unsigned char *)NewPtr(kPhysBufferSize);
	glob->PHStagingBuf = (unsigned char *)NewPtr(kMaxPacket);
	glob->PHMagic = kMagicVal;
#endif

	InitCRM();
	InitCTBUtilities();
	InitCM();
	return noErr;
}

OSErr _POpen(char *config, unsigned long flags)
{
	return PUOpenPort(kOriginate, config);
}

OSErr _PListen(char *config, long flags)
{
	return PUOpenPort(kListen, config);
}

OSErr _PClose(void)
{
NetParamBlock	pBlock;
unsigned long	stopTime, read, write, lastRead, lastWrite;
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	if (!glob->PHConnHandle) 
		return noErr;
	
	if (glob->PHConnState != kConnClosed) {
		// signal handlers
#ifdef CORRECT
		(*PIdler[((PLinkHeader *)frameStart)->protoType])(nil, kConnClosing, 0);
#else
		TIndication(nil, kConnClosing, 0);
#endif
		NetIdle(&pBlock);
		stopTime = GetCurrentTime() + kCloseTimeout;
		while ((pBlock.ioPhysNetState == kConnOpen) && (stopTime < GetCurrentTime())) {
			read = FifoAvailable(&glob->PHReadFifo);
			write = FifoAvailable(&glob->PHWriteFifo);
			if ((lastRead != read) || (lastWrite != write)) {
				lastRead = read;
				lastWrite = write;
				stopTime = GetCurrentTime() + kCloseTimeout;
				}
			}
		PUClosePort();
		glob->PHConnState = kConnClosed;
		}
	
	CMDispose(glob->PHConnHandle);
	glob->PHConnHandle = nil;
	return noErr;
}


// NetIdle -- returns kNetPrimed (0) if net is idle, kNetPrimed (1) if ready,
//	negative gen purpose error code on failure.
short _PNetIdle(NetParamBlock *pBlock)
{
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	// dump the crap somewhere if we don't have a place to put it
	if (pBlock) {
		pBlock->ioLastPhysicalError = noErr;
		pBlock->ioAvailable = 0;
		pBlock->ioTotal = glob->PHTotalIn;
		pBlock->ioPhysNetState = kConnClosed;
		}
		
	switch (glob->PHConnState) {
		case kConnOpen:
			CMIdle(glob->PHConnHandle);
			if (pBlock)
				pBlock->ioPhysNetState = kConnOpen;
			break;
		case kConnClosed:
		case kConnClosing:
			break;
		default:
			ASSERT_MESG(0,"Unhandled connection state case!");
		};
	
	return PUProcessIdle();
}

OSErr _PWritePacketSync(WDS *sendBuffer)
{
short			retVal;
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	if (glob->PHConnState != kConnOpen) 
		return kLinkClosed;

	retVal = PWritePacketASync(sendBuffer);
	if (retVal) return retVal;
	
	while (glob->PHWriteActive)
		PNetIdle(nil);
		
	return noErr;
}

OSErr _PUProcessIdle(void)
{
short			frameSize, retVal;
PGlobalType		*glob = GetGlobals();

	if (glob->PHIndicating)
		return noErr;
		
	retVal = FifoRead(&glob->PHLengthsFifo, (unsigned char *)&frameSize, sizeof(short));
	if (retVal == noErr)
		PUProcessSTIdle(frameSize);
	else if (retVal == kFifoUnderflowErr)
		retVal = noErr;
	glob->PHIndicating = false;
	
	PUAsyncWriteFifoData();
	return retVal;
}

// queue small chunks as we find kDLEChar's scattered through the outgoing buffer
// called by TWriteDataSync, and in turn TWriteDataASync
OSErr _PWritePacketASync(WDS *sendBuffer)
{
OSErr			theErr;
long			bufLength, iter, padPoint;
unsigned char	*addr;
unsigned short	crc;
Boolean			doingFCS;
PGlobalType		*glob = GetGlobals();
DECLAREVARSIFTESTING();

	CHECKMAGIC(glob);
	if (glob->PHConnState != kConnOpen) 
		return kLinkClosed;
//	if (glob->PHGTPacketType != kSTType)
//		return kWrongPacketType;
		
	bufLength = sendBuffer->length1 + sendBuffer->length2;
	if (FifoRemaining(&glob->PHWriteFifo) < bufLength) {
		// we have more to write than the fifo can handle.  Idle here if
		// if the buffer is big enough to ever handle it, otherwise idle until
		// FifoAvailable is zero and switch buffers.
		if (FifoSize(&glob->PHWriteFifo) > bufLength) {
			// the fifo can handle it, just not right now.  Idle a bit
			while (FifoRemaining(&glob->PHWriteFifo) < bufLength) {
				PNetIdle(nil);
				if (Button()) return kAsyncInProgErr;
				}
			}
		else {
			// the buffer is bigger than the fifo
			ASSERT_MESG(0,"The packet write fifo isn't big enough to for this buffer");
			}
		}
	
	bufLength = sendBuffer->length1;
	addr = sendBuffer->buf1;
	padPoint = iter = 0;
	crc = 0xffff;
	doingFCS = false;
	while (1) {
		// (doingFCS == true) signals the writing of the FCS itself
		if (!doingFCS)
			crc = ccitt_updcrc(crc, (unsigned char *)addr, bufLength);
		while (iter < bufLength) {
			if (addr[iter] == kDLEChar) {
				iter += 1;
				TRASHHEADERIFTESTING();
				theErr = FifoWrite(&glob->PHWriteFifo, &addr[padPoint], iter - padPoint);
				LASTTRASHHEADERIFTESTING();
				if (theErr) return theErr;
				if (iter <= bufLength) {
					// send a pad
					theErr = FifoWrite(&glob->PHWriteFifo, &addr[iter-1], 1);
					if (theErr) return theErr;
					padPoint = iter;
					}
				}
			else {
				iter += 1;
				if (iter == bufLength) {
					TRASHHEADERIFTESTING();
					// flush the rest of the buffer
					theErr = FifoWrite(&glob->PHWriteFifo, &addr[padPoint], bufLength - padPoint);
					LASTTRASHHEADERIFTESTING();
					if (theErr) return theErr;
					}
				}
			}
		if (doingFCS)
			break;
		else if (addr == sendBuffer->buf1) {
			// if the address is the first buffer then it should be the second next loop
			padPoint = iter = 0;
			bufLength = sendBuffer->length2;
			addr = sendBuffer->buf2;
			UPDATEVARSIFTESTING();
			}
		else {
			// if the address is not the FCS and not the first buffer then it 
			// is the second and we should set up for the FCS
			crc = ~crc;
			padPoint = iter = 0;
			bufLength = sizeof(crc);
			addr = (unsigned char *)&crc;
			doingFCS = true;
			TRASHCRCIFTESTING();
			}
		}
		
	// send the framing
	crc = (kDLEChar<<8) + kETXChar;
	
	TRASHENDIFTESTING();

	theErr = FifoWrite(&glob->PHWriteFifo, (unsigned char *)&crc, sizeof(crc));
	if (theErr) return theErr;
	
	// call netidle to get the write rolling
	PNetIdle(nil);
	
	return noErr;
}

short _PUProcessSTIdle(unsigned short length)
{
short			hold;
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	glob->PHIndicating = true;
	// checksum happens in the fifo to avoid gratuitous copying
	if ((FifoChkSum(&glob->PHReadFifo, length - kFramingSize) == 0x1D0F)
			&& (length > kPhysHdrSiz + kFCSSize + kFramingSize)) {
		FifoSkip(&glob->PHReadFifo, kPhysHdrSiz);

		FifoResetConsumption(&glob->PHReadFifo);
#ifdef CORRECT
		// good packet, dispatch on type
		(*PIdler[((PLinkHeader *)frameStart)->protoType])();
#else
		// a good approximation, since there is only one protocol type
		TIndication(&glob->PHReadFifo, glob->PHConnState, length - (kPhysHdrSiz + kFCSSize + kFramingSize));
#endif
		FifoAdjustConsumption(&glob->PHReadFifo, length - (kPhysHdrSiz + kFCSSize + kFramingSize));
#ifdef DEBUG
		// kill the FCS and check that the framing is all there
		FifoSkip(&glob->PHReadFifo, kFCSSize);
		FifoRead(&glob->PHReadFifo, (unsigned char *)&hold, kFramingSize);
		ASSERT_MESG(hold == 0x1003,"Frame end mismatch");
#else
		// just kill it all
		FifoSkip(&glob->PHReadFifo, kFramingSize+kFCSSize);
#endif
		}
	else {
		// BRAIN DAMAGE: record bad packet reception here 
		WARNING_MESG("Bad Packet Detected");
#ifdef DEBUG
		// kill the FCS and check that the framing is all there
		FifoSkip(&glob->PHReadFifo, length - kFramingSize);
		FifoRead(&glob->PHReadFifo, (unsigned char *)&hold, kFramingSize);
		ASSERT_MESG(hold == 0x1003,"Frame end mismatch");
#else
		// just kill it all
		FifoSkip(&glob->PHReadFifo, length);
#endif
		}
	return noErr;		
}


OSErr _PUOpenPort(Boolean listen, char *config)
{
CMBufferSizes	sizes;
Point			where = {100,100};
OSErr			theErr;
Str32			localConfig;
short			procID;
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	
	if (glob->PHConnState == kConnOpen)
		return noErr;
		
	// just return if the port is open
	if (glob->PHConnHandle)
		return noErr;

	sizes[cmDataIn] = 0;
	sizes[cmDataOut] = 0;
	sizes[cmCntlIn] = 0;
	sizes[cmCntlOut] = 0;
	sizes[cmAttnIn] = 0;
	sizes[cmAttnOut] = 0;
	
	if (config) {
		strcpy((char *)localConfig,config);
		c2pstr((char *)localConfig);
		procID = CMGetProcID(localConfig);
		glob->PHConnHandle = CMNew(procID, cmData, sizes, 0, SetCurrentA5());
		CMReset(glob->PHConnHandle);
		CMSetConfig(glob->PHConnHandle, &config[strlen(config)+1]);
		}
	else {
		procID = PUGetToolProcID();
		glob->PHConnHandle = CMNew(procID, cmData, sizes, 0, SetCurrentA5());
		CMReset(glob->PHConnHandle);
#ifdef SIMULATOR
		FlushEvents(keyDownMask+keyUpMask+autoKeyMask, 0);
#endif
		CMChoose(&glob->PHConnHandle, where, nil);
		}

	// make sure there are no characters that the callback counter will count
	// they will be included in the first lengths fifo entry,screwing things up later
	// not sure that this is doing the trick, but it screws up the serial tool if it is done later
	if (listen) {
		theErr = CMListen(glob->PHConnHandle, false, nil, -1);
		if ((theErr) && (theErr != cmNotSupported)) {
			CMDispose(glob->PHConnHandle);
			glob->PHConnHandle = nil;
			return theErr;
			}
		else if (theErr == cmNotSupported) {
			if (CMOpen(glob->PHConnHandle, false, nil, -1)) {
				CMDispose(glob->PHConnHandle);
				glob->PHConnHandle = nil;
				return theErr;
				}
			}
		else
			CMAccept(glob->PHConnHandle, true);
		}
	else {
		theErr = CMOpen(glob->PHConnHandle, false, nil, -1);
		if (theErr) {
			CMDispose(glob->PHConnHandle);
			glob->PHConnHandle = nil;
			return theErr;
			}
		}
	
	// set up the fifo
	FifoInit(&glob->PHReadFifo, glob->PHReadDataBuf, kPhysBufferSize, kCircularQ);
	FifoInit(&glob->PHWriteFifo, glob->PHWriteDataBuf, kPhysBufferSize, kCircularQ);
	FifoInit(&glob->PHLengthsFifo, glob->PHLengthsBuf, kFrameStartBufSiz, kCircularQ);
	glob->PHFrameSizAccum = 0;
	
	glob->ReadCallbackUPP = NewConnectionCompletionProc(PUAsyncReadCompletion);
	glob->WriteCallbackUPP = NewConnectionCompletionProc(PUAsyncWriteCompletion);
	glob->PHReadyBuffer = nil;
	
#ifdef DEBUG
	// test code
	FifoInit(&glob->testRead, (unsigned char *)NewPtrClear(10000), 10000, kCircularQ);
	*((Fifo **)OFFSET(SegaLowMem,debugReserve1)) = &glob->testRead;
	FifoInit(&glob->testWrite, (unsigned char *)NewPtrClear(10000), 10000, kCircularQ);
	*((Fifo **)OFFSET(SegaLowMem,debugReserve2)) = &glob->testWrite;
#endif
	
	glob->PHPacketState = kProcessingST;
	
	PUAsyncReadData(1, GetFifoIn(&glob->PHReadFifo, 1, true));
	
	glob->PHConnState = kConnOpen;
	
	return noErr;
}

void _PUClosePort(void)
{
CMStatFlags 	status;
CMBufferSizes	sizes;
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	if(!glob->PHConnHandle)
		return;
	
	CMStatus(glob->PHConnHandle, sizes, &status);
		
	if (!(status & cmStatusOpen)) {
		CMIOKill(glob->PHConnHandle, 
			cmDataIn+cmDataOut+cmCntlIn+cmCntlOut+cmAttnIn+cmAttnOut+cmRsrvIn+cmRsrvOut);
		CMClose(glob->PHConnHandle, false, nil, -1, true);
		}
		
#ifdef DEBUG
	DisposePtr((Ptr)glob->testRead.bufStart);
	DisposePtr((Ptr)glob->testWrite.bufStart);
#endif
	
 	return;
}


short PUGetToolProcID(void)
{
Str255			toolName;
OSErr			theErr;
short			procID;
	
	procID = CMGetProcID("\pSerial Tool");
	if (procID == -1) {
		if (!(theErr = CRMGetIndToolName(classCM,1,toolName)))
			procID = CMGetProcID(toolName);
		}
	return procID;
}

pascal void PUAsyncReadCompletion(ConnHandle hConn)
{
unsigned char	*readEndPtr, prevChar;
PGlobalType		*glob = 0;
OSErr			theErr;

#if defined(THINKSUCKS) || defined(__MWERKS__)
long			oldGlob;

	oldGlob = SetA5((**hConn).userData);
#endif

#ifdef __SERVER__
	glob = GetGlobals();
#else
	if (GetManagerGlobals (kPhysicalLayerManager, (Ptr *) &glob, 0L) != noErr) {
		/* BRAIN DAMAGE: things are really bad if we get here */
		return;
		}
#endif

	CHECKMAGIC(glob);
	// check error cases 
	theErr = (**hConn).errCode;
	if (theErr) {
		if (theErr == abortErr)
			return;
		else if (theErr == cmNotOpen) {
			glob->PHConnState = kConnClosed;
			return;
			}
		else {
			Debugger();
			PUAsyncReadData(1, GetFifoIn(&glob->PHReadFifo, 1, false)-1);
			return;
			}
		}
			
	// make sure we got some bytes
	// This breaks the thread if we don't have data
	// usually we only break if there is a connection breakage
	if ((**hConn).asyncCount[cmDataIn] != 1) {
		glob->PHConnState = kConnClosed;
		return;
		}
	
	// update fram size accumulator
	glob->PHFrameSizAccum += 1;
	glob->PHTotalIn += 1;
	
	// get the last char
	prevChar = FifoLastCharIn(&glob->PHReadFifo);
	
	PUAsyncReadDispatch(glob, prevChar);
	
	readEndPtr = GetFifoIn(&glob->PHReadFifo, 1, true);
		
	PUAsyncReadData(1, readEndPtr);
#if defined(THINKSUCKS) || defined(__MWERKS__)
	SetA5(oldGlob);
#endif
}

// this needs to be an assembly dispatcher for the box
void PUAsyncReadDispatch(PGlobalType * glob, unsigned char prevChar)
{
	CHECKMAGIC(glob);
	
#ifdef DEBUG
	// Add to the fifo, then dump it out.  Gives us a buffer that never fills.
	FifoWrite(&glob->testRead, &prevChar, 1);
	FifoSkip(&glob->testRead, 1);
#endif
	
	// first check for frame end
	if ((glob->PHPacketState == kCheckNextST) && (prevChar == kETXChar)) {
		// yep, the last one was a frame
		FifoWrite(&glob->PHLengthsFifo, (unsigned char *)&glob->PHFrameSizAccum, sizeof(short));
		glob->PHFrameSizAccum = 0;
		glob->PHPacketState = kProcessingST; 			// reset for next time
		}
	else if (prevChar == kDLEChar) {					// found a DLE?
		if (glob->PHPacketState == kCheckNextST) { 		// yep, did we just see one?
			FifoUnwrite(&glob->PHReadFifo, 1);			// yep, dump this one
			// update fram size accumulator
			glob->PHFrameSizAccum -= 1;
			glob->PHPacketState = kProcessingST; 		// reset for next time
			}
		else											// didn't just see one, prepare to
			glob->PHPacketState = kCheckNextST;			// dump next one if there is one
		}
	else {
		glob->PHPacketState = kProcessingST; 			// either way the next is something!
		}
}

OSErr _PUAsyncReadData(long numBytes, unsigned char *dataBuf)
{
OSErr			theErr;
CMFlags 		recieveFlags;
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	if (!glob->PHConnHandle) {
		Debugger();
		return 69;
		}
	
	if (numBytes != 1) Debugger();

	theErr = CMRead(glob->PHConnHandle, dataBuf, &numBytes,
							cmData, true, glob->ReadCallbackUPP, -1, &recieveFlags);
	return theErr;
}


// this guy is in the closure for PUProcessData, so it probably needs to be written in assembly
// for SegaSerial.c
OSErr _PUAsyncWriteFifoData(void)
{
unsigned long	fifoAvailable;
short			theErr;
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	if (glob->PHConnState != kConnOpen) 
		return kLinkClosed;

	if (!glob->PHWriteActive) {
		fifoAvailable = FifoAvailable(&glob->PHWriteFifo);
		if (fifoAvailable) {
			if (fifoAvailable > kMaxPacket)
				fifoAvailable = kMaxPacket;
			glob->PHWriteActive = true;
			FifoRead(&glob->PHWriteFifo, glob->PHStagingBuf, fifoAvailable);
			
#ifdef DEBUG
			FifoWrite(&glob->testWrite, glob->PHStagingBuf, fifoAvailable);
			FifoSkip(&glob->testWrite, fifoAvailable);
#endif
	
			glob->PHTotalOut += fifoAvailable;
			
#ifdef TRASHEVERY1K
			if (glob->PHTotalOut > 1000) {
				glob->PHStagingBuf[0] = ~glob->PHStagingBuf[0];
				glob->PHTotalOut = 0;
				}
#endif
			theErr = CMWrite(glob->PHConnHandle, glob->PHStagingBuf, (long *)&fifoAvailable, cmData,
					true, glob->WriteCallbackUPP, 0, 0);
			}
		}
	return noErr;
}

pascal void PUAsyncWriteCompletion(ConnHandle hConn)
{
PGlobalType		*glob = 0;
#if defined(THINKSUCKS) || defined(__MWERKS__)
long			oldGlob;

	if ((**hConn).userData == 0)
		{
		DebugStr("\pa5==nil in PUAsyncWriteCompletion");
		}
	oldGlob = SetA5((**hConn).userData);
#endif

#ifdef __SERVER__
	glob = GetGlobals();
#else
	if (GetManagerGlobals (kPhysicalLayerManager, (Ptr *) &glob, 0L) != noErr) {
		/* BRAIN DAMAGE: things are really bad if we get here */
		Debugger();
#if defined(THINKSUCKS) || defined(__MWERKS__)
		SetA5(oldGlob);
#endif
		return;
		}
#endif
		
	CHECKMAGIC(glob);
	glob->PHWriteActive = false;
	PUAsyncWriteFifoData();

#if defined(THINKSUCKS) || defined(__MWERKS__)
	SetA5(oldGlob);
#endif
}


