/*
 *	$Id: PModem.c,v 1.2 1995/05/10 11:04:13 jhsia Exp $
 *	
 *	$Log: PModem.c,v $
 * Revision 1.2  1995/05/10  11:04:13  jhsia
 * switch to cvs keywords
 *
 */

//#define DEBUG 1
#define ENABLE_FAST_DSP 1			/* enabled lower latency */

#ifdef DEBUG
#define BUFFERDATA
#endif

#ifdef __MWERKS__
#define __SERVER__ 1
#endif

#if defined (SIMULATOR) || defined(__SERVER__)
#define MESSAGES 1
#endif

#ifdef __SERVER__
#define SEGAOSIDLE
#else
#define SEGAOSIDLE SegaOSIdle( kNetworkCode );
#endif


/*
	File:		PModem.c

	Contains:	Modem Physical Layer, adapted from SegaSerial.c

	Written by:	Ted Cohn, Brian Topping, Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

	   <172>	 9/23/94	HEC		Fixed leased line mode and fast dsp mode not enabling due to
									thinkc bug.  Significantly reduces line noise retraining from
									scratch.
	   <171>	 9/16/94	HEC		Retrain modems on peer-to-peer too!
	   <170>	 9/12/94	HEC		Make compile on server.
	   <169>	 8/28/94	HEC		With Haixiang Liang's excellent suggestions, answer connect now
									delays two seconds after picking up hook before answer tones.
									Leased line is now a dbconstant.  Check the speed is 2400 for
									answer side before connect is positive.
	   <168>	 8/27/94	HEC		More use of gTicks for game dispatchable routines.  And, YES,
									DJ, it compiles on the server!
	   <167>	 8/26/94	DJ		fixed syntax error for compile on server (still won't compile
									though cuz no gTicks on server).
	   <166>	 8/26/94	BET		Fix multiple definitions of TMTask.
	   <165>	 8/26/94	HEC		BIG ONE: Made PUCheckLine on down callable through the game
									dispatcher.  Made call waiting min bong time a dbconstant.
	   <164>	 8/25/94	BET		Add call to SETNETSTATS
	   <163>	 8/25/94	HEC		Optional hangup parameter to PUCheckAnswer if no modem
									responded.
	   <162>	 8/25/94	HEC		Use new dtmf timing dbconstants.
	   <161>	 8/24/94	BET		Add kChatDebugFifoSize stuff to DBConstants, make DEBUGCHAT
									happen all the time, add some robustness to the script
									navigators.
	   <160>	 8/23/94	BET		update DEBUGCHAT shit
	   <159>	 8/23/94	HEC		PUCheckRing takes flag param
	   <158>	 8/22/94	BET		Change reserved30 to modemDebug to match globals.h change.
	   <157>	 8/22/94	ADS		More debug-shit globals
	   <156>	 8/22/94	HEC		Play phone ring sound FX in PUCheckRing. Check line stuff before
									carrier loss in PUCheckLine.
	   <155>	 8/21/94	ADS		New lomem layout
	   <154>	 8/21/94	HEC		Made timers dbconstants...
	   <153>	 8/20/94	BET		Grrr...
	   <152>	 8/20/94	BET		Fix fifo not getting emptied.  Hopefully this will fix the
									probs.
	   <151>	 8/20/94	BET		Up fifo size on DEBUGCHATSCRIPT stuff.
	   <150>	 8/20/94	BET		Add DEBUGCHATSCRIPT stuff.
	   <149>	 8/18/94	BET		Add jizz to print out stuff going across the line.
	   <148>	 8/17/94	BET		Fix bufferdata so it works with a single vector and always
									reference it so it isn't mistaken as unused.  Also speed up
									script connects.
	   <147>	 8/16/94	BET		Remove MACSERVER, make it work as macserver via script 0.
	   <146>	 8/16/94	BET		Make the last change a happy change.
	   <145>	 8/16/94	BET		PUDoSelectorLogin was returning an error when it shouldn't.
									Also propagate the error properly when it should.
	   <144>	 8/16/94	HEC		Listen to call waiting tone for a short period of time before
									declaring CW.
	   <143>	 8/16/94	SGP		Reconciled with Harddefines.a.
	   <142>	 8/15/94	BET		Add error increment on script errors.
	   <141>	 8/14/94	HEC		Added Handshake and Timeout errors to PListen to get more
									feedback for peer connect (and for robustness, of course).
	   <140>	 8/13/94	HEC		Corrected ReadEQM.
	   <139>	 8/13/94	HEC		Don't call PUSetError in PUCheckLine n down since game needs to
									call PUCheckLine too.  Don't turn on FastDSP for server connect!
	   <138>	 8/13/94	BET		Update PUDoSelectorLogin to peek the fifo while looking for
									strings
	   <137>	 8/12/94	BET		Add fucking SEGAOSIDLE.
	   <136>	 8/12/94	BET		Add fucking SEGAOSIDLE.
	   <135>	 8/12/94	BET		10 points!
	   <134>	 8/12/94	HEC		Turn on Leased Line mode for ALL connects to keep line active
									over bad noise. Increase DTMF duration from 50ms to 60ms.
	   <133>	 8/11/94	SAH		User BUFFERDATA rather than DEBUG for buffer debugging. Use
									special ram on the sega.
	   <132>	 8/11/94	DJ		jogglers
	   <131>	 8/11/94	DJ		ifdefed to use gTicks on stimulator, GetCurrentTime on mac
									server
	   <130>	 8/10/94	HEC		Lower TLVL to pass FCC.  Fixed order of delay before dtmf.
	   <129>	 8/10/94	BET		Added scriptID brokering changes.
	   <128>	 8/10/94	DJ		removed gTicks and using GetCurrentTime
	   <127>	 8/10/94	HEC		Faster PUCheckLine for Shannon. Fast static PUReadEQM.
	   <126>	 8/10/94	HEC		Always ride over call waiting bongs if user disabled it.
	   <125>	 8/10/94	BET		Move DEBUG fifo write higher up it's food chain so it works
									before parsing packets.
	   <124>	  8/9/94	HEC		More robust handling of no dialtone and bad handshake errors.
	   <123>	  8/9/94	BET		Teach script parser about wildcard strings and make it
									case-insensitive.
	   <122>	  8/9/94	HEC		Return kHandshakeErr on bad connects.
	   <121>	  8/8/94	HEC		Forgot to call PUCheckRing in PNetIdle.
	   <120>	  8/6/94	HEC		Added PUCheckRing. Decoupled ring detect from PUCheckAnswer so
									we can put up UI faster once ring is detected.
	   <119>	  8/5/94	HEC		Simulator keys for call waiting ("w") & carrier loss ("d").
									Also moved around checks for servertalk.
	   <118>	  8/4/94	HEC		Removed dead code. Fixed PListen in non serverTalk case.
	   <117>	  8/3/94	BET		Fix more steamers in connect scripts.
	   <116>	  8/3/94	HEC		Disable call waiting backoff for peer as well as server.  Made
									count before retry a dbconstant.
	   <115>	  8/3/94	HEC		Don't use scripts when calling peer.
	   <114>	  8/2/94	BET		Add more calling script fixes.
	   <113>	  8/2/94	HEC		Allow the physical layer to open without serverTalk. Defined
									kDisableServerTalk and added serverTalk global flag.
									PUCheckError now returns kConnectionEstablished if successful
									answer. All callers have been modified to accept this.
	   <112>	  8/2/94	BET		Fixed TearDownServerTalk to do the fifo clear check instead of
									PClose.  This fixes a problem in calling TearDownServerTalk and
									expecting that all the data has been sent.
	   <111>	  8/1/94	HEC		Removed protos for unused routines.
	   <110>	 7/31/94	DJ		semaphores turned off for __SERVER__ (no globals in server)
	   <109>	 7/31/94	HEC		Disable call waiting when listening too, i.e. just ignore call
									waiting tones.  Added semaphore for tearing down
									servertalk--prevents PNetIdle from running.
	   <108>	 7/30/94	HEC		PCheckError at top of PNetIdle.  Removed commented out dead code
									in PUSetupServerTalk().
	   <107>	 7/29/94	HEC		Commented out ENABLE_FAST_DSP --  peer-to-peer connects just
									aren't working.
	   <106>	 7/29/94	HEC		PUSetError instead of returning errors. Expanded data mode entry
									in PUDetectLineNoise. Reversed order of RLSD/noise check in
									PUCheckLine. PCheckError was always happening in PNetIdle. Now
									only call it for Frame & Overrun errors.
	   <105>	 7/29/94	BET		Remove PCheckError calls in P[Listen|Open][Async].  Add
									PCheckError call to PUOpenPort.  This should clean things up
									nicely.
	   <104>	 7/29/94	SAH		(HEC) Killed a bad LL1.
	   <103>	 7/29/94	HEC		Simplified carrier loss detection in PNetIdle.  Now part of
									PUCheckLine.  Fixed kUseServerProtocol bug.  Added
									PUCheckCarrier.  Renamed PUCheckLineNoise to PUCheckLine.
	   <102>	 7/28/94	HEC		(SAH) Tedward, Tedward, Tedward...
	   <101>	 7/28/94	HEC		Added fastDSPMode global switch for lowering peer-to-peer
									latency. This is controllable by the server.
	   <100>	 7/27/94	SAH		Flashy.
		<99>	 7/27/94	HEC		Added SEGAOSIDLE in some loops, and removed it from
									DetectLineNoise...
		<98>	 7/26/94	SAH		Use new restart semaphore in time mgr tasks.
		<97>	 7/26/94	HEC		PUTearDownServerTalk now checks for installation of time task
									before removing it.
		<96>	 7/25/94	HEC		Finally install PUIsNumberBusy selector. Return dialtone error
									based on flag setting to POpen.
		<95>	 7/25/94	DJ		ifdef out GetSegaString for server in PUMatch
		<94>	 7/25/94	BET		More the dummy read to before the read semaphore set in
									StartupServerTalk.  Previously, the dummy read was ignored
									because the time mgr proc already started up, came in and read
									the bad byte.
		<93>	 7/24/94	DJ		removed spintimeout code, cuz is not a field in globals anymore
		<92>	 7/23/94	BET		Add login scripting from DB items.  Rename NOSELECTOR to
									MACSERVER.  Comment out MACSERVER to do Sun connections along
									with setting correct phone number.
		<91>	 7/23/94	DJ		Add NOSELECTOR to build to work with Mac server until X.25 is up
									fully.
		<90>	 7/23/94	HEC		Some optimizations. Write directly to modem registers when
									resetting. Wait for ATV25 tone to end before continuing in
									POriginateAsync (recommended by Rockwell).
		<89>	 7/22/94	HEC		Check servertalk up before trying to close servertalk connection
									in PClose. If we have game trying to do PClose, we do not want
									to deal with servertalk. Set hangup-pickup delay to default
									after disabling call waiting.
		<88>	 7/22/94	BET		Add some assertions, fix a bug I added to the non-sun connect.
		<87>	 7/22/94	BET		Add code to dial into "800 service".  Still need to go through
									and add all the database entries for portal service prompts and
									timeouts.  Also need to add code to figure which service to ask
									for based on the number we are dialing (search on 800 prefix?).
									Everything else is there.
		<86>	 7/21/94	BET		Remove frame end mismatch check because it doesn't apply here
									any more.  Once upon a time, there was code just before the
									check to match up the read fifo with the frame end, this is now
									done by FifoAdjustConsumption and never fails.
		<85>	 7/18/94	DJ		ifdef thinkc around asm.h
		<84>	 7/17/94	HEC		Fixed my goobers.
		<83>	 7/17/94	HEC		Modified timing on disabling call waiting. Retry disabling call
									waiting after 10 calls when we fail to disable cw properly.
		<82>	 7/17/94	HEC		Managerized _PUAsyncReadDispatch for Andy.
		<81>	 7/16/94	HEC		Managerized, finally. Call waiting and noise checking are now in
									force.
		<80>	 7/15/94	HEC		Added disable call waiting function which is activated by a
									POpen kDisableCallWaiting flag.
		<79>	 7/15/94	HEC		Think I fixed the fucking hang problem with our modem chip by
									adding nop's to the end of each write.
		<78>	 7/15/94	SAH		Got so excited about all the dead code that I deleted
									everything. On to the next file......
		<77>	 7/14/94	BET		Add RLSD check to ReadSerialByte to try to fix fifo overflows
									when the modem loses connection.
		<76>	 7/14/94	HEC		(BET) Move consumption code to PUProcessIdle.
		<75>	 7/14/94	HEC		(BET) Re-add more non-dead code that was deleted in <70>. Thanks.
		<74>	 7/14/94	HEC		Add frame and overrun error detection in ROSKO version of
									PUReadSerialByte
		<73>	 7/13/94	BET		Re-add the non-dead code that was deleted in <67>. Thanks.
		<72>	 7/13/94	HEC		_PUReceiveBufferAvail
		<71>	 7/13/94	DJ		commented out #debug
		<70>	 7/12/94	DJ		commented out the optimization in PUProcessIdle for easier
									debugging of fifo underflow error.
		<69>	 7/11/94	SAH		Don't clear out the globals if there is an active connection
									during soft init.
		<68>	 7/11/94	HEC		Added PUCheckLineNoise and PUListenToLine to check call waiting,
									but is not enabled yet. Spin-loop timeouts work now -- get a
									user break when this happens.
		<67>	  7/9/94	HEC		Cleaned up and optimized a lot of shit.  Removed dead code.
									Added PIsNumberBusy.
		<66>	  7/9/94	BET		Fixed jizzled packet on originate by doing a PUReadSerialByte
									before returning that the port is open.  Added some currently
									unused synchronization code so it doesn't get lost.
		<65>	  7/7/94	HEC		Commented out latency reduction code in SetData to improve
									connections. Also always do Leased Line mode on server and peer.
		<64>	  7/7/94	DJ		fixed DelayTicks for server
		<63>	  7/7/94	HEC		Fixed bogus HangUp in PUOpenPort. Fixed premature return in
									HangUp.
		<62>	  7/7/94	DJ		made it work on server by ifdefing out the DB accesses for
									timeout constants
		<61>	  7/7/94	HEC		Delays now call SegaOSIdle. SegaOSIdle called in most loops.
									Removed GTE on listen -- not needed.
		<60>	  7/7/94	BET		Add error recording
		<59>	  7/6/94	BET		Add SegaOSIdle to PNetIdle.  This is at the bottom of any
									xNetIdle call, so it will be called.
		<58>	  7/6/94	BET		Had some constants wrong, also reverted bad merge in <56> for
									<Timer.h>.
		<57>	  7/6/94	BET		Added threshold adjustments for carrier sense.
		<56>	  7/6/94	HEC		Switched over to using new database constants.
		<55>	  7/6/94	BET		Remove sticky error checks from NetIdle procs, maybe some other
									jizz.
		<54>	  7/6/94	BET		Remove a debugger, fix a prob where the interrupt handler was
									clearing sticky errors and they were not getting propagated.
		<53>	  7/5/94	BET		Remove calls to clear line, need to do a handshake instead.
									Change DEBUG code to do the right thing after it was screwed up
									with new error code.  Also turned DEBUG on by default here until
									some later date.
		<52>	  7/5/94	BET		Move calls to HangUp to after setting connState
		<51>	  7/5/94	BET		Mo' sticky goo.
		<50>	  7/5/94	BET		Add sticky error routines and update PModem to use them.  Also
									clean up source a bit, get rid of most all calls to GetGlobals.
		<49>	  7/4/94	BET		Hang up the connection if we lose carrier.
		<48>	  7/3/94	DJ		cleaning up errors
		<47>	  7/3/94	HEC		Added protocol flag to PListen.
		<46>	  7/2/94	HEC		Added ResetModem workaround suggested by         Rockwell Tech
									Notes.
		<45>	  7/2/94	BET		Well, I see why.  Removed the interface and added macro
									directly.
		<44>	  7/2/94	BET		An interface and some comments got deleted in the last checkin.
		<43>	  7/2/94	HEC		Bring out dialtone and noanswer errors.          Add server flag
									to POpen and POpenAsync         to distinguish between server
									and peer communication. Removed noanswer global. Added server
									flag global.
		<42>	  7/1/94	SAH		Added debug stuff for Teddis.
		<41>	  7/1/94	BET		Remove OpenLevel and OpenState, they are already reflected in
									PHConnState.
		<40>	  7/1/94	DJ		made glob->PHOpenLevel = 0 in PListenAsync and POpenAsync.  also
									turned off #define DEADCODE
		<39>	  7/1/94	BET		Turn off leased line changes from <37>, they don't work when
									calling a server.
		<38>	  7/1/94	BET		Code review changes.
		<37>	 6/30/94	HEC		Added leased line mode to keep connection alive at all times.
									Reduced latency from 28ms to 21ms oneway. Fixed some stupid
									error propagation bugs.
		<36>	 6/28/94	DJ		made CheckAnswer set the PHLastError
		<35>	 6/28/94	DJ		changed a printf.  big friggin deal
		<34>	 6/28/94	DJ		fixed GetCurrentTime for real
		<33>	 6/28/94	DJ		made GetCurrentTime work for StinkC
		<32>	 6/28/94	SAH		Revamped includes for new globals stuff.
		<31>	 6/28/94	BET		Be a little more conservative with the size we expect we can
									stuff in the fifo.
		<30>	 6/22/94	BET		Reroll 26 until we can look at it some more.
		<29>	 6/22/94	BET		Move CallbackSemaphore outside of ifdef's; it was fucking up
									server build.
		<28>	 6/22/94	SAH		(HEC) Learning to compile before checking in...
		<27>	 6/22/94	SAH		(HEC) Fixed previous fucked up checkin.
		<26>	 6/21/94	HEC		Added SetData() function which sets up reduced 11.5 ms delay for
									modem.
		<25>	 6/21/94	BET		Add PUReceiveBufferAvail.
		<24>	 6/21/94	BET		Check in those files!  This finally gets the modem running again
									on Fred2.
		<23>	 6/20/94	BET		Add PUSetupServerTalk and PUTearDownServerTalk for Dave.
		<22>	 6/20/94	DJ		fixed a return value in POpen (well, in something that it calls
									somewhere)
		<21>	 6/20/94	HEC		First working with Fred2
		<20>	 6/20/94	BET		Fix POpenState not keeping state.
		<19>	 6/20/94	BET		Add kConnectBusy return.
		<18>	 6/20/94	BET		Add some async infastructure.
		<17>	 6/20/94	BET		Change unreliable assembly back to C
		<16>	 6/20/94	HEC		Mods to work on Fred2 board.
		<15>	 6/19/94	BET		Change to new Fifo world.
		<14>	 6/18/94	BET		Restore Ted's state information to NetParamBlock.
		<13>	 6/18/94	BET		Restore Ted's TimeIdle removal.
		<12>	 6/18/94	BET		Works with server & simulator now.
		<11>	 6/17/94	HEC		Fixing modem noise.
		<10>	 6/17/94	BET		Checkin with fixes
		 <9>	 6/17/94	BET		It works again.  Archive this version
		 <8>	 6/16/94	BET		Revert Ted's changes.
		 <7>	 6/15/94	HEC		(BET) Checking in, not sure if it is ready though.
		 <6>	 6/14/94	HEC		More reliable connection.
		 <5>	 6/14/94	HEC		Reliable redial and listening works now.
		 <3>	 6/12/94	HEC		Connection with Server works!
		 <2>	 6/11/94	HEC		Switched to including "PModemPriv.h"
		 <1>	 6/10/94	HEC		first checked in
	
	Change History (from SegaSerial.c):
		<14>	  6/9/94	BET		Bad packets would cause everything to go crazy.  This is a fix
									to the dispatcher to do the right thing
		<13>	  6/5/94	BET		Change interfaces to TOpen and TListen
		<11>	  6/4/94	BET		Remove DebugStrs (it's late).
		<10>	  6/4/94	BET		Fix more FUD
		 <9>	  6/3/94	SAH		Reference checkin
		 <8>	  6/3/94	BET		Add more FUD
		 <7>	  6/2/94	SAH		(Really BET) First round serial debugging -- IT WORKS!
		 <6>	  6/1/94	BET		Fix some late arrivals
		 <5>	  6/1/94	BET		Major rewrite, take the latest from CMPhysical.c
		 <4>	 5/31/94	SAH		Updated to latest interfaces.
		 <3>	 5/27/94	SAH		Commented out a bunch of stuff that was crashing the sega build.
		 <2>	 5/26/94	SAH		Fleshed out some.
	
	To Do:
		�	Be sure that we have enough stats.  Specifically, there is no recording of total
			bytes, total packets.  Do we want this?
*/


#ifdef THINK_C
#include "asm.h"
#endif

#include "SegaOS.h"
#include "globals.h"
#include "osglobals.h"
#include "heaps.h"
#include "Errors.h"
#include "PhysicalLayer.h"
#include "utils.h"
#include "PhysicalStructs.h"
#include "PModemPriv.h"
#include "TransportLayer.h"
#include "Fifo.h"
#include "ccitt.h"
#include "heaps.h"
#include "SegaOS.h"
#include "SegaText.h"
#include "NetErrors.h"
#include "NetMisc.h"
#include "HardDefines.h"
#include "Database.h"
#include "DBTypes.h"
#include "DBConstants.h"
#include "BoxSer.h"
#include "StringDB.h"
#include "Exceptions.h"
#include "SegaSound.h"
#include "GamePatch.h"

#ifndef OFFSET
#define OFFSET(type, field)		((int) &((type *) 0)->field)
#endif

#if !defined(SIMULATOR) && !defined(__SERVER__)
#define ROSKO
#endif

#ifndef __SERVER__
#include "Time.h"
#else
#include <Stdio.h>
#include <OSUtils.h>
#endif

#ifdef SIMULATOR
#include <Timer.h>
#include <Stdio.h>
#include <Events.h>
#endif

#ifdef __SERVER__

#ifdef THINK_C
#define gTicks TickCount()
#define GetCurrentTime() TickCount()
#else
#define gTicks LMGetTicks()
#define GetCurrentTime() LMGetTicks()
#define TimerProcPtr TimerUPP
#endif

#endif

#ifdef __SERVER__
#define OSDetectLineNoise()		PUDetectLineNoise()
#define OSDelayTicks(a,b)		DelayTicks(a,b)
#define OSCheckCarrier()		PUCheckCarrier()
#define OSListenToLine()		PUListenToLine()
#define OSReadXRAM(a,b)			PUReadXRAM(a,b)
#define OSReadYRAM(a,b)			PUReadYRAM(a,b)
#define OSWriteXRAM(a,b,c)		PUWriteXRAM(a,b,c)
#define OSWriteYRAM(a,b,c)		PUWriteYRAM(a,b,c)
#define OSSetTimerTicks(a,b)	PUSetTimerTicks(a,b)
#define OSTimerExpired(a)		PUTimerExpired(a)
#define OSToneMode()			PUToneMode()
#endif

#ifdef THINK_C
#define THINKSUCKS
#endif

// extern protos
OSErr	_PInit(void);
OSErr	_POpen(char *config, unsigned long flags);
OSErr	_PListen(char *config, long flags);
OSErr	_POpenAsync(char *config, long flags);
OSErr	_PListenAsync(char *config, long flags);
OSErr	_PClose(void);
OSErr	_PNetIdle(NetParamBlock *pBlock);
OSErr	_PWritePacketSync(WDS *sendBuffer);
OSErr	_PWritePacketASync(WDS *sendBuffer);
OSErr	_PUOpenPort(Boolean listen, char *config);
void	_PUClosePort(void);
OSErr	_PUProcessIdle(void);
short	_PUProcessSTIdle(unsigned short length);
Boolean _PUSetupServerTalk(void);
Boolean _PUTearDownServerTalk(void);
OSErr	_PUSetError(OSErr err);
OSErr	_PCheckError(void);
OSErr 	_PGetError(void);
OSErr	_PClearPhysLine(void);
Boolean	_PUIsNumberBusy(char *);
short	_PUReceiveBufferAvail(void);
OSErr	_PUOriginateAsync(char *config, long flags);
Boolean	_PUAnstondet(short timer);
Boolean	_PUWaitForRLSD(short timer);
void	_PUInitCallProgress(void);
short	_PUCallProgress(void);
OSErr	_PUDialNumber( char *number );
OSErr	_PUWaitDialTone(short timer, Boolean continuous);
OSErr	_PUAnswerAsync(char *config);
OSErr	_PUCheckAnswer(Boolean hangupOnNoAnswer);
OSErr	_PUResetModem(void);
void	_PUSetTimerTicks(short t, short ticks);
void	_PUSetTimerSecs(short t, short seconds);
short	_PUTimerExpired(short t);
OSErr	_PUHangUp(void);
void	_PUPickUp(short delay);
void	_PUWriteXRAM(long addr, long xcr, long val);
void	_PUWriteYRAM(long addr, long ycr, long val);
long	_PUReadXRAM(long addr, long xcr);
long	_PUReadYRAM(long addr, long ycr);
void	_PUIdleMode(void);
void	_PUDataMode(void);
void	_PUDialMode(void);
void	_PUToneMode(void);
Boolean	_PUIsNumberBusy(char *num);
OSErr	_PUCheckLine(void);
OSErr	_PUCheckCarrier(void);
OSErr	_PUDetectLineNoise(void);
short	_PUListenToLine(void);
short	_PUDisableCallWaiting(void);
void	_PUAsyncReadDispatch(PGlobalType * glob, unsigned char prevChar);
OSErr 	_PUMatchString(ServicePair *sp, unsigned long endTime);
Boolean _PUCheckRing( short playsnd );

#if defined(SIMULATOR) || defined(__SERVER__)
static pascal void _PUReadTimeProc(void);
static pascal void _PUWriteTimeProc(void);
#endif

PGlobalType PGlobals;

#ifdef __SERVER__
	#define	GetGlobals()	&PGlobals
#else
	#define	GetGlobals()	((PGlobalType *) &REFGLOBAL(PGlobals,PHReadyBuffer))
#endif

#ifndef __SERVER__

long
_PhysicalLayerControl ( short command, long data )
{
PGlobalType		*globals;
long			offset;
short			error;
short			count;

	error = commandSelectorUnknown;

	switch ( command )
		{
		case kHardInitialize:
		
			/* allocate and initialize our globals */
			GETMGRGLOBALSOFFSET(PGlobals,offset);
			error = AllocateGlobalSpace (kPhysicalLayerManager, offset, sizeof(PGlobalType), (Ptr *) &globals);
			if (error != noErr)
				{
				return error;
				}
			
			// clear globals on hard init
			for (count = sizeof(PGlobalType)-1; count >= 0; count--)
				((char *)globals)[count] = 0;

			/* install our selectors */
			SetDispatchedFunction (kPInit,					kPhysicalLayerManager,	_PInit);
			SetDispatchedFunction (kPOpen,					kPhysicalLayerManager,	_POpen);
			SetDispatchedFunction (kPListen,				kPhysicalLayerManager,	_PListen);
			SetDispatchedFunction (kPOpenAsync,				kPhysicalLayerManager,	_POpenAsync);
			SetDispatchedFunction (kPListenAsync,			kPhysicalLayerManager,	_PListenAsync);
			SetDispatchedFunction (kPListen,				kPhysicalLayerManager,	_PListen);
			SetDispatchedFunction (kPClose,					kPhysicalLayerManager,	_PClose);
			SetDispatchedFunction (kPNetIdle,				kPhysicalLayerManager,	_PNetIdle);
			SetDispatchedFunction (kPWritePacketSync,		kPhysicalLayerManager,	_PWritePacketSync);
			SetDispatchedFunction (kPWritePacketASync,		kPhysicalLayerManager,	_PWritePacketASync);
			SetDispatchedFunction (kPUOpenPort,				kPhysicalLayerManager,	_PUOpenPort);
			SetDispatchedFunction (kPUClosePort,			kPhysicalLayerManager,	_PUClosePort);
			SetDispatchedFunction (kPUProcessIdle,			kPhysicalLayerManager,	_PUProcessIdle);
			SetDispatchedFunction (kPUProcessSTIdle,		kPhysicalLayerManager,	_PUProcessSTIdle);
			SetDispatchedFunction (kPUReadSerialByte,		kPhysicalLayerManager,	_PUReadSerialByte);
			SetDispatchedFunction (kPUWriteSerialByte,		kPhysicalLayerManager,	_PUWriteSerialByte);
			SetDispatchedFunction (kPUTransmitBufferFree,	kPhysicalLayerManager,	_PUTransmitBufferFree);
			SetDispatchedFunction (kPUReceiveBufferAvail,	kPhysicalLayerManager,	_PUReceiveBufferAvail);
			SetDispatchedFunction (kPUTestForConnection,	kPhysicalLayerManager,	_PUTestForConnection);
			SetDispatchedFunction (kPUReadTimeCallback,		kPhysicalLayerManager,	_PUReadTimeCallback);
			SetDispatchedFunction (kPUWriteTimeCallback,	kPhysicalLayerManager,	_PUWriteTimeCallback);
			SetDispatchedFunction (kPUSetupServerTalk,		kPhysicalLayerManager,	_PUSetupServerTalk);
			SetDispatchedFunction (kPUTearDownServerTalk,	kPhysicalLayerManager,	_PUTearDownServerTalk);
			SetDispatchedFunction (kPUSetError,				kPhysicalLayerManager,	_PUSetError);
			SetDispatchedFunction (kPGetError,				kPhysicalLayerManager,	_PGetError);
			SetDispatchedFunction (kPCheckError,			kPhysicalLayerManager,	_PCheckError);
			SetDispatchedFunction (kPUOriginateAsync,		kPhysicalLayerManager,	_PUOriginateAsync);
			SetDispatchedFunction (kPUAnstondet,			kPhysicalLayerManager,	_PUAnstondet);
			SetDispatchedFunction (kPUWaitForRLSD,			kPhysicalLayerManager,	_PUWaitForRLSD);
			SetDispatchedFunction (kPUInitCallProgress,		kPhysicalLayerManager,	_PUInitCallProgress);
			SetDispatchedFunction (kPUCallProgress,			kPhysicalLayerManager,	_PUCallProgress);
			SetDispatchedFunction (kPUDialNumber,			kPhysicalLayerManager,	_PUDialNumber);
			SetDispatchedFunction (kPUWaitDialTone,			kPhysicalLayerManager,	_PUWaitDialTone);
			SetDispatchedFunction (kPUAnswerAsync,			kPhysicalLayerManager,	_PUAnswerAsync);
			SetDispatchedFunction (kPUCheckAnswer,			kPhysicalLayerManager,	_PUCheckAnswer);
			SetDispatchedFunction (kPUResetModem,			kPhysicalLayerManager,	_PUResetModem);
			SetDispatchedFunction (kPUSetTimerTicks,		kPhysicalLayerManager,	_PUSetTimerTicks);
			SetDispatchedFunction (kPUSetTimerSecs,			kPhysicalLayerManager,	_PUSetTimerSecs);
			SetDispatchedFunction (kPUTimerExpired,			kPhysicalLayerManager,	_PUTimerExpired);
			SetDispatchedFunction (kPUHangUp,				kPhysicalLayerManager,	_PUHangUp);
			SetDispatchedFunction (kPUPickUp,				kPhysicalLayerManager,	_PUPickUp);
			SetDispatchedFunction (kPUWriteXRAM,			kPhysicalLayerManager,	_PUWriteXRAM);
			SetDispatchedFunction (kPUWriteYRAM,			kPhysicalLayerManager,	_PUWriteYRAM);
			SetDispatchedFunction (kPUReadXRAM,				kPhysicalLayerManager,	_PUReadXRAM);
			SetDispatchedFunction (kPUReadYRAM,				kPhysicalLayerManager,	_PUReadYRAM);
			SetDispatchedFunction (kPUIdleMode,				kPhysicalLayerManager,	_PUIdleMode);
			SetDispatchedFunction (kPUDataMode,				kPhysicalLayerManager,	_PUDataMode);
			SetDispatchedFunction (kPUDialMode,				kPhysicalLayerManager,	_PUDialMode);
			SetDispatchedFunction (kPUToneMode,				kPhysicalLayerManager,	_PUToneMode);
			SetDispatchedFunction (kPUCheckLine,			kPhysicalLayerManager,	_PUCheckLine);
			SetDispatchedFunction (kPUCheckCarrier,			kPhysicalLayerManager,	_PUCheckCarrier);
			SetDispatchedFunction (kPUDetectLineNoise,		kPhysicalLayerManager,	_PUDetectLineNoise);
			SetDispatchedFunction (kPUListenToLine,			kPhysicalLayerManager,	_PUListenToLine);
			SetDispatchedFunction (kPUDisableCallWaiting,	kPhysicalLayerManager,	_PUDisableCallWaiting);
			SetDispatchedFunction (kPUAsyncReadDispatch,	kPhysicalLayerManager,	_PUAsyncReadDispatch);
			SetDispatchedFunction (kPUDoSelectorLogin,		kPhysicalLayerManager,	_PUDoSelectorLogin);
			SetDispatchedFunction (kPUMatchString,			kPhysicalLayerManager,	_PUMatchString);
			SetDispatchedFunction (kPUIsNumberBusy,			kPhysicalLayerManager,	_PUIsNumberBusy);
			SetDispatchedFunction (kPUCheckRing,			kPhysicalLayerManager,	_PUCheckRing);
			SetDispatchedFunction (kPGetDebugChatScript,	kPhysicalLayerManager,	_PGetDebugChatScript);
			
			break;
		
		case kSoftInialize:
			error = noErr;
			break;
		
		case kHardClose:
			error = noErr;
			break;
		
		case kSoftClose:
			error = noErr;
			break;
					
		case kCodeBlockMoved:
			error = noErr;
			break;
					
		case kGlobalsMoved:
			error = noErr;
			break;
		}
		
	return error;
}

#endif

#ifdef __SERVER__
void DelayTicks(long a, short b);
void DelayTicks(long a, short b)
{
long endTicks;

	endTicks = GetCurrentTime()+a;
	while (GetCurrentTime() < endTicks) ;
}

#define DelayMS(a,b) DelayTicks(a/16667+1, kNetworkCode)
#endif

////////////////////////////////////////////////////////////////////////////////////////////
// should only be called once at box powerup!
////////////////////////////////////////////////////////////////////////////////////////////

OSErr _PInit(void)
{
short			count;
OSErr			err;
long			temp;
Fifo			**fifoP;

	// subtract 1 so disableCWcount is not cleared
	for (count = sizeof(PGlobalType)-2; count >= 0; count--)
		((char *)&PGlobals)[count] = 0;
	
	REFGLOBAL(PGlobals,PHMagic) = kMagicVal;
	REFGLOBAL(PGlobals,PHCharMask) = 0xff;
	SETNETSTATS(gNetStats800);
	
#ifdef __SERVER__
	REFGLOBAL(PGlobals,PHLengthsBuf) = (unsigned char *)NewPtr(kFrameStartBufSiz);
	REFGLOBAL(PGlobals,PHReadDataBuf) = (unsigned char *)NewPtr(kPhysBufferSize);
	REFGLOBAL(PGlobals,PHWriteDataBuf) = (unsigned char *)NewPtr(kPhysBufferSize);
	REFGLOBAL(PGlobals,PHStagingBuf) = (unsigned char *)NewPtr(kMaxPacket);

	REFGLOBAL(PGlobals,rb).ringOnTimeMin = kRingOnTimeMin;
	REFGLOBAL(PGlobals,rb).ringOnTimeMax = kRingOnTimeMax;
	REFGLOBAL(PGlobals,rb).ringOffTimeMin = kRingOffTimeMin;
	REFGLOBAL(PGlobals,rb).ringOffTimeMax = kRingOffTimeMax;
	REFGLOBAL(PGlobals,rb).busyOnTimeMin = kBusyOnTimeMin;
	REFGLOBAL(PGlobals,rb).busyOnTimeMax = kBusyOnTimeMax;
	REFGLOBAL(PGlobals,rb).busyOffTimeMin = kBusyOffTimeMin;
	REFGLOBAL(PGlobals,rb).busyOffTimeMax = kBusyOffTimeMax;
	REFGLOBAL(PGlobals,rb).BongListenTimeout = kBongListenTimeout;
	REFGLOBAL(PGlobals,rb).EQMThreshold = kEQMThreshold;
	REFGLOBAL(PGlobals,rb).EQMPeriod = kEQMPeriod;
	REFGLOBAL(PGlobals,rb).PreCWNoNoisePeriod = kPreCWNoNoisePeriod;
	REFGLOBAL(PGlobals,rb).CWDTMFPeriod = kCWDTMFPeriod;
	REFGLOBAL(PGlobals,rb).CWReceiveDTMFValue = kCWReceiveDTMFValue;
	REFGLOBAL(PGlobals,rb).CWSendDTMFValue = kCWSendDTMFValue;
	REFGLOBAL(PGlobals,rb).LostRLSDPeriod = kLostRLSDPeriod;
	REFGLOBAL(PGlobals,rb).RetrainExpiration = kRetrainExpiration;
	REFGLOBAL(PGlobals,rb).listenCWLoops = kListenCallWaitingTime;
#else
	// set up buffers
	REFGLOBAL(PGlobals,PHLengthsBuf) = NewMemory(kTemp,kFrameStartBufSiz);
	ASSERT(REFGLOBAL(PGlobals,PHLengthsBuf));
	REFGLOBAL(PGlobals,PHReadDataBuf) = NewMemory(kTemp,kPhysBufferSize);
	ASSERT(REFGLOBAL(PGlobals,PHReadDataBuf));
	REFGLOBAL(PGlobals,PHWriteDataBuf) = NewMemory(kTemp,kPhysBufferSize);
	ASSERT(REFGLOBAL(PGlobals,PHWriteDataBuf));
	REFGLOBAL(PGlobals,PHStagingBuf) = NewMemory(kTemp,kMaxPacket);
	ASSERT(REFGLOBAL(PGlobals,PHStagingBuf));

	REFGLOBAL(PGlobals,hangupTime) = GetCurrentTime();

	DBGetConstant(kRetrainExpirationConst,&temp);
	REFGLOBAL(PGlobals,rb).RetrainExpiration = temp;
	
	DBGetConstant(kLostRLSDPeriodConst,&temp);
	REFGLOBAL(PGlobals,rb).LostRLSDPeriod = temp;
	
	DBGetConstant(kDBRingOnTimeMinConst,&temp);
	REFGLOBAL(PGlobals,rb).ringOnTimeMin = temp;
	
	DBGetConstant(kDBRingOnTimeMaxConst,&temp);
	REFGLOBAL(PGlobals,rb).ringOnTimeMax = temp;
	
	DBGetConstant(kDBRingOffTimeMinConst,&temp);
	REFGLOBAL(PGlobals,rb).ringOffTimeMin = temp;
	
	DBGetConstant(kDBRingOffTimeMaxConst,&temp);
	REFGLOBAL(PGlobals,rb).ringOffTimeMax = temp;
	
	DBGetConstant(kDBBusyOnTimeMinConst,&temp);
	REFGLOBAL(PGlobals,rb).busyOnTimeMin = temp;
	
	DBGetConstant(kDBBusyOnTimeMaxConst,&temp);
	REFGLOBAL(PGlobals,rb).busyOnTimeMax = temp;
	
	DBGetConstant(kDBBusyOffTimeMinConst,&temp);
	REFGLOBAL(PGlobals,rb).busyOffTimeMin = temp;
	
	DBGetConstant(kDBBusyOffTimeMaxConst,&temp);
	REFGLOBAL(PGlobals,rb).busyOffTimeMax = temp;
	
	DBGetConstant(kBongListenTimeoutConst,&temp);
	REFGLOBAL(PGlobals,rb).BongListenTimeout = temp;

	DBGetConstant(kEQMThresholdConst,&temp);
	REFGLOBAL(PGlobals,rb).EQMThreshold = temp;

	DBGetConstant(kEQMPeriodConst,&temp);
	REFGLOBAL(PGlobals,rb).EQMPeriod = temp;

	DBGetConstant(kPreCWNoNoisePeriodConst,&temp);
	REFGLOBAL(PGlobals,rb).PreCWNoNoisePeriod = temp;

	DBGetConstant(kCWDTMFPeriodConst,&temp);
	REFGLOBAL(PGlobals,rb).CWDTMFPeriod = temp;

	DBGetConstant(kCWReceiveDTMFValueConst,&temp);
	REFGLOBAL(PGlobals,rb).CWReceiveDTMFValue = temp;

	DBGetConstant(kCWSendDTMFValueConst,&temp);
	REFGLOBAL(PGlobals,rb).CWSendDTMFValue = temp;

	DBGetConstant(kListenCallWaitingTimeConst,&temp );
	REFGLOBAL(PGlobals,rb).listenCWLoops = temp;

	DBGetConstant(kChatDebugFifoConst,&temp);
	REFGLOBAL(PGlobals,chatDebugFifoSize) = temp;
#endif

#ifdef BUFFERDATA
	// test code
	fifoP = (Fifo **)NewMemory(kTemp, 8);
	*((long **)OFFSET(SegaLowMem,modemDebug)) = (long *)fifoP;
	
#ifdef SIMULATOR
	FifoInit(&REFGLOBAL(PGlobals,testRead), (unsigned char *)NewPtrClear(10000), 10000, kCircularQ);
	fifoP[0] = &REFGLOBAL(PGlobals,testRead);
	
	FifoInit(&REFGLOBAL(PGlobals,testWrite), (unsigned char *)NewPtrClear(10000), 10000, kCircularQ);
	fifoP[1] = &REFGLOBAL(PGlobals,testWrite);

#else
	FifoInit(&REFGLOBAL(PGlobals,testRead), (unsigned char *)0xf000, 0x800, kCircularQ);
	fifoP[0] = &REFGLOBAL(PGlobals,testRead);
	
	FifoInit(&REFGLOBAL(PGlobals,testWrite), (unsigned char *)0xf800, 0x800, kCircularQ);
	fifoP[1] = &REFGLOBAL(PGlobals,testWrite);
#endif
#else
	*((long *)OFFSET(SegaLowMem,modemDebug)) = 0;
#endif

	FifoInit(&REFGLOBAL(PGlobals,PHScrDebugFifo), (unsigned char *)NewMemory(kTemp, REFGLOBAL(PGlobals,chatDebugFifoSize)), REFGLOBAL(PGlobals,chatDebugFifoSize), kCircularQ);

	PUSetError(noErr);

#ifndef ROSKO
	REFGLOBAL(PGlobals,modemPtr) = (ModemPtr)kModemBaseAddress;
#endif
	return PUHangUp();
}

// phone number in config. server set true when calling server, else false for peer-to-peer 
OSErr _POpen(char *config, unsigned long flags)
{
OSErr			err;

	err = noErr;
	MESG("POpen");
	
	err = POpenAsync(config, flags);
	if (err)
		return err;
	
	do	{
		if (PNetIdle(nil) < 0)
			break;
		}
	while (REFGLOBAL(PGlobals,PHConnState) == kConnOpening);

	if (REFGLOBAL(PGlobals,PHConnState) == kConnOpen) {
		if ((REFGLOBAL(PGlobals,server)) && GETCONNECTSCRIPT(flags)) {
			err = PUDoSelectorLogin((ServiceScript *)DBGetItem(kConnectSequenceType, GETCONNECTSCRIPT(flags)));
			if (!err) {
				REFGLOBAL(PGlobals,PHPacketParseActive) = true;
				REFGLOBAL(PGlobals,PHFrameSizAccum) = 0;
				}
			else {
				INCRCOMMERROR(scriptLoginError, 1);
				PUClosePort();
				PUHangUp();
				}
			}
		else {	
			REFGLOBAL(PGlobals,PHPacketParseActive) = true;
			}
			
		return err;
		}
	else
		return PGetError();
}

#define DEBUGTIME 0
OSErr _PUDoSelectorLogin(ServiceScript *service)
{
#define			kStrBufSiz 30
unsigned char	buf[kStrBufSiz], holdMask;
OSErr			err;
short			count, total;
Boolean			retried;
unsigned long	timeout;
	
	MESG("PUDoSelectorLogin begin");
	timeout = GetCurrentTime() + service->totalTimeout + DEBUGTIME;
	total = service->pairCount;
	if (service->dataMask) {
		holdMask = REFGLOBAL(PGlobals,PHCharMask);
		REFGLOBAL(PGlobals,PHCharMask) = service->dataMask;
		}
	else
		holdMask = 0;
		
	retried = false;
	count = 0;
	while ((timeout > GetCurrentTime()) && (count < total)) {
		err = PUMatchString(&service->pair[count], timeout);
		if (err) {	
			if (!retried) {
				retried = true;
				if (count)
					count -= 1;
				continue;
				}
			else
				goto fail;
			}
		else
			retried = false;
			
		count += 1;
		}
		
fail:
	MESG("PUDoSelectorLogin exiting");
	if (holdMask)
		REFGLOBAL(PGlobals,PHCharMask) = holdMask;
		
	if (err)
		return PUSetError(err);
	
	if (count < total)
		return PUSetError(kScriptTimeoutErr);
	else
		return noErr;
}

// search for str at the end of output, if can't find it send poke until
// it is found or timeoutTicks is spent looking
OSErr _PUMatchString(ServicePair *sp, unsigned long endTime)
{

#ifdef __SERVER__
	return(noErr);
#else

#define			kMaxStrBufSiz 30
unsigned char	buf[kStrBufSiz];
unsigned long	avail, lastAvail, time, end;
OSErr			err;
unsigned short	strlen, count;
char			*workStr;
Boolean			found;
char			*nm;

	workStr = GetSegaString(sp->sendString);
	strlen = GetStringLength(workStr);
	found = false;
	
	count = sp->repeatCount;
	lastAvail = avail = 0;
	while ((count-- > 0) && !found) {
		if (sp->poke) {
		
			#ifdef SIMULATOR
			printf("poked: %x\n", sp->poke);
			#endif
			FifoWrite(&REFGLOBAL(PGlobals,PHScrDebugFifo), (unsigned char *)&sp->poke, 1);
			
			err = FifoWrite(&REFGLOBAL(PGlobals,PHWriteFifo), &sp->poke, 1);
			if (err) return PUSetError(err);
			time = GetCurrentTime() + sp->timeToWait + DEBUGTIME;
			}
			
		time = GetCurrentTime() + sp->timeToWait + DEBUGTIME;
		while (time > GetCurrentTime()) {
			SEGAOSIDLE;
			if (endTime < GetCurrentTime())
				return PUSetError(kScriptTimeoutErr);
				
			avail = FifoAvailable(&REFGLOBAL(PGlobals,PHReadFifo));
			if (lastAvail != avail) {
				lastAvail = avail;
				time = GetCurrentTime() + sp->timeToWait + DEBUGTIME;
				}
			else if (*(short *)workStr != 0x2a00) {
				err = FifoPeekEnd(&REFGLOBAL(PGlobals,PHReadFifo), buf, strlen);
				if (!err) {
					buf[strlen] = 0;
					if (!CompareStrings((char *)buf, workStr)) {
						found = true;
						break;
						}
					}
				}
			}
		// if we get a wildcard, we always found what we are looking 
		// for unless there is nothing there!
		if (((*(short *)workStr == 0x2a00) && avail) || (!*workStr)) {
			found = true;
			}
		}

	// eat all the text to here
	avail = FifoAvailable(&REFGLOBAL(PGlobals,PHReadFifo));
	
	nm = NewMemory(kTemp, avail+1);
	FifoPeek(&REFGLOBAL(PGlobals,PHReadFifo), (unsigned char *)nm, (unsigned long)avail);
	nm[avail] = 0;
	MESG(nm);
	FifoWrite(&REFGLOBAL(PGlobals,PHScrDebugFifo), (unsigned char *)nm, (unsigned long)avail);
	DisposeMemory(nm);
	
	err = FifoSkip(&REFGLOBAL(PGlobals,PHReadFifo), avail);
	if (err) return PUSetError(err);

	if (!found)
		return PUSetError(kScriptTimeoutErr);
	else if (sp->replyString) {
		workStr = GetSegaString(sp->replyString);
		strlen = GetStringLength(workStr);
		MESG(workStr);
		err = FifoWrite(&REFGLOBAL(PGlobals,PHWriteFifo), (unsigned char *)workStr, strlen);
		if (err) return PUSetError(err);
		
		if (!(sp->flags & kHalfDuplex)) {	
			while (FifoAvailable(&REFGLOBAL(PGlobals,PHReadFifo)) < strlen) {
				SEGAOSIDLE;
				if (endTime < GetCurrentTime())
					return PUSetError(kScriptTimeoutErr);
				}
			err = FifoSkip(&REFGLOBAL(PGlobals,PHReadFifo), strlen);
			if (err) return PUSetError(err);
			}
			
		FifoWrite(&REFGLOBAL(PGlobals,PHScrDebugFifo), (unsigned char *)workStr, strlen);
		
		#ifdef SIMULATOR
		printf("wrote: %s\n", workStr);
		#endif
		}
	
	return noErr;

#endif __SERVER__
}

// wait for peer to call us
OSErr _PListen(char *config, long flags)
{
OSErr			err;

	MESG("PListen");
	
	err = PListenAsync(config, flags);
	if (err)
		return err;
	
	if (REFGLOBAL(PGlobals,serverTalk))
	{
		do	{
			if (PNetIdle(nil) < 0)
				break;
			}
		while (REFGLOBAL(PGlobals,PHConnState) == kConnListening);
		if (REFGLOBAL(PGlobals,PHConnState) == kConnOpen)
			return noErr;
		else
			return PGetError();
	}
	else
	{
		while ( PUCheckRing( true ) == false )
			SEGAOSIDLE;
		err = PUCheckAnswer(true);
		return err;
	}
}

OSErr _POpenAsync(char *config, long flags)
{
OSErr			err;

	MESG("POpenAsync");

	REFGLOBAL(PGlobals,server) = !(flags & kUsePeerProtocol);
	REFGLOBAL(PGlobals,serverTalk) = !(flags & kDisableServerTalk);

	err = PUOpenPort(kOriginate, config);
	if (err)
		return err;
		
	return PUOriginateAsync(config, flags);
}

// wait for peer to call us
OSErr _PListenAsync(char *config, long flags)
{
OSErr			err;

	MESG("PListenAsync");

	REFGLOBAL(PGlobals,server) = !(flags & kUsePeerProtocol);
	REFGLOBAL(PGlobals,serverTalk) = !(flags & kDisableServerTalk);

	if (flags & kDisableCallWaiting)
	{
		// If there user wishes to disable call waiting, the best we can
		// do when listening is to simply ignore any call waiting tones.
		REFGLOBAL(PGlobals,disableCW) = 1;
	}
	err = PUOpenPort(kListen, config);
	if (err)
		return err;
		
	return PUAnswerAsync(config);
}

// DO NOT CALL PCLOSE DURING GAME PLAY! (WE NEED TO CALL DBGETCONSTANT)
OSErr _PClose(void)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h
OSErr			err;

	MESG("_PClose");

	if (REFGLOBAL(PGlobals,PHConnState) != kConnClosed) {
		if (REFGLOBAL(PGlobals,PHCallbackSema)) {
			PUClosePort();
		}
		REFGLOBAL(PGlobals,PHConnState) = kConnClosed;
	}
	err = PUHangUp();
	return err;
}


// NetIdle -- returns negative gen purpose error code on failure.
short _PNetIdle( NetParamBlock *pBlock )
{
MODEMPTR;
OSErr			err;
	
	// prevent PNetIdle from running if serverTalk has been disabled.
	if (!REFGLOBAL(PGlobals,serverTalk))
		return noErr;

	SEGAOSIDLE;

	PCheckError();
	if (pBlock) {
		// fill in some fields
		pBlock->ioPhysNetState = kConnClosed; 
		pBlock->ioLastPhysicalError = noErr;
		pBlock->ioAvailable = 0;
		pBlock->ioTotal = REFGLOBAL(PGlobals,PHTotal);
		}
		
	if (REFGLOBAL(PGlobals,PHConnState) != kConnClosed)
	{
		if (REFGLOBAL(PGlobals,PHConnState) == kConnOpen)
		{
			// Check for call waiting, remote call waiting, noise, and carrier loss
			if (err = PUCheckLine())
			{
				PUSetError(err);
				if (err == kCallWaitingErr)
				{
					MESG("Got Call Waiting Tone");
					INCRCOMMERROR(callWaitingError,1);
				}
				else if (err == kRemoteCallWaitingErr)
				{
					MESG("Remote Got Call Waiting Tone");
					INCRCOMMERROR(remoteCallWaitingError,1);
				}
				else if (err == kConnectionLost)
				{
					MESG("Lost Carrier");
					if (REFGLOBAL(PGlobals,server))
						INCRCOMMERROR(serverDisconnectError,1);
					else
						INCRCOMMERROR(peerDisconnectError,1);
				}
				REFGLOBAL(PGlobals,PHConnState) = kConnClosing;
				PUHangUp();
				// ... and indicate such to higher levels
				TIndication(nil, REFGLOBAL(PGlobals,PHConnState), 0);
				return PGetError();
			}
		}

		switch(PGetError())
		{
			case kFrameError:
				INCRCOMMERROR(framingError, 1);
				MESG("PModem Frame Error");
				PCheckError();
				break;
			case kOverrunError:
				INCRCOMMERROR(overrunError, 1);
				MESG("PModem Overrun Error");
				PCheckError();
				break;
			default:
				break;
		}

		if (pBlock)
			pBlock->ioPhysNetState = REFGLOBAL(PGlobals,PHConnState);

		return PUProcessIdle();
		}
	else
		// return the last error
		return PGetError();
}

OSErr _PWritePacketSync(WDS *sendBuffer)
{
OSErr			err;

	if (err = PGetError()) {
		ERROR_MESG("Outstanding error has not been cleared");
		return err;
		}

	if (REFGLOBAL(PGlobals,PHConnState) != kConnOpen) 
		return PUSetError(kLinkClosed);

	err = PWritePacketASync(sendBuffer);
	if (err) return err;
	
	while (REFGLOBAL(PGlobals,PHWriteActive)) {
		err = PNetIdle(nil);
		if (err < 0) return err;
		}
		
	return noErr;
}

// queue small chunks as we find kDLEChar's scattered through the outgoing buffer
// called by TWriteDataSync, and in turn TWriteDataASync
OSErr _PWritePacketASync(WDS *sendBuffer)
{
OSErr			theErr;
long			bufLength, iter, padPoint;
unsigned char	*addr;
unsigned short	crc;
Boolean			doingFCS;
DECLAREVARSIFTESTING();

	if (theErr = PGetError()) {
		ERROR_MESG("Outstanding error has not been cleared");
		return theErr;
		}

	if (REFGLOBAL(PGlobals,PHConnState) != kConnOpen) 
		return PUSetError(kLinkClosed);

	// for those bad days when everything is a frame char, the worst case packet size is 2x
	bufLength = (sendBuffer->length1 + sendBuffer->length2 + kFCSSize + kFramingSize) * 2;
	if (FifoRemaining(&REFGLOBAL(PGlobals,PHWriteFifo)) < bufLength) {
		// we have more to write than the fifo can handle.  Idle here if
		// if the buffer is big enough to ever handle it, otherwise idle until
		// FifoAvailable is zero and switch buffers.
		if (FifoSize(&REFGLOBAL(PGlobals,PHWriteFifo)) > bufLength) {
			// the fifo can handle it, just not right now.  Idle a bit
			while (FifoRemaining(&REFGLOBAL(PGlobals,PHWriteFifo)) < bufLength) {
				theErr = PNetIdle(nil);
				if (theErr < 0) return theErr;
				}
			}
		else {
			// the buffer is bigger than the fifo
			ASSERT_MESG(0,"The packet write fifo isn't big enough to for this buffer");
			}
		}
			
	bufLength = sendBuffer->length1;
	addr = sendBuffer->buf1;
	padPoint = iter = 0;
	crc = 0xffff;
	doingFCS = false;
	while (1) {
		// (doingFCS == true) signals the writing of the FCS itself
		if (!doingFCS)
			crc = ccitt_updcrc(crc, (unsigned char *)addr, bufLength);
		while (iter < bufLength) {
			if (addr[iter] == kDLEChar) {
				iter += 1;
				TRASHHEADERIFTESTING();
				theErr = FifoWrite(&REFGLOBAL(PGlobals,PHWriteFifo), &addr[padPoint], iter - padPoint);
				LASTTRASHHEADERIFTESTING();
				if (theErr) return PUSetError(theErr);
				if (iter <= bufLength) {
					// send a pad
					theErr = FifoWrite(&REFGLOBAL(PGlobals,PHWriteFifo), &addr[iter-1], 1);
					if (theErr) return PUSetError(theErr);
					padPoint = iter;
					}
				}
			else {
				iter += 1;
				if (iter == bufLength) {
					TRASHHEADERIFTESTING();
					// flush the rest of the buffer
					theErr = FifoWrite(&REFGLOBAL(PGlobals,PHWriteFifo), &addr[padPoint], bufLength - padPoint);
					LASTTRASHHEADERIFTESTING();
					if (theErr) return PUSetError(theErr);
					}
				}
			}
		if (doingFCS)
			break;
		else if (addr == sendBuffer->buf1) {
			// if the address is the first buffer then it should be the second next loop
			padPoint = iter = 0;
			bufLength = sendBuffer->length2;
			addr = sendBuffer->buf2;
			UPDATEVARSIFTESTING();
			}
		else {
			// if the address is not the FCS and not the first buffer then it 
			// is the second and we should set up for the FCS
			crc = ~crc;
			padPoint = iter = 0;
			bufLength = sizeof(crc);
			addr = (unsigned char *)&crc;
			doingFCS = true;
			TRASHCRCIFTESTING();
			}
		}
		
	// send the framing
	crc = (kDLEChar<<8) + kETXChar;

	TRASHENDIFTESTING();

	theErr = FifoWrite(&REFGLOBAL(PGlobals,PHWriteFifo), (unsigned char *)&crc, sizeof(crc));
	if (theErr) return PUSetError(theErr);
	
	// call netidle to get the write rolling
	theErr = PNetIdle(nil);
	if (theErr) return theErr;
	
	return noErr;
}

OSErr _PUProcessIdle(void)
{
short			frameSize, retVal;

	if (REFGLOBAL(PGlobals,PHIndicating))
		return noErr;
		
	retVal = FifoRead(&REFGLOBAL(PGlobals,PHLengthsFifo), (unsigned char *)&frameSize, sizeof(short));
	if (retVal == noErr) {
		// Reset always returns noErr.  If it returns an error, then the goto code _WILL_ cause the
		// packet stream to be permanently fucked!  Further, if an error comes back from ProcessIdle,
		// the consumption _MUST_ be adjusted for the same reasons.  We can't code for an error from
		// the adjust, so it is ignored.
		retVal = FifoResetConsumption(&REFGLOBAL(PGlobals,PHReadFifo));
		if (retVal) goto failed;
		retVal = PUProcessSTIdle(frameSize);
		FifoAdjustConsumption(&REFGLOBAL(PGlobals,PHReadFifo), frameSize);
		}
	else if (retVal == kFifoUnderflowErr)
		retVal = noErr;

	REFGLOBAL(PGlobals,PHIndicating) = false;
	
failed:
	if (retVal)
		PUSetError(retVal);
	return retVal;
}

// this guy gets hit when a ServerTalk frame comes in.  His speed is not as important as the
// PUProcessGTIdle.
short _PUProcessSTIdle(unsigned short length)
{
short			retVal;
#ifdef DEBUG
short			frameTest;
#endif

	REFGLOBAL(PGlobals,PHIndicating) = true;
	// checksum happens in the fifo to avoid gratuitous copying
	if (FifoChkSum(&REFGLOBAL(PGlobals,PHReadFifo), length - kFramingSize) == 0x1D0F) {
		retVal = FifoSkip(&REFGLOBAL(PGlobals,PHReadFifo), kPhysHdrSiz);
		if (retVal) goto failed;
		
		retVal = TIndication(&REFGLOBAL(PGlobals,PHReadFifo), REFGLOBAL(PGlobals,PHConnState), length - (kPhysHdrSiz + kFCSSize + kFramingSize));
		if (retVal) goto failed;
		
		retVal = FifoSkip(&REFGLOBAL(PGlobals,PHReadFifo), kFramingSize+kFCSSize);
		if (retVal) goto failed;
		}
	else {
		INCRCOMMERROR(packetError, 1);
		WARNING_MESG("Bad Packet Detected");
		// just kill it all
		retVal = FifoSkip(&REFGLOBAL(PGlobals,PHReadFifo), length);
		if (retVal) goto failed;
		}
	REFGLOBAL(PGlobals,PHIndicating) = false;

failed:	
	if (retVal)
		PUSetError(retVal);
	return retVal;		
}


OSErr _PUOpenPort(Boolean listen, char *config)
{
OSErr			err;
long			thd;
long			xbo;

	PCheckError();
	REFGLOBAL(PGlobals,disableCW) = 0;
	REFGLOBAL(PGlobals,rlsdstate) = 1;

	FifoInit(&REFGLOBAL(PGlobals,PHScrDebugFifo), (unsigned char *)REFGLOBAL(PGlobals,PHScrDebugFifo).bufStart, REFGLOBAL(PGlobals,chatDebugFifoSize), kCircularQ);

	// do common port opening stuff here
	err = PUResetModem();
	if (err)
		return err;

#ifdef __SERVER__
	if (listen)
		thd = kFEOffListenThreshold;
	else
		thd = kFEOffOriginateThreshold;
	REFGLOBAL(PGlobals,fastDSPMode) = 0;
#else
	if (listen)
		DBGetConstant(kDBFEOffListenThresholdConst, &thd);
	else
		DBGetConstant(kDBFEOffOriginateThresholdConst, &thd);
	
	DBGetConstant(kXBANDOptions1Const, &xbo);
	REFGLOBAL(PGlobals,fastDSPMode) = 0;
	if (!REFGLOBAL(PGlobals,server) && (xbo & kXB_FastDSPMode))
		REFGLOBAL(PGlobals,fastDSPMode) = 1;
	
	REFGLOBAL(PGlobals,leasedline) = 0;
	if (!REFGLOBAL(PGlobals,server) && (xbo & kXB_LeasedLineMode))
		REFGLOBAL(PGlobals,leasedline) = 1;
#endif
	// BET: set RLSD off setting to something higher in attempt to detect when
	// other side disconnects, but only for listen connections
	PUWriteXRAM(0x35, 0, thd);
	return noErr;
}

void _PUClosePort(void)
{
	PUTearDownServerTalk();
	MESG("PUClosePort");
}

Boolean _PUSetupServerTalk()
{
unsigned char	dummy;

	if (!REFGLOBAL(PGlobals,serverTalk))
		return false;

	MESG("_PUSetupServerTalk");

	// set up the fifo
	FifoInit(&REFGLOBAL(PGlobals,PHReadFifo), REFGLOBAL(PGlobals,PHReadDataBuf), kPhysBufferSize, kCircularQ);
	FifoInit(&REFGLOBAL(PGlobals,PHWriteFifo), REFGLOBAL(PGlobals,PHWriteDataBuf), kPhysBufferSize, kCircularQ);
	FifoInit(&REFGLOBAL(PGlobals,PHLengthsFifo), REFGLOBAL(PGlobals,PHLengthsBuf), kFrameStartBufSiz, kCircularQ);
	REFGLOBAL(PGlobals,PHFrameSizAccum) = 0;
	
	// remove this if we are GT/ST coresident
	REFGLOBAL(PGlobals,PHPacketState) = kProcessingST;
	
#if defined(SIMULATOR) || defined(__SERVER__)
	REFGLOBAL(PGlobals,PHReadTimeTask).tmTask.tmAddr = (TimerProcPtr)_PUReadTimeProc;
	REFGLOBAL(PGlobals,PHReadTimeTask).tmTask.tmWakeUp = 0;
	REFGLOBAL(PGlobals,PHReadTimeTask).tmTask.tmReserved = 0;
	REFGLOBAL(PGlobals,PHReadTimeTask).tmA5 = SetCurrentA5();
	
	REFGLOBAL(PGlobals,PHWriteTimeTask).tmTask.tmAddr = (TimerProcPtr)_PUWriteTimeProc;
	REFGLOBAL(PGlobals,PHWriteTimeTask).tmTask.tmWakeUp = 0;
	REFGLOBAL(PGlobals,PHWriteTimeTask).tmTask.tmReserved = 0;
	REFGLOBAL(PGlobals,PHWriteTimeTask).tmA5 = SetCurrentA5();
	
	InsTime((QElemPtr)&REFGLOBAL(PGlobals,PHReadTimeTask));
	InsTime((QElemPtr)&REFGLOBAL(PGlobals,PHWriteTimeTask));
	
	PrimeTime((QElemPtr)&REFGLOBAL(PGlobals,PHReadTimeTask), kRWTimeDelay);
	PrimeTime((QElemPtr)&REFGLOBAL(PGlobals,PHWriteTimeTask), kRWTimeDelay);
#endif
	// be sure the fifos are clear
	PUReadSerialByte(&dummy);
	REFGLOBAL(PGlobals,PHCallbackSema) = true;	// turn on callbacks
	return true;
}

Boolean _PUTearDownServerTalk(void)
{
long			closeTimeout;
NetParamBlock	pBlock;
unsigned long	stopTime, read, write, lastRead, lastWrite;

	if (!REFGLOBAL(PGlobals,serverTalk))
		return false;

#ifdef __SERVER__
	closeTimeout = kCloseTimeout;
#else
	DBGetConstant(kDBCloseTimeoutConst, &closeTimeout);
#endif

	if (NetIdle(&pBlock) < 0) 
		CheckError();
	else {
		stopTime = GetCurrentTime() + closeTimeout;
		while ((pBlock.ioPhysNetState == kConnOpen) && (stopTime < GetCurrentTime())) {
			if (NetIdle(&pBlock) < 0) {
				CheckError();
				break;
				}
			
			read = FifoAvailable(&REFGLOBAL(PGlobals,PHReadFifo));
			write = FifoAvailable(&REFGLOBAL(PGlobals,PHWriteFifo));
			if ((lastRead != read) || (lastWrite != write)) {
				lastRead = read;
				lastWrite = write;
				stopTime = GetCurrentTime() + closeTimeout;
				}
			}
		}
#if defined(SIMULATOR) || defined(__SERVER__)
	MESG("PUTearDownServerTalk");
	if (REFGLOBAL(PGlobals,serverTalk) && REFGLOBAL(PGlobals,PHCallbackSema)) {
		RmvTime((QElemPtr)&REFGLOBAL(PGlobals,PHReadTimeTask));
		RmvTime((QElemPtr)&REFGLOBAL(PGlobals,PHWriteTimeTask));
		REFGLOBAL(PGlobals,PHReadTimeTask).tmTask.tmAddr = 0;
		REFGLOBAL(PGlobals,PHWriteTimeTask).tmTask.tmAddr = 0;
	}
#endif
	REFGLOBAL(PGlobals,PHCallbackSema) = false;	// turn off callbacks
	REFGLOBAL(PGlobals,serverTalk) = 0;			// ServerTalk is now "off"
	return true;
}

#if defined(SIMULATOR) || defined(__SERVER__)
pascal void _PUReadTimeProc(void)
{
long		oldA5;
TMInfoPtr	tmPtr;
		
	tmPtr = GetTMInfo();
	oldA5 = SetA5(tmPtr->tmA5);

#ifndef __SERVER__
	++gRestartSemaphore;		// semaphore to keep dispatcher reset happy
	FlagTimeTask ( kPUReadTimeTask );
#endif

	PUReadTimeCallback( 0, 0 );
	PrimeTime((QElemPtr)tmPtr, kRWTimeDelay);

#ifndef __SERVER__
	FlagTimeTask ( kPUReadTimeTask );
	--gRestartSemaphore;		// restart safe again
#endif

	SetA5(oldA5);
}

pascal void _PUWriteTimeProc(void)
{
long		oldA5;
TMInfoPtr	tmPtr;

	tmPtr = GetTMInfo();
	oldA5 = SetA5(tmPtr->tmA5);

#ifndef __SERVER__
	++gRestartSemaphore;		// semaphore to keep dispatcher reset happy
	FlagTimeTask ( kPUWriteTimeTask );
#endif


	PUWriteTimeCallback( 0, 0 );
	PrimeTime((QElemPtr)tmPtr, kRWTimeDelay);

#ifndef __SERVER__
	FlagTimeTask ( kPUWriteTimeTask );
	--gRestartSemaphore;		// restart safe again
#endif

	SetA5(oldA5);
}
#endif

long _PUReadTimeCallback( long time, long data )
{
OSErr			error;
unsigned char	byte;

	if (REFGLOBAL(PGlobals,PHCallbackSema) == false)
		return time+1;

	error = PUReadSerialByte(&byte);
	while (!error) {
#ifdef BUFFERDATA
	// Add to the fifo, then dump it out.  Gives us a buffer that never fills.
	FifoWrite(&REFGLOBAL(PGlobals,testRead), &byte, 1);
	FifoSkip(&REFGLOBAL(PGlobals,testRead), 1);
#endif
		error = FifoWrite(&REFGLOBAL(PGlobals,PHReadFifo), &byte, sizeof(byte));
		if (error)
			PUSetError(error);
		if (REFGLOBAL(PGlobals,PHPacketParseActive))
		PUAsyncReadDispatch(nil/*not used?*/, byte);
		error = PUReadSerialByte(&byte);
		}
		
	return time+1;
}

void _PUAsyncReadDispatch(PGlobalType * glob, unsigned char prevChar)
{
	REFGLOBAL(PGlobals,PHFrameSizAccum) += 1;
		if ((REFGLOBAL(PGlobals,PHPacketState) == kCheckNextST) && (prevChar == kETXChar)) {
			// yep, the last one was a frame
			FifoWrite(&REFGLOBAL(PGlobals,PHLengthsFifo), (unsigned char *)&REFGLOBAL(PGlobals,PHFrameSizAccum), sizeof(short));
			REFGLOBAL(PGlobals,PHFrameSizAccum) = 0;
			REFGLOBAL(PGlobals,PHPacketState) = kProcessingST; 			// reset for next time
			}
		else if (prevChar == kDLEChar) {					// found a DLE?
			if (REFGLOBAL(PGlobals,PHPacketState) == kCheckNextST) { 		// yep, did we just see one?
				FifoUnwrite(&REFGLOBAL(PGlobals,PHReadFifo), 1);			// yep, dump this one
				// update fram size accumulator
				REFGLOBAL(PGlobals,PHFrameSizAccum) -= 1;
				REFGLOBAL(PGlobals,PHPacketState) = kProcessingST; 		// reset for next time
				}
			else											// didn't just see one, prepare to
				REFGLOBAL(PGlobals,PHPacketState) = kCheckNextST;			// dump next one if there is one
			}
		else {
			REFGLOBAL(PGlobals,PHPacketState) = kProcessingST; 			// either way the next is something!
			}
}

long _PUWriteTimeCallback( long time, long unused )
{
short			count;
long			returnTime;
unsigned long	fifoBytesAvailable;
	
	if (REFGLOBAL(PGlobals,PHCallbackSema) == false)
		return time+1;

	returnTime = time + 1;
	if (REFGLOBAL(PGlobals,PHConnState) == kConnOpen) 
	{
		fifoBytesAvailable = FifoAvailable(&REFGLOBAL(PGlobals,PHWriteFifo));
		if (fifoBytesAvailable != 0) 
		{
			if (PUTransmitBufferFree() == noErr) 
			{
				count = kFIFOLENGTH;
				if (fifoBytesAvailable > count)
					fifoBytesAvailable = count;
					
				REFGLOBAL(PGlobals,PHWriteActive) = true;

				FifoRead(&REFGLOBAL(PGlobals,PHWriteFifo), REFGLOBAL(PGlobals,PHStagingBuf), fifoBytesAvailable);
#ifdef BUFFERDATA
			FifoWrite(&REFGLOBAL(PGlobals,testWrite), REFGLOBAL(PGlobals,PHStagingBuf), fifoBytesAvailable);
			FifoSkip(&REFGLOBAL(PGlobals,testWrite), fifoBytesAvailable);
#endif
	
				for (count=0; count<fifoBytesAvailable; count++)
					PUWriteSerialByte(REFGLOBAL(PGlobals,PHStagingBuf)[count]);
			}
		}
		else 
		{
			REFGLOBAL(PGlobals,PHWriteActive) = false;
		}
	}
		
	return returnTime;
}

// this is managerized so it can be patched
OSErr _PUSetError(OSErr err)
{
	REFGLOBAL( PGlobals, PHLastError ) = err;
	return err;
}

// this is managerized so it can be patched
OSErr _PGetError(void)
{
	return REFGLOBAL( PGlobals, PHLastError );
}

// this is managerized so it can be patched
OSErr _PCheckError(void)
{
OSErr		err;

	err = REFGLOBAL( PGlobals, PHLastError );
	REFGLOBAL( PGlobals, PHLastError ) = noErr;
	return err;
}

OSErr
_PClearPhysLine(void)
{
WDS					writePB;
unsigned char		foo;

	writePB.length1 = 1;
	writePB.buf1 = &foo;
	writePB.length2 = 0;
	writePB.buf2 = nil;
	return PWritePacketSync(&writePB);
}

////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
// change from here down for modem stuff
OSErr _PUReadSerialByte( unsigned char *byte )
{
MODEMPTR;
short error;
short result;
short mstatus2;
short mstatus1;

	error = 0;
#ifdef ROSKO
	mstatus1 = READ_FRED(kReadMStatus1);
	mstatus2 = READ_FRED(kReadMStatus2);
	if (!(mstatus2 & kRMrxready))
		error = kNoByteReady;
	else {
		if (mstatus2 & kRMframeerr)
			error = kFrameError;
		if (mstatus1 & kRMoverrun)
			error = kOverrunError;
		*byte = READ_FRED(kRxBuff) & REFGLOBAL(PGlobals,PHCharMask);
	}
#else
	if (FE) {
		error = kFrameError;
		FE0;
	} else if (PE) {
		error = kParityError;
		PE0;
	} else if (OE) {
		error = kOverrunError;
		OE0;
	}
	if ((!RDBF) || (!RLSD)){
		error = kNoByteReady;
	} else {
		*byte = RBUFFER & REFGLOBAL(PGlobals,PHCharMask);
	}
#endif
	return error;
}

OSErr _PUWriteSerialByte (unsigned char byte)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h
short error;
short mstatus;

	error = 0;
#ifdef ROSKO
	mstatus = READ_FRED(kReadMStatus1);
	if (mstatus & kRMoverrun)
		error = kOverrunError;
	while (mstatus & kRMtxfull)
		{
			mstatus = READ_FRED(kReadMStatus1);
			if (mstatus & kRMoverrun)
				error = kOverrunError;
		}
	WRITE_FRED(kTxBuff,byte);
#else
	WHILE_TIMEOUT (!TDBE);
	SETTBUFFER(byte);
#endif
	if (error)
		PUSetError(error);
	return error;
}


OSErr _PUTransmitBufferFree (void)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h

short error;

	error = kTransmitBufferFull;
	
#ifdef ROSKO
	if (!(READ_FRED(kReadMStatus1) & kRMtxfull))
		error = 0;
#else
	if ( RLSD && CTS && TDBE )
		error = 0;
#endif

	return error;
}

short _PUReceiveBufferAvail (void)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h

#ifdef ROSKO
	return READ_FRED(kReadMStatus2) & kRMrxready;
#else
	return (RDBF);
	
#endif

}

OSErr _PUTestForConnection ( void )
{
short error;
unsigned char byte;

	error = kNoConnection;
	
	/* if we got a byte, make sure it's the connect token */
	if (  ( &byte ) == 0 )
		{
		if ( byte == kConnectToken )
			{
			error = 0;
			}
		}

	if (error)
		PUSetError(error);
	return error;
}

////////////////////////////////////////////////////////////////////////////////////
//
//	ORIGINATE CALL
//
////////////////////////////////////////////////////////////////////////////////////

OSErr _PUOriginateAsync(char *config, long flags)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h

OSErr			err = kConnectFailed;
short			noanswer = 0;
long			delayBeforeDial;
long			originateTimeout;
long			triesBeforeDisableCW;
short			progress = 0;
short			connect = 0;
short			handshaking = 0;

	PUPickUp(0);

#ifdef __SERVER__
	delayBeforeDial = kDelayBeforeDial;
	originateTimeout = kOriginateTimeout;
	triesBeforeDisableCW = kTriesBeforeDisableCW;
#else
	DBGetConstant(kDBDelayBeforeDialConst,&delayBeforeDial);
	DBGetConstant(kDBOriginateTimeoutConst,&originateTimeout);
	if (flags & kDisableCallWaiting)
	{
		// always set our disable flag so we ignore call waiting tones later
		REFGLOBAL(PGlobals,disableCW) = 1;
		// check if we're ready to retry disabling call waiting
		if (REFGLOBAL(PGlobals,disableCWCounter) == 0)
		{
			if (PUDisableCallWaiting())	// then don't retry for another 10 calls
				REFGLOBAL(PGlobals,disableCWCounter)++;
		}
		else
		{
			REFGLOBAL(PGlobals,disableCWCounter)++;
			DBGetConstant(kTriesBeforeDisableCWConst,&triesBeforeDisableCW);
			if (REFGLOBAL(PGlobals,disableCWCounter) > triesBeforeDisableCW)
				REFGLOBAL(PGlobals,disableCWCounter) = 0;
		}
	}
#endif

	DelayTicks(delayBeforeDial,kNetworkCode);
	err = PUDialNumber(config);
	if (err && !(flags & kIgnoreDialTone))
		goto failed;

	// Errors from DialNumber are not fatal--yet. We always dial there regardless of dialtone.

	MESG("Waiting for answer...");
	PUInitCallProgress();
	ORG1;
	NEWCONF;
	PUDataMode();
	SETDIAL;
	PUSetTimerTicks(0,originateTimeout);
	do {
		if (ATV25) {
			handshaking = 1;
			connect = PUAnstondet(1);
		}
		if (connect)
		{
			if (REFGLOBAL(PGlobals,server))
				INCRCOMMERROR(serverConnects, 1);
			else
				INCRCOMMERROR(peerConnects, 1);

			RTS1;
			WHILE_TIMEOUT (!CTS);	// wait reasonable period for CTS going high
			if (!CTS) break;		// if never went high, we failed...
			PUSetupServerTalk();
			if (REFGLOBAL(PGlobals,leasedline)) {
				LL1;
				NEWCONF;
			}
			MESG("CONNECTED");
			REFGLOBAL(PGlobals,PHConnState) = kConnOpen;
			REFGLOBAL(PGlobals,lastEQMTime) = GetCurrentTime();
			REFGLOBAL(PGlobals,nextEQMTime) = GetCurrentTime() + REFGLOBAL(PGlobals,rb).EQMPeriod;
			return noErr;
		}
		progress = PUCallProgress();
		if (progress == kBusy)
			break;
		SEGAOSIDLE;
	} while (!( noanswer = PUTimerExpired(0) ));
failed:
	MESG("CONNECT FAILED");
	REFGLOBAL(PGlobals,PHConnState) = kConnClosed;
	if (err == kNoDialtone)
	{
		MESG("NO CONNECT: NO DIALTONE");
	}
	else if (progress == kBusy)
	{
		err = kConnectBusy;
		if (REFGLOBAL(PGlobals,server))
			INCRCOMMERROR(serverBusyError, 1);
		else
			INCRCOMMERROR(peerBusyError, 1);
		MESG("NO CONNECT: BUSY");
	}
	else if (noanswer && !handshaking)
	{
		err = kNoAnswer;
		if (REFGLOBAL(PGlobals,server))
			INCRCOMMERROR(serverNoAnswerError, 1);
		else
			INCRCOMMERROR(peerNoAnswerError, 1);
		MESG("NO CONNECT: NO ANSWER");
	}
	else if ( handshaking )
	{
		err = kHandshakeErr;
		MESG("NO CONNECT: BAD HANDSHAKE");
		if (REFGLOBAL(PGlobals,server))
			INCRCOMMERROR(serverHandshakeError, 1);
		else
			INCRCOMMERROR(peerHandshakeError, 1);
	}
	PUHangUp();
	if (err)
		PUSetError(err);
		
	return err;
}

// Modem Designer's Guide p7-3
Boolean _PUAnstondet(short timer)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h
long answerToneDelay;
long atvTimeout;
long u1detTimeout;

	MESG("Anstondet");
#ifdef __SERVER__
	answerToneDelay = kAnswerToneDelay;
	atvTimeout = kAnswerToneTimeout >> 16;
	u1detTimeout = kAnswerToneTimeout & 0xFFFF;
#else
	DBGetConstant( kDBAnswerToneDelayConst, &answerToneDelay);
	DBGetConstant( kAnswerToneTimeoutConst, &u1detTimeout);
	atvTimeout = u1detTimeout >> 16;
	u1detTimeout &= 0xFFFF;
#endif
	PUSetTimerSecs(timer, atvTimeout);
	while (ATV25) {
		if (PUTimerExpired(timer))
			break;
		SEGAOSIDLE;
	}
	PUDataMode();
	PUSetTimerSecs(timer, u1detTimeout);
	do {
		DelayMS(answerToneDelay,kNetworkCode);
		if (U1DET) {
			if (PUWaitForRLSD(timer+1))
				return 1;
		}
		PUDataMode();
		SEGAOSIDLE;
	} while (!PUTimerExpired(timer));
	return 0;
}

Boolean _PUWaitForRLSD(short timer)
{
long answerCarrierTimeout;
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h

#ifdef __SERVER__
	answerCarrierTimeout = kAnswerCarrierTimeout;
#else
	DBGetConstant( kAnswerCarrierTimeoutConst, &answerCarrierTimeout);
#endif
	PUSetTimerSecs(timer,answerCarrierTimeout);
	do {
		if (RLSD) 
		{
			if (SPEED != k2400Baud)
				return 0;
			return 1;
		}
		SEGAOSIDLE;
	} while (!PUTimerExpired(timer));
	return 0;
}

void _PUInitCallProgress(void)
{
	REFGLOBAL(PGlobals,offtoon) = REFGLOBAL(PGlobals,lastdet) = 0;
	REFGLOBAL(PGlobals,rb).ringtimer = GetCurrentTime();
}

//	Returns call status:
//	0		= nothing to report
//	kBusy	= Busy detected
//	kRing	= Ring detected

short _PUCallProgress(void)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h
short progress = 0;
long ringofftime;
long curtime;

	curtime = GetCurrentTime();
	DATA0;
	NEWCONF;
	SETCONF(kDialMode);
	NEWCONF;
	if (TONEA)
	{
		if (REFGLOBAL(PGlobals,lastdet))
			return 0;
		REFGLOBAL(PGlobals,lastdet) = 1;
		ringofftime = curtime - REFGLOBAL(PGlobals,rb).ringtimer;
		if (REFGLOBAL(PGlobals,offtoon))
		{
			if (	(REFGLOBAL(PGlobals,rb).ringontime  >= REFGLOBAL(PGlobals,rb).ringOnTimeMin)
				&&	(REFGLOBAL(PGlobals,rb).ringontime  <= REFGLOBAL(PGlobals,rb).ringOnTimeMax)
				&&	(ringofftime >= REFGLOBAL(PGlobals,rb).ringOffTimeMin)
				&&	(ringofftime <= REFGLOBAL(PGlobals,rb).ringOffTimeMax) )
			{
				MESG("RING");
				progress = kRing;
			}
			else
			if (	(REFGLOBAL(PGlobals,rb).ringontime  >= REFGLOBAL(PGlobals,rb).busyOnTimeMin)
				&&	(REFGLOBAL(PGlobals,rb).ringontime  <= REFGLOBAL(PGlobals,rb).busyOnTimeMax)
				&&	(ringofftime >= REFGLOBAL(PGlobals,rb).busyOffTimeMin)
				&&	(ringofftime <= REFGLOBAL(PGlobals,rb).busyOffTimeMax) )
			{
				MESG("BUSY");
				progress = kBusy;
			}
		} else
			REFGLOBAL(PGlobals,offtoon) = 1;
		REFGLOBAL(PGlobals,rb).ringtimer = curtime;
	} else {
		if (REFGLOBAL(PGlobals,lastdet))
		{
			REFGLOBAL(PGlobals,lastdet) = 0;
			REFGLOBAL(PGlobals,rb).ringontime = curtime-REFGLOBAL(PGlobals,rb).ringtimer;
			REFGLOBAL(PGlobals,rb).ringtimer = curtime;
		}
	}
	return progress;
}

// This routine is fairly dumb in that it simply dials DTMF tones and assumes the
// phone is off the hook.  Pass a "w" in the string to wait for dial tone before
// continuing. If dial tone fails, an error is returned.
// Possible strings are:
//		"w555-1212" waits for dial tone before dialing.
//		"w*70,w555-1212" wait for dial tone, turns off call waiting, dials number.

OSErr _PUDialNumber( char *number )
{
	MODEMPTR;
	short digit, error;
	long delayBeforeDTMF;
	long dialPauseDelay;
	long dtmf_interdigit;
	long dtmf_duration;

#ifdef __SERVER__
	delayBeforeDTMF = kDelayBeforeDTMF;
	dialPauseDelay = kDialPauseDelay;
	dtmf_interdigit = kDTMFInterdigit;
	dtmf_duration = kDTMFDuration;
#else
	DBGetConstant(kDBDelayBeforeDTMFConst, &delayBeforeDTMF);
	DBGetConstant(kDBDialPauseDelayConst, &dialPauseDelay);
	DBGetConstant(kDTMFInterdigitConst, &dtmf_interdigit);
	DBGetConstant(kDTMFDurationConst, &dtmf_duration);
#endif
	
	PUDialMode();
	DTMF1;
	NEWCONF;
	PUWriteXRAM(0x7E,0,dtmf_duration);
	PUWriteXRAM(0x7C,0,dtmf_interdigit);

	// Always wait for dialtone up front
	if (error = PUWaitDialTone(0,false))
		return error;
	
	DelayTicks(delayBeforeDTMF,kNetworkCode);

	// Dialtone just makes us dial faster. If we timed out without a dialtone,
	// then we dial anyway and wait for further line status. Hopefully, we connect
	// anyway. But we need to dial just in case there's something slightly different
	// about some user's dialtone.

#ifndef ROSKO
	printf("Dialing %s\n", number);
#endif
	for (; *number; number++) {
		WHILE_TIMEOUT (!TDBE);
		switch (*number) {
			case '*':
				digit = 0xA;
				break;
			case '#':
				digit = 0xE;
				break;
			case 'w':
				error = PUWaitDialTone(0,false);
				continue;
			case ',':
				DelayTicks(dialPauseDelay,kNetworkCode);
				continue;
			default:
				digit = *number - '0';
				if (digit < 0 || digit > 9)
					continue;
				break;
		}
		SETTBUFFER(digit);
		SEGAOSIDLE;
	}
	WHILE_TIMEOUT(!TDBE);
	return noErr;
}

// returns true if dial tone is detected
OSErr _PUWaitDialTone(short timer, Boolean continuous)
{
	long dialToneTimeout;
	long dialToneConstTimeout;
	MODEMPTR;

#ifdef __SERVER__
	dialToneTimeout = kDialToneTimeout;
#else
	DBGetConstant(kDBDialToneTimeoutConst, &dialToneTimeout);
#endif
	if (continuous)
	{
#ifdef __SERVER__
	dialToneConstTimeout = kDialToneConstTime;
#else
	DBGetConstant(kDBDialToneConstTimeConst, &dialToneConstTimeout);
#endif
		// wait for positive tone lock up front for short time
		PUSetTimerTicks(timer,20);
		while (!PUTimerExpired(timer)) {
			SEGAOSIDLE;
			if (TONEA) break;
		}
		// if we never got it or don't have it now, fail.
		if (TONEA)
		{
			PUSetTimerTicks(timer,dialToneConstTimeout);
			do {
				if (!TONEA)
					goto none;
				SEGAOSIDLE;
			} while (!PUTimerExpired(timer));
			if (TONEA)
				return noErr;
		}
	} else {
		PUSetTimerTicks(timer,dialToneTimeout);
		do {
			if (TONEA)
			{
				MESG("Dialtone detected.");
				return noErr;
			}
			SEGAOSIDLE;
		} while (!PUTimerExpired(timer));
	}
none:
	INCRCOMMERROR(noDialtoneError, 1);
	MESG("No Dialtone.");
	return PUSetError(kNoDialtone);
}

////////////////////////////////////////////////////////////////////////////////////
//
//	ANSWER CALL (FROM PEER)
//
////////////////////////////////////////////////////////////////////////////////////

OSErr _PUAnswerAsync(char *config)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h

	REFGLOBAL(PGlobals,PHConnState) = kConnListening;
	return noErr;
}

// We are waiting for a call, so check the ringer. If detected, pick up the line
// and try establishing a connection.

Boolean _PUCheckRing( short playsnd )
{
	MODEMPTR;
	if (RI)
	{
		if (playsnd)
			PlayDBFX(kPhoneRingSnd,0,0);
		return 1;
	}
	return 0;
}

//
// Errors:
//			kHandshakeErr
//			kNoAnswer
//

OSErr _PUCheckAnswer(Boolean hangupOnNoAnswer)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h
OSErr			err;
short			connect = 0;
short			handshaking = 0;
long			overallTimeout;
long			carrierTimeout;
long			answerDelay;

#ifdef __SERVER__
	overallTimeout = kAnswerTimeout >> 16;
	carrierTimeout = kAnswerTimeout & 0xFFFF;
	answerDelay = kAnswerDelay;
#else
	DBGetConstant(kAnswerDelayConst, &answerDelay);
	DBGetConstant(kAnswerTimeoutConst, &carrierTimeout);
	overallTimeout = carrierTimeout >> 16;
	carrierTimeout &= 0xFFFF;
#endif
	MESG("Answering phone.");
	PUPickUp(0);
	DelayTicks( answerDelay, kNetworkCode );
	ORG0;
	NEWCONF;
	SETCONF(kV22bisMode);
	NEWCONF;
	PUDataMode();
	PUSetTimerSecs(0, overallTimeout);
	do {
		if (S1DET)
		{
			handshaking = 1;
			MESG("S1DET");
			PUSetTimerSecs(1,carrierTimeout);
			do {
				if ( RLSD && (SPEED == k2400Baud) )
					connect = 1;
				SEGAOSIDLE;
			} while (!PUTimerExpired(1));
			break;
		}
		SEGAOSIDLE;
	} while (!PUTimerExpired(0));

	if (connect) {
		RTS1;
		WHILE_TIMEOUT (!CTS);	// wait reasonable period for CTS to go high.
		if (!CTS) goto failed;	// if never went high, we failed.
		if (REFGLOBAL(PGlobals,leasedline)) {
			LL1;
			NEWCONF;
		}
		if (REFGLOBAL(PGlobals,server))
			INCRCOMMERROR(serverConnects, 1);
		else
			INCRCOMMERROR(peerConnects, 1);
		PUSetupServerTalk();
		MESG("CONNECTED");
		REFGLOBAL(PGlobals,PHConnState) = kConnOpen;
		REFGLOBAL(PGlobals,lastEQMTime) = GetCurrentTime();
		REFGLOBAL(PGlobals,nextEQMTime) = GetCurrentTime() + REFGLOBAL(PGlobals,rb).EQMPeriod;
		return noErr;
	}

failed:
	REFGLOBAL(PGlobals,PHConnState) = kConnClosed;
	if (handshaking)
	{
		MESG("FAILED CONNECT: BAD HANDSHAKE!");
		err = kHandshakeErr;
	} else {
		MESG("FAILED CONNECT: TIMED OUT--NOT A MODEM?");
		err = kNoAnswer;
	}
	if (hangupOnNoAnswer || err != kNoAnswer)
	{
		PUHangUp();
	} else {
		DATA0;
		NEWCONF;
		LL0;
		NEWCONF;
	}
	return PUSetError( err );
}

////////////////////////////////////////////////////////////////////////////////////
//
//	MODEM UTILITIES
//
////////////////////////////////////////////////////////////////////////////////////

// this code needs to timeout on infinite loops
OSErr _PUResetModem(void)
{
	long fredStatus;

	MODEMPTR;
	WRITE_REG(0x18,0);		// XRAM Data LSB
	WRITE_REG(0x19,0);		// XRAM Data MSB
	WRITE_REG(0x1C,0x36);	// IOX Address for GPRH
	WRITE_REG(0x1D,0x8A);	// (XACC=1, IOX=1, XWT=1)
	WHILE_TIMEOUT(XACC);
	WRITE_REG(0x04,0x40);	// SWRES = 1;
	WHILE_TIMEOUT (!TDBE);	// wait for checksum data to be read from DSP
	IOX0;
	LL0;
	NEWCONF;
	SETVOL(0);
	NEWCONF;
	SETTLVL(2);
	NEWCONF;
#ifdef ROSKO	
	DBGetConstant( kFredModemStatusConst, &fredStatus );
	if (!REFGLOBAL(PGlobals,server))
		fredStatus >>= 8;
	fredStatus &= 0xFF;
	WRITE_FRED(kBCnt,130);
	WRITE_FRED(kBCnt+3,0);
	WRITE_FRED(kMStatus2,kMsync);
	WRITE_FRED(kMStatus1,fredStatus|kMresetModem);
	WRITE_FRED(kMStatus1,fredStatus);
#else
	TPDM1;						// Set parallel data transfer mode
	NEWCONF;
#endif
	ASYNC1;						// we want asynchronous mode for nubus card
	NEWCONF;
	SETWDSZ(3);					// Set 8 data bits in async mode
	NEWCONF;
	PUWriteYRAM(0x21, 1, 7200*6);	// Set RLSD timeout to 6 seconds
	PUIdleMode();
	return noErr;
}

void _PUSetTimerTicks(short t, short ticks)
{
	REFGLOBAL(PGlobals,timer[t]) = gTicks + ticks;
}

void _PUSetTimerSecs(short t, short seconds)
{
	REFGLOBAL(PGlobals,timer[t]) = gTicks + seconds*60;
}

short _PUTimerExpired(short t)
{
	return (gTicks > REFGLOBAL(PGlobals,timer[t]));
}

OSErr _PUHangUp(void)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h
OSErr err;

	err = PUResetModem();
	if (err)
		return err;
	RA0;
	NEWCONF;
	// Remember when we hung up so we don't pick up too early. Our local RBOC
	// pukes if we pick up too quickly and then dial--we get a busy signal no matter what.
	// We should leave this in for every RBOC since (a) we don't know which RBOC we're
	// in, and (b) other RBOC's may have this problem. Question is, are there other RBOC's
	// with longer onhook requirements?
	REFGLOBAL(PGlobals,hangupTime) = GetCurrentTime();
	return noErr;
}

void _PUPickUp(short delay)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h
long since;
long fuckedRBOCDelay;

	// Handle the case where we hung up too recently and have to delay until
	// we are on the hook for the minimum kFuckedRBOCDelay period.
	// This delay should call TimeIdle() or SegaOSIdle() to keep background
	// animation running.

	if (delay == 0) {
	#ifdef __SERVER__
		fuckedRBOCDelay = kFuckedRBOCDelay;
	#else
		DBGetConstant(kDBFuckedRBOCDelayConst, &fuckedRBOCDelay);
	#endif
		since = GetCurrentTime() - REFGLOBAL(PGlobals,hangupTime);
		if (since < fuckedRBOCDelay)
			DelayTicks(fuckedRBOCDelay - since,kNetworkCode);
	} else DelayTicks(delay, kNetworkCode);
	RA1;
	NEWCONF;
}

void _PUWriteXRAM(long addr, long xcr, long val)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h

	SETXDATA(val);
	SETXADDR(addr);
	if (xcr) {XCR1} else XCR0;
	XWT1;
	XACC1;
	WHILE_TIMEOUT(XACC);
}

void _PUWriteYRAM(long addr, long ycr, long val)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h

	SETYDATA(val);
	SETYADDR(addr);
	if (ycr) {YCR1} else YCR0;
	YWT1;
	YACC1;
	WHILE_TIMEOUT(YACC);
}

long _PUReadXRAM(long addr, long xcr)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h

	SETXADDR(addr);
	if (xcr) {XCR1} else XCR0;
	XWT0;
	XACC1;
	WHILE_TIMEOUT(XACC);
	return XDATA;
}

long _PUReadYRAM(long addr, long ycr)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h

	SETYADDR(addr);
	if (ycr) {YCR1} else YCR0;
	YWT0;
	YACC1;
	WHILE_TIMEOUT(YACC);
	return YDATA;
}

void _PUIdleMode(void)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h
	SETCONF(kV22bisMode);
	NEWCONF;
	DATA0;
	NEWCONF;
}

void _PUDataMode(void)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h
// The following code does is supposed to redunce end-to-end latency
// from 28ms to 21ms. However, it reduces reliability of successfull connections.
	SETCONF(kV22bisMode);
	NEWCONF;
	if (!REFGLOBAL(PGlobals,server)) {
#ifdef ENABLE_FAST_DSP
		if (REFGLOBAL(PGlobals,fastDSPMode)) {
			MESG("FastDSPMode");
			CEQE0;
			PUWriteYRAM(8,1,0);
			PUWriteXRAM(8,1,0);
			PUWriteYRAM(2,1,3000);
			PUWriteXRAM(2,1,3000);
		}
#endif
	}
	DATA1;
	NEWCONF;
}

void _PUDialMode(void)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h
	LL0;
	NEWCONF;
	DATA0;
	NEWCONF;
	SETCONF(kDialMode);
	NEWCONF;
}

void _PUToneMode(void)
{
MODEMPTR;				// alloc ptr with macro defined in PModemPriv.h
	DATA0;
	NEWCONF;
	LL0;
	NEWCONF;
	SETCONF(kToneMode);
	NEWCONF;
}

// Call a phone number and return true if busy
// VERY DANGEROUS IF THE NUMBER IS NOT US!

Boolean _PUIsNumberBusy(char *num)
{
	Boolean result = true;
// Dial number to find out if it is busy--a very good indication that we have called
// ourselves. If ringing, or times out without a busy signal, then assume we have moved
// and put up a dialog to the user asking if he has moved the box.

	PUInitCallProgress();
	PUPickUp(0);
	PUDialNumber(num);
	PUSetTimerSecs(0,3);
	do {
		if (PUCallProgress() == kBusy)
			goto done;
		SEGAOSIDLE;
	} while (!PUTimerExpired(0));
	result = false;
done:
	PUHangUp();
	return result;
}

static unsigned long PUReadEQM(void)
{
	MODEMPTR;
	SETXADDR(0x52);
	WRITE_REG(0x1D,0x81);// XCR1, XWT0, XACC1
	WHILE_TIMEOUT(XACC);
	return XDATA;
}

OSErr _PUCheckLine( void )
{
	OSErr error = noErr;
	MODEMPTR;
#ifdef SIMULATOR
	KeyMap theKeys;
#endif


	if (!error) {
		if (gTicks >= REFGLOBAL(PGlobals,nextEQMTime) &&
		PUReadEQM() > REFGLOBAL(PGlobals,rb).EQMThreshold)
			error = OSDetectLineNoise();
	}

	if (!error)
	{
		if (!RLSD)
			error = OSCheckCarrier();
		else
			REFGLOBAL(PGlobals,rlsdstate) = 1;
	}
	return error;
}

OSErr _PUCheckCarrier( void )
{
	// If we lose carrier, make sure we've lost it for a full
	// second (or some period of time) before closing the connection
	
	if (REFGLOBAL(PGlobals,rlsdstate))
	{
		// 1->0 transition of RLSD
		REFGLOBAL(PGlobals,lostrlsdtime) = gTicks;
		REFGLOBAL(PGlobals,rlsdstate) = 0;
	} else {
		// RLSD is still low... how long have we lost carrier?
		if (gTicks > REFGLOBAL(PGlobals,lostrlsdtime) + REFGLOBAL(PGlobals,rb).LostRLSDPeriod)
		{
			return kConnectionLost;		// lost carrier...
		}
	}
	return noErr;
}

OSErr _PUDetectLineNoise()
{
	OSErr err;
	long timeout;
	MODEMPTR;

	err = OSListenToLine();
	if (err == kCallWaitingErr)
	{
		long oldTONTME = OSReadXRAM(0x7E,0);
		DTMF1;								// Set DTMF dialing
		SETCONF(kDialMode);					// Can only do this in dial mode
		NEWCONF;
		OSWriteXRAM(0x7e,0,0);				// Make DTMF duration infinite
		SETTBUFFER(kCWSendDTMFValue);		// Generate the DTMF tone
		timeout = gTicks + REFGLOBAL(PGlobals,rb).CWDTMFPeriod;
		while(gTicks < timeout)	// Send DTMF for timeout period
			;
		OSWriteXRAM(0x7e,0,oldTONTME);		// Restore DTMF duration
		return kCallWaitingErr;
	}
	else if (err == 0)
	{
		MESG("Noise detected. Retraining modems.");
		// Return to data mode
		SETCONF(kV22bisMode);
		NEWCONF;
		if (REFGLOBAL(PGlobals,leasedline)) {
			LL1;
			NEWCONF;
		}
#ifdef ENABLE_FAST_DSP
		if (REFGLOBAL(PGlobals,fastDSPMode)) {
			CEQE0;
			OSWriteYRAM(8,1,0);
			OSWriteXRAM(8,1,0);
			OSWriteYRAM(2,1,3000);
			OSWriteXRAM(2,1,3000);
		}
#endif
		SETDATA;
		//if (REFGLOBAL(PGlobals,server))
		{
			long t0;
			RTRN1;
			OSSetTimerTicks(0,REFGLOBAL(PGlobals,rb).RetrainExpiration);
#ifdef SIMULATOR
			t0 = gTicks;
#endif
			while (RTRN) {
				if (OSTimerExpired(0)) {
					err = kConnectionLost;
					break;
				}
			}
#ifdef SIMULATOR
			printf("Took %ld seconds to retrain.\n", (gTicks-t0)/60);
#endif
		}
	}
	REFGLOBAL(PGlobals,lastEQMTime) = gTicks;
	REFGLOBAL(PGlobals,nextEQMTime) = gTicks + REFGLOBAL(PGlobals,rb).EQMPeriod;
	return err;
}

short _PUListenToLine(void)
{
	MODEMPTR;
	long timeout;
	
	OSToneMode();
	DTMFE1;
	OSDelayTicks(2,kDontCallSegaOSIdle);	// must wait min. of 30 ms. for tone filter to recognize tones.
	timeout = gTicks + REFGLOBAL(PGlobals,rb).BongListenTimeout;
	
	while (timeout > gTicks) {
		if (DTDET && (DTDIG == REFGLOBAL(PGlobals,rb).CWReceiveDTMFValue)) {
			return kRemoteCallWaitingErr;
		}
		if (!REFGLOBAL(PGlobals,disableCW) && TONEB)
		{
			long i;
			for (i=REFGLOBAL(PGlobals,rb).listenCWLoops; i>0; i--)
			{
				if (!TONEB)
					return 0;
			}
			return kCallWaitingErr;
		}
	}
	return 0;
}

// Disable call waiting on an outgoing call. We return whether or not
// we think we have disabled call waiting. If we think we did, then we
// don't hang up the phone. Otherwise, we return leaving the phone off
// the hook.

short _PUDisableCallWaiting( void )
{
	char *cwstr;
#ifndef __SERVER__
	// Phone has already been picked up by caller

	cwstr = GetSegaString( kCallWaitingDisable );
	if (PUDialNumber( cwstr ))
		return 1;
	if ( PUWaitDialTone(0,true /* continuous */) )
	{
		// No dialtone... hang up.
		PUHangUp();
		PUPickUp(0);
		return 1;
	}
#endif
	return noErr;
}


Ptr		_PGetDebugChatScript(long *size)
{
	*size = FifoAvailable(&REFGLOBAL(PGlobals,PHScrDebugFifo));
	return (Ptr)REFGLOBAL(PGlobals,PHScrDebugFifo).bufStart;
}

