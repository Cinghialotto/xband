/*
 *	$Id: PModemPriv.h,v 1.2 1995/05/10 11:04:15 jhsia Exp $
 *
 *	$Log: PModemPriv.h,v $
 * Revision 1.2  1995/05/10  11:04:15  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		PModemPriv.h

	Contains:	Macros and Defines for Rockwell Modem Hardware

	Written by:	Ted Cohn

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<44>	 8/28/94	HEC		Added leased line mode switch controllable by a dbconstant flag.
		<43>	 8/26/94	BET		Fix multiple definitions of TMTask
		<42>	 8/26/94	HEC		Added listenCWLoops to ringbusyrec.
		<41>	 8/24/94	BET		Add kChatDebugFifoSize stuff to DBConstants, make DEBUGCHAT
									happen all the time, add some robustness to the script
									navigators.
		<40>	 8/20/94	BET		Add DEBUGCHATSCRIPT stuff.
		<39>	 8/13/94	HEC		unsigned XDATA and YDATA.
		<38>	 8/11/94	SAH		(with BET) changed DEBUG to BUFFERDEBUG to solve Debugger
									problems on the sega.
		<37>	  8/3/94	BET		Add PHMaskFlag for connects that require bit filtering
		<36>	 7/31/94	HEC		Added serverTalk global flag.
		<35>	 7/28/94	HEC		Replaced overrunerr global flag with fastDSPMode switch.
		<34>	 7/24/94	HEC		Removed ancient spintimeout global.
		<33>	 7/23/94	HEC		Some globals are only for DEBUG.
		<32>	 7/22/94	BET		Add code to dial into "800 service".  Still need to go through
									and add all the database entries for portal service prompts and
									timeouts.  Also need to add code to figure which service to ask
									for based on the number we are dialing (search on 800 prefix?).
									Everything else is there.
		<31>	 7/20/94	HEC		Was not delaying after clearing modem registers, like other
									writes. Reduced delay on Sega to one nop since this is well over
									334ns required by Rockwell.
		<30>	 7/17/94	HEC		Fixed my goobers.
		<29>	 7/17/94	HEC		Added disableCWcount global.
		<28>	 7/16/94	HEC		Added globals for retrain, carrier.
		<27>	 7/15/94	HEC		Increased write delay.
		<26>	 7/15/94	HEC		Added nop's after writes to modem to fix modem hang problems.
		<25>	 7/15/94	SAH		Added overrunerr.
		<24>	 7/13/94	HEC		Increased spinloop timeout.
		<23>	 7/11/94	HEC		Added globals lastEQMTime, nextEQMTime, and spintimeouts.
									WHILE_TIMEOUT now works finally.
		<22>	 7/11/94	JBH		Remove SEGAOSIDLE from SPIN_TIMEOUT, as it is called at
									interrupt time, and we don't have a reentrant OS.
		<21>	  7/9/94	HEC		Added/subtracted some globals.
		<20>	  7/7/94	DJ		fixed SEGAOSIDLE for server
		<19>	  7/7/94	HEC		Added kNetworkCode to Delay calls.
		<18>	  7/6/94	HEC		Added RingBusyTimes struct. Moved timeout constants to
									DBConstants.h.
		<17>	  7/2/94	HEC		Made ModemPtr explicitly volatile to fix THINKC optimization
									which skips reading the actual hardware!
		<16>	  7/2/94	HEC		New server flag. Removed noanswer flag.  Added IOX register
									access.
		<15>	  7/1/94	KON		Change modem base address to slot E.
		<14>	 6/30/94	HEC		Added LL register macros.  Added SPIN_TIMEOUT macro (but isn't
									turned on yet). Reorganized timeout constants.  Added
									hangupTimeout global to reduce originate time.
		<13>	 6/21/94	HEC		Updates
		<12>	 6/21/94	BET		Check in those files!  This finally gets the modem running again
									on Fred2.
		<11>	 6/20/94	HEC		
		<10>	 6/20/94	BET		Add busy field.
		 <9>	 6/20/94	HEC		Mods for fred2 hardware
		 <8>	 6/19/94	BET		Add PHOpenLevel
		 <7>	 6/18/94	BET		Removed answerTimeout
		 <6>	 6/17/94	BET		Check in the changes that didn't get tested...
		 <5>	 6/17/94	HEC		Adding additional modem macros
		 <4>	 6/17/94	BET		It works again, archive this version
		 <3>	 6/14/94	HEC		New stuff!
		 <2>	 6/12/94	HEC		Version that works! First connect to server.
		 <1>	 6/11/94	HEC		first checked in
		 <3>	 6/10/94	HEC		Integrated into Physical layer.
		 <2>	  6/9/94	HEC		Fixing section that got wiped
		 <1>	  6/9/94	HEC		first checked in

	To Do:
*/

#ifndef __PModemPriv__
#define __PModemPriv__

#include "Time.h"
#include "GT.h"

#ifndef __HardDefines__
#include "HardDefines.h"
#endif

#ifndef __Fifo__
#include "Fifo.h"
#endif

#if defined(SIMULATOR) || defined(__SERVER__)
#ifndef __TIMER__
#include "Timer.h"
#endif
#endif

typedef unsigned char uchar;

#if defined(SIMULATOR) || defined(__SERVER__)

#define kModemBaseAddress	(0xFd000203)
#define MODEMPTR register ModemPtr modemPtr = REFGLOBAL(PGlobals,modemPtr)
#define MULT 16
#define kFIFOLENGTH 1
#define kNOP asm { nop } asm { nop } asm { nop } asm { nop } \
			 asm { nop } asm { nop } asm { nop } asm { nop }
#else

#define MODEMPTR \
	register FredPtr fredPtr = (FredPtr)gRegisterBase + 1;\
	register ModemPtr modemPtr = (ModemPtr)((long)fredPtr + 0x180)
#define MULT 2
#define kFIFOLENGTH 4
#define kNOP asm { nop }

#endif


#ifdef __SERVER__
#define SEGAOSIDLE
#else
#define SEGAOSIDLE SegaOSIdle( kNetworkCode );
#endif


// The following MACRO just prevents us from spinning forever waiting for a condition
// that may never happen.  It is up to the caller to detect whether the condition
// actually failed. In general, we expect the modem to respond to the condition.

#if 0
#define WHILE_TIMEOUT(_flag) while (_flag)
#else
#define WHILE_TIMEOUT(_flag) \
	{\
		long _timeout = GetCurrentTime()+60;\
		while (_flag) {\
			if (GetCurrentTime() > _timeout) {\
				ERROR_MESG("Oh Fuck. The modem died in a spinloop. Power-off and on again.");\
				break;\
			}\
		}\
	}
#endif

//
// Call Progress
//

#define kBusy			1
#define kRing			2

//
// CONF Register Modes
//

#define kV22bisMode		0x84
#define kV22Mode		0x52
#define kV21Mode		0xA0
#define kToneMode		0x80
#define kDialMode		0x81
#define kBell103Mode	0x60

//
// Baud Rates (SPEED Register Values)
//

#define k300Baud		0
#define k600Baud		1
#define k1200Baud		2
#define k2400Baud		3

typedef volatile uchar * ModemPtr;
typedef volatile uchar * FredPtr;

//
// Macros for accessing Fred registers
//

#define READ_FRED(_o) \
	(*(volatile FredPtr)(fredPtr + (_o)))

#define WRITE_FRED(_o,_v) \
	*(FredPtr)(fredPtr + (_o)) = (_v)


//
// Macros for accessing modem registers
//

// GET SUBREGISTER VALUE
#define GET_REG(_o,_b,_m) \
	((*(volatile ModemPtr)(modemPtr + (_o)*MULT) >> (_b)) & (_m))

// SET SUBREGISTER VALUE
#define SET_REGVAL(_o,_b,_m,_x) \
	*(modemPtr + (_o)*MULT) = (*(modemPtr + (_o)*MULT) & ~((_m)<<(_b))) | ((_x)<<(_b)); kNOP

// SET REGISTER TO 1
#define ONE_REG(_o,_b) \
	*(modemPtr+(_o)*MULT) |= (1<<(_b)); kNOP


// CLEAR REGISTER TO 0
#define ZERO_REG(_o,_b) \
	*(modemPtr+(_o)*MULT) &= ~(1<<(_b)); kNOP

// READ REGISTER VALUE
#define READ_REG(_o) \
	*(volatile ModemPtr)(modemPtr+(_o)*MULT)

// WRITE REGISTER VALUE
#define WRITE_REG(_o,_x) \
	*(modemPtr + (_o)*MULT) = (_x); kNOP

//
// SET REGISTERS
//

#define ASYNC1			ONE_REG(8,7)
#define NV25_1			ONE_REG(9,6)
#define CC1				ONE_REG(9,6)
#define CEQE1			ONE_REG(5,3)
#define CTS1			ONE_REG(15,5)
#define DSR1			ONE_REG(15,4)
#define SETCONF(_x)		WRITE_REG(0x12,_x)
#define DATA1			ONE_REG(9,2)
#define DTMF1			ONE_REG(9,5)
#define DTMFE1			ONE_REG(5,6)
#define GTE1			ONE_REG(3,1)
#define IOX1			ONE_REG(0x1d,3)
#define L2ACT1			ONE_REG(7,5)
#define L3ACT1			ONE_REG(7,3)
#define LL1				ONE_REG(9,3)
#define NEWC1			ONE_REG(0x1F,0)
#define ORG1			ONE_REG(9,4)
#define RA1				ONE_REG(7,1)
#define RLSD1			ONE_REG(15,7)
#define RTS1			ONE_REG(8,0)
#define RTRN1			ONE_REG(8,1)
#define SLEEP1			ONE_REG(9,0)
#define SWRES1			ONE_REG(4,6)
#define SETTBUFFER(_x)	WRITE_REG(0x10,_x)
#define TPDM1			ONE_REG(8,6)
#define TRFZ1			ONE_REG(8,3)
#define SETWDSZ(_x)		SET_REGVAL(6,0,3,_x)
#define XACC1			ONE_REG(0x1D,7)
#define YACC1			ONE_REG(0x1B,7)
#define XWT1			ONE_REG(0x1D,1)
#define YWT1			ONE_REG(0x1B,1)
#define XCR1			ONE_REG(0x1D,0)
#define YCR1			ONE_REG(0x1B,0)
#define SETXADDR(_x)	WRITE_REG(0x1C,_x)
#define SETYADDR(_x)	WRITE_REG(0x1A,_x)
#define SETXDATA(_x)	WRITE_REG(0x18,(_x)); WRITE_REG(0x19,((_x)>>8))
#define SETYDATA(_x)	WRITE_REG(0x16,(_x)); WRITE_REG(0x17,((_x)>>8))
#define SETTLVL(_x)		SET_REGVAL(0x13,4,0xf,_x)
#define SETVOL(_x)		SET_REGVAL(0x13,2,3,_x)

//
// CLEAR REGISTERS
//

#define ASYNC0			ZERO_REG(8,7)
#define NV25_0			ZERO_REG(9,7)
#define CC0				ZERO_REG(9,6)
#define CEQE0			ZERO_REG(5,3)
#define CTS0			ZERO_REG(15,5)
#define DSR0			ZERO_REG(15,4)
#define DATA0			ZERO_REG(9,2)
#define DTMF0			ZERO_REG(9,5)
#define GTE0			ZERO_REG(3,1)
#define IOX0			ZERO_REG(0x1d,3)
#define L2ACT0			ZERO_REG(7,5)
#define L3ACT0			ZERO_REG(7,3)
#define LL0				ZERO_REG(9,3)
#define NEWS0			ZERO_REG(0x1F,3)
#define ORG0			ZERO_REG(9,4)
#define RA0				ZERO_REG(7,1)
#define RLSD0			ZERO_REG(0xF,7)
#define RTS0			ZERO_REG(8,0)
#define RTRN0			ZERO_REG(8,1)
#define SLEEP0			ZERO_REG(9,0)
#define SWRES0			ZERO_REG(4,6)
#define TPDM0			ZERO_REG(8,6)
#define TRFZ0			ZERO_REG(8,3)
#define XCR0			ZERO_REG(0x1D,0)
#define YCR0			ZERO_REG(0x1B,0)
#define XWT0			ZERO_REG(0x1D,1)
#define YWT0			ZERO_REG(0x1B,1)
#define OE0				ZERO_REG(0xE,3)
#define FE0				ZERO_REG(0xE,4)
#define PE0				ZERO_REG(0xE,5)

//
// STATUS
//

#define ASYNC			GET_REG(8,7,1)
#define ATBELL			GET_REG(0xB,3,1)
#define ATV25			GET_REG(0xB,4,1)
#define BEL103			GET_REG(0xB,0,1)
#define CC				GET_REG(9,6,1)
#define CEQE			GET_REG(5,3,1)
#define CONF			READ_REG(0x12)
#define CTS				GET_REG(0xF,5,1)
#define DSR				GET_REG(0xF,4,1)
#define DATA			GET_REG(9,2,1)
#define DTMF			GET_REG(9,5,1)
#define DTDET			GET_REG(0xB,1,1)
#define DTDIG			GET_REG(0xC,0,0xf)
#define EDET			GET_REG(0xC,7,1)
#define FE				GET_REG(0xE,4,1)
#define GTE				GET_REG(3,1,1)
#define IOX				GET_REG(0x1d,3,1)
#define L2ACT			GET_REG(7,5,1)
#define L3ACT			GET_REG(7,3,1)
#define LL				GET_REG(9,3,1)
#define NEWC			GET_REG(0x1F,0,1)
#define NEWS			GET_REG(0x1F,3,1)
#define ORG				GET_REG(9,4,1)
#define OE				GET_REG(0xE,3,1)
#define PARSL			GET_REG(6,4,3)
#define PE				GET_REG(0xE,5,1)
#define PEN				GET_REG(6,3,1)
#define RA				GET_REG(7,1,1)
#define RB				GET_REG(7,2,1)
#define RBUFFER			READ_REG(0)
#define RDBF			GET_REG(0x1E,0,1)
#define RI				GET_REG(0xF,3,1)
#define RLSD			GET_REG(0xF,7,1)
#define RTDET			GET_REG(0xE,7,1)
#define RTS				GET_REG(8,0,1)
#define RTRN			GET_REG(8,1,1)
#define SADET			GET_REG(0xD,2,1)
#define SLEEP			GET_REG(9,0,1)
#define SPEED			GET_REG(0xE,0,7)
#define STB				GET_REG(6,2,1)
#define SWRES			GET_REG(4,6,1)
#define TDBE			GET_REG(0x1E,3,1)
#define TONEA			GET_REG(0xB,7,1)
#define TONEB			GET_REG(0xB,6,1)
#define TONEC			GET_REG(0xB,5,1)
#define TPDM			GET_REG(8,6,1)
#define U1DET			GET_REG(0xD,3,1)
#define SCR				GET_REG(0xD,4,1)
#define S1DET			GET_REG(0xD,5,1)
#define WDSZ			GET_REG(6,0,3)
#define XACC			GET_REG(0x1D,7,1)
#define YACC			GET_REG(0x1B,7,1)
#define VOL				GET_REG(0x13,2,3)
#define XDATA			((unsigned long)(READ_REG(0x18)&0xFF) | (unsigned long)(READ_REG(0x19)<<8))
#define YDATA			((unsigned long)(READ_REG(0x16)&0xFF) | (unsigned long)(READ_REG(0x17)<<8))

//
// Useful Macros
//

#define NEWCONF \
	NEWC1; \
	WHILE_TIMEOUT(NEWC)

#define SETV22BIS \
	SETCONF(kV22bisMode); NEWCONF

#define SETTONE \
	SETCONF(kToneMode); NEWCONF; DelayMS(32,kNetworkCode)

#define SETDATA \
	DATA1; NEWCONF

#define CLEARDATA \
	DATA0; NEWCONF

#define SETDIAL \
	SETCONF(kDialMode); NEWCONF; DelayMS(32,kNetworkCode)

#define TIMEREXPIRED \
	(REFGLOBAL(PGlobals,timer) <= GetCurrentTime())

#define RESET \
	SWRES1; WHILE_TIMEOUT (SWRES)

/* some magic serial line tokens */
#define	kConnectToken		0xae

//#define kPhysBufferSize (kADSPMinPktSiz*kMaxPacket*2)	// size of data buffer HACK! the 2x multiplier is a test
#define	kMaxFrames 400									// maximum number of frames that can be indexed
#define	kFrameStartBufSiz kMaxFrames*sizeof(short)		// size of buffer for framestarts

#define kMagicVal 'BET!'
#define CHECKMAGIC(a) { if (a->PHMagic != kMagicVal) ASSERT_MESG(0, "PH Globals are bad!"); }

#define kRWTimeDelay	3

typedef struct {
	long	ringtimer;
	short	ringOnTimeMin;
	short	ringOnTimeMax;
	short	ringOffTimeMin;
	short	ringOffTimeMax;
	short	busyOnTimeMin;
	short	busyOnTimeMax;
	short	busyOffTimeMin;
	short	busyOffTimeMax;	
	short	ringontime;
	short	BongListenTimeout;
	short	EQMThreshold;
	short	EQMPeriod;
	short	PreCWNoNoisePeriod;
	short	CWDTMFPeriod;
	short	LostRLSDPeriod;
	short	RetrainExpiration;
	short	listenCWLoops;
	char	CWReceiveDTMFValue;
	char	CWSendDTMFValue;
} RingBusyRec;

typedef struct PGlobalType {
	RDS						*PHReadyBuffer;				// buffer that we are primed to put stuff into
	RDS						*PHFilledBuffer;			// buffer that we already put stuff into
	short					PHPacketState;				// state of the current packet (in framing, etc.)
	unsigned short			PHFrameSizAccum;			// accumulator for current frame length
	Fifo					PHLengthsFifo;				// fifo of packet lengths
	unsigned char			*PHLengthsBuf;				// buffer for the lengths
	Fifo					PHReadFifo;					// fifo information for physical fifo
	unsigned char			*PHReadDataBuf;				// circular buffer space
	Fifo					PHWriteFifo;				// fifo information for physical fifo
	unsigned char			*PHWriteDataBuf;			// circular buffer space
	unsigned char			*PHStagingBuf; 				// circular buffer space
	unsigned long			PHTotal;					// sum of bytes passed
	Boolean					PHWriteActive;				// signals outstanding Async IO
	Boolean					PHIndicating;				// PNetIdle is already threading an indication
	Boolean					PHFramingDisabled;			// Set to disable frame detection
	Boolean					pad;						// Do YOU trust the compiler?
	short					PHConnState;				// state of connection
	short					PHGameFifoR;				// read pointer of game fifo
	short					PHGameFifoW;				// write pointer of game fifo
	short					PHLastError;				// last error that occured in this manager
	short					PHOpenLevel;				// number of open links
	long					*PHGameFifoBuf;				// buffer for actual data
	long					PHMagic;					// magic cookie
	unsigned char			PHCharMask;					// mask for incoming chars.  Strip parity on X.25
#if defined(SIMULATOR) || defined(__SERVER__) 
	TMInfo					PHReadTimeTask;
	TMInfo					PHWriteTimeTask;
#else
	TimeProcRef				PHReadTimeRef;				// Time Manager request for read service
	TimeProcRef				PHWriteTimeRef;				// Time Manager request for write service
#endif
	
	// Modem specific globals
	
	unsigned 				offtoon:1;					// should be a local somewhere
	unsigned 				lastdet:1;					// should be a local somewhere
	unsigned 				server:1;					// whether the last ringing was a busy
	unsigned 				fastDSPMode:1;				// server-overridable fast dsp mode switch on peer-to-peer
	unsigned 				leasedline:1;				// server-overridable leased line mode switch on peer-to-peer
	unsigned 				disableCW:1;				// set if call waiting has been disabled
	unsigned 				rlsdstate:1;				// set if carrier is currently on
	unsigned				PHPacketParseActive:1;		// set if we should parse packets
	unsigned				PHCallbackSema:1;
	unsigned				serverTalk:1;				// clear when gametalk in use
	RingBusyRec				rb;
	long					timer[4];
	long					hangupTime;					// Timestamp of last hang up.
	ModemPtr				modemPtr;					// pointer to modem registers
	short					POpenState;					// Set when PModem is open
	long					lastEQMTime;
	long					nextEQMTime;
	long					lostrlsdtime;
#ifdef BUFFERDATA
	Fifo					testRead;
	Fifo					testWrite;
#endif
	Fifo					PHScrDebugFifo;
	unsigned short			chatDebugFifoSize;
	
	// variables below this are not clear at softinitialize

	unsigned char			disableCWCounter;
} PGlobalType;

#ifdef	SIMULATOR
#define	MANAGERGLOBALTYPE PGlobalType
#else
PGlobalType PGlobals;
#endif


#endif __PModemPriv__

