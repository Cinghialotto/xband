/*
 *	$Id: LoadCPE.c,v 1.2 1995/05/10 11:03:53 jhsia Exp $
 *
 *	$Log: LoadCPE.c,v $
 * Revision 1.2  1995/05/10  11:03:53  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		LoadCPE.c

	Contains:	xxx put contents here xxx

	Written by:	Konstantin Othmer

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <9>	 7/23/94	JOE		don't #include "LoadCPE.h"
		 <8>	 6/28/94	BET		Is this thing even used any more?  Update it for error returns
									anyways...
		 <7>	  6/5/94	KON		Remove stale CPE routine.
		 <6>	  6/3/94	DJ		updating to revised DrawDBGraphic call
		 <5>	 5/31/94	SAH		Killed SegaMisc.h.
		 <4>	 5/29/94	KON		Now uses the graphics database.
		 <3>	 5/26/94	BET		Update for managerized Disk Transport.
		 <2>	 5/26/94	BET		Remove obsolete refs to GameTalk.h
		 <5>	 5/24/94	KON		Update to call generic getdata routine rather than assuming
									network data.
		 <4>	 5/20/94	SAH		Updated call to LinearizeScreenArea.
		 <3>	 5/18/94	HEC		Changing FlushPatterns to InitPatternManager
		 <2>	 5/17/94	KON		Update to use SetFontColors call.

	To Do:
*/

#include "SegaBM.h"
#include "SegaVDP.h"
#include "vdp.h"
#include "sega.h"
#include "SegaScrn.h"
#include "Intro.h"
#include "SegaText.h"
#include "SegaIn.h"
//#include "LoadCPE.h"
#include "TransportLayer.h"
#include "GetData.h"
#include "GraphicsDB.h"


/* Download CPEFile gets called when serial traffic starts...
**
** If we don't receive a valid header, return with an error.
** If the header is valid, download the file and return success.
**
** NOTE: The byte count is thrown away for now...
*/
short DownloadCPEFile( )
{
char	theChar;
Ptr		targetAddress;
short	charsReceived;
char	header[6] = { 0x43, 0x50, 0x45, 0x01, 0x08, 0x00 };
long	targetCount;
OSErr	err;

/****
6 bytes: 43 50 45 01 08 00
Then for every segment:
1 byte of 01,
long little endian address, 
long little endian count (1-based), 
count data bytes

at the end:
1 byte of 00
*****/
	
//
// Check the header as it comes...
//
	charsReceived = 0;
	while( 1 )
	{
		theChar = TReadAByte();
		err = TNetError();
		if (err)
			return err;
		if( theChar != header[charsReceived] )
			return	-1;
		
		charsReceived++;
	}
//
// Header came through ok. Download the file
//
	
	while( 1 )
	{
		theChar = TReadAByte();
		err = TNetError();
		if (err)
			return err;
		if( theChar == 0 )
			return 0;			//successfully terminated
			
		if( theChar != 0x01 )
			return -2;			// expected a 01 here...

		charsReceived++;
			
//
// Get the little indian address
//	
		targetAddress = (Ptr)GetLittleEndianLong();
//
// Get the little indian long word count
//
		targetCount = GetLittleEndianLong();
		charsReceived += 4;

//
// Load the shit
//
		while( targetCount-- )
		{
			*targetAddress++ = TReadAByte();
			err = TNetError();
			if (err)
				return err;
			charsReceived++;
			if( charsReceived & 0x1F )
			{
				// Give feedback!
			}
		}
	}
}

long GetLittleEndianLong( void )
{
char	buffer[sizeof(long)];
short	buffIndex;

	if (TReadData(sizeof(long), buffer, false))
		return 0;

	return ( buffer[3]<<24 + buffer[2]<<16 + buffer[1]<<8 + buffer[0] );

}
