/*
 *	$Id: fifo.h,v 1.2 1995/05/10 11:04:39 jhsia Exp $
 *
 *	$Log: fifo.h,v $
 * Revision 1.2  1995/05/10  11:04:39  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		fifo.h

	Contains:	xxx put contents here xxx

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<10>	 8/13/94	BET		Add FifoPeekEnd.
		 <9>	 7/18/94	ADS		Remove unused placeholder
		 <8>	 7/18/94	DJ		ifdef serverized
		 <7>	 7/17/94	ADS		Manager-ize
		 <6>	 7/13/94	BET		unix-ise.
		 <5>	 6/19/94	BET		Change and add interfaces
		 <4>	 6/15/94	BET		Change interface to FifoUnwrite
		 <3>	 5/31/94	BET		Changed (char *)'s to (unsigned char *)
		 <2>	 5/29/94	BET		Change an interface
		 <3>	 5/24/94	BET		Add fifo pointer locking via setIntr() and resetIntr()
		 <2>	 5/18/94	BET		fix a hasty
		 <1>	 5/18/94	BET		first checked in

	To Do:
*/

// ===========================================================================
//	fifo.h					�1994 Brian Topping All rights reserved.
// ===========================================================================

#ifndef __Fifo__
#define __Fifo__

#ifdef unix
#include "NetTypes.h"
#endif


#define kCircularQMask	0x80
enum {
	kUnusedQ			= 0x00,						// unused Q marker
	kFlatQ				= 0x01,						// unrestricted r/w flat
	kChokingQ			= 0x02,						// restricted r/w flat
	kCircularQ			= 0x83,						// unrestricted circular
	kCachingQ			= 0x84						// unrestricted circular caching
};

// the alternative to this is to make a guard band of one byte, but on a one
// byte queue on a unexpecting buffer, this doesn't work.  Picky, I know, 
// but it happens in GameTalk.
#define kFifoHasDataFlagMask 1
#define SETFIFOHASDATA(f) (f->flags |= kFifoHasDataFlagMask)
#define SETFIFONODATA(f) (f->flags &= ~kFifoHasDataFlagMask)
#define GETFIFOHASDATA(f) (f->flags & kFifoHasDataFlagMask)

typedef struct Fifo {
	unsigned char		qType;						// type of this Q
	unsigned char		flags;						// flags
	unsigned char		*input;						// where we add to the buffer
	unsigned char		*output;					// where we read from in this buffer
	unsigned char		*cache;						// data already read but not flushed
	unsigned char		*bufStart;					// beginning of the buffer
	unsigned char		*bufEnd;					// end of the buffer
	unsigned long		consumption;				// resettable accumulator
	} Fifo;



/*
* BRAIN DAMAGE (7/18/94 ADS): we need to compile this seperately for the server and the sega/simulator build.
* The sega goes through the dispatcher, the server needs to call the functions directly.
* Having two definitions is gross, but I didn't know any other way to do it.
*/

/*
*	(7/18/94 ADS) Due to the late hour of this file's vectorization, and its complete lack of
*	globals, this manager is stealing space from TransportLayer.c.  I suppose it
*	would be a good idea to put it in its own manager eventually.  I'm just being
*	a slacker....
*/


					// set up a fifo
	void			_FifoInit(Fifo *f, unsigned char *bufStart, unsigned long length, short type);
					// is the fifo active?
	Boolean			_FifoActive(Fifo *f);
					// write some data to the fifo
	OSErr			_FifoWrite(Fifo *f, unsigned char *inBuf, unsigned long length);
					// read some data from the fifo
	OSErr			_FifoRead(Fifo *f, unsigned char *outBuf, unsigned long length);
					// look at the first data in the fifo, but don't remove it
	OSErr			_FifoPeek(Fifo *f, unsigned char *outBuf, unsigned long length);
					// look at the last data in the fifo, but don't remove it
	OSErr			_FifoPeekEnd(Fifo *f, unsigned char *outBuf, unsigned long length);
					// how much is available to read from the fifo
	unsigned long	_FifoAvailable(Fifo *f);
					// how much is available for us to write into the fifo
	unsigned long	_FifoRemaining(Fifo *f);
					// skip some bytes
	OSErr			_FifoSkip(Fifo *f, unsigned long skip);
					// fifo to fifo copy
	OSErr 			_FifoCopy(Fifo *src, Fifo *dest, unsigned long length);
					// checksum fifo in buffer
	unsigned short	_FifoChkSum(Fifo *f, unsigned long length);
					// get pointer to next input character in the fifo
	unsigned char *	_GetFifoIn(Fifo *f, unsigned long length, Boolean doIncr);
					// get do a LIFO on the last character
	unsigned char	_FifoLastCharIn(Fifo *f);
					// dump the last character that came in
	OSErr			_FifoUnwrite(Fifo *f, unsigned long length);
					// size of the fifo
	unsigned long	_FifoSize(Fifo *f);
					// clear saved bytes from a caching queue
	OSErr			_FifoFlush(Fifo *f, unsigned long length);
					// move back to cached data
	OSErr			_FifoUnread(Fifo *f, unsigned long length);
					// reset consumption field
	OSErr			_FifoResetConsumption(Fifo *f);
					// adjust for consumption
	OSErr			_FifoAdjustConsumption(Fifo *f, unsigned long amount);


#ifdef __SERVER__
					
#define	FifoInit(f, a, b, c)			_FifoInit( f, a, b, c )
#define	FifoActive(f)					_FifoActive( f )
#define	FifoWrite(f, a, b)				_FifoWrite( f, a, b )
#define	FifoRead(f, a, b)				_FifoRead( f, a, b )
#define	FifoPeek(f, a, b)				_FifoPeek( f, a, b )
#define	FifoPeekEnd(f, a, b)			_FifoPeekEnd( f, a, b )
#define	FifoAvailable(f)				_FifoAvailable( f )
#define	FifoRemaining(f)				_FifoRemaining( f )
#define	FifoSkip(f, a)					_FifoSkip( f, a )
#define	FifoCopy(f, a, b)				_FifoCopy( f, a, b )
#define	FifoChkSum(f, a)				_FifoChkSum( f, a )
#define	GetFifoIn(f, a, b)				_GetFifoIn( f, a, b )
#define	FifoLastCharIn(f)				_FifoLastCharIn( f )
#define	FifoUnwrite(f, a)				_FifoUnwrite( f, a )
#define	FifoSize(f)						_FifoSize( f )
#define	FifoFlush(f, a)					_FifoFlush( f, a )
#define	FifoUnread(f, a)				_FifoUnread( f, a )
#define	FifoResetConsumption(f)			_FifoResetConsumption( f )
#define	FifoAdjustConsumption(f, a)		_FifoAdjustConsumption( f, a )

#else

#ifndef __Dispatcher__
#include "Dispatcher.h"
#endif

	void			FifoInit(Fifo *f, unsigned char *bufStart, unsigned long length, short type) =
						CallDispatchedFunction( kFifoInit );
						
	Boolean			FifoActive(Fifo *f) =
						CallDispatchedFunction( kFifoActive );

	OSErr			FifoWrite(Fifo *f, unsigned char *inBuf, unsigned long length) =
						CallDispatchedFunction( kFifoWrite );

	OSErr			FifoRead(Fifo *f, unsigned char *outBuf, unsigned long length) =
						CallDispatchedFunction( kFifoRead );

	OSErr			FifoPeek(Fifo *f, unsigned char *outBuf, unsigned long length) =
						CallDispatchedFunction( kFifoPeek );

	OSErr			FifoPeekEnd(Fifo *f, unsigned char *outBuf, unsigned long length) =
						CallDispatchedFunction( kFifoPeekEnd );

	unsigned long	FifoAvailable(Fifo *f) =
						CallDispatchedFunction( kFifoAvailable );

	unsigned long	FifoRemaining(Fifo *f) =
						CallDispatchedFunction( kFifoRemaining );

	OSErr			FifoSkip(Fifo *f, unsigned long skip) =
						CallDispatchedFunction( kFifoSkip );

	OSErr 			FifoCopy(Fifo *src, Fifo *dest, unsigned long length) =
						CallDispatchedFunction( kFifoCopy );

	unsigned short	FifoChkSum(Fifo *f, unsigned long length) =
						CallDispatchedFunction( kFifoChkSum );

	unsigned char *	GetFifoIn(Fifo *f, unsigned long length, Boolean doIncr) =
						CallDispatchedFunction( kGetFifoIn );

	unsigned char	FifoLastCharIn(Fifo *f) =
						CallDispatchedFunction( kFifoLastCharIn );

	OSErr			FifoUnwrite(Fifo *f, unsigned long length) =
						CallDispatchedFunction( kFifoUnwrite );

	unsigned long	FifoSize(Fifo *f) =
						CallDispatchedFunction( kFifoSize );

	OSErr			FifoFlush(Fifo *f, unsigned long length) =
						CallDispatchedFunction( kFifoFlush );

	OSErr			FifoUnread(Fifo *f, unsigned long length) =
						CallDispatchedFunction( kFifoUnread );

	OSErr			FifoResetConsumption(Fifo *f) =
						CallDispatchedFunction( kFifoResetConsumption );

	OSErr			FifoAdjustConsumption(Fifo *f, unsigned long amount) =
						CallDispatchedFunction( kFifoAdjustConsumption );


#endif





#endif __Fifo__


