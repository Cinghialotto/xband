/*
 * $Id: TransportLayer.c,v 1.7 1996/01/30 21:40:04 fadden Exp $
 *
 * $Log: TransportLayer.c,v $
 * Revision 1.7  1996/01/30  21:40:04  fadden
 * steveb: fixed _TWriteDataASync so that it doesn't call TAsyncWriteFifoData
 *  constantly with no data to write.
 * fadden: added TUSleepIO and TUGetMinTimer to prevent TAsyncWriteFifoData
 *  from spinning on the CPU when waiting for the box to become writable.  Added
 *  comments [ in brackets ] with my understanding of existing code.
 *
 * Revision 1.6  1996/01/30  01:35:26  fadden
 * Set gTLayerReading in TListen so we don't spin.
 *
 * Revision 1.5  1995/09/13  10:47:18  ted
 * Fixed warnings.
 *
 * Revision 1.4  1995/07/13  19:15:54  fadden
 * Added a NULL-pointer check inside _TSetTransportHold.  Somehow we ended
 * up with a few core dumps featuring:
 *   print TGlobals
 *   {TSessionList = 0x0, TCurrentSession = 0x0, lastTransportError = -408,
 *    TMagic = 1111839777}
 *
 * This was during the inetd fail-a-thon.
 *
 * Revision 1.3  1995/05/10  11:04:29  jhsia
 * switch to cvs keywords
 *
 */

#ifndef DEBUG
#define DEBUG
#endif



/*
	File:		TransportLayer.c

	Contains:	GameTalk session layer

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<95>	  9/1/94	DJ		add comments to the <94> fix.  It does indeed fix the problem.
									yay.
		<94>	  9/1/94	DJ		TNetError now checks the existing errors (TGetError) before
									calling TNetIdle.  This is an attempt to fix the cleared patch
									problem.
		<93>	 8/25/94	BET		Looks like the quick timeout problem had some code associated
									with it also.  Mostly just check to see if timer is set before
									comparing to it.
		<92>	 8/25/94	SAH		Kill NEWERRORS.
		<91>	 8/25/94	BET		When NEWERRORS is defined, call INCRCOMMERROR on the retrans
									field.
		<90>	 8/24/94	BET		Fix TClose so it returns an error when TOpen fails and
									FindOpponent calls TClose anyways.
		<89>	 8/21/94	BET		Move s->tickleCount = 0 in TUUpdateSessionInfo to only occur if
									the packet is in sequence.
		<88>	 8/21/94	BET		Cock sucker muther fucker eat a bag of shit.
		<87>	 8/21/94	BET		Add code to TClose to ignore errors and close the fucker.  Also
									remove TNetIdle check to make sure all data has been sent, this
									may screw the server (we'll see soon...)
		<86>	 8/16/94	BET		Add some error checking to TUInitSessRec.
		<85>	 8/15/94	BET		Make TSetTransportHoldSession(true) do a NetIdle to get jizz
									flowing after a wait.
		<84>	  8/8/94	BET		Update buffer sizes to use single constant.
		<83>	  8/8/94	BET		Don't return kNotASession, just dump the packet by returning
									noErr.
		<82>	  8/6/94	DJ		uncleared errors are warnings now
		<81>	  8/4/94	BET		Shannon said "Fucker Fucker Fucker".
		<80>	  8/3/94	BET		Fix FifoHold stuff.
		<79>	  8/3/94	BET		Include DBConstants.h
		<78>	  8/1/94	HEC		Removed protos for obsolete routines.
		<77>	 7/30/94	HEC		Do PCheckError and TCheckError in T[Open][Listen]Async.
		<76>	 7/29/94	DJ		fixed TCheckError to clear errors
		<75>	 7/29/94	BET		Add check to TCloseAsync to see if the state is already
									kKonClosing.  Also, if the TUSetError already has a sticky
									error, don't set a new one.
		<74>	 7/29/94	BET		Add PCheckError to all physical layer calls that return an error
									before setting the error into TUSetError.
		<73>	 7/29/94	BET		Add a CheckError call to TClose. If there _are_ errors that the
									client has not unsuck before calling in, they should not stop
									the close from happening.
		<72>	 7/28/94	BET		Add TUnthread call to TOpen and TListen in error case.
		<71>	 7/25/94	DJ		mod to proto for transporthold
		<70>	 7/25/94	DJ		added T[SG]etTransportHoldSession
		<69>	 7/25/94	BET		Make TAsyncWriteFifoData check for remoteRemaining more safely.
									Great bug Dave!
		<68>	 7/25/94	BET		Add T[GS]etTransportHold calls.  This code hints the transport
									layer on whether it needs to flush data as it is TWritten or
									whether it is guaranteed more is coming shortly.
		<67>	 7/19/94	DJ		moved transportlayer.h to first include (neede for metrowerks)
		<66>	 7/19/94	BET		Add macros for header field access on the Stun, which cannot
									read unalingned longs.
		<65>	 7/16/94	dwh		Add #ifndef NULL.  (BET: do we really need this here?)
		<64>	 7/14/94	BET		Fix the resend fucker.
		<63>	 7/13/94	BET		unix-ise.
		<62>	 7/12/94	DJ		TUSetError now returns the OSErr you set.  Also I made a bunch
									of invalid Session errors sticky.
		<61>	 7/10/94	BET		Fixed the fix.
		<60>	  7/8/94	DJ		fixed timeout in TListen
		<59>	  7/7/94	HEC		Added #include "BoxSer.h" for DBGetConstant()
		<58>	  7/7/94	BET		Serverize DB timeouts
		<57>	  7/6/94	BET		Move retry timeouts to database.
		<56>	  7/6/94	BET		TClose when link is closed already.
		<55>	  7/6/94	BET		Remove sticky error checks from NetIdle procs, maybe some other
									jizz.
		<54>	  7/5/94	BET		Listen timeout polarity was backwards, instant timeouts!
		<53>	  7/5/94	BET		Add listen timeouts
		<52>	  7/5/94	BET		Change TIndication to also look for kConnClosed when looking for
									closed physical layer.
		<51>	  7/4/94	DJ		added TUGetError and removed lastError in SessionRec
		<50>	  7/4/94	BET		Change TUSetError to _TUSetError to match headers.
		<49>	  7/3/94	BET		Set global error state along with session error state.
		<48>	  7/3/94	DJ		better error propogation esp from TUnthread
		<47>	  7/3/94	BET		Fix a problem when multiple resends caused confusion on the
									reciever.
		<46>	  7/1/94	BET		Add code to check if link is down on TOpen/TListen and bail if
									so.
		<45>	 6/30/94	BET		Change kSync to kSynch.
		<44>	 6/30/94	BET		Code review dust bunny cleanup, fix some problems found with the
									Timmer test framework.  
		<43>	 6/29/94	BET		Add timeout stuff, rework tickles in the process, rework
									interfaces for bytesready procs to return OSErr's, more cheeze.
		<42>	 6/28/94	DJ		made GetCurrentTime work for StinkC
		<41>	 6/28/94	BET		Bring the little jizzlers back.
		<40>	 6/21/94	BET		Fix a rare bug where the connID can be set to zero based on the
									clock.  Simply loop until the clock changes.
		<39>	 6/20/94	BET		Revert the error changes.  They are not going to be done in time
									for CES.
		<38>	 6/19/94	BET		Added first round of Dave's error checking scheme.
		<37>	 6/18/94	BET		Restore Ted's state information to NetParamBlock.
		<36>	 6/18/94	BET		Close dialogue changes.
		<35>	 6/17/94	BET		Open dialogue changes
		<34>	 6/16/94	BET		Revert Ted's changes.
		<33>	 6/15/94	BET		Fix retrans.
		<32>	 6/15/94	HEC		Uses new ioPhysState
		<31>	 6/15/94	BET		Rinsed everything off.
		<30>	 6/15/94	BET		Piss yellow liquid all over the cum stained source.
		<29>	 6/14/94	BET		Add CloseAck packets and states.  This allows a handshaked close
									with both peers fully purged.  Not tested yet under actual
									conditions.
		<28>	 6/13/94	BET		Add first round of opening dialog retrans stuff
		<27>	 6/11/94	BET		I thought I checked this in earlier.  Make TOpen and TListen
									call PNetIdle instead of NetIdle, which calls TNetIdle.  This
									avoids waiting packets from being processed if we are not ready
									yet.
		<26>	 6/10/94	BET		Check in the changes I was working on properly.
		<25>	 6/10/94	BET		Fuckin heat
		<24>	  6/9/94	BET		Forgot to managerize the new API!
		<23>	  6/9/94	BET		Change interfaces to do async open and listen.
		<22>	  6/5/94	BET		Update the Button() abort connection opening to actually clean
									up after itself.
		<21>	  6/5/94	BET		Fuck that!-)
		<20>	  6/4/94	DJ		Shannon, stop checking things in with the comment "fuck".
		<19>	  6/3/94	SAH		(BET) Merge changes for ageS.
		<18>	  6/3/94	BET		Set up TMagicVal before letting the init roam too far
		<17>	  6/3/94	BET		Add more FUD
		<16>	  6/2/94	SAH		Add utils.h
		<15>	  6/2/94	BET		Change the way globals are accessed
		<14>	  6/1/94	BET		Fix some late arrivals
		<13>	  6/1/94	BET		Fix a problem with remoteRemaining going negative in
									PUFifoWriteAsync
		<12>	 5/31/94	BET		add time.h for sega builds
		<11>	 5/31/94	BET		Add a change for even-aligning higher level         protocols.
									Last checkin wasn't quite enough.  Also macro up GetCurrentTime
									for server builds
		<10>	 5/31/94	BET		Add stuff to keep word fields on even addresses
		 <9>	 5/31/94	SAH		Fixed some compile errors.
		 <8>	 5/31/94	BET		Remove a calls to Random, IfDEBUGStr, and Tickx.  This isn't a
									Mac, after all!
		 <7>	 5/31/94	BET		Changed (char *)'s to (unsigned char *) for Fifo.c changes.
		 <6>	 5/29/94	BET		Fix up for CRC
		 <5>	 5/27/94	BET		Remove refs to old global types
		 <4>	 5/27/94	BET		Fix a return value in TReadAByte
		 <3>	 5/27/94	SAH		The non simulator build needed access to the control function -
									added a __SERVER__ ifdef.
		 <2>	 5/26/94	BET		Add NetError
		 <1>	 5/26/94	BET		first checked in
		 <2>	 5/25/94	BET		Fix a checkin messup
		 
		 Previous checkin comments
		 <3>	 5/25/94	BET		Fix send window not being set properly in ConnOpenReqAck packet
		 <2>	 5/25/94	BET		Fix peer hang on close
		 <5>	 5/24/94	BET		Fixed a fifo overflow in phys layer by bounding the amount we
									tell the session peer is available to kBufferSize/2.  Also fix a
									flow problem when the sender tells that he is out of space, but
									doesn't clear the block until the timeout.
		 <2>	 5/23/94	BET		Fix a goodies screwup
		 <1>	 5/22/94	BET		first checked in
		 <3>	 5/19/94	BET		Fix a re-entrancy problem in PNetIdle
		 <2>	 5/18/94	BET		update for changes

	To Do:
*/

#include "TransportLayer.h"
#include "TransportLayerPriv.h"
#include "TransportStructs.h"
#include "PhysicalStructs.h"
#include "PhysicalLayer.h"
#include "NetErrors.h"
#include "NetMisc.h"
#include "Errors.h"
#include "DBConstants.h"
#include "../newrpc/common/Common_Log.h"

#ifndef unix
#include "SegaOS.h"
#include "heaps.h"
#include "utils.h"
#include "Database.h"
#include "BoxSer.h"
#endif 

#ifndef __SERVER__
	#include "time.h"
#else

# if	defined(unix) && ! defined(NULL)
#  define	NULL		0
# endif

# ifdef THINK_C
#  define GetCurrentTime() Ticks
# else
#  ifndef unix
#   define GetCurrentTime() LMGetTicks()
#   define TimerProcPtr TimerUPP
#  endif
   // UNIX stuff:
   extern unsigned long GetCurrentTime(void);
#  include <sys/types.h>
#  include <time.h>
#  include <sys/time.h>
#  include <errno.h>
# endif

#endif	/*!__SERVER__*/

int TUGetMinTimer(struct timeval *tm);
void TUSleepIO(int who);


#ifdef THINK_C
	#define THINKSUCKS
#endif

	void			_TInit(void);
	OSErr			_TOpen(SessionRec *s, PortT localPort, PortT remPort);
	OSErr			_TListen(SessionRec *s, PortT localPort, PortT remPort, unsigned long timeout);
	OSErr			_TOpenAsync(SessionRec *s, PortT localPort, PortT remPort);
	OSErr			_TListenAsync(SessionRec *s, PortT localPort, PortT remPort, unsigned long timeout);
	OSErr			_TClose(SessionRec *s);
	OSErr			_TCloseAsync(SessionRec *s);
	void			_TUnthread(SessionRec *ds);
	OSErr 			_TNetIdle(NetParamBlock *pBlock);
	OSErr			_TUCheckTimers(SessionRec *s);
	OSErr			_TReadDataSync(SessionRec *sess, unsigned long length, Ptr address);
	OSErr			_TReadDataASync(SessionRec *sess, unsigned long length, Ptr address);
	OSErr			_TWriteDataSync(SessionRec *sess, unsigned long length, Ptr address);
	OSErr			_TWriteDataASync(SessionRec *sess, unsigned long length, Ptr address);
	OSErr			_TAsyncWriteFifoData(SessionRec *s);
	OSErr			_TReadData(unsigned long length, Ptr address, Boolean async );
	OSErr			_TWriteData(unsigned long length, Ptr address, Boolean async );
	unsigned char	_TReadAByte( void );
	OSErr			_TWriteAByte( char myByte );
	OSErr			_TQueueAByte( char myByte );
	OSErr			_TReadBytesReady( unsigned long *amount );
	OSErr			_TDataReady(unsigned long *amount);
	OSErr			_TDataReadySess(SessionRec *sess, unsigned long *amount);
	OSErr			_TIndication(Fifo *physFifo, unsigned short physState, unsigned short length);
	OSErr			_TForwardReset(SessionRec *s);
	OSErr			_TCheckError(void);
	OSErr			_TUSetError(OSErr err);
	OSErr			_TUGetError(void);
	OSErr			_TNetError( void );
	OSErr			_TUInitSessRec(SessionRec *s, PortT localPort, PortT remPort);
	OSErr			_TUSendCtl(SessionRec *s, Boolean probeRequested);
	OSErr			_TUDoSendCtl(SessionRec *s, Boolean probeRequested);
	OSErr			_TUDoSendOpenCtl(SessionRec *s, Boolean probeRequested);
	OSErr			_TUUpdateSessionInfo(SessionRec *s, char *header, Boolean *sequenceValid);
	OSErr			_TUSendOpen(SessionRec *s);
	OSErr			_TUSendOpenAck(SessionRec *s);
	OSErr			_TUSendCloseAdv(SessionRec *s);
	OSErr			_TUSendFwdReset(SessionRec *s);
	OSErr			_TUSendFwdResetAck(SessionRec *s);
	OSErr			_TUSendFwdResetPacket(SessionRec *s, unsigned char cCode);
	OSErr			_TUSendRetransAdv(SessionRec *s);
	unsigned short	_TUOpenDialogPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header);
	unsigned short	_TUFwdResetPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header);
	unsigned short	_TUCloseConnPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header);
	unsigned short	_TURetransAdvPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header);
	OSErr			_TUAllowConnection(SessionRec *s);
	OSErr			_TUDenyConnection(SessionRec *s);
	void			_TSetTransportHold(Boolean hold);
	void			_TSetTransportHoldSession(SessionRec *s, Boolean hold);
	Boolean			_TGetTransportHold(void);
	Boolean			_TGetTransportHoldSession(SessionRec *s);


//
// TransportLayer globals
//
TGlobalType TGlobals;

#ifndef	__SERVER__
	#define	GetGlobals()	((TGlobalType *) &REFGLOBAL(TGlobals,TSessionList))
#else
	#define	GetGlobals()	&TGlobals
#endif

#ifndef __SERVER__

long
_TransportLayerControl ( short command, long data )
{
TGlobalType *globals;
long offset;
OSErr error;

	error = commandSelectorUnknown;

	switch ( command )
		{
		case kHardInitialize:
		
			/* allocate and initialize our globals */
			GETMGRGLOBALSOFFSET(TGlobals,offset);
			
			error = AllocateGlobalSpace ( kTransportLayerManager, offset, sizeof(TGlobalType), (Ptr *) &globals );
			if ( error != noErr )
				{
				return error;
				}
			
			/* install our selectors */
			SetDispatchedFunction ( kTInit,					kTransportLayerManager,	_TInit );
			SetDispatchedFunction ( kTOpen,					kTransportLayerManager,	_TOpen );
			SetDispatchedFunction ( kTListen,				kTransportLayerManager,	_TListen );
			SetDispatchedFunction ( kTOpenAsync,			kTransportLayerManager,	_TOpenAsync );
			SetDispatchedFunction ( kTListenAsync,			kTransportLayerManager,	_TListenAsync );
			SetDispatchedFunction ( kTClose,				kTransportLayerManager,	_TClose );
			SetDispatchedFunction ( kTCloseAsync,			kTransportLayerManager,	_TCloseAsync );
			SetDispatchedFunction ( kTUnthread,				kTransportLayerManager,	_TUnthread );
			SetDispatchedFunction ( kTNetIdle,				kTransportLayerManager,	_TNetIdle );
			SetDispatchedFunction ( kTUCheckTimers,			kTransportLayerManager,	_TUCheckTimers );
			SetDispatchedFunction ( kTReadDataSync,			kTransportLayerManager,	_TReadDataSync );
			SetDispatchedFunction ( kTReadDataASync,		kTransportLayerManager,	_TReadDataASync );
			SetDispatchedFunction ( kTWriteDataSync,		kTransportLayerManager,	_TWriteDataSync );
			SetDispatchedFunction ( kTWriteDataASync,		kTransportLayerManager,	_TWriteDataASync );
			SetDispatchedFunction ( kTAsyncWriteFifoData,	kTransportLayerManager,	_TAsyncWriteFifoData );
			SetDispatchedFunction ( kTReadData,				kTransportLayerManager,	_TReadData );
			SetDispatchedFunction ( kTWriteData,			kTransportLayerManager,	_TWriteData );
			SetDispatchedFunction ( kTReadAByte,			kTransportLayerManager,	_TReadAByte );
			SetDispatchedFunction ( kTWriteAByte,			kTransportLayerManager,	_TWriteAByte );
			SetDispatchedFunction ( kTQueueAByte,			kTransportLayerManager,	_TQueueAByte );
			SetDispatchedFunction ( kTReadBytesReady,		kTransportLayerManager,	_TReadBytesReady );
			SetDispatchedFunction ( kTDataReady,			kTransportLayerManager,	_TDataReady );
			SetDispatchedFunction ( kTDataReadySess,		kTransportLayerManager,	_TDataReadySess );
			SetDispatchedFunction ( kTIndication,			kTransportLayerManager,	_TIndication );
			SetDispatchedFunction ( kTForwardReset,			kTransportLayerManager,	_TForwardReset );
			SetDispatchedFunction ( kTNetError,				kTransportLayerManager,	_TNetError );
			SetDispatchedFunction ( kTCheckError,			kTransportLayerManager,	_TCheckError );
			SetDispatchedFunction ( kTUSetError,			kTransportLayerManager,	_TUSetError );
			SetDispatchedFunction ( kTUGetError,			kTransportLayerManager,	_TUGetError );
			SetDispatchedFunction ( kTUInitSessRec,			kTransportLayerManager,	_TUInitSessRec );
			SetDispatchedFunction ( kTUSendCtl,				kTransportLayerManager,	_TUSendCtl );
			SetDispatchedFunction ( kTUDoSendCtl,			kTransportLayerManager,	_TUDoSendCtl );
			SetDispatchedFunction ( kTUDoSendOpenCtl,		kTransportLayerManager,	_TUDoSendOpenCtl );
			SetDispatchedFunction ( kTUUpdateSessionInfo,	kTransportLayerManager,	_TUUpdateSessionInfo );
			SetDispatchedFunction ( kTUSendOpen,			kTransportLayerManager,	_TUSendOpen );
			SetDispatchedFunction ( kTUSendOpenAck,			kTransportLayerManager,	_TUSendOpenAck );
			SetDispatchedFunction ( kTUSendCloseAdv,		kTransportLayerManager,	_TUSendCloseAdv );
			SetDispatchedFunction ( kTUSendFwdReset,		kTransportLayerManager,	_TUSendFwdReset );
			SetDispatchedFunction ( kTUSendFwdResetAck,		kTransportLayerManager,	_TUSendFwdResetAck );
			SetDispatchedFunction ( kTUSendFwdResetPacket,	kTransportLayerManager,	_TUSendFwdResetPacket );
			SetDispatchedFunction ( kTUSendRetransAdv,		kTransportLayerManager,	_TUSendRetransAdv );
			SetDispatchedFunction ( kTUOpenDialogPacket,	kTransportLayerManager,	_TUOpenDialogPacket );
			SetDispatchedFunction ( kTUFwdResetPacket,		kTransportLayerManager,	_TUFwdResetPacket );
			SetDispatchedFunction ( kTUCloseConnPacket,		kTransportLayerManager,	_TUCloseConnPacket );
			SetDispatchedFunction ( kTURetransAdvPacket,	kTransportLayerManager,	_TURetransAdvPacket );
			SetDispatchedFunction ( kTUAllowConnection,		kTransportLayerManager,	_TUAllowConnection );
			SetDispatchedFunction ( kTUDenyConnection,		kTransportLayerManager,	_TUDenyConnection );
			SetDispatchedFunction ( kTGetUserRef,			kTransportLayerManager,	_TGetUserRef );
			SetDispatchedFunction ( kTSetUserRef,			kTransportLayerManager,	_TSetUserRef );
			SetDispatchedFunction ( kTGetTransportHold,		kTransportLayerManager,	_TGetTransportHold );
			SetDispatchedFunction ( kTGetTransportHoldSession,		kTransportLayerManager,	_TGetTransportHoldSession );
			SetDispatchedFunction ( kTSetTransportHold,		kTransportLayerManager,	_TSetTransportHold );
			SetDispatchedFunction ( kTSetTransportHoldSession,		kTransportLayerManager,	_TSetTransportHoldSession );
			break;
		
		case kSoftInialize:
			// clear out globals
			globals = GetGlobals();
			for (error = sizeof(TGlobalType)-1; error >= 0; error--)
				((char *)globals)[error] = 0;
			
			REFGLOBAL(TGlobals,TMagic) = kMagicVal;
			error = noErr;
			break;
		
		case kHardClose:
			error = noErr;
			break;
		
		case kSoftClose:
			error = noErr;
			break;
					
		case kCodeBlockMoved:
			error = noErr;
			break;
					
		case kGlobalsMoved:
			error = noErr;
			break;
		}
		
	return error;
}

#endif


void ClearBytes(Ptr addr, unsigned long length);
void ClearBytes(Ptr addr, unsigned long length)
{
char	*end;

	end = addr+length;
	while (addr < end)
		*addr++ = 0;
}


////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////
/////////				   T R A N S P O R T   L A Y E R				   /////////
////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////

// This is really the session layer, and we are actually using ADSP for this.  ADSP
// is well defined and robust enough for what we are doing without too much overhead.
// Attention messages are not supported.

// initialization code
void _TInit(void)
{
TGlobalType		*glob;

	PInit();
	glob = GetGlobals();
	
#ifdef __SERVER__
	glob->TMagic = kMagicVal;
#else
	CHECKMAGIC(glob);
#endif
	
	glob->TSessionList = nil;
}

unsigned char _TReadAByte( void )
{
char			retVal;
unsigned long	length = 1;
	
	TReadData(length, &retVal, kSynch);
	return retVal;
}

// write a single byte on the transport NOW
OSErr _TWriteAByte( char myByte )
{
unsigned long length = 1;

	return TWriteData(length, &myByte, kSynch);
}

// write a single byte on the transport after a full amount
OSErr _TQueueAByte( char myByte )
{
unsigned long length = 1;

	return TWriteData(length, &myByte, kAsync);
}

// BRAIN DAMAGE: this should look like the other calls, but it is too late in the
// evening to figure out where they all are
OSErr _TReadBytesReady( unsigned long *amount )
{
	return(TDataReady(amount));
}

// If there is data waiting, take it and use it.  Copy the data that has come in into
// the client fifo.  Exit with the client fifo possibly in use
OSErr _TReadDataASync(SessionRec *s, unsigned long length, Ptr address)
{
unsigned short	primeAmount;
OSErr			err;

	if (CHECKSESSION(s) == false)
		return ( TUSetError(kNotASession) );

	if((err = TUGetError()))
	{
		WARNING_MESG("Outstanding error has not been cleared");
		return err;
	}

	if (s->connState == kConnClosed) 
		return( TUSetError( kSessionClosedErr ));
		
	if (FifoActive(&s->clientFifo)) {
		TUSetError(kAsyncInProgErr);
		return kAsyncInProgErr;
		}
	
	FifoInit(&s->clientFifo, (unsigned char *)address, length, kFlatQ);
	
	// how much do we have buffered?
	primeAmount = FifoAvailable(&s->readFifo);
	if (primeAmount) {
		if (primeAmount > length)
			primeAmount = length;
		// there is data that came in unexpectedly before this read; eat it first
		err = FifoCopy(&s->readFifo, &s->clientFifo, primeAmount);
		if (err) {
			TUSetError(err);
			return(err);
		}

		address += primeAmount;
		length -= primeAmount;
	}
	if (!length) {
		// we filled the request, kill the client fifo
		FifoInit(&s->clientFifo, nil, 0, kUnusedQ);
	}
	return noErr;
}

OSErr _TReadData(unsigned long length, Ptr address, Boolean async )
{
TGlobalType		*glob = GetGlobals();
	
	CHECKMAGIC(glob);
	if (async)
		return TReadDataASync((SessionRec *)glob->TCurrentSession, length, address);
	else
		return TReadDataSync((SessionRec *)glob->TCurrentSession, length, address);
}

OSErr _TWriteData(unsigned long length, Ptr address, Boolean async )
{
TGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	if (async)
		return TWriteDataASync((SessionRec *)glob->TCurrentSession, length, address);
	else
		return TWriteDataSync((SessionRec *)glob->TCurrentSession, length, address);
}

// this guy just calls TReadDataAsync and waits for completion
OSErr _TReadDataSync(SessionRec *s, unsigned long length, Ptr address )
{
OSErr			err;

	CHECKMAGIC(glob);
	if (CHECKSESSION(s) == false) {	
		ClearBytes(address, length);
		return( TUSetError( kNotASession ));
		}

	if((err = TUGetError()))
	{
		WARNING_MESG("Outstanding error has not been cleared");
		ClearBytes(address, length);
		return err;
	}

	// if the end of the buffer doesn't point to the end of the session buffer 
	// _someone_ else is active right now.
	if (FifoActive(&s->clientFifo)) {
		TUSetError(kAsyncInProgErr);
		ClearBytes(address, length);
		return kAsyncInProgErr;
		}
	
	if (TReadDataASync(s, length, address) != noErr) {
		ClearBytes(address, length);
		return TUGetError();
		}

	while ((FifoActive(&s->clientFifo)) && !SESSCLOSED(s)) {
		err = TNetIdle(nil);
		if (err) {
			ClearBytes(address, length);
			return err;
			}
		}

	return noErr;
}


OSErr _TWriteDataSync(SessionRec *s, unsigned long length, Ptr address )
{
OSErr	err;

	if (CHECKSESSION(s) == false)
		return( TUSetError( kNotASession ));
		
	if((err = TUGetError()))
	{
		WARNING_MESG("Outstanding error has not been cleared");
		return err;
	}

	if (TWriteDataASync(s, length, address))
		return TUGetError();
	
	while ((FifoAvailable(&s->writeFifo)) && !SESSCLOSED(s)) {
		err = TNetIdle(nil);
		if (err)
			return noErr;
		}
		
	return noErr;
}

OSErr _TWriteDataASync(SessionRec *s, unsigned long length, Ptr address )
{
unsigned long	writeQuantum;
OSErr			err;

	CHECKMAGIC(glob);
	if (CHECKSESSION(s) == false)
		return( TUSetError( kNotASession ));
		
	if((err = TUGetError()))
	{
		WARNING_MESG("Outstanding error has not been cleared");
		return err;
	}

	if (s->connState == kConnClosed)
		return( TUSetError( kSessionClosedErr ));
		
#ifdef OLD_WAY
	// [ FifoRemaining tells you how much space is left in the fifo.  If
	//   we don't have enough space left to put "length" bytes in, we have
	//   to wait for it to drain. ++ATM ]
	//
	writeQuantum = FifoSize(&s->writeFifo);
	if (FifoRemaining(&s->writeFifo) < length) {
		// we have more to write than the fifo can handle.  Idle here if
		// if the buffer is big enough to ever handle it, otherwise idle until
		// FifoAvailable is zero and switch buffers.
		if (writeQuantum > length) {
			// the fifo can handle it, just not right now.  Idle a bit
			while ((FifoRemaining(&s->writeFifo) < length) && !SESSCLOSED(s)) {
				err = TNetIdle(nil);
				if (err)
					return err;
				}
			}
		else {
			// the buffer is bigger than the fifo
			// it still works, it just sticks around in here for a while
			// this could be optimized to do the small part first so it came
			// out quicker...
			}
		}

	// [ Now the fun part.  Write "writeQuantum" bytes of data to the fifo,
	//   then wait for it to drain.  Somehow TAsyncWriteFifoData and
	//   TNetIdle are involved in this (note TAsyncWriteFifoData is called
	//   both below and from within TNetIdle... probably redundant to do
	//   it below). ++ATM ]
	//
	while (length) {
		if (writeQuantum > length)
			writeQuantum = length;
		
		while ((FifoRemaining(&s->writeFifo) < writeQuantum) && !SESSCLOSED(s)) {
			err = TNetIdle(nil);
			if (err)
				return err;
			}
		// the fifo has enough space now, add the data
		err = FifoWrite(&s->writeFifo, (unsigned char *)address, writeQuantum);
		if (err) {
			TUSetError(err);
			return err;
			}
			
		address += writeQuantum;
		length -= writeQuantum;
		
		// [ This causes the data to be written, assuming the client is able
		//   to receive data at this time. ++ATM ]
		//
		if (TAsyncWriteFifoData(s) < 0)
			return TUGetError();
		}
#else
	// New & improved version of the above.  The previous version set the
	// writeQuantum too high, and we ended up calling TAsyncWriteFifoData
	// with no data to write.  This prevents that from happening (though
	// it may still occur every once in a while?).
	//
	// If we can't write because the box's flow control stuff prevents
	// us from doing so, a check in TAsyncWriteFifoData will make us
	// block until the client is ready or a timer expires.
	//
	while (length) {
		while ( (writeQuantum = FifoRemaining(&s->writeFifo)) <= 0 ) {
			err = TNetIdle(nil);
			if (err)
				return err;
		}

		if (writeQuantum > length)
			writeQuantum = length;
		
		//Logmsg("TWriteDataASync: quantum = %d\n", writeQuantum);
		//Logmsg("TWriteDataASync: fifo remain = %d\n", 
		//	FifoRemaining(&s->writeFifo));

		// the fifo has enough space now, add the data
		err = FifoWrite(&s->writeFifo, (unsigned char *)address, writeQuantum);
		if (err) {
			TUSetError(err);
			return err;
		}
			
		address += writeQuantum;
		length -= writeQuantum;
		
		if (TAsyncWriteFifoData(s) < 0)
			return TUGetError();
		}
#endif
	
	return noErr;
}

// this guy gets called from both TWriteDataASync and TNetIdle to possibly send data from the fifo.
// there is no guarantee that the data will be sent, only that the pipe is full.
//
// [ Translation: we spin on this while we're waiting for the client's
//   flow control to clear up so we can send more data.  When this call is
//   made, either we send data or we return early because the client is
//   being overwhelmed.
//
//   Which isn't strictly true, because the transport hold stuff is also
//   dealt with here. ++ATM ]
//
OSErr _TAsyncWriteFifoData(SessionRec *s)
{
short			localRemaining, remoteRemaining, thisWrite;
unsigned long	length;
WDS				writePB;
OSErr			err;

	CHECKMAGIC(glob);
	if (CHECKSESSION(s) == false)
		return( TUSetError( kNotASession ));			// can't store this error cuz this isn't a valid session.

	if((err = TUGetError()))
	{
		WARNING_MESG("Outstanding error has not been cleared");
		return err;
	}

	// how much can the other end accept
	remoteRemaining = s->sendWdwSeq - s->sendSeq;
	if (remoteRemaining <= 0) {
		TUSleepIO(0);	// wait for data or timer expire
		return noErr;
		}

	length = FifoAvailable(&s->writeFifo);
	if (!length) {
		// nothing to send
		//TUSleepIO(1);	// wait for data or timer expire
		return noErr;
		}

	// check to see if we are holding the transport sends to economize headers.  If we are
	// don't send unless there is data in this send left over, the implication being the fifo
	// doesn't have the space to hold everything.
	if ((s->transportHold) && (FifoAvailable(&s->writeFifo) < kADSPMaxDataSiz)) {
		return noErr;
		}

	// we can start queueing things to the next layer down
	while (length) {
		thisWrite = remoteRemaining;
		ASSERT_MESG(length != 0, "About to chatter...");
		if ((length < kADSPMaxDataSiz) && (length < remoteRemaining))
			thisWrite = length;
		else if (remoteRemaining > kADSPMaxDataSiz)
			thisWrite = kADSPMaxDataSiz;

		// [ Yes, we are now reading from the write fifo.  Welcome to hell. ]
		err = FifoRead(&s->writeFifo, (unsigned char *)s->preWriteBuf, thisWrite);
		if (err) {
			TUSetError(err);
			return err;
		}

		// set up the header fields
		SETADSPWCONNID(s->writeHeader, s->myConnID);
		SETADSPWFSTBYTESEQ(s->writeHeader, s->sendSeq);
		SETADSPWNEXTRECSEQ(s->writeHeader, s->recvSeq);
		localRemaining = FifoRemaining(&s->readFifo);
		if (localRemaining > kPhysBufferSize/2)
			localRemaining = kPhysBufferSize/2;
		SETADSPWRECWIND(s->writeHeader, localRemaining);
		
		// check to see if we need to ask for an ack
		ASSERT_MESG(remoteRemaining - thisWrite >= 0, "We are about to send too much");
		// This will end up sending a small packet just to fill the recievers buffer, but it
		// is doing so at the end of the datastream
		if ((remoteRemaining - thisWrite <= 0) || (length-thisWrite == 0))
			SETADSPWDESC(s->writeHeader, kDescAckMsk);
		else
			SETADSPWDESC(s->writeHeader, 0);
		
		// now set up the WDS
		writePB.length1 = kADSPAllHdrSiz;
		writePB.buf1 = (unsigned char *)PBUFADDR(s->writeHeader);
		writePB.length2 = thisWrite;
		writePB.buf2 = (unsigned char *)s->preWriteBuf;
		err = PWritePacketASync(&writePB);
		if (err) {
			TUSetError(PCheckError());
			return err;
		}
		
		// update shit
		length -= thisWrite;
		s->sendSeq += thisWrite;
		remoteRemaining = s->sendWdwSeq - s->sendSeq;
		if (remoteRemaining <= 0)
			break;
		}
	
	return noErr;
}

//
// Hack to avoid having _TWriteDataASync blow away the CPU by spinning on
// TNetIdle and friends.  This falls asleep until one of the session's
// timers goes off or there's activity on an fd.
//
void TUSleepIO(int who)
{
	struct timeval	tm;
	fd_set readfds;
	int cc;

	if (!TUGetMinTimer(&tm))
		return;

	FD_ZERO(&readfds);
	FD_SET(0, &readfds);	// watch stdin only
	cc = select(1, &readfds, NULL, NULL, &tm);

	//PLogmsg(LOGP_DETAIL, "SELECT_WAIT %d: returned %d (%d)\n", who, cc, errno);
}


// find out how much data is ready on this session.  If there is an async read going
// on, this will return zero.  This is because there is none available for YOU to read
// with some sync call, and you can't stack async calls in this model.
OSErr _TDataReadySess(SessionRec *s, unsigned long *amount)
{
OSErr			err;

	*amount = 0;
	CHECKMAGIC(glob);
	if (CHECKSESSION(s) == false)
		return( TUSetError( kNotASession ));	// can't store this, cuz this isn't a sessionRec!

	if((err = TUGetError()))
	{
		WARNING_MESG("Outstanding error has not been cleared");
		return err;
	}

	if (s->connState == kConnClosed) {
		TUSetError(kSessionClosedErr);
		return kSessionClosedErr;
		}

	err = TNetIdle(nil);
	if (err)
		return err;

	if (FifoActive(&s->clientFifo))
		*amount = 0;
	else
		*amount = FifoAvailable(&s->readFifo);
	
	return noErr;
}

OSErr _TDataReady(unsigned long *amount)
{
TGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	return TDataReadySess((SessionRec *)glob->TCurrentSession, amount);
}

OSErr _TUInitSessRec(SessionRec *s, PortT localPort, PortT remPort)
{
short			count;
TGlobalType		*glob = GetGlobals();
Boolean			retVal;
SessionRec		*link;

	retVal = true;
	CHECKMAGIC(glob);
	
	// verify that the session is not already linked in
	link = glob->TSessionList;
	while (link) {
		if (link == s)
			return TUSetError(kPortOpenErr);
		link = link->next;
		}
		
	// init session rec to nil
	for (count = sizeof(SessionRec)-1; count >= 0; count--)
		((char *)s)[count] = 0;
	TUSetError(noErr);			// noErr = 0
		
	FifoInit(&s->readFifo, (unsigned char *)s->pcktRdBuf, kReadFifoLength, kCircularQ);
	FifoInit(&s->clientFifo, nil, 0, kUnusedQ);
	FifoInit(&s->writeFifo, (unsigned char *)s->pcktWrBuf, kWriteFifoLength, kCachingQ);

	// link in session to list
	s->next = glob->TSessionList;
	glob->TSessionList = s;
	
	SETSESSION(s, kTransportMagic);
	// set current session to this one
	glob->TCurrentSession = s;

	do
		s->myConnID = GetCurrentTime();
	while (s->myConnID == 0);
	
#ifndef __SERVER__
	// get timeout bounds from database
	DBGetConstant(kDBTransportTickleConst, &temp);
	s->tickleTimeoutCount = temp;
	DBGetConstant(kDBTransportTimeoutConst, &temp);
	s->timeoutTicks = temp;
#else
	s->tickleTimeoutCount = kTransportTickleCount;
	s->timeoutTicks = kTransportTimeoutValue;
#endif

	// init timeouts
	s->retransTimer = kTimerUnused;
	s->timer = kTimerUnused;
	s->tickleCount = 0;
	return noErr;
}

OSErr
_TOpen(SessionRec *s, PortT localPort, PortT remPort)
{
OSErr	err;
	
	err = TOpenAsync(s, localPort, remPort);
	if (err != noErr)
		return err;
	
	// spin until the session is open, closed, or an error occurs
	err = NetIdle(nil);
	while (err >= 0) {
		if (SESSREADY(s)) {
			err = noErr;
			break;
			}
		if (SESSCLOSED(s)) {
			err = kNoConnection;
			break;
			}
		err = NetIdle(nil);
		}
	if (err) {
		TUnthread(s);
		TUSetError(err);
		}
		
	return err;
}

OSErr
_TListen(SessionRec *s, PortT localPort, PortT remPort, unsigned long timeout)
{
extern int		gTLayerReading;
OSErr			err;
unsigned long	killTime;

	if (timeout)
		killTime = GetCurrentTime() + timeout;
	else
		killTime = 0xffffffff;

	err = TListenAsync(s, localPort, remPort, timeout);
	if (err != noErr)
		return err;
	
	// spin until the session is open, closed, or an error occurs
	err = NetIdle(nil);
	while (err >= 0) {
		if (SESSREADY(s)) {
			err = noErr;
			break;
			}
		if (SESSCLOSED(s)) {
			err = kNoConnection;
			break;
			}
		
		// this should be taken care of by the idler, but anyways...
		if (killTime < GetCurrentTime()) {
			err = kTimeout;
			break;
			}
		gTLayerReading = true;
		err = NetIdle(nil);
		gTLayerReading = false;
		}
	if (err) {
		TUnthread(s);
		TUSetError(err);
		}

	return err;
}

// true return value from here means that we _can_ open the connection, not that
// it actually opened.  SESSREADY(s) must be used to test this, and a synchronous
// open must be simulated by looping on SESSREADY
OSErr
_TOpenAsync(SessionRec *s, PortT localPort, PortT remPort)
{
NetParamBlock	npb;
OSErr			err;

	CHECKMAGIC(glob);
	
/*
	// BRAIN DAMAGE ******************************************
	//
	if(s == (SessionRec *)0xDEADFACE)
		Debugger();
*/

	PCheckError();
	TCheckError();
	PNetIdle(&npb);

	if (npb.ioPhysNetState == kConnClosed)
		return( TUSetError( kLinkClosed ));
						
	err = TUInitSessRec(s, localPort, remPort);
	if (err)
		return err;
		
	s->connState = kConnOpening;
	
	// send an opening volley
	return TUSendOpen(s);
}

// true return value from here means that we _can_ open the connection, not that
// it actually opened.  SESSREADY(s) must be used to test this, and a synchronous
// open must be simulated by looping on SESSREADY.
// PNetIdle is called _after_ TUInitSessRec to attempt to hold waiting open request
// packets until the socket is open.  In worst case, the request will resend.
OSErr
_TListenAsync(SessionRec *s, PortT localPort, PortT remPort, unsigned long timeout)
{
NetParamBlock	npb;
OSErr			err;

	CHECKMAGIC(glob);
	
	err = TUInitSessRec(s, localPort, remPort);
	if (err)
		return err;

	if (timeout)
		s->listenTimeout = timeout + GetCurrentTime();
	else
		s->listenTimeout = 0xffffffff;
		
	PCheckError();
	TCheckError();
	PNetIdle(&npb);

	if (npb.ioPhysNetState == kConnClosed) {
		TUnthread(s);
		return( TUSetError( kLinkClosed ));
		}
		
	s->connState = kConnListening;
	
	return noErr;
}

OSErr
_TClose(SessionRec *s)
{
OSErr	err;

	// clear out remaining, client doesn't want it.
	FifoSkip(&s->readFifo, FifoAvailable(&s->readFifo));
	// clear out any stuck error, can't have that slowing us down
	TCheckError();
	err = TCloseAsync(s);
	if (err != noErr) {
		if (err == kNotASession)
			return err;
		else
			TCheckError();
		}

	while (!SESSCLOSED(s)) {
		err = NetIdle(nil);
		// if all sessions are closed we will get kNotASession
		if (err) {
			TCheckError();
			}
		}
	
	if ((err < 0) && (err != kNotASession))
		return err;
	else
		return noErr;
}

// this should probably return an OSErr, like all the other opening and closing routines
OSErr
_TCloseAsync(SessionRec *s)
{
	if ((s->connState == kConnClosed) || (s->connState == kConnClosing))
		return noErr;
		
	if (CHECKSESSION(s) == false)
		return( TUSetError( kNotASession ));
		
	s->connState = kConnLocallyClosed;
	return noErr;
}

// remove sess from the TSessionList global list.  If sess is also TCurrentSession,
// the current session becomes undefined.
void _TUnthread(SessionRec *sess)
{
TGlobalType		*glob = GetGlobals();
SessionRec		*s, **sp;

	CHECKMAGIC(glob);
	if (CHECKSESSION(sess) == false)
		return;
		
	sp = (SessionRec **)&glob->TSessionList;
	for (;;) {
		s = *sp;
		if ( s == sess ) {
			*sp = s->next;
			break;
			}
		if ( s == nil )
			break;
		sp = &s->next;
		}
	
	// well, not quite undefined, but not predictable either
	if (glob->TCurrentSession == sess)
		glob->TCurrentSession = glob->TSessionList;
		
	s->connState = kConnClosed;
	SETSESSION(s, 0xDEADBEEF);
}

// this guy gets called when a transport packet arrives.  Find the correct session
// and put it in his buffer.  PFillProc is used to do the buffer copy because the fifo source is circular.
//
// This is where the meat of taking apart the incoming packets happens.  
OSErr _TIndication(Fifo *physFifo, unsigned short physState, unsigned short length)
{
TGlobalType		*glob = GetGlobals();
SessionRec		*s;
char			header[kADSPAllBufSiz];
Boolean			sequenceValid, isOpenDlgPacket;
unsigned long	localRemaining;
unsigned char	packetType;
OSErr			err;

	CHECKMAGIC(glob);
	// if the physical layer closes out from under us, we can never send packets.  This is a very ungraceful
	// exit, but we can't hang waiting.  If you don't want to blast the sessions, re-establish the link before
	// passing a kConnClosing for the physical layer in here
	if ((physState == kConnClosing) || (physState == kConnClosed)) {
		s = glob->TSessionList;
		while (s) {
//			TUnthread(s);
			s->connState = kConnClosing;
			s = s->next;
			}
		}
	
	// if u are going to send messages to TIndication with a zero length, do 
	// processing for them before this check
	if (length == 0)
		return noErr;
		
	// get packet header from circular fifo
	// if there is not enough there, blow out of here.
	if (length < kADSPHdrSiz)
		return kRuntPacketDetected;
		
	err = FifoRead(physFifo, (unsigned char *)&header, kADSPHdrSiz);
	if (err) { 
		return err;
		}
	
	length -= kADSPHdrSiz;

	// find the correct session for this packet
	packetType = GETADSPRDESC(header) & kDescCtrlCodeMsk;
	if (GETADSPRDESC(header) & kDescCtrlMsk) {
		if ((packetType == kADSPOpenConnReq) || (packetType == kADSPOpenConnReqAck))
			isOpenDlgPacket = true;
		}
		
	s = glob->TSessionList;
	while (s) {
		if (GETADSPRCONNID(header) == s->remConnID)
			break;
		if (isOpenDlgPacket && ((s->connState == kConnListening) || (s->connState == kConnOpening)))
			break;
		s = s->next;
		}

	if (!s) {
		if (packetType != kADSPProbeOrAck) {
			// no sessions were found.  If the connection is coming up, the other side will
			// keep trying until we are ready.
			return noErr;
			}
		}

	if (TUUpdateSessionInfo(s, header, &sequenceValid) < 0) {	
		return TUGetError();
		}

	// check for control packet, we can process and return
	if (GETADSPRDESC(header) & kDescCtrlMsk) {
		// these should be vectored for speed.  Anywhere else?
		switch (packetType) {
			case kADSPProbeOrAck:						// probe or acknowledgement
				if (GETADSPRDESC(header) & kDescAckMsk) {
					// probe packet (ctrl-ack)
					if (TUSendCtl(s, false) < 0) {
						return TUGetError();
						}
					}
				else if (GETADSPRFSTBYTESEQ(header) > s->recvSeq) {
					if (TUSendRetransAdv(s) < 0) {
						return TUGetError();
						}
					}
				break;
			case kADSPOpenConnReq:						// open connection request
			case kADSPOpenConnAck:						// open connection ack
			case kADSPOpenConnReqAck:					// open connection req and ack
			case kADSPOpenConnDeny:						// open connection denial
				length -= TUOpenDialogPacket(s, physFifo, packetType, header);
				break;
			case kADSPFwdReset:							// forward reset
				length -= TUFwdResetPacket(s, physFifo, packetType, header);
				break;
			case kADSPFwdResetAck:						// forward reset ack
				ASSERT_MESG(0,"A forward reset ack in TIndication??!??");
				break;
			case kADSPCloseConnAdv:						// close connection advice
				length -= TUCloseConnPacket(s, physFifo, packetType, header);
				break;
			case kADSPRetransAdv:						// retransmit advice
				length -= TURetransAdvPacket(s, physFifo, packetType, header);
				break;
			default:
				ASSERT_MESG(0,"Unhandled control packet type in TIndication");
			}
		}
	else {
		if (sequenceValid == false) {
			// if the incoming sequence doesn't match, return (dumping packet)
			return TUGetError();
			}
		
		// start by adding to the sequence, later we subtract what we didn't get (hopefully 0)
		s->recvSeq += length;

		// we have a data packet, stuff it
		// see if it will fit in the client fifo
		if (FifoActive(&s->clientFifo)) {
			// yes, see how much remains there
			localRemaining = FifoRemaining(&s->clientFifo);
			// if more remains than the length of the packet, there is room to store it
			// but not enough to fill out the buffer and cancel it
			if (localRemaining > length) {
				err = FifoCopy(physFifo, &s->clientFifo, length);
				if (err) {
					TUSetError(err);
					return err;
					}
				length = 0;
				}
			else {
				// otherwise, there is enough to fill out the buffer and cancel the client buffer
				err = FifoCopy(physFifo, &s->clientFifo, localRemaining);
				if (err) {
					TUSetError(err);
					return err;
				}
				
				FifoInit(&s->clientFifo, nil, 0, kUnusedQ);
				length -= localRemaining;
				localRemaining = FifoRemaining(&s->readFifo);
				if (localRemaining > length)
					localRemaining = length;
				// HACK-- this gets around some flakey in the read code
				FifoInit(&s->readFifo, (unsigned char *)s->pcktRdBuf, kReadFifoLength, kCircularQ);
				err = FifoCopy(physFifo, &s->readFifo, localRemaining);
				if (err) {
					TUSetError(err);
					return err;
					}
				
				length -= localRemaining;
				}
			}
		else {
			// just queue it up
			localRemaining = FifoRemaining(&s->readFifo);
			if (localRemaining > length)
				localRemaining = length;
			err = FifoCopy(physFifo, &s->readFifo, localRemaining);
			if (err) {
				TUSetError(err);
				return err;
				}
				
			length -= localRemaining;
			}

		// add back what we didn't get
		s->recvSeq -= length;
		// check for ack request
		if (GETADSPRDESC(header) & kDescAckMsk) {
			// probe packet (ctrl-ack)
			if (TUSendCtl(s, false) < 0) {
				return TUGetError();
				}
			}
		}
	
	return noErr;
}

// BRAIN DAMAGE:  What about outstanding async operations on the client fifo?
OSErr _TForwardReset(SessionRec *s)
{
OSErr		err;

	if (CHECKSESSION(s) == false)
		return( TUSetError( kNotASession ));	// can't store this, cuz this isn't a sessionRec!

	if((err = TUGetError()))
	{
		WARNING_MESG("Outstanding error has not been cleared");
		return err;
	}
		
	FifoInit(&s->readFifo, (unsigned char *)s->pcktRdBuf, kReadFifoLength, kCircularQ);
	FifoInit(&s->clientFifo, nil, 0, kUnusedQ);
	FifoInit(&s->writeFifo, (unsigned char *)s->pcktWrBuf, (kWriteFifoLength), kCachingQ);

	if (TUSendFwdReset(s) < 0)
		return TUGetError();
	
	s->connState = kConnFwdReset;
	while ((s->connState == kConnFwdReset) && !SESSCLOSED(s)) {
		err = TNetIdle(nil);
		if (err)
			return err;
		}
		
	if (s->connState == kConnFwdResetAck) {
		s->connState = kConnOpen;
		return noErr;
		}
	else {
		return kFwdResetFailed;
		}
}

/////////////////////////////////////////////////////////////////////
// NOTE: Errors are cached in TNetIdle and the last one
// returned.  NetIdle has to run to completion on all sessions every
// time through.  There are undoubetedly cases that the loop should
// bail out and crash the net, but they are not defined yet.  Note
// the preffered early exit from this loop is to bring the net down,
// trash all the sessions, and start over.
/////////////////////////////////////////////////////////////////////

OSErr _TNetIdle( NetParamBlock *pBlock )
{
OSErr			retVal;
SessionRec		*s, *s2;
TGlobalType		*glob = GetGlobals();

	//PLogmsg(LOGP_PROGRESS, "--- TNetIdle\n");
	CHECKMAGIC(glob);

	if (pBlock) {
		// fill in some fields
		pBlock->ioLastTransportError = glob->lastTransportError;
		}
	
	// get some packets  This can call through to an XIndication proc, so be careful here
	// This will only call TIndication if the link is up and a packet comes in
	retVal = PNetIdle(pBlock);
	
	/////////////////////////////////////////////////////////////////////
	// Returning here is really bad and will leave the transport hanging until the physical
	// layer is repaired. 
	/////////////////////////////////////////////////////////////////////
	if (retVal < 0) {
		WARNING_MESG("Bailing on TNetIdle because PNetIdle returned an error");
		TUSetError(PCheckError());
		return retVal;
		}
	else
		retVal = 0;
		
	// check timeouts on each session
	// find the correct session for this packet
	s = glob->TSessionList;
	while (s) {		
		ASSERT_MESG(CHECKSESSION(s), "There is an uninitialized or bogus session in the session list");
		if (s->connState == kConnLocallyClosed) {
			if (!FifoAvailable(&s->writeFifo) && (s->sendSeq == s->firstRtmtSeq)) {
				if (TUSendCloseAdv(s))
					retVal = TUGetError();
				s->connState = kConnClosing;
				}
			}
			
		if (s->connState == kConnClosing) {
			// check to see if this guy is exhausted
//			if (!FifoAvailable(&s->readFifo) && !FifoAvailable(&s->writeFifo)) {
			if (!FifoAvailable(&s->readFifo)) {
				s2 = s->next;
				TUnthread(s);
				s = s2;
				continue;
				}
			if (s->timer && (s->timer <= GetCurrentTime())) {
				if (TUSendCtl(s, true))
					retVal = TUGetError();
				}
			}
		if (TUCheckTimers(s))
			retVal = TUGetError();
		// this guy figures out for himself whether he should do anything
		if (TAsyncWriteFifoData(s))
			retVal = TUGetError();
		ASSERT_MESG(s->next != s, "next is same as this");
		s = s->next;
		}
	
	return retVal;
}

OSErr _TUCheckTimers(SessionRec *s)
{
OSErr	retVal;

	retVal = noErr;
	if (CHECKSESSION(s) == false)
		return (TUSetError( kNotASession ));
		
	if (s->timer && (s->timer <= GetCurrentTime())) {
		if (s->timer == kTimerWaitForSpace) {
			if (FifoRemaining(&s->readFifo) + FifoRemaining(&s->clientFifo)) {
				retVal = TUSendCtl(s, true);
				}
			}
		else {
			retVal = TUSendCtl(s, true);
			}
		}
		
	if (s->retransTimer && (s->retransTimer <= GetCurrentTime())) {
		if (s->timer == kTimerWaitForSpace) {
			if (FifoRemaining(&s->readFifo) + FifoRemaining(&s->clientFifo)) {
				retVal = TUSendRetransAdv(s);
				}
			}
		else {
			retVal = TUSendRetransAdv(s);
			}
		}
	
	if ((s->tickleCount > s->tickleTimeoutCount)
			|| ((s->connState == kConnListening) && (s->listenTimeout < (unsigned long)GetCurrentTime()))) {
		retVal = kTimeout;
		TUnthread(s);
		}
		
	if(retVal)
		TUSetError(retVal);

	return retVal;
}

//
// (This is a hack to try to avoid spinning while waiting for the client to
// become writable.)
//
// Sets up the timeval pointed to by "tm" with the smallest timeout
// found in the set of "s->timer", "s->retransTimer", and "s->listenTimeout".
// Note that some of the timers can have "kTimerWaitForSpace" jammed in to
// force immediate action; this gets handled pretty much transparently.
//
// Returns 0 if no timers are pending, 1 if "tm" has a useful value in it.
//
int TUGetMinTimer(struct timeval *tm)
{
	TGlobalType	*glob = GetGlobals();
	SessionRec	*s;
	unsigned long now, soonest;

	s = glob->TSessionList;
	if (s->next) {
		PLogmsg(LOGP_FLAW, "GLITCH: more than one session!\n");
		// hell, just return 100ms so we don't toast the CPU
		tm->tv_sec = 0;
		tm->tv_usec = 100000;
		return (1);
	}

	// Start with a huge value, find a smaller one.  The value represents
	// the time in ticks since the dawn of mankind (i.e. 1970).  This will
	// actually roll over and screw us briefly every couple of years.
	//
	soonest = 0xffffffffL;

	if (s->timer && s->timer < soonest)
		soonest = s->timer;
	if (s->retransTimer && s->retransTimer < soonest)
		soonest = s->timer;
	if (s->listenTimeout && s->listenTimeout < soonest)
		soonest = s->timer;
	
	if (soonest == 0xffffffffL) {
		// No timers are pending, so we can wait forever.  Let's give up
		// after a few seconds though just in case something broken.
		//
		//PLogmsg(LOGP_DETAIL, "TIMER: none pending\n");
		tm->tv_sec = 3;
		tm->tv_usec = 0;
		return (1);
	} else if (soonest == kTimerWaitForSpace) {
		// We're in "wait for space" mode, so we don't want to pause.
		//
		//PLogmsg(LOGP_DETAIL, "TIMER: kWaitForSpace\n");
		return (0);
	} else {
		// Got a real value.  Set it up, converting 1/60th second ticks
		// back into sec/usec.
		//
		now = GetCurrentTime();
		if (soonest <= now) {
			// We're already at the timer expire point.
			//
			//PLogmsg(LOGP_DETAIL, "TIMER: already expired\n");
			return (0);
		}

		tm->tv_sec = (soonest - now) / 60;
		tm->tv_usec = ((soonest - now) % 60) * 16666;
		//PLogmsg(LOGP_DETAIL, "TIMER: will wait for %lu/%lu\n",
		//	tm->tv_sec, tm->tv_usec);
		return (1);
	}

	/*NOTREACHED*/
}

OSErr _TUUpdateSessionInfo(SessionRec *s, char *header, Boolean *sequenceValid)
{
unsigned long	pktNextRecSeq;
OSErr			retVal;

	if (CHECKSESSION(s) == false)
		return( TUSetError( kNotASession ));
		
	*sequenceValid = true;
	retVal = noErr;

	pktNextRecSeq = GETADSPRNEXTRECSEQ(header);

	// if the retransmit info is within bounds we can flush our buffers even though
	// the packet is out of sequence  This may also indicate that a packet was lost and
	// that we should back up the send seq
	if ((s->firstRtmtSeq <= pktNextRecSeq) && (pktNextRecSeq <= s->sendSeq)) {
		// remote end is acknowledging reciept
		/////////////////////////////////////////////////////////////////////
		// WARNING: this FifoFlush is treated as non-fatal, even though the 
		// error needs to be propagated because the code following must be 
		// executed.  There are currently no subroutine calls that will modify 
		// lastError, and you will probably break things if you add one!!!!!!!!
		/////////////////////////////////////////////////////////////////////
		retVal = FifoFlush(&s->writeFifo, pktNextRecSeq - s->firstRtmtSeq);
		s->firstRtmtSeq = pktNextRecSeq;
		}

	if (GETADSPRFSTBYTESEQ(header) == s->recvSeq) {
		// packet is in sequence
		s->sendWdwSeq = GETADSPRRECWIND(header) + pktNextRecSeq;
		s->retransTimer = kTimerUnused;
		s->tickleCount = 0;
		}
	else {
		if (GETADSPRFSTBYTESEQ(header) > s->recvSeq) {
			// ask for retrans this is non-fatal
			retVal = TUSendRetransAdv(s);
			}
		*sequenceValid = false;
		}

	// update recieve timer
	s->timer = GetCurrentTime() + s->timeoutTicks;
	
	if(retVal)
		TUSetError(retVal);

	return retVal;
}

// this guy's client must reset the fifos for accurate peer update of packet recieve window info
OSErr _TUSendFwdReset(SessionRec *s)
{
	if (CHECKSESSION(s) == false)
		return( TUSetError( kNotASession ));	// can't store this, cuz this isn't a sessionRec!
		
	return TUSendFwdResetPacket(s, kDescCtrlMsk | kADSPFwdReset);
}

// this guy's client must reset the fifos for accurate peer update of packet recieve window info
OSErr _TUSendFwdResetAck(SessionRec *s)
{
	if (CHECKSESSION(s) == false)
		return( TUSetError( kNotASession ));	// can't store this, cuz this isn't a sessionRec!
		
	return TUSendFwdResetPacket(s, kDescCtrlMsk | kADSPFwdResetAck);
}

OSErr _TUSendFwdResetPacket(SessionRec *s, unsigned char cCode)
{
WDS				writePB;
long			localRemaining;
OSErr			err;

	if (CHECKSESSION(s) == false)
		return( TUSetError( kNotASession ));	// can't store this, cuz this isn't a sessionRec!
		
	if((err = TUGetError()))
	{
		WARNING_MESG("Outstanding error has not been cleared");
		return err;
	}
		
	if (s->connState == kConnClosed) {
		TUSetError(kSessionClosedErr);
		return kSessionClosedErr;
		}
		
	// send a control packet
	// set up the header fields
	SETADSPWCONNID(s->ackHeader, s->myConnID);
	SETADSPWFSTBYTESEQ(s->ackHeader, s->sendSeq);
	SETADSPWNEXTRECSEQ(s->ackHeader, s->recvSeq);
	localRemaining = FifoRemaining(&s->readFifo) + FifoRemaining(&s->clientFifo);
	if (localRemaining > kPhysBufferSize/2)
		localRemaining = kPhysBufferSize/2;
	SETADSPWRECWIND(s->ackHeader, localRemaining);
	SETADSPWDESC(s->ackHeader, kDescCtrlMsk | kADSPFwdResetAck);
	
	// now set up the WDS
	writePB.length1 = kADSPAllHdrSiz;
	writePB.buf1 = (unsigned char *)PBUFADDR(s->ackHeader);
	writePB.length2 = 0;
	writePB.buf2 = nil;
	err = PWritePacketSync(&writePB);
	if (err)
		TUSetError(PCheckError());
		
	s->timer = GetCurrentTime() + s->timeoutTicks;
	
	return err;
}

OSErr _TUSendRetransAdv(SessionRec *s)
{
WDS				writePB;
long			localRemaining;
OSErr			err;

	if (CHECKSESSION(s) == false)
		return( TUSetError( kNotASession ));
		
	if((err = TUGetError()))
	{
		WARNING_MESG("Outstanding error has not been cleared");
		return err;
	}

	if (s->connState == kConnClosed) {
		TUSetError( kSessionClosedErr);
		return kSessionClosedErr;
		}
	
	// Don't blow him over with retrans.
	// This makes the retrans happen at database timeoutTicks intervals
	if ((s->retransTimer != kTimerUnused) && (s->retransTimer > GetCurrentTime()))
		return noErr;
	
	INCRCOMMERROR(packetRetransError,1);

	// send a control packet
	// set up the header fields
	SETADSPWCONNID(s->ackHeader, s->myConnID);
	SETADSPWFSTBYTESEQ(s->ackHeader, s->sendSeq);
	SETADSPWNEXTRECSEQ(s->ackHeader, s->recvSeq);
	localRemaining = FifoRemaining(&s->readFifo) + FifoRemaining(&s->clientFifo);
	if (localRemaining > kPhysBufferSize/2)
		localRemaining = kPhysBufferSize/2;
	SETADSPWRECWIND(s->ackHeader, localRemaining);
	
	SETADSPWDESC(s->ackHeader, kDescCtrlMsk | kADSPRetransAdv);
	
	// now set up the WDS
	writePB.length1 = kADSPAllHdrSiz;
	writePB.buf1 = (unsigned char *)PBUFADDR(s->ackHeader);
	writePB.length2 = 0;
	writePB.buf2 = 0;
	err = PWritePacketSync(&writePB);
	if(err)
		TUSetError(PCheckError());

	// if there is no space, set the timer flag.  This says to resend a control packet
	// as soon as there is some space.
	if (localRemaining == 0)
		s->retransTimer = kTimerWaitForSpace;
	else {
		s->tickleCount += 1;
		s->retransTimer = GetCurrentTime() + s->timeoutTicks;
		}
		
	return (TUGetError());
}

OSErr _TUSendCtl(SessionRec *s, Boolean probeRequested)
{
OSErr	err;

	if (CHECKSESSION(s) == false)
		return noErr;
		
	if((err = TUGetError()))
	{
		WARNING_MESG("Outstanding error has not been cleared");
		return err;
	}
		
	if ((s->connState == kConnOpen) || (s->connState == kConnLocallyClosed))
		TUDoSendCtl(s, probeRequested);
	else if (s->connState == kConnFwdReset)
		TUSendFwdReset(s);
	else
		TUDoSendOpenCtl(s, probeRequested);
	
	// only count this as a retry if it is not in response to a request
	if (probeRequested)
		s->tickleCount += 1;
	
	return TUGetError();
}

// this guy gets hit when we are in the opening dialog and the connection times out

OSErr _TUDoSendOpenCtl(SessionRec *s, Boolean probeRequested)
{
	if (s->connState == kConnRecvReq)
		// retrans the Req+Ack
		TUAllowConnection(s);
	else if (s->connState == kConnOpening)
		// retrans the open
		TUSendOpen(s);
	
	return TUGetError();
}

// do a tickle.
OSErr _TUDoSendCtl(SessionRec *s, Boolean probeRequested)
{
WDS				writePB;
long			localRemaining;
OSErr			err;

	// send a control packet
	// set up the header fields
	SETADSPWCONNID(s->ackHeader, s->myConnID);
	SETADSPWFSTBYTESEQ(s->ackHeader, s->sendSeq);
	SETADSPWNEXTRECSEQ(s->ackHeader, s->recvSeq);
	localRemaining = FifoRemaining(&s->readFifo) + FifoRemaining(&s->clientFifo);
	if (localRemaining > kPhysBufferSize/2)
		localRemaining = kPhysBufferSize/2;
	SETADSPWRECWIND(s->ackHeader, localRemaining);
	
	if (probeRequested) {
		SETADSPWDESC(s->ackHeader, kDescCtrlMsk | kDescAckMsk | kADSPProbeOrAck);
		}
	else {
		SETADSPWDESC(s->ackHeader, kDescCtrlMsk | kADSPProbeOrAck);
		}
	
	// now set up the WDS
	writePB.length1 = kADSPAllHdrSiz;
	writePB.buf1 = (unsigned char *)PBUFADDR(s->ackHeader);
	writePB.length2 = 0;
	writePB.buf2 = 0;
	err = PWritePacketSync(&writePB);
	if(err)
		TUSetError(PCheckError());

	// if there is no space, set the timer flag.  This says to resend a control packet
	// as soon as there is some space.
	if (localRemaining == 0)
		s->timer = kTimerWaitForSpace;
	else
		s->timer = GetCurrentTime() + s->timeoutTicks;

	return TUGetError();
}

OSErr _TUSendOpen(SessionRec *s)
{
WDS				writePB;
long			localRemaining;
char			openingInfo[kADSPOpenSubheadSiz];
OSErr			err;

	if (CHECKSESSION(s) == false)
		return( TUSetError( kNotASession ));	// can't store this, cuz this isn't a sessionRec!

	if((err = TUGetError()))
	{
		WARNING_MESG("Outstanding error has not been cleared");
		return err;
	}
		
	// send an open packet
	// set up the header fields
	SETADSPWCONNID(s->ackHeader, s->myConnID);
	SETADSPWFSTBYTESEQ(s->ackHeader, s->sendSeq);
	SETADSPWNEXTRECSEQ(s->ackHeader, s->recvSeq);
	localRemaining = FifoRemaining(&s->readFifo) + FifoRemaining(&s->clientFifo);
	if (localRemaining > kPhysBufferSize/2)
		localRemaining = kPhysBufferSize/2;
	SETADSPWRECWIND(s->ackHeader, localRemaining);
	SETADSPWDESC(s->ackHeader, kDescCtrlMsk | kADSPOpenConnReq);
	
	// now set up the data field
	SETADSPDATAOPENVERS(openingInfo, kADSPVersion);
	SETADSPDATAOPENDCONN(openingInfo, 0);
	SETADSPDATAOPENATTNR(openingInfo, 0);
	
	// now set up the WDS
	writePB.length1 = kADSPAllHdrSiz;
	writePB.buf1 = (unsigned char *)PBUFADDR(s->ackHeader);
	writePB.length2 = kADSPOpenSubheadSiz;
	writePB.buf2 = (unsigned char *)openingInfo;
	err = PWritePacketSync(&writePB);
	if(err)
		TUSetError(PCheckError());

	s->timer = GetCurrentTime() + s->timeoutTicks;

	return TUGetError();
}

OSErr _TUSendOpenAck(SessionRec *s)
{
WDS				writePB;
long			localRemaining;
char			openingInfo[kADSPOpenSubheadSiz];
OSErr			err;

	if (CHECKSESSION(s) == false)
		return( TUSetError( kNotASession ));	// can't store this, cuz this isn't a sessionRec!

	if((err = TUGetError()))
	{
		WARNING_MESG("Outstanding error has not been cleared");
		return err;
	}
		
	// send an open packet
	// set up the header fields
	SETADSPWCONNID(s->ackHeader, s->myConnID);
	SETADSPWFSTBYTESEQ(s->ackHeader, s->sendSeq);
	SETADSPWNEXTRECSEQ(s->ackHeader, s->recvSeq);
	localRemaining = FifoRemaining(&s->readFifo) + FifoRemaining(&s->clientFifo);
	if (localRemaining > kPhysBufferSize/2)
		localRemaining = kPhysBufferSize/2;
	SETADSPWRECWIND(s->ackHeader, localRemaining);
	SETADSPWDESC(s->ackHeader, kDescCtrlMsk | kADSPOpenConnAck);
	
	// now set up the data field
	SETADSPDATAOPENVERS(openingInfo, kADSPVersion);
	SETADSPDATAOPENDCONN(openingInfo, s->remConnID);
	SETADSPDATAOPENATTNR(openingInfo, 0);
	
	// now set up the WDS
	writePB.length1 = kADSPAllHdrSiz;
	writePB.buf1 = (unsigned char *)PBUFADDR(s->ackHeader);
	writePB.length2 = kADSPOpenSubheadSiz;
	writePB.buf2 = (unsigned char *)openingInfo;
	err = PWritePacketSync(&writePB);
	if(err)
		TUSetError(PCheckError());

	s->timer = GetCurrentTime() + s->timeoutTicks;
	return TUGetError();
}

OSErr _TUSendCloseAdv(SessionRec *s)
{
WDS				writePB;
OSErr			err;

	if (CHECKSESSION(s) == false)
		return( TUSetError( kNotASession ));	// can't store this, cuz this isn't a sessionRec!

	if((err = TUGetError()))
	{
		WARNING_MESG("Outstanding error has not been cleared");
		return err;
	}
		
	if (s->connState == kConnClosed) {
		TUSetError(kSessionClosedErr);
		return kSessionClosedErr;
		}		
		
	// send a close packet
	// set up the header fields
	SETADSPWCONNID(s->ackHeader, s->myConnID);
	SETADSPWFSTBYTESEQ(s->ackHeader, s->sendSeq);
	SETADSPWNEXTRECSEQ(s->ackHeader, s->recvSeq);
	SETADSPWRECWIND(s->ackHeader, 0);
	SETADSPWDESC(s->ackHeader, kDescCtrlMsk | kADSPCloseConnAdv);
	
	// now set up the WDS
	writePB.length1 = kADSPAllHdrSiz;
	writePB.buf1 = (unsigned char *)PBUFADDR(s->ackHeader);
	writePB.length2 = 0;
	writePB.buf2 = nil;
	err = PWritePacketSync(&writePB);
	if(err)
		TUSetError(PCheckError());

	s->connState = kConnClosing;
	s->timer = GetCurrentTime() + s->timeoutTicks;

	return TUGetError();
}

unsigned short _TUOpenDialogPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header)
{
char		openSubheader[kADSPOpenSubheadSiz];
OSErr		theErr;

	FifoRead(f, (unsigned char *)openSubheader, kADSPOpenSubheadSiz);
	switch (packetType) {
		case kADSPOpenConnReq:						// open connection request
			if (s->connState == kConnRecvReq) {
				// the first packet in to the other guy got dropped, resend the accept
				s->connState = kConnListening;
				}
			// fall through to rest of open code
		case kADSPOpenConnReqAck:					// open connection req and ack
			if ((s->connState == kConnClosing) || (s->connState == kConnClosed)) {
				if (TUDenyConnection(s) < 0)
					return kADSPOpenSubheadSiz;
				s->remConnID = 0;
				}
			else if (s->connState == kConnListening) {
				s->remConnID = GETADSPRCONNID(header);
				if(TUAllowConnection(s) < 0)
					return kADSPOpenSubheadSiz;
				s->connState = kConnRecvReq;
				}
			else {
				s->remConnID = GETADSPRCONNID(header);
				if(TUSendOpenAck(s) < 0)
					return kADSPOpenSubheadSiz;
				if (s->sendSeq > 0) {
					if (s->firstRtmtSeq > 0) {
						ERROR_MESG("Open Dialog failure with flushed bytes");
						break;
						}
					theErr = FifoUnread(&s->writeFifo, s->sendSeq);
					ASSERT_MESG(theErr == 0, "Error on retrans advice while FifoUnread'ing");
					s->sendSeq = 0;
					}
				s->connState = kConnOpen;
				}
			break;				
		case kADSPOpenConnAck:						// open connection ack
			ASSERT_MESG(s->remConnID != 0, "remConnID is zero on OpenConnAck?");
			s->connState = kConnOpen;
			break;				
		case kADSPOpenConnDeny:						// open connection denial
			s->connState = kConnRecvDeny;
			s->remConnID = 0;
			break;
		}
	return kADSPOpenSubheadSiz;
}

// this needs to have an address block in the future
// OSErr TUDenyConnection(SessionRec *s, AddrBlock addr)
OSErr _TUDenyConnection(SessionRec *s)
{
WDS				writePB;
char			openingInfo[kADSPOpenSubheadSiz];
OSErr			err;

	if (CHECKSESSION(s) == false)
		return( TUSetError( kNotASession ));
		
	// send an open packet
	// set up the header fields
	SETADSPWCONNID(s->ackHeader, 0);
	SETADSPWFSTBYTESEQ(s->ackHeader, 0);
	SETADSPWNEXTRECSEQ(s->ackHeader, 0);
	SETADSPWRECWIND(s->ackHeader, 0);
	SETADSPWDESC(s->ackHeader, kDescCtrlMsk | kADSPOpenConnDeny);
	
	// now set up the data field
	SETADSPDATAOPENVERS(openingInfo, kADSPVersion);
	SETADSPDATAOPENDCONN(openingInfo, s->remConnID);
	SETADSPDATAOPENATTNR(openingInfo, 0);
	
	// now set up the WDS
	writePB.length1 = kADSPAllHdrSiz;
	writePB.buf1 = (unsigned char *)PBUFADDR(s->ackHeader);
	writePB.length2 = kADSPOpenSubheadSiz;
	writePB.buf2 = (unsigned char *)openingInfo;
	err = PWritePacketSync(&writePB);
	if(err)
		TUSetError(PCheckError());

	return TUGetError();
}

// this needs to have an address block in the future
// 	eg.  OSErr TUAllowConnection(SessionRec *s, AddrBlock addr)
//
OSErr _TUAllowConnection(SessionRec *s)
{
WDS				writePB;
long			localRemaining;
char			openingInfo[kADSPOpenSubheadSiz];
OSErr			err;

	if (CHECKSESSION(s) == false)
		return( TUSetError( kNotASession ));
		
	// send an open packet
	// set up the header fields
	SETADSPWCONNID(s->ackHeader, s->myConnID);
	SETADSPWFSTBYTESEQ(s->ackHeader, 0);
	SETADSPWNEXTRECSEQ(s->ackHeader, 0);
	localRemaining = FifoRemaining(&s->readFifo) + FifoRemaining(&s->clientFifo);
	if (localRemaining > kPhysBufferSize/2)
		localRemaining = kPhysBufferSize/2;
	SETADSPWRECWIND(s->ackHeader, localRemaining);
	SETADSPWDESC(s->ackHeader, kDescCtrlMsk | kADSPOpenConnReqAck);
	
	// now set up the data field
	SETADSPDATAOPENVERS(openingInfo, kADSPVersion);
	SETADSPDATAOPENDCONN(openingInfo, s->remConnID);
	SETADSPDATAOPENATTNR(openingInfo, 0);
	
	// now set up the WDS
	writePB.length1 = kADSPAllHdrSiz;
	writePB.buf1 = (unsigned char *)PBUFADDR(s->ackHeader);
	writePB.length2 = kADSPOpenSubheadSiz;
	writePB.buf2 = (unsigned char *)openingInfo;
	err = PWritePacketSync(&writePB);
	if(err)
		TUSetError(PCheckError());

	s->timer = GetCurrentTime() + s->timeoutTicks;
	return TUGetError();
}

unsigned short _TUCloseConnPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header)
{
	s->connState = kConnClosing;
	ASSERT_MESG((s->sendSeq == s->firstRtmtSeq), "Peer requested close of session with pending outbound!");
	return 0;
}

unsigned short _TUFwdResetPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header)
{
	FifoInit(&s->readFifo, (unsigned char *)s->pcktRdBuf, kReadFifoLength, kCircularQ);
	FifoInit(&s->clientFifo, nil, 0, kUnusedQ);
	FifoInit(&s->writeFifo, (unsigned char *)s->pcktWrBuf, kWriteFifoLength, kCachingQ);
	s->recvSeq = GETADSPRFSTBYTESEQ(header);
	TUSendFwdResetAck(s);
	return 0;
}

unsigned short _TURetransAdvPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header)
{
unsigned long	newSeq;
OSErr			err;


	if (GETADSPRFSTBYTESEQ(header) >= s->recvSeq) {
		// retrans and the sequence looks good
		newSeq = GETADSPRNEXTRECSEQ(header);
		
		if (newSeq < s->firstRtmtSeq) {
			// this is a request to transmit flushed bytes; aka old packet
			return 0;
			}

		////////////////////////////////////////////////////////////////////////////
		// BRAIN DAMAGE:  This will give the wrong results on networks that can mix up
		// packet ordering.  The assumption is made here that the packets will never
		// be delivered out of order, so we can live with this.  The first term of
		// this is the offending term, but I am just a junior engineer, not smart
		// enough to figure it out with too many beers to care.  And too much attitude.
		////////////////////////////////////////////////////////////////////////////
		if (newSeq > s->sendSeq) 
			err = FifoSkip(&s->writeFifo, newSeq - s->sendSeq);
		else
			err = FifoUnread(&s->writeFifo, s->sendSeq - newSeq);

		if(err)
		{
			TUSetError(err);
			ERROR_MESG("Error on retrans advice while FifoUnread'ing");
			return 0;	// THIS LOOKS LIKE BRAIN DAMAGE TO ME  dj 7/3/94
		}
		s->sendSeq = newSeq;
	}
	return 0;
}


#define PATCHFORANDY

#ifdef PATCHFORANDY
//
// Check the existing errors before calling Netidle.
// TNetIdle doesn't check the existing error, as all callers of
// TNetIdle are supposed to.  This routine was very very old and
// hadn't been updated to the sticky error mechanism.
//
// With this bug, it was possible
// for an existing error to get cleared and not detected by the
// first call to TNetError.  TNetError will eventually find the
// problem, but this can be fatal if the thing that crapped out
// was downloading of a patch, and we think the patch got loaded
// correctly, but it didnt, yet we install it anyway.  -dj 9/1/94
//
// Yes, this does indeed fix the problem.  NULL patches won't get
// installed anymore!  Yay!
//
OSErr _TNetError( void )
{
OSErr	result;

	result = TUGetError();
	if(result)
		return 1;

/* I think this is overkill, so don't put it in.

	result = PGetError();
	if(result)
		return 1;
*/

	result = TNetIdle(0);
	if (result < 0) 
		return 1;
	else
		return 0;
}

#else

OSErr _TNetError( void )
{
OSErr	result;

	result = TNetIdle(0);
	if (result < 0) 
		return 1;
	else
		return 0;
}

#endif

//
// returns the lastError and clears the sticky error flag.
//
OSErr _TCheckError(void)
{
TGlobalType		*glob = GetGlobals();
OSErr		err;

	err = glob->lastTransportError;
	if(err)
		glob->lastTransportError = 0;
		// can't call TUSetError(0) cuz it won't set if there is already an error
	return(err);
}

OSErr _TUSetError(OSErr err)
{
TGlobalType		*glob = GetGlobals();

	if (glob->lastTransportError)
		return glob->lastTransportError;
	
	glob->lastTransportError = err;
	return(err);
}

OSErr _TUGetError(void)
{
TGlobalType		*glob = GetGlobals();

	return(glob->lastTransportError);
}

long _TGetUserRef(SessionRec *s)
{
	return s->userRef;
}

void _TSetUserRef(SessionRec *s, long refCon)
{
	s->userRef = refCon;
}

void _TSetTransportHold(Boolean hold)
{
TGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	ASSERT(glob->TCurrentSession)

	// This could leave us with the session in "hold" mode, which is
	// very bad.  However, given that the current session is a NULL
	// pointer, I'm not sure there's anything left to screw up...
	//
	if (glob->TCurrentSession == NULL) {
		PLogmsg(LOGP_FLAW,
			"ERROR: TransportHold CurrentSession is NULL! (req=%d)\n", hold);
		return;
	}
	
	TSetTransportHoldSession(glob->TCurrentSession, hold);
}

void _TSetTransportHoldSession(SessionRec *s, Boolean hold)
{
	s->transportHold = hold;
	if (hold)
		NetIdle(nil);
}

Boolean _TGetTransportHold(void)
{
TGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	ASSERT(glob->TCurrentSession)
	
	return TGetTransportHoldSession(glob->TCurrentSession);
}

Boolean _TGetTransportHoldSession(SessionRec *s)
{
	return s->transportHold;
}

