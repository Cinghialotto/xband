/*
 *	$Id: NetMisc.c,v 1.2 1995/05/10 11:04:04 jhsia Exp $
 *
 *	$Log: NetMisc.c,v $
 * Revision 1.2  1995/05/10  11:04:04  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		NetMisc.c

	Contains:	Misc GameTalk routines

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <7>	 7/15/94	DJ		made work on server (non-managerized)
		 <6>	 7/14/94	ADS		Managerize NetMisc
		 <5>	  7/7/94	DJ		removed StartupNet
		 <4>	 6/28/94	BET		Add CheckError interface.
		 <3>	 6/10/94	BET		Remove USEDISK macros
		 <2>	 5/26/94	BET		Add USEDISK macros
		 <1>	 5/26/94	BET		first checked in
	To Do:
*/

#include "TransportLayer.h"
#include "NetMisc.h"
#include "NetMiscPriv.h"
#include "Errors.h"


/* if we're not on the simulator, we need to allocate the globals for real */
#ifndef SIMULATOR
NetMiscGlobals gNetMisc;
#endif


//
//  PUBLIC DISPATCHED ROUTINES
//
short			_NetIdle( NetParamBlock *pBlock );
OSErr			_CheckError(void);
unsigned long	_ccitt_updcrc(unsigned int icrc, unsigned char *icp, int icnt);



#ifndef __SERVER__

long
_NetMiscControl ( short command, long data )
{
long			offset;
short			error;
NetMiscGlobals*	globals;
short			ii;

	error = commandSelectorUnknown;

	switch ( command )
		{
		case kHardInitialize:
			/* allocate and initialize our globals */
			GETMGRGLOBALSOFFSET(gNetMisc,offset);
			
			error = AllocateGlobalSpace ( kNetMiscManager, offset, sizeof(NetMiscGlobals), (Ptr *) &globals );
			ASSERT_MESG ( !error, "Can't create netmisc globals" );
			if ( error != noErr )
				{
				return error;
				}
				
			/* install our selectors */
			SetDispatchedFunction ( kNetIdleFunc,		kNetMiscManager,		_NetIdle );
			SetDispatchedFunction ( kCheckError,		kNetMiscManager,		_CheckError );
			SetDispatchedFunction ( kccitt_updcrc,		kNetMiscManager,		_ccitt_updcrc	 );
			break;
		
		case kSoftInialize:
			/* init our globals here */
			error = noErr;
			break;
		
		case kHardClose:
			error = noErr;
			break;
		
		case kSoftClose:
			error = noErr;
			break;
					
		case kCodeBlockMoved:
			error = noErr;
			break;
					
		case kGlobalsMoved:
			error = noErr;
			break;
		}
		
	return error;
}


#endif



short _NetIdle( NetParamBlock *pBlock )
{
	// Do stuff.  This can call through to an XIndication proc, so be careful here
	// if this routine gets bigger.  Typically it just calls the highest level idler.
	return TNetIdle(pBlock);
}


OSErr _CheckError(void)
{
	return TCheckError();
}


