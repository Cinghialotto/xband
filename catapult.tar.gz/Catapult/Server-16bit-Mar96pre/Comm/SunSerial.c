/*
 * $Id: SunSerial.c,v 1.18 1996/02/12 14:46:20 fadden Exp $
 *
 * $Log: SunSerial.c,v $
 * Revision 1.18  1996/02/12  14:46:20  fadden
 * More dances with #ifdef DEBUG.  We want it on for Errors.h (so we still
 * get the assert messages), but if it's off we don't want it turned back
 * on by Server.h (which gets included eventually via Common.h... sigh).
 *
 * Revision 1.17  1996/02/09  19:30:31  fadden
 * Undefine DEBUG, since it's not doing anything useful.
 *
 * Revision 1.16  1996/02/05  20:28:52  fadden
 * Forget the sleep stuff from the previous checkin... just die.
 *
 * Revision 1.15  1996/02/05  13:19:11  fadden
 * Added some comments about the cause of "Attempted Overflow in FifoWrite"
 * error messages.  Added a sleep call to reduce the number of errors in the
 * log, and some comments about what enterprising individuals could do to
 * remove it.
 *
 * Revision 1.14  1996/02/02  15:31:05  fadden
 * Changed atomic(write, ...) to atomic_write(...) in a fit of annoyance.
 * Check the return value, and send ourselves a SIGHUP when it fails.
 *
 * Revision 1.13  1996/01/30  21:15:40  fadden
 * Change GetCurrentTime to do an integer divide instead of a floating-point
 * multiply.
 *
 * Revision 1.12  1996/01/30  14:52:36  steveb
 * Added support for non-pty based connections.  The idea is to remove the
 * extra process acting as the pty master for server connects, thus reducing
 * the total number of processes running on an fe.  SIGHUPs are simulated
 * by calling kill(0, SIGHUP) when EOF is encountered on a socket.
 *
 * Revision 1.11  1996/01/30  02:50:55  fadden
 * More intelligent handling of writeP stuff when gTLayerReading is set.
 *
 * Revision 1.10  1996/01/30  01:46:15  fadden
 * Added support for gTLayerDataReady (SIGIO-based I/O) and gTLayerReading
 * (only block in select() when we're in TListen or TReadData).  Changed
 * select timeout from 100ms to 3sec since it only gets called when needed.
 * Made search for packets in PUProcessIdle a loop to catch all available
 * packets.  Made steveb's cool new read() call a one-shot instead of a loop.
 * Changed some error messages from LOGP_INFO to LOGP_FLAW, and added an
 * error message to a possibly nasty situation.  Added comments with my
 * understanding of the existing code [ in brackets ] to help the next poor
 * sot who gets stuck with this pile of shit.
 *
 * Revision 1.9  1996/01/29  22:08:31  steveb
 * Buffered network reads to reduce the number of syscalls() made getting
 * data from the net.  Initial tests show a reduction from around 2100 reads
 * to only 165 with bufferring.
 *
 * Revision 1.8  1996/01/29  19:15:43  steveb
 * An attempt at reducing the number of times read() is called.
 *
 * Revision 1.7  1995/12/27  14:16:23  ansell
 * Added error checking and return values to some of the low-level routines to
 * handle case where we get a stream of garbage data that overflows a fifo.
 *
 * Revision 1.6  1995/12/21  16:33:54  fadden
 * Set gDebugLastBoxWrite.
 *
 * Revision 1.5  1995/09/13  10:47:17  ted
 * Fixed warnings.
 *
 * Revision 1.4  1995/07/04  22:50:45  fadden
 * Enabled PRINTPACKET, added gDebugWireReadCount and gDebugWireWriteCount.
 *
 * Revision 1.3  1995/05/10  11:04:24  jhsia
 * switch to cvs keywords
 *
 */

//#define TRASHPACKETS 1
#define PRINTPACKET 1

#undef DEBUG
/*
#ifndef DEBUG
# define DEBUG 1
#endif
*/

/*
	File:		StunSerial.c

	Contains:	Physical layer for Sun serial ports.  The general idea here is to launch a blocking
				read thread in a LWP and let it fill the buffer as it will.  When we have a buffer to
				write, we currently just do blocking writes and let them complete as they may.
				They need to spin off their own LWP and flow out the data as the buffer is
				available, since it is possible for the write to block until it can handle the data.


	[ To my knowledge SunSerial.c has never really used LWPs. ++ATM ]

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<26>	01/26/95	SLS		Fix trivial bugs in PacketTrace Link code.
		<25>	11/11/94	BET		Define PRINTPACKET in order to not use the new flake code that I
									have written.
		<24>	11/10/94	BET		Bring mail only connects down to 9 seconds without TOpen fix.
									Yay!
		<23>	10/21/94	BET		Remove <20> part two. It doesn't do anything, it shouldn't be
									there, and it messes things up.
		<22>	10/19/94	ATM		Logmsg doesn't like leading '\n's.
		<21>	10/19/94	ATM		Changed fprintf(stderr, ...) to Logmsg.
		<20>	 9/19/94	ATM		Changed /var/selector/trace to /var/catapult/trace.  Added
									checks for error and EOF to PUReadThreadProc (they don't usually
									do anything; I'm just curious to see if they will).
		<19>	  9/1/94	ATM		Updated Loghexdump calls.
		<18>	 8/23/94	BET		Update PRINTPACKET so it will print by making an empty file
									named /var/selector/log.
		<17>	 8/16/94	BET		So shoot me.
		<16>	  8/8/94	BET		Update PRINTPACKET macros
		<15>	  8/7/94	BET		Fix atomic so it doesn't bail on EWOULDBLOCK.  This was dropping
									characters when the sun fifo would fill.
		<14>	  8/4/94	BET		Add select on read and write pipes.
		<13>	  8/3/94	BET		Include DBConstants.h
		<12>	 7/31/94	BET		Change to non-blocking io in a non-threaded version
		<11>	 7/26/94	BET		Add PRINTPACKET defines.
		<10>	 7/26/94	BET		Remooove kCloseTimeout now that DBConstants.h is included via
									TransportStructs.h
		 <9>	 7/25/94	BET		Move "PHIndicating = false" so it also gets hit in the failure
									case.
		 <8>	 7/25/94	BET		Clean up code a bit, remove frame end checks, always call
									FifoAdjustConsumption after TIndication.
		 <7>	 7/25/94	BET		Update POpen interfaces to unsigned long flags.
		 <6>	 7/21/94	BET		Looks like it is working.
		 <5>	 7/17/94	dwh		Minor debugging tweaks, still not finished.
		 <4>	 7/16/94	dwh		Update for Ted's changes to POpen/PListen
		 <3>	 7/15/94	dwh		Add some line control stuff
		 <2>	 7/13/94	BET		Now that there are fewer fires, make it work.
		 <1>	 7/13/94	BET		first checked in
	To Do:
*/


#include <malloc.h>
#include "PhysicalLayer.h"
#include "PhysicalStructs.h"
#include "SunSerialPriv.h"
#include "TransportLayer.h"
#include "DBConstants.h"
#include "ccitt.h"
#include "NetErrors.h"
#ifndef DEBUG		// we want the assert messages even w/o debug
# define DEBUG	1
# include "Errors.h"
# undef DEBUG
#else
# include "Errors.h"
#endif
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include "NetMisc.h"
#include <stdio.h>
#include <sgtty.h>
#include <sys/filio.h>
#include <errno.h>
#include <unistd.h>
#include <signal.h>

#ifndef DEBUG
# include "Common.h"
# undef DEBUG		// Server.h sets DEBUG
#else
# include "Common.h"
#endif
#include "Common_Log.h"
#include "Common_Missing.h"
#ifdef DEBUG
 ^^^^^;
#endif

// extern protos
OSErr	_PInit(void);
OSErr	_POpen(char *config, unsigned long flags);
OSErr	_PListen(char *config, long flags);
OSErr	_PClose(void);
short	_PNetIdle(NetParamBlock *pBlock);
OSErr	_PWritePacketSync(WDS *sendBuffer);
OSErr	_PWritePacketASync(WDS *sendBuffer);
OSErr	_PUOpenPort(Boolean _listen, char *config);
void	_PUClosePort(void);
OSErr	_PUAsyncReadData(long numBytes, unsigned char *dataBuf);
OSErr	_PUAsyncWriteFifoData(void);
OSErr	PUSunReadDispatch(unsigned char prevChar);
OSErr	_PUProcessIdle(void);
OSErr	PUReadThreadProc(void);
void	PUWriteThreadProc(void);

// internal protos
short PUGetToolProcID(void);
int atomic_write(int fd, char *buf, size_t nbytes);

#define	GetGlobals()	&PGlobals

// globals
PGlobalType		PGlobals;
DECLAREVARSIFTESTING();
extern int errno;
extern FILE *gLogFile;
unsigned long GetCurrentTime(void);

#ifdef DEBUG
 ^^^^^;
#endif

// returns current time in sixtieths
unsigned long GetCurrentTime(void)
{
	struct timeval	tp;

	gettimeofday(&tp, nil);
	//return ((tp.tv_sec*60) + (tp.tv_usec*.00006));
	return ((tp.tv_sec*60) + (tp.tv_usec/16666));
}

OSErr _PInit(void)
{
PGlobalType		*glob = GetGlobals();
struct stat		buf;

	// assume that the globals are clear by now!
	glob->PHLengthsBuf = (unsigned char *)malloc(kFrameStartBufSiz);
	glob->PHReadDataBuf = (unsigned char *)malloc(kPhysBufferSize);
	glob->PHWriteDataBuf = (unsigned char *)malloc(kPhysBufferSize);
	glob->PHStagingBuf = (unsigned char *)malloc(kMaxPacket);
	glob->PHMagic = kMagicVal;
	glob->readHead = glob->writeHead = glob->readTail = glob->writeTail = 0;
	if (stat("/var/catapult/trace", &buf))
		glob->trace = false;
	else
		glob->trace = true;
		
	return noErr;
}

OSErr _POpen(char *config, unsigned long flags)
{
	return PUOpenPort(kOriginate, config);
}

OSErr _PListen(char *config, long flags)
{
	return PUOpenPort(kListen, config);
}

OSErr _PClose(void)
{
NetParamBlock	pBlock;
unsigned long	stopTime, lread, lwrite, lastRead, lastWrite;
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	
	if (glob->PHConnState != kConnClosed) {
		// signal handlers
		TIndication(nil, kConnClosing, 0);
		NetIdle(&pBlock);
		stopTime = GetCurrentTime() + kCloseTimeout;
		while ((pBlock.ioPhysNetState == kConnOpen) && (stopTime < GetCurrentTime())) {
			lread = FifoAvailable(&glob->PHReadFifo);
			lwrite = FifoAvailable(&glob->PHWriteFifo);
			if ((lastRead != lread) || (lastWrite != lwrite)) {
				lastRead = lread;
				lastWrite = lwrite;
				stopTime = GetCurrentTime() + kCloseTimeout;
				}
			}
		PUClosePort();
		glob->PHConnState = kConnClosed;
		}
	return noErr;
}


// NetIdle -- returns kNetPrimed (0) if net is idle, kNetPrimed (1) if ready,
//	negative gen purpose error code on failure.
short _PNetIdle(NetParamBlock *pBlock)
{
PGlobalType		*glob = GetGlobals();

	//PLogmsg(LOGP_DBUG, "--- PNetIdle\n");
	CHECKMAGIC(glob);
	
	// dump the crap somewhere if we don't have a place to put it
	if (pBlock) {
		pBlock->ioLastPhysicalError = noErr;
		pBlock->ioAvailable = 0;
		pBlock->ioTotal = glob->PHTotalIn;
		pBlock->ioPhysNetState = kConnClosed;
		}
		
	switch (glob->PHConnState) {
		case kConnOpen:
			if (pBlock)
				pBlock->ioPhysNetState = kConnOpen;
			break;
		case kConnClosed:
		case kConnClosing:
			break;
		default:
			ASSERT_MESG(0,"Unhandled connection state case!");
		};
	
	return PUProcessIdle();
}

OSErr _PWritePacketSync(WDS *sendBuffer)
{
short			retVal;
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	if (glob->PHConnState != kConnOpen) 
		return kLinkClosed;

	retVal = PWritePacketASync(sendBuffer);
	if (retVal) return retVal;
	
	// [ Note we don't check for errors here.  I *think* we'd want to
	//   put the error in glob->PHLastError so PCheckError will show it
	//   back in TransportLayer.c, but that's more messing around than
	//   I want to do at this point. ++ATM 960205 ]
	while (glob->PHWriteActive)
		PNetIdle(nil);
		
	return noErr;
}

OSErr _PUProcessIdle(void)
{
extern int		gTLayerDataReady;		// SIGIO-based I/O
extern int		gTLayerReading;			// boolean; should we block on read
short			frameSize, retVal;
PGlobalType		*glob = GetGlobals();
unsigned char	buf[256];
struct timeval	tv;
fd_set			readSet, writeSet, *writeP;
int				res;

	if (glob->PHIndicating)
		return noErr;

	// If gTLayerDataReady is 1 we have data, if -1 we failed to set up
	// SIGIO correctly.  Either way we want to continue through the routine.
	// The only time we want to bail is if the flag==0, because that means
	// SIGIO is working but nothing is ready.
	//
	// Don't skip over the read if we want to block waiting for I/O.
	//
	retVal = noErr;
	if (!gTLayerDataReady && !gTLayerReading)
		goto failed;

	// We want to clear this BEFORE we read data... if we clear it afterward,
	// we create a race condition unless we mask signals.  This could cause
	// us to receive a second signal when no data is pending (because we
	// read two batches of data the first time through), but at worst that's
	// one extra read() call.
	//
	if (gTLayerDataReady > 0) {
		//Logmsg("Cleared gTLayerDataReady\n");
		gTLayerDataReady = 0;
	}

	// [ Set up the file descriptor sets for reading, and if data is
	//   pending set one up for writing.  In practice the write fdset
	//   almost never gets set, because the "atomic" write call spins
	//   when it gets an EWOULDBLOCK, so there's never any data that's
	//   pending on a blocked fd.  Besides, the ADSP flow control is
	//   so restrictive that there's rarely on opportunity for the
	//   network buffers to fill up. ++ATM ]
	//
	FD_ZERO(&readSet);
	FD_SET(fileno(stdin), &readSet);
	if (FifoAvailable(&glob->PHWriteFifo)) {
		FD_ZERO(&writeSet);
		FD_SET(fileno(stdout), &writeSet);
		writeP = &writeSet;
		}
	else
		writeP = nil;
	
#ifdef ORIGINAL_SELECT
	tv.tv_sec = 0;
	tv.tv_usec = 100000;
	res = select(4, &readSet, writeP, nil, &tv);
#else
	{
		//extern long gDebugWireReadCount, gDebugWireWriteCount;

		// Only pause if we're waiting for data to arrive.  If we have
		// data that needs to be written, don't go to sleep!
		//
		if (gTLayerReading && writeP == NULL) {
			//Logmsg("Before select, wireRead=%ld, writeWrite=%ld\n",
			//	gDebugWireReadCount, gDebugWireWriteCount);
			//tv.tv_sec = 0;
			//tv.tv_usec = 100000;
			tv.tv_sec = 3;	// should match keep-alive timeout
			tv.tv_usec = 0;
			res = select(4, &readSet, NULL, NULL, &tv);
		}
	}
#endif
	
	// [ Read as many bytes from the network as are available, calling
	//   PUSunReadDispatch after every byte. Note that more than one
	//   packet may have arrived. ++ATM ]
	//
	retVal = PUReadThreadProc();
	if (retVal) 
		goto failed;

	// [ Read from the PHLengthsFifo, which was written to down in
	//   PUSunReadDispatch if it found a complete packet.  So if this
	//   FifoRead succeeds, we must have a complete packet.
	//
	//   This probably ought to be a FifoAvailable call, but I figure it's
	//   safer to stick with the original. ++ATM ]
	//
#ifdef PREVIOUS
	retVal = FifoRead(&glob->PHLengthsFifo, (unsigned char *)&frameSize,
		sizeof(short));
	if (retVal == noErr) {
#endif

	while ( (retVal = FifoRead(&glob->PHLengthsFifo,
					(unsigned char *)&frameSize, sizeof(short))) == noErr)
	{
		glob->PHIndicating = true;
		// checksum happens in the fifo to avoid gratuitous copying
		if ((FifoChkSum(&glob->PHReadFifo, frameSize - kFramingSize) == 0x1D0F)
				&& (frameSize > kPhysHdrSiz + kFCSSize + kFramingSize)) {
			if (glob->trace) {
				FifoPeek(&glob->PHReadFifo, buf, frameSize);
#ifdef PRINTPACKET
				gettimeofday(&tv, nil);
				Logmsg("\n");
				Logmsg("read good (%09.9d.%06.6d):\n", tv.tv_sec, tv.tv_usec);
				Loghexdump(buf, frameSize);
				fflush(gLogFile);
#else
				p = (Packet *)malloc(sizeof(Packet) + frameSize);
				p->next = NULL;
				gettimeofday(&p->timestamp, nil);
				p->length = frameSize;
				p->flags |= kReadGood;
				memcpy(p->data, buf, frameSize);
				p->next = 0;
				if (!glob->readHead) /* this must be the first packet */
				  glob->readHead = p;
				if (glob->readTail) 
				  glob->readTail->next = p;
				glob->readTail = p;
#endif
				}

			retVal = FifoSkip(&glob->PHReadFifo, kPhysHdrSiz);
			if (retVal) goto failed;
	
			retVal = FifoResetConsumption(&glob->PHReadFifo);
			if (retVal) goto failed;
			
			// Always call FifoAdjustConsumption, but return the error from TInd if there is one 
			retVal = TIndication(&glob->PHReadFifo, glob->PHConnState, frameSize - (kPhysHdrSiz + kFCSSize + kFramingSize));
			FifoAdjustConsumption(&glob->PHReadFifo, frameSize - (kPhysHdrSiz + kFCSSize + kFramingSize));
			if (retVal) goto failed;

			retVal = FifoSkip(&glob->PHReadFifo, kFramingSize+kFCSSize);
			if (retVal) goto failed;
			}
		else {
			// BRAIN DAMAGE: record bad packet reception here 
			WARNING_MESG("Bad Packet Detected");
			if (glob->trace) {
				FifoPeek(&glob->PHReadFifo, buf, frameSize);
#ifdef PRINTPACKET
				gettimeofday(&tv, nil);
				Logmsg("\n");
				Logmsg("READ BAD  (%09.9d.%06.6d):\n", tv.tv_sec, tv.tv_usec);
				Loghexdump(buf, frameSize);
				fflush(gLogFile);
#else
				p = (Packet *)malloc(sizeof(Packet) + frameSize);
				p->next = NULL;
				gettimeofday(&p->timestamp, nil);
				p->length = frameSize;
				memcpy(p->data, buf, frameSize);
				p->next = 0;
				if (!glob->readHead) 				/* first packet */
					glob->readHead = p;
				if (glob->readTail)
				  glob->readTail->next = p;
				glob->readTail = p;
#endif
				}
				
			retVal = FifoSkip(&glob->PHReadFifo, frameSize);
			if (retVal) goto failed;
			}
		}

	// [ This happens if we didn't have a full packet yet, so we want to
	//   clear the error status so we don't mistakenly report an error.
	//   Sucks that we re-use retVal above, but all of the error states
	//   jump directly to "failed". ++ATM ]
	//
	if (retVal == kFifoUnderflowErr)
		retVal = noErr;
	
failed:
	glob->PHIndicating = false;

	PUAsyncWriteFifoData();

	if (retVal)
		PUSetError(retVal);
	return retVal;
}

// queue small chunks as we find kDLEChar's scattered through the outgoing buffer
// called by TWriteDataSync, and in turn TWriteDataASync
OSErr _PWritePacketASync(WDS *sendBuffer)
{
OSErr			theErr;
long			bufLength, iter, padPoint;
unsigned char	*addr;
unsigned short	crc;
Boolean			doingFCS;
PGlobalType		*glob = GetGlobals();

	if ((theErr = PGetError())) {
		ERROR_MESG("Outstanding error has not been cleared");
		return theErr;
		}

	if (glob->PHConnState != kConnOpen) 
		return PUSetError(kLinkClosed);

	// for those bad days when everything is a frame char, the worst case packet size is 2x
	bufLength = (sendBuffer->length1 + sendBuffer->length2 + kFCSSize + kFramingSize) * 2;
	if (FifoRemaining(&glob->PHWriteFifo) < bufLength) {
		// we have more to write than the fifo can handle.  Idle here if
		// if the buffer is big enough to ever handle it, otherwise idle until
		// FifoAvailable is zero and switch buffers.
		if (FifoSize(&glob->PHWriteFifo) > bufLength) {
			// the fifo can handle it, just not right now.  Idle a bit
			while (FifoRemaining(&glob->PHWriteFifo) < bufLength) {
				theErr = PNetIdle(nil);
				if (theErr < 0) return theErr;
				}
			}
		else {
			// the buffer is bigger than the fifo
			ASSERT_MESG(0,"The packet write fifo isn't big enough to for this buffer");
			}
		}
	
	bufLength = sendBuffer->length1;
	addr = sendBuffer->buf1;
	padPoint = iter = 0;
	crc = 0xffff;
	doingFCS = false;
	while (1) {
		// (doingFCS == true) signals the writing of the FCS itself
		if (!doingFCS)
			crc = ccitt_updcrc(crc, (unsigned char *)addr, bufLength);
		while (iter < bufLength) {
			if (addr[iter] == kDLEChar) {
				iter += 1;
				TRASHHEADERIFTESTING();
				theErr = FifoWrite(&glob->PHWriteFifo, &addr[padPoint], iter - padPoint);
				LASTTRASHHEADERIFTESTING();
				if (theErr) return PUSetError(theErr);
				if (iter <= bufLength) {
					// send a pad
					theErr = FifoWrite(&glob->PHWriteFifo, &addr[iter-1], 1);
					if (theErr) return PUSetError(theErr);
					padPoint = iter;
					}
				}
			else {
				iter += 1;
				if (iter == bufLength) {
					TRASHHEADERIFTESTING();
					// flush the rest of the buffer
					theErr = FifoWrite(&glob->PHWriteFifo, &addr[padPoint], bufLength - padPoint);
					LASTTRASHHEADERIFTESTING();
					if (theErr) return PUSetError(theErr);
					}
				}
			}
		if (doingFCS)
			break;
		else if (addr == sendBuffer->buf1) {
			// if the address is the first buffer then it should be the second next loop
			padPoint = iter = 0;
			bufLength = sendBuffer->length2;
			addr = sendBuffer->buf2;
			UPDATEVARSIFTESTING();
			}
		else {
			// if the address is not the FCS and not the first buffer then it 
			// is the second and we should set up for the FCS
			crc = ~crc;
			padPoint = iter = 0;
			bufLength = sizeof(crc);
			addr = (unsigned char *)&crc;
			doingFCS = true;
			TRASHCRCIFTESTING();
			}
		}
		
	// send the framing
	crc = (kDLEChar<<8) + kETXChar;

	TRASHENDIFTESTING();

	theErr = FifoWrite(&glob->PHWriteFifo, (unsigned char *)&crc, sizeof(crc));
	if (theErr) return PUSetError(theErr);
	
	// call netidle to get the write rolling
	theErr = PNetIdle(nil);
	if (theErr) return theErr;
	
	return noErr;
}


OSErr _PUAsyncWriteFifoData(void)
{
short			theErr;
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	if (glob->PHConnState != kConnOpen) 
		return kLinkClosed;

	if ((glob->PHWriteActive == false) && FifoAvailable(&glob->PHWriteFifo)) {
		PUWriteThreadProc();
		}
	return theErr;
}

// maybe we should delay after EWOULDBLOCK instead of spinning? ++ATM 951220
int
atomic_write(int fd, char *buf, size_t nbytes)
{
	int cc = 0, need = nbytes;

	do {
		while ((cc = write(fd, buf, need)) > 0 && (need -= cc) > 0)
			buf += cc;
	} while (need && (errno == EWOULDBLOCK));

	return (cc < 0 ? cc : nbytes - need);
}


// [ Somebody else gets to figure out what all this is doing.  The most
//   interesting fact is that write calls are done with a call to "atomic",
//   which spins on write even if EWOULDBLOCK is returned.
//
//   Called from _PUAsyncWriteFifoData, which was in turn called from
//   the end of PUProcessIdle. ++ATM ]
//
void
PUWriteThreadProc(void)
{
unsigned long	fifoAvailable;
OSErr			theErr;
PGlobalType		*glob = GetGlobals();
struct timeval	tv;
extern long		gDebugWireWriteCount;
extern unsigned long	gDebugLastBoxWrite;

	fifoAvailable = FifoAvailable(&glob->PHWriteFifo);
	while (fifoAvailable) {
		if (fifoAvailable > kMaxPacket)
			fifoAvailable = kMaxPacket;
		theErr = FifoRead(&glob->PHWriteFifo, glob->PHStagingBuf, fifoAvailable);

	#ifdef DEBUG
		FifoWrite(&glob->testWrite, glob->PHStagingBuf, fifoAvailable);
		FifoSkip(&glob->testWrite, fifoAvailable);
	#endif
		glob->PHTotalOut += fifoAvailable;
	
		if (atomic_write(fileno(stdout), glob->PHStagingBuf, fifoAvailable) < 0)
		{
			int err = errno;

			PLogmsg(LOGP_FLAW, "ERROR: atomic_write failed (err=%d)\n", err);
			// There's no way to propagate errors that I can see; theErr
			// is never used and the function returns void.  Probably some
			// way to set a global error status, but why bother when you
			// can just kill yourself.
			//
			if (err != EPIPE) {
				PLogmsg(LOGP_FLAW,
					"WARNING: aborting on non-EPIPE write failure (%d)\n", err);
			}
			kill(0, SIGHUP);
			Common_Abort();
		} else {
			gDebugWireWriteCount += fifoAvailable;
			gDebugLastBoxWrite = time(0);
		}

		if (glob->trace) {
#ifdef PRINTPACKET
			gettimeofday(&tv, nil);
			Logmsg("\n");
			Logmsg("writing   (%09.9d.%06.6d):\n", tv.tv_sec, tv.tv_usec);
			Loghexdump(glob->PHStagingBuf, fifoAvailable);
			fflush(gLogFile);
#else
			p = (Packet *) malloc(sizeof(Packet) + fifoAvailable);
			p->next = NULL;
			gettimeofday(&p->timestamp, nil);
			p->length = fifoAvailable;
			memcpy(p->data, glob->PHStagingBuf, fifoAvailable);
			p->next = 0;
			if (!glob->writeHead)
				glob->writeHead = p;
			if (glob->writeTail)
			  glob->writeTail->next = p;
			glob->writeTail = p;
#endif
			}

		fifoAvailable = FifoAvailable(&glob->PHWriteFifo);
		}
	glob->PHWriteActive = false;
}

OSErr _PUOpenPort(Boolean _listen, char *config)
{
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	
	if (glob->PHConnState == kConnOpen)
		return noErr;
	
	PCheckError();
	// set up the fifo
	FifoInit(&glob->PHReadFifo, glob->PHReadDataBuf, kPhysBufferSize, kCircularQ);
	FifoInit(&glob->PHWriteFifo, glob->PHWriteDataBuf, kPhysBufferSize, kCircularQ);
	FifoInit(&glob->PHLengthsFifo, glob->PHLengthsBuf, kFrameStartBufSiz, kCircularQ);
	glob->PHFrameSizAccum = 0;
	
	glob->PHReadyBuffer = nil;
	
#ifdef DEBUG
	// test code
	FifoInit(&glob->testRead, (unsigned char *)calloc(10000,1), 10000, kCircularQ);
	FifoInit(&glob->testWrite, (unsigned char *)calloc(10000,1), 10000, kCircularQ);
#endif
	
	glob->PHPacketState = kProcessingST;
	
	glob->PHConnState = kConnOpen;
	
	return noErr;
}

void _PUClosePort(void)
{
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	
#ifdef DEBUG
	free(glob->testRead.bufStart);
	free(glob->testWrite.bufStart);
#endif
	
 	return;
}

// this allocs a very small automatic buffer.  We will get chars so slowly that the select
// will probably only get them one at a time.  An opt here _might_ be to get them less frequently,
// but only if the wait is omnicient and can tell that there is a frame end in the buffer.
//
// [ This will read as much data as is available from the network.  The
//   above comments are wrong -- data arrives in chunks of several bytes
//   at a time, often enough for two full packets and then some. ++ATM ]
//
OSErr
PUReadThreadProc(void)
{
	OSErr			err;
	int				i, amount;
	unsigned char	buf[1024];
	extern long		gDebugWireReadCount;

	do {
		// This read() would block on a network socket, but it won't since
		// we're using a pty.
		// [ We may not be using a pty anymore, but if we use a socket
		//   we'll have it set non-blocking anyway. ++ATM ]
		// [ We're not using a pty anymore, and the socket is set
		//   to non-blocking. ++SB ]
		//
		amount = read(fileno(stdin), buf, 1024);
		//PLogmsg(LOGP_DBUG, "read %d\n", amount);

		if (amount <= 0) 
			break;

		gDebugWireReadCount += amount;

		// this guy likes it one at a time.  He has to have it this way because
		// he is looking for both byte stuffing and framing.
		for ( i = 0; i < amount; i++ ) {
			if ((err = PUSunReadDispatch(buf[i])))
				return(err);
		}
	} while (0 /*1*/);		// only do the read() call once

	if (amount < 0 && errno != EWOULDBLOCK) {
		PLogmsg(LOGP_FLAW, "PUReadThreadProc: errno %d reading fd %d\n",
			errno, fileno(stdin));
	}

	// If (amount == 0), we just hit EOF.  On a pty, we don't care, since
	// we'll get slammed with a SIGHUP anyway.
    if (amount == 0) {
        Logmsg("EOF on input stream\n");
        kill(0, SIGHUP);
    }

	return (noErr);
}


// this is detatched from the main line of the code so that it can better match
// against other physical layers that contain it this way
//
// [ Given one byte read from the box, determine if we've reached the end
//   of a frame.  Also handles escaped delimiter bytes.  The "packet length"
//   fifo has the length written to it, which indicates to PUProcessIdle
//   that a packet has been received. ++ATM ]
//
OSErr
PUSunReadDispatch(unsigned char prevChar)
{
PGlobalType		*glob = GetGlobals();
OSErr			theErr;

	CHECKMAGIC(glob);
	
#ifdef DEBUG
	// Add to the fifo, then dump it out.  Gives us a buffer that never fills.
	FifoWrite(&glob->testRead, &prevChar, 1);
	FifoSkip(&glob->testRead, 1);
#endif
	
	// Should we be updating PHFrameSizAccum even when FifoWrite fails??
	// ++ATM 960129
	theErr = FifoWrite(&glob->PHReadFifo, &prevChar, 1);
	glob->PHFrameSizAccum += 1;
	
	if (theErr) {
		// The error will propagate up about five levels to PWritePacketSync,
		// which will then fail to report it to the TLayer routine which
		// called it.  See the notes there for details if you want to fix
		// this to work right.
		//
		// Until then, just go to sleep for a second to avoid having 2000
		// lines of "Attempted Overflow in FifoWrite" messages in the log.
		//
		// Update: screw it, just die.
		//
		PLogmsg(LOGP_FLAW, "NOTE: PHFrameSizAccum may be twisted; dying\n");
		//return theErr;
		kill(0, SIGHUP);
		Common_Abort();
	}

	// first check for frame end
	if ((glob->PHPacketState == kCheckNextST) && (prevChar == kETXChar)) {
		// yep, the last one was a frame
		FifoWrite(&glob->PHLengthsFifo, (unsigned char *)&glob->PHFrameSizAccum, sizeof(short));
		glob->PHFrameSizAccum = 0;
		glob->PHPacketState = kProcessingST; 			// reset for next time
		}
	else if (prevChar == kDLEChar) {					// found a DLE?
		if (glob->PHPacketState == kCheckNextST) { 		// yep, did we just see one?
			FifoUnwrite(&glob->PHReadFifo, 1);			// yep, dump this one
			// update fram size accumulator
			glob->PHFrameSizAccum -= 1;
			glob->PHPacketState = kProcessingST; 		// reset for next time
			}
		else											// didn't just see one, prepare to
			glob->PHPacketState = kCheckNextST;			// dump next one if there is one
		}
	else {
		glob->PHPacketState = kProcessingST; 			// either way the next is something!
		}
	return(noErr);
}

OSErr _PUSetError(OSErr err)
{
PGlobalType		*glob = GetGlobals();

	glob->PHLastError = err;
	return err;
}

OSErr _PGetError(void)
{
PGlobalType		*glob = GetGlobals();

	return glob->PHLastError;
}

OSErr _PCheckError(void)
{
OSErr			err;
PGlobalType		*glob = GetGlobals();

	err = glob->PHLastError;
	glob->PHLastError = noErr;
	return err;
}

#ifdef DEADCODE
// this monster takes the timeval rec that is passed in and adds the requested timeout
// to the queue.  Then it finds out the first time that is requested and returns it.
// This returned time is the time that select should return and call NetIdle.
OSErr PUSleepQueue(struct timeval *nextTime)
{
struct timeval	thisTime;
long			sec, ms, ticks;
short			lastIndex, newIndex, count;
OSErr			err;
PGlobalType		*glob = GetGlobals();
	
	err = noErr;
	gettimeofday(&thisTime, nil);
	
	// first update the queue information
	sec = thisTime.tv_sec - glob->PHTimeQueue.lastService.tv_sec;
	ms = thisTime.tv_usec - glob->PHTimeQueue.lastService.tv_usec;
	if (ms < 0) {
		ms += 1000;
		sec -= 1;
		}
		
	ticks = (((ms + (sec * 1000)) * kTicksASec) / 1000);
	lastIndex = glob->PHTimeQueue.lastIndex;
	
	
	// when we update the lastIndex, we need to clear all the bytes that we skip.
	// verify that we have been called sooner than kWakeupSlots ticks
	if (ticks >= kWakeupSlots) {
		// nope clear it all out
		memset(glob->PHTimeQueue.wakeup, 0, kWakeupSlots*sizeof(unsigned char));
		newIndex = glob->PHTimeQueue.lastIndex = 0;
		}
	else {
		// yes, we need to be more savvy with clearing the memory
		newIndex = lastIndex + ticks;
		if (newIndex >= kWakeupSlots) {
			newIndex -= kWakeupSlots;
			memset(&glob->PHTimeQueue.wakeup[lastIndex], 0, (kWakeupSlots - lastIndex)*sizeof(unsigned char));
			lastIndex = 0;
			}
		memset(&glob->PHTimeQueue.wakeup[lastIndex], 0, (newIndex - lastIndex)*sizeof(unsigned char));
		glob->PHTimeQueue.lastIndex = newIndex;
		}
		
	glob->PHTimeQueue.lastService = thisTime;
	
	// now add the new entry if it is nonzero
	if (nextTime->tv_sec || nextTime->tv_usec) {
		sec = nextTime->tv_sec - thisTime.tv_sec;
		ms = nextTime->tv_usec - thisTime.tv_usec;
		if (ms < 0) {
			ms += 1000;
			sec -= 1;
			}
		ticks = (((ms + (sec * 1000)) * kTicksASec) / 1000);
		if (ticks >= kWakeupSlots) {
			// wait request is bigger than our queue.  We handle this by waiting as long
			// as possible.  It is currently not fatal if the timer skips a beat or two, but the queue should
			// really be increased if this is happening.
			ticks = kWakeupSlots - 1;
			err = kTimeout;
			}
		lastIndex = newIndex;
		newIndex += ticks;
		if (newIndex > kWakeupSlots)	
			newIndex -= kWakeupSlots;
		glob->PHTimeQueue.wakeup[newIndex] += 1;
		}
	
	// finally find the next timeout
	ticks = 0;
	for (count = lastIndex; count < kWakeupSlots; count++) {
		if (glob->PHTimeQueue.wakeup[count])
			break;
		ticks += 1;
		}
	
	if (count == kWakeupSlots) {	
		for (count = 0; count < lastIndex; count++) {
			if (glob->PHTimeQueue.wakeup[count])
				break;
			ticks += 1;
			}
		}
	
	// when we get here, ticks is either set to the first timeout or the count of array entries
	// figure time offset from the current time...
	nextTime->tv_sec = ticks/kTicksASec;
	nextTime->tv_usec = (ticks - ((nextTime->tv_sec*kTicksASec) * 1000/kTicksASec));
	// ...and add the current time
	nextTime->tv_sec += thisTime.tv_sec;
	nextTime->tv_usec += thisTime.tv_usec;
	if (nextTime->tv_usec >= 1000) {
		nextTime->tv_usec -= 1000;
		nextTime->tv_sec += 1;
		}
	
	return err;
}
#endif

