/*
 *	$Id: PhysicalLayer.h,v 1.4 1995/09/13 10:47:16 ted Exp $
 *
 *	$Log: PhysicalLayer.h,v $
 * Revision 1.4  1995/09/13  10:47:16  ted
 * Fixed warnings.
 *
 * Revision 1.3  1995/05/10  11:04:16  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		PhysicalLayer.h

	Contains:	Physical layer headers

	Written by:	Brian Topping, Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<46>	 8/25/94	HEC		hangup param to PUCheckAnswer
		<45>	 8/24/94	BET		Ooops, forgot to remove the DEBUGCHATSCRIPT ifdefs.
		<44>	 8/24/94	BET		Add kChatDebugFifoSize stuff to DBConstants, make DEBUGCHAT
									happen all the time, add some robustness to the script
									navigators.
		<43>	 8/23/94	HEC		Changed PUCheckRing
		<42>	 8/21/94	HEC		turned off chatdebug in the build
		<41>	 8/20/94	BET		Add DEBUGCHATSCRIPT stuff.
		<40>	  8/8/94	DJ		Added PUCheckRing prototype
		<39>	  8/6/94	HEC		Added PUCheckRing.
		<38>	  8/2/94	BET		Add param to POpen
		<37>	  8/1/94	HEC		Removed obsolete protos.
		<36>	 7/29/94	HEC		Added PUCheckCarrier. Renamed PUCheckLineNoise to PUCheckLine.
		<35>	 7/26/94	BET		_POpen takes unsigned long flags in prototype
		<34>	 7/23/94	BET		Update dialing script structure.
		<33>	 7/22/94	BET		Move POpen flags to PhysicalStructs.h.
		<32>	 7/22/94	BET		Add code to dial into "800 service".  Still need to go through
									and add all the database entries for portal service prompts and
									timeouts.  Also need to add code to figure which service to ask
									for based on the number we are dialing (search on 800 prefix?).
									Everything else is there.
		<31>	 7/17/94	KON		Fix PUAsyncReadDispatch just for Teddis.
		<30>	 7/17/94	HEC		Added kPUAsyncReadDispatch just for Andy.
		<29>	 7/16/94	HEC		Managerize PModem calls.
		<28>	 7/15/94	HEC		Changed POpen/PListen server param to more general flags.
		<27>	 7/13/94	HEC		Added PUReceiveBufferAvail.
		<26>	 7/13/94	BET		unix-ise.
		<25>	  7/9/94	HEC		Added PIsNumberBusy.
		<24>	  7/9/94	BET		Add unused synchronization call so it doesn't get lost.
		<23>	  7/5/94	BET		Remove late-night semicolons.
		<22>	  7/5/94	BET		Add sticky error routines and update PModem to use them.
		<21>	  7/3/94	HEC		Adding server boolean to PListen and PListenAsync
		<20>	  7/2/94	KON		Added defines for use server protocol and use peer protocol in
									POpen.
		<19>	  7/2/94	HEC		POpen and POpenAsync now take flag which tells if we're calling
									server or peer.
		<18>	 6/21/94	BET		Add PUReceiveBufferAvail/
		<17>	 6/20/94	BET		Add PUSetupServerTalk and PUTearDownServerTalk for Dave.
		<16>	 6/20/94	BET		Add some async infastructure
		<15>	 6/20/94	BET		Checkin changes for aborted GameTalk removal.
		<14>	 6/18/94	BET		Add async calls
		<13>	 6/16/94	BET		Dwain Bamage
		<12>	 6/16/94	BET		Dwain Bamage
		<11>	 6/14/94	BET		Add more GameTalk API
		<10>	 6/13/94	BET		Add API for GameTalk
		 <9>	  6/9/94	BET		Callbacks had wrong macros for server build
		 <8>	  6/5/94	BET		Add more FUD
		 <7>	  6/3/94	BET		Add more FUD
		 <6>	  6/2/94	BET		Change the way globals are accessed
		 <5>	  6/1/94	BET		Fix some late arrivals
		 <4>	  6/1/94	BET		Added API for SegaSerial
		 <3>	 5/31/94	BET		Changed a (char *) to (unsigned char *).  Added some API
		 <2>	 5/26/94	BET		Check in Shannon's start on changes for patchable managers, my
									changes for making work on the server.  Not verified yet on
									SegaOS.
	To Do:
*/

#ifndef __PhysicalLayer__
#define __PhysicalLayer__


#include "NetStructs.h"
#include "PhysicalStructs.h"
#ifndef unix
#include "OSManagers.h"
#include "Dispatcher.h"
#endif

OSErr	_PInit(void);
OSErr	_POpen( char *, unsigned long );
OSErr	_PListen(char *, long );
OSErr	_POpenAsync( char *, long );
OSErr	_PListenAsync( char *, long);
OSErr	_PClose(void);
OSErr	_PNetIdle(NetParamBlock *);
OSErr	_PWritePacketSync(WDS *);
OSErr	_PWritePacketASync(WDS *);
OSErr	_PUOpenPort(Boolean, char *);
void	_PUClosePort(void);
OSErr	_PUAsyncReadData(long, unsigned char *);
OSErr	_PUAsyncWriteFifoData(void);
OSErr	_PUProcessIdle(void);
short	_PUProcessSTIdle(unsigned short length);
//void	_PUAsyncReadDispatch(struct PGlobalType *, unsigned char);

OSErr	_PUReadSerialByte (unsigned char *);
OSErr	_PUWriteSerialByte (unsigned char);
OSErr	_PUTransmitBufferFree (void);
short	_PUReceiveBufferAvail(void);
OSErr	_PUTestForConnection (void);
long	_PUReadTimeCallback(long, long);
long	_PUWriteTimeCallback(long, long);
Boolean _PUSetupServerTalk(void);
Boolean _PUTearDownServerTalk(void);
OSErr	_PUSetError(OSErr);
OSErr 	_PGetError(void);
OSErr	_PCheckError(void);
OSErr	_PClearPhysLine(void);
Boolean	_PUIsNumberBusy(char *);
OSErr	_PUDoSelectorLogin(ServiceScript *);
OSErr 	_PUMatchString(ServicePair *, unsigned long);
Boolean	_PUCheckRing(short);
Ptr		_PGetDebugChatScript(long *);

#ifdef __SERVER__

#define	PInit()					_PInit()
#define	POpen(a,b)				_POpen(a,b)
#define	PListen(a,b)			_PListen(a,b)
#define	POpenAsync(a,b)			_POpenAsync(a,b)
#define	PListenAsync(a,b)		_PListenAsync(a,b)
#define	PClose()				_PClose()
#define	PNetIdle(p) 			_PNetIdle(p)
#define	PWritePacketSync(p)		_PWritePacketSync(p)
#define	PWritePacketASync(p)	_PWritePacketASync(p)
#define	PUOpenPort(p, b)		_PUOpenPort(p, b)
#define	PUClosePort()			_PUClosePort()
#define	PUAsyncReadData(p,q)	_PUAsyncReadData(p,q)
#define	PUAsyncWriteFifoData()	_PUAsyncWriteFifoData()
#define	PUProcessIdle()			_PUProcessIdle()
#define	PUProcessSTIdle(a)		_PUProcessSTIdle(a)
#define	PUAsyncReadDispatch(a,b) _PUAsyncReadDispatch(a,b)
#define	PUReadSerialByte(a)		_PUReadSerialByte(a)
#define	PUWriteSerialByte(a)	_PUWriteSerialByte(a)
#define	PUTransmitBufferFree()	_PUTransmitBufferFree()
#define	PUTestForConnection()	_PUTestForConnection()
#define	PUReadTimeCallback(a,b)	_PUReadTimeCallback(a,b)
#define	PUWriteTimeCallback(a,b) _PUWriteTimeCallback(a,b)
#define	PUSetupServerTalk()		_PUSetupServerTalk()
#define	PUTearDownServerTalk()	_PUTearDownServerTalk()
#define	PUSetError(a)			_PUSetError(a)
#define	PGetError()				_PGetError()
#define	PCheckError()			_PCheckError()
#define PClearPhysLine()		_PClearPhysLine()
#define PUIsNumberBusy(a)		_PUIsNumberBusy(a)
#define PUReceiveBufferAvail()	_PUReceiveBufferAvail()
#define PUOriginateAsync(a,b)	_PUOriginateAsync(a,b)
#define PUAnstondet(a)			_PUAnstondet(a)
#define PUWaitForRLSD(a)		_PUWaitForRLSD(a)
#define PUInitCallProgress()	_PUInitCallProgress()
#define PUCallProgress()		_PUCallProgress()
#define PUDialNumber(a)			_PUDialNumber(a)
#define PUWaitDialTone(a,b)		_PUWaitDialTone(a,b)
#define PUAnswerAsync(a)		_PUAnswerAsync(a)
#define PUCheckAnswer(a)		_PUCheckAnswer(a)
#define PUResetModem()			_PUResetModem()
#define PUSetTimerTicks(a,b)	_PUSetTimerTicks(a,b)
#define PUSetTimerSecs(a,b)		_PUSetTimerSecs(a,b)
#define PUTimerExpired(a)		_PUTimerExpired(a)
#define PUHangUp()				_PUHangUp()
#define PUPickUp(a)				_PUPickUp(a)
#define PUWriteXRAM(a,b,c)		_PUWriteXRAM(a,b,c)
#define PUWriteYRAM(a,b,c)		_PUWriteYRAM(a,b,c)
#define PUReadXRAM(a,b)			_PUReadXRAM(a,b)
#define PUReadYRAM(a,b)			_PUReadYRAM(a,b)
#define PUIdleMode()			_PUIdleMode()
#define PUDataMode()			_PUDataMode()
#define PUDialMode()			_PUDialMode()
#define PUToneMode()			_PUToneMode()
#define PUIsNumberBusy(a)		_PUIsNumberBusy(a)
#define PUCheckLine()			_PUCheckLine()
#define PUCheckCarrier()		_PUCheckCarrier()
#define PUDetectLineNoise()		_PUDetectLineNoise()
#define PUListenToLine()		_PUListenToLine()
#define PUDisableCallWaiting()	_PUDisableCallWaiting()
#define PUDoSelectorLogin(a)	_PUDoSelectorLogin(a)
#define PUMatchString(a,b)		_PUMatchString(a,b)
#define	PUCheckRing(a)			_PUCheckRing(a)
#define PGetDebugChatScript(a)	_PGetDebugChatScript(a)


#else

void	PInit(void) =
	CallDispatchedFunction(kPInit);

OSErr	POpen(char *config, long flags) =
	CallDispatchedFunction(kPOpen);

OSErr	PListen(char *config, long flags) =
	CallDispatchedFunction(kPListen);
	
OSErr	PClose(void) =
	CallDispatchedFunction(kPClose);

OSErr	PListenAsync(char *config, long flags) =
	CallDispatchedFunction(kPListenAsync);
	
OSErr	POpenAsync(char *config, long flags) =
	CallDispatchedFunction(kPOpenAsync);

short	PNetIdle(NetParamBlock *pBlock) =
	CallDispatchedFunction(kPNetIdle);

OSErr	PWritePacketSync(WDS *sendBuffer) =
	CallDispatchedFunction(kPWritePacketSync);

OSErr	PWritePacketASync(WDS *sendBuffer) =
	CallDispatchedFunction(kPWritePacketASync);

OSErr	PUOpenPort(Boolean listen, char *config) =
	CallDispatchedFunction(kPUOpenPort);

void	PUClosePort(void) =
	CallDispatchedFunction(kPUClosePort);

short	PUProcessIdle(void) =
	CallDispatchedFunction(kPUProcessIdle);

short	PUProcessSTIdle(unsigned short length) =
	CallDispatchedFunction(kPUProcessSTIdle);

OSErr 	PUReadSerialByte (unsigned char *byte) =
	CallDispatchedFunction(kPUReadSerialByte);
	
OSErr 	PUWriteSerialByte (unsigned char byte) =
	CallDispatchedFunction(kPUWriteSerialByte);
	
OSErr 	PUTransmitBufferFree (void) =
	CallDispatchedFunction(kPUTransmitBufferFree);
	
OSErr 	PUTestForConnection (void) =
	CallDispatchedFunction(kPUTestForConnection);

long	PUReadTimeCallback(long time, long data) =
	CallDispatchedFunction(kPUReadTimeCallback);

long	PUWriteTimeCallback(long time, long data) =
	CallDispatchedFunction(kPUWriteTimeCallback);

Boolean	PUSetupServerTalk (void) =
	CallDispatchedFunction(kPUSetupServerTalk);
	
Boolean	PUTearDownServerTalk (void) =
	CallDispatchedFunction(kPUTearDownServerTalk);
	
OSErr	PUSetError(OSErr err) =
	CallDispatchedFunction(kPUSetError);
	
OSErr 	PGetError(void) =
	CallDispatchedFunction(kPGetError);

OSErr	PCheckError(void) =
	CallDispatchedFunction(kPCheckError);

short	PUReceiveBufferAvail(void) =
	CallDispatchedFunction(kPUReceiveBufferAvail);

//OSErr	PClearPhysLine(void) =
//	CallDispatchedFunction(kPClearPhysLine);

OSErr	PUOriginateAsync(char *config, long flags) =
	CallDispatchedFunction(kPUOriginateAsync);

Boolean	PUAnstondet(short timer) =
	CallDispatchedFunction(kPUAnstondet);

Boolean	PUWaitForRLSD(short timer) =
	CallDispatchedFunction(kPUWaitForRLSD);

void	PUInitCallProgress(void) =
	CallDispatchedFunction(kPUInitCallProgress);

short	PUCallProgress(void) =
	CallDispatchedFunction(kPUCallProgress);

OSErr	PUDialNumber( char *number ) =
	CallDispatchedFunction(kPUDialNumber);

OSErr	PUWaitDialTone(short timer, Boolean continuous) =
	CallDispatchedFunction(kPUWaitDialTone);

OSErr	PUAnswerAsync(char *config) =
	CallDispatchedFunction(kPUAnswerAsync);

OSErr	PUCheckAnswer(Boolean hangupOnNoAnswer) =
	CallDispatchedFunction(kPUCheckAnswer);

OSErr	PUResetModem(void) =
	CallDispatchedFunction(kPUResetModem);

void	PUSetTimerTicks(short t, short ticks) =
	CallDispatchedFunction(kPUSetTimerTicks);

void	PUSetTimerSecs(short t, short seconds) =
	CallDispatchedFunction(kPUSetTimerSecs);

short	PUTimerExpired(short t) =
	CallDispatchedFunction(kPUTimerExpired);

OSErr	PUHangUp(void) =
	CallDispatchedFunction(kPUHangUp);

void	PUPickUp(short delay) =
	CallDispatchedFunction(kPUPickUp);

void	PUWriteXRAM(long addr, long xcr, long val) =
	CallDispatchedFunction(kPUWriteXRAM);

void	PUWriteYRAM(long addr, long ycr, long val) =
	CallDispatchedFunction(kPUWriteYRAM);

long	PUReadXRAM(long addr, long xcr) =
	CallDispatchedFunction(kPUReadXRAM);

long	PUReadYRAM(long addr, long ycr) =
	CallDispatchedFunction(kPUReadYRAM);

void	PUIdleMode(void) =
	CallDispatchedFunction(kPUIdleMode);

void	PUDataMode(void) =
	CallDispatchedFunction(kPUDataMode);

void	PUDialMode(void) =
	CallDispatchedFunction(kPUDialMode);

void	PUToneMode(void) =
	CallDispatchedFunction(kPUToneMode);

Boolean	PUIsNumberBusy(char *num) =
	CallDispatchedFunction(kPUIsNumberBusy);

OSErr	PUCheckLine(void) =
	CallDispatchedFunction(kPUCheckLine);

OSErr	PUCheckCarrier(void) =
	CallDispatchedFunction(kPUCheckCarrier);

OSErr	PUDetectLineNoise(void) =
	CallDispatchedFunction(kPUDetectLineNoise);

short	PUListenToLine(void) =
	CallDispatchedFunction(kPUListenToLine);

short	PUDisableCallWaiting(void) = 
	CallDispatchedFunction(kPUDisableCallWaiting);

void	PUAsyncReadDispatch(struct PGlobalType * glob, unsigned char prevChar) =
	CallDispatchedFunction(kPUAsyncReadDispatch);

OSErr	PUDoSelectorLogin(ServiceScript *service) = 
	CallDispatchedFunction(kPUDoSelectorLogin);

OSErr	PUMatchString(ServicePair *sp, unsigned long endTime) = 
	CallDispatchedFunction(kPUMatchString);

Boolean	PUCheckRing( short playsnd ) =
	CallDispatchedFunction(kPUCheckRing);

Ptr		PGetDebugChatScript(long *size) =
	CallDispatchedFunction(kPGetDebugChatScript);


#endif // __SERVER__
#endif // __PhysicalLayer__

