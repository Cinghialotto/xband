/*
 *	$Id: TransportStructs.h,v 1.2 1995/05/10 11:04:34 jhsia Exp $
 *
 *	$Log: TransportStructs.h,v $
 * Revision 1.2  1995/05/10  11:04:34  jhsia
 * switch to cvs keywords
 *
 */

 /*
	File:		TransportStructs.h

	Contains:	GameTalk session layer header

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<32>	11/29/94	BET		Fix the ugly rash of warnings on server build by redefining
									kTransportMagic.
		<31>	 8/23/94	BET		kTimerWaitForSpace needs to be 1 instead of -1 because the time
									constants we use here are unsigned.
		<30>	 8/12/94	DJ		made kon's change work under unix
		<29>	 8/12/94	KON		Include DebugSelectors.h to support the USEDISK define.
		<28>	  8/8/94	BET		Update buffer sizes to use single constant
		<27>	  8/3/94	DJ		don't include DBConstants.h on server
		<26>	 7/26/94	BET		Include DBConstants.h, remove defines that are set there.
		<25>	 7/25/94	BET		Add T[GS]etTransportHold calls.  This code hints the transport
									layer on whether it needs to flush data as it is TWritten or
									whether it is guaranteed more is coming shortly.
		<24>	 7/21/94	BET		Update GETLONG and GETSHORT macros for sun.
		<23>	 7/19/94	BET		Modify header accessors for Stun, which cannot read unaligned
									longs.
		<22>	 7/13/94	BET		unix-ise.
		<21>	 7/12/94	DJ		made CHECKSESSION check for NULL session, even in no debug
									version
		<20>	  7/6/94	BET		Move retry timeouts to database
		<19>	  7/5/94	BET		Add listenTimeout
		<18>	  7/5/94	BET		Moved byte stomping macros to PhysicalStructs.h where they
									belong.
		<17>	  7/4/94	DJ		removed lastError in SessionRec
		<16>	  7/1/94	ADS		Move the USEDISK switch here for minimal impact
		<15>	 6/30/94	BET		Change kSync to kSynch ***NOTE*** This is the last version
									supporting multiple sessions on the same link.
		<14>	 6/30/94	BET		Add Timmer test framework changes.
		<13>	 6/29/94	DJ		changed #if to #ifdef
		<12>	 6/29/94	BET		Add timeout stuff
		<11>	 6/20/94	BET		Add a dorky field.
		<10>	 6/15/94	BET		Add retrans timer
		 <9>	 6/14/94	DJ		added sticky error (lastError)
		 <8>	 6/14/94	BET		Change timeout value to 3 seconds, maybe some other stuff
		 <7>	 6/10/94	DJ		added kConfigStrLength 1000
		 <6>	 6/10/94	BET		Add FUD
		 <6>	 6/10/94	BET		Add FUD
		 <5>	  6/9/94	BET		Add SESSREADY macro
		 <4>	  6/5/94	BET		Add stuff for magic
		 <3>	 5/31/94	BET		Add a change for even-aligning higher level         protocols.
									Last checkin wasn't quite enough.
		 <2>	 5/26/94	BET		I just love it when the check in scrips blow away some the
									currently selected text...
		 <1>	 5/26/94	BET		first checked in
*/

#ifndef __TransportStruct__
#define __TransportStruct__

#include "PhysicalStructs.h"

#ifndef __SERVER__

#include "DBConstants.h"
#include "DebugSelectors.h"

#endif

//--- If you define USEDISK, we only do our I/O with the hard disk
//  on the simulator.  For most types of builds this should be commented
//  off (meaning use real modem connections).

#ifdef SIMULATOR
//	#define USEDISK 1		// uncomment me to use disk transport layer
#endif


#define kConfigStrLength	1000						// Comm Toolbox config str length.
#define kReadFifoLength		kMaxPacket*8
#define kWriteFifoLength	kMaxPacket*20

#define kADSPVersion 0x0100
#define kTimerWaitForSpace 1
#define kTimerUnused 0

#define kAsync	true
#define kSynch	false

typedef unsigned char byte;
typedef unsigned short PortT;

typedef long TConnectID;

#define kTransportMagic ((long)('B'<<24 | 'E'<<16 | 'T'<<8 | '!'))

#ifdef DEBUG
#define CHECKSESSION(s) (s != NULL && (s)->magic == kTransportMagic)
#define SETSESSION(s,a) ((s)->magic = a)
#else
#define CHECKSESSION(s) (s != NULL)
#define SETSESSION(s,a) 
#endif


// ADSP header offsets
#define kSrcConnID			0							// (word) source connection ID
#define	kPktFirstByteSeq	kSrcConnID			+ 2		// (long) first byte sequence of this packet
#define	kPktNextRecSeq		kPktFirstByteSeq	+ 4		// (long) first byte requested by sender
#define	kPktRecvWdw			kPktNextRecSeq		+ 4		// (word) amount reamining in sender buffer
#define	kADSPDesc			kPktRecvWdw			+ 2		// (char) packet flag bitfield
#define kADSPHdrSiz			kADSPDesc			+ 1		// size of this header (#13)
#define kADSPAllHdrSiz		(kADSPHdrSiz+kPhysHdrSiz) 	// size of all headers in this chain
#define kADSPAllBufSiz		(kADSPHdrSiz+kAlignedPhysHdrSiz) // size of all headers in this chain
#define kADSPMaxDataSiz		(kMaxPacket - (kADSPAllHdrSiz + kFramingSize + kFCSSize)) // max size of data
#define kADSPMinPktSiz		(kADSPAllHdrSiz + 1)		// minimum size of a whole packet

#define kADSPVersOffset		0
#define kADSPDestConnOff	kADSPVersOffset		+ 2
#define kADSPPktAttnRcvOff	kADSPDestConnOff	+ 2
#define kADSPOpenSubheadSiz	kADSPPktAttnRcvOff	+ 4

// ADSP header accessors
	#ifdef sparc
		#define GETLONG(h,a) 			(((*((unsigned short *)&h[a])) << 16) | (*((unsigned short *)&h[a+2])))
		#define GETSHORT(h,a) 			(((*((unsigned char *)&h[a])) << 8) | (*((unsigned char *)&h[a+1])))
		#define SETLONG(h,a,v) 			{ (*((unsigned short *)&h[a])) = (v&0xFFFF0000)>>16; (*((unsigned short *)&h[a+2])) = v&0xFFFF;  }
		#define SETSHORT(h,a,v) 		{ (*((unsigned char *)&h[a])) = (v&0xFF00)>>8; (*((unsigned char *)&h[a+1])) = v&0xFF;  }
	#else
		#define GETLONG(h,a) 			(*((unsigned long *)&h[a]))
		#define GETSHORT(h,a) 			(*((unsigned short *)&h[a]))
		#define SETLONG(h,a,v) 			{ (*((unsigned long *)&h[a])) = v; }
		#define SETSHORT(h,a,v) 		{ (*((unsigned short *)&h[a])) = v; }
	#endif
	
	// GETTERS
	#define GETADSPRCONNID(h)			GETSHORT(h,kSrcConnID)
	#define GETADSPRFSTBYTESEQ(h)		GETLONG(h, kPktFirstByteSeq)
	#define GETADSPRNEXTRECSEQ(h)		GETLONG(h, kPktNextRecSeq)
	#define GETADSPRRECWIND(h)			GETSHORT(h,kPktRecvWdw)
	#define GETADSPRDESC(h)				(*((unsigned char *)&h[kADSPDesc]))
	
	#define GETADSPWCONNID(h)			GETSHORT(h,kSrcConnID+kAlignedPhysHdrSiz)
	#define GETADSPWFSTBYTESEQ(h)		GETLONG(h, kPktFirstByteSeq+kAlignedPhysHdrSiz)
	#define GETADSPWNEXTRECSEQ(h)		GETLONG(h, kPktNextRecSeq+kAlignedPhysHdrSiz)
	#define GETADSPWRECWIND(h)			GETSHORT(h,kPktRecvWdw+kAlignedPhysHdrSiz)
	#define GETADSPWDESC(h)				(*((unsigned char *)&h[kADSPDesc+kAlignedPhysHdrSiz]))
	
	// ADSP subheader accessors
	#define GETADSPDATAOPENVERS(h)		GETSHORT(h,kADSPVersOffset)
	#define GETADSPDATAOPENDCONN(h) 	GETSHORT(h,kADSPDestConnOff)
	#define GETADSPDATAOPENATTNR(h) 	GETLONG(h, kADSPPktAttnRcvOff)

	// SETTERS
	#define SETADSPRCONNID(h,v)			SETSHORT(h,kSrcConnID,v)
	#define SETADSPRFSTBYTESEQ(h,v)		SETLONG(h, kPktFirstByteSeq,v)
	#define SETADSPRNEXTRECSEQ(h,v)		SETLONG(h, kPktNextRecSeq,v)
	#define SETADSPRRECWIND(h,v)		SETSHORT(h,kPktRecvWdw,v)
	#define SETADSPRDESC(h,v)			(*((unsigned char *)&h[kADSPDesc]) = v)
	
	#define SETADSPWCONNID(h,v)			SETSHORT(h,kSrcConnID+kAlignedPhysHdrSiz,v)
	#define SETADSPWFSTBYTESEQ(h,v)		SETLONG(h, kPktFirstByteSeq+kAlignedPhysHdrSiz,v)
	#define SETADSPWNEXTRECSEQ(h,v)		SETLONG(h, kPktNextRecSeq+kAlignedPhysHdrSiz,v)
	#define SETADSPWRECWIND(h,v)		SETSHORT(h,kPktRecvWdw+kAlignedPhysHdrSiz,v)
	#define SETADSPWDESC(h,v)			(*((unsigned char *)&h[kADSPDesc+kAlignedPhysHdrSiz]) = v)
	
	// ADSP subheader accessors
	#define SETADSPDATAOPENVERS(h,v)	SETSHORT(h,kADSPVersOffset,v)
	#define SETADSPDATAOPENDCONN(h,v)	SETSHORT(h,kADSPDestConnOff,v)
	#define SETADSPDATAOPENATTNR(h,v)	SETLONG(h,kADSPPktAttnRcvOff,v)

// bit masks for kADSPDesc
#define kDescCtrlMsk		0x80						// control packet
#define kDescAckMsk			0x40						// ack requested
#define kDescEOMMsk			0x20						// end of message
#define kDescAttnMsk		0x10						// attention message
#define kDescCtrlCodeMsk	0x0F						// control code mask

// control codes
#define kADSPProbeOrAck		0x00						// probe or acknowledgement
#define kADSPOpenConnReq	0x01						// open connection request
#define kADSPOpenConnAck	0x02						// open connection ack
#define kADSPOpenConnReqAck	0x03						// open connection req and ack
#define kADSPOpenConnDeny	0x04						// open connection denial
#define kADSPCloseConnAdv	0x05						// close connection advice
#define kADSPFwdReset		0x06						// forward reset
#define kADSPFwdResetAck	0x07						// forward reset ack
#define kADSPRetransAdv		0x08						// retransmit advice
#define kADSPCloseConnAck	0x0F						// close connection ack (NOT SPEC)

// session record tests
#define SESSREADY(s)	((s)->connState == kConnOpen)	// test to see if the session is up
#define SESSCLOSED(s)	((s)->connState == kConnClosed)	// test to see if the session is down
#define SESSASYNCBSY(s)	(FifoActive(&(s)->clientFifo))	// test for active async
typedef struct SessionRec {
	struct SessionRec	*next;						// next session rec for searching
	long				magic;						// magic cookie to check for session validity
	unsigned long		remoteIAddr;				// internet address we are talking to (unused)
	unsigned short		myConnID, remConnID;		// ports for this connection
	unsigned long		sendSeq;					// next byte requested from this (my) end
	unsigned long		firstRtmtSeq;				// first (oldest) byte in my send queue
	unsigned long		sendWdwSeq;					// locally calculated, last byte remote can accept
	unsigned long		recvSeq;					// next byte that the we expect to receive
	unsigned long		recvWdw;					// space available locally
	unsigned long		timer;						// next time in ticks that we have to tickle other end
	unsigned long		retransTimer;				// next time in ticks that we have to ask for retrans
	unsigned short		tickleCount;				// count of how many times we have done this
	short				connState;					// state of this session
	struct RDS			readPB;						// pb for doing reads with
	char				writeHeader[kADSPAllBufSiz]; // header for sending crap
	struct WDS			writePB;					// mostly used for sending acks
	char				ackHeader[kADSPAllBufSiz];	// header for sending crap
	char				preWriteBuf[kADSPMaxDataSiz]; // buffer for staging
	
	
	// async buffer that we are reading
	// This is _always_ set up so that it points to the client buffer.  The client buffer is defined
	// as the actual buffer in a sync or async reads, and pcktRdBuf when there is no read in progress.
	// Sync reads just loop on NetIdle waiting for the packet to be filled, async reads are eventually
	// filled by NetIdle and the pointers are reset to pcktRdBuf on completion.
	char				pcktRdBuf[kReadFifoLength];	// place that a packet is read into
	Fifo				readFifo;					// fifo information for read fifo
	Fifo				clientFifo;					// fifo information for client fifo
	// async buffer that we are writing
	char				pcktWrBuf[kWriteFifoLength];	// place that a packet is written into
	Fifo				writeFifo;					// fifo information for read fifo
	
#ifdef USEDISK
	short				ioRefNum;					// for debugging purposes
#endif
	long				userRef;					// user refcon
	unsigned long		listenTimeout;				// timeout if connection is listening
	unsigned short		timeoutTicks;				// time before we retry a packet
	unsigned short		tickleTimeoutCount;			// count of retries before we timeout
	Boolean				transportHold;				// true if we are trying to chunk small writes
} SessionRec;


#endif // __TransportStruct__

