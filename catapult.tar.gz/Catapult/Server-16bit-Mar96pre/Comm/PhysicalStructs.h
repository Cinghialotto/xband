/*
 *	$Id: PhysicalStructs.h,v 1.2 1995/05/10 11:04:18 jhsia Exp $
 *
 *	$Log: PhysicalStructs.h,v $
 * Revision 1.2  1995/05/10  11:04:18  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		PhysicalStructs.h

	Contains:	GameTalk physical layer header

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<28>	 8/25/94	BET		Add SETNETSTATS
		<27>	 8/24/94	BET		Added flags to the ServicePair structure.  The first flag
									defined is the half-duplex field.
		<26>	  8/7/94	BET		Tone down the size of the physical fifo's, they were multiplied
									2x for testing a long time ago and never reset.
		<25>	  8/3/94	BET		Update SETCONNECTSCRIPT macro and add to ServiceScript
									structure.
		<24>	  8/2/94	BET		Add more script fixes.
		<23>	  8/2/94	HEC		kDisableServerTalk
		<22>	 7/26/94	HEC		kIgnoreDialTone from 3 to 4.
		<21>	 7/26/94	HEC		Added kIgnoreDialTone
		<20>	 7/23/94	BET		Update dialing script structure.
		<19>	 7/22/94	BET		Move POpen flags to here.  Also add connect script ID
									getter/setter macros.
		<18>	 7/13/94	BET		unix-ise.
		<17>	  7/7/94	BET		Add error recording.
		<16>	  7/6/94	HEC		Moved kCloseTimeout to DBConstants.h
		<15>	  7/5/94	BET		Add sticky error routines and update PModem to use them.
		<14>	  7/3/94	SAH		Changed "Connections.h" to <Connections.h> to speed up compiles.
		<13>	  7/3/94	HEC		Fucked up.
		<12>	  7/3/94	HEC		Commented out #include "TransportStructs.h" to remove circular
									reference.
		<11>	 6/30/94	BET		Add a 'k' for Kon.  He sure likes that letter for some reason...
		<10>	 6/18/94	BET		Add kCloseTimeout
		 <9>	 6/15/94	BET		Snub out csum stuff in metro
		 <8>	 6/14/94	BET		Fix some mistakes in the macros
		 <7>	 6/13/94	BET		Add gametalk stuff
		 <5>	 5/31/94	BET		Add a change for even-aligning higher level         protocols.
									Last checkin wasn't quite enough.
		 <4>	 5/31/94	BET		Add a change for even-aligning higher level protocols
		 <3>	 5/31/94	BET		Add changes for game-game communication.  Mostly constants and
									enums.
		 <2>	 5/29/94	BET		Add CRC stuff
		 <1>	 5/26/94	BET		first checked in
*/

#ifndef __PhysicalStructs__
#define __PhysicalStructs__

#include "SegaTypes.h"

#ifndef unix
#include <Connections.h>
#else
#include "NetTypes.h"
#endif
#include "fifo.h"

#ifndef __MIXEDMODE__
#define ConnectionCompletionUPP ProcPtr
#define NewConnectionCompletionProc 
#endif

#define kDLEChar	0x10
#define kETXChar	0x03
#define ISFRAMEDLE(a) (*(char *)a == kDLEChar)
#define ISFRAMEETX(a) (*(char *)a == kETXChar)
#define ISFRAMEFLAG(a) (ISFRAMEDLE(a) && ISFRAMEETX(&a[1]))

#ifndef __SERVER__
#define SETNETSTATS(a) (gNetStats = &a)
#define SETCOMMERROR(a,b) (gNetStats->a = b)
#define INCRCOMMERROR(a,b)  (gNetStats->a += b)
#define GETCOMMERROR(a) (gNetStats->a)
#else
#define SETNETSTATS(a) 
#define SETCOMMERROR(a,b)
#define INCRCOMMERROR(a,b)
#define GETCOMMERROR(a) 0
#endif

// read thread states
enum {
	kIdleLink = 0,
	kProcessingST,
	kCheckNextST,
	kProcessingGT1,
	kProcessingGT2
	};

// read data structure
typedef struct RDS {
	unsigned char	length1;							// all the data
	unsigned char	*buf1;								// where it's at
	} RDS;
	
// write data structure
typedef struct WDS {
	unsigned char	length1;							// used for header data
	unsigned char	*buf1;								// it's up to the client to get the length right here
	unsigned short	length2;							// commonly used for actual data
	unsigned char	*buf2;
	} WDS;

#define kFCSSize	2									// off the end of the data
#define kFramingSize 2									// off the end of the FCS

#define kMaxPacket 128
#define kForwardBuffer kMaxPacket*1

#define kOriginate	false
#define kListen		true

// physical link header offsets
// this is for sega, which craps on odd addressed word fields in higher layers
// adjust it if the phys headers become even-sized
#define kEvenAddressing		1
#define kProtoType			kEvenAddressing + 0			// embedded protocol
#define kAlignedPhysHdrSiz	kProtoType	+ 1				// header size (1) // really 1, but we need to fake it
#define kPhysHdrSiz			kAlignedPhysHdrSiz-kEvenAddressing // for sega, which craps on odd addressed fields in higher layers

// phys link header accessors
#define PGETPROTOTYPE(h)	(*((char *)&h[kProtoType]))
#define PBUFADDR(b)			(&b[1])

#define kPhysBufferSize (16*kMaxPacket)					// size of data buffer
#define	kMaxFrames 400									// maximum number of frames that can be indexed
#define	kFrameStartBufSiz kMaxFrames*sizeof(short)		// size of buffer for framestarts

/* for flags field */
#define kHalfDuplex 1

typedef struct ServicePair {
	unsigned short	timeToWait;
	unsigned short	repeatCount;
	unsigned char	poke;
	DBID			sendString;
	DBID			replyString;
	unsigned char	flags;
	} ServicePair;

typedef struct ServiceScript {
	unsigned short	totalTimeout;
	unsigned char	dataMask;
	unsigned short	pairCount;
	ServicePair		pair[1];
	} ServiceScript;
//
// flags to POpen for server or peer
//
#define	kUseServerProtocol 		0
#define kUsePeerProtocol		1
#define kDisableCallWaiting		2
#define kIgnoreDialTone			4
#define kDisableServerTalk		8
// script ID constants
enum {
	kSega800ServiceScript = 0,
	kSegaX25ServiceScript
	};

#define GETCONNECTSCRIPT(f) 	((f&0xFF000000)>>24)
#define SETCONNECTSCRIPT(f,v)	{ f |= (((long)v)<<24); }

#ifdef TRASHPACKETS
#define DECLAREVARSIFTESTING() 		extern Boolean bTrashStartFrame;	\
									extern Boolean bTrashCRC;			\
									extern Boolean bTrashEndFrame;		\
									extern Boolean bTrashData;			\
									extern Boolean bTrashHeader;
#define TRASHHEADERIFTESTING()		{ if ( bTrashHeader ) { addr[padPoint] = ~addr[padPoint]; } }
#define LASTTRASHHEADERIFTESTING()	{ if ( bTrashHeader ) { addr[padPoint] = ~addr[padPoint]; bTrashHeader = false; } }
#define UPDATEVARSIFTESTING()		{ bTrashHeader = bTrashData; bTrashData   = false; }
#define TRASHCRCIFTESTING()			{ if ( bTrashCRC ) { crc = ~crc; bTrashCRC = false; } }
#define TRASHENDIFTESTING()			{ if ( bTrashEndFrame ) { crc = ~crc; bTrashEndFrame = false; } }
#else
#define DECLAREVARSIFTESTING() 
#define TRASHHEADERIFTESTING() 
#define LASTTRASHHEADERIFTESTING() 
#define UPDATEVARSIFTESTING() 
#define TRASHCRCIFTESTING() 
#define TRASHENDIFTESTING() 
#endif

#endif // __PhysicalStructs__




