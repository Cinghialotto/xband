/*
 *	$Id: SunSerialPriv.h,v 1.2 1995/05/10 11:04:26 jhsia Exp $
 *
 *	$Log: SunSerialPriv.h,v $
 * Revision 1.2  1995/05/10  11:04:26  jhsia
 * switch to cvs keywords
 *
 */

 /*
	File:		SunSerialPriv.h

	Contains:	SunSerial physical layer header

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <5>	11/29/94	BET		Fix the ugly rash of warnings on server build by redefining
									kMagicVal.
		 <4>	11/10/94	BET		Add cheeze for on-demand packet trace.
		 <3>	 8/23/94	BET		Add trace.
		 <2>	 7/21/94	BET		Looks like it is working
		 <1>	 7/13/94	BET		first checked in
*/

#ifndef __PhysicalPriv__
#define __PhysicalPriv__

#include "NetTypes.h"
#include <sys/time.h>

#define kMagicVal ((long)('B'<<24 | 'E'<<16 | 'T'<<8 | '!'))

#if defined(SIMULATOR) || defined(__SERVER__)
#define CHECKMAGIC(a) { if (a->PHMagic != kMagicVal) ASSERT_MESG(0, "PH Globals are bad!"); }
#else //#elif defined(SEGAONLY)
#define CHECKMAGIC(a) { if (a->PHMagic != kMagicVal) asm { dc.w 0xa003 }; }
#endif


#define kMaxTimeout		3*2								// match this against transport timeouts
#define kTicksASec		10								// wise to make this a power of 10
#define kWakeupSlots	kMaxTimeout*kTicksASec

typedef struct TimeQueue {
	struct timeval			lastService;
	short					lastIndex;
	unsigned char			wakeup[kWakeupSlots];
	} TimeQueue;

#define kReadGood 1

typedef struct Packet {
	struct Packet			*next;
	struct timeval			timestamp;
	long					length;
	long					flags;
	char					data[0];
	} Packet;

typedef struct PGlobalType {
	RDS						*PHReadyBuffer;				// buffer that we are primed to put stuff into
	RDS						*PHFilledBuffer;			// buffer that we already put stuff into
	short					PHPacketState;				// state of the current packet (in framing, etc.)
	unsigned short			PHFrameSizAccum;			// accumulator for current frame length
	Fifo					PHLengthsFifo;				// fifo of packet lengths
	unsigned char			*PHLengthsBuf;				// buffer for the lengths
	Fifo					PHReadFifo;					// fifo information for physical fifo
	unsigned char			*PHReadDataBuf;				// circular buffer space
	Boolean					PHWriteActive;				// signals outstanding Async IO
	Fifo					PHWriteFifo;				// fifo information for physical fifo
	unsigned char			*PHWriteDataBuf;			// circular buffer space
	unsigned char			*PHStagingBuf; 				// circular buffer space

	unsigned long			PHTotalIn;					// sum of bytes passed
	unsigned long			PHTotalOut;					// sum of bytes passed
	Boolean					PHIndicating;				// PNetIdle is already threading an indication
	short					PHConnState;				// state of connection
	long					PHMagic;					// Magic Cookie for testing
	OSErr					PHLastError;				// last error we encountered
	TimeQueue				PHTimeQueue;				// wakeup schedule for select return
#ifdef DEBUG
	Fifo					testRead;
	Fifo					testWrite;
#endif
	Boolean					trace;
	Packet					*readHead, *readTail;
	Packet					*writeHead, *writeTail;
	} PGlobalType;

#ifdef	SIMULATOR
#define	MANAGERGLOBALTYPE		PGlobalType
#else
PGlobalType PGlobals;
#endif

#endif //  __PhysicalStructs__

