/*
 *	$Id: SerialPhysicalPriv.h,v 1.2 1995/05/10 11:04:23 jhsia Exp $
 *
 *	$Log: SerialPhysicalPriv.h,v $
 * Revision 1.2  1995/05/10  11:04:23  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		SerialPhysicalPriv.h

	Contains:	header for SegaSerial

	Written by:	Shannon Holland, Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <9>	 6/21/94	BET		Add a timer for CESSerial.c
		 <8>	  6/9/94	BET		Fix up global handling for server builds
		 <7>	  6/4/94	BET		Fix more FUD
		 <6>	  6/3/94	BET		Add more FUD
		 <5>	  6/1/94	BET		Fix some late arrivals
		 <4>	  6/1/94	BET		Add some FUD
		 <3>	 5/27/94	SAH		Commmented out kPhysBufferSize as it was already defined.
		 <2>	 5/26/94	SAH		Fleshed out.

	To Do:
*/

#ifndef __SerPhysPriv__
#define __SerPhysPriv__

#include "time.h"

/* serial states */
enum
{
	kIdle,
	kWaitingForAnswer,
	kWaitingForCall,
	kConnected
};

/* some magic serial line tokens */
#define	kConnectToken		0xae
#define kConnectTickle		180

//#define kPhysBufferSize (kADSPMinPktSiz*kMaxPacket*2)	// size of data buffer HACK! the 2x multiplier is a test
#define	kMaxFrames 400									// maximum number of frames that can be indexed
#define	kFrameStartBufSiz kMaxFrames*sizeof(short)		// size of buffer for framestarts

#define kMagicVal 'BET!'
#define CHECKMAGIC(a) { if (a->PHMagic != kMagicVal) ASSERT_MESG(0, "PH Globals are bad!"); }


typedef struct PGlobalType {
	RDS						*PHReadyBuffer;				// buffer that we are primed to put stuff into
	RDS						*PHFilledBuffer;			// buffer that we already put stuff into
	short					PHPacketState;				// state of the current packet (in framing, etc.)
	unsigned short			PHFrameSizAccum;			// accumulator for current frame length
	Fifo					PHLengthsFifo;				// fifo of packet lengths
	unsigned char			*PHLengthsBuf;				// buffer for the lengths
	Fifo					PHReadFifo;					// fifo information for physical fifo
	unsigned char			*PHReadDataBuf;				// circular buffer space
	Boolean					PHWriteActive;				// signals outstanding Async IO
	Fifo					PHWriteFifo;				// fifo information for physical fifo
	unsigned char			*PHWriteDataBuf;			// circular buffer space
	unsigned char			*PHStagingBuf; 				// circular buffer space

	unsigned long			PHTotal;					// sum of bytes passed
	Boolean					PHIndicating;				// PNetIdle is already threading an indication
	short					PHConnState;				// state of connection
	short					PHGameFifoR;				// read pointer of game fifo
	short					PHGameFifoW;				// write pointer of game fifo
	long					*PHGameFifoBuf;				// buffer for actual data
	TimeProcRef				PHReadTimeRef;				// Time Manager request for read service
	TimeProcRef				PHWriteTimeRef;				// Time Manager request for write service
	short					PHLastError;				// last error that occured in this manager
	long					PHMagic;					// magic cookie
	long					PHTimer;					// time to tickle next
	} PGlobalType;

#ifdef	SIMULATOR
#define	MANAGERGLOBALTYPE		PGlobalType
#else
PGlobalType PGlobals;
#endif

#endif // __SerPhysPriv__



