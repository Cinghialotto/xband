/*
 *	$Id: GetData.h,v 1.2 1995/05/10 11:03:51 jhsia Exp $
 *
 *	$Log: GetData.h,v $
 * Revision 1.2  1995/05/10  11:03:51  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GetData.h

	Contains:	xxx put contents here xxx

	Written by:	Konstantin Othmer

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <7>	  8/1/94	KON		Remove local get data procs.
		 <6>	 7/21/94	BET		add #ifdef __SERVER__
		 <5>	  7/4/94	DJ		changed TReadBytesReady to return OSErr
		 <4>	  6/4/94	SAH		Managerized.
		 <3>	 5/27/94	KON		Wrapper network procs so they go through the dispatcher.
		 <2>	 5/26/94	BET		Update for managerized Disk Transport.
		 <1>	 5/24/94	KON		first checked in

	To Do:
*/


#ifndef __GetData__
#define __GetData__

#ifndef __SegaOS__
#include "SegaOS.h"
#endif

#ifdef __SERVER__
// do something so the server can use the file

#else

OSErr	GetDataSync( unsigned long length, Ptr address ) =
	CallDispatchedFunction( kGetDataSync );

OSErr	GetDataBytesReady( unsigned long *amount ) =
	CallDispatchedFunction( kGetDataBytesReady );

short	GetDataError( void ) =
	CallDispatchedFunction( kGetDataError );

#endif //__SERVER__

#endif __GetData__
