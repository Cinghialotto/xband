/*
 *	$Id: DiskTransport.c,v 1.2 1995/05/10 11:03:44 jhsia Exp $
 *
 *	$Log: DiskTransport.c,v $
 * Revision 1.2  1995/05/10  11:03:44  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		DiskTransport.c

	Contains:	Debugging stubs for GameTalk

	Written by:	Konstantin Othmer, Brian Topping

	Copyright:	� 1994 by Apple Computer, Inc., all rights reserved.

	Change History (most recent first):

		 <6>	 8/20/94	ADS		More stubs to keep the OS happy
		 <5>	 7/18/94	ADS		Fill out unused slos
		 <4>	  7/8/94	ADS		Broken because interfaces changed
		 <3>	 6/18/94	BET		Add TInit call to avoid boot warnings
		 <2>	 5/26/94	BET		Fix some nitties.
		 <1>	 5/26/94	BET		first checked in
		 <5>	 5/25/94	KON		Fix standard file problem when hitting return twice in a row
									really fast. Mac's suck!
		 <4>	 5/18/94	BET		Fix a merge problem
		 <3>	 5/18/94	BET		Reflect GameTalk API changes
		 <2>	 5/18/94	BET		Reflect GameTalk API changes

	To Do:
*/


#include "DiskTransport.h"
#include "DiskTransportPriv.h"
#include "SegaOS.h"
#include "Errors.h"

	void 			_DTInit(void);
	OSErr			_DTOpen(SessionRec *s, PortT localPort, PortT remPort);
	OSErr			_DTClose(SessionRec *s);
	unsigned char	_DTReadAByte( void );
	OSErr			_DTReadData( unsigned long length, Ptr address, Boolean async );
	short			_DTNetIdle( NetParamBlock *pBlock );
	OSErr			_DTNetError( void );
	OSErr			_DTReadBytesReady( unsigned long *amount );
	OSErr			_DTWriteAByte( char myByte );
	OSErr			_DTWriteData( unsigned long length, Ptr address, Boolean async );
	
	void			_DTUnimplemented(void);

	void			_DTSetTransportHold(Boolean hold);
	void			_DTSetTransportHoldSession(SessionRec *s, Boolean hold);
	Boolean			_DTGetTransportHold(void);
	Boolean			_DTGetTransportHoldSession(SessionRec *s);
	OSErr			_DTCheckError(void);


#ifndef	SIMULATOR
DTGlobalType DTGlobals;

#define	DTGetGlobals()	((DTGlobalType *) &REFGLOBAL(DTGlobals,gFileRef))

#else
static	DTGlobalType *	DTGetGlobals( void );

long
_DiskTransportControl ( short command, long data )
{
DTGlobalType *globals;
long offset;
short error;
short	iii;

	error = commandSelectorUnknown;

	switch ( command )
		{
		case kHardInitialize:
		
			/* allocate and initialize our globals */
			GETMGRGLOBALSOFFSET(TGlobals,offset);
			
			error = AllocateGlobalSpace ( kTransportLayerManager, offset, sizeof(DTGlobalType), (Ptr *) &globals );
			if ( error != noErr )
				{
				return error;
				}
				
			/*
			*	Since we have far fewer functions than the "real" transport layer,
			*	we'll fill them all with 0 for now.  This causes us to skip the nasty
			*	empty-procs checker (which should be busy with more realistic issues)
			*/
			
			for (iii = kTInit; iii < kInitPermDatabase; ++iii)
				SetDispatchedFunction( iii, kTransportLayerManager, _DTUnimplemented );
			
			
			/* install our selectors */
			SetDispatchedFunction ( kTInit,					kTransportLayerManager,	_DTInit );
			SetDispatchedFunction ( kTOpen,					kTransportLayerManager,	_DTOpen );
			SetDispatchedFunction ( kTClose,				kTransportLayerManager,	_DTClose );
			SetDispatchedFunction ( kTReadAByte,			kTransportLayerManager,	_DTReadAByte );
			SetDispatchedFunction ( kTReadData,				kTransportLayerManager,	_DTReadData );
			SetDispatchedFunction ( kTNetIdle,				kTransportLayerManager,	_DTNetIdle );
			SetDispatchedFunction ( kTNetError,				kTransportLayerManager,	_DTNetError );
			SetDispatchedFunction ( kTReadBytesReady,		kTransportLayerManager,	_DTReadBytesReady );
			SetDispatchedFunction ( kTWriteAByte,			kTransportLayerManager,	_DTWriteAByte );
			SetDispatchedFunction ( kTWriteData,			kTransportLayerManager,	_DTWriteData );
			SetDispatchedFunction ( kTCheckError,			kTransportLayerManager,	_DTCheckError );

			SetDispatchedFunction ( kTGetTransportHold,		kTransportLayerManager,	_DTGetTransportHold );
			SetDispatchedFunction ( kTGetTransportHoldSession,		kTransportLayerManager,	_DTGetTransportHoldSession );
			SetDispatchedFunction ( kTSetTransportHold,		kTransportLayerManager,	_DTSetTransportHold );
			SetDispatchedFunction ( kTSetTransportHoldSession,		kTransportLayerManager,	_DTSetTransportHoldSession );
			break;
		
		case kSoftInialize:
			error = noErr;
			break;
		
		case kHardClose:
			error = noErr;
			break;
		
		case kSoftClose:
			error = noErr;
			break;
					
		case kCodeBlockMoved:
			error = noErr;
			break;
					
		case kGlobalsMoved:
			error = noErr;
			break;
		}
		
	return error;
}

static
DTGlobalType *	DTGetGlobals( void )
{
DTGlobalType 	*globals;

	globals = 0;
	
	GetManagerGlobals ( kTransportLayerManager, (Ptr *) &globals, (short *) 0L );
	
	return globals;
}

#endif

void	_DTUnimplemented(void)
{
	ASSERT_MESG(0, "Trying to call a transport fn not included in disktransport");
}


void _DTInit(void)
{
}

OSErr _DTOpen(SessionRec *s, PortT localPort, PortT remPort)
{
//
// Put up standard file and open a file. Set the mark to the beginning.
//
Point			wher;		/*where to display dialog*/
SFReply			reply;		/*reply record*/
SFTypeList		myFileTypes;	/*see Standard File */
short			numFileTypes;
OSErr			err;
QDProcsPtr		savedProcs;
CQDProcs		myProcs;
PicHandle		myPicture;
long			longCount,myEOF,filePos;
CGrafPtr		savePort;
GDHandle		saveGDHandle;
QDErr			myErr;
PixMapHandle	myPixels;
PixMapHandle	mySegaPixels;
PixMapHandle	myWPixels;
Rect			myRect;
short			xpos, ypos;
DTGlobalType	*glob = DTGetGlobals();

//
// Get name of file to suck in
//
	SetPt( &wher, 0, 0 );
	numFileTypes = 1;		/*display 'PICT's*/
	myFileTypes[0] = 'SMsg';
	
	reply.fName[0] = 0;
	do
	{
		SFGetFile( wher,"\pSelect File to suck in", nil, numFileTypes, myFileTypes, nil, &reply );
	} while( reply.fName[0] == 0 && reply.good );
	
	if( !reply.good )
	{
		DebugStr("\pWe're not that robust!!! - died in TConnectRequest" );
		return -1;
	}
	
	myPicture = (PicHandle)NewHandle(sizeof(Picture));

	err = FSOpen( (unsigned char *)&reply.fName, reply.vRefNum, &glob->gFileRef );
	if (err != noErr) return err;

	err = SetFPos( glob->gFileRef, fsFromStart, 0 );
	if (err != noErr) return err;

//
// Get name of file to spit data out to
//

	SetPt( &wher, 0, 0 );
	SFPutFile( wher, "\pSpit out data to file:", "\pPuke.dump", nil, &reply );
	if( !reply.good )
	{
		DebugStr("\pBroke in Write1BitSega" );
		return 0;
	}

	myErr = Create( reply.fName, reply.vRefNum, '????', 'TEXT' );

	myErr = FSOpen( reply.fName, reply.vRefNum, &glob->gOutputFileRef );
		if( myErr )
			DebugStr("\pCouldn't open output file" );

	SetEOF( glob->gOutputFileRef, 0 );
	myErr |= SetFPos( glob->gOutputFileRef, fsFromStart, 0 );
	
}

OSErr _DTClose(SessionRec *s)
{
//
// Close the file
//
DTGlobalType	*glob = DTGetGlobals();

	FSClose( glob->gFileRef );
	FSClose( glob->gOutputFileRef );
	
	return 0;
}

unsigned char _DTReadAByte( void )
{
long			longCount, myEOF, filePos;
unsigned char	myReceiveByte;
OSErr			err;
DTGlobalType	*glob = DTGetGlobals();

//
// return a byte out of the file and bump the mark
//
	longCount = 1;
	err = FSRead( glob->gFileRef, &longCount, (Ptr)&myReceiveByte);
	return myReceiveByte;

}

OSErr _DTReadData( unsigned long length, Ptr address, Boolean async )
{
long	longCount, myEOF, filePos;
char	myReceiveByte;
DTGlobalType	*glob = DTGetGlobals();

//
// read length bytes out of the file into *address
//
	longCount = length;
	FSRead( glob->gFileRef, &longCount, address );

	return 0;
}

short _DTNetIdle( NetParamBlock *pBlock )
{
//
// return file system errors, or nil if none
//
	return 0;

}

short _DTNetError( void )
{
short	result;
	result = TNetIdle( 0 );
	if( result < 0 )
		return 1;
	else
		return 0;
}

OSErr			_DTReadBytesReady( unsigned long *amount )
{
long	longCount,myEOF,filePos;
OSErr	err;
//
// Return bytes from mark to EOF
//
DTGlobalType	*glob = DTGetGlobals();

	GetFPos( glob->gFileRef, &filePos );	/*get position for check*/

	GetEOF( glob->gFileRef, &myEOF );

	*amount = myEOF - filePos;
	
	return 0;

}

OSErr _DTWriteAByte( char myByte )
{
long	count;
DTGlobalType	*glob = DTGetGlobals();

	count = 1;
	FSWrite( glob->gOutputFileRef, &count, &myByte );
	
	return 0;
}

OSErr _DTWriteData( unsigned long length, Ptr address, Boolean async )
{
long	count;
DTGlobalType	*glob = DTGetGlobals();

//
// Do something really smart here
//
	count = length;
	FSWrite( glob->gOutputFileRef, &count, address );

	return 0;
}

void _DTSetTransportHold(Boolean hold)
{
}

void _DTSetTransportHoldSession(SessionRec *s, Boolean hold)
{
}

Boolean _DTGetTransportHold(void)
{
	return false;
}

Boolean _DTGetTransportHoldSession(SessionRec *s)
{
	return false;
}

OSErr _DTCheckError(void)
{
	return(noErr);
}








