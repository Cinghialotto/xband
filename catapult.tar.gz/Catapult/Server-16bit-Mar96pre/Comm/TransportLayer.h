/*
 *	$Id: TransportLayer.h,v 1.2 1995/05/10 11:04:31 jhsia Exp $
 *
 *	$Log: TransportLayer.h,v $
 * Revision 1.2  1995/05/10  11:04:31  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		TransportLayer.h

	Contains:	GameTalk session layer header

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<25>	 8/16/94	BET		Add error checking to TUInitSessRec.
		<24>	  8/1/94	HEC		Removed obsolete protos.
		<23>	 7/25/94	DJ		added T[SG]etTransportHoldSession
		<22>	 7/25/94	BET		Add T[GS]etTransportHold calls.  This code hints the transport
									layer on whether it needs to flush data as it is TWritten or
									whether it is guaranteed more is coming shortly.
		<21>	 7/13/94	BET		unix-ise.
		<20>	 7/12/94	DJ		TUSetError now returns the OSErr you set
		<19>	  7/5/94	BET		Change to unsigned longs for timeout.
		<18>	  7/4/94	DJ		added TUGetError and removed lastError in SessionRec
		<17>	  7/3/94	BET		Add TUSetError
		<16>	  7/3/94	SAH		Changed the OS includes to SegaOS.h.
		<15>	 6/29/94	BET		Change interfaces for BytesAvailable procs.
		<14>	 6/28/94	BET		Put them back.  Around and around we go!
		<13>	 6/20/94	BET		Revert previous changes, they are not going to be done in time
									for CES.
		<12>	 6/19/94	BET		Add CheckError interfaces
		<11>	 6/15/94	BET		Ooops!
		<10>	 6/15/94	BET		Add TUCheckTimers API
		 <9>	 6/14/94	BET		Add TCloseAck API
		 <8>	 6/13/94	BET		Add first round of open dialog retrans code
		 <7>	 6/10/94	BET		Make some changes
		 <6>	  6/9/94	BET		Add Async Open and Listen
		 <5>	  6/5/94	BET		Add config string to TOpen and TListne
		 <4>	 5/27/94	BET		Fix a prob in TReadAByte for the returned byte.
		 <3>	 5/26/94	BET		Add TNetError
		 <2>	 5/26/94	BET		Check in Shannon's start on changes for patchable managers, my
									changes for making work on the server.  Not verified yet on
									SegaOS.
*/

#ifndef __Transport__
#define __Transport__

#if !defined(__SERVER__) && defined(__MWERKS__)
#define __SERVER__
#endif

#include "NetStructs.h"
#include "TransportStructs.h"
#ifndef unix
#include "SegaOS.h"
#endif

/*
* BRAIN DAMAGE: we need to compile this seperately for the server and the sega/simulator build.
* The sega goes through the dispatcher, the server needs to call the functions directly.
* Having two definitions is gross, but I didn't know any other way to do it.
*/


	void			_TInit(void);
	OSErr			_TOpen(SessionRec *s, PortT localPort, PortT remPort);
	OSErr			_TListen(SessionRec *s, PortT localPort, PortT remPort, unsigned long timeout);
	OSErr			_TOpenAsync(SessionRec *s, PortT localPort, PortT remPort);
	OSErr			_TListenAsync(SessionRec *s, PortT localPort, PortT remPort, unsigned long timeout);
	OSErr			_TClose(SessionRec *s);
	OSErr			_TCloseAsync(SessionRec *s);
	void			_TUnthread(SessionRec *ds);
	short 			_TNetIdle(NetParamBlock *pBlock);
	OSErr			_TUCheckTimers(SessionRec *s);

	OSErr			_TReadDataSync(SessionRec *sess, unsigned long length, Ptr address);
	OSErr			_TReadDataASync(SessionRec *sess, unsigned long length, Ptr address);
	OSErr			_TWriteDataSync(SessionRec *sess, unsigned long length, Ptr address);
	OSErr			_TWriteDataASync(SessionRec *sess, unsigned long length, Ptr address);
	OSErr			_TAsyncWriteFifoData(SessionRec *s);
	
					// in case you didn't feel like using a session...
	OSErr			_TReadData(unsigned long length, Ptr address, Boolean async );
	OSErr			_TWriteData(unsigned long length, Ptr address, Boolean async );

					// read a byte 
	unsigned char	_TReadAByte( void );
					// write a single byte on the transport NOW
	OSErr			_TWriteAByte( char myByte );
					// write a single byte on the transport after a full amount
	OSErr			_TQueueAByte( char myByte );
	
					// how much is available in the pipe
	OSErr			_TReadBytesReady( unsigned long *amount );
	
	OSErr			_TDataReady(unsigned long *amount);
	OSErr			_TDataReadySess(SessionRec *sess, unsigned long *amount);
	OSErr			_TIndication(Fifo *physFifo, unsigned short physState, unsigned short length);
	OSErr			_TForwardReset(SessionRec *s);
	OSErr			_TNetError( void );
	OSErr			_TCheckError(void);
	OSErr			_TUSetError(OSErr err);
	OSErr			_TUGetError(void);

	OSErr			_TUInitSessRec(SessionRec *s, PortT localPort, PortT remPort);
	OSErr			_TUSendCtl(SessionRec *s, Boolean probeRequested);
	OSErr			_TUUpdateSessionInfo(SessionRec *s, char *header, Boolean *sequenceValid);
	
					// opening dialog routines
	OSErr			_TUSendOpen(SessionRec *s);
	OSErr			_TUSendOpenAck(SessionRec *s);
	OSErr			_TUSendCloseAdv(SessionRec *s);
	OSErr			_TUSendCloseConnAck(SessionRec *s);
	OSErr			_TUSendFwdReset(SessionRec *s);
	OSErr			_TUSendFwdResetAck(SessionRec *s);
	OSErr			_TUSendFwdResetPacket(SessionRec *s, unsigned char cCode);
	OSErr			_TUSendRetransAdv(SessionRec *s);

	unsigned short	_TUOpenDialogPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header);
	unsigned short	_TUFwdResetPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header);
	unsigned short	_TUCloseConnPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header);
	unsigned short	_TUCloseConnAckPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header);
	unsigned short	_TURetransAdvPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header);
	OSErr			_TUAllowConnection(SessionRec *s);
	OSErr			_TUDenyConnection(SessionRec *s);
	long 			_TGetUserRef(SessionRec *s);
	void 			_TSetUserRef(SessionRec *s, long refCon);
	SessionRec*		_TUFindSession(char *header, Boolean *sequenceValid, Boolean *packetType);
	void			_TSetTransportHold(Boolean hold);
	void			_TSetTransportHoldSession(SessionRec *s, Boolean hold);
	Boolean			_TGetTransportHold(void);
	Boolean			_TGetTransportHoldSession(SessionRec *s);

#ifdef __SERVER__

#define TInit()									_TInit()
#define TOpen(a,b,c)							_TOpen(a,b,c)
#define TListen(a,b,c,d)						_TListen(a,b,c,d)
#define TOpenAsync(a,b,c)						_TOpenAsync(a,b,c)
#define TListenAsync(a,b,c,d)					_TListenAsync(a,b,c,d)
#define TClose(a)								_TClose(a)
#define TCloseAsync(a)							_TCloseAsync(a)
#define TUnthread(a)							_TUnthread(a)
#define TNetIdle(a)								_TNetIdle(a)
#define TUCheckTimers(a)						_TUCheckTimers(a)
#define TReadDataSync(a,b,c)					_TReadDataSync(a,b,c)
#define TReadDataASync(a,b,c)					_TReadDataASync(a,b,c)
#define TWriteDataSync(a,b,c)					_TWriteDataSync(a,b,c)
#define TWriteDataASync(a,b,c)					_TWriteDataASync(a,b,c)
#define TAsyncWriteFifoData(a)					_TAsyncWriteFifoData(a)
#define TReadData(a,b,c)						_TReadData(a,b,c)
#define TWriteData(a,b,c)						_TWriteData(a,b,c)
#define TReadAByte()							_TReadAByte()
#define TWriteAByte(a)							_TWriteAByte(a)
#define TQueueAByte(a)							_TQueueAByte(a)
#define TReadBytesReady(a)						_TReadBytesReady(a)
#define TDataReady(a)							_TDataReady(a)
#define TDataReadySess(a,b)						_TDataReadySess(a,b)
#define TIndication(a,b,c)						_TIndication(a,b,c)
#define TForwardReset(a)						_TForwardReset(a)
#define TUInitSessRec(a,b,c)					_TUInitSessRec(a,b,c)
#define TUSendCtl(a,b)							_TUSendCtl(a,b)
#define TUDoSendCtl(a,b)						_TUDoSendCtl(a,b)
#define TUDoSendOpenCtl(a,b)					_TUDoSendOpenCtl(a,b)
#define TUUpdateSessionInfo(a,b,c)				_TUUpdateSessionInfo(a,b,c)
#define TUSendOpen(a)							_TUSendOpen(a)
#define TUSendOpenAck(a)						_TUSendOpenAck(a)
#define TUSendCloseAdv(a)						_TUSendCloseAdv(a)
#define TUSendCloseConnAck(a)					_TUSendCloseConnAck(a)
#define TUSendFwdReset(a)						_TUSendFwdReset(a)
#define TUSendFwdResetAck(a)					_TUSendFwdResetAck(a)
#define TUSendFwdResetPacket(a,b)				_TUSendFwdResetPacket(a,b)
#define TUSendRetransAdv(a)						_TUSendRetransAdv(a)
#define TUOpenDialogPacket(a,b,c,d)				_TUOpenDialogPacket(a,b,c,d)
#define TUFwdResetPacket(a,b,c,d)				_TUFwdResetPacket(a,b,c,d)
#define TUCloseConnPacket(a,b,c,d)				_TUCloseConnPacket(a,b,c,d)
#define TUCloseConnAckPacket(a,b,c,d)			_TUCloseConnAckPacket(a,b,c,d)
#define TURetransAdvPacket(a,b,c,d)				_TURetransAdvPacket(a,b,c,d)
#define TUAllowConnection(a)					_TUAllowConnection(a)
#define TUDenyConnection(a)						_TUDenyConnection(a)
#define TNetError()								_TNetError()
#define TCheckError()							_TCheckError()
#define TUSetError(a)							_TUSetError(a)
#define TUGetError()							_TUGetError()
#define TGetUserRef(a)							_TGetUserRef(a)
#define TSetUserRef(a,b)						_TSetUserRef(a,b)
#define	TUFindSession(a,b,c)					_TUFindSession(a,b,c)
#define TSetTransportHold(a)					_TSetTransportHold(a)
#define TSetTransportHoldSession(a,b)			_TSetTransportHoldSession(a,b)
#define TGetTransportHold()					_TGetTransportHold()
#define TGetTransportHoldSession(a)				_TGetTransportHoldSession(a)

#else

void			TInit(void) =
	CallDispatchedFunction( kTInit );
OSErr			TOpen(SessionRec *s, PortT localPort, PortT remPort) =
	CallDispatchedFunction( kTOpen );
OSErr			TListen(SessionRec *s, PortT localPort, PortT remPort, unsigned long timeout) =
	CallDispatchedFunction( kTListen );
OSErr			TOpenAsync(SessionRec *s, PortT localPort, PortT remPort) =
	CallDispatchedFunction( kTOpenAsync);
OSErr			TListenAsync(SessionRec *s, PortT localPort, PortT remPort, unsigned long timeout) =
	CallDispatchedFunction( kTListenAsync );
OSErr			TClose(SessionRec *s) =
	CallDispatchedFunction( kTClose );
OSErr			TCloseAsync(SessionRec *s) =
	CallDispatchedFunction( kTCloseAsync );
void			TUnthread(SessionRec *ds) =
	CallDispatchedFunction( kTUnthread );
OSErr 			TNetIdle(NetParamBlock *pBlock) =
	CallDispatchedFunction( kTNetIdle );
OSErr			TUCheckTimers(SessionRec *s) =
	CallDispatchedFunction( kTUCheckTimers );

OSErr			TReadDataSync(SessionRec *sess, unsigned long length, Ptr address) =
	CallDispatchedFunction( kTReadDataSync );
OSErr			TReadDataASync(SessionRec *sess, unsigned long length, Ptr address) =
	CallDispatchedFunction( kTReadDataASync );
OSErr			TWriteDataSync(SessionRec *sess, unsigned long length, Ptr address) =
	CallDispatchedFunction( kTWriteDataSync );
OSErr			TWriteDataASync(SessionRec *sess, unsigned long length, Ptr address) =
	CallDispatchedFunction( kTWriteDataASync );
OSErr			TAsyncWriteFifoData(SessionRec *s) =
	CallDispatchedFunction( kTAsyncWriteFifoData );

				// in case you didn't feel like using a session...
OSErr			TReadData(unsigned long length, Ptr address, Boolean async ) =
	CallDispatchedFunction( kTReadData );
OSErr			TWriteData(unsigned long length, Ptr address, Boolean async ) =
	CallDispatchedFunction( kTWriteData );

				// read a byte 
unsigned char	TReadAByte( void ) =
	CallDispatchedFunction( kTReadAByte );
				// write a single byte on the transport NOW
OSErr			TWriteAByte( char myByte ) =
	CallDispatchedFunction( kTWriteAByte );
				// write a single byte on the transport after a full amount
OSErr			TQueueAByte( char myByte ) =
	CallDispatchedFunction( kTQueueAByte );

				// how much is available in the pipe
OSErr			TReadBytesReady( unsigned long *amount ) =
	CallDispatchedFunction( kTReadBytesReady );

OSErr			TDataReady(unsigned long *amount) =
	CallDispatchedFunction( kTDataReady );
OSErr			TDataReadySess(SessionRec *sess, unsigned long *amount) =
	CallDispatchedFunction( kTDataReadySess );
OSErr			TIndication(Fifo *physFifo, unsigned short physState, unsigned short length) =
	CallDispatchedFunction( kTIndication );
OSErr			TForwardReset(SessionRec *s) =
	CallDispatchedFunction( kTForwardReset );

OSErr			TUInitSessRec(SessionRec *s, PortT localPort, PortT remPort) =
	CallDispatchedFunction( kTUInitSessRec );
OSErr			TUSendCtl(SessionRec *s, Boolean probeRequested) =
	CallDispatchedFunction( kTUSendCtl );
OSErr			TUDoSendCtl(SessionRec *s, Boolean probeRequested) =
	CallDispatchedFunction( kTUDoSendCtl );
OSErr			TUDoSendOpenCtl(SessionRec *s, Boolean probeRequested) =
	CallDispatchedFunction( kTUDoSendOpenCtl );
Boolean			TUUpdateSessionInfo(SessionRec *s, char *header, Boolean *sequenceValid) =
	CallDispatchedFunction( kTUUpdateSessionInfo );

				// opening dialog routines
OSErr			TUSendOpen(SessionRec *s) =
	CallDispatchedFunction( kTUSendOpen );
OSErr			TUSendOpenAck(SessionRec *s) =
	CallDispatchedFunction( kTUSendOpenAck );
OSErr			TUSendCloseAdv(SessionRec *s) =
	CallDispatchedFunction( kTUSendCloseAdv );
OSErr			TUSendFwdReset(SessionRec *s) =
	CallDispatchedFunction( kTUSendFwdReset );
OSErr			TUSendFwdResetAck(SessionRec *s) =
	CallDispatchedFunction( kTUSendFwdResetAck );
OSErr			TUSendFwdResetPacket(SessionRec *s, unsigned char cCode) =
	CallDispatchedFunction( kTUSendFwdResetPacket );
OSErr			TUSendRetransAdv(SessionRec *s) =
	CallDispatchedFunction( kTUSendRetransAdv );

unsigned short	TUOpenDialogPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header) =
	CallDispatchedFunction( kTUOpenDialogPacket );
unsigned short	TUFwdResetPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header) =
	CallDispatchedFunction( kTUFwdResetPacket );
unsigned short	TUCloseConnPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header) =
	CallDispatchedFunction( kTUCloseConnPacket );
unsigned short	TURetransAdvPacket(SessionRec *s, Fifo *f, unsigned char packetType, char *header) =
	CallDispatchedFunction( kTURetransAdvPacket );
OSErr			TUAllowConnection(SessionRec *s) =
	CallDispatchedFunction( kTUAllowConnection );
OSErr			TUDenyConnection(SessionRec *s) =
	CallDispatchedFunction( kTUDenyConnection );
OSErr 			TNetError(void) =
	CallDispatchedFunction( kTNetError );
OSErr 			TCheckError(void) =
	CallDispatchedFunction( kTCheckError );
OSErr			TUSetError(OSErr err) =
	CallDispatchedFunction( kTUSetError );
OSErr			TUGetError(void) =
	CallDispatchedFunction( kTUGetError );
long 			TGetUserRef(SessionRec *s) =
	CallDispatchedFunction( kTGetUserRef );
void 			TSetUserRef(SessionRec *s, long refCon) =
	CallDispatchedFunction( kTSetUserRef );
void			TSetTransportHold(Boolean hold) =
	CallDispatchedFunction( kTSetTransportHold );
void			TSetTransportHoldSession(SessionRec *s, Boolean hold) =
	CallDispatchedFunction( kTSetTransportHoldSession );
Boolean			TGetTransportHold(void) =
	CallDispatchedFunction( kTGetTransportHold );
Boolean			TGetTransportHoldSession(SessionRec *s) =
	CallDispatchedFunction( kTGetTransportHoldSession );

#endif // __SERVER__
#endif // __Transport__


