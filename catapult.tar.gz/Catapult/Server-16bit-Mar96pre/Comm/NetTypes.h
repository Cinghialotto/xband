/*
 *	$Id: NetTypes.h,v 1.2 1995/05/10 11:04:11 jhsia Exp $
 *
 *	$Log: NetTypes.h,v $
 * Revision 1.2  1995/05/10  11:04:11  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		NetTypes.h

	Contains:	Missing types for unix build

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	 7/13/94	BET		first checked in

	To Do:
*/

#ifndef __NetTypes__
#define __NetTypes__

#define nil 0

#define noErr 0

typedef char *Ptr;

enum  {
	false,
	true
};

typedef unsigned char Boolean;

typedef long (*ProcPtr)();

typedef unsigned char Str255[256], Str63[64], Str32[33], Str31[32], Str27[28], Str15[16], *StringPtr, **StringHandle;

typedef short OSErr;

typedef unsigned long OSType;

typedef OSType *OSTypePtr;

typedef unsigned long ResType;

typedef ResType *ResTypePtr;

struct Point {
	short						v;
	short						h;
};

typedef struct Point Point;

typedef Point *PointPtr;

struct Rect {
	short						top;
	short						left;
	short						bottom;
	short						right;
};

typedef struct Rect Rect;

typedef Rect *RectPtr;


#endif // __NetTypes__

