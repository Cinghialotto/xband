/*
 *	$Id: DiskTransportPriv.h,v 1.2 1995/05/10 11:03:47 jhsia Exp $
 *
 *	$Log: DiskTransportPriv.h,v $
 * Revision 1.2  1995/05/10  11:03:47  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		DiskTransportPriv.h

	Contains:	GameTalk session layer private header

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	 5/26/94	BET		first checked in
		 <1>	 5/26/94	BET		first checked in
*/

#ifndef __DiskTransportPriv__
#define __DiskTransportPriv__



typedef
struct DTGlobalType
{
	short	gFileRef;		//file ref num for sucking data in
	short	gOutputFileRef;	//file ref for spitting data out
} DTGlobalType;

#ifdef	SIMULATOR
#define	MANAGERGLOBALTYPE		DTGlobalType
#endif


#endif __TransportPriv__
