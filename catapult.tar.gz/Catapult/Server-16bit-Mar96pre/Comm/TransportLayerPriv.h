/*
 *	$Id: TransportLayerPriv.h,v 1.2 1995/05/10 11:04:33 jhsia Exp $
 *
 *	$Log: TransportLayerPriv.h,v $
 * Revision 1.2  1995/05/10  11:04:33  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		TransportLayerPriv.h

	Contains:	GameTalk session layer private header

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <7>	11/29/94	BET		Fix the ugly rash of warnings on server build by redefining
									kMagicVal.
		 <6>	 6/19/94	BET		Add lastTransportError field to globals
		 <5>	  6/3/94	DJ		Add more FUD
		 <4>	  6/3/94	BET		Add more FUD
		 <3>	  6/2/94	BET		Change the way globals are accessed
		 <2>	  6/1/94	BET		first checked in
		 <1>	 5/26/94	BET		first checked in
*/

#ifndef __TransportPriv__
#define __TransportPriv__

#include "TransportStructs.h"

#define kMagicVal ((long)('B'<<24 | 'E'<<16 | 'T'<<8 | '!'))
// #define CHECKMAGIC(a) { if (a->TMagic != kMagicVal) ASSERT_MESG(0, "TGlobals are bad!"); }
#define CHECKMAGIC(a)

typedef
struct GlobalType
{
	SessionRec				*TSessionList;				// list of open sessions
	SessionRec				*TCurrentSession;			// current session for sessionless calls
	OSErr					lastTransportError;			// last error in the transport
	long					TMagic;						// Magic Cookie for testing
} TGlobalType;

#ifdef	SIMULATOR
#define	MANAGERGLOBALTYPE		TGlobalType
#else
TGlobalType TGlobals;
#endif


#endif __TransportPriv__
