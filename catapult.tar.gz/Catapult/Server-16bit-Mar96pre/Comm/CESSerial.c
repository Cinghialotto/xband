/*
 * 	$Id: CESSerial.c,v 1.2 1995/05/10 11:01:53 jhsia Exp $
 * 
 * 	$Log: CESSerial.c,v $
 * Revision 1.2  1995/05/10  11:01:53  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		CESSerial.c

	Contains:	Dumb serial code for CES only

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<10>	 8/24/94	SAH		Made compile.
		 <9>	 7/24/94	JOE		Made POpen() flags an unsigned long to fix typecheck barf
		 <8>	 7/15/94	HEC		Changed POpen/PListen server param to long flags for more
									general mode passing.
		 <7>	  7/5/94	BET		Change API for passing errors better
		 <6>	  7/3/94	HEC		Added server param to PListen and PListenAsync.
		 <5>	  7/2/94	BET		Fix a checkin fuckup.
		 <4>	  7/2/94	BET		Change POpen interfaces.
		 <3>	 6/21/94	SAH		Fucker. Fucker. Fucker. Fucker.
		 <2>	 6/21/94	BET		Clear timer every time, not just at hard init.  (Thanks Kon)
		 <1>	 6/21/94	BET		first checked in

	To Do:
*/

#include "PhysicalLayer.h"
#include "PhysicalStructs.h"
#include "hardDefines.h"
#include "SerialPhysicalPriv.h"
#include "heaps.h"
#include "SegaOS.h"
#include "NetErrors.h"
#include "Errors.h"
#include "Time.h"
#include "utils.h"
#include "SegaSerial.h"


#ifdef THINK_C
#define THINKSUCKS
#endif

// extern protos
OSErr	_PInit( void );
OSErr	_POpen( char *config, unsigned long flags );
OSErr	_PListen( char *config, long flags );
OSErr	_POpenAsync(char *config, long flags);
OSErr	_PListenAsync(char *config, long flags);
OSErr	_PClose( void );
short	_PNetIdle( NetParamBlock *pBlock );
OSErr	_PUOpenPort( Boolean listen, char *config );
void	_PUClosePort( void );


PGlobalType PGlobals;
#define	GetGlobals()	((PGlobalType *) &REFGLOBAL(PGlobals,PHReadyBuffer))

long
_PhysicalLayerControl ( short command, long data )
{
PGlobalType		*globals;
long			offset;
short			error;
short			count;

	error = commandSelectorUnknown;

	switch ( command )
		{
		case kHardInitialize:
		
			/* allocate and initialize our globals */
			GETMGRGLOBALSOFFSET(PGlobals,offset);
			error = AllocateGlobalSpace ( kPhysicalLayerManager, offset, sizeof(PGlobalType), (Ptr *) &globals );
			if ( error != noErr )
				{
				return error;
				}
			
			/* install our selectors */
			SetDispatchedFunction ( kPInit,					kPhysicalLayerManager,	_PInit );
			SetDispatchedFunction ( kPOpen,					kPhysicalLayerManager,	_POpen );
			SetDispatchedFunction ( kPListen,				kPhysicalLayerManager,	_PListen );
			SetDispatchedFunction ( kPOpenAsync,			kPhysicalLayerManager,	_POpenAsync);
			SetDispatchedFunction ( kPListenAsync,			kPhysicalLayerManager,	_PListenAsync);
			SetDispatchedFunction ( kPClose,				kPhysicalLayerManager,	_PClose );
			SetDispatchedFunction ( kPNetIdle,				kPhysicalLayerManager,	_PNetIdle );
			SetDispatchedFunction ( kPUOpenPort,			kPhysicalLayerManager,	_PUOpenPort );
			SetDispatchedFunction ( kPUClosePort,			kPhysicalLayerManager,	_PUClosePort );
			SetDispatchedFunction ( kPUReadSerialByte,		kPhysicalLayerManager,	_PUReadSerialByte );
			SetDispatchedFunction ( kPUWriteSerialByte,		kPhysicalLayerManager,	_PUWriteSerialByte );
			SetDispatchedFunction ( kPUTransmitBufferFree,	kPhysicalLayerManager,	_PUTransmitBufferFree );
			SetDispatchedFunction ( kPUTestForConnection,	kPhysicalLayerManager,	_PUTestForConnection );
			break;
		
		case kSoftInialize:
			// clear out globals
			globals = GetGlobals();
			for (count = sizeof(PGlobalType)-1; count >= 0; count--)
				((char *)globals)[count] = 0;
			
			globals->PHMagic = kMagicVal;
			
			error = noErr;
			break;
		
		case kHardClose:
			error = noErr;
			break;
		
		case kSoftClose:
			error = noErr;
			break;
					
		case kCodeBlockMoved:
			error = noErr;
			break;
					
		case kGlobalsMoved:
			error = noErr;
			break;
		}
		
	return error;
}


OSErr _PInit(void)
{
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	return noErr;
}

// client calling server, phone number as parameter in final box.  For now,
// a port number will be fine
OSErr _POpen( char *config, unsigned long flags )
{
OSErr			err;
char			byte;
long			time;
PGlobalType		*glob = GetGlobals();

	err = POpenAsync(config, true);
	if (err)
		return err;
	while (glob->PHConnState == kConnOpening)
		PNetIdle( 0L ) ;
}

// client calling server, phone number as parameter in final box.  For now,
// a port number will be fine
OSErr _PListen( char *config, long flags )
{
OSErr			err;
PGlobalType		*glob = GetGlobals();

	err = PListenAsync(config, flags);
	if (err)
		return err;
	while (glob->PHConnState == kConnListening)
		PNetIdle( 0L ) ;
}

OSErr _POpenAsync(char *config, long flags)
{
	return PUOpenPort( false, config );
}

// wait for peer to call us
OSErr _PListenAsync(char *config, long flags)
{
	// put the serial in answer mode
	return PUOpenPort( true, config );
}

OSErr _PClose(void)
{
	return noErr;
}


// NetIdle -- returns kNetPrimed (0) if net is idle, kNetPrimed (1) if ready,
//	negative gen purpose error code on failure.
short _PNetIdle( NetParamBlock *pBlock )
{
short			retVal = kNetIdle;
PGlobalType		*glob = GetGlobals();
NetParamBlock	localPB;
unsigned char	byte;
OSErr			err;

	CHECKMAGIC(glob);
	// dump the crap somewhere if we don't have a place to put it
	if (!pBlock) pBlock = &localPB;
	
	pBlock->ioLastPhysicalError = noErr;
	pBlock->ioAvailable = 0;
	pBlock->ioTotal = glob->PHTotal;
	pBlock->ioPhysNetState = glob->PHConnState;
	
	if (glob->PHConnState == kConnListening) {
		err = PUReadSerialByte(&byte);
		if (!err && (byte == kConnectToken)) {
			// tell originator we got it
			PUWriteSerialByte ( kConnectToken );
			glob->PHConnState = kConnOpen;
			}
		}
	else if (glob->PHConnState == kConnOpening) {
		if (GetCurrentTime() > glob->PHTimer) {
			PUWriteSerialByte ( kConnectToken );
			glob->PHTimer = GetCurrentTime() + kConnectTickle;
			}
		err = PUReadSerialByte(&byte);
		if (!err && (byte == kConnectToken))
			glob->PHConnState = kConnOpen;
		}
	return noErr;
}

OSErr _PUOpenPort( Boolean listen, char *config )
{
unsigned char 	fucker;
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	fucker = 0;
	
	*(unsigned char *) ( kDefaultInternal + kMStatus1 + 1) = kMonestop + kMenstop + kMbit_8 + kMresetModem + kMenModem;
	*(unsigned char *) ( kDefaultInternal + kBCnt + 1) = 0x38;
	*(unsigned char *) ( kDefaultInternal + kBCnt + 3) = 0x1;
	*(unsigned char *) ( kDefaultInternal + kMStatus1 + 1) = kMonestop + kMenstop + kMbit_8 + kMenModem;
		
	glob->PHTimer = 0;
	
	if (listen)
		glob->PHConnState = kConnListening;
	else
		glob->PHConnState = kConnOpening;

	return noErr;
}

void _PUClosePort(void)
{
PGlobalType		*glob = GetGlobals();

}

OSErr
_PUReadSerialByte ( unsigned char *byte )
{
short error;
unsigned short lineStatus;
	error = 0;
	
	/* get the serial status */
	lineStatus = *(unsigned char *) ( kDefaultInternal + kReadMStatus2 + 1 );

	if ( lineStatus & 0x1 )
		{
		*byte = *(unsigned char *) ( kDefaultInternal + kRxBuff + 1 );
		
		}
	else
		{
		error = -1;
		}
	
	REFGLOBAL( PGlobals, PHLastError ) = error;
	return error;
}


OSErr
_PUWriteSerialByte ( unsigned char byte )
{
short error;
Ptr		bufPtr;

	error = 0;
	
	*(unsigned char *) ( kDefaultInternal + kTxBuff + 1 ) = byte;

	REFGLOBAL( PGlobals, PHLastError ) = error;
	return error;
}


OSErr
_PUTransmitBufferFree ( void )
{
short error;
unsigned char status;

	error = 0;
	
	status = *(unsigned char *) ( kDefaultInternal + kReadMStatus1 + 1 );
	if ( status & 0x1 )
		{
		error = -1;
		}

	REFGLOBAL( PGlobals, PHLastError ) = error;
	return error;
}


OSErr
_PUTestForConnection ( void )
{
short error;
unsigned char byte;

	error = eNoConnection;
	
	/* if we got a byte, make sure it's the connect token */
	if ( PUReadSerialByte ( &byte ) == 0 )
		{
		if ( byte == kConnectToken )
			{
			error = 0;
			}
		}

	REFGLOBAL( PGlobals, PHLastError ) = error;
	return error;
}


