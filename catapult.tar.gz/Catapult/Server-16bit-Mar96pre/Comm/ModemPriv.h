/*
 *	$Id: ModemPriv.h,v 1.2 1995/05/10 11:04:01 jhsia Exp $
 *
 *	$Log: ModemPriv.h,v $
 * Revision 1.2  1995/05/10  11:04:01  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		ModemPriv.h

	Contains:	xxx put contents here xxx

	Written by:	Ted

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <8>	 7/17/94	HEC		More
		 <7>	 6/30/94	HEC		More
		 <6>	 6/20/94	HEC		MOre
		 <4>	 6/17/94	HEC		Major updates.

	To Do:
*/

//#define REMOTEMODEM 1
//#define ROSKO 1

#ifdef REMOTEMODEM
#define kPhoneNumber		"3661730"
#else
#define kPhoneNumber		"7771432"
#endif

typedef unsigned char uchar;

#ifdef ROSKO
#define kModemBaseAddress	0x003bc181
#define MULT				2
#else
#if REMOTEMODEM
#define kModemBaseAddress	0xfe000203
#else
#define kModemBaseAddress	0xfd000203
#endif
#define MULT				16
#endif

//
// CONF Register Modes
//

#define kV22bisMode		0x84
#define kV22Mode		0x52
#define kV21Mode		0xA0
#define kToneMode		0x80
#define kDialMode		0x81
#define kBell103Mode	0x60

//
// Baud Rates (SPEED Register Values)
//

#define k300Baud		0
#define k600Baud		1
#define k1200Baud		2
#define k2400Baud		3

//
// Return values
//

enum {
	kNothing = 0,
	kBusy,
	kRing,
	kNoDialtone,
	kLastEntry
};

//
// Timing
//
	
#define kJustOffHookDelay			90			/* 1.5 sec */

#define kDialToneTimeout			120			/* 2 sec */
#define kCallConnectTimeout			180			/* 3 sec */
#define kAnswerConnectTimeout		180			/* 3 sec */

#define kRingOnTimeMin				60			/* 1 sec */	
#define kRingOnTimeMax				180			/* 3 sec */
#define kRingOffTimeMin				180			/* 3 sec */
#define kRingOffTimeMax				270			/* 4.5 sec */

#define kBusyOnTimeMin				28			/* ~475ms */	
#define kBusyOnTimeMax				31			/* ~525ms */
#define kBusyOffTimeMin				28			/* ~475ms */	
#define kBusyOffTimeMax				31			/* ~525ms */	

typedef short ModemErr;
typedef volatile uchar * ModemPtr;

#ifndef ROSKO

ModemErr		_ModemOriginate(char *,short fake);
ModemErr		_ModemAnswer(short fake);
ModemErr		_ModemClose(void);
ModemErr		_ModemEstablishLink(void);
void			_ModemIdle(void);
void			SetTimer(short seconds);
void			ClearTimer(void);
void			_ModemVBL(void);
ModemErr		_ModemReadByte(char *data);
ModemErr		_ModemWriteByte(char data);

ModemErr		modemDial(char *number, Boolean v,short fake);
ModemErr		originate(void);
ModemErr		answer(void);
void			anstonedet(void);
void 			belldet(void);
void 			v21det(void);
void 			verifyRLSD(void);
void 			cleartone(void);
short 			callprogress(void);
void 			speedcheck(void);
short 			ringon(void);
void			ringoff(void);
ModemPtr		InitModem(void);
void			ResetModem(void);
Boolean			CheckDialTone(Boolean v);
void			timerCheck(void);
void			printregs(void);
void			MyDelayMS(short ms);
void			MyDelay(short ticks);
void			onhook(void);
void			offhook(void);
short			HandshakeORG(void);
void			WriteXRAM(long addr, long xcr, long val);
void			WriteYRAM(long addr, long ycr, long val);
long			ReadXRAM(long addr, long xcr);
long			ReadYRAM(long addr, long ycr);
short 			HaveCallWaiting(Boolean);
ModemErr		HandshakeANS(void);
void			forg(void);
void			fans(void);
void			LowerLatency(void);
#endif

//
// Macros for accessing modem registers
//

// GET SUBREGISTER VALUE
#define GET_REG(_o,_b,_m) \
	((*(volatile ModemPtr)(modemPtr + (_o)*MULT) >> (_b)) & (_m))

// SET SUBREGISTER VALUE
#define SET_REGVAL(_o,_b,_m,_x) \
	*(modemPtr + (_o)*MULT) = (*((volatile ModemPtr)(modemPtr + (_o))) & ~((_m)<<(_b))) | ((_x)<<(_b))

// SET REGISTER TO 1
#define ONE_REG(_o,_b) \
	*(modemPtr+(_o)*MULT) |= (1<<(_b))

// CLEAR REGISTER TO 0
#define ZERO_REG(_o,_b) \
	*(modemPtr+(_o)*MULT) &= ~(1<<(_b))

// READ REGISTER VALUE
#define READ_REG(_o) \
	(*(volatile ModemPtr)(modemPtr+(_o)*MULT))

// WRITE REGISTER VALUE
#define WRITE_REG(_o,_x) \
	*(modemPtr + (_o)*MULT) = (_x)

//
// SET REGISTERS
//

#define ASYNC1			ONE_REG(8,7)
#define NV25_1			ONE_REG(9,6)
#define CC1				ONE_REG(9,6)
#define CEQE1			ONE_REG(5,3)
#define CTS1			ONE_REG(15,5)
#define DSR1			ONE_REG(15,4)
#define SETCONF(_x)		WRITE_REG(0x12,_x)
#define DATA1			ONE_REG(9,2)
#define DTMF1			ONE_REG(9,5)
#define DTMFE1			ONE_REG(5,6)
#define GTE1			ONE_REG(3,1)
#define IOX1			ONE_REG(0x1d,3)
#define L2ACT1			ONE_REG(7,5)
#define L3ACT1			ONE_REG(7,3)
#define LL1				ONE_REG(9,3)
#define NEWC1			ONE_REG(0x1F,0)
#define ORG1			ONE_REG(9,4)
#define RA1				ONE_REG(7,1)
#define RLSD1			ONE_REG(15,7)
#define RTS1			ONE_REG(8,0)
#define RTRN1			ONE_REG(8,1)
#define SLEEP1			ONE_REG(9,0)
#define SWRES1			ONE_REG(4,6)
#define SETTBUFFER(_x)	WRITE_REG(0x10,_x)
#define TPDM1			ONE_REG(8,6)
#define TRFZ1			ONE_REG(8,3)
#define SETWDSZ(_x)		SET_REGVAL(6,0,3,_x)
#define XACC1			ONE_REG(0x1D,7)
#define YACC1			ONE_REG(0x1B,7)
#define XWT1			ONE_REG(0x1D,1)
#define YWT1			ONE_REG(0x1B,1)
#define XCR1			ONE_REG(0x1D,0)
#define YCR1			ONE_REG(0x1B,0)
#define SETXADDR(_x)	WRITE_REG(0x1C,_x)
#define SETYADDR(_x)	WRITE_REG(0x1A,_x)
#define SETXDATA(_x)	WRITE_REG(0x18,(_x)); WRITE_REG(0x19,((_x)>>8))
#define SETYDATA(_x)	WRITE_REG(0x16,(_x)); WRITE_REG(0x17,((_x)>>8))
#define SETTLVL(_x)		SET_REGVAL(0x13,4,0xf,_x)
#define SETVOL(_x)		SET_REGVAL(0x13,2,3,_x)

//
// CLEAR REGISTERS
//

#define ASYNC0			ZERO_REG(8,7)
#define NV25_0			ZERO_REG(9,7)
#define CC0				ZERO_REG(9,6)
#define CEQE0			ZERO_REG(5,3)
#define CTS0			ZERO_REG(15,5)
#define DSR0			ZERO_REG(15,4)
#define DATA0			ZERO_REG(9,2)
#define DTMF0			ZERO_REG(9,5)
#define GTE0			ZERO_REG(3,1)
#define IOX0			ZERO_REG(0x1d,3)
#define L2ACT0			ZERO_REG(7,5)
#define L3ACT0			ZERO_REG(7,3)
#define LL0				ZERO_REG(9,3)
#define NEWS0			ZERO_REG(0x1F,3)
#define ORG0			ZERO_REG(9,4)
#define RA0				ZERO_REG(7,1)
#define RLSD0			ZERO_REG(0xF,7)
#define RTS0			ZERO_REG(8,0)
#define RTRN0			ZERO_REG(8,1)
#define SLEEP0			ZERO_REG(9,0)
#define SWRES0			ZERO_REG(4,6)
#define TPDM0			ZERO_REG(8,6)
#define TRFZ0			ZERO_REG(8,3)
#define XCR0			ZERO_REG(0x1D,0)
#define YCR0			ZERO_REG(0x1B,0)
#define XWT0			ZERO_REG(0x1D,1)
#define YWT0			ZERO_REG(0x1B,1)

//
// STATUS
//

#define ASYNC			GET_REG(8,7,1)
#define ATBELL			GET_REG(0xB,3,1)
#define ATV25			GET_REG(0xB,4,1)
#define BEL103			GET_REG(0xB,0,1)
#define CC				GET_REG(9,6,1)
#define CEQE			GET_REG(5,3,1)
#define CONF			READ_REG(0x12)
#define CTS				GET_REG(0xF,5,1)
#define DSR				GET_REG(0xF,4,1)
#define DATA			GET_REG(9,2,1)
#define DTMF			GET_REG(9,5,1)
#define DTDET			GET_REG(0xB,1,1)
#define DTDIG			GET_REG(0xC,0,0xf)
#define EDET			GET_REG(0xC,7,1)
#define FE				GET_REG(0xE,4,1)
#define GTE				GET_REG(3,1,1)
#define IOX				GET_REG(0x1d,3,1)
#define L2ACT			GET_REG(7,5,1)
#define L3ACT			GET_REG(7,3,1)
#define LL				GET_REG(9,3,1)
#define NEWC			GET_REG(0x1F,0,1)
#define NEWS			GET_REG(0x1F,3,1)
#define ORG				GET_REG(9,4,1)
#define OE				GET_REG(0xE,3,1)
#define PARSL			GET_REG(6,4,3)
#define PE				GET_REG(0xE,5,1)
#define PEN				GET_REG(6,3,1)
#define RA				GET_REG(7,1,1)
#define RB				GET_REG(7,2,1)
#define RBUFFER			READ_REG(0)
#define RDBF			GET_REG(0x1E,0,1)
#define RI				GET_REG(0xF,3,1)
#define RLSD			GET_REG(0xF,7,1)
#define RTDET			GET_REG(0xE,7,1)
#define RTS				GET_REG(8,0,1)
#define RTRN			GET_REG(8,1,1)
#define SADET			GET_REG(0xD,2,1)
#define SLEEP			GET_REG(9,0,1)
#define SPEED			GET_REG(0xE,0,7)
#define STB				GET_REG(6,2,1)
#define SWRES			GET_REG(4,6,1)
#define TDBE			GET_REG(0x1E,3,1)
#define TONEA			GET_REG(0xB,7,1)
#define TONEB			GET_REG(0xB,6,1)
#define TONEC			GET_REG(0xB,5,1)
#define TPDM			GET_REG(8,6,1)
#define U1DET			GET_REG(0xD,3,1)
#define SCR				GET_REG(0xD,4,1)
#define S1DET			GET_REG(0xD,5,1)
#define WDSZ			GET_REG(6,0,3)
#define XACC			GET_REG(0x1D,7,1)
#define YACC			GET_REG(0x1B,7,1)
#define VOL				GET_REG(0x13,2,3)
#define XDATA			((long)(READ_REG(0x18)&0xFF) | (long)(READ_REG(0x19)<<8))
#define YDATA			((long)(READ_REG(0x16)&0xFF) | (long)(READ_REG(0x17)<<8))

//
// Useful Macros
//

#define NEWCONF \
	NEWC1; \
	while (NEWC)

#define SETV22BIS \
	SETCONF(kV22bisMode); NEWCONF

#define SETTONE \
	SETCONF(kToneMode); NEWCONF;

#define SETDATA \
	DATA1; NEWCONF

#define CLEARDATA \
	DATA0; NEWCONF

#define SETDIAL \
	SETCONF(kDialMode); NEWCONF; MyDelay(2)

#define TIMEREXPIRED \
	(REFGLOBAL(modem,timer) <= TickCount())

#define STARTTIMER \
	(REFGLOBAL(modem,timer) = TickCount())

#define RESET \
	SWRES1; SWRES0

typedef struct ModemGlobals
{
	unsigned short	connect:1;
	unsigned short	noanswer:1;
	unsigned short	timerset:1;
	unsigned short	ansdet:1;
	unsigned short	offtoon:1;
	unsigned short	lastdet:1;
	long			countdown;
	long			timer;
	long			ringtimer;
	short			ringontime;
	short			ringofftime;
	ModemPtr		modemPtr;
} ModemGlobals;

#define MODEMPTR register ModemPtr modemPtr = REFGLOBAL(modem,modemPtr)

#ifdef SIMULATOR
#define MANAGERGLOBALTYPE ModemGlobals
#else
extern ModemGlobals modem;
#endif


