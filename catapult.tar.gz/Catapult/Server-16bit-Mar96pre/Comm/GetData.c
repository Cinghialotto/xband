/* 
 *	$Id: GetData.c,v 1.2 1995/05/10 11:03:49 jhsia Exp $
 *
 *	$Log: GetData.c,v $
 * Revision 1.2  1995/05/10  11:03:49  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GetData.c

	Contains:	xxx put contents here xxx

	Written by:	Konstantin Othmer

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <9>	  8/9/94	HEC		Include errors.h
		 <8>	  8/1/94	KON		Remove local get data procs.
		 <7>	 7/18/94	ADS		Remove temp placeholder
		 <6>	 7/18/94	ADS		Init all vectors at hardinit time
		 <5>	  7/4/94	DJ		changed TReadBytesReady to return an OSErr
		 <4>	  6/4/94	SAH		Fuck. Fuck. Fuck. Fuck. Fuck. Fuck. Fuck. Fuck. Fuck. Fuck.
									Fuck. Fuck. Fuck. Fuck. Fuck. Fuck. Fuck. Fuck. Fuck. Fuck.
									Fuck. Fuck. Fuck. Fuck. Fuck. Fuck. Fuck. Fuck. Fuck. Fuck.
									Fuck. Fuck. Fuck. Fuck. Fuck. Fuck. Fuck. Fuck. Fuck. Fuck.
									Fuck. Fuck.
		 <3>	 5/27/94	KON		Wrapper network procs so they go through the dispatcher.
		 <2>	 5/26/94	BET		Update for managerized Disk Transport.
		 <1>	 5/24/94	KON		first checked in

	To Do:
*/

#include "TransportLayer.h"
#include "GetData.h"
#include "Errors.h"


/* the network versions */
OSErr			_NetworkGetDataSync( unsigned long length, Ptr address );
OSErr			_NetworkDataBytesReadyProc( unsigned long *amount );
short			_NetworkDataError( void );

long
_GetDataControl ( short command, long data )
{
short error;

	error = commandSelectorUnknown;

	switch ( command )
		{
		case kHardInitialize:
			error = noErr;
			
			// do these at hard time so we have something/anything installed

			SetDispatchedFunction ( kGetDataSync,			kGetDataManager,	_NetworkGetDataSync );
			SetDispatchedFunction ( kGetDataBytesReady,		kGetDataManager,	_NetworkDataBytesReadyProc );
			SetDispatchedFunction ( kGetDataError,			kGetDataManager,	_NetworkDataError );
			break;
		
		case kSoftInialize:
			error = noErr;
			/* install our selectors */
			/* these default to the network version */
			SetDispatchedFunction ( kGetDataSync,			kGetDataManager,	_NetworkGetDataSync );
			SetDispatchedFunction ( kGetDataBytesReady,		kGetDataManager,	_NetworkDataBytesReadyProc );
			SetDispatchedFunction ( kGetDataError,			kGetDataManager,	_NetworkDataError );
			break;
		
		case kHardClose:
			error = noErr;
			break;
		
		case kSoftClose:
			error = noErr;
			break;
					
		case kCodeBlockMoved:
			error = noErr;
			break;
					
		case kGlobalsMoved:
			error = noErr;
			break;
		}
		
	return error;
}


/* the network traps have their own versions here as the parameters are somewhat different than the transport */
/* layer's and we don't want the two pieces to be too far in bed as to proc ptr wise. the local get data procs */
/* are in Playback.c */

OSErr _NetworkGetDataSync( unsigned long length, Ptr address )
{
	return TReadData( length, address, false );	//read sync
}

OSErr _NetworkDataBytesReadyProc( unsigned long *amount )
{
	return TReadBytesReady(amount);
}

short _NetworkDataError( void )
{
	return TNetError( );
}

