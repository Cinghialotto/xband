/*
  	$Id: Modem.c,v 1.2 1995/05/10 11:03:59 jhsia Exp $
  
  	$Log: Modem.c,v $
 * Revision 1.2  1995/05/10  11:03:59  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		Modem.c

	Contains:	xxx put contents here xxx

	Written by:	xxx put writers here xxx

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <6>	 7/17/94	HEC		Add more stuff. Who knows what.
		 <6>	 7/17/94	HEC		More stuff. Who knows what.
		 <5>	 6/30/94	HEC		Added leased line mode to maintain connection, reduced latency
									from 28ms to 21ms. Cleaned up some goo.
		 <4>	 6/20/94	HEC		New stuff....
		 <3>	 6/17/94	HEC		Major updates.
		 <1>	  6/9/94	HEC		first checked in

	To Do:
*/

/********************************************************************************

	Catapult Modem Physical Layer
	
	Written by Ted Cohn, May/June 1994
	
	Copyright 1994 Catapult Entertainment, Inc.
	
	TODO:
	
	1.	Answer. DONE.
	2.	Reliable call waiting check.
	3.	Integrate into GameTalk and OS.
	4.	Hook up VBL to test line problems.
	5.	Time handshake at different baud rates.
	6.	Support 1200 and 300 baud (really necessary?).
	7.	Revamp modemErr throughout.
	8.	Check in the project! DONE
	9.	Determine loss of carrier/line (see item 1).
	10.	Check what baudrate we're we're actually.
	11.	Rosko hardware will be different. Maintain runtime switch
		between rosko and nubus board.
	
********************************************************************************/

#include "Dispatcher.h"
#include "SegaOS.h"
#include "Errors.h"
#include "Time.h"

#include "ModemPriv.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>


/* if we're not on the simulator, we need to allocate the globals for real */
#ifndef SIMULATOR
ModemGlobals modem;
#endif

#define GetCurrentTime() Ticks()

ModemErr _ModemClose(void)
{
	MODEMPTR;

	ResetModem();
	SLEEP1;	// power down
	return noErr;
}

void _ModemVBL(void)
{
	/*
		This is called at VBL time to detect any changes in modem status
		since we don't have IRQ capability. 

		Status we're interested in is:
			- call coming in
			- carrier detected
			- carrier lost
			- error: check for call waiting
	*/
}

ModemErr _ModemReadByte(char *data)
{
/*
	if data ready,
		data = *RBUFFER;
		return noErr;
*/
	return 1;
}

ModemErr _ModemWriteByte(char data)
{
	// if fifo full, wait until it isn't full, then deposit data and leave.
	// need some timeout
//	while (fifo full) ;
//	*fifo = data;
	return noErr;
}

/*--------------------------------------------------------------------------------
Called by OSIdle() to process any background tasks such as reading/writing fifo
data from/to the modem hardware.  _ModemVBL() senses transmission errors and call
waiting and informs _ModemIdle() via global flags.
--------------------------------------------------------------------------------*/
void _ModemIdle(void)
{
	// How does modem send NetErrors up the chain?
	

}

ModemPtr InitModem(void)
{
	REFGLOBAL(modem,modemPtr) = (ModemPtr)kModemBaseAddress;
	ResetModem();
	return REFGLOBAL(modem,modemPtr);
}

void ResetModem(void)
{
	MODEMPTR;
	SLEEP0;
	onhook();

	IOX1;
	WriteXRAM(0x36, 0, 0);
	SWRES1;
	while (!TDBE);	// wait for checksum data to be read from DSP
	IOX0;
	LL0;
	NEWCONF;
	SETVOL(0);
	NEWCONF;
	SETTLVL(0);
	NEWCONF;
	SETCONF(kV22bisMode);
	NEWCONF;
	DATA0;
	NEWCONF;
	TPDM1;
	NEWCONF;
	ASYNC1;
	NEWCONF;
	SETWDSZ(3);
	NEWCONF;
	WriteYRAM(0x21, 1, 7200);
	LowerLatency();
}

void LowerLatency(void)
{
MODEMPTR;
	CEQE0;
	WriteYRAM(8,1,0);
	WriteXRAM(8,1,0);
	WriteYRAM(2,1,3000);
	WriteXRAM(2,1,3000);
}

/********************************************************************************
 ********************************************************************************
									ORIGINATE
 ********************************************************************************
 ********************************************************************************/

ModemErr _ModemOriginate(char *number, short fake)
{
	MODEMPTR;
	printf("Originating call\n");
	ResetModem();
	MyDelay(180);
	if (!modemDial(number, true, fake))
	{
		if (HandshakeORG()) {
			printf("DID NOT CONNECT\n");
			ResetModem();
			return -1;
		}
		LL1;
		return 0;
	}
	return -1;
}

short HandshakeORG(void)
{
	MODEMPTR;
		printf("Waiting For Connection.\n");
		REFGLOBAL(modem,connect) = 0;
		REFGLOBAL(modem,offtoon) = 0;
		REFGLOBAL(modem,ansdet) = 0;
		REFGLOBAL(modem,lastdet) = 0;
		REFGLOBAL(modem,ringtimer) = TickCount();
		ClearTimer();
		ORG1;		// Set before Dial mode
		NEWCONF;
		SETDATA;
		SETDIAL;
		do {
			if (Button())
				break;
			if (ATV25)
			{
				anstonedet();
			}
#if 0
			else if (ATBELL)
			{
				belldet();
			}
			else if (TONEC)
			{
				v21det();
			}
#endif
			if (REFGLOBAL(modem,connect))
			{
				printf("CONNECT\n");
				RTS1;
				printf("Waiting for CTS.\n");
				while (!CTS && !Button())
					;
				return 0;
			}
			callprogress();
		} while (!REFGLOBAL(modem,noanswer));
		return 1;
}


// Modem Designer's Guide p7-3
void anstonedet(void)
{
	MODEMPTR;
	printf("anstonedet\n");
	REFGLOBAL(modem,ansdet) = 1;
	//while (!ATV25);
	SETV22BIS;
	SETDATA;
	SetTimer(5);
	while (1) {
		MyDelayMS(200);
		if (U1DET) {
			speedcheck();	
		}
		if (!REFGLOBAL(modem,timerset))
			return;
		if (TIMEREXPIRED)
		{
			ClearTimer();
			return;
		}
		LowerLatency();
		SETV22BIS;
		SETDATA;
	}
}

void belldet(void)
{
	MODEMPTR;
	printf("belldet\n");
	SETV22BIS;
	SETDATA;
	SetTimer(2);
	do {
		if (SCR)
		{
			speedcheck();
			ClearTimer();
			return;
		}
	} while (!TIMEREXPIRED);
	SETCONF(kBell103Mode);
	DATA0;
	NEWCONF;
	SETDATA;
	REFGLOBAL(modem,connect) = 1;
	ClearTimer();
	return;
}

 void v21det(void)
{
	MODEMPTR;
	printf("v21det\n");
	NV25_1;
	SETCONF(kV21Mode);
	NEWCONF;
	SETDATA;
	verifyRLSD();
}

 void verifyRLSD(void)
{
	MODEMPTR;
	printf("verifyRLSD\n");
	SetTimer(5);
	do {
		if (RLSD) {
			REFGLOBAL(modem,connect)=1;
			break;
		}
	} while (!TIMEREXPIRED);
	ClearTimer();
}

void cleartone(void)
{
	MODEMPTR;
	printf("cleartone\n");
	SETXDATA(0);
	SETYDATA(0);
	SETXADDR(0x6F);
	SETYADDR(0x6F);
	XWT1;
	XACC1;
	while(XACC);
	YWT1;
	YACC1;
	while(YACC);
	XWT0;
	YWT0;
}

void speedcheck(void)
{
	MODEMPTR;
	printf("speedcheck\n");
	SetTimer(5);
	do {
		if (RLSD) 
		{
			printf("RLSD dectected.\n");
			REFGLOBAL(modem,connect) = 1;
			if (SPEED == 2 || SPEED == 1)
			{
				SETCONF(kV22Mode);
				NEWCONF;
				printf("V22 mode\n");
			} else printf("V22bis mode\n");
			break;		
		}
	} while (!TIMEREXPIRED);
	ClearTimer();
}

short callprogress(void)
{
	MODEMPTR;
	CLEARDATA;
	SETDIAL;
	if (TONEA)
		return ringon();
	else
		ringoff();
	return 0;
}

short ringon(void)
{
	short result = 0;
	MODEMPTR;
	if (REFGLOBAL(modem,lastdet))
		return result;
	REFGLOBAL(modem,lastdet) = 1;
	REFGLOBAL(modem,ringofftime) = TickCount()-REFGLOBAL(modem,ringtimer);
	
	if (REFGLOBAL(modem,offtoon))
	{
		if (	(REFGLOBAL(modem,ringontime) >= kRingOnTimeMin)
			&&	(REFGLOBAL(modem,ringontime) <= kRingOnTimeMax)
			&&	(REFGLOBAL(modem,ringofftime) >= kRingOffTimeMin)
			&&	(REFGLOBAL(modem,ringofftime) <= kRingOffTimeMax) )
		{
			printf("RING\n");
			result = kRing;
		}
		else
		if (	(REFGLOBAL(modem,ringontime) >= kBusyOnTimeMin)
			&&	(REFGLOBAL(modem,ringontime) <= kBusyOnTimeMax)
			&&	(REFGLOBAL(modem,ringofftime) >= kBusyOffTimeMin)
			&&	(REFGLOBAL(modem,ringofftime) <= kBusyOffTimeMax) )
		{
			printf("BUSY\n");
			result = kBusy;
			REFGLOBAL(modem,noanswer) = 1;
		}
	} else REFGLOBAL(modem,offtoon) = 1;
	REFGLOBAL(modem,ringtimer) = TickCount();
	ClearTimer();
	return result;
}

void ringoff(void)
{
	MODEMPTR;
	if (REFGLOBAL(modem,lastdet))
	{
		REFGLOBAL(modem,lastdet) = 0;
		REFGLOBAL(modem,ringontime) = TickCount()-REFGLOBAL(modem,ringtimer);
		REFGLOBAL(modem,ringtimer) = TickCount();
	}
}

ModemErr modemDial(char *number, Boolean v, short fake)
{
	MODEMPTR;
	short digit;
	
	// Based on Modem Designer's Guide, p. 3-22
	SETTLVL(0);
	offhook();
	ORG1; SETCONF(kDialMode); NEWCONF;
	if (!fake && !CheckDialTone(v))
		return 1;
	MyDelay(4);
	for (; *number; number++) {
		while (!TDBE);
		DTMF1;
		// write digit to TBUFFER
		switch (*number) {
			case '*':
				digit = 0xA;
				break;
			case '#':
				digit = 0xE;
				break;
			case ',':
				MyDelay(120);
				continue;
			default:
				digit = *number - '0';
				if (digit < 0 || digit > 9)
					continue;
				break;
		}
		if (v) printf("%c",*number);
		SETTBUFFER(digit);
	}
	while (!TDBE);	 // wait for TBUFFER to empty
	SETCONF(kV22bisMode);
	NEWCONF;
	if (v) printf("\n");
	return 0;	
}

Boolean CheckDialTone(Boolean v)
{
	MODEMPTR;
	SETCONF(kDialMode); NEWCONF;
	MyDelayMS(kJustOffHookDelay);
	SetTimer(5);
	do {
		if (TONEA)
		{
			// We detected somethng that sounded like a dialtone.
			// Now make sure we keep it for at least a second
			SetTimer(1);
			do {
				if (!TONEA)
					return false;
			} while (!TIMEREXPIRED);
			if (v) printf("Dialtone Detected.\n");
			return true;
		}
	} while (!TIMEREXPIRED);
	if (v) printf("No Dialtone Detected.\n");
	return false;
}

/********************************************************************************
 ********************************************************************************
									ANSWER
 ********************************************************************************
 ********************************************************************************/

ModemErr _ModemAnswer(short fake)
{
	MODEMPTR;
	REFGLOBAL(modem,connect) = 0;
	onhook(); 
	ResetModem();
	if (!fake) {
		// WAIT FOR RING
		printf("waiting for ring (hit button to escape)\n");
		while (1) {
			if (RI) {
				printf("RING\n");
				break;
			}
			if (Button()) return abortErr;
		}
	}
	return HandshakeANS();
}

ModemErr HandshakeANS(void)
{
	MODEMPTR;
	ORG0;	// Set before entering Tone/Dial/Handshake mode
	NEWCONF;
	SETCONF(kV22bisMode);
	LowerLatency();
	NEWCONF;
	SETDATA;
	offhook();
	printf("Picked up the phone.\n");
	SetTimer(6);
	do {
		if (S1DET)
		{
			printf("s1det\n");
			SetTimer(4);
			timerCheck();
			break;
		}
#if 0
		else if (SCR)
		{
			printf("scr\n");
			SetTimer(3);
			timerCheck();
			if (!REFGLOBAL(modem,connect))
				break;
			while (NEWC);
			break;
		}
		else if (BEL103)
		{
			printf("bell103\n");
			NV25_1;
			DATA0;
			SETCONF(kBell103Mode);
			NEWCONF;
			SETDATA;
			SetTimer(3);
			timerCheck();
			break;
		} else
#endif
			if (Button()) return abortErr;
	} while (!TIMEREXPIRED);
	if (REFGLOBAL(modem,connect)) {
		RTS1;
		while (!CTS);
		printf("CONNECT\n");
		return noErr;
	}
	printf("NO CONNECT\n");
	ResetModem();
	return -1;
}

void timerCheck(void)
{
	MODEMPTR;
	do {
		if (DSR) {
			GTE1;
			NEWCONF;
		}
		if (RLSD)
		{
			LL1;
			REFGLOBAL(modem,connect) = 1;
			return;
		}
	} while (!TIMEREXPIRED);
}

/********************************************************************************
 ********************************************************************************
									UTILITIES
 ********************************************************************************
 ********************************************************************************/
 
void SetTimer(short seconds)
{
	REFGLOBAL(modem,timer) = TickCount() + seconds*60;
	REFGLOBAL(modem,timerset) = 1;
}

void ClearTimer(void)
{
	REFGLOBAL(modem,timerset) = 0;
}

void MyDelayMS(short ms)
{
	long time = TickCount()+ms/16;
	while (time > TickCount());
}

void MyDelay(short ticks)
{
	long time = TickCount()+ticks;
	while (time > TickCount());
}

void onhook(void)
{
	MODEMPTR;
	RA0; NEWCONF;
}

void offhook(void)
{
	MODEMPTR;
	RA1; NEWCONF;
}

void WriteXRAM(long addr, long xcr, long val)
{
	MODEMPTR;
	SETXDATA(val);
	SETXADDR(addr);
	if (xcr) XCR1; else XCR0;
	XWT1;
	XACC1;
	while(XACC);
}

void WriteYRAM(long addr, long ycr, long val)
{
	MODEMPTR;
	SETYDATA(val);
	SETYADDR(addr);
	if (ycr) YCR1; else YCR0;
	YWT1;
	YACC1;
	while(YACC);
}

long ReadXRAM(long addr, long xcr)
{
	MODEMPTR;
	SETXADDR(addr);
	if (xcr) XCR1; else XCR0;
	XWT0;
	XACC1;
	while(XACC);
	return XDATA;
}

long ReadYRAM(long addr, long ycr)
{
	MODEMPTR;
	SETYADDR(addr);
	if (ycr) YCR1; else YCR0;
	YWT0;
	YACC1;
	while(YACC);
	return YDATA;
}

/* Check the line for call waiting capability by actually dialing the call waiting
 * prefix and listening to what we get back.  If we get a dialtone after 4 seconds,
 * we've got it! Else, we don't. Then hang up.
 */
short HaveCallWaiting(Boolean v)
{
	short result;
	ResetModem();
	MyDelayMS(2500);
	if (modemDial("*70,", v, 0))
		return 0;
	result = CheckDialTone(v);
	ResetModem();
	return result;
}

