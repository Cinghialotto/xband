/*
 *	$Id: LoadCPE.h,v 1.2 1995/05/10 11:03:56 jhsia Exp $
 *
 *	$Log: LoadCPE.h,v $
 * Revision 1.2  1995/05/10  11:03:56  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		LoadCPE.h

	Contains:	xxx put contents here xxx

	Written by:	KON

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <3>	 7/20/94	ADS		Kill LoadCPE/msInstall for good.  Dead.
		 <2>	  6/5/94	KON		Remove CPE routine that no longer exists.

	To Do:
*/


ERROR ERROR ERROR

THIS FILE IS OBSOLETE

SHOULD NOT EVEN BE INCLUDED BY ANYBODY!




