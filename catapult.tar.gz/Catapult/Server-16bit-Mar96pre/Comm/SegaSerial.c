/*
 *	$Id: SegaSerial.c,v 1.2 1995/05/10 11:04:20 jhsia Exp $
 *
 *	$Log: SegaSerial.c,v $
 * Revision 1.2  1995/05/10  11:04:20  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		SegaSerial.c

	Contains:	xxx put contents here xxx

	Written by:	xxx put writers here xxx

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<15>	 6/15/94	BET		Remove TimeIdle from PNetIdle
		<14>	  6/9/94	BET		Bad packets would cause everything to go crazy.  This is a fix
									to the dispatcher to do the right thing
		<13>	  6/5/94	BET		Change interfaces to TOpen and TListen
		<11>	  6/4/94	BET		Remove DebugStrs (it's late).
		<10>	  6/4/94	BET		Fix more FUD
		 <9>	  6/3/94	SAH		Reference checkin
		 <8>	  6/3/94	BET		Add more FUD
		 <7>	  6/2/94	SAH		(Really BET) First round serial debugging -- IT WORKS!
		 <6>	  6/1/94	BET		Fix some late arrivals
		 <5>	  6/1/94	BET		Major rewrite, take the latest from CMPhysical.c
		 <4>	 5/31/94	SAH		Updated to latest interfaces.
		 <3>	 5/27/94	SAH		Commented out a bunch of stuff that was crashing the sega build.
		 <2>	 5/26/94	SAH		Fleshed out some.

	To Do:
*/


#include "heaps.h"
#include "SegaOS.h"
#include "Errors.h"
#include "PhysicalLayer.h"
#include "SerialPhysicalPriv.h"
#include "Time.h"
#include "utils.h"


#include "PhysicalLayer.h"
#include "PhysicalStructs.h"
#include "SegaSerial.h"
#include "SerialPhysicalPriv.h"
#include "TransportLayer.h"
#include "Fifo.h"
#include "ccitt.h"
#include "heaps.h"
#include "SegaOS.h"
#include "time.h"
#include "NetErrors.h"
#include "Errors.h"
#include "SegaVDP.h"


#ifdef THINK_C
#define THINKSUCKS
#endif

// extern protos
void	_PInit( void );
Boolean	_POpen( char *config );
Boolean	_PListen( char *config );
Boolean	_PClose( void );
short	_PNetIdle( NetParamBlock *pBlock );
OSErr	_PWritePacketSync( WDS *sendBuffer );
OSErr	_PWritePacketASync( WDS *sendBuffer );
Boolean	_PUOpenPort( Boolean listen, char *config );
void	_PUClosePort( void );
OSErr	_PUAsyncReadData( long numBytes, unsigned char *dataBuf );
OSErr	_PUAsyncWriteFifoData( void );
#ifdef __MWERKS__
static asm short _PUProcessIdle(void);
#else
static short _PUProcessIdle(void);
#endif
short	_PUProcessGTIdle(unsigned short length);
short	_PUProcessSTIdle(unsigned short length);
void	PUAsyncReadDispatch(PGlobalType * glob, unsigned char prevChar);

// internal protos
short PUGetToolProcID(void);
pascal void PUAsyncWriteCompletion(ConnHandle hConn);
pascal void PUAsyncReadCompletion(ConnHandle hConn);


#ifdef __SERVER__
	static	PGlobalType *	GetGlobals( void );
#else
	PGlobalType PGlobals;
	#define	GetGlobals()	((PGlobalType *) &REFGLOBAL(PGlobals,PHReadyBuffer))
#endif

#ifndef __SERVER__

long
_PhysicalLayerControl ( short command, long data )
{
PGlobalType		*globals;
long			offset;
short			error;
short			count;

	error = commandSelectorUnknown;

	switch ( command )
		{
		case kHardInitialize:
		
			/* allocate and initialize our globals */
			GETMGRGLOBALSOFFSET(PGlobals,offset);
			error = AllocateGlobalSpace ( kPhysicalLayerManager, offset, sizeof(PGlobalType), (Ptr *) &globals );
			if ( error != noErr )
				{
				return error;
				}
			
			/* install our selectors */
			SetDispatchedFunction ( kPInit,					kPhysicalLayerManager,	_PInit );
			SetDispatchedFunction ( kPOpen,					kPhysicalLayerManager,	_POpen );
			SetDispatchedFunction ( kPListen,				kPhysicalLayerManager,	_PListen );
			SetDispatchedFunction ( kPClose,				kPhysicalLayerManager,	_PClose );
			SetDispatchedFunction ( kPNetIdle,				kPhysicalLayerManager,	_PNetIdle );
			SetDispatchedFunction ( kPWritePacketSync,		kPhysicalLayerManager,	_PWritePacketSync );
			SetDispatchedFunction ( kPWritePacketASync,		kPhysicalLayerManager,	_PWritePacketASync );
			SetDispatchedFunction ( kPUOpenPort,			kPhysicalLayerManager,	_PUOpenPort );
			SetDispatchedFunction ( kPUClosePort,			kPhysicalLayerManager,	_PUClosePort );
//			SetDispatchedFunction ( kPUAsyncWriteFifoData,	kPhysicalLayerManager,	_PUAsyncWriteFifoData );
			SetDispatchedFunction ( kPUProcessIdle,			kPhysicalLayerManager,	_PUProcessIdle );
			SetDispatchedFunction ( kPUProcessGTIdle,		kPhysicalLayerManager,	_PUProcessGTIdle );
			SetDispatchedFunction ( kPUProcessSTIdle,		kPhysicalLayerManager,	_PUProcessSTIdle );
			SetDispatchedFunction ( kPUReadSerialByte,		kPhysicalLayerManager,	_PUReadSerialByte );
			SetDispatchedFunction ( kPUWriteSerialByte,		kPhysicalLayerManager,	_PUWriteSerialByte );
			SetDispatchedFunction ( kPUTransmitBufferFree,	kPhysicalLayerManager,	_PUTransmitBufferFree );
			SetDispatchedFunction ( kPUTestForConnection,	kPhysicalLayerManager,	_PUTestForConnection );
			SetDispatchedFunction ( kPUReadTimeCallback,	kPhysicalLayerManager,	_PUReadTimeCallback );
			SetDispatchedFunction ( kPUWriteTimeCallback,	kPhysicalLayerManager,	_PUWriteTimeCallback );
			break;
		
		case kSoftInialize:
			// clear out globals
			globals = GetGlobals();
			for (count = sizeof(PGlobalType)-1; count >= 0; count--)
				((char *)globals)[count] = 0;
			
			globals->PHMagic = kMagicVal;
			// set up buffers
			REFGLOBAL(PGlobals,PHLengthsBuf) = NewMemory(false,kFrameStartBufSiz);
			REFGLOBAL(PGlobals,PHReadDataBuf) = NewMemory(false,kPhysBufferSize);
			REFGLOBAL(PGlobals,PHWriteDataBuf) = NewMemory(false,kPhysBufferSize);
			REFGLOBAL(PGlobals,PHStagingBuf) = NewMemory(false,kMaxPacket);
			
			error = noErr;
			break;
		
		case kHardClose:
			error = noErr;
			break;
		
		case kSoftClose:
			error = noErr;
			break;
					
		case kCodeBlockMoved:
			error = noErr;
			break;
					
		case kGlobalsMoved:
			error = noErr;
			break;
		}
		
	return error;
}

#endif

#ifdef __SERVER__

static
PGlobalType *	GetGlobals( void )
{
PGlobalType * globals;

	globals = 0;
	
	GetManagerGlobals ( kPhysicalLayerManager, (Ptr *) &globals, (short *) 0L );
	
	return globals;
}

#endif

void _PInit(void)
{
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
/************
************* Done for us at softInit 
	// assume that the globals are clear by now!
	glob->PHLengthsBuf = (unsigned char *)NewMemory(false, kFrameStartBufSiz);
	glob->PHReadDataBuf = (unsigned char *)NewMemory(false, kPhysBufferSize);
	glob->PHWriteDataBuf = (unsigned char *)NewMemory(false, kPhysBufferSize);
	glob->PHStagingBuf = (unsigned char *)NewMemory(false, kMaxPacket);
*************/
}

// client calling server, phone number as parameter in final box.  For now,
// a port number will be fine
Boolean _POpen( char *config )
{
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	// put the modem in answer mode and dial number here
//	PUWriteSerialByte ( kConnectToken );
	return PUOpenPort( false, config );
}

// client calling server, phone number as parameter in final box.  For now,
// a port number will be fine
Boolean _PListen( char *config )
{
	// put the modem in answer mode and wait here
//	PUWriteSerialByte ( kConnectToken );
	return PUOpenPort( true, config );
}

Boolean _PClose(void)
{
	return noErr;
}


// NetIdle -- returns kNetPrimed (0) if net is idle, kNetPrimed (1) if ready,
//	negative gen purpose error code on failure.
short _PNetIdle( NetParamBlock *pBlock )
{
short			retVal = kNetIdle;
PGlobalType		*glob = GetGlobals();
NetParamBlock	localPB;

	CHECKMAGIC(glob);
	// dump the crap somewhere if we don't have a place to put it
	if (!pBlock) pBlock = &localPB;
	
	pBlock->ioLatestResult = noErr;
	pBlock->ioAvailable = 0;
	pBlock->ioTotal = glob->PHTotal;

	switch (glob->PHConnState) {
		case kConnOpen:
			pBlock->ioNetUp = true;
			break;
		case kConnClosed:
		case kConnClosing:
			pBlock->ioNetUp = false;
			break;
		default:
			ASSERT_MESG(0,"Unhandled connection state case!");
		};
	
	return _PUProcessIdle();
}

OSErr _PWritePacketSync(WDS *sendBuffer)
{
short			retVal;
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	if (glob->PHConnState != kConnOpen) 
		return kLinkClosed;

	retVal = PWritePacketASync(sendBuffer);
	if (retVal) return retVal;
	
	while (glob->PHWriteActive)
		PNetIdle(nil);
		
	return noErr;
}

// queue small chunks as we find kDLEChar's scattered through the outgoing buffer
// called by TWriteDataSync, and in turn TWriteDataASync
OSErr _PWritePacketASync(WDS *sendBuffer)
{
PGlobalType		*glob = GetGlobals();
OSErr			theErr;
long			bufLength, iter, padPoint;
unsigned char	*addr;
unsigned short	crc;
Boolean			doingFCS;

	CHECKMAGIC(glob);
	if (glob->PHConnState != kConnOpen) 
		return kLinkClosed;

	bufLength = sendBuffer->length1 + sendBuffer->length2;
	if (FifoRemaining(&glob->PHWriteFifo) < bufLength) {
		// we have more to write than the fifo can handle.  Idle here if
		// if the buffer is big enough to ever handle it, otherwise idle until
		// FifoAvailable is zero and switch buffers.
		if (FifoSize(&glob->PHWriteFifo) > bufLength) {
			// the fifo can handle it, just not right now.  Idle a bit
			while (FifoRemaining(&glob->PHWriteFifo) < bufLength) {
				PNetIdle(nil);
				if (Button()) return kAsyncInProgErr;
				}
			}
		else {
			// the buffer is bigger than the fifo
			ASSERT_MESG(0,"The packet write fifo isn't big enough to for this buffer");
			}
		}
	
	bufLength = sendBuffer->length1;
	addr = sendBuffer->buf1;
	padPoint = iter = 0;
	crc = 0xffff;
	doingFCS = false;
	while (1) {
		// (doingFCS == true) signals the writing of the FCS itself
		if (!doingFCS)
			crc = ccitt_updcrc(crc, (unsigned char *)addr, bufLength);
		while (iter < bufLength) {
			if (addr[iter] == kDLEChar) {
				iter += 1;
				theErr = FifoWrite(&glob->PHWriteFifo, &addr[padPoint], iter - padPoint);
				if (theErr) return theErr;
				if (iter <= bufLength) {
					// send a pad
					theErr = FifoWrite(&glob->PHWriteFifo, &addr[iter-1], 1);
					if (theErr) return theErr;
					padPoint = iter;
					}
				}
			else {
				iter += 1;
				if (iter == bufLength) {
					// flush the rest of the buffer
					theErr = FifoWrite(&glob->PHWriteFifo, &addr[padPoint], bufLength - padPoint);
					if (theErr) return theErr;
					}
				}
			}
		if (doingFCS)
			break;
		else if (addr == sendBuffer->buf1) {
			// if the address is the first buffer then it should be the second next loop
			padPoint = iter = 0;
			bufLength = sendBuffer->length2;
			addr = sendBuffer->buf2;
			}
		else {
			// if the address is not the FCS and not the first buffer then it 
			// is the second and we should set up for the FCS
			crc = ~crc;
			padPoint = iter = 0;
			bufLength = sizeof(crc);
			addr = (unsigned char *)&crc;
			doingFCS = true;
			}
		}
		
	// send the framing
	crc = (kDLEChar<<8) + kETXChar;
	theErr = FifoWrite(&glob->PHWriteFifo, (unsigned char *)&crc, sizeof(crc));
	if (theErr) return theErr;
	
	// call netidle to get the write rolling
	PNetIdle(nil);
	
	return noErr;
}

// this guy gets hit when any frame comes in.  He is probably written in assembly and needs
// to finish very fast.  He will call either the PUProcessGTIdle or an entry from the listener
// table when a packet has arrived.


#if defined(THINKSUCKS)
static short _PUProcessIdle(void)
{
short		frameSize, retVal;
register PGlobalType	*glob = GetGlobals();

	CHECKMAGIC(glob);
		asm {
			clr.w	retVal
			tst.b	OFFSET(PGlobalType,PHIndicating)(glob)
			bne.s	@exit
			clr.b	-(a7)
			pea		2
			pea		frameSize
			pea		OFFSET(PGlobalType,PHLengthsFifo)(glob)
			jsr		FifoRead
			lea		14(SP),sp
			beq.s	@hasFifo						// if no err, dispatch on it
			cmp.w	#kFifoUnderflowErr, d0			// else check to see if we just didn't have one
			bne.s	@noFifo							// something else, leave the error
			moveq.l	#0, d0							// just out, clear the error
			bra.s	@noFifo							// and bail
			
			// we have some data in the fifo, dispatch based on known partitioning or
			// listener dispatch table for partition 000 frames
			// Note:  This is currently optimized such that any frame of size 4 is assumed to be
			// a GT frame.  If we partition further, we need to add to the dispatcher
@hasFifo:	move.w	frameSize,-(sp)					// push param
			cmp.w	#4, frameSize
			bhi.s	@STFrame
			jsr		_PUProcessGTIdle
			bra.s	@noFifo
@STFrame:	jsr		_PUProcessSTIdle
			
@noFifo:	move.w	d0,retVal
			addq.l	#sizeof(short),sp				// pop param
@exit:		move.w	retVal,d0
			}
}

static short _PUProcessGTIdle(unsigned short length)
{
short		retVal;
long		gtFrame;
register PGlobalType	*glob = GetGlobals();

	CHECKMAGIC(glob);
		asm {
			// first find the location of the queue entry for this data
			move.w	#kNetIdle, retVal				// save the default return
			moveq.l	#0,d2							// prepare for index
			move.w	d2, -(sp)						// borrow it for stack param
			move.w	OFFSET(PGlobalType,PHGameFifoW)(glob), d2		// get the index
			move.w	d2,d1							// prepare to increment
			addq.w	#1,d1							// increment it
			cmp.w	#kGameFifoSize, d1				// bounds check
			bmi.s	@indexOK						// if index fits
			moveq.l	#0,d1							// otherwise wrap
@indexOK:	move.w	d1, OFFSET(PGlobalType,PHGameFifoW)(glob)		// and store it

			// at this point the index is set up, postincremented, wrapped and saved
			// need to make an address out of it and store the incoming frame at that location
			lsl.w	#2,d2							// run it out to long address
			move.l	OFFSET(PGlobalType,PHGameFifoBuf)(glob), A0		// get the buffer
			lea		0(a0,d2.w), a1					// and the address of the frame
			move.w	length,d0						// push the size of the buffer
			ext.l	d0
			move.l	d0, -(sp)
			move.l	a1, -(sp)						// and the address of the frame
			pea		OFFSET(PGlobalType,PHReadFifo)(glob)
			jsr		FifoRead						// do it up!
			lea		14(SP),sp
			
			// now that we have the data, we can checksum it.  Setting the frame to 0 should
			// be a sufficient flag that the data was bad if the checksum fails
			// (fuck the checksum)
			
@exit:		move.w	retVal,d0
			rts
			}
}

#else
	#error "Undefined compiler!  And you want inline asm?!?"
#endif

// this guy gets hit when a GameTalk frame comes in.  He is probably written in assembly and needs
// to finish very fast.  He is hit by some dispatcher that is also probably written in assembly.
// this guy gets hit when a ServerTalk frame comes in.  His speed is not as important as the
// PUProcessGTIdle.
short _PUProcessSTIdle(unsigned short length)
{
short			retVal = kNetIdle;
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	glob->PHIndicating = true;
	// checksum happens in the fifo to avoid gratuitous copying
	if (FifoChkSum(&glob->PHReadFifo, length - kFramingSize) == 0x1D0F) {
		FifoSkip(&glob->PHReadFifo, kPhysHdrSiz, false);
#ifdef CORRECT
		// good packet, dispatch on type
		(*PIdler[((PLinkHeader *)frameStart)->protoType])();
#else
		// a good approximation, since there is only one protocol type
		TIndication(&glob->PHReadFifo, glob->PHConnState, length - (kPhysHdrSiz + kFCSSize + kFramingSize));
#endif
	// kill the FCS, get ready for framing by passing true here
	FifoSkip(&glob->PHReadFifo, 2, true);
#ifdef DEBUG
	FifoRead(&glob->PHReadFifo, (unsigned char *)&retVal, sizeof(short), false);
	ASSERT_MESG(retVal == 0x1003,"Frame end mismatch");
#else
	// and the framing
	FifoSkip(&glob->PHReadFifo, kFramingSize, false);
#endif
		}
	else {
		// BRAIN DAMAGE: record bad packet reception here 
		ASSERT_MESG(0,"Bad Packet Detected");
		// HACK -- This is done because Skip with a boolean of true aligns the _next_ read to have
		// the framing.  Then we call with false to get the framing.  Obstensibly, this is also so
		// the debug code can look at the framing
		FifoSkip(&glob->PHReadFifo, length - 2, true);
#ifdef DEBUG
		FifoRead(&glob->PHReadFifo, (unsigned char *)&retVal, sizeof(short), false);
		ASSERT_MESG(retVal == 0x1003,"Frame end mismatch");
#else
		// and the framing
		FifoSkip(&glob->PHReadFifo, kFramingSize, false);
#endif
		}
	retVal = kNetPrimed;
	glob->PHIndicating = false;

	return retVal;		
}


Boolean _PUOpenPort( Boolean listen, char *config )
{
unsigned char 	fucker;
PGlobalType		*glob = GetGlobals();

	CHECKMAGIC(glob);
	fucker = 0;
	
	*sIntEn = fucker;			// clear all interrupts
	*sLineCtl = sLCRDLab;		// get ready to set divisor
	*sDivLow = 85;				// 2400 baud with 3.2768 Mhx crystal
	*sDivHi = fucker;
	
	*sLineCtl = sLCR8Bits + sLCR1Stop;
	*sFifoCtl = fEnFifos;
	
	// set up the fifo
	FifoInit(&glob->PHReadFifo, glob->PHReadDataBuf, kPhysBufferSize, kCircularQ);
	FifoInit(&glob->PHWriteFifo, glob->PHWriteDataBuf, kPhysBufferSize, kCircularQ);
	FifoInit(&glob->PHLengthsFifo, glob->PHLengthsBuf, kFrameStartBufSiz, kCircularQ);
	glob->PHFrameSizAccum = 0;
	
	// remove this if we are GT/ST coresident
	glob->PHPacketState = kProcessingST;
	
	glob->PHReadTimeRef = AddTimeRequest((TimeRequestProc)_PUReadTimeCallback, 0);
	glob->PHWriteTimeRef = AddTimeRequest((TimeRequestProc)_PUWriteTimeCallback, 0);
	glob->PHConnState = kConnOpen;
}

void _PUClosePort(void)
{
PGlobalType		*glob = GetGlobals();

	RemoveTimeRequest(glob->PHReadTimeRef);
	RemoveTimeRequest(glob->PHWriteTimeRef);
}

long _PUReadTimeCallback( long time, long data )
{
OSErr			error;
unsigned char	byte;
PGlobalType		*glob;

	if ( GetManagerGlobals ( kPhysicalLayerManager, (Ptr *) &glob, 0L ) != noErr )
		{
		/* BRAIN DAMAGE: things are really bad if we get here */
		return 0;
		}

	CHECKMAGIC(glob);
	
	error = PUReadSerialByte(&byte);
	while (!error) {
		glob->PHFrameSizAccum += 1;
		FifoWrite(&glob->PHReadFifo, &byte, sizeof(byte));
		PUAsyncReadDispatch(glob, byte);
		error = PUReadSerialByte(&byte);
		}
		
	return time+1;
}

// this needs to be an assembly dispatcher for the box
void PUAsyncReadDispatch(PGlobalType * glob, unsigned char prevChar)
{
	if (glob->PHPacketState == kIdleLink) {
//		if (prevChar & kGT2FlagMask)						// check high bit only partition
//			glob->PHPacketState = kProcessingGT2;
//		else if ((prevChar & kGT1FlagMask) == kGT1Flag) 	// check low/high partition
//			glob->PHPacketState = kProcessingGT1;
//		else if ((prevChar & kSTFlagMask) == kSTFlag)		// check all low partition
			glob->PHPacketState = kProcessingST;
//		else {
//			ASSERT_MESG(0, "Unhandled Frame Type (Framing error?)");
//			}
		}
	if ((glob->PHPacketState == kProcessingST) || (glob->PHPacketState == kCheckNextST)) {
		// first check for frame end
		if ((glob->PHPacketState == kCheckNextST) && (prevChar == kETXChar)) {
			// yep, the last one was a frame
			FifoWrite(&glob->PHLengthsFifo, (unsigned char *)&glob->PHFrameSizAccum, sizeof(short));
			glob->PHFrameSizAccum = 0;
			// if GT/ST coreside on the link, use this one instead
			// glob->PHPacketState = kIdleLink; 			// reset for next time
			glob->PHPacketState = kProcessingST; 			// reset for next time
			}
		else if (prevChar == kDLEChar) {					// found a DLE?
			if (glob->PHPacketState == kCheckNextST) { 		// yep, did we just see one?
				FifoUnwrite(&glob->PHReadFifo, 1);			// yep, dump this one
				// update fram size accumulator
				glob->PHFrameSizAccum -= 1;
				glob->PHPacketState = kProcessingST; 		// reset for next time
				}
			else											// didn't just see one, prepare to
				glob->PHPacketState = kCheckNextST;			// dump next one if there is one
			}
		else {
			glob->PHPacketState = kProcessingST; 			// either way the next is something!
			}
		}
}

long _PUWriteTimeCallback( long time, long unused )
{
PGlobalType		*glob;
short			count;
long			returnTime;
unsigned long	fifoBytesAvailable;
	
	if ( GetManagerGlobals ( kPhysicalLayerManager, (Ptr *) &glob, 0L ) != noErr )
	{
		/* ==BRAIN DAMAGE==: things are really bad if we get here */
		return 0;
	}

	CHECKMAGIC(glob);

	returnTime = time + 1;
	if (glob->PHConnState == kConnOpen) 
	{
		fifoBytesAvailable = FifoAvailable(&glob->PHWriteFifo);
		if (fifoBytesAvailable != 0) 
		{
			if (PUTransmitBufferFree() == noErr) 
			{
				count = 4;
				if (fifoBytesAvailable > count)
					fifoBytesAvailable = count;
					
				glob->PHWriteActive = true;

				FifoRead(&glob->PHWriteFifo, glob->PHStagingBuf, fifoBytesAvailable, false);
	
				for (count=0; count<fifoBytesAvailable; count++)
					PUWriteSerialByte(glob->PHStagingBuf[count]);
			}
		}
		else 
		{
			glob->PHWriteActive = false;
		}
	}
		
	return returnTime;
}

OSErr
_PUReadSerialByte ( unsigned char *byte )
{
short error;
short lineStatus;
	error = 0;
	
	/* get the serial status */
	lineStatus = *sLineSts;

#if 0
	/* check for transmission errors */
	if ( lineStatus & sParityError )
		{
		asm { dc.w	0xa003 };
		error = eParityError;
		FLAGANALYZER();
		}
	else
	if ( lineStatus & sFrameError )
		{
		asm { dc.w	0xa003 };
		error = eFrameError;
		FLAGANALYZER();
		}
	else
	/* read the data if there is some */
#endif
	if ( lineStatus & sDataReady )
		{
		*byte = *sRcvTrx;
		
		}
	else
		{
		error = eNoByteReady;
		}
	
	REFGLOBAL( PGlobals, PHLastError ) = error;
	return error;
}


OSErr
_PUWriteSerialByte ( unsigned char byte )
{
short error;
Ptr		bufPtr;

	error = 0;
	
	*sRcvTrx = byte;
//		bufPtr = *(Ptr *) 0x250;
//		*bufPtr++ = byte;
//		*(Ptr *) 0x250 = bufPtr;

	REFGLOBAL( PGlobals, PHLastError ) = error;
	return error;
}


OSErr
_PUTransmitBufferFree ( void )
{
short error;

	error = eTransmitBufferFull;
	
	if ( *sLineSts & sXmitHoldingEmpty )
		{
		error = 0;
		}

	REFGLOBAL( PGlobals, PHLastError ) = error;
	return error;
}


OSErr
_PUTestForConnection ( void )
{
short error;
unsigned char byte;

	error = eNoConnection;
	
	/* if we got a byte, make sure it's the connect token */
	if ( PUReadSerialByte ( &byte ) == 0 )
		{
		if ( byte == kConnectToken )
			{
			error = 0;
			}
		}

	REFGLOBAL( PGlobals, PHLastError ) = error;
	return error;
}


