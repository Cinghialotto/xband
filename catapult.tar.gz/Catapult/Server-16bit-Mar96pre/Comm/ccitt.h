/*
 *	$Id: ccitt.h,v 1.2 1995/05/10 11:04:37 jhsia Exp $
 *
 *	$Log: ccitt.h,v $
 * Revision 1.2  1995/05/10  11:04:37  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		ccitt.h

	Contains:	xxx put contents here xxx

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <4>	 7/15/94	DJ		made it work on server too
		 <3>	 7/14/94	ADS		Remove placeholder
		 <2>	 7/14/94	ADS		Managerize NetMisc, including crc stuff
		 <1>	 5/29/94	BET		first checked in

	To Do:
*/


#ifdef __SERVER__

unsigned long _ccitt_updcrc(unsigned int icrc, unsigned char *icp, int icnt);
#define ccitt_updcrc(icrc, icp, icnt)	_ccitt_updcrc(icrc, icp, icnt)

#else

#include "Dispatcher.h"

unsigned long ccitt_updcrc(unsigned int icrc, unsigned char *icp, int icnt) =
	CallDispatchedFunction (kccitt_updcrc);

#endif

