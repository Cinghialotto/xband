/*
 *	$Id: NetMisc.h,v 1.2 1995/05/10 11:04:06 jhsia Exp $
 *
 *	$Log: NetMisc.h,v $
 * Revision 1.2  1995/05/10  11:04:06  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		NetMisc.h

	Contains:	Misc GameTalk headers

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <7>	 7/15/94	DJ		made work non-managerized for server
		 <6>	 7/14/94	ADS		Removed placeholder
		 <5>	 7/14/94	ADS		Managerize NetMisc
		 <4>	  7/7/94	DJ		removed StartupNet
		 <3>	 6/28/94	BET		Add CheckError interface.
		 <2>	 6/18/94	BET		Add include of NetStructs.h
		 <1>	  6/1/94	BET		first checked in
	To Do:
*/

#ifndef __NetMisc__
#define __NetMisc__

#include "NetStructs.h"

#ifdef __SERVER__

short			_NetIdle( NetParamBlock *pBlock );
OSErr			_CheckError(void);

#define NetIdle(pBlock)	_NetIdle(pBlock)
#define CheckError()	_CheckError()


#else

short NetIdle( NetParamBlock *pBlock ) =
	CallDispatchedFunction (kNetIdleFunc);
	
OSErr CheckError(void) =
	CallDispatchedFunction (kCheckError);
	
	
// see also ccitt.h, it's call(s) are also managerized under "netmisc" manager
	
#endif // __SERVER__

#endif // __NetMisc__
