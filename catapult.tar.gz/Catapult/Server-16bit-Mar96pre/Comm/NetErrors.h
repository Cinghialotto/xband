/*
 *	$Id: NetErrors.h,v 1.2 1995/05/10 11:04:02 jhsia Exp $
 *
 *	$Log: NetErrors.h,v $
 * Revision 1.2  1995/05/10  11:04:02  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		NetErrors.h

	Contains:	xxx put contents here xxx

	Written by:	Brian Topping

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<17>	  8/9/94	HEC		Moved errors to errors.h
		<16>	  8/2/94	HEC		kConnectionEstablished
		<15>	 7/29/94	HEC		Added numbering comments
		<14>	 7/12/94	HEC		Added kCallWaitingErr, and kRemoteCallWaitingErr.
		<13>	  7/1/94	BET		Add PModem errors.
		<12>	 6/28/94	BET		Add kFwdResetFailed
		<11>	 6/21/94	HEC		Added kNoDialtone.
		<10>	 6/21/94	HEC		Added kNoAnswer.
		 <9>	 6/20/94	BET		Add kConnectBusy.
		 <8>	 6/20/94	BET		Add some async infastructure
		 <7>	 6/19/94	BET		Add some errors
		 <6>	 6/14/94	BET		Mo errors
		 <5>	 6/13/94	BET		Add an error for GameTalk
		 <4>	  6/5/94	BET		Add some errors
		 <3>	 5/31/94	BET		Add kLinkClosed
		 <2>	 5/26/94	BET		Move kAsyncInProg from obsoleted GameTalk.h
		 <1>	 5/22/94	BET		first checked in

	To Do:
*/



