/*
 *	$Id
 *
 *	$Log: GameTalkTest.c,v $
 * Revision 1.2  1995/05/10  11:11:20  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GameTalkTest.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <3>	  7/8/94	DJ		update to use protocol specificer
		 <2>	 6/28/94	DJ		first checked in
		 <1>	 6/28/94	DJ		first checked in

	To Do:
*/


#include <stdio.h>
#include "PhysicalLayer.h"
#include "errors.h"

void PlayJevansGame( Boolean master);


#define MASTER

main()
{
OSErr	err;

	PInit();

#ifdef MASTER

	if( (err = POpen("3661731", kUseServerProtocol)) == kNoError)
		PlayJevansGame(1);
	else
		printf("couldn't dial due to error #%ld\n", (long)err);

#else

	if((err = PListen(NULL, kUseServerProtocol)) == kNoError)
		PlayJevansGame(0);
	else
		printf("couldn't listen due to error #%ld\n", (long)err);

#endif

	PClose();
}


