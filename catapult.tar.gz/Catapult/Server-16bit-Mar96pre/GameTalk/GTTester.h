/*
 *	$Id
 *
 *	$Log: GTTester.h,v $
 * Revision 1.2  1995/05/10  11:11:18  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GTTester.h

	Contains:	xxx put contents here xxx

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	 7/22/94	SAH		first checked in

	To Do:
*/



#ifndef __GTTester__
#define __GTTester__

//
// Send and receive bytes to ram through two shared clients to verify the basic gametalk
// transport.
//
//#define	GT_RAMTEST		1
#define	USETIMEMGR		1
//#define	USERAMMODEMS	1


#ifndef __GT__
#include "GT.h"
#endif


#define	kModemBufferSize	200


typedef
struct RamModem
{
	struct GTSession *	session;
	struct RamModem *	line;
	unsigned char		transmit[ kModemBufferSize ];
	unsigned char *		transmitEnd;
	unsigned char *		writePtr;
	unsigned char *		readPtr;
	long				size;
	short				id;
	short				bytesAvail;
	unsigned char		nextByte;
	unsigned char		firstByte;
	unsigned char		lastByte;
} RamModem;

extern RamModem *	modem1;
extern RamModem *	modem2;


void DoGTTest ( void );
Err ModemWriteByte ( RamModem * modem, unsigned char byte );
Err ModemReadByte ( RamModem * modem, unsigned char * byte );

#endif
