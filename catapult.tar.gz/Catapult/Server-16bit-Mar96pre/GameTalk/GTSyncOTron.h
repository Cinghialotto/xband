/*
 *	$Id
 *
 *	$Log: GTSyncOTron.h,v $
 * Revision 1.2  1995/05/10  11:11:16  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GTSyncOTron.h

	Contains:	xxx put contents here xxx

	Written by:	Steve

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <6>	 8/28/94	SAH		Latest sinko.
		 <5>	 8/27/94	SAH		Beginning of sinko II.
		 <4>	 8/24/94	SAH		New interfaces.
		 <3>	 8/22/94	SAH		Latest poo.
		 <2>	 8/20/94	SGP		Fixed syntax bugs.
		 <1>	 8/15/94	SGP		first checked in

	To Do:
*/


#ifndef __GTSYNCOTRON__
#define __GTSYNCOTRON__

#ifndef __GT__
#include "GT.h"
#endif

#ifndef __Sprites__
#include "Sprites.h"
#endif

#define		syncoDiffMax		128
#define		syncoDiffUndefined	0x7fff

#define		waitFrames			10					/* wait these ticks until we draw inital graphics */

#define		nullData			0x00
#define		noData				0x03				// avoids start,A,B,or C tripping something off
#define		illegalTimeStamp	0x62				// rxThreeBytes needs this to be positive
#define		syncLock			0x8c				// b6-b4 = latency-1, b7,b3-b2 = 1 11, b1 = IT add, b0 = DE add
#define		syncMask			syncLock
#define		holdOff				0x0b
#define		byteThree			0x63

#define		RUThere				0x83				// Uses 0x83,93,A3,B3,C3,D3,E3,F3 from masks
#define		RUThereMask			0x8f				// Rejects all other values
#define		NotRUThere			((!RUThere)&0xff)	// Inverse of RUThere
#define		autoPlayMask		0x10
#define		autoPlayBit			0x4
#define		q1Mask				0x20
#define		q1Bit				0x5
#define		hiLiteMask			0x40
#define		hiLiteBit			0x6


#define		echoByte			0x7c				// 
#define		deferEarly1			0x01				// 0000 0001
#define		inTime1				0x02				// 0000 0010
#define		deferLate1			0x03				// 0000 0011
#define		deferEarly2			0x04				// 0000 0100
#define		inTime2				0x08				// 0000 1000
#define		deferLate2			0x0c				// 0000 1100


#define		syncsNeededInARow	0x04				// Sync's required in a row to deem serial reliable

#define		maxLatency	0x8							// longest latency we can handle (3 bits normalized 1-8)

#define		rxFifoSize	(maxLatency*2)				// last offset from rxFifo (must be even!)
#define		rxPipeSize	16							// last offset from rxPipe

#define		tipOffTime	0xf8						// number of frames from start of game till end of tip off
#define		syncJitter	0x3							// acceptable synchronization jitter
														// one bit is 1/2400 sec or 417 �sec.
														// each VCnt is 170.7 �sec, so there are
														// about 2.5 VCnts per bit. A sync jitter of 3
														// should be achievable. It also leaves room for 
														// the 1/2 line variation between interlaced and
														// non-interlaced frames (1/2 line = 32 �sec.
														// 32/171 = 0.19 Vcnts) and margin for
														// clock differential between the 2 machines. To be safe, make it 4.

#define		kMaxTargetDiff	24						/* max difference between us and our target to know we're not out of phase */
#define		vblVCnt			0x5c					// Vcnt @ Vbl entry
#define		readVCnt		0x60					// Vcnt at safe read time (can be as late as 0x5D (resync 0x5f) entering rxThreeBytes)
#define		deferEarlyVCnt	(readVCnt-0xa)			// defer early between this and readVCnt
#define		deferLateVCnt	(readVCnt+0xa-kMaxVCnt-1)	// defer late between readVCnt and this
#define		inTimeVCnt		(deferEarlyVCnt-0xa)	// in time between this and deferLateVCnt
#define		syncOTronMargin	(syncJitter+3)			// VCnt drift on each side before syncOTron kicks in

#define		holdOffDelay	(0x10)
#define		screenMapLow	(0x2f7bda0)				// screens 0x00-0x1f: 0010 1111 0111 1011 1101 1010 0000 0100
#define		screenMapHigh	(0x785a)				// screens 0x20-0x2f: 0111 1000 0101 1010

	
//	SyncOTron Variables
typedef
struct SyncState
{
	/* input parameters */
	GTSession *		gtSession;
	short			master;
	short			gameDelta;
	short			doGraphics;
	long			timeout;
	SyncoTronRef	ref;
	short			consecSyncs;
	short			maxJitter;
	short			maxTargetDiff;
	short			vdpRegState;
	
	/* returned results */
	short			frameDelay;				// number of frames of latency
	short			vCountDelay;			// the odd frame latency
	short			interlaceOffDrift;		// turn interlace mode off if vCount is before here
	short			interlaceOnDrift;		// turn interlace mode on if vCount drifts past here
	
	/* internal stuff */
	long			syncRate;				// the amount to move the graphics for each diff
	short			diff;
	short			lastDiff;
	long			endTime;
	long			minEndTime;
	short			receivedTime;
	short			interlaceOn;
	short			interlaceOff;
	short			targetVCount;
	
	long			reserved[ 10 ];			// just in case...
} SyncState;



// ErrorList codes

#define	lostSyncErr			0x1
#define	sequenceErr			0x2
#define	rxFifoOverFlowErr	0x3
#define	byteThreeError		0x4
#define unknownModeErr		0x5
#define	lastFrameReached	0x6
#define	exceptError			0x7
#define	rxSyncError			0x8
#define	echoTimeOutErr		0x9
#define	phaseTwoError		0xA
#define	rxPipeOverFlowErr	0xB
#define	latencyLookupError	0xC
#define	shiftError			0xD
#define	messageError		0xE
#define	rxOverrunError		0xF

// functions

Err 	GTSyncOTron_Synch ( SyncState * state ) = 
	CallDispatchedFunction( kGTSyncotron );


#endif

