/*
 *	$Id
 *
 *	$Log: GTSyncOTron.c,v $
 * Revision 1.2  1995/05/10  11:11:15  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GTSyncOTron.c

	Contains:	xxx put contents here xxx

	Written by:	Steve

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<13>	 8/29/94	SAH		Fucker Fucker.
		<12>	 8/29/94	SAH		Latency calculator works for master and slave. Synco proper
									still fucked.
		<11>	 8/29/94	SAH		Latency seems reasonable.
		<10>	 8/28/94	SAH		Latest sinko with fake header.
		 <9>	 8/27/94	SAH		Added a stupid sound and some other low level shit.
		 <8>	 8/27/94	KON		If defed the VBL stuff to be SIMULATOR only.
		 <7>	 8/27/94	SAH		First stab at new sinko.
		 <6>	 8/24/94	SAH		Dispatcherized many things.
		 <5>	 8/22/94	SAH		Spell simulator. Other stim bugs.
		 <4>	 8/22/94	SAH		Lameness for stimulator.
		 <3>	 8/22/94	SAH		Integratged with os.
		 <2>	 8/20/94	SGP		Added some more comments for Shannon
		 <1>	 8/15/94	SGP		first checked in

	To Do:
*/

//#define	SYNCO_DEBUG		1


#include "GT.h"
#include "harddefines.h"
#include "GTSyncOTron.h"
#include "GamePatch.h"
#include "SegaVDP.h"
#include "math.h"
#include "GamePatch.h"
#include "DispatcherControl.h"
#include "SegaSound.h"
#include "DBConstants.h"
#include "BoxSer.h"


Err		_GTSyncOTron_Synch ( SyncState * state );
Err		_MasterCalculateLatency ( SyncState * state );
Err		_SlaveCalculateLatency ( SyncState * state );
Err		_SyncronizeVBLs ( SyncState * state );
Err		_SyncronizeMasterLeave ( SyncState * state );
Err		_SyncronizeSlaveLeave ( SyncState * state );
void	_SyncoTronVBLHandler ( void );
void 	_SyncoReadModemVBL ( void );

/*
* Internal syncotron calls
*/
Err 	OSMasterCalculateLatency ( SyncState * state ) = 
	CallGameOSFunction( kOSGTMasterCalculateLatency );

Err 	OSSlaveCalculateLatency ( SyncState * state ) = 
	CallGameOSFunction( kOSGTSlaveCalculateLatency );

Err 	OSSyncronizeVBLs ( SyncState * state ) = 
	CallGameOSFunction( kOSGTSyncronizeVBLs );

Err 	OSSyncronizeMasterLeave ( SyncState * state ) = 
	CallGameOSFunction( kOSGTSyncronizeMasterLeave );

Err 	OSSyncronizeSlaveLeave ( SyncState * state ) = 
	CallGameOSFunction( kOSGTSyncronizeSlaveLeave );




#define	INTERLACE_MODE(s)		WriteVDPRegister( 12, (s)->interlaceOn )
#define	NON_INTERLACE_MODE(s)	WriteVDPRegister( 12, (s)->interlaceOff )

#define	kInterlaceMode			0x02			/* interlace on bit */




Err _GTSyncOTron_Synch ( SyncState * state )
{
Err		err;
long	saveVBL;

	/* this is the fake synco version in case we can't get the real one done */
	/* once we have it patched/going, we can hopefully set the vector to point */
	/* just below this */
#if 1
	state->endTime = gTicks + state->timeout;
	state->minEndTime = gTicks;
	
	/* init the syncotron graphics */
	if ( state->doGraphics )
		{
		state->diff = 255;
		state->lastDiff = 255;
		state->ref = SyncOTron ( state->ref, state->diff );

		// do the stinko sound and closing animation
		state->ref = SyncOTron ( state->ref, 0 );
		PlayDBFX ( kSinkoSinkedSnd, 0, 0 );
		
		/* hang out for this long (MAKE THIS A DBCONSTANT) */
		DBGetConstant ( kDefaultSyncOTronDelayConst, &state->minEndTime );
		state->minEndTime += gTicks;
		
		while ( gTicks < state->minEndTime )
			;

		state->ref = SyncOTron ( state->ref, -1 );
		}

	return noErr;
#endif

	/* save off our state for the vbl handler */
	(((SegaLowMem *) gBottomPermRam)->gameVectors.syncoParams) = (long) state;

	state->endTime = gTicks + state->timeout;
	state->minEndTime = gTicks;
	
	/* init the syncotron graphics */
	if ( state->doGraphics )
		{
		state->diff = 255;
		state->lastDiff = 255;
		state->ref = SyncOTron ( state->ref, state->diff );
		}
		
#ifdef SIMULATOR
	err = noErr;
#else
	// save the caller's vbl and install ours
	saveVBL = gVBLHandler;
	GetDispatchedFunction ( kGTSyncoReadModemVBL, 0L, (ProcPtr *) &gVBLHandler );

	state->frameDelay = 0;
	state->vCountDelay = 0;
	
	err = -1;
	
	/* keep trying to sync until we are successful or we time out */
	while ( err != noErr )
		{
		/* make sure we have a clean gametalk session */
		OSGTSession_FlushInput ( state->gtSession );
		err = OSGTSession_EstablishSynch ( state->gtSession, 0 );

		/* init the syncotron graphics */
		/* if we have to come through a second time due to errors this will reset */
		/* the graphics from the users perspective, making it appear as if a second */
		/* sync is happening */
		if ( state->doGraphics )
			{
			state->diff = 255;
			state->lastDiff = 255;
			state->ref = SyncOTron ( state->ref, state->diff );
			
			/* force the sync rate to be calculated when we start receiving data */
			state->syncRate = 0;
			}
		
		/* calculate latency between the two */
		if ( err == noErr )
			{
			if ( state->master )
				{
				err = OSMasterCalculateLatency ( state );
				}
			else
				{
				err = OSSlaveCalculateLatency ( state );
				}
			}
		
		/* bail if we've timed out */
		if ( err != noErr && gTicks > state->endTime )
			{
			err = kTimeout;
			break;
			}
		
		/* do the actual syncotron */
		if ( err == noErr )
			{
			err = OSSyncronizeVBLs ( state );
			}
		
		/* if we succeeded at that, do the final synch */
		if ( err == noErr )
			{
			/* first update the graphics and play the sound */
			if ( state->doGraphics )
				{
				state->ref = SyncOTron ( state->ref, 0 );
				PlayDBFX ( kSinkoSinkedSnd, 0, 0 );
				
				/* record the minimum frame count we can leave at so that the user */
				/* can hear the sound */
				DBGetConstant ( kDefaultSyncOTronDelay, &state->minEndTime );
				state->minEndTime += gTicks;
				}
				
				
			if ( state->master )
				{
				err = OSSyncronizeMasterLeave ( state );
				}
			else
				{
				err = OSSyncronizeSlaveLeave ( state );
				}
			}
			
		/* if we haven't timed out, and we got an error, then call checkline to see if it */
		/* can fix it */
		if ( err != noErr )
			{
			/* if checkline returns an error, then bail */
			err = OSCheckLine();
			if ( err != noErr )
				{
				goto bail;
				}
			
			/* we didn't synch properly, so force us to loop around again */
			err = -1;
			}
		}
#endif
		
	/* wait until our min timeout is done and then kill the graphics */
	if ( state->doGraphics )
		{
		/* only wait if we haven't encountered an error */
		if ( err == noErr )
			{
			while ( gTicks < state->minEndTime )
				;
			}
		
		/* make sure to put this screen up before we dispose... */
		state->ref = SyncOTron ( state->ref, 0 );
		state->ref = SyncOTron ( state->ref, -1 );
		}

bail:
	gVBLHandler = saveVBL;
	
	return err;
}


#define	kLatencyDoneBit		0x80
#define	kFrameDelayMask		0x7f
#define	kVCountMask			0x7f
#define	kMaxVCount			0x61
#define	kNumPackets			4


/*
*
* calculate latency by sending frame/vCount times at the other guy. keep sending until we receive
* something from them. once we do, then start echoing their packets. once we start getting our packets
* back, calculate a running latency. when we're done, compute the average latency.
*
* we divide down the base vCount clock by 2 (the serial vCount clock by 4) to get to a value that is
* within our tranmission space (we have 6 bits).
* 
*/
Err	_MasterCalculateLatency ( SyncState * state )
{
Err				err;
long			sendFrame;
long			receiveFrame;
short			vCount;
short			packetsToReceive;
unsigned char *	vCountPtr;
long			remote;
long			local;
long			arrival;
long			vCountDelay;
short			frameDelay;
	
	vCountPtr = (unsigned char *) gRegisterBase;
	vCountPtr += kReadMVSyncHigh + 1;
	
	vCountDelay = 0;
	
	err = noErr;
	packetsToReceive = kNumPackets;
			
	while ( packetsToReceive-- > 0 && err == noErr )
		{
		/* send the packet - we now expect one back */
		/* get our current vCount (high 7 bits) */
		vCount = *vCountPtr;
		while ( vCount != *vCountPtr )
			vCount = *vCountPtr;
		
		if ( vCount > kMaxVCount )
			{
			vCount -= kMaxVCount;
			}
					
		sendFrame = gTicks;
			
		OSGTSession_SendController( state->gtSession, 0 );
		
		/* allow us to get into this loop... */
		err = kNoData;
		
		/* wait for the packet to come back */
		while ( err == kNoData )
			{
			err = OSGTSession_ReadController ( state->gtSession, &local, &remote );
			receiveFrame = gTicks;
			
			if ( err >= 0 )
				{
				/* we got a return packet */
				arrival = err;
				
				err = noErr;
				
				/* process the packet data */
				/* is it a done latency packet (shouldn't get one here....) */
				
				/* if it's one of our packets, then compute latency */
				if ( remote & kLatencyDoneBit )
					{				
					/* error - how did we get one of these when we didn't send one? */
					/* pop back up to the main level and start over */
					err = kFucked;
					}
				else
					{
					/* it's a response packet, figure out it's round trip latency */
					/* get the packet arrival time... */
					frameDelay = receiveFrame - sendFrame;
					
					/* divide down the serial vCount by two to get to our resolution */
					arrival = ( arrival & 0xff ) >> 1;
					arrival += frameDelay * kMaxVCount;
					
					/* subtract the send vCount time */
					arrival -= vCount;	
					vCountDelay += arrival;
					}
				}
			
			/* bail if we've timed out */
			if ( err != noErr && gTicks > state->endTime )
				{
				err = kTimeout;
				break;
				}
			}
		}
	
	/* now compute the overall latency from our vCountDelay and frameDelay */
	if ( err == noErr )
		{
		/* divide by two for one way time */
		vCountDelay >>= 1;
		
		/* divide by the total number of packets for our average */
		vCountDelay = vCountDelay / kNumPackets;
		
		/* and then extract the frame and vCount delay */
		state->frameDelay = vCountDelay  / kMaxVCount;
		state->vCountDelay = vCountDelay % kMaxVCount;

		/* record our target vCount to solve phasing problems in the real sync */
		state->targetVCount = state->vCountDelay;
	
		/* now send them a frame delay and the target vCount */
		OSGTSession_SendController ( state->gtSession, state->frameDelay | kLatencyDoneBit );
		OSGTSession_SendController ( state->gtSession, state->targetVCount );
	
		remote = 0;
		
		/* then wait for their return kLatencyDone packet */
		while ( !( remote & kLatencyDoneBit)  && ( err == noErr || err == kNoData ) )
			{
			err = OSGTSession_ReadController ( state->gtSession, &local, &remote );
			if ( err >= 0 )
				{
				err = noErr;
				
				/* make sure it's a latency done, if not, we're fucked */
				if ( !( remote & kLatencyDoneBit ) )
					{
					err = kFucked;
					}
				}
	
			/* bail if we've timed out */
			if ( err != noErr && gTicks > state->endTime )
				{
				err = kTimeout;
				}
			}
		}
	
	return err;
}


/*
*	Spin on ReadController until we get a kLatencyDone packet. Any other packets we get we just
*	immediately send them back to the master. the latency done packet will contain the frame delay
*	and will be followed by the odd vCount delay.
*/
Err	_SlaveCalculateLatency ( SyncState * state )
{
Err				err;
long			remote;
long			local;

	err = kNoData;
	
	/* spin returning any packets until we get a latency done packet */
	while ( true )
		{
		err = OSGTSession_ReadController ( state->gtSession, &local, &remote );
		
		if ( err >= 0 )
			{
			err = noErr;
			
			if ( remote & kLatencyDoneBit )
				{
				/* got our ending packet, grab the frame delay and then go read the vCount delay */
				state->frameDelay = remote & kFrameDelayMask;
				break;
				}
			
			/* not a done packet, so return it */
			OSGTSession_SendController ( state->gtSession, remote );
			}
		else
		if ( err != kNoData )
			{
			/* bail immediately */
			return err;
			}
		
		/* bail if we've timed out */
		if ( err != noErr && gTicks > state->endTime )
			{
			return kTimeout;
			}
		}
	
	/* if we got here with no error, then we know to expect the vCount latency packet */
	/* we won't get here with a kNoData */
	while ( err == noErr || err == kNoData )
		{
		err = OSGTSession_ReadController ( state->gtSession, &local, &remote );
		
		/* if we got a packet, then grab the vCount delay */
		if ( err >= 0 )
			{
			err = noErr;
			state->vCountDelay = remote;
			state->targetVCount = remote;

			/* send them a done packet */
			OSGTSession_SendController ( state->gtSession, kLatencyDoneBit );
			break;
			}
		
		/* bail if we've timed out - if we have something other than kNoData, then return that */
		if ( err == kNoData && gTicks > state->endTime )
			{
			err = kTimeout;
			}
		}
		
	return err;
}


#define	kInterlaceBit		0x80
#define	kInvalidVCount		0x66
#define	kDoneSynco			0x65
#define	kMaxSyncVCount		0x61
#define	kVBLVCountMask		0x7f
#define	kConsecutiveSyncs	5
#define	kMaxTargetDiff		24

/*
*	The stinko workhorse: actually syncronize the two vbl's.
*/
Err	_SyncronizeVBLs ( SyncState * state )
{
long	saveVBL;
Err		err;
long	local;
long	remote;
short	consecSinks;
long	arrival;
long	diff;
short	targetDiff;
long	targetDist;
Boolean	remoteInInterlace;
	
	/* haven't received anything yet */
	state->receivedTime = kInvalidVCount;
	
	state->interlaceOn = state->vdpRegState | kInterlaceMode;
	state->interlaceOff = state->vdpRegState & ~kInterlaceMode;
	
	state->maxTargetDiff = kMaxTargetDiff;
	
	saveVBL = gVBLHandler;
	GetDispatchedFunction ( kGTSyncoTronVBLHandler, 0L, (ProcPtr *) &gVBLHandler );
	
	/* sync until our difference has been within tolerence for the required number of frames */
	/* and we have encountered no error */
	consecSinks = 0;
	err = noErr;
	
	while ( consecSinks < state->consecSyncs && ( err == noErr || err == kNoData ) )
		{
		err = OSGTSession_ReadController ( state->gtSession, &local, &remote );
		if ( err >= 0 )
			{
			/* we got ourselves a packet */
			arrival = ( err & kVBLVCountMask ) >> 1;
			err = noErr;

			/* is the remote guy in interlace mode? */
			remoteInInterlace = remote & kInterlaceBit != 0;
			
			/* be sure to clear it */
			remote &= ~kInterlaceBit;

			/* did we get a done packet? */
			if ( remote == kDoneSynco )
				{
				/* send one in response and go home */
				/* the other guy got consecSinks before we did due to jitter */
				OSGTSession_SendController ( state->gtSession, kDoneSynco );
				goto bail;
				}
			
			/* record our arrival time */
			state->receivedTime = arrival;

			/* did we get a init packet? */
			if ( remote == kInvalidVCount )
				{
				/* loop again, waiting for some real data */
				continue;
				}
			
			/* how far are we from our target? (and in which direction do we want to go?) */
			targetDiff = state->targetVCount - arrival;
			targetDist = targetDiff;
			if ( targetDist < 0 )
				{
				targetDist = -targetDist;
				}
				
			/* get the difference between our arrival time and the remote's */
			remote &= kVBLVCountMask;
			if ( remote > kMaxSyncVCount )
				{
				remote -= kMaxSyncVCount;
				}
				
			diff = arrival - remote;
			if ( diff < 0 )
				{
				diff = -diff;
				}
			
			state->diff = diff;
			
			/* if we haven't adjusted our sync rate for the graphics yet, do it now */
			if ( state->doGraphics && state->syncRate == 0 )
				{
				/* put the first sync difference at 100	*/
				state->syncRate = targetDist / 100;
				}
				
			/* if we're within tolerence of our peer and we're within tolerence of our target, then */
			/* record this as a success */
			if ( diff <= state->maxJitter && targetDist <= state->maxTargetDiff )
				{
				/* we're within tolerance, don't adjust (or stop interlace mode if we were */
				/* adjusting */
				NON_INTERLACE_MODE(state);
				state->receivedTime &= ~kInterlaceBit;
				++consecSinks;
				}
			else
				{
				/* we weren't in synch. decide which way to drift, if to drift at all */
				/* if their arrival time is greater than ours, then we know that we're ahead */
				/* of them, so we go into interlace mode to compensate */
				
				/* if we're within targetSync of the target, then just look at the difference */
				/* between us and remote */
				if ( targetDist <= state->maxTargetDiff )
					{
					remote -= arrival;
					}
				else
					{
					remote = targetDiff;
					}
				
				/* don't go into interlace if the other guy already is */
				if ( remote > 0 && !remoteInInterlace )
					{
					INTERLACE_MODE(state);
					state->receivedTime |= kInterlaceBit;
					}
				else
					{
					NON_INTERLACE_MODE(state);
					state->receivedTime &= ~kInterlaceBit;
					}
				
				/* start over with our consecutive sync count */
				consecSinks = 0;
				}
			}
		
		/* bail if we've timed out */
		if ( consecSinks < state->consecSyncs && gTicks > state->endTime )
			{
			err = kTimeout;
			break;
			}
		
		/* run the graphic display if the caller requested one */
		if ( state->doGraphics )
			{
			/* if we've moved closer together, update the graphic */
			if ( state->diff < state->lastDiff )
				{
				diff = state->diff;
				
				/* multiply this with our rate multiplier to get a smooth sync */
				diff *= state->syncRate;
				diff >>= 16;
				
				/* don't do a difference of zero until we're out of the synco loop */
				if ( diff <= 0 )
					{
					diff = 1;
					}
					
				state->ref = SyncOTron ( state->ref, diff );
				}
			}
		}
	
	/* if we bailed because of a successful sync, send our done packet and wait for theirs */
	if ( err == noErr )
		{
		OSGTSession_SendController ( state->gtSession, kDoneSynco );
	
		err = kNoData;
		while ( err == kNoData )
			{
			err = OSGTSession_ReadController ( state->gtSession, &local, &remote );
			if ( err >= 0 )
				{
				if ( remote == kDoneSynco )
					{
					err = noErr;
					}
				else
					{
					/* bail on this one */
					err = kNoData;
					}
				}
		
			/* bail if we've timed out */
			if ( err != noErr && gTicks > state->endTime )
				{
				err = kTimeout;
				break;
				}
			}
		}

bail:
	gVBLHandler = saveVBL;

	/* make sure we didn't fuck up */
	NON_INTERLACE_MODE(state);

	return err;
}


/*
*	Now go off and syncronize the master to the slave
*/
Err	_SyncronizeMasterLeave ( SyncState * state )
{
	return noErr;
}


/*
*	Now go off and syncronize the slave to the master
*/
Err	_SyncronizeSlaveLeave ( SyncState * state )
{
	return noErr;
}


/*
*	We use this guy to send our sync packets.
*/
void _SyncoTronVBLHandler ( void )
{
#ifndef SIMULATOR
	asm
		{
		movem.l	d0-d2/a0-a1,-(sp)
	
		move.l	GameGlobal(syncoParams),a0
	
	// param for ReadModem
		move.l	SyncState.gtSession,-(sp)

		moveq	#0,d0
		move.l	SyncState.receivedTime(a0),d0
		move.l	d0,-(sp)
		move.l	SyncState.gtSession(a0),-(sp)
		OSGTSession_SendController
		addq.l	#8,sp
	
		OSGTSession_ReadHardwareModem
		addq.l	#4,sp
		
		addq.l	#1,gTicks
		
		movem.l	(sp)+,d0-d2/a0-a1
		rte
		}
#endif
}


/*
* Use this one to read the modem in the latency calculator
*/
void _SyncoReadModemVBL ( void )
{
#ifndef SIMULATOR
	asm
		{
		movem.l	d0-d2/a0-a1,-(sp)
	
		move.l	GameGlobal(syncoParams),a0
		
		move.l	SyncState.gtSession(a0),-(sp)
		OSGTSession_ReadHardwareModem
		addq.l	#4,sp
		
		addq.l	#1,gTicks
		
		movem.l	(sp)+,d0-d2/a0-a1
		rte
		}
#endif
}

