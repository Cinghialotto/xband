/*
 *	$Id
 *
 *	$Log: GT.h,v $
 * Revision 1.2  1995/05/10  11:11:00  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GT.h

	Contains:	xxx put contents here xxx

	Written by:	Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<22>	 8/29/94	ATM		Added #ifndef __SERVER__ stuff to make it build under UNIX.
		<21>	 8/27/94	SAH		Bumped size of gametalk fifos.
		<20>	 8/24/94	SAH		New interfaces. Moved Stinko to GTStinkOTron.h. New packet
									formats.
		<19>	 8/22/94	SAH		Added all the packet formats.
		<18>	 8/22/94	SAH		More stink.
		<17>	 8/22/94	SAH		Added GTSyncOTron_GraphicSynch.
		<16>	 8/21/94	ADS		New lomem layout
		<15>	 8/18/94	SAH		Took out k16bitData for a while.
		<14>	 8/15/94	SGP		Added constant for 16 bit data
		<13>	 8/10/94	HEC		Added eqmThreshold session field.
		<12>	  8/8/94	SAH		Keep track of bad packets.
		<11>	 7/26/94	SAH		Added GTSession_CloseSessionSynch.
		<10>	 7/24/94	SAH		New functions. Cleaned up.
		 <9>	 7/22/94	SAH		New interfaces.
		 <8>	  7/8/94	DJ		Added ReadBytes and FlushInput
		 <7>	  7/3/94	SAH		Did the <> thing around the Types.h include to speed up
									compiles.
		 <6>	 6/28/94	DJ		GetCurrentTime shit
		 <5>	 6/21/94	BET		We think we integrate, but then we learn.
		 <4>	 6/21/94	HEC		Compiling is good
		 <3>	 6/21/94	BET		Need these too...
		 <2>	 6/21/94	BET		Managerize
		 <1>	 6/20/94	DJ		first checked in

	To Do:
*/



#ifndef __GT__
#define __GT__

#if defined(SIMULATOR) || defined(__SERVER__)

# ifdef GT_RAMTEST
#  ifdef USETIMEMGR
#   define NETWORKUSEINTERRUPTS
#  endif
# else
#  define NETWORKUSEINTERRUPTS
# endif

#endif

#ifndef __SERVER__
#include <asm.h>
#include <Types.h>
#include "GTErrors.h"
#include "GTNetwork.h"
#include "GTModem.h"

#ifndef __SegaOS__
#include "SegaOS.h"
#endif
#endif	/*__SERVER__*/


//
// Some packet formats
//
enum
{
	k8BitData,		// 16 bit packets
	k12BitData,		// 16 bit packets
	k16BitData,		// 24 bit packets
	k19BitData,		// 24 bit packets
	k24BitData,		// 32 bit packets
	k27BitData		// 32 bit packets
};


#ifdef __SERVER__

#ifdef THINK_C
#define GetCurrentTime() TickCount()
#endif

void WaitForVBL(void);

#endif __SERVER__

	// BRAIN DAMAGE: because of our fifo masking, make sure this is always a power of two
#define kMaxFrameLatency	16		// This is the maximum one way latency (in frames (vbls))
									// that our software can handle.

#define	kMaxFifoSize		(kMaxFrameLatency*2)		// size of fifo to accomodate max frame latency (size in longs)
#define	k1ByteFifoIndexMask	(kMaxFifoSize - 1)			// mask for 1 byte fifo's - assumes power of two
#define	k2ByteFifoIndexMask	(k1ByteFifoIndexMask << 1)	// mask for 2 byte fifo's - assumes power of two
#define	k4ByteFifoIndexMask	(k1ByteFifoIndexMask << 2)	// mask for 4 byte fifo's - assumes power of two

#define	kTimeStampMask		0x7f	// we send 7bits of frame data in our resend command
									// therefore we keep 7 bits of frame data in our local
									// time stamps

#ifndef __SERVER__
typedef struct GTSession
{
	struct GTModem modem;

	short 			frameDelay;			// frame delay we're working with
	short			byteLatency;		// one way latency for single byte
	short			roundtripLatency;	// how long for modem round trip

	short			packetFormat;		// packet format for this gt session
	short			bytesInPacket;		// how many bytes in a packet for this format
	short			bitSize;			// size of the packet data in bits
	long			packetMask;			// mask for packet data only
	
	unsigned long	sendFifo[ kMaxFifoSize ];	// send/local fifo
	short			localIndex;			// index where we're reading local controllers from
	short			remoteIndex;		// index where we're sending remote controllers from
	short			writeIndex;			// index where we're putting new local controller reads

	short			sendTimeStamp;		// timestamp for last packet sent
	short			recvTimeStamp;		// timestamp of last packet received.
	
	long			eqmThreshold;		// take action above this noise threshold 
	
	// some default timeouts
	long			defaultEstSynchTimeout;
	long			defaultSynchStateTimeout;
	long			defaultExgCommandsTimeout;
	long			defaultErrorRecoverTimeout;
	
	// some debugging stuff
	long			badPackets;
	
	// no one needs this yet as far as i know, but i'll leave it here as it's small
	// and convenient
	Boolean			master;

} GTSession;
#endif /*__SERVER__*/


/*

Sega controller:
	pad is 4 bits, where the first bit indicates controller up, and the following 3 bits
	indicate which of the 8 directions is pressed (only a single direction can be pressed).
	
	normal buttons are 4 bits: three controller buttons (a,b,c) and a start button.
	extended buttons are 3bits: three extended buttons (x, y, z).

	In the worst case we send 12 bits per controller, although NBA Jam uses only 9 bits
		(no extended buttons).
	
	Two player games then can require 24 bits, and 2 player Jams requires 18 bits.
	
	
Packet Descriptions:

	12 bit data		0-3 pad, 4 start, 5-7 acb, 8-11 free
	16 bit packet:	0-3 checksum 4-11 data

	19 bit data:	0-3 pad. 4 start 5-7 abc 8-10 xyz
	24 bit packet:	0-3 checksum 4-14 data

	26 bit data:	8 bit data1, 8 bit data2
	32 bit packet:	0-4 checksum 5-12 data1 13-20 data2
*/


#define kSingleTripTime		2	// 2 vbls latency
#define kRoundTripTime		2*kSingleTripTime
#define kRoundTripTimeOut	2*kRoundTripTime

#define kStreamResumeControl	0x1



//
// Some control packet formats
#define	kReceivedToPacket		0x80			// high bit + frame number
#define	kQuitCommand			0x01


// macro to test for a given command
#define	ISCOMMAND(x,c)			(( (x) & (c) ) == (c))
#define	GETCOMMANDDATA(x,c)		((x) & ~(c))


#ifndef __SERVER__
/////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////  P R O T O T Y P E S /////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////

#define	CallThroughVector( address )	{ 0x2078, address, 0x4e90 }


void	GTSession_Init(GTSession *session, Boolean master) =
	CallDispatchedFunction( kGTSInit );

void	GTSession_Shutdown(GTSession *session) =
	CallDispatchedFunction( kGTSShutdown );

Err		GTSession_SetGTPacketFormat ( GTSession * session, short packetFormat ) = 
	CallDispatchedFunction( kGTSSetPacketFormat );

Err		GTSession_SetRamRomOffsets ( GTSession * session, long ramOffset, long romOffset ) = 
	CallDispatchedFunction( kGTSSetRamRomOffset );

Err 	GTSession_SetLatency ( GTSession * session, short frameLatency ) = 
	CallDispatchedFunction( kGTSessionSetLatency );

Err		GTSession_PrefillFifo ( GTSession * session, unsigned long fillData ) = 
	CallDispatchedFunction( kGTSessionPrefillFifo );

Err		GTSession_EstablishSynch ( GTSession * session, long timeout ) = 
	CallDispatchedFunction( kGTSessionEstablishSynch );

Err		GTSession_ExchangeCommands ( GTSession * session, unsigned char send, unsigned char * receive, long timeout ) = 
	CallDispatchedFunction( kGTSessionExchangeCommands );
	
long 	GTSession_ReadController ( GTSession * session, long *localData, long * remoteData ) = 
	CallThroughVector ( OFFSET(SegaLowMem,gameVectors.gtReadController) );

Err 	GTSession_SendController ( GTSession * session, long data ) = 
	CallThroughVector ( OFFSET(SegaLowMem,gameVectors.gtSendController) );

#ifdef SIMULATOR
#define	GTSession_ReadHardwareModem(s)	(noErr)
#else
Err 	GTSession_ReadHardwareModem ( GTSession * session ) = 
	CallThroughVector ( OFFSET(SegaLowMem,gameVectors.gtReadModem) );
#endif

Err		GTSession_ErrorRecover ( GTSession * session, Err error, long timeout ) = 
	CallDispatchedFunction( kGTSErrorRecover );

Err		GTSession_CloseSessionSynch ( GTSession * session, long timeout ) = 
	CallDispatchedFunction( kGTSCloseSessionSynch );

Err 	GTSession_FlushInput(GTSession *session) = 
	CallDispatchedFunction( kGTSFlushInput );

#endif /*__SERVER__*/

#endif __GT__


