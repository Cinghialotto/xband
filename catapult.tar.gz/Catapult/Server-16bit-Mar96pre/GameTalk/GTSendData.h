/*
 *	$Id
 *
 *	$Log: GTSendData.h,v $
 * Revision 1.2  1995/05/10  11:11:11  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GTSendData.h

	Contains:	xxx put contents here xxx

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <3>	  8/7/94	HEC		Added 'err' field to LooseSession.
		 <2>	  8/3/94	SAH		Loose session stuff.
		 <1>	  8/2/94	SAH		first checked in

	To Do:
*/



#ifndef __GTSendData__
#define	__GTSendData__

#ifndef __GT__
#include "GT.h"
#endif

/*
*	Private stuff
*/

typedef
struct GTSendReceiveState
{
	GTSession *		session;
	long			packetsToSend;
	unsigned char *	sendBuf;
	long			sendLength;
	unsigned char *	recvBuf;
	long			recvLength;
} GTSendReceiveState;

Err		_GTSendReceiveBytes ( GTSendReceiveState * state, Boolean establshSynch );
Err		_GTCloseSessionSafe ( GTSession * session, long timeout );

typedef
struct LooseSession
{
	long		expectNextPacket;
	long		sendNextTickle;
	long		timeBetweenReads;
	long		timeBetweenWrites;
	long		controlPacketMask;
	GTSession *	session;
	short		err;
} LooseSession;

Err		_GTCreateLooseSession ( GTSession * session, LooseSession ** lsession );
Err		_GTLooseSessionIdle ( LooseSession * lsession, long *inData, long *outData );
Err		_GTCloseLooseSession ( LooseSession * lsession );



/*
*	Public stuff
*/


Err		GTSendReceiveBytes ( GTSendReceiveState * state, Boolean establshSynch ) = 
	CallDispatchedFunction( kGTSendReceiveBytes );

Err		GTCloseSessionSafe ( GTSession * session, long timeout ) = 
	CallDispatchedFunction( kGTCloseSessionSafe );



Err		GTCreateLooseSession ( GTSession * session, LooseSession ** lsession ) = 
	CallDispatchedFunction( kGTCreateLooseSession );

Err		GTLooseSessionIdle ( LooseSession * lsession, long *inData, long *outData ) = 
	CallDispatchedFunction( kGTLooseSessionIdle );

Err		GTCloseLooseSession ( LooseSession * lsession ) = 
	CallDispatchedFunction( kGTCloseLooseSession );


#endif
