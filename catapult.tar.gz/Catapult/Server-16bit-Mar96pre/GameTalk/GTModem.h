/*
 *	$Id
 *
 *	$Log: GTModem.h,v $
 * Revision 1.2  1995/05/10  11:11:06  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GTModem.h

	Contains:	xxx put contents here xxx

	Written by:	Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <4>	 8/24/94	SAH		Turned the Pad into a currentFrame counter (Perlman). Added some
									fifo masks.
		 <3>	 7/24/94	SAH		Cleaned up, added new protos.
		 <2>	 7/22/94	SAH		New modem stuff.
		 <1>	 6/20/94	DJ		first checked in

	To Do:
*/



#ifndef __GTMODEM__
#define __GTMODEM__

#include "GTNetwork.h"
#include "GTErrors.h"

// #define GTMODEMDEBUG

#ifdef GTMODEMDEBUG
#include <stdio.h>
#endif


//
// The modem has a 32 byte buffer (eg. 8 frames).
//
#define kModemInBufferLength	32
#define kModemOutBufferLength	16

//
// These masks are multiplied by four to preshift the array lookups
//
#define	kModemInBufferMask		((kModemInBufferLength<<2) - 1)	
#define	kModemOutBufferMask		((kModemOutBufferLength<<2) - 1)	
#define	kModemInBufferMask		((kModemInBufferLength<<2) - 1)	

//
// Because you can only read fred's current frame number when the 
//	rx fifo is empty, most data arrives without us being able to
//	determine the current frame number
//

#define	kUnknownCurrentFrame	0x0f

typedef
struct GTModemByte {
	unsigned char	byte;
	unsigned char	roskoFrame;
	unsigned char	currentFrame;
	unsigned char	vCount;
} GTModemByte;

typedef
struct GTModem {
	GTModemByte		inBuffer[kModemInBufferLength];
	short			readIndex;
	short			writeIndex;
	short			byteCount;
	
	Err				modemErr;

	struct GTNetwork	network;
	Boolean			master;
} GTModem;


/* direct modem calls - only gametalk is allowed to call these in some cases */
void	_GTModem_Init( GTModem *modem, Boolean master);
Err		_GTModem_GetModemError(	GTModem * modem );
void	_GTModem_ClearFifo ( GTModem *modem );
void	_GTModem_ClockInByte( GTModem *modem, unsigned char byte, unsigned char frame, unsigned char vCount, unsigned char currentFrame );
Err		_GTModem_ClockOutByte ( GTModem * modem, GTModemByte * byte );
Boolean _GTModem_AbleToSend( GTModem *modem);
Err		_GTModem_SendBytes( GTModem *modem, short numBytes, unsigned char *bytes);
Err		_GTModem_CheckLine ( GTModem * modem );

// this call is only used on the sega
Err		_GTModem_ReadModem ( struct GTSession * session );


/* the public/dispatched versions of these are in GameTalkPriv.h */


//
// There are 60 VBLs per second.
// There are 5 network byte ticks per vbl = 300 per second.
// kNumDataTicksPerVBL = 4 (plus the 1 tick for start bits).
//
// Roskow's chip gives us the vbl (well, the lower 2 bits of it!)
// and an 8 bit fractional time which is 1/256th of a vbl = 256 * 60 = 15360 fracticks/ sec


#define ConvertNetworkTicksToVBL(networkByteTicks) 	((networkByteTicks) / 5)
#define ConvertNetworkTicksToFracTicks(networkByteTicks)	(((networkByteTicks) % 5) * 51) 

#endif __GTMODEM__

