/*
 *	$Id
 *
 *	$Log: GTErrors.h,v $
 * Revision 1.2  1995/05/10  11:11:04  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GTErrors.h

	Contains:	xxx put contents here xxx

	Written by:	Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <7>	  8/9/94	HEC		Moved errors to errors.h
		 <6>	  8/5/94	SAH		Killed some bogus errors.
		 <5>	  8/3/94	SAH		Added kBadPacketData.
		 <4>	 7/24/94	SAH		Changed.
		 <3>	 7/22/94	SAH		Changed.
		 <2>	 6/21/94	HEC		Compile in new world
		 <1>	 6/20/94	DJ		first checked in

	To Do:
*/


#ifndef __GTERRORS__
#define __GTERRORS__

#ifndef __Errors__
#include "Errors.h"
#endif

#endif __GTERRORS__

