/*
 *	$Id
 *
 *	$Log: GTSendData.c,v $
 * Revision 1.2  1995/05/10  11:11:10  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GTSendData.c

	Contains:	xxx put contents here xxx

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<19>	 9/18/94	ADS		1.0 bugs:  Restore VBL.  Allow longer P-P latency.
		<18>	 8/27/94	SAH		Fucker. Fucker. Fucker.
		<17>	 8/27/94	SAH		Fuck. Only set packet format and latency the first time through
									(really helps error recovery if the fifo's aren't reset halfway
									through!).
		<16>	 8/27/94	SAH		Use all default timeouts.
		<15>	 8/24/94	SAH		New packet formats. Use some default timeouts. Call ErrorRecover
									in SendReceiveData when we reenter after an error!
		<14>	 8/23/94	HEC		Turn on more efficient DOTHREEBYTES and set BYTESINPACKET to 3.
		<13>	 8/10/94	SAH		Call CheckLine during the loose animation.
		<12>	  8/8/94	SAH		Fixed some closing problems with loose sessions. Use gTicks
									rather than GetCurrentTime.
		<11>	  8/8/94	SAH		Fixed a tub o bugs.
		<10>	  8/7/94	HEC		Check lsession->err in CloseLooseSession
		 <9>	  8/5/94	SAH		Install the gametalk vbl during send receive bytes.
		 <8>	  8/4/94	SAH		Read the modem some on the sega.
		 <7>	  8/4/94	HEC		(SAH) Fixed byte order stuff.
		 <6>	  8/3/94	SAH		Added looseness.
		 <5>	  8/2/94	SAH		Latest and greatest.
		 <4>	  8/2/94	HEC		Fix some bugs.
		 <3>	  8/2/94	SAH		Fuck.
		 <2>	  8/2/94	SAH		Code review.
		 <1>	  8/2/94	SAH		first checked in

	To Do:
*/



#include "SegaOS.h"
#include "GT.h"
#include "GTSendData.h"
#include "NetErrors.h"
#include "heaps.h"
#include "DBConstants.h"
#include "BoxSer.h"
#include "Time.h"
#include "GamePatch.h"
#include "Exceptions.h"
#include "PhysicalLayer.h"


#define	BYTESINPACKET		3
#define DOTHREEBYTES		1


Err		_GTSendReceiveBytes ( GTSendReceiveState * state, Boolean establshSynch );


/*
*	Send a receive bytes. We assume that we have a initialized session record
*	and a clean line (ie the caller has done an establish synch). The first time
*	through, packetsToSend should be set to zero.
*/
Err	_GTSendReceiveBytes ( GTSendReceiveState * state, Boolean establshSynch )
{
long			packetsToSend;
Err				err;
unsigned long	packetData;
long			local;
long			remote;
unsigned char * send;
unsigned char * recv;
long			ticks;
long			saveVBL;
long			saveGTSession;
short			noDatas;
Boolean			forceRecover;
Boolean			linkClosed;
Boolean			skipSend;

	/* are we already done? */
	if ( state->packetsToSend < 0 )
		{
		return noErr;
		}
	
	forceRecover = false;
	
	/* are we being called for the first time? if so, we need to calculate how */
	/* many packets to send. this is based on the larger of the send or receive */
	/* byte lengths */
	if ( state->packetsToSend == 0 )
		{
		/* we send two bytes per packet for now */
#ifdef DOTHREEBYTES
		GTSession_SetGTPacketFormat ( state->session, k27BitData );
#else
		GTSession_SetGTPacketFormat ( state->session, k16BitData );
#endif
	
		/* bump up latency really high so we have lots of resend room */
		GTSession_SetLatency ( state->session, kMaxFrameLatency );

		GTSession_FlushInput ( state->session );
		
#ifdef DOTHREEBYTES
		packetsToSend = state->sendLength;
		if ( state->recvLength > state->sendLength )
			{
			packetsToSend = state->recvLength;
			}
		
		packetsToSend = ( packetsToSend + 2 ) / 3;
#else
		packetsToSend = state->sendLength;
		if ( state->recvLength > state->sendLength )
			{
			packetsToSend = state->recvLength;
			}
		
		packetsToSend = ( packetsToSend + 1 ) >> 1;
#endif	
		/* get a zero based count */
		state->packetsToSend = packetsToSend - 1;

		/* add in twice our latency to make sure that all the packets we care about */
		/* really get there -- this is slow, but safe! */
		state->packetsToSend += 2 * kMaxFrameLatency + 1;
		}
	else
		{
		/* we're reentering after an exit in mid-data transmission. as we exited due to */
		/* an error, we need to do an error recover here */
		forceRecover = true;
		}

	/* now that we know we're going for real, install our magic vbl handler that */
	/* reads the modem for us so that we can be sure to not miss any bytes */
	saveVBL = gVBLHandler;
	saveGTSession = gVBLGTSession;
	
	gVBLGTSession = (long) state->session;
	gVBLHandler = (long) GameTalkVBL;

	/* do we need to establish synch? */
	if ( establshSynch )
		{
		err = GTSession_EstablishSynch ( state->session, 0 );
	
		/* bail if we couldn't find them */
		if ( err != noErr )
			{
			goto bail;
			}
		}
	
	/* if we need to recover, do it now */
	if ( forceRecover )
		{
		err = GTSession_ErrorRecover ( state->session, kNoData, 0 );
		if ( err != noErr )
			{
			goto bail;					// <19> 1.0 BUG
			}
		}
		
	/* finally, actually transfer the data */
	err = noErr;
	forceRecover = false;
	linkClosed = false;
	noDatas = 0;
	packetsToSend = state->packetsToSend;
	send = state->sendBuf;
	recv = state->recvBuf;
	
	while ( err == noErr && !linkClosed && ( packetsToSend >= 0 || state->recvLength > 0 ) )
		{
		skipSend = false;
		
		/* read a packet */
		err = GTSession_ReadController ( state->session, &local, &remote );
		if ( err > 0 )
			{
			err = noErr;
			}
			
		switch ( err )
			{
			case noErr:
				if ( state->recvLength > 0 )
					{
					switch  ( state->recvLength )
						{
						default:
#ifdef DOTHREEBYTES
						case 3:
							*recv++ = remote >> 16;
#endif
						case 2:
							*recv++ = remote >> 8;
						case 1:
							*recv++ = remote;
						case 0:
							break;
						}
						
					state->recvLength -= BYTESINPACKET;
					}
				noDatas = 0;
				break;
			
			case kNoData:
				if ( ++noDatas == 20 )			// <19> 1.0 BUG
					{
					forceRecover = true;
					}
				else
					{
					err = noErr;
					}
				break;
				
			default:
				forceRecover = true;
				break;
			}
		
		/* do we want to recover? */
		if ( forceRecover )
			{
			err = GTSession_ErrorRecover ( state->session, err, 0 );
			forceRecover = false;
			
			if ( err == kLinkClosed )
				{
				linkClosed = true;

				/* if we're all done, then we're ok */
				if ( state->sendLength <= 0 && state->recvLength <= 0 )
					{
					err = noErr;
					}
				}

			/* an error here is bad - return to the caller to let them deal with it */
			if ( err != noErr )
				{
				break;
				}
			
			/* skip the send for this frame */
			skipSend = true;
			noDatas = 0;
			}
		
		/* if we still have packets to send, send them (we should only never send packets */
		/* in cases where we got gibbled data) */
		if ( !skipSend && packetsToSend >= 0 )
			{
			/* are we sending real shit or fake packets? */
			if ( state->sendLength > 0 )
				{
				packetData = 0;

				switch ( state->sendLength )
					{
					default:
#ifdef DOTHREEBYTES
					case 3:
					packetData = *send++;
					packetData <<= 16;
#endif
					case 2:
						packetData |= ( (long) *send++ ) << 8;
					case 1:
						packetData |= *send++;
					case 0:
						break;
					}
				
				state->sendLength -= BYTESINPACKET;
				}
			else
				{
				packetData = 0;
				}
	
			GTSession_SendController ( state->session, packetData );				
			--packetsToSend;
			}
		
		/* wait for the next tick */
		ticks = gTicks;
		while ( ticks == gTicks )
			;
		}
	
	state->packetsToSend = packetsToSend;
	state->sendBuf = send;
	state->recvBuf = recv;
	
	/* if we get here with no error, we need to try and shut down the link */
	/* we send a done packet and wait until we get one. if we don't, we go */
	/* into error recovery mode */
	
	/* if we finished and we got no error and the link is still open, then close it */
	if ( !linkClosed && packetsToSend < 0 && err == noErr )
		{
		/* we don't care about data loss here as the other guy should have received all the */
		/* data! */
		GTSession_CloseSessionSynch ( state->session, 0 );
		}

bail:
	/* restore the caller's vbl handler and gt session */
	gVBLHandler = saveVBL;
	gVBLGTSession = saveGTSession;

	return err;
}


/*
*	Close a session safely - ie make sure that the other party has received all of our
*	data.
*/
Err	_GTCloseSessionSafe ( GTSession * session, long timeout )
{
long	endTime;
Err		err;
long	local;
long	remote;
Boolean	forceRecover;
Boolean	done;

	if ( timeout == 0 )
		{
		timeout = 500;
		}
		
	endTime = gTicks + timeout;
	
	/* send an end packet */
	err = GTSession_SendController ( session, 666 );
	if ( err != noErr )
		{
		return err;
		}

	/* wait until we receive one */
	err = -1;
	forceRecover = false;
	done = false;
	
	while ( err != noErr && gTicks < endTime && !done )
		{
		err = GTSession_ReadController ( session, &local, &remote );
		if ( err > 0 )
			{
			err = noErr;
			}
			
		switch ( err )
			{
			case noErr:
				if ( remote != 666 )
					{
					/* just eat it */
					err = -1;
					}
				break;
			
			case kNoData:
				break;
			
			case kLinkClosed:
				done = true;
				break;
			
			default:
				forceRecover = true;
				break;
			}
		
		/* do we want to recover? */
		if ( forceRecover )
			{
			err = GTSession_ErrorRecover ( session, err, 0 );
			forceRecover = false;
			
			/* an error here is bad */
			if ( err != noErr )
				{
				break;
				}
			}
		}
	
	/* just to be on the safe side, force the link to be closed, this will ensure */
	/* that both parties are done with the session */
	GTSession_CloseSessionSynch ( session, 0 );
	
	return err;
}



/*
*	These are a bunch of routines that manage loosely linked gametalk session. We can use
*	it for things like chat, play again dialog, etc where we need to exchange data at a very
*	slow rate but want to send tickle packets, etc to ensure that the remote guy is alive and
*	well.
*
*	This does not absolutely guarantee that all data was transmitted. If you need that, go
*	elsewhere (if one end has received a bad packet and asks for a resend at the time the other
*	closes the link, it will never get that packet).
*
*	RESTRICTIONS:
*		In order to make space for control data, we reserve the high order bit of the packet
*		data. If this bit is set on data passed into idle, an error will be returned.
*
*		Idle will call ReadHardwareModem. If it's likely that you'll be away for more than a
*		tick, be sure to call it in your vbl or something so that data is not dropped.
*/


/*
*	CreateLooseSession assumes that the gametalk session you pass in has been initialized and
*	set to the packet format you want. It will return a ptr to it's own internal structure
*	that you pass into the other calls.
*/
Err	_GTCreateLooseSession ( GTSession * session, LooseSession ** lsession )
{
Err				err;

	*lsession = NewMemory ( kTemp, sizeof(LooseSession) );

	DBGetConstant(kChatTickleSentTimeoutConst, &(*lsession)->timeBetweenWrites);
	DBGetConstant(kChatMaxTimeBetweenReadsConst, &(*lsession)->timeBetweenReads);
	(*lsession)->session = session;
	
	/* make sure the session begins at a reasonable place */
	GTSession_FlushInput ( session );
	GTSession_SetLatency ( session, kMaxFrameLatency );
	
	/* try and reach the other guy */
	err = GTSession_EstablishSynch ( session, 0 );
	if ( err != noErr )
		{
		DisposeMemory ( *lsession );
		*lsession = 0L;
		return err;
		}
	
	(*lsession)->expectNextPacket = gTicks + (*lsession)->timeBetweenReads;
	(*lsession)->sendNextTickle = gTicks + (*lsession)->timeBetweenWrites;	
	(*lsession)->controlPacketMask = 1L << ( session->bitSize - 1 );
	
	/* set up the vbl to do our stuff */
	gVBLGTSession = (long) session;
	
	return noErr;
}


/*
*	Call this in your inner control loop. It's best to call it about once a tick although it
*	won't care if you take longer. It will return kNoData if it got no remote controller read.
*	If you don't want to send anything, pass nil for inData. The only errors you should get
*	back are things like call waiting and connection closed (ie line dropped). Deal with
*	these as you will.
*/
Err _GTLooseSessionIdle ( LooseSession * lsession, long *inData, long *outData )
{
Err		err;
long	local;
long	remote;
OSErr	lineErr;

	GTSession_ReadHardwareModem ( lsession->session );

	/* see if their send packet was bogus */
	if ( inData && ( *inData & lsession->controlPacketMask ) )
		{
		return kBadPacketData;
		}
	
	/* see if the other guy has sent anything for us */
	err = GTSession_ReadController ( lsession->session, &local, &remote );
	if ( err > 0 )
		{
		err = noErr;
		}
	
	switch ( err )
		{
		case noErr:
			/* if we got a control tickle packet, ignore it */
			if ( remote & lsession->controlPacketMask )
				{
				/* make the caller ignore the packet */
				err = kNoData;
				*outData = 0;
				MESG ( "tickle" );
				}
			else
				{
				/* the packet was for them */
				*outData = remote;
				}
				
			/* record when we need to next get a packet */
			lsession->expectNextPacket = gTicks + lsession->timeBetweenReads;
			break;
		
		case kNoData:
			*outData = 0;
			break;
		
		default:
			err = GTSession_ErrorRecover ( lsession->session, err, 0 );
			
			/* we just got synched, so get new timeouts */
			lsession->sendNextTickle = gTicks + lsession->timeBetweenWrites;	
			lsession->expectNextPacket = gTicks + lsession->timeBetweenReads;
			break;
		}
	
	/* is the link still ok to send? */
	if ( err == noErr || err == kNoData )
		{
		/* send a packet if they want us to */
		if ( inData )
			{
			GTSession_SendController ( lsession->session, *inData );
			lsession->sendNextTickle = gTicks + lsession->timeBetweenWrites;	
			}
		else
		/* send a tickle packet if we need to */
		if ( gTicks > lsession->sendNextTickle )
			{
			GTSession_SendController ( lsession->session, lsession->controlPacketMask );
			lsession->sendNextTickle = gTicks + lsession->timeBetweenWrites;	
			}

		/* if we haven't received a packet and we should have by now, error recover */
		if ( gTicks > lsession->expectNextPacket )
			{
			MESG ( "No data timeout" );
			err = GTSession_ErrorRecover ( lsession->session, kNoData, 0 );
			if ( err == noErr )
				{
				/* we just got synched, so get new timeouts */
				lsession->sendNextTickle = gTicks + lsession->timeBetweenWrites;	
				lsession->expectNextPacket = gTicks + lsession->timeBetweenReads;
				}
			}
		}
	
	/* if we don't have an error yet (or no data), then check the line */
	if ( err == noErr || err == kNoData )
		{
		lineErr = OSCheckLine();
		if ( lineErr != noErr )
			{
			err = lineErr;
			}
		}
		
	lsession->err = err;
	return err;
}


/*
*	Dispose the session memory. This will not Shutdown the gametalk session
*/
Err _GTCloseLooseSession ( LooseSession * lsession )
{
Err		err;

	err = noErr;
	if ( lsession->err == noErr || lsession->err == kNoData )
		{
		/* close the session */
		err = GTSession_CloseSessionSynch ( lsession->session, 0 );
		}
	
	/* flush their gametalk session to be nice */
	GTSession_FlushInput ( lsession->session );

	DisposeMemory ( lsession );
	
	return err;
}

