/*
 *	$Id
 *
 *	$Log: GTNetwork.c,v $
 * Revision 1.2  1995/05/10  11:11:07  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GTNetwork.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<12>	 8/24/94	SAH		Pass current frame count to ClockInByte.
		<11>	 7/27/94	SAH		Flashy
		<10>	 7/26/94	SAH		Use restart semaphore in time mgr task.
		 <9>	 7/26/94	SAH		Disable interrupts inside our time mgr task.
		 <8>	 7/24/94	SAH		Killed some unused shit.
		 <7>	 7/22/94	SAH		New gametalk.
		 <5>	  7/3/94	SAH		<>'s asm.h to speed up compiles.
		 <4>	 6/28/94	DJ		more fuckfuck
		 <3>	 6/21/94	BET		(With DJ) Make it work on Fred instead of just compile.
		 <2>	 6/21/94	HEC		Compile in new world. Fred conversion.
		 <1>	 6/20/94	DJ		first checked in

	To Do:
*/



#include "GT.h"
#include "GTNetwork.h"
#include "GTModem.h"
#include "GTErrors.h"
#include "NetErrors.h"
#include <asm.h>
#include "GameTalkPriv.h"
#include "Exceptions.h"

#include "GTTester.h"

// #define OLDMODEMLAYER	1

#ifdef OLDMODEMLAYER
#include "Modem.h"
#else

#include "PhysicalLayer.h"
#endif

#ifdef SIMULATOR
#include <stdlib.h>
#include <stdio.h>
#endif

void GTNetwork_DoTick(GTNetwork *network);

void GTNetwork_DoTick(GTNetwork *network)
{
unsigned char 	byte;
unsigned char	frame;
unsigned char	vCount;
OSErr			err;

#ifndef	USETIMEMGR
	network->time++;
	return;
	
#else

	// if we still have a modem error hanging about, don't clear it */
	if ( network->masterModem->modemErr != noErr )
		{
		return;
		}
		
	network->time++;

#ifdef USERAMMODEMS
	err = ModemReadByte ( network->ramModem, &byte );
#else
	// if there is data, clock it into the master modem.
	err = PUReadSerialByte(&byte);
	if ( err == kNoByteReady )
		{
		err = kNoData;
		}
#endif
	
	// record the error so the next GT_ReadController can get it - unless it's a no data error
	if ( err != kNoData )
		{
		network->masterModem->modemErr = err;
		}
	
	// if we got the byte ok, clock it into the modem fifo with the arrival time
	if ( err == noErr )
		{
		frame = ConvertNetworkTicksToVBL ( network->time );
		vCount = ConvertNetworkTicksToFracTicks ( network->time );
		
		_GTModem_ClockInByte(network->masterModem, byte, frame, vCount, kUnknownCurrentFrame );
		}
#endif
}

#ifdef NETWORKUSEINTERRUPTS


pascal void GTTickProc(void)
{
long		oldA5;
TMInfoPtr	tmPtr;
short		saveSr;

	asm { move.w	sr,saveSr };
	asm { or.w		#0x0700,sr };
	
	tmPtr = GetTMInfo();
	oldA5 = SetA5(tmPtr->tmA5);
	++gRestartSemaphore;		// semaphore to keep dispatcher reset happy

	FlagTimeTask ( kGameTalkTask );
	
	GTNetwork_DoTick(tmPtr->tmNetwork);
	PrimeTime((QElemPtr)tmPtr, kNetworkInterruptMilliseconds);

	FlagTimeTask ( kGameTalkTask );

	--gRestartSemaphore;		// restart safe again
	SetA5(oldA5);
	
	asm { move.w	saveSr,sr };
}

void GTInstallTimeTask(GTNetwork *network)
{
	network->timetask.tmTask.tmAddr = (TimerProcPtr)GTTickProc;
	network->timetask.tmTask.tmWakeUp = 0;
	network->timetask.tmTask.tmReserved = 0;
	network->timetask.tmA5 = SetCurrentA5();
	network->timetask.tmNetwork = network;
	
	InsTime((QElemPtr)&network->timetask);
	PrimeTime((QElemPtr)&network->timetask, kNetworkInterruptMilliseconds);
}

void GTRemoveTimeTask(GTNetwork *network)
{
	RmvTime((QElemPtr)&network->timetask);
}

void GTDisableInterrupts(GTNetwork *network)
{
	asm {
		move.l	network,a0
		move.w	sr,OFFSET(GTNetwork,oldSR)(a0)
		or.w	#0x0700,sr
	}
}

void GTEnableInterrupts(GTNetwork *network)
{
	asm {
		move.l	network,a0
		move.w	OFFSET(GTNetwork,oldSR)(a0),sr
	}
}

void GTNetwork_Tick(GTNetwork *network)
{
}


void GTNetwork_RunVBL(GTNetwork *network)
{
	network->time++;	// simulate a start-bit tick.
}

#else


void GTNetwork_Tick(GTNetwork *network)
{
	GTNetwork_DoTick(network);
}

void GTNetwork_RunVBL(GTNetwork *network)
{
long a;

	for(a = 0; a < kNumDataTicksPerVBL; a++)
		GTNetwork_Tick(network);
	
	network->time++;	// simulate a start-bit tick.
}

#endif NETWORKUSEINTERRUPTS



void GTNetwork_Init(GTNetwork *network, GTModem *master, RamModem * modem)
{
long a;

	network->time = 0;
	network->masterModem = master;
#ifdef GT_RAMTEST
	network->ramModem = modem;
#endif
#ifdef NETWORKUSEINTERRUPTS
	GTInstallTimeTask(network);
#endif
}

void GTNetwork_Shutdown(GTNetwork *network)
{
#ifdef NETWORKUSEINTERRUPTS
	GTRemoveTimeTask(network);
#endif
}


