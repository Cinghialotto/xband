/*
 *	$Id
 *
 *	$Log: GTSync.c,v $
 * Revision 1.2  1995/05/10  11:11:14  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GTSync.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	 6/20/94	DJ		first checked in

	To Do:
*/


#include <stdio.h>


#include "GT.h"
#include "GTErrors.h"
#include "GTModem.h"
#include "GTNetwork.h"
#include "GTErrorRecover.h"


Err GTSessionLow_SendLowSyncPacket(GTSession *session)
{
	switch(session->packetSize)
	{
		case 2:	GTSessionLow_SendLowSyncPacket16(session);
			break;
		case 3:	GTSessionLow_SendLowSyncPacket24(session);
			break;
	}
}

Err GTSessionLow_SendLowSyncPacket24(GTSession *session)
{
unsigned char bytes[3];
unsigned char checksum;
	
	bytes[0] = 0xff;
	bytes[1] = 0xff;
	bytes[2] = 0xff;
	
	GTSession_BlockingSendRawByte(session, bytes[0]);
	GTSession_BlockingSendRawByte(session, bytes[1]);
	GTSession_BlockingSendRawByte(session, bytes[2]);

	return(kNoError);
}

Err GTSessionLow_SendLowSyncPacket16(GTSession *session)
{
unsigned char bytes[2];
unsigned char checksum;
	
	bytes[0] = 0xff;
	bytes[1] = 0xff;
	
	GTSession_BlockingSendRawByte(session, bytes[0]);
	GTSession_BlockingSendRawByte(session, bytes[1]);

	return(kNoError);
}



