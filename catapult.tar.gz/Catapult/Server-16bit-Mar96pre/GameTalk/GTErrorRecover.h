/*
 *	$Id
 *
 *	$Log: GTErrorRecover.h,v $
 * Revision 1.2  1995/05/10  11:11:03  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GTErrorRecover.h

	Contains:	xxx put contents here xxx

	Written by:	Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<11>	 7/22/94	SAH		Never
		<10>	 7/16/94	DJ		made timeouts real again (20 sec) not debug (200 sec)
		 <9>	 7/13/94	DJ		twiddled timeouts
		 <8>	 7/13/94	DJ		trying to make it work on segas
		 <7>	 7/13/94	DJ		timeout tweaks
		 <6>	  7/9/94	DJ		fix multiple define of kOneSecond (for Intro.c)
		 <5>	 6/28/94	DJ		added underscores for server using _GTSession_MasterErrorRecover
		 <4>	 6/21/94	BET		Make it work on Fred instead of just compile.
		 <3>	 6/21/94	BET		Need these too...
		 <2>	 6/21/94	BET		Managerize
		 <1>	 6/20/94	DJ		first checked in

	To Do:
*/

#ifdef NEVER

#ifndef GTERRORRECOVER
#define GTERRORRECOVER


#ifndef __SERVER__
#include "OSManagers.h"
#endif

//
// These are timeout values for error recovery.  If we don't get synced within these
// timeouts, then the ErrorRecover routines will fail and return kDroppedCarrier.
//

//#define kDebugTimeout		10					/* timeout multiplier for debugging	*/
#define kDebugTimeout		1

#define kMaxResyncTimeout	60*20*1			/* 20 seconds	*/
#define	kResyncTryAgain		60*5*kDebugTimeout	/* 5 seconds	*/
#define kTwoSeconds			120*kDebugTimeout	/* 2 seconds	*/


//
// number of LoSyncs that must be sucessfully transmitted and received between master and
// slave at the beginning of error recovery.  After these have been exchanged, the boxes
// then send control codes for things like resending frames.
//
#define kInitialLoSyncs		20
#define kNumPingedSyncs		20

//
// Control code nibbles
//
#define kDoneControl		0x01
#define kClearLineControl	0x02
#define kResendController	0x03

#define kLowSyncControl		0xff


//
// Actually we can send 5 bits of data with a 3 bit checksum.  Kind of a nibble++  :-)  -dj
//
#define kNibbleMask			0x1f

/////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////  P R O T O T Y P E S /////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////


#endif GTERRORRECOVER
#endif

