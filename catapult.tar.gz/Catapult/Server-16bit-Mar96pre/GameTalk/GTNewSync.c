/*
 *	$Id
 *
 *	$Log: GTNewSync.c,v $
 * Revision 1.2  1995/05/10  11:11:09  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GTNewSync.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <6>	 7/22/94	SAH		Never
		 <5>	 7/15/94	SAH		Don't call that GTModem_NumBytesAvailToRead fucker.
		 <4>	 6/28/94	DJ		GetCurrentTime shit
		 <3>	 6/21/94	HEC		Compile in new world
		 <2>	 6/21/94	BET		Managerize
		 <1>	 6/20/94	DJ		first checked in

	To Do:
*/

#ifdef NEVER

#include <stdio.h>

#include "GT.h"
#include "GTErrors.h"
#include "GTModem.h"
#include "GTNetwork.h"
#include "GTErrorRecover.h"

#ifndef __SERVER__
#include "time.h"
#endif

short	_GTSession_MasterSync(GTSession *session);
short	_GTSession_SlaveSync(GTSession *session);
Err		GTSession_ClearLine(GTSession *session);
short	GTSession_WrapupSync(GTSession *session, unsigned char delay);
Err		GTSession_PullSend(GTSession *session, unsigned char sendByte, unsigned char *recvByte);
Err		GTSession_SendCouldReceive(GTSession *session, unsigned char sendByte, unsigned char *recvByte);


/*
	The master sends and the slave simply sends back what it received.
	
	The master sends '1' until it receives a '1'
	then it

*/

/*
;
;------------------------------------------------------------------------------------
; equates
;

; i have chosen these because they are above the frame number values we should be
; able to receive from the vbl synch. we might want an intermediate step which clears
; the line. before we come here...
*/

#define kBase			245						// base token to begin synch on
#define kMagicToken		252						// magic token to say we're done frame delay
#define kEndToken		253						// final synch token


// these are for the vbl synch
#define kMaxScan		249						// max scanline we allow from v counter
#define kSynchBegin		250						// begining synch char
#define kSynchDone		251						// the synch is done
#define kLineClear		255						// and we're all clear



short _GTSession_MasterSync(GTSession *session)
{
unsigned char 	sendByte;
unsigned char 	bytes[4], byte;
unsigned char 	vbl, ticksAfterVBL;
unsigned char 	count, countQueue[5];
unsigned char 	i;
Err				err;
short			frameDelay, delay, temp;
GTModemByte		mByte;

	if(GTSession_ClearLine(session) == kDroppedCarrier)
		return(-1);

	sendByte = kBase;
	count = 0;
	i = 0;
	for(;;)
	{
		if ( GTModem_ClockOutByte(&session->modem, &mByte) == noErr )
		{
			byte = mByte.byte;
			
			if(byte == sendByte)
			{
				// got it back from the slave, yay!
				countQueue[i] = count;	// round trip latency == 'count' modem ticks.
				if(i == 4)
					break;	// done sending treats.
				i++;
				sendByte++;
				count = 0;
			}
		}

		// send our treat
		if(GTModem_AbleToSend(&session->modem))
		{
			GTModem_SendBytes(&session->modem, 0, &sendByte);
			count++;
		}

		// try sending again.
//		GTNetwork_Tick(network);
	}

// there are rountrip - 1 bytes of the last treat out on the wire.

	// send the magic end token.
	sendByte = kMagicToken;
	GTSession_PullSend(session, sendByte, NULL);

// there are rountrip - 2 bytes of the last treat out on the wire.

	// ok, now the countQueue is the 5 roundtrip latencies.
	// compute the average round trip latency.
	// use the last 4 cuz the first one is jizz cuz you don't know when slave started listening.
	//
	for( i = 1; i < 5; i++)
		if(i == 1)
			delay = countQueue[i];
		else
			delay += countQueue[i];

	delay += 4;		// add half for rounding
	delay >>= 3;	// divide by 8 to get one way latency time

// printf("Line delay is %ld bytes\n", (long)delay);

	// send the computed frame delay to the slave
	sendByte = (unsigned char)delay;
	GTSession_PullSend(session, sendByte, NULL);


	session->byteLatency = sendByte;

	//  there are now delay - 2 bytes on the wire (cuz we sent the delay and the magicToken).
	temp = delay - 2;
	if(temp == -1)	// yikes!  only a one tick delay between master and slave.
	{
		// receive a single byte in this special case.
		for(;;)
		{
			if(GTModem_ClockOutByte(&session->modem, &mByte) == noErr)
			{
				byte = mByte.byte;
				break;
			}
//			GTNetwork_Tick(network);
		}
	}
	else
	{
		// the normal case: send the magicToken to make up the rest of the frame delay
		//
		sendByte = kMagicToken;
		for(; temp--;)
			GTSession_PullSend(session, sendByte, NULL);
	}


#ifdef SHANNONBUG
	// there are still 1/2 trip (ie. delay) bytes on the line.
	
	for(temp = delay - 1; temp;)
	{
		if(GTModem_ClockOutByte(&session->modem, &mByte) == noErr)
		{
			byte = mByte.byte;
			temp--;
		}
//		GTNetwork_Tick(network);
	}
	
#endif

	// OK.  The line is nice and empty, and both sides know it at the *same time*.
	// 		What a miracle of synchronization!

// printf("wrapping up\n");

	frameDelay = GTSession_WrapupSync(session, delay);
	session->frameDelay = frameDelay;
//printf("Line delay is %ld bytes\n", (long)delay);
//printf("Frame delay is %ld vbls\n", (long)frameDelay);

	return(frameDelay);
}





short _GTSession_SlaveSync(GTSession *session)
{

unsigned char byte, vbl, ticksAfterVBL, sendByte;
short frameDelay, temp, delay;
Boolean sent;
GTModemByte		mByte;

	// echo whatever gets sent to us
	for(;;)
	{
		if(GTModem_ClockOutByte(&session->modem, &mByte) == noErr)
		{
			byte = mByte.byte;
			
			if(byte == kMagicToken)
				break;

			for(sent = false; sent == false;)
			{
				if(GTModem_AbleToSend(&session->modem))
				{
					GTModem_SendBytes(&session->modem, 0, &byte);
					sent = true;
				}
//				GTNetwork_Tick(network);
			}
		}
//		GTNetwork_Tick(network);
	}
	
	// yay!  got the magic token.
	// Now read the tick delay.
	for(;;)
	{
		if(GTModem_ClockOutByte(&session->modem, &mByte) == noErr)
		{
			byte = mByte.byte;
			break;
		}
//		GTNetwork_Tick(network);
	}

	ASSERT_MESG(byte > 0, "GTSession_SlaveSync: got a latency delay less than 1!?!\n");
	delay = (short)byte;
	session->byteLatency = delay;

// printf("Line delay is %ld bytes\n", (long)delay);

//
// this is jizzed.  master is expecting me to ping back the tick delay.
//



	// OK, now read/send the remainder of a frame
	// There have been 2 bytes sent in this frame already (kMagicToken and the tickDelay)
	//
	temp = byte - 2;
	if(temp == -1)	// yikes!  only a one tick delay between master and slave. fast line!?!
	{
		// send a single byte in this special case.
		sendByte = kMagicToken;
		for(;;)
		{
			if(GTModem_AbleToSend(&session->modem))
			{
				GTModem_SendBytes(&session->modem, 0, &sendByte);
				break;
			}
//			GTNetwork_Tick(network);
		}
	}
	else
	{
		// the normal case: master sent magicTokens to fill up a frame delay.  read 'em
		//
		for(; temp;)
		{
			if(GTModem_ClockOutByte(&session->modem, &mByte) == noErr)
			{
				byte = mByte.byte;
				temp--;
			}
//			GTNetwork_Tick(network);
		}
	}
	
	// OK.  The line is nice and empty, and both sides know it at the *same time*.
	// 		What a miracle of synchronization!
	
	frameDelay = GTSession_WrapupSync(session, delay);
	session->frameDelay = frameDelay;
//printf("Line delay is %ld bytes\n", (long)delay);
//printf("Frame delay is %ld vbls\n", (long)frameDelay);

	return(frameDelay);
}



short GTSession_WrapupSync(GTSession *session, unsigned char delay)
{
unsigned char 	sendByte;
unsigned char 	byte;
unsigned char 	vbl, ticksAfterVBL;
Err				err;
short			frameDelay;
GTModemByte		mByte;

/***
short poo, pee;
	for(poo = pee = 0; poo < 10000; poo++)
	{
		if(GTModem_ClockOutByte(&session->modem, &mByte) == noErr)
		{
			byte = mByte.byte;
			pee++;
		}
//		GTNetwork_Tick(network);
	}
//if(pee)
//	printf("The line wasn't empty!  %ld bytes read. byte = %ld\n", (long)pee, (long)byte);
***/


	//
	// Now compute the # of VBLs that this byte latency represents.  Always round up.
	//
	
	frameDelay = delay + 2;	// for rounding up.
	frameDelay >>= 2;		// divide by 4 (cuz 2400 baud modem sends 4 data bytes per VBL)
	
	// Shannon said some wackiness about adding one to the frameDelay?
#ifdef DOVBLSynch
	if(frameDelay < 1)
		frameDelay = 1;
#else
	if(frameDelay < 2)
		frameDelay = 2;
#endif

	// Send a final jizzly end token
	//
	sendByte = kEndToken;
	for(;;)
	{
		if(GTModem_AbleToSend(&session->modem))
		{
			GTModem_SendBytes(&session->modem, 0, &sendByte);
			break;
		}
//		GTNetwork_Tick(network);
	}

	byte = 0;
	for(;;)
	{
		if(GTModem_ClockOutByte(&session->modem, &mByte) == noErr)
		{
			byte = mByte.byte;
			
			if(byte == kEndToken)
				break;
		}
//		GTNetwork_Tick(network);
	}

	return(frameDelay);
}



//
// Reads 1 byte and sends 1 byte.
//
Err GTSession_PullSend(GTSession *session, unsigned char sendByte, unsigned char *recvByte)
{
unsigned char byte, vbl, ticksAfterVBL;
Err err;
Boolean sent, recvd;
GTModemByte		mByte;

	if(!recvByte)
		recvByte = &byte;	// caller doesn't want to read the recvd byte, so make a dummy to read it into.

	sent = recvd = false;
	for(;;)
	{

		// BRAIN DAMAGE.  need a timeout here in case the line goes down.

		if(sent == false && GTModem_AbleToSend(&session->modem))
		{
			GTModem_SendBytes(&session->modem, 0, &sendByte);
			sent = true;
		}
		if(recvd == false && GTModem_ClockOutByte(&session->modem, &mByte) == noErr)
		{
			*recvByte = mByte.byte;
			recvd = true;
		}
		if(sent == true && recvd == true)
			return(kNoError);
//		GTNetwork_Tick(network);
	}
}



//
// Sends 1 byte and could receive a bytes.
//
Err GTSession_SendCouldReceive(GTSession *session, unsigned char sendByte, unsigned char *recvByte)
{
unsigned char 	byte, vbl, ticksAfterVBL;
Err 			recvError;
Boolean			recvd;
GTModemByte		mByte;

	if(!recvByte)
		recvByte = &byte;	// caller doesn't want to read the recvd byte, so make a dummy to read it into.

	recvError = kNoData;
	recvd = false;
	for(;;)
	{

		// BRAIN DAMAGE.  need a timeout here in case the line goes down.

		if(recvd == false && GTModem_ClockOutByte(&session->modem, &mByte) == noErr)
		{
			*recvByte = mByte.byte;
			recvError = kNoError;
			recvd = true;
		}

		if(GTModem_AbleToSend(&session->modem))
		{
			GTModem_SendBytes(&session->modem, 0, &sendByte);
			return(recvError);
		}
//		GTNetwork_Tick(network);
	}
}


/*
	Send some zeros down the line for fun.
*/
Err GTSession_ClearLine(GTSession *session)
{
unsigned char byte, rxbyte;
long a;
Err err;
long	startTime, time, delayTime;

	startTime = GetCurrentTime();

	byte = 0;
	for(a = 0; a < 15; )
	{
		time = GetCurrentTime();
		delayTime = time - startTime;
		if(delayTime > kMaxResyncTimeout)
			return(kDroppedCarrier);

		err = GTSession_SendCouldReceive(session, byte, &rxbyte);
		if(err == kDroppedCarrier || err == kCallWaiting)
			return(err);
		else if (err == kNoError && rxbyte == byte)
			a++;
	}
	return(kNoError);

}

#endif
