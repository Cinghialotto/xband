/*
 *	$Id
 *
 *	$Log: GTSession.c,v $
 * Revision 1.2  1995/05/10  11:11:12  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GTSession.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans, Holland, and Perlman

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<34>	 8/28/94	SAH		Fast 24 bit packets. Fixed a bug in error return in 8 bit
									packets. Fixed install on 8 and 24 bit handlers.
		<33>	 8/28/94	KON		Add 8bit packet format.[SAH]
		<32>	 8/27/94	SAH		Return all the modem timing data in ReadController. Use Steve's
									fast 16bit ReadController - don't know how i missed it before...
		<31>	 8/27/94	SAH		Install new sinko functions.
		<30>	 8/26/94	HEC		Call OSCheckLine directly.
		<29>	 8/25/94	SAH		Consolidated default controller read/send code.
		<28>	 8/24/94	SAH		Boatloads of new formats. Steve's fast 16 bit stuff.
		<27>	 8/22/94	DJ		fixed a shannon fuckup
		<26>	 8/22/94	SAH		Provide general patchable support for all packet formats.
		<25>	 8/22/94	SAH		Install more stinko.
		<24>	 8/22/94	SAH		Install _GTSyncOTron_GraphicSynch.
		<23>	 8/10/94	SAH		Keep track of error better in ErrorRecover.
		<22>	 8/10/94	HEC		Init eqmThreshold field.
		<21>	  8/8/94	SAH		Keep track of bad packets.
		<20>	  8/6/94	SAH		Fixed some error propogation.
		<19>	  8/5/94	SAH		Less debugging code.
		<18>	  8/3/94	SAH		Added the loose selectors.
		<17>	  8/3/94	SAH		Check for some stupid errors in error recover before attempting
									to recover. Use default timeout in establish synch.
		<16>	  8/2/94	SAH		Added the send bytes stuff.
		<15>	 7/29/94	SAH		More timeout/error recovery stuff. Call PModem to read bytes in
									error cases.
		<14>	 7/28/94	SAH		Cleaned up timeout stuff.
		<13>	 7/28/94	SAH		Make sure to read the modem while in error recovery mode on the
									sega.
		<12>	 7/26/94	SAH		Try to recover from an error for the full duration of the
									timeout.
		<11>	 7/26/94	SAH		Added GTSession_CloseSessionSynch.
		<10>	 7/24/94	SAH		Game patch vectorizing funness.
		 <9>	 7/22/94	SAH		Lametalk too.
		 <8>	 7/15/94	SAH		Don't call that GTModem_NumBytesAvailToRead fucker anymore.
									Optimized the one byte checksum sum.
		 <7>	  7/8/94	DJ		Added ReadBytes and FlushInput
		 <6>	 6/27/94	SAH		Make SoftInit return noErr.
		 <5>	 6/21/94	BET		(With DJ) Make it work on Fred instead of just compile.
		 <4>	 6/21/94	HEC		Compile in new world
		 <3>	 6/21/94	BET		Need these too...
		 <2>	 6/21/94	BET		Managerize
		 <1>	 6/20/94	DJ		first checked in

	To Do:
*/


#include "SegaOS.h"
#include "DispatcherControl.h"
#include "OSGlobals.h"
#include "GT.h"
#include "GTErrors.h"
#include "GTModem.h"
#include "NetErrors.h"
#include "DBConstants.h"
#include "BoxSer.h"
#include "GamePatch.h"
#include "GameTalkPriv.h"
#include "GTSendData.h"
#include "hardDefines.h"

#ifdef SIMULATOR
#include <stdio.h>
#endif

void	_GTSession_Init(GTSession *session, Boolean master);
void	_GTSession_Shutdown(GTSession *session);
Err		_GTSession_SetGTPacketFormat ( GTSession * session, short packetFormat );
Err		_GTSession_SetRamRomOffsets ( GTSession * session, long ramOffset, long romOffset );
Err 	_GTSession_SetLatency ( GTSession * session, short frameLatency );
Err 	_GTSession_SendController8 ( GTSession * session, long data );
long	_GTSession_ReadController8 ( GTSession * session , long *localData, long * remoteData);
Err 	_GTSession_SendController12 ( GTSession * session, long data );
long	_GTSession_ReadController12 ( GTSession * session , long *localData, long * remoteData);
Err 	_GTSession_SendController16 ( GTSession * session, long data );
Err 	_GTSession_ReadController16 ( GTSession * session, long *localData, long * remoteData );
Err 	_GTSession_SendController18 ( GTSession * session, long data );
long	_GTSession_ReadController18 ( GTSession * session, long *localData, long * remoteData );
Err 	_GTSession_SendController24 ( GTSession * session, long data );
long	_GTSession_ReadController24 ( GTSession * session, long *localData, long * remoteData );
Err 	_GTSession_SendController27 ( GTSession * session, long data );
long	_GTSession_ReadController27 ( GTSession * session, long *localData, long * remoteData );
Err		_GTSession_DefaultSend ( GTSession * session, long data );
long	_GTSession_DefaultRead ( GTSession * session, long *localData, long * remoteData );
Err		_GTSession_PrefillFifo ( GTSession * session, unsigned long fillData );
Err		_GTSession_EstablishSynch ( GTSession * session, long timeout );
Err		_GTSession_ExchangeCommands ( GTSession * session, unsigned char send, unsigned char * receive, long timeout );
Err		_GTSession_ValidateControlPacket ( GTSession * session, unsigned char packet );
Err		_GTSession_ErrorRecover ( GTSession * session, Err error, long timeout );
Err		_GTSession_DoCommand ( GTSession * session, Err error, unsigned char sendCommand,
			unsigned char receiveCommand );
Err		_GTSession_DoResend ( GTSession * session, short localFrame, short remoteFrame );
Err		_GTSession_ResendFromFrame ( GTSession * session, short resendFrames );
Err		_GTSession_FlushInput(GTSession *session);
Err		_GTSession_CloseSessionSynch ( GTSession * session, long timeout );

	/* stinko priv prototypes */
Err		_GTSyncOTron_Synch ( SyncState * state );
Err		_MasterCalculateLatency ( SyncState * state );
Err		_SlaveCalculateLatency ( SyncState * state );
Err		_SyncronizeVBLs ( SyncState * state );
Err		_SyncronizeMasterLeave ( SyncState * state );
Err		_SyncronizeSlaveLeave ( SyncState * state );
void	_SyncoTronVBLHandler ( void );
void 	_SyncoReadModemVBL ( void );


static	void	RemapFunctionVector ( long * address, long ramOffset, long romOffset );

unsigned char GT_ChecksumPacket ( long data, short bitCount );
unsigned long GT_BuildPacket ( short bitSize, unsigned long data );
Err	GT_UnpackVerifyPacket ( GTSession * session, long * packet );



#ifndef __SERVER__

#ifndef __Dispatcher__
#include "Dispatcher.h"
#endif

#ifndef __OSManagers__
#include "OSManagers.h"
#endif

#include "SegaErrors.h"



/*
* A macro to load the rom checksum table - we know we're already in asm!
*/

#ifdef SIMULATOR
#define	GETCHECKSUMTABLE(r)		\
								move.l	gRomBottom,r \
								add.l	#kRomGTCksumOffset,r
#else
#define	GETCHECKSUMTABLE(r)		\
								lea		gRomGTChecksum,r \
								add.l	GameGlobal(romOffset),r
#endif


				
long
_GameTalkControl ( short command, long data )
{
long		error;

	error = commandSelectorUnknown;

	switch ( command )
		{
		case kHardInitialize:
			/* install our selectors */
			SetDispatchedFunction (kGTSInit,					kGameTalkManager,	_GTSession_Init);
			SetDispatchedFunction (kGTSShutdown,				kGameTalkManager,	_GTSession_Shutdown);
			SetDispatchedFunction (kGTSFlushInput,				kGameTalkManager,	_GTSession_FlushInput);
			SetDispatchedFunction (kGTSErrorRecover,			kGameTalkManager,	_GTSession_ErrorRecover);
			SetDispatchedFunction (kGTSCloseSessionSynch,		kGameTalkManager,	_GTSession_CloseSessionSynch);
			SetDispatchedFunction (kGTSDoCommand,				kGameTalkManager,	_GTSession_DoCommand);
			SetDispatchedFunction (kGTSDoResend,				kGameTalkManager,	_GTSession_DoResend);
			SetDispatchedFunction (kGTSResendFromFrame,			kGameTalkManager,	_GTSession_ResendFromFrame);
			SetDispatchedFunction (kGTSSetPacketFormat,			kGameTalkManager,	_GTSession_SetGTPacketFormat);
			SetDispatchedFunction (kGTSSetRamRomOffset,			kGameTalkManager,	_GTSession_SetRamRomOffsets);
			SetDispatchedFunction (kGTSessionSetLatency,		kGameTalkManager,	_GTSession_SetLatency);
			SetDispatchedFunction (kGTSessionSendController8,	kGameTalkManager,	_GTSession_SendController8);
			SetDispatchedFunction (kGTSessionReadController8,	kGameTalkManager,	_GTSession_ReadController8);
			SetDispatchedFunction (kGTSessionSendController12,	kGameTalkManager,	_GTSession_SendController12);
			SetDispatchedFunction (kGTSessionReadController12,	kGameTalkManager,	_GTSession_ReadController12);
			SetDispatchedFunction (kGTSessionSendController16,	kGameTalkManager,	_GTSession_SendController16);
			SetDispatchedFunction (kGTSessionReadController16,	kGameTalkManager,	_GTSession_ReadController16);
			SetDispatchedFunction (kGTSessionSendController18,	kGameTalkManager,	_GTSession_SendController18);
			SetDispatchedFunction (kGTSessionReadController18,	kGameTalkManager,	_GTSession_ReadController18);
			SetDispatchedFunction (kGTSessionSendController24,	kGameTalkManager,	_GTSession_SendController24);
			SetDispatchedFunction (kGTSessionReadController24,	kGameTalkManager,	_GTSession_ReadController24);
			SetDispatchedFunction (kGTSessionSendController27,	kGameTalkManager,	_GTSession_SendController27);
			SetDispatchedFunction (kGTSessionReadController27,	kGameTalkManager,	_GTSession_ReadController27);
			SetDispatchedFunction (kGTSessionPrefillFifo,		kGameTalkManager,	_GTSession_PrefillFifo);
			SetDispatchedFunction (kGTSessionEstablishSynch,	kGameTalkManager,	_GTSession_EstablishSynch);
			SetDispatchedFunction (kGTSessionExchangeCommands,	kGameTalkManager,	_GTSession_ExchangeCommands);
			SetDispatchedFunction (kGTSessionValidateControl,	kGameTalkManager,	_GTSession_ValidateControlPacket);
			
			/* init selectors for GTModem */
			SetDispatchedFunction (kGTModemInit,				kGameTalkManager,	_GTModem_Init);
			SetDispatchedFunction (kGTModemGetModemError,		kGameTalkManager,	_GTModem_GetModemError);
			SetDispatchedFunction (kGTModemClearFifo,			kGameTalkManager,	_GTModem_ClearFifo);
			SetDispatchedFunction (kGTModemClockInByte,			kGameTalkManager,	_GTModem_ClockInByte);
			SetDispatchedFunction (kGTModemClockOutByte,		kGameTalkManager,	_GTModem_ClockOutByte);
			SetDispatchedFunction (kGTModemAbleToSend,			kGameTalkManager,	_GTModem_AbleToSend);
			SetDispatchedFunction (kGTModemSendBytes,			kGameTalkManager,	_GTModem_SendBytes);
			SetDispatchedFunction (kGTModemCheckLine,			kGameTalkManager,	_GTModem_CheckLine);
			SetDispatchedFunction (kGTModemReadModem,			kGameTalkManager,	_GTModem_ReadModem);
			
			/* SendData */
			SetDispatchedFunction (kGTSendReceiveBytes,			kGameTalkManager,	_GTSendReceiveBytes);
			SetDispatchedFunction (kGTCloseSessionSafe,			kGameTalkManager,	_GTCloseSessionSafe);
			SetDispatchedFunction (kGTCreateLooseSession,		kGameTalkManager,	_GTCreateLooseSession);
			SetDispatchedFunction (kGTLooseSessionIdle,			kGameTalkManager,	_GTLooseSessionIdle);
			SetDispatchedFunction (kGTCloseLooseSession,		kGameTalkManager,	_GTCloseLooseSession);
			
			/* stinkotron */
			SetDispatchedFunction (kGTSyncotron,				kGameTalkManager,	_GTSyncOTron_Synch);
			SetDispatchedFunction (kGTMasterCalculateLatency,	kGameTalkManager,	_MasterCalculateLatency);
			SetDispatchedFunction (kGTSlaveCalculateLatency,	kGameTalkManager,	_SlaveCalculateLatency);
			SetDispatchedFunction (kGTSyncronizeVBLs,			kGameTalkManager,	_SyncronizeVBLs);
			SetDispatchedFunction (kGTSyncronizeMasterLeave,	kGameTalkManager,	_SyncronizeMasterLeave);
			SetDispatchedFunction (kGTSyncronizeSlaveLeave,		kGameTalkManager,	_SyncronizeSlaveLeave);
			SetDispatchedFunction (kGTSyncoTronVBLHandler,		kGameTalkManager,	_SyncoTronVBLHandler);
			SetDispatchedFunction (kGTSyncoReadModemVBL,		kGameTalkManager,	_SyncoReadModemVBL);
			break;
		
		case kSoftInialize:
			error = noErr;
			break;
		
		case kHardClose:
			error = noErr;
			break;
		
		case kSoftClose:
			error = noErr;
			break;
					
		case kCodeBlockMoved:
			error = noErr;
			break;
					
		case kGlobalsMoved:
			error = noErr;
			break;
		}
		
	return error;
}

#endif // __SERVER__




//
// A low level sync is 2 bytes of 0xff.
// When you get that, you should keep gobbling them until you get the
// low level start packet which is a byte of 0x00
//

void _GTSession_Init(GTSession *session, Boolean master)
{
	OSGTModem_Init(&session->modem, true);
	
	session->master = master;	
	session->packetFormat = 0;
	session->bytesInPacket = 0;
	session->bitSize = 0;
	
	session->frameDelay = kMaxFrameLatency;
	session->byteLatency = 0;
	session->roundtripLatency = 40;		// HACK. (also, really is more like 20).
	
	session->localIndex = 0;
	session->remoteIndex = 0;
	session->writeIndex = 0;
	
	session->sendTimeStamp = 0;			// timestamp for outgoing packets (can't be longer than a nibble)
	session->recvTimeStamp = 0;

	session->badPackets = 0;
	
	/* get the default timeouts */
	DBGetConstant ( kEQMThresholdConst, &session->eqmThreshold );
	DBGetConstant ( kDefaultSynchTimeoutConst, &session->defaultEstSynchTimeout );
	DBGetConstant ( kDefaultSynchStateTimeoutConst, &session->defaultSynchStateTimeout );;
	DBGetConstant ( kExchangeCommandsTimeoutConst, &session->defaultExgCommandsTimeout );;
	DBGetConstant ( kDefaultErrorRecoverTimeoutConst, &session->defaultErrorRecoverTimeout );;

}

void _GTSession_Shutdown(GTSession *session)
{
	GTNetwork_Shutdown(&session->modem.network);
}


//
// Set the mode GameTalk will be running in. We set some internal stuff and then set
// up the read and write controller vectors that the game will use
//

Err	_GTSession_SetGTPacketFormat ( GTSession * session, short packetFormat )
{
short	bitSize;
short	bytes;

	session->packetFormat = packetFormat;
	
	switch ( packetFormat )
		{
		case k8BitData:
			bitSize = 8;
			bytes = 2;
			GetDispatchedFunction ( kGTSessionReadController8, 0L, (ProcPtr *) &gGTReadController );
			GetDispatchedFunction ( kGTSessionSendController8, 0L, (ProcPtr *) &gGTSendController );
			break;
			
		case k12BitData:
			bitSize = 12;
			bytes = 2;
			GetDispatchedFunction ( kGTSessionReadController12, 0L, (ProcPtr *) &gGTReadController );
			GetDispatchedFunction ( kGTSessionSendController12, 0L, (ProcPtr *) &gGTSendController );
			break;
			
		case k16BitData:
			bitSize = 16;
			bytes = 3;
			GetDispatchedFunction ( kGTSessionReadController16, 0L, (ProcPtr *) &gGTReadController );
			GetDispatchedFunction ( kGTSessionSendController16, 0L, (ProcPtr *) &gGTSendController );
			break;
			
		case k19BitData:
			bitSize = 19;
			bytes = 3;
			GetDispatchedFunction ( kGTSessionReadController18, 0L, (ProcPtr *) &gGTReadController );
			GetDispatchedFunction ( kGTSessionSendController18, 0L, (ProcPtr *) &gGTSendController );
			break;
			
		case k24BitData:
			bitSize = 24;
			bytes = 4;
			GetDispatchedFunction ( kGTSessionReadController24, 0L, (ProcPtr *) &gGTReadController );
			GetDispatchedFunction ( kGTSessionSendController24, 0L, (ProcPtr *) &gGTSendController );
			break;
			
		case k27BitData:
			bitSize = 27;
			bytes = 4;
			GetDispatchedFunction ( kGTSessionReadController27, 0L, (ProcPtr *) &gGTReadController );
			GetDispatchedFunction ( kGTSessionSendController27, 0L, (ProcPtr *) &gGTSendController );
			break;
			
		default:
			ERROR_MESG( "Some fucker called us with an invalid packet format" );
		}

	GetDispatchedFunction ( kGTModemReadModem, 0L, (ProcPtr *) &gGTReadModem );

	session->bitSize = bitSize;
	session->bytesInPacket = bytes;
	
	// a convenient mask for packet unpacking
	session->packetMask = (1L << bitSize ) - 1;
	
	return noErr;
}


//
// Set the ram and rom offsets that the game patch will be mapping the world to.
// We need to offset a bunch of our internal vectors to work
//
Err	_GTSession_SetRamRomOffsets ( GTSession * session, long ramOffset, long romOffset )
{

#ifndef SIMULATOR

	/* offset the session ptr and the fast dispatched vectors */
	/* the game patch needs to be careful about turning off interrupts around */
	/* here so that ReadHardwareModem is not called while the real ram and rom */
	/* offsets don't match the software mappings */
	
	/* remap the session ptr - it is always in ram */
	session = (GTSession *) (long) session + ramOffset;
	
	/* remap the functions - they may be in ram or rom */
	RemapFunctionVector ( &gGTSendController, ramOffset, romOffset );
	RemapFunctionVector ( &gGTReadController, ramOffset, romOffset );
	RemapFunctionVector ( &gGTReadModem, ramOffset, romOffset );
	

#endif

	return noErr;
}

static
void	RemapFunctionVector ( long * vector, long ramOffset, long romOffset )
{
long	address;

	address = *vector;
	if ( address >= gRomBottom )
		{
		address += romOffset;
		}
	else
		{
		address += ramOffset;
		}
	
	*vector = address;
}


//
// Force gameyak's latency to some value (in frames). This can only be called before
// data has been transmitted as it will reset the fifo's
//
Err _GTSession_SetLatency ( GTSession * session, short frameLatency )
{
	session->localIndex = 0;
	session->remoteIndex = 0;
	session->writeIndex = 0;

	session->frameDelay = frameLatency;
}


//
// Prefill the local fifo with noop data and send the nop controller reads to the remote guy to
// to prefill the local fifo and the wire with the right shit
//
Err _GTSession_PrefillFifo ( GTSession * session, unsigned long fillData )
{
short	frames;
Err		err;
long	ticks;

	err = noErr;
	
	for ( frames = session->frameDelay - 1; frames >= 0 && err == noErr; --frames )
		{
		// wait for the next frame
		ticks = gTicks;
		while ( ticks == gTicks )
			;

		err = OSGTSession_SendController ( session, fillData );
		}
	
	return err;
}


//
// Establish a connection to the other gametalker and ensure that we have a clear line
//
Err _GTSession_EstablishSynch ( GTSession * session, long timeout )
{
short			state;
Err				err;
GTModemByte 	mByte;
long			startTime;
long			innerStateStart;
short			startFifoBytes;
	
	/* get the default timeout if the caller wants it */
	if ( timeout == 0 )
		{
		timeout = session->defaultEstSynchTimeout;
		}
		
	// we send and read raw bytes here as we're essentially below the gametalk protocol
	
	// we use 0xff as a magic packet as it is illegal in the gametalk world. so, we send
	// 0xff until we get one back, then we send a 1 and wait until we get a one, then we
	// send a two and wait until we get one back. if any of these timeout, or we get bad
	// data, we go back to the beginning

#define	kSynchByte			0xff

// BRAIN DAMAGE - make this a db constant
#define	kStateTimeout		0x60
	
	// clear the modem fifo
	OSGTModem_ClearFifo ( &session->modem );
	startFifoBytes = session->modem.byteCount;
	
	err = noErr;
	state = 0;
	startTime = gTicks;

//	printf ( "Starting synch with %d bytes in modem fifo\n", startFifoBytes  );
	
	while ( true )
		{

#ifndef SIMULATOR
		// on the sega, we must call ReadModemByte as we don't know if anyone is doing it in
		// our time mgr task for us
		OSGTSession_ReadHardwareModem ( session );
#endif

		switch ( state )
			{
			case 0:
				// send 0xff until we get one back				
				err = OSGTModem_ClockOutByte ( &session->modem, &mByte );
				if ( err == noErr )
					{
					if ( mByte.byte == kSynchByte )
						{
						// we got our byte, bump to state one and get a timeout for it
						state = 1;
						innerStateStart = gTicks;
						}
					}
				else
				if ( err != kNoData )
					{
					state = 5;
					}
					
				// since we didn't get one, send them a synch byte
				// if we get an error here, then we assume something is really bad
				// we use the physical layer here as it will block forever on the transmit register
				err = OSWriteSerialByte( kSynchByte );
				if ( err )
					{
					state = 5;
					}
				break;
				
			case 1:
				// send a one
				err = OSWriteSerialByte( 1 );
				if ( err )
					{
					state = 5;
					}
				else
					{
					// go wait for a one
					state = 2;
					innerStateStart = gTicks;
					}
				break;
				
			case 2:
				// wait for a one
				err = OSGTModem_ClockOutByte ( &session->modem, &mByte );
				if ( err == noErr )
					{
					if ( mByte.byte == 1 )
						{
						state = 3;
						innerStateStart = gTicks;
						}
					else
					// we may get more synch bytes here (which are ok). anything else is bad
					if ( mByte.byte != kSynchByte )
						{
						state = 0;
						}
					}
				else
				if ( err != kNoData )
					{
					// we got a bad error, quit
					state = 5;
					}
				break;
				
			case 3:
				// send a two
				err = OSWriteSerialByte( 2 );
				if ( err )
					{
					state = 5;
					}
				else
					{
					// go wait for a two
					state = 4;
					innerStateStart = gTicks;
					}
				break;
				
			case 4:
				// wait for a two
				err = OSGTModem_ClockOutByte ( &session->modem, &mByte );
				if ( err == noErr )
					{
					if ( mByte.byte == 2 )
						{
						// we're done
						state = 5;
						innerStateStart = gTicks;
						}
					else
						{
						// getting anything else at this point is a nasty error, start over
						state = 0;
						}
					}
				else
				if ( err != kNoData )
					{
					// we got a bad error, quit
					state = 5;
					}
				break;
				
			case 5:
				// if we got here because of a modem overrun error, clear the fifo and
				// start over
				if ( err == kOverrunError )
					{
					// the modem was overrun, clear the fifo and return to state 0
					OSGTModem_ClearFifo ( &session->modem );
					state = 0;
					}
				else
					{
					// we're done, go home
					return err;
					}
				break;
			}
			
		// see if we've timed out on a global scale
		if ( gTicks - startTime > timeout )
			{
			return kTimeout;
			}
		
		// if we're not at state 0, see if we've timed out at whatever state level we're
		// currently at and if we have, go back to state 0
		if ( state != 0 && gTicks - innerStateStart > kStateTimeout )
			{
			state = 0;
			}
		}
}


//
// Send one packet of control information between the two boxes. This code assumes that
// GTSession_EstablishSynch has just been called and that we have two live machines talking
// to one another with a clean line. After sending the control packet, the two machines send
// a clear line packet and then wait for their opponents clear line packet. if they timeout
// waiting, an error is returned, and the caller may resume the process
//
// BRAIN DAMAGE: Things could very quickly get fucked. We can retry several times, but at
// some point we want to give up. We may need to keep an error recover timeout around the
// whole process - if it takes too long just give the fuck up.
//
Err	_GTSession_ExchangeCommands ( GTSession * session, unsigned char send, unsigned char * receive, long timeout )
{
Err				err;
long			startTime;
GTModemByte		mByte;

#define	kClearLine	0xfe

	startTime = gTicks;
	
	// send our packet
	err = OSWriteSerialByte( send );
	if ( err != noErr )
		{
		return err;
		}
	
	// wait for theirs
	err = kNoData;
	
	while ( err == kNoData )
		{
		GTSession_ReadHardwareModem ( session );
		err = OSGTModem_ClockOutByte ( &session->modem, &mByte );
		if ( err && gTicks - startTime > timeout )
			{
			err = kTimeout;
			}
		}
	
	if ( err == noErr )
		{
		// copy the receive byte and then verify the packet
		*receive = mByte.byte;
		err = OSGTSession_ValidateControlPacket ( session, mByte.byte );
		}
		
	if ( err != noErr )
		{
		return err;
		}
		
	// send our clear line and wait for theirs
	err = OSWriteSerialByte( kClearLine );
	if ( err != noErr )
		{
		return err;
		}
	
	// wait for one
	err = kNoData;
	while ( err == kNoData )
		{
		GTSession_ReadHardwareModem ( session );
		err = OSGTModem_ClockOutByte ( &session->modem, &mByte );
		if ( err == kNoData && gTicks - startTime > timeout )
			{
			err = kTimeout;
			}
		}
	
	// getting anything other than a clear line packet is an error
	if ( err == noErr )
		{		
		if ( mByte.byte != kClearLine )
			{
			err = kBadControlPacket;
			}
		}

	if ( err != noErr )
		{
		}
	return err;
}


//
// Make sure that the control packet we just got is a valid one
//
Err	_GTSession_ValidateControlPacket ( GTSession * session, unsigned char packet )
{
Err		err;
short	frame;

	err = kBadControlPacket;
	
	if ( ISCOMMAND(packet,kReceivedToPacket) )
		{
		frame = GETCOMMANDDATA(packet,kReceivedToPacket);
		err = noErr;
		}
	else
	if ( packet == kQuitCommand )
		{
		err = noErr;
		}
	
	return err;
}



//
// Some gametalker got an error - they call us to resolve it. We know that the two
// ends are out of synch at this point. So, we call EstablishSynch to get a clear line
// back and then send a curFrame command packet to one another. From this, we determine
// who is behind and go from there.
Err	_GTSession_ErrorRecover ( GTSession * session, Err sessionErr, long timeout )
{
Err				err;
unsigned char	sendCommand;
unsigned char	receiveCommand;
long			startTime;
long			subTimeout;

	/* if we got a link closed error, just return it */
	if ( sessionErr == kLinkClosed )
		{
		return sessionErr;
		}
		
	/* use the default timeout if the caller requested it */
	if ( timeout == 0 )
		{
		timeout = session->defaultErrorRecoverTimeout;
		}
	
	subTimeout = timeout >> 4;
	if ( subTimeout == 0 )
		{
		subTimeout = 1;
		}
		
	startTime = gTicks;

	/* keep trying until we get no error or we time out */
	err = -1;
	while ( err != noErr )
		{
		// check the modem line to see if tedward can fix it
		// if we get call waiting here, we return it to the game patch
		err = OSCheckLine();
		
		// look at magic errors we get from CheckLine for things like call waiting. we want
		// to send these magic values directly back to the caller
		switch ( err )
			{
			case kConnectionLost:
			case kNoConnection:
			case kCallWaitingErr:
			case kRemoteCallWaitingErr:
#ifdef SIMULATOR
				printf ( "Checkline returned %ld. Quitting Error Recover\n", err );
#endif
				goto badError;
			
			default:
				break;
			}
			
		if ( err == noErr )
			{
			// try and reestablish a clean line
			err = OSGTSession_EstablishSynch ( session, subTimeout );
#ifdef SIMULATOR
//			printf ( "Establish Synch returned err %ld\n", err );
			printf ( "%ld", err );
#endif
			}
		
		// if we got here ok, then try and send a command to one another saying what frame
		// we're at
		if ( err == noErr )
			{
			sendCommand = kReceivedToPacket + session->recvTimeStamp;
			err = OSGTSession_ExchangeCommands ( session, sendCommand, &receiveCommand, subTimeout );
			}
		
		if ( err == noErr )
			{
			// act upon the commands
			err = OSGTSession_DoCommand ( session, sessionErr, sendCommand, receiveCommand );
			
			/* some errors that we get here we want to just bail on */
			if ( err == kLinkClosed )
				{
				return err;
				}
			
			/* any other errors mean a fault in the communications and we should continue */
			/* to try to synch */
			}
		
		// if we got an error, see if we've timed out
		if ( err != noErr && ( gTicks - startTime > timeout ) )
			{
			err = kTimeout;
			break;
			}
		}

badError:		
	return err;
}


//
// Send a link closed command to the other guy. This guy returns kLinkClosed if successful
//
Err	_GTSession_CloseSessionSynch ( GTSession * session, long timeout )
{
Err				err;
unsigned char	sendCommand;
unsigned char	receiveCommand;
long			subTimeout;

	/* use the default timeout if the caller requested it */
	if ( timeout == 0 )
		{
		timeout = session->defaultErrorRecoverTimeout;
		}
	
	subTimeout = timeout >> 2;
	if ( subTimeout == 0 )
		{
		subTimeout = 1;
		}

	// try and reestablish a clean line
	err = OSGTSession_EstablishSynch ( session, subTimeout );
	
	// if we got here ok, then send them the quit command
	if ( err == noErr )
		{
		sendCommand = kQuitCommand;
		err = OSGTSession_ExchangeCommands ( session, sendCommand, &receiveCommand, subTimeout );
		}
	
	if ( err == noErr )
		{
		// determine how to handle the resend
		// just refill the fifos for now
		err = OSGTSession_DoCommand ( session, noErr, sendCommand, receiveCommand );
		}
		
	return err;

}


//
// We sent a received a command between segas. Resolve them and continue if we can
//
Err	_GTSession_DoCommand ( GTSession * session, Err error, unsigned char sendCommand,
	unsigned char receiveCommand )
{
short	localFrame;
short	remoteFrame;
Err		err;

	err = noErr;

	// if we got or sent a quit command, then bail
	if ( ( receiveCommand == kQuitCommand ) || ( sendCommand == kQuitCommand ) )
		{
		return	kLinkClosed;
		}

	// the only remaining problem is need for a resend
	// we know the packet is valid because we checked it before
	localFrame = GETCOMMANDDATA(sendCommand,kReceivedToPacket);
	remoteFrame = GETCOMMANDDATA(receiveCommand,kReceivedToPacket);

	err = OSGTSession_DoResend ( session, localFrame, remoteFrame );
	
	return err;
}


//
// Handle the resend prototcol
// the process:
// we don't want to have the game deal with the problem before us at all
// therefore, when we return to them, they should just be able to continue
// as normal. if they are behind us, we send them packets until we have
// returned to the last real packet we processed at which point we return to
// the game. if we're behind, then we need to wait the latent number of frames
// (so their data can reach us) and then we return to the game
//
Err	_GTSession_DoResend ( GTSession * session, short localFrame, short remoteFrame )
{
Err		err;
long	delayTicks;
short	resendFrames;
short	delayFrames;

	err = noErr;

	// determine how many frames they are behind our last sent frame. if that amount
	// if less than our frame delay, delay that many frames and then resend and then
	// return to the game
	
	resendFrames = session->sendTimeStamp - remoteFrame;
	resendFrames &= kTimeStampMask;
	delayFrames = session->frameDelay - resendFrames;
	if ( delayFrames < 0 )
		{
		delayFrames = 0;
		}
		
	// delay the number of delay frames
	delayTicks = gTicks + delayFrames;
	while ( gTicks < delayTicks )
		;
	
	// send all of our catchup frames
	if ( resendFrames )
		{
		err = OSGTSession_ResendFromFrame ( session, resendFrames );
		}

	return err;
}


//
// Resend "resendFrames" number of frames
//
Err	_GTSession_ResendFromFrame ( GTSession * session, short resendFrames )
{
Err				err;
short			startPacket;
short			endPacket;
unsigned long	packet;
short			bytesInPacket;
unsigned char *	sendPtr;
long			ticks;

	err = noErr;

	bytesInPacket = session->bytesInPacket;
		
	// point at the first byte to send
	sendPtr = (unsigned char *) &packet;
	sendPtr += 4 - bytesInPacket;
	
	// figure out which packet number to start at
	endPacket = session->writeIndex;
	startPacket = endPacket - resendFrames;
	startPacket &= k1ByteFifoIndexMask;
	
	while ( startPacket != endPacket && err == noErr )
		{
		packet = GT_BuildPacket ( session->bitSize, session->sendFifo[ startPacket ] );
		
		// put the fucker down the wire
		err = OSGTModem_SendBytes ( &session->modem, bytesInPacket - 1, sendPtr );
		
		// bump to the next frame, making sure to wrap in the fifo
		startPacket = ( startPacket + 1 ) & k1ByteFifoIndexMask;
		
		// now wait for the next vbl
		ticks = gTicks;
		while ( ticks == gTicks )
			;
		}
	
	return err;
}


//
// =========================================================================================
//
// Read and write the controllers. We have different versions of these for each of the gametalk
// modes. All fifo management is done here. Local controller reads are buffered in a local fifo
// and remote ones are sent along a hardware fifo otherwise known as a modem
//
// =========================================================================================
//


//
// Send a controller read as well as placing it in the game's local fifo
// Sends 8 bit packets
//
Err _GTSession_SendController8 ( GTSession * session, long data )
{
unsigned char	byte1;
unsigned char	byte2;
short			writeIndex;
Err				err = noErr;

	asm	
		{
		move.l	OFFSET(SegaLowMem,gameVectors)+OFFSET(GameTimeLowMem,registerBase),a0
  
	// compute checksum
		moveq	#0,d1					// clear word pointer

		GETCHECKSUMTABLE(a1)
		
		move.b	data+3,d1				// snag data lsb
		move.b	(a1,d1.w),d0			// get checksum

#ifdef SIMULATOR
		// save these off for the stupid stimulator
		move.b	d0,byte1
		move.b	d1,byte2
		}
	
	// send them
	OSWriteSerialByte ( byte1 );
	OSWriteSerialByte ( byte2 );
	
	// back to asm!
	asm
		{
#else
	// tx three bytes blindly
@wait1		
		btst	#kRMtxfullBit,kReadMStatus1+1(a0)
		bne.s	@wait1		
		move.b	d0,kTxBuff+1(a0)		// send checksum

@wait2		
		btst	#kRMtxfullBit,kReadMStatus1+1(a0)
		bne.s	@wait2		
		move.b	d1,kTxBuff+1(a0)		// send data msb
#endif
		}

	
	// grab our current indices
	writeIndex = session->writeIndex;

	session->sendFifo[ writeIndex ] = data;
	
	// bump the fifos
	session->writeIndex = ( writeIndex + 1 ) & k1ByteFifoIndexMask;
	session->remoteIndex = ( session->remoteIndex + 1 ) & k1ByteFifoIndexMask;
	
	// and our send time stamp
	session->sendTimeStamp = ( session->sendTimeStamp + 1 ) & kTimeStampMask;
		
	return err;
}


//
// Read the next controller from the modem fifo. If we get an error, then bump the world...
// Receives 8 bit backets
//
long _GTSession_ReadController8 ( GTSession * session, long *localData, long * remoteData )
{
	asm	{
		movem.w	d3-d5,-(sp)
		
		move.l	session,a0
			// don't use moveq here. only d4.w saved on stack
		move.w	GTModem.byteCount(a0),d0
		cmp.w	#2,d0									// see if we have at least 2 bytes
		bge.s	@haveTwoBytes							// yes, deal with data

		}
		
	OSGTSession_ReadHardwareModem ( session );
		
	asm
		{
		cmp.l	#kNoData,d0								// passes back kNoData even if read data...BRAIN DAMAGE
		beq.s	@noErr
		tst.l	d0										// see if error
		bne		@done
		
@noErr
		move.l	session,a0								// restore a0
		move.w	GTModem.byteCount(a0),d0
		cmp.w	#2,d0									// see if we have at least 2 bytes
		bge.s	@haveTwoBytes							// yes, deal with data

		move.l	GTModem.modemErr(a0),d0					// grab any error modem might have...=BRAIN DAMAGE ReadModem returns this
		beq.s	@noModemError
		clr.l	GTModem.modemErr(a0)					// clear any modem error
		bra		@done									// return error

@noModemError
		move.l	#kNoData,d0
		bra		@done
		
	//
	// By this time we know we have enough data in the modem buffer, so go off and put it into
	// a packet. Compute checksum as we assemble the packet
	//

@haveTwoBytes
		sub.w	#2,GTModem.byteCount(a0)		// decrement byteCount by packetSize

		move.w	sr,d4							// hold sr
		move.w	#0x2700,sr
		
		GETCHECKSUMTABLE(a1)

		move.w	GTModem.readIndex(a0),d1

	// pull out the checksum byte first
		move.b	(a0,d1.w),d5					// grab modemByte data b15-8
		
		addq.w	#4,d1							// move to 2nd GTModem byte
		and.w	#kModemInBufferMask,d1			// kill upper bits if it wraps

		moveq	#0,d2
		move.b	(a0,d1.w),d2					// grab modemByte data b15-b8 in lsb
		move.b	(a1,d2.w),d3					// start computed checksum

		move.l	(a0,d1.w),d0					// grab timimg data
		and.l	#0x00ffffff,d0					// kill msb
		
		addq.w	#4,d1							// move to next GTModemByte
		and.w	#kModemInBufferMask,d1			// kill upper bits if it wraps

		move.w	d1,GTModem.readIndex(a0)		// update readIndex

		move.w	d4,sr							// restore sr
		
		cmp.b	d5,d3							// see if checksums match
		beq		@goodChecksum
		
		move.l	#kGibbledPacket,d0				// bad checksum
		addq.l	#1,GTSession.badPackets(a0)
		bra		@done

@goodChecksum
		move.l	remoteData,a1					// result data ptr
		move.l	d2,(a1)							// return assembled packet
		
		move.w	GTSession.recvTimeStamp(a0),d2	// update receive timeStamp
		addq.w	#1,d2
		and.w	#kTimeStampMask,d2
		move.w	d2,GTSession.recvTimeStamp(a0)

		move.w	GTSession.localIndex(a0),d2
		move.w	d2,d1

		addq.w	#1,d2							// move to next fifo entry
		and.w	#k1ByteFifoIndexMask,d2			// kill upper bits if it wraps
		move.w	d2,GTSession.localIndex(a0)	// update localIndex

		add.w	d1,d1							// BRAIN DAMAGE! use byte index, not struct index!
		add.w	d1,d1							// BRAIN DAMAGE! use byte index, not struct index!
		move.l	localData,a1
		add.w	#GTSession.sendFifo,a0
		move.l	(a0,d1.w),(a1)					// grab local data	

@done
		movem.w	(sp)+,d3-d5
		}
}


//
// Send a controller read as well as placing it in the game's local fifo
// Sends 12 bit packets
//
Err _GTSession_SendController12 ( GTSession * session, long data )
{
	// call the default fucker
	return _GTSession_DefaultSend ( session, data );
}


//
// Read the next controller from the modem fifo. If we get an error, then bump the world...
// Receives 12 bit backets
//
long _GTSession_ReadController12 ( GTSession * session, long *localData, long * remoteData )
{
	// call the default fucker
	return _GTSession_DefaultRead ( session, localData, remoteData );
}


//
// Send a controller read as well as placing it in the game's local fifo
// Sends 16 bit packets.
//
Err _GTSession_SendController16 ( GTSession * session, long data )
{
unsigned char	byte1;
unsigned char	byte2;
unsigned char	byte3;
short			writeIndex;
Err				err = noErr;

	asm	
		{
		move.l	OFFSET(SegaLowMem,gameVectors)+OFFSET(GameTimeLowMem,registerBase),a0
  
	// compute checksum
		moveq	#0,d1					// clear word pointer
		move.l	d1,d2
		
		GETCHECKSUMTABLE(a1)

		move.b	data+3,d2				// snag data lsb
		move.b	(a1,d2.w),d0			// get checksum
		move.b	data+2,d1				// snag data msb
		add.b	(a1,d1.w),d0			// add to checksum

#ifdef SIMULATOR
		// save these off for the stupid stimulator
		move.b	d0,byte1
		move.b	d1,byte2
		move.b	d2,byte3
		}
	
	// send them
	OSWriteSerialByte ( byte1 );
	OSWriteSerialByte ( byte2 );
	OSWriteSerialByte ( byte3 );
	
	// back to asm!
	asm
		{
#else
	// tx three bytes blindly
@wait1		
		btst	#kRMtxfullBit,kReadMStatus1+1(a0)
		bne.s	@wait1		
		move.b	d0,kTxBuff+1(a0)		// send checksum

@wait2		
		btst	#kRMtxfullBit,kReadMStatus1+1(a0)
		bne.s	@wait2		
		move.b	d1,kTxBuff+1(a0)		// send data msb

@wait3		
		btst	#kRMtxfullBit,kReadMStatus1+1(a0)
		bne.s	@wait3		
		move.b	d2,kTxBuff+1(a0)		// send data lsb
#endif
		}

	
	// grab our current indices
	writeIndex = session->writeIndex;

	session->sendFifo[ writeIndex ] = data;
	
	// bump the fifos
	session->writeIndex = ( writeIndex + 1 ) & k1ByteFifoIndexMask;
	session->remoteIndex = ( session->remoteIndex + 1 ) & k1ByteFifoIndexMask;
	
	// and our send time stamp
	session->sendTimeStamp = ( session->sendTimeStamp + 1 ) & kTimeStampMask;
		
	return err;
}


Err _GTSession_ReadController16 ( GTSession * session, long *localData, long * remoteData )
{
	asm	{
		movem.w	d3-d5,-(sp)
		
		move.l	session,a0
			// don't use moveq here. only d4.w saved on stack
		move.w	GTSession.bytesInPacket(a0),d4			// hold packet size since used a lot
		cmp.w	GTModem.byteCount(a0),d4				// see if we have at least 3 bytes
		ble.s	@haveThreeBytes							// yes, deal with data

		}
		
	OSGTSession_ReadHardwareModem ( session );
		
	asm
		{
		cmp.l	#kNoData,d0								// passes back kNoData even if read data...BRAIN DAMAGE
		beq.s	@noErr
		tst.b	d0										// see if error
		bne		@done
		
@noErr
		move.l	session,a0								// restore a0
		cmp.w	GTModem.byteCount(a0),d4				// see if we now have at least 3 bytes
		ble.s	@haveThreeBytes							// yes, deal with data

		move.l	GTModem.modemErr(a0),d0					// grab any error modem might have...=BRAIN DAMAGE ReadModem returns this
		beq.s	@noModemError
		clr.l	GTModem.modemErr(a0)					// clear any modem error
		bra		@done									// return error

@noModemError
		move.l	#kNoData,d0
		bra		@done
		
	//
	// By this time we know we have enough data in the modem buffer, so go off and put it into
	// a packet. Compute checksum as we assemble the packet
	//

@haveThreeBytes
		sub.w	d4,GTModem.byteCount(a0)		// decrement byteCount by packetSize

		move.w	sr,d4							// hold sr
		move.w	#0x2700,sr

		GETCHECKSUMTABLE(a1)

		move.w	GTModem.readIndex(a0),d1

	// pull out the checksum byte first
		move.b	(a0,d1.w),d2					// grab modemByte data b23-b16
		move.b	d2,d5							// hold received checksum bits
		
		addq.w	#4,d1							// move to 2nd GTModem byte
		and.w	#kModemInBufferMask,d1			// kill upper bits if it wraps

		move.w	(a0,d1.w),d2					// grab modemByte data b15-b8 in msb, trash in lsb
		clr.w	d0								// clear lsw
		move.b	(a0,d1.w),d0					// grab modemByte data b15-b8 in lsb
		move.b	(a1,d0.w),d3					// start computed checksum
		
		addq.w	#4,d1							// move to 3rd GTMode byte
		and.w	#kModemInBufferMask,d1			// kill upper bits if it wraps

		move.b	(a0,d1.w),d2					// grab modemByte data b7-b0 in lsb
		move.b	d2,d0							// copy data
		add.b	(a1,d0.w),d3					// add to computed checksum
		move.l	(a0,d1.w),d0					// grab timimg data
		and.l	#0x00ffffff,d0					// kill msb
		
		addq.w	#4,d1							// move to next GTModemByte
		and.w	#kModemInBufferMask,d1			// kill upper bits if it wraps

		move.w	d1,GTModem.readIndex(a0)		// update readIndex

		move.w	d4,sr							// restore sr
		
		cmp.b	d5,d3							// see if checksums match
		beq		@goodChecksum
		
		move.l	#kGibbledPacket,d0				// bad checksum
		addq.l	#1,GTSession.badPackets(a0)
		bra		@done

@goodChecksum
		move.l	remoteData,a1					// result data ptr
		move.l	d2,(a1)							// return assembled packet
		
		move.w	GTSession.recvTimeStamp(a0),d2	// update receive timeStamp
		addq.w	#1,d2
		and.w	#kTimeStampMask,d2
		move.w	d2,GTSession.recvTimeStamp(a0)

		lea		GTSession.sendFifo(a0),a0		// get closer to data
		move.w	(unsigned char*)GTSession.localIndex-(unsigned char*)GTSession.sendFifo(a0),d1
		add.w	d1,d1							// BRAIN DAMAGE! use byte index, not struct index!
		add.w	d1,d1							// BRAIN DAMAGE! use byte index, not struct index!
		move.l	localData,a1
		move.l	(a0,d1.w),(a1)					// grab local data	
		addq.w	#4,d1							// move to next fifo entry
		lsr.w	#2,d1							// BRAIN DAMAGE! use byte index, not struct index!
		and.w	#k1ByteFifoIndexMask,d1			// kill upper bits if it wraps
		move.w	d1,(unsigned char*)GTSession.localIndex-(unsigned char*)GTSession.sendFifo(a0)	// update localIndex

@done
		movem.w	(sp)+,d3-d5
		}
}


//
// Send a controller read as well as placing it in the game's local fifo
// Sends 18 bit packets
//
Err _GTSession_SendController18 ( GTSession * session, long data )
{
	// call the default fucker
	return _GTSession_DefaultSend ( session, data );
}


//
// Read the next controller from the modem fifo. If we get an error, then bump the world...
// Receives 18 bit backets
//
long _GTSession_ReadController18 ( GTSession * session, long *localData, long * remoteData )
{
	// call the default fucker
	return _GTSession_DefaultRead ( session, localData, remoteData );
}


//
// Send a controller read as well as placing it in the game's local fifo
// Sends 24 bit packets
//
Err _GTSession_SendController24 ( GTSession * session, long data )
{
unsigned char	byte1;
unsigned char	byte2;
unsigned char	byte3;
unsigned char	byte4;
short			writeIndex;
Err				err = noErr;

	asm	
		{
		move.w	d3,-(sp)
		move.l	GameGlobal(registerBase),a0
  
	// compute checksum
		moveq	#0,d1					// clear word pointer
		move.w	d1,d2
		move.w	d1,d3
		
		GETCHECKSUMTABLE(a1)
		
		move.b	data+1,d1				// snag data lsb
		move.b	(a1,d1.w),d0			// get checksum
		
		move.b	data+2,d2				// snag data lsb
		add.b	(a1,d2.w),d0			// get checksum
		
		move.b	data+3,d3				// snag data lsb
		add.b	(a1,d3.w),d0			// get checksum

#ifdef SIMULATOR
		// save these off for the stupid stimulator
		move.b	d0,byte1
		move.b	d1,byte2
		move.b	d2,byte3
		move.b	d3,byte4
		}
	
	// send them
	OSWriteSerialByte ( byte1 );
	OSWriteSerialByte ( byte2 );
	OSWriteSerialByte ( byte3 );
	OSWriteSerialByte ( byte4 );
	
	// back to asm!
	asm
		{
#else
	// tx three bytes blindly
@wait1		
		btst	#kRMtxfullBit,kReadMStatus1+1(a0)
		bne.s	@wait1		
		move.b	d0,kTxBuff+1(a0)		// send checksum

@wait2		
		btst	#kRMtxfullBit,kReadMStatus1+1(a0)
		bne.s	@wait2		
		move.b	d1,kTxBuff+1(a0)		// send data msb

@wait3		
		btst	#kRMtxfullBit,kReadMStatus1+1(a0)
		bne.s	@wait3		
		move.b	d2,kTxBuff+1(a0)		// send data msb

@wait4		
		btst	#kRMtxfullBit,kReadMStatus1+1(a0)
		bne.s	@wait4		
		move.b	d3,kTxBuff+1(a0)		// send data msb
#endif

		move.w	(sp)+,d3
		}

	
	// grab our current indices
	writeIndex = session->writeIndex;

	session->sendFifo[ writeIndex ] = data;
	
	// bump the fifos
	session->writeIndex = ( writeIndex + 1 ) & k1ByteFifoIndexMask;
	session->remoteIndex = ( session->remoteIndex + 1 ) & k1ByteFifoIndexMask;
	
	// and our send time stamp
	session->sendTimeStamp = ( session->sendTimeStamp + 1 ) & kTimeStampMask;
		
	return err;
}


//
// Read the next controller from the modem fifo. If we get an error, then bump the world...
// Receives 24 bit backets
//
long _GTSession_ReadController24 ( GTSession * session, long *localData, long * remoteData )
{
	asm	{
		movem.w	d3-d5,-(sp)
		
		move.l	session,a0
			// don't use moveq here. only d4.w saved on stack
		move.w	GTModem.byteCount(a0),d0
		cmp.w	#4,d0									// see if we have at least 4 bytes
		bge.s	@haveFourBytes							// yes, deal with data

		}
		
	OSGTSession_ReadHardwareModem ( session );
		
	asm
		{
		cmp.l	#kNoData,d0								// passes back kNoData even if read data...BRAIN DAMAGE
		beq.s	@noErr
		tst.b	d0										// see if error
		bne		@done
		
@noErr
		move.l	session,a0								// restore a0
		move.w	GTModem.byteCount(a0),d0
		cmp.w	#4,d0									// see if we have at least 4 bytes
		bge.s	@haveFourBytes							// yes, deal with data

		move.l	GTModem.modemErr(a0),d0					// grab any error modem might have...=BRAIN DAMAGE ReadModem returns this
		beq.s	@noModemError
		clr.l	GTModem.modemErr(a0)					// clear any modem error
		bra		@done									// return error

@noModemError
		move.l	#kNoData,d0
		bra		@done
		
	//
	// By this time we know we have enough data in the modem buffer, so go off and put it into
	// a packet. Compute checksum as we assemble the packet
	//

@haveFourBytes
		sub.w	#4,GTModem.byteCount(a0)		// decrement byteCount by packetSize

		move.w	sr,d4							// hold sr
		move.w	#0x2700,sr
		
		GETCHECKSUMTABLE(a1)

		move.w	GTModem.readIndex(a0),d1

	// pull out the checksum byte first
		move.b	(a0,d1.w),d5					// grab modemByte data b31-24 (checksum)
		
		addq.w	#4,d1							// move to 2nd GTModem byte
		and.w	#kModemInBufferMask,d1			// kill upper bits if it wraps

		moveq.l	#0,d2
		move.l	d2,d0
		
		move.b	(a0,d1.w),d2					// grab modemByte data b23-16 in lsb
		move.b	(a1,d2.w),d3					// start computed checksum
		swap.w	d2								// get data in high bits
		
		addq.w	#4,d1							// move to 2nd GTModem byte
		and.w	#kModemInBufferMask,d1			// kill upper bits if it wraps
		
		move.w	(a0,d1.w),d2					// get modemByte data b15-8 in msb, trash in lsb
		move.b	(a0,d1.w),d0					// get byte as word for checksum
		add.b	(a1,d0.w),d3					// add in checksum
		
		addq.w	#4,d1							// move to 3rd GTModem byte
		and.w	#kModemInBufferMask,d1			// kill upper bits if it wraps
		
		move.b	(a0,d1.w),d2					// get modemByte data b7-0 in lsb
		move.b	d2,d0							// get copy for crc tab
		add.b	(a1,d0.w),d2					// add in checksum
		
		move.l	(a0,d1.w),d0					// grab timimg data
		and.l	#0x00ffffff,d0					// kill msb
		
		addq.w	#4,d1							// move to next GTModemByte
		and.w	#kModemInBufferMask,d1			// kill upper bits if it wraps

		move.w	d1,GTModem.readIndex(a0)		// update readIndex

		move.w	d4,sr							// restore sr
		
		cmp.b	d5,d3							// see if checksums match
		beq		@goodChecksum
		
		move.l	#kGibbledPacket,d0				// bad checksum
		addq.l	#1,GTSession.badPackets(a0)
		bra		@done

@goodChecksum
		move.l	remoteData,a1					// result data ptr
		move.l	d2,(a1)							// return assembled packet
		
		move.w	GTSession.recvTimeStamp(a0),d2	// update receive timeStamp
		addq.w	#1,d2
		and.w	#kTimeStampMask,d2
		move.w	d2,GTSession.recvTimeStamp(a0)

		move.w	GTSession.localIndex(a0),d2
		move.w	d2,d1

		addq.w	#1,d2							// move to next fifo entry
		and.w	#k1ByteFifoIndexMask,d2			// kill upper bits if it wraps
		move.w	d2,GTSession.localIndex(a0)	// update localIndex

		add.w	d1,d1							// BRAIN DAMAGE! use byte index, not struct index!
		add.w	d1,d1							// BRAIN DAMAGE! use byte index, not struct index!
		move.l	localData,a1
		add.w	#GTSession.sendFifo,a0
		move.l	(a0,d1.w),(a1)					// grab local data	

@done
		movem.w	(sp)+,d3-d5
		}
}


//
// Send a controller read as well as placing it in the game's local fifo
// Sends 27 bit packets
//
Err _GTSession_SendController27 ( GTSession * session, long data )
{
	// call the default fucker
	return _GTSession_DefaultSend ( session, data );
}


//
// Read the next controller from the modem fifo. If we get an error, then bump the world...
// Receives 27 bit backets
//
long _GTSession_ReadController27 ( GTSession * session, long *localData, long * remoteData )
{
	// call the default fucker
	return _GTSession_DefaultRead ( session, localData, remoteData );
}


//
// a default implementation of the send controller code. handles all packet formats.
// is slow!!!!
//
Err _GTSession_DefaultSend ( GTSession * session, long data )
{
short			writeIndex;
long			packedData;
short			bytesInPacket;
unsigned char *	sendPtr;
Err				err;
	
	// grab our current indices
	writeIndex = session->writeIndex;
	
	// build a packet
	packedData = GT_BuildPacket ( session->bitSize, data );
	
	bytesInPacket = session->bytesInPacket;
	
	// point at the first byte to send
	sendPtr = (unsigned char *) &packedData;
	sendPtr += 4 - bytesInPacket;
	
	// take the 32 bit packet and send it then put it into our local fifo
	err = _GTModem_SendBytes ( &session->modem, bytesInPacket - 1, sendPtr );
	if ( err == noErr )
		{
		session->sendFifo[ writeIndex ] = data;
		
		// bump the fifos
		session->writeIndex = ( writeIndex + 1 ) & k1ByteFifoIndexMask;
		session->remoteIndex = ( session->remoteIndex + 1 ) & k1ByteFifoIndexMask;
		
		// and our send time stamp
		session->sendTimeStamp = ( session->sendTimeStamp + 1 ) & kTimeStampMask;
		}
		
	return err;
}


//
// a default implementation of the read controller code. handles all packet formats.
// is slow!!!!
//
long _GTSession_DefaultRead ( GTSession * session, long *localData, long * remoteData )
{
GTModemByte		mByte;
Err				err;
long			result;
short			byteCount;
short			localIndex;
unsigned short	checksum;
unsigned long	timingData;
unsigned char	*remoteBytes;


#ifdef SIMULATOR
#ifndef	USETIMEMGR
	{
	Err				err;
	unsigned char	byte;
		
		err = noErr;
		
		// actually read the modem here
		while ( err == noErr )
			{
			err = ModemReadByte ( session->modem.network.ramModem, &byte );
			if ( err == noErr )
				{
				_GTModem_ClockInByte ( &session->modem, byte, 0, 0 );
				}
			}
	}
#endif
#endif

	byteCount = session->bytesInPacket;
	*remoteData = 0;
	remoteBytes = (unsigned char *) remoteData;
	remoteBytes += 4 - byteCount;
	
	// make sure the modem has enough buffered data
	if ( session->modem.byteCount < byteCount )
		{
		// it doesn't, try reading again
#ifndef	SIMULATOR
		// we don't do this for the stimulator as a time mgr task does it for us
		
		// since we have no data, read the modem again and see if some just arrived
		err = GTSession_ReadHardwareModem ( session );
		if ( err )
			{
			return err;
			}
#endif
		// if we still don't have enough, then bail
		if ( session->modem.byteCount < byteCount )
			{
			// see if the modem has a really nasty error
			err = _GTModem_GetModemError ( &session->modem );
			
			// if not, just return noData
			if ( err == noErr )
				{
				err = kNoData;
				}
				
			return err;
			}
		}
	
	//
	// By this time we know we have enough data in the modem buffer, so go off and put it into
	// a packet
	for ( --byteCount; byteCount >= 0; --byteCount )
		{
		err = _GTModem_ClockOutByte ( &session->modem, &mByte );
		if ( err )
			{
			return err;
			}
		
		// push the byte into our packet data
		*remoteBytes++ = mByte.byte;
		}
	
	// verify the packet checksum
	err = GT_UnpackVerifyPacket ( session, remoteData );
	if ( err )
		{
		session->badPackets++;
		return err;
		}
	
	// extract the timing information from the last packet
	// we put frame count in the high word and vCount in the low word
	timingData = *(long *) &mByte;
	timingData &= 0x00ffffff;
	
	// now get the local packet
	localIndex = session->localIndex;
	*localData = session->sendFifo[ localIndex ];
	session->localIndex = ( localIndex + 1 ) & k1ByteFifoIndexMask;
	
	// bump our receive time stamp
	session->recvTimeStamp = ( session->recvTimeStamp + 1 ) & kTimeStampMask;

	return timingData;
}


unsigned long GT_BuildPacket ( short bitSize, unsigned long data )
{
short			count;
unsigned long	checksum;
			
	// let's get a checksum out of the data
	checksum = GT_ChecksumPacket ( data, bitSize );
	checksum <<= bitSize;
	data |= checksum;
	
	return data;
}


//
// Extract the data from a packet and verify it's checksum
//
Err	GT_UnpackVerifyPacket ( GTSession * session, long * packet )
{	
	asm {
		move.l	d3,-(sp)
		
	// compute checksum
		move.l	packet,a1
		move.l	(a1),d2						// grab data
		
		move.l	session,a0
		move.l	d2,d3						// extract checksum bits
		move.w	GTSession.bitSize(a0),d0
		lsr.l	d0,d3
		
		and.l	GTSession.packetMask(a0),d2	// get packet data only
		move.l	d2,(a1)						// return data to caller
		
		clr.w	d0							// clear word pointer
		
		GETCHECKSUMTABLE(a0)

		move.b	d2,d0						// snag lsb
		move.b	(a0,d0.w),d1				// get checksum
		swap	d2							// snag lsb of msw	
		move.b	d2,d0
		add.b	(a0,d0.w),d1				// add to checksum
		ror.l	#8,d2						// snag msb
		move.b	d2,d0
		add.b	(a0,d0.w),d1				// add to checksum
		swap	d2							// snag msb of lsw
		move.b	d2,d0
		add.b	(a0,d0.w),d1				// add to checksum
		
		moveq	#0,d0						// hope noErr
		cmp.b	d1,d3						// compare checksums
		beq.s	@ok							// good!
		move.l	#kGibbledPacket,d0			// bad!
@ok		move.l	(sp)+,d3
		unlk	a6
		rts
		}
}


//
// Read everything that is avail from the modem. Zero out the session's
// send buffer.
//
Err _GTSession_FlushInput(GTSession *session)
{
	OSGTModem_ClearFifo ( &session->modem );
	
	session->localIndex = 0;
	session->remoteIndex = 0;
	session->writeIndex = 0;

	session->sendTimeStamp = 0;
	session->recvTimeStamp = 0;

	return noErr;
}


////////////////////////////////////////////////////////////////////////////////////////////
//
// Checksum stuff
//

unsigned char GT_ChecksumPacket ( long data, short bitCount )
{
	asm
		{
		move.l	data,d2					// grab data
		clr.w	d1						// clear word pointer
		clr.l	d0

		GETCHECKSUMTABLE(a0)

		move.b	d2,d1					// snag lsb
		move.b	(a0,d1.w),d0			// get checksum
		swap	d2						// snag lsb of msw	
		move.b	d2,d1
		add.b	(a0,d1.w),d0			// add to checksum
		ror.l	#8,d2					// snag msb
		move.b	d2,d1
		add.b	(a0,d1.w),d0			// add to checksum
		swap	d2						// snag msb of lsw
		move.b	d2,d1
		add.b	(a0,d1.w),d0			// add to checksum
		unlk	a6
		rts
		}
}

