/*
 *	$Id
 *
 *	$Log: GameTalkPriv.h,v $
 * Revision 1.2  1995/05/10  11:11:20  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GameTalkPriv.h

	Contains:	xxx put contents here xxx

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	 7/24/94	SAH		first checked in

	To Do:
*/



#ifndef __GamePatch__
#include "GamePatch.h"
#endif


/*
*	Private game dispatched game talk calls
*
*/	

	/* general game talk protocol calls */
Err		OSGTSession_ValidateControlPacket ( GTSession * session, unsigned char packet ) = 
	CallGameOSFunction( kOSGTSessionValidateControl );
	
Err		OSGTSession_DoCommand ( GTSession * session, Err error, unsigned char sendCommand,
			unsigned char receiveCommand ) = 
	CallGameOSFunction( kOSGTSDoCommand );
	
Err		OSGTSession_DoResend ( GTSession * session, short localFrame, short remoteFrame ) = 
	CallGameOSFunction( kOSGTSDoResend );
	
Err		OSGTSession_ResendFromFrame ( GTSession * session, short resendFrames ) = 
	CallGameOSFunction( kOSGTSResendFromFrame );

Err		OSGTSession_ExchangeCommands ( GTSession * session, unsigned char send, unsigned char * receive,
			long timeout ) = 
	CallGameOSFunction( kOSGTSessionExchangeCommands );


	/* gametalk modem calls */
void	OSGTModem_Init( GTModem *modem, Boolean master) = 
	CallGameOSFunction( kOSGTModemInit );
	
Err		OSGTModem_GetModemError(	GTModem * modem ) = 
	CallGameOSFunction( kOSGTModemGetModemError );

void	OSGTModem_ClearFifo ( GTModem *modem ) = 
	CallGameOSFunction( kOSGTModemClearFifo );

void	OSGTModem_ClockInByte( GTModem *modem, unsigned char byte, unsigned char frame, unsigned char vCount ) = 
	CallGameOSFunction( kOSGTModemClockInByte );

Err		OSGTModem_ClockOutByte ( GTModem * modem, GTModemByte * byte ) = 
	CallGameOSFunction( kOSGTModemClockOutByte );

Boolean OSGTModem_AbleToSend( GTModem *modem) = 
	CallGameOSFunction( kOSGTModemAbleToSend );

Err		OSGTModem_SendBytes( GTModem *modem, short numBytes, unsigned char *bytes) = 
	CallGameOSFunction( kOSGTModemSendBytes );

Err		OSGTModem_CheckLine ( GTModem * modem ) = 
	CallGameOSFunction( kOSGTModemCheckLine );

