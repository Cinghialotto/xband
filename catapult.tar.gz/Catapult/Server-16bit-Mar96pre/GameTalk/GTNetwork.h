/*
 *	$Id
 *
 *	$Log: GTNetwork.h,v $
 * Revision 1.2  1995/05/10  11:11:08  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GTNetwork.h

	Contains:	xxx put contents here xxx

	Written by:	Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <3>	 7/24/94	SAH		Removed some unused stuff.
		 <2>	 7/22/94	SAH		Next checked in.
		 <1>	 6/20/94	DJ		first checked in

	To Do:
*/



#ifndef __GTNETWORK__
#define __GTNETWORK__

#include "GT.h"
#include "GTErrors.h"
#include "GTTester.h"
// #include "GTModem.h"

#ifdef NETWORKUSEINTERRUPTS
#include <OSUtils.h>
#include <Timer.h>

typedef struct TMInfo {
	TMTask	tmTask;
	long	tmA5;
	struct GTNetwork	*tmNetwork;
} TMInfo, *TMInfoPtr;

pascal TMInfoPtr GetTMInfo(void)
	= 0x2e89;

#endif NETWORKUSEINTERRUPTS

//
//
// We can send 40 bits per frame (2400/60)
// But using 9-bit protocol (1 start bit, 8 data bits, no stop bit), we can send 32 data bits.
//
//

//
// A network Tick is 1/300 of a second.  This is the time to clock a byte.
// 2400 / 8 = 300 bytes per second.
// There are 4 data ticks per VBL (300 / 60 = 5 ticks, but one is for start bits)
// So the buffers can move 4 bytes per frame.
#define kNumDataTicksPerVBL	4



//
// Data moves from the right to the left
//	(eg. fromMaster[kLatencyBytes-1] is entrance into the wire and fromMaster[0] is exit)
//
typedef struct GTNetwork {
	long				time;
	struct GTModem	*	masterModem;
#ifdef GT_RAMTEST
	struct RamModem * 	ramModem;
#endif

#ifdef NETWORKUSEINTERRUPTS
	short				oldSR;
	TMInfo				timetask;
#endif

} GTNetwork;

void GTNetwork_Init(GTNetwork *network, struct GTModem *master, struct RamModem * modem);
void GTNetwork_Shutdown(GTNetwork *network);

void GTNetwork_RunVBL(GTNetwork *network);
void GTNetwork_Tick(GTNetwork *network);

#ifdef NETWORKUSEINTERRUPTS

#define kNetworkInterruptMilliseconds		1

void GTInstallTimeTask(GTNetwork *network);
void GTRemoveTimeTask(GTNetwork *network);
pascal void GTTickProc(void);
void GTDisableInterrupts(GTNetwork *network);
void GTEnableInterrupts(GTNetwork *network);

#endif

#endif __GTNETWORK__

