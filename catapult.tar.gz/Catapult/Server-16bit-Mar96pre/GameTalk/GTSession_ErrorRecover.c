/*
 *	$Id
 *
 *	$Log: GTSession_ErrorRecover.c,v $
 * Revision 1.2  1995/05/10  11:11:13  jhsia
 * switch to cvs keywords
 *
 */

// #define DEBUG 1

/*
	File:		GTSession_ErrorRecover.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<13>	 7/22/94	SAH		Hail satan!
		<12>	 7/15/94	SAH		Don't call GTModem_NumBytesAvailToRead if you really want to
									read anything.
		<11>	 7/13/94	DJ		more harshness
		<10>	 7/13/94	DJ		twiddled timeouts
		 <9>	 7/13/94	DJ		trying to make it work on segas
		 <8>	 7/13/94	DJ		fixed timeout bug in slavesync, also losync resend logic in
									controlnibble read sections (ie. syncing should be more reliable
									now)
		 <7>	  7/8/94	DJ		timeout fix in slavesync
		 <6>	  7/8/94	DJ		turned timeouts back on in slave side
		 <5>	 6/28/94	DJ		GetCurrentTime shit
		 <4>	 6/21/94	BET		(With DJ) Make it work on Fred instead of just compile.
		 <3>	 6/21/94	HEC		For Fred
		 <2>	 6/21/94	BET		Managerize
		 <1>	 6/20/94	DJ		first checked in

	To Do:
*/

#ifdef NEVER

#include <stdio.h>


#include "GT.h"
#include "GTErrors.h"
#include "GTModem.h"
#include "GTNetwork.h"
#include "GTErrorRecover.h"

#ifndef __SERVER__
#include "time.h"
#endif


//
// send a stream of syncs until we get them back from the slave.
// if the slave is in readcontrollers, it will detect these bogus controllers and pop
// into SlaveRecover.
//
// once Master gets kNumPingedSyncs , he then starts sending control information.
// when the server's control info is done, he starts processing slave's controls.
// when they are done they exchange a kClearlineControl and they are finished.
//
Err _GTSession_MasterErrorRecover(GTSession *session)
{
Boolean masterInSync;
Err		err;
unsigned char	vbl, ticksAfterVBL;
unsigned char control, byte, sendByte;
Boolean	done, processedAnEvent, nextByteIsResendData;
long	i;
long	startTime, delayTime, slaveTime, time, killTime;


	killTime = GetCurrentTime();

	// this timer figures bails if the line is excessively noisy.
	//	eg. if we don't successfully get through this recovery after 10 seconds or so...
start:
//printf("start mastersync loop\n");

	startTime = GetCurrentTime();
	time = GetCurrentTime();
	delayTime = startTime - killTime;
	if(delayTime > kMaxResyncTimeout)
	{
bail:
		ERROR_MESG("GTSession_MasterErrorRecover: timed out on resync\n");
		return(kDroppedCarrier);
	}


	// bogus treat in case one of the sides got into their kNumPingedSyncs loop awhile ago
	//
	sendByte = 0x01;
	GTSession_BlockingSendRawByte(session, sendByte);


	// then send and look for kNumPingedSyncs losyncs.
	//
	sendByte = kLowSyncControl;
	for(i = 0; i < kNumPingedSyncs; )
	{
		// a timeout here in case line goes down.
		delayTime = GetCurrentTime() - killTime;
		if(delayTime > kMaxResyncTimeout)
			goto bail;


		if(GTModem_ReadByte(&session->modem, &byte, &vbl, &ticksAfterVBL))
		{
			if(byte == kLowSyncControl)
				i++;
			else
				i = 0;	// should we branch up to start.. cuz line is bad?
		}

		GTSession_BlockingSendRawByte(session, sendByte);
	}


	// do our control data
	// - kResendControler packets.
	// - kDoneControl
	
	sendByte = kResendController;
	GTSession_BlockingSendControlNibble(session, sendByte);
	sendByte = (session->recvTimeStamp & kNibbleMask);
	GTSession_BlockingSendControlNibble(session, sendByte);

	sendByte = kDoneControl;
	GTSession_BlockingSendControlNibble(session, sendByte);


	// process slave's control poop.
	//
	slaveTime = GetCurrentTime();
	nextByteIsResendData = false;
	for(done = processedAnEvent = false; done == false;)
	{
		// hmmm. maybe slave didn't get the kDoneControl.  start again.
		time = GetCurrentTime();
		delayTime = time - slaveTime;
		if(delayTime > kTwoSeconds)	// BRAIN DAMAGE: this should be a factor of the line latency really.
			goto start;				// eg. 2 * latency is expected, so make it 4*latency?


		byte = 0;
		err = GTSession_ReadControlNibble(session, &byte);
		if(err == kNoError)
		{
			if(nextByteIsResendData){
				session->resendFromTimeStamp = byte;
				nextByteIsResendData = false;
//printf("slave wants resend from %ld... current sent is %ld\n", (long)session->resendFromTimeStamp, (long)session->sendTimeStamp);
			} else 
				switch(byte)
				{
					case kDoneControl:	done = true;
						break;
				
					case kResendController:	nextByteIsResendData = true;
						break;
					
					default:	ERROR_MESG("GTSession_MasterErrorRecover: got an unknown control packet\n");
								goto start;
						break;
			
				}
			processedAnEvent = true;
			slaveTime = GetCurrentTime();	// reset this wee timer cuz we got a good control pkt.
		}
		else if (err == kGibbledPacket)
		{
			ERROR_MESG("GTSession_MasterErrorRecover: got a gibbled control packet\n");
			goto start;
		}
		else if( err == kLowSync)
		{
#if 1
			if(processedAnEvent)
			{
				// this must be a spurious kLowSync because the slave never generates them, and it never
				// pings them back to us after it has sent its first control message.
				//
				ERROR_MESG("GTSession_MasterErrorRecover: got a lowSync while reading slave control packets\n");
				goto start;
			}
/*
			else
				slaveTime = GetCurrentTime();	// reset this wee timer cuz the line appears to be up.
												// it's OK to get err == kLowSync if we've yet to read the first control packet.
*/
#else

			// slave doesn't ping 'em back after kNumPingedSyncs loop, so any losync we get is an error.
			//
			ERROR_MESG("GTSession_MasterErrorRecover: got a lowSync while reading slave control packets\n");
			goto start;

#endif


		}
		// it's OK to get err == kNoData

//		GTNetwork_Tick(network);
	}


	// send clearlineControl ( + onedelay  duds if you want em synced by time)
	//
	sendByte = kClearLineControl;
	GTSession_BlockingSendControlNibble(session, sendByte);

	
	// wait till we get it back (use pullsend if sending duds too).
	//
	slaveTime = GetCurrentTime();
	for(done = false; done == false;)
	{
		// hmmm. where is the slave's kClearLineControl?  start again if timeout
		time = GetCurrentTime();
		delayTime = time - slaveTime;
		if(delayTime > kTwoSeconds)
			goto start;

		byte = 0;
		err = GTSession_ReadControlNibble(session, &byte);
		if(err == kNoError)
		{
			if(byte == 	kClearLineControl)
				done = true;
			else
			{
				ERROR_MESG("GTSession_MasterErrorRecover: got an unknown control packet, expecting kClearLineControl\n");
				goto start;
			}
		}
		else if(err == kGibbledPacket || err == kLowSync)
		{
			ERROR_MESG("GTSession_MasterErrorRecover: got a gibbled control packet. expecting kClearLineControl\n");
			goto start;
		}
	
//		GTNetwork_Tick(network);
	}
	
	return(kNoError);
}



//
// go into read stream mode.  this will cause master to timeout and go into MasterErrorRecover.
//
// we look for sync bytes (we must get a bunch of them).
// and then we start echoing them back.
// then after kNumPingedSyncs + roundtrip delay #losyncs, we start looking for control nibbles and processing them.
//
// once we have processed the master's control nibbles, we send ours.
//
// when everyone is done controlling, we send clearline and resume.
//
Err _GTSession_SlaveErrorRecover(GTSession *session)
{
Boolean masterInSync;
Err		err;
unsigned char	vbl, ticksAfterVBL;
unsigned char control, byte, sendByte;
Boolean	done, processedAnEvent, nextByteIsResendData;
long	i;
long	startTime, delayTime, slaveTime, time, killTime;
long fuckCount;

	// this timer figures bails if the line is excessively noisy.
	//	eg. if we don't successfully get through this recovery after 10 seconds or so...
	//
	killTime = GetCurrentTime();

start:
//printf("start slavesync loop\n");
	startTime = GetCurrentTime();
	delayTime = startTime - killTime;
	if(delayTime > kMaxResyncTimeout)
	{
bail:
		ERROR_MESG("GTSession_SlaveErrorRecover: timed out on resync\n");
		return(kDroppedCarrier);
	}

fuckCount = 0;

	// bogus treat in case one of the sides got into their kNumPingedSyncs loop awhile ago
	//
	sendByte = 0x01;
	GTSession_BlockingSendRawByte(session, sendByte);

	// then look for kNumPingedSyncs losyncs and pong them back.
	//
	for(i = 0; i < kNumPingedSyncs; )
	{
		// a timeout here in case line is very noisy and we're out of sync with master
		delayTime = GetCurrentTime() - killTime;
		if(delayTime > kMaxResyncTimeout)
			goto bail;

		if(GTModem_ReadByte(&session->modem, &byte, &vbl, &ticksAfterVBL))
		{
			if(byte == kLowSyncControl)
			{
				i++;
				GTSession_BlockingSendRawByte(session, byte);
			} else
				i = 0;	// should we branch up to start.. cuz line is bad?
		}

//		GTNetwork_Tick(network);
	}

	// then start processing master control packets.
	// The timeout on this loop will restart if each command takes longer than 1 second.
	// This may need to be retuned when we do real resends etc.
	//
	slaveTime = GetCurrentTime();
	nextByteIsResendData = false;
	for(done = processedAnEvent = false; done == false;)
	{
		// a timeout here in case line goes down.
		delayTime = GetCurrentTime() - slaveTime;
		if(delayTime > kTwoSeconds)	// BRAIN DAMAGE: this should be a factor of the line latency really.
			goto start;				// eg. 2 * latency is expected, so make it 4*latency?

		err = GTSession_ReadControlNibble(session, &byte);
		if(err == kNoError)
		{
			if(nextByteIsResendData)
			{
				session->resendFromTimeStamp = byte;
				nextByteIsResendData = false;
//printf("master wants resend from %ld... current sent is %ld\n", (long)session->resendFromTimeStamp, (long)session->sendTimeStamp);

			} else 
				switch(byte)
				{
					case kDoneControl:	done = true;
						break;
				
					case kResendController:	nextByteIsResendData = true;
						break;
				
					default:	ERROR_MESG("GTSession_SlaveErrorRecover: got an unknown control packet\n");
								goto start;
						break;
			
				}
			processedAnEvent = true;
			slaveTime = GetCurrentTime();	// reset this wee timer cuz we got a good control pkt.
		}
		else if (err == kGibbledPacket)
		{
			ERROR_MESG("GTSession_SlaveErrorRecover: got a gibbled control packet\n");
			goto start;
		}
		else if (err == kLowSync)
		{
		fuckCount++;
			if(processedAnEvent)
			{
				// master must have encountered an error and is back trying to sync
				ERROR_MESG("GTSession_SlaveErrorRecover: got a lowSync while reading master control packets\n");
				goto start;
			} else
			{
// do not send back to him, cuz he may be still waiting for kNumPinged (eg. a pinged losync got dropped)
// and we don't want him to think we're still in our little loop waiting for his losyncs.
//
				sendByte = kLowSyncControl;
				GTSession_BlockingSendRawByte(session, sendByte);

				//
				// No!  Don't reset this timer... cuz you could be getting a bogus stream
				// of kLowSyncControl (eg. 0xFF) if modems hung up
				//
				// slaveTime = GetCurrentTime();	// reset this wee timer cuz the line appears to be up.
			}

			// it's OK to get err == kLowSync if we've yet to read the first control packet.
		}
		
		// it's OK to get err == kNoData cuz the master doesn't keep the pipe full after first control packet.

//		GTNetwork_Tick(network);
	}


	// now do our control
	// - kResendControler packets.
	// - kDoneControl
	sendByte = kResendController;
	GTSession_BlockingSendControlNibble(session, sendByte);
	sendByte = (session->recvTimeStamp & kNibbleMask);
	GTSession_BlockingSendControlNibble(session, sendByte);

	sendByte = kDoneControl;
	GTSession_BlockingSendControlNibble(session, sendByte);


	// look for the clearlineControl and then onedelay duds (read and eat 'em).
	//
	slaveTime = GetCurrentTime();
	for(done = false; done == false;)
	{
		// hmmm. maybe master didn't get the kDoneControl.  start again.
		time = GetCurrentTime();
		delayTime = time - slaveTime;
		if(delayTime > kTwoSeconds)
			goto start;

		err = GTSession_ReadControlNibble(session, &byte);
		if(err == kNoError)
		{
			if(byte == 	kClearLineControl)
				done = true;
			else
			{
				ERROR_MESG("GTSession_SlaveErrorRecover: got an unknown control packet, expecting kClearLineControl\n");
				goto start;
			}
		}
		else if(err == kGibbledPacket || err == kLowSync)
		{
			ERROR_MESG("GTSession_SlaveErrorRecover: got a gibbled control packet. expecting kClearLineControl\n");
			goto start;
		}
	
//		GTNetwork_Tick(network);
	}

	// send clearlineControl ( + onedelay  duds if you want em synced by time)
	sendByte = kClearLineControl;
	GTSession_BlockingSendControlNibble(session, sendByte);

	return(kNoError);

}


//
// Resend controllers.  use session->resendFromTimeStamp.
// send everything from session->resendFromTimeStamp to session->sendTimeStamp
//
Err _GTSession_ResendControllers(GTSession *session)
{
short i, ii, count;


	if(session->packetSize != 3)
	{
		ERROR_MESG("GTSession_ResendControllers: I only work with 3 byte packets so far  6/19/94 dj\n");
		return(kNoError);
	}
	
	// special case: before we've even sent any controllers.... nothing to resend!
	//
	if(!session->outBufferLast && !session->wrappedOutBuffer)
		return(kNoError);

	// he didn't encounter an error.  he's waiting for the next controller (that we haven't send yet cuz we got this read error).
	//
	if(session->resendFromTimeStamp == session->sendTimeStamp)
	{
		ERROR_MESG("GTSession_ResendControllers: he's cool.  he is waiting for the controller that we've not sent yet.  Yay!\n");
		return(kNoError);
	}

/****
	//
	// This is a case that should never happen on the real game, but may happen on a ping-pong test.
	// This is because the master has sent a packet, eg #4 that the slave hasn't received.
	// Then, either the master times out waiting for a response to #4, or some  noise comes
	// in that generates a spurious #4 that was never sent by the slave.
	// So the master requests a resend of packet #4 from the slave, but the slave has
	// only sent and received packet #3.  What should I do in this case?
	//
	// Maybe one of the control messages can be a tell of which frame # we think we're both on.
	//
	// Actually, in this case the slave should request packet #4, which the server will then
	// send.  And the server will receive it and do the proper thing (ie. pong it back).
	// So this isn't an error condition at all.
	//
	if(session->resendFromTimeStamp > session->sendTimeStamp)
	{
		ERROR_MESG("GTSession_ResendControllers: Dave's wacko state: he wants a packet we've not sent yet, so I must not have received it or whatever... AOK\n");
		return(kNoError);
	}
*****/

	// work back from outBufferLast to find packet with timestamp == session->resendFromTimeStamp
	//
	count = 0;
	i = session->outBufferLast;

	while(count++ < kOutBufferLength)
	{
		if(--i < 0)
		{
			if(!session->wrappedOutBuffer)
			{
				// There are three possiblities:
				//	1. - box is asking for a resend of something we haven't sent yet.  he either got it spuriously (line noise)
				//		or we are a frame behind him, or we are a ping ponger, and we haven't received his ping.
				//	2. - the resend data is gibbled and checksum in ReadNibble in ErrorRecover didn't find it.
				//	3. - this code is a tub of poo and has a logical bug.
				//
				// let's assume that it is option #1.
				//
				ERROR_MESG("GTSession_ResendControllers: can't find packet with matching timestamp to resend. I hope this works!?!?\n");
				return(kNoError);
//				Debugger();
//				return(kFucked);
			}
			i = kOutBufferLength - 1;
		}
		
		if(session->outBuffer[i].timestamp == session->resendFromTimeStamp)
			break;
	}
	
	if(count > kOutBufferLength)
	{
		// Same story here as above.  3 possibilities for why we can't find a packe with matching timestamp to resend.
		// Let's assume it is because we are 1 or more frames behind the peer (perhaps we are a pong program and
		// we didn't receive his ping).
		//
		ERROR_MESG("GTSession_ResendControllers: can't find packet with matching timestamp to resend. I hope this works!?!?\n");
		return(kNoError);
//		ERROR_MESG("GTSession_ResendControllers: impl error... can't find packet with matching timestamp to resend!\n");
//		Debugger();
//		return(kFucked);
	}

	ASSERT_MESG(i < kOutBufferLength, "GTSession_ResendControllers: impl error. why is i >= kOutBufferLength?\n");

	//
	// Now resend.
	//
	for(; i != session->outBufferLast; )
	{	
		for(ii = 0; ii < 3; ii++)
			GTSession_BlockingSendRawByte(session, session->outBuffer[i].bytes[ii]);
		if(++i == kOutBufferLength)
			i = 0;
	}
	
	return(kNoError);
}



// build a 3-bit checksum, stuff into a byte, stuff down the modem.
//
Err GTSession_BlockingSendControlNibble(GTSession *session, unsigned char control)
{
unsigned char checksum, byte;

	control &= kNibbleMask;		// 0x1f
	checksum = GT_GenerateChecksum3(control);
	byte = checksum << 5;
	byte |= control;

	GTSession_BlockingSendRawByte(session, byte);
	
	return(kNoError);
}


// build a 3-bit checksum, stuff into a byte, stuff down the modem.
//
Err GTSession_SendControlNibble(GTSession *session, unsigned char control)
{
unsigned char checksum, byte;

	control &= kNibbleMask;		// 0x1f
	checksum = GT_GenerateChecksum3(control);
	byte = checksum << 5;
	byte |= control;

	if(!GTModem_AbleToSend(&session->modem))
		return( kNoSpace );
	GTModem_SendByte(&session->modem, byte);
	return(kNoError);

}

// read from modem or bufferByte.  extract and check 3 bit checksum.
//
Err GTSession_ReadControlNibble(GTSession *session, unsigned char *control)
{
unsigned char checksum, checksum1, byte;
unsigned char vbl, ticksAfterVBL;

	if(!GTModem_ReadByte(&session->modem, &byte, &vbl, &ticksAfterVBL))
		return(kNoData);
	
	if(byte == kLowSyncControl)
		return(kLowSync);

	checksum = byte >> 5;
	byte &= kNibbleMask;		// 0x1f
	checksum1 = GT_GenerateChecksum3(byte);
	if(checksum == checksum1)
	{
		*control = byte;
		return(kNoError);
	}
	return(kGibbledPacket);
}

#endif
