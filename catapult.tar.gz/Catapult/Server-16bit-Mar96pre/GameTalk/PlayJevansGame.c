/*
 *	$Id
 *
 *	$Log: PlayJevansGame.c,v $
 * Revision 1.2  1995/05/10  11:11:21  jhsia
 * switch to cvs keywords
 *
 */

//#define MESSAGES 1
/*
	File:		PlayJevansGame.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <6>	  7/8/94	DJ		added timeout in master
		 <5>	 6/29/94	DJ		fixed count init for slave
		 <4>	 6/28/94	DJ		GetCurrentTime shit
		 <3>	 6/21/94	BET		(With DJ) Make it work on Fred instead of just compile.
		 <2>	 6/21/94	HEC		For Fred
		 <1>	 6/20/94	DJ		first checked in

	To Do:
*/


#if defined(__SERVER__) || defined(SIMULATOR)
#include <stdio.h>
#endif

#include "GT.h"
#include "GTErrors.h"
#include "GTModem.h"
#include "GTNetwork.h"
#include "GTErrorRecover.h"
#include "PhysicalLayer.h"
#include "errors.h"

#ifndef __SERVER__
#include "time.h"
#endif


#define kPingPongTrips			500000		// how long to run it for.

#define kMaxTimeBetweenReads	10			// 10 vbls max wait for a controller read


#define kMaxNumOneWayTripWaits	3		// waiting for a controller read.  how many one way delays will we wait.

void PlayJevansGame( Boolean master);


static long vbltime;

static void WaitForVBL(void)
{
long	vbl;
long a = 0;

	for(vbl = vbltime; vbl == vbltime; a++)
		vbl = GetCurrentTime();

	vbltime = vbl;
}


void PlayJevansGame( Boolean master)
{
GTSession 		session;
long			latencyErrors, masterErrors, slaveErrors, uncaughtErrors;
unsigned char	readByte1, readByte2, sendByte1, sendByte2;
short			timeSinceLastRead;
short			frameLatency, i;
unsigned char	vbl, fractVbl;
Boolean			sendable;
Err				err;
unsigned char 	sendByte;
register long 			count;
char			hold[128], foo;
unsigned char	bar;
long			lastReadFromSlave, delayTime;


	PUTearDownServerTalk();

	GTSession_Init(&session, master, 3);	// master session. 3 byte packets


	if(master)
	{
		frameLatency = GTSession_MasterSync(&session);	// compute latency and frame delay
frameLatency = 3;

#if defined(__SERVER__) || defined(SIMULATOR)
		sprintf(hold, "frame delay is %ld", (long)frameLatency);
		MESG(hold);
#endif

		if(frameLatency < 0)
		{
			ERROR_MESG("Dropped carrier in GTSession_MasterSync");
			return;
		}

		sendable = true;
		sendByte1 = sendByte2 = 0;
		readByte1 = readByte2 = 0;

		latencyErrors = 0;
		masterErrors = 0;
		slaveErrors = 0;
		uncaughtErrors = 0;
		count = 0;

		GTSession_FlushInput(&session);

syncMaster:	
		if(GTSession_MasterErrorRecover(&session) != kNoError)
		{
			MESG("couldn't sync up");
			GTSession_Shutdown(&session);
			return;
		}
	
		MESG("synced");

		if(GTSession_ResendControllers(&session) != kNoError)
		{
			ERROR_MESG("main: GTSession_ResendControllers returned an error!?\n");
			//Debugger();
		}
		//
		// after a sync we should spin waiting for a controller read.  at all other times
		// there should be one at each vbl.
		//



		sendByte = 0;
		vbltime = GetCurrentTime();
		timeSinceLastRead = 0;

		lastReadFromSlave = GetCurrentTime();

		for(;;)
		{

//			WaitForVBL();

			delayTime = GetCurrentTime() - lastReadFromSlave;
			if(delayTime > kMaxTimeBetweenReads)
			{
				MESG("delayTime > kMaxTimeBetweenReads");
				goto syncMaster;
			}
			

			// send current controller.
			if(sendable)
			{
				if(GTSession_Send2Bytes(&session, sendByte1, sendByte2) != kNoError)
				{
					ERROR_MESG(" send buffer is full.  fuck\n");
					goto syncMaster;
				}
				else
					sendable = false;
			}

			err = GTSession_Read2Bytes(&session, &readByte1, &readByte2, &vbl, &fractVbl);
			if(err == kNoError)
			{
		
				if(readByte1 != sendByte1 || readByte2 != sendByte2)
				{
					ERROR_MESG("read controllers don't match sent controllers... but checksum didn't catch it!?!\n");
					uncaughtErrors++;
				}
				sendByte1++;
				sendByte2++;

				if(session.recvTimeStamp != session.sendTimeStamp)
				{
#if defined(__SERVER__) || defined(SIMULATOR)
					sprintf(hold, "recv timestamp %ld != send timestamp %ld\n", (long)session.recvTimeStamp, (long)session.sendTimeStamp);
					MESG(hold);
#endif
//					Debugger();
				}
			
				lastReadFromSlave = GetCurrentTime();
				timeSinceLastRead = 0;
				sendable = true;
				count++;
				if(!(count % 100))
				{
#if defined(__SERVER__) || defined(SIMULATOR)
					sprintf(hold, "%ld trips with %ld masterErrors, %ld slaveErrors, %ld latencyErrors, %ld uncaughtErrors",
						count, masterErrors, slaveErrors, latencyErrors, uncaughtErrors);
					MESG(hold);
#endif
				}
				
				if(count == kPingPongTrips)
					break;	// all done!
			}
		
			if(err == kGibbledPacket)
			{
				masterErrors++;
				ERROR_MESG("Shit.  got a gibbled packet.\n");
				goto syncMaster;
			}

			if(err == kLowSync)
			{
				slaveErrors++;
				ERROR_MESG("Shit.  got a lowsync packet.\n");
				goto syncMaster;
			}

			if(err == kNoData)
			{
/*
				if(timeSinceLastRead++ > kMaxNumOneWayTripWaits*frameLatency)
				{
					ERROR_MESG("No controller read for frameLatency vbls, recyncing\n");
					latencyErrors++;
					goto syncMaster;
				}
*/
			}

		}







	}
	else
	{
		count = 0;

		frameLatency = GTSession_SlaveSync(&session);	// compute latency and frame delay
// frameLatency = 3;

//printf("frame delay is %ld\n", (long)frameLatency);
		if(frameLatency < 0)
		{
			ERROR_MESG("Dropped carrier in GTSession_SlaveSync");
			return;
		}

syncSlave:
		if(GTSession_SlaveErrorRecover(&session) != kNoError)
		{
			MESG("couldn't sync up");
			GTSession_Shutdown(&session);
			return;
		}
	
		MESG("synced");

		if(GTSession_ResendControllers(&session) != kNoError)
		{
			ERROR_MESG("main: GTSession_ResendControllers returned an error!?\n");
			//Debugger();
		}

		for(;;)
		{
//			WaitForVBL();

			err = GTSession_Read2Bytes(&session, &readByte1, &readByte2, &vbl, &fractVbl);
			if(err == kNoError)
			{
				for(;;)
				{
					if(GTSession_Send2Bytes(&session, readByte1, readByte2) != kNoError)
					{
						ERROR_MESG(" send buffer is full.  fuck\n");
						goto syncSlave;
					} else
					{
						if(session.recvTimeStamp != session.sendTimeStamp)
						{
							//printf("recv timestamp %ld != send timestamp %ld\n", (long)session.recvTimeStamp, (long)session.sendTimeStamp);
							//Debugger();
						}
						
						count++;
						break;
					}
				
				}
			}
			if(err == kGibbledPacket)
			{
				ERROR_MESG("Shit.  got a gibbled packet.  resyncing\n");
				goto syncSlave;
			}

			if(err == kLowSync)
			{
				MESG("slave resyncing");
				goto syncSlave;
			}

			if(count == kPingPongTrips) 
				break;	// all done!
		}
		
	}
	
	MESG("all done");
	GTSession_Shutdown(&session);
}

