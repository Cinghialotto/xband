/*
 *	$Id
 *
 *	$Log: GTTester.c,v $
 * Revision 1.2  1995/05/10  11:11:17  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GTTester.c

	Contains:	xxx put contents here xxx

	Written by:	Shannon Holland

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <1>	 7/22/94	SAH		first checked in

	To Do:
*/


#include "GTTester.h"
#include "GT.h"
#include "Heaps.h"
#include "Time.h"
#include "PhysicalLayer.h"
#include "NetErrors.h"
#include "BoxSer.h"

#ifdef SIMULATOR
#include <stdio.h>
#endif


#undef	kModemBufferSize
#define	kModemBufferSize	40



// some test defines
#define	kTestFrames			10000
#define	kErrorTolerance		10


Boolean		DoModemTask ( RamModem * modem );
void		SegaGTTestVBL ( void );


#ifdef SIMULATOR
RamModem *			modem1 = 0L;
RamModem *			modem2 = 0L;
long				gGoodPackets;
long				gFrameCount;
long				gMissedData;
long				gErrors;
long				gMaxConsecutive;
long				gConsecutive;

#define	gSession		(modem1->session)

#else

typedef
struct	GTTestVars
{
	GTSession * 	session;
	long			goodPackets;
	long			frameCount;
	long			missedData;
	long			errors;
	long			maxConsecutive;
	long			consecutive;
} GTTestVars;

#define	testVars		((GTTestVars *) (0x10000 - sizeof(GTTestVars)))

#define	gSession		testVars->session
#define	gGoodPackets	testVars->goodPackets
#define	gFrameCount		testVars->frameCount
#define	gMissedData		testVars->missedData
#define	gErrors			testVars->errors
#define	gMaxConsecutive	testVars->maxConsecutive
#define	gConsecutive	testVars->consecutive

#endif

// create some buffers 
void DoGTTest ( void )
{
short				count;
unsigned char		data;
unsigned char * 	bytePtr;
long				time;
Err					err;
Boolean				done1;
Boolean				done2;
#ifndef SIMULATOR
RamModem *			modem1 = 0L;
long				saveVBL;
#endif

	gGoodPackets = 0;
	gFrameCount = 0;
	gMissedData = 0;
	gErrors = 0;
	gMaxConsecutive = 0;
	gConsecutive = 0;

	done1 = false;
#ifdef USERAMMODEMS
	done2 = false;
#else
	done2 = true;
#endif
	
#ifdef USERAMMODEMS
	// create and init the ram modems
	modem1 = NewMemoryClear ( kTemp, sizeof(RamModem) );
	modem1->size = kModemBufferSize;
	modem1->firstByte = 'A';
	modem1->nextByte = modem1->firstByte;
	modem1->lastByte = 'Z';
	modem1->transmitEnd = modem1->transmit + kModemBufferSize;
	modem1->id = 1;
	modem1->bytesAvail = 0;
	
	modem2 = NewMemoryClear ( kTemp, sizeof(RamModem) );
	modem2->size = kModemBufferSize;
	modem2->firstByte = 'A';
	modem2->nextByte = modem2->firstByte;
	modem2->lastByte = 'Z';
	modem2->transmitEnd = modem2->transmit + kModemBufferSize;
	modem2->id = 2;
	modem2->bytesAvail = 0;
	
	gSession = NewMemory ( kTemp, sizeof(GTSession) );
	modem2->session = NewMemory ( kTemp, sizeof(GTSession) );
#else
	// create and init the ram modems
	modem1 = NewMemoryClear ( kTemp, sizeof(RamModem) );
	modem1->size = kModemBufferSize;

	modem1->firstByte = 'A';
	if ( IsBoxMaster() )
		{
		modem1->firstByte += 32;
		}
		
	modem1->nextByte = modem1->firstByte;
	modem1->lastByte = modem1->firstByte + 25;

	modem1->transmitEnd = modem1->transmit + kModemBufferSize;
	modem1->id = 1;
	modem1->bytesAvail = 0;

	gSession = NewMemory ( kTemp, sizeof(GTSession) );
	modem1->session = gSession;
#endif

#ifdef USERAMMODEMS

	// connect the two modems
	modem1->line = modem2;
	modem2->line = modem1;
	
	modem1->writePtr = modem2->transmit;
	modem1->readPtr = modem1->transmit;
	
	modem2->writePtr = modem1->transmit;
	modem2->readPtr = modem2->transmit;
#endif

#if 0
	// read the modem a few times to get rid of some shit
	err = 1;
	while ( err != kNoByteReady )
		{
		err = PUReadSerialByte ( &data );
		printf ( "received %d, error %ld while clearing\n", data, err );
		}
#endif
	
#ifdef USERAMMODEMS
	// create the gametalk session
	GTSession_Init ( modem1->session, true );
	GTSession_SetGTPacketFormat ( modem1->session, k18BitData );
	GTSession_SetLatency ( modem1->session, 3 );
	
	GTSession_Init ( modem2->session, false );
	GTSession_SetGTPacketFormat ( modem2->session, k18BitData );
	GTSession_SetLatency ( modem2->session, 3 );

	// set the ram modems in the network
	modem1->session->modem.network.ramModem = modem1;
	modem2->session->modem.network.ramModem = modem2;
#else
	// create the gametalk session
	GTSession_Init ( gSession, IsBoxMaster() );
	GTSession_SetGTPacketFormat ( gSession, k18BitData );
	GTSession_SetLatency ( gSession, 3 );
#endif


#ifndef SIMULATOR
	// load the GTTester VBL
	saveVBL = *(long *) 0x78;
	*(long *) 0x78 = (long) SegaGTTestVBL;
#endif

#ifndef USERAMMODEMS
	// we need to establish synch between the two yakkers
	err = GTSession_EstablishSynch ( modem1->session, 10000 );
	if ( err )
		{
		ERROR_MESG( "Fucker: couldn't establish synch" );
		return;
		}
#endif
	
	// prefill the fifo's before we go
	GTSession_PrefillFifo ( gSession, '1' );
#ifdef USERAMMODEMS
	GTSession_PrefillFifo ( modem2->session, '2' );
#endif

#if 0
	// delay our frame delay number of frames
	time = GetCurrentTime() + 3;
	while ( GetCurrentTime() < time )
		;
#endif
	
	// we run between the two tasks, using GetCurrentTime as our timebase, calling
	// each of them once a tick
	time = GetCurrentTime();
#ifdef SIMULATOR
	while ( ( !done1 || !done2 ) && !Button() && gFrameCount != kTestFrames )
#else
	while ( ( !done1 || !done2 ) && gFrameCount != kTestFrames )
#endif
		{
		if ( GetCurrentTime() - time > 0 )
			{
			if ( !done1 )
				{
				done1 = DoModemTask ( modem1 );
				}
				
#ifdef USERAMMODEMS
			if ( !done2 )
				{
				done2 = DoModemTask ( modem2 );
				}
#endif
			time = GetCurrentTime();
			}
		}

#ifndef SIMULATOR
	*(long *) 0x78 = saveVBL;
#endif

#ifdef SIMULATOR
	// print out our stats:
	printf ( "Total frames: %ld\n", gFrameCount );
	printf ( "Total good packets %ld\n", gGoodPackets );
	printf ( "Max consecutive good packets %ld\n", gMaxConsecutive );
	printf ( "Total kNoData's %ld\n", gMissedData );
	printf ( "Total other errors %ld\n", gErrors );
#endif

	ERROR_MESG( "Quitting" );
	
	GTNetwork_Shutdown ( &gSession->modem.network );
#ifdef USERAMMODEMS
	GTNetwork_Shutdown ( &modem2->session->modem.network );
#endif
	
	modem1 = 0L;
#ifdef SIMULATOR
	modem2 = 0L;
#endif
}


Boolean DoModemTask ( RamModem * modem )
{
Err		err;
long	local;
long	remote;
long	packetTime;
long	timeout;
short	diff;

	++gFrameCount;
	
	// read the controller
	packetTime = GTSession_ReadController ( modem->session, &local, &remote );
	
	if ( packetTime >= 0 )
		{
		++gGoodPackets;
		++gConsecutive;
		
		if ( gConsecutive > gMaxConsecutive )
			{
			gMaxConsecutive = gConsecutive;
			}
			
		diff = local - remote;
		if ( diff < 0 )
			{
			diff *= -1;
			}
			
#ifdef SIMULATOR
		if ( ( diff != 32 && diff != 0 ) || ( diff == 0 && local != '1' ) )
			{
			printf ( "PACKET SYNCH BUG: local %c remote %c\n", (char) local, (char) remote );
			}
#endif
			

		// send the current modem value
		err = GTSession_SendController ( modem->session, modem->nextByte );
//		printf ( "modem %d sent: %x,%c error %d\n", modem->id, modem->nextByte, modem->nextByte, err );

		if ( ++modem->nextByte > modem->lastByte )
			{
			modem->nextByte = modem->firstByte;
			}
		}
	else
	if ( packetTime != kNoData )
		{
		timeout = gTicks + 600;
		err = 1;
		
		gConsecutive = 0;
		
		if ( gErrors++ >= kErrorTolerance )
			{
			ERROR_MESG( "too many fuckers" );
			return true;
			}

#ifdef SIMULATOR
		printf ( "PACKET ERROR: %ld. Received %lx\n", packetTime, remote );
#endif
		while ( err != noErr && gTicks < timeout )
			{
			err = GTSession_ErrorRecover ( modem->session, packetTime, 500 );
			}
			
		if ( err != noErr )
			{
#ifdef SIMULATOR
			printf ( "BAILING: Resynch failed with error %ld\n", err );
#endif
			ERROR_MESG( "Fucker Fucker Fucker" );
			return true;
			}

//		GTSession_PrefillFifo ( modem->session, '1' );
		}
	else
		{
		gMissedData++;
		gConsecutive = 0;
//		printf ( "no data - %d bytes in modem\n", modem->session->modem.byteCount );
		}
	
	return false;
}


#ifdef USERAMMODEMS

Err ModemWriteByte ( RamModem * modem, unsigned char byte )
{
short	saveSr;

	asm { move.w	sr,saveSr };
	asm { move.w	#0x2700,sr };

//	printf ( "Modem %d writing %d to %lx\n", modem->id, byte, modem->writePtr );
	
	*modem->writePtr++ = byte;
	++modem->line->bytesAvail;
	
	// wrap the queue if we need to
	if ( modem->writePtr == modem->line->transmitEnd )
		{
		modem->writePtr = modem->line->transmit;
		}
	
	asm { move.w	saveSr,sr };
	
	return noErr;
}

Err ModemReadByte ( RamModem * modem, unsigned char * byte )
{
Err		err;
short	saveSr;

	asm { move.w	sr,saveSr };
	asm { move.w	#0x2700,sr };

	err = kNoData;

	if ( modem->bytesAvail > 0 )
		{
		--modem->bytesAvail;
		*byte = *modem->readPtr++;
//		printf ( "Modem %d: reading: %d,%c\n", modem->id, *byte, *byte );
		
		// wrap the queue if we need to
		if ( modem->readPtr == modem->transmitEnd )
			{
			modem->readPtr = modem->transmit;
			}
		err = noErr;
		}
	else
		{
//		printf ( "Modem %d: empty\n", modem->id );
		}
		
	asm { move.w	saveSr,sr };
	
	return err;
}
#endif


#ifndef SIMULATOR
void SegaGTTestVBL ( void )
{

	asm
		{
		movem.l	a0-a2/d0-d2,-(sp)
		}

	gTicks++;
	GTSession_ReadHardwareModem ( gSession );
	
	asm
		{
		movem.l	(sp)+,a0-a2/d0-d2
		rte
		}
}
#endif

