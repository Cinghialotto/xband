/*
 *	$Id
 *
 *	$Log: GTControllerTwo.c,v $
 * Revision 1.2  1995/05/10  11:11:02  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GTControllerTwo.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		 <3>	  7/8/94	DJ		added GTSession_ReadBytes
		 <2>	 6/21/94	BET		Managerize
		 <1>	 6/20/94	DJ		first checked in

	To Do:
*/


#include "GT.h"
#include "GTErrors.h"
#include "GTModem.h"
#include "GTErrorRecover.h"


//
// there should be space in the modem's buffer to send this, as we're never really going
// to overload it (we send at most 4 bytes per frame...)
//
Err GTSession_SendTwoController8(GTSession *session, GTController *controller1, GTController *controller2)
{
	return(GTSession_Send2Bytes(session, controller1->bytes[0], controller2->bytes[0]));
}

//
// the bytes should be in the input fifo.  if not, there is a major error.
//
Err GTSession_ReadTwoController8(GTSession *session, GTController *controller1, GTController *controller2, unsigned char *vbl, unsigned char *fractVbl)
{
Err err;

	err = GTSession_Read2Bytes(session, &controller1->bytes[0], &controller2->bytes[0], vbl, fractVbl);

/**
	if(err == kNoError)
		if(controller1->bytes[0] == 0xff)
			return(kSync);
		else
			return(kNoError);
**/

	// if error, what is it?
	// could be kGibbledPacket or kNoData.
	// kGibbled Packet we should sync and send a resend request for packet number VBL.
	// kNoData means that either the line dropped or he crashed or something.
	// if line dropped or call waiting, return that.
	// if not, then we're either way out of sync... so resync...
	// or... he died.

	return(err);
}

// generate a 5bit checksum, pack the bytes, store 'em in the outBuffer, & send 'em.
//
Err _GTSession_Send2Bytes(GTSession *session, unsigned char byte1, unsigned char byte2)
{
unsigned char sendBytes[3];
unsigned char checksum;
GTSessionPacket	*sendPacket;
GTModem			*modem;

	sendPacket = &session->outBuffer[session->outBufferLast++];
	if(session->outBufferLast == kOutBufferLength)
	{
		session->outBufferLast = 0;
		session->wrappedOutBuffer = true;	// just a persistent flag for GTSession_ResendControllers()
	}

	sendPacket->timestamp = session->sendTimeStamp++;
	if(session->sendTimeStamp > kMaxTimeStamp)
		session->sendTimeStamp = 0;


	checksum = GT_GenerateChecksum16(byte1, byte2);
	checksum &= 0x1f;
	sendPacket->bytes[0] = checksum << 3;	// put in 5 bit checksum
	sendPacket->bytes[0] |= byte1 >> 5;		// put in hi 3 bits of byte1
	sendPacket->bytes[1] = byte1 << 3;		// put in lo 5 bits of byte1
	sendPacket->bytes[1] |= byte2 >> 5;		// put in hi 3 bits of byte2
	sendPacket->bytes[2] = byte2 << 3;		// put in lo 5 bits of byte2
	

	// BRAIN DAMAGE.  This could be made more robust... but for now, the modem
	// is expected to be able to send a packet (up to 4 bytes) whenever we call Send.
	//
	modem = &session->modem;
	if(!GTModem_AbleToSend(modem))
	{
		ERROR_MESG("GTSession_Send2Bytes: modem wasn't ready to send\n");
		return( kNoSpace );
	}
	GTModem_SendByte(modem, sendPacket->bytes[0]);

	if(!GTModem_AbleToSend(modem))
	{
		ERROR_MESG("GTSession_Send2Bytes: modem wasn't ready to send\n");
		return( kNoSpace );
	}
	GTModem_SendByte(modem, sendPacket->bytes[1]);

	if(!GTModem_AbleToSend(modem))
	{
		ERROR_MESG("GTSession_Send2Bytes: modem wasn't ready to send\n");
		return( kNoSpace );
	}
	GTModem_SendByte(modem, sendPacket->bytes[2]);

	return(kNoError);
}



//
// takes 2 bytes from the modem and turns it into 1 data byte.
//
Err _GTSession_Read2Bytes(GTSession *session, unsigned char *byte1, unsigned char *byte2, unsigned char *vbl, unsigned char *fractVbl)
{
unsigned char bytes[3];
unsigned char checksum, checksum1;
unsigned char dataByte1, dataByte2;

	if(GTSession_ReadBytes(session, 3, bytes, vbl, fractVbl) != kNoError)
		return(kNoData);

	// See if it is our out-of-band signal.
	//
	if( bytes[0] == kLowSyncControl && bytes[1] == kLowSyncControl && bytes[2] == kLowSyncControl)
		return(kLowSync);

	// De-checksum
	//
	checksum = bytes[0] >> 3;
	dataByte1 = bytes[0] << 5;
	dataByte1 |= bytes[1] >> 3;
	dataByte2 = bytes[1] << 5;
	dataByte2 |= bytes[2] >> 3;

	checksum1 = GT_GenerateChecksum16(dataByte1, dataByte2);

	if(checksum == checksum1)
	{
		*byte1 = dataByte1;
		*byte2 = dataByte2;

		session->recvTimeStamp++;					// successful receive.
		if(session->recvTimeStamp > kMaxTimeStamp)
			session->recvTimeStamp = 0;

		return(kNoError);
	} else
		return(kGibbledPacket);
}

