/*
 *	$Id
 *
 *	$Log: GTModem.c,v $
 * Revision 1.2  1995/05/10  11:11:05  jhsia
 * switch to cvs keywords
 *
 */

/*
	File:		GTModem.c

	Contains:	xxx put contents here xxx

	Written by:	Jevans, Holland, and Perlman

	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.

	Change History (most recent first):

		<21>	 8/24/94	SAH		Integrated Steve's fast new ReadModem and other assembly stuff.
		<20>	 8/22/94	SAH		Don't flag the ice.
		<19>	 8/21/94	ADS		New lomem layout
		<18>	 8/20/94	SAH		Return the error in _GTModem_ReadModem if there's a stored
									modemErr.
		<17>	 8/19/94	SAH		Don't read the line noise in ReadModem until we can figure out
									the weird mapping stuff.
		<16>	 8/16/94	SGP		Reconciled with Harddefines.a.
		<15>	 8/13/94	SAH		New noise testing code from Teddis. Return noise errors
									properly.
		<14>	 8/10/94	HEC		Added 13 lines of assembly to check modem carrier and noise
									level.
		<13>	  8/6/94	SAH		Be sure to return overrun errors.
		<12>	  8/5/94	SAH		Disable interrupts on the sega while reading the modem.
		<11>	 7/29/94	SAH		Fixed the sega modem stuff.
		<10>	 7/29/94	HEC		Renamed PUCheckLineNoise to PUCheckLine.
		 <9>	 7/24/94	SAH		Vector fun.
		 <8>	 7/22/94	SAH		New sheit.
		 <7>	 7/15/94	SAH		Put nasty warnings in GTModem_NumBytesAvailToRead.
		 <6>	 7/13/94	SAH		Dia angle brackets around Types.h to speed up compiles.
		 <5>	 6/28/94	DJ		fixed ifdefs for server and simulator again
		 <4>	 6/28/94	DJ		fixed ifdefs for server and simulator
		 <3>	 6/21/94	BET		(With DJ) Make it work on Fred instead of just compile.
		 <2>	 6/21/94	HEC		Compile in new world
		 <1>	 6/20/94	DJ		first checked in

	To Do:
*/


#include <Types.h>
#include "SegaOS.h"
#include "GT.h"
#include "GTNetwork.h"
#include "GTModem.h"
#include "GTErrors.h"
#include "PhysicalLayer.h"
#include "hardDefines.h"
#include "GamePatch.h"
#include "Globals.h"
#include "NetErrors.h"
#include "GamePatch.h"
#include "GameTalkPriv.h"

#ifdef SIMULATOR
#include <stdio.h>
#endif


//
// Modem
//

void _GTModem_Init(GTModem *modem, Boolean master)
{
long a;

	modem->master = master;
	modem->readIndex = 0;
	modem->writeIndex = 0;
	modem->modemErr = noErr;
	modem->byteCount = 0;
	
	GTNetwork_Init(&modem->network, modem, 0L);
}


//
// Return and clear the modem error
//
Err _GTModem_GetModemError( GTModem * modem )
{
Err		err;

	err = modem->modemErr;
	modem->modemErr = noErr;
	
	return err;
}


void _GTModem_ClearFifo ( GTModem *modem )
{
short			saveSr;
Err				err;
unsigned char	byte;

	asm { move.w	sr,saveSr };
	asm { move.w	#0x2700,sr };

	modem->readIndex = 0;
	modem->writeIndex = 0;
	modem->modemErr = noErr;
	modem->byteCount = 0;

	// now clear the physical modem fifo
	err = noErr;
	while ( err == noErr || err == kOverrunError )
		{
		err = OSReadSerialByte ( &byte );
		}
		
	asm { move.w	saveSr,sr };
}


//
// Someone read a byte from the modem. Stick it in our fifo
// 
void _GTModem_ClockInByte( GTModem *modem, unsigned char byte, unsigned char frame,
									unsigned char vCount, unsigned char currentFrame )
{
			asm
				{
				move.l	modem,a1
	// if the fifo is full, set the modem err to overrun and return without stuffing the byte
	// we'll detect the error next time we clock out a byte
				move.w	GTModem.byteCount(a1),d1
				cmp.w	#kModemInBufferLength,d1
				bne.s	@notFull
				move.l	#kOverrunError,GTModem.modemErr(a1)
				bra.s	@clockInDone

@notFull
				addq.w	#1,d1
				move.w	d1,GTModem.byteCount(a1)
				
				move.w	GTModem.writeIndex(a1),d1
				lea		(a1,d1.w),a0
				move.b	byte,(a0)+					// move byte,frame,currentFrame,VCount	
				move.b	frame,(a0)+
				move.b	currentFrame,(a0)+
				move.b	vCount,(a0)+
				addq.w	#4,d1						// move to next GTModemByte
				and.w	#kModemInBufferMask,d1		// kill upper bits if it wraps
		
				move.w	d1,GTModem.writeIndex(a1)	// update writeIndex
@clockInDone
				}
}


//
// Pull the next byte out of our modem input fifo
// ==BRAIN DAMAGE== Putting this in it's own function is way too slow
// Using indices rather than ptrs is also way to slow
//
Err _GTModem_ClockOutByte ( GTModem * modem, GTModemByte * byte )
{

	asm
	{	
		move.w	sr,d2							// hold sr
		move.w	#0x2700,sr
		
		move.l	modem,a0
		move.l	GTModem.modemErr(a0),d0			// if modem has recorded an error
		beq.s	@noErr
		clr.l	GTModem.modemErr(a0)		// clear it, and return it
		bra.s	@done

@noErr		
		move.w	GTModem.byteCount(a0),d1
		bne.s	@haveData
		move.l	#kNoData,d0
		bra.s	@done

@haveData
		subq.w	#1,d1
		move.w	d1,GTModem.byteCount(a0)
		
		move.w	GTModem.readIndex(a0),d1
		move.l	byte,a1
		move.l	(a0,d1.w),(a1)					// grab modemByte data
		addq.w	#4,d1							// next readIndex
		and.w	#kModemInBufferMask,d1			// kill upper bits if it wraps
		move.w	d1,GTModem.readIndex(a0)		// update readIndex

@done
		move.w	d2,sr							// restore sr
	}
	
}


#define	kModemInBufferMask		((kModemInBufferLength<<2) - 1)	
#define	READNOISE	0


//
// This is called by the game at vbl time to make sure to grab all the data
// It stuffs everything (including the timing info) into the modem fifo
//
Err _GTModem_ReadModem ( GTSession * session )
{
#ifndef SIMULATOR
///////////////////////////////////////////////////////////
// must be first 4 automatic variables to allow long access
unsigned char	vCount;
unsigned char	currentFrame;
unsigned char	frame;
unsigned char	byte;
///////////////////////////////////////////////////////////

		asm
			{
			move.w	d3,-(sp)
			move.l	session,a1
			move.l	GTModem.modemErr(a1),d0
			bne		@returnErr
			
			sf		d2								// init moreData flag

		//	while ( err == noErr )
@whileStart
			tst.l	d0
			bne		@whileEnd


		// disable interrupts inside here in case we're running in mainline code but the vbl is
		// also reading the modem
			move.w	sr,-(sp)
			or.w	#0x700,sr
			
			// get register base
			move.l	OFFSET(SegaLowMem,gameVectors)+OFFSET(GameTimeLowMem,registerBase),a0

#if READNOISE			
			// check modem RLSD && EQM
@rlsd
			btst	#7,kModem+0xF*2+1(a0)			// check RLSD
			beq.s	@noiseerror
@eqm
			move.b	#0x52,kModem+0x1c*2+1(a0)		// stuff XADD
			move.b	#0x81,kModem+0x1d*2+1(a0)		// XCR1,XWT0,XACC1
			bra.s	@checkdata
@noiseerror
			move.l	#kLineNoiseErr,d0
			bra		@done
@checkdata
#endif

			// is there any data ready?
			tst.b	d2								// rxready set to flag moreData
			bne.s	@read							// don't check rxReady again...might be buggy
			move.b	kReadMStatus2+1(a0),d3
			btst	#kRMrxreadyBit,d3
			bne.s	@read
			move.l	#kNoData,d0
			bra		@done

@read		// we have a byte of data, make sure it's ok
			btst	#kRMframeerrBit,d3
			beq.s	@frameOK
			move.l	#kFrameError,d0
			move.b	kRxBuff+1(a0),d3		// read the byte to throw it away
			bra		@done
			
@frameOK
			// check for overrun
			// BRAIN DAMAGE: by bailing here we are losing four good bytes
			// however, keeping the error around is somewhat nasty, so I just
			// bail on the whole thing as we'll have to recover sometime anyway
			move.b	kReadMStatus1+1(a0),d1
			btst	#kRMoverrunBit,d1
			beq.s	@overrunOK
			move.l	#kOverrunError,d0
			bra.s	@done

@overrunOK
#if READNOISE			
			// see what line noise we really have
@wait		btst	#7,kModem+0x1d*2+1(a0)
			bne.s	@wait
			moveq	#0,d1
			move.b	kModem+0x19*2+1(a0),d1			// read XDATA MSB
			lsl.w	#8,d1
			move.b	kModem+0x18*2+1(a0),d1			// read XDATA LSB
//			move.l	modem,a1
			cmp.l	GTSession.eqmThreshold(a1),d1	// above threshold?
			bcc.s	@noiseerror
#endif
			
			// we got a real valid  byte, so stuff it and it's time
			// first save off the current frame count
			and.b	#kRMframecount,d3
			lsr.b	#3,d3
			move.b	d3,frame
			
			// then grab the vCount and the data
			move.b	kReadSerialVCnt+1(a0),d1
			move.b	d1,vCount
			move.b	kRxBuff+1(a0),byte

			// is there another byte?
			move.b	kReadMStatus2+1(a0),d2			// if no byte, snarf framecount
			btst	#kRMrxreadyBit,d2
			bne.s	@anotherByte
			
			// see if data arrived on same VCount as current VCount
			// if so, bump it back by one VCount so there is no uncertainty
			// as to whether data arrived this frame or the last
			// If it arrived this frame, its VCnt is forced to be < current VCnt
			// If it arrived previous, its VCnt is >= current VCnt
			and.b	#kRMframecount,d2				// isolate current framecount
			lsr.b	#3,d2							// shift down framecount
			move.b	d2,currentFrame					// tag read with current framecount
			eor.b	d3,d2							// see if rxData frame different from current frame
			beq.s	@done							// must be same frame if same

@getReadVcntAgain
			clr.b	d2								// flag last byte
			move.b	kReadMVSyncHigh+1(a0),d3		// get current VCount
			cmp.b	kReadMVSyncHigh+1(a0),d3		// validate counter value
			bne.s	@getReadVcntAgain
			lsr.b	#1,d1							// match serial VCnt reolution with d3
			cmp.b	d1,d3							// see if current and serial have same VCnt
			bne.s	@done
			
			// same VCnt, different frame. Data must be from one frame previous
			// Bump VCnt forward by 1 (2 serial VCnts) to eliminate uncertainty.
			cmp.b	#kMaxVCnt,d3					// see if VCnt == kMaxVCnt
			beq.s	@VCntWrap
			addq.b	#2,vCount						// go forward one (low res) VCount
			bra.s	@done

@VCntWrap
			clr.b	vCount							// wrap to 0
			bra.s	@done			

@anotherByte
			move.b	#kUnknownCurrentFrame,currentFrame	// tag with unknown frame
			move.b	d2,d3								// use as new kReadMStatus2
@done
			
			tst.l	d0
			bne.s	@clockInDone
//			move.l	session,a1
// if the fifo is full, set the modem err to overrun and return without stuffing the byte
// we'll detect the error next time we clock out a byte
			move.w	GTModem.byteCount(a1),d1
			cmp.w	#kModemInBufferLength,d1
			bne.s	@notFull
			move.l	#kOverrunError,GTModem.modemErr(a1)
			bra.s	@clockInDone

@notFull
			addq.w	#1,d1
			move.w	d1,GTModem.byteCount(a1)
			
			move.w	GTModem.writeIndex(a1),d1
			move.l	byte,(a1,d1.w)				// move byte,frame,currentFrame,VCount	
			addq.w	#4,d1						// move to next GTModemByte
			and.w	#kModemInBufferMask,d1		// kill upper bits if it wraps
	
			move.w	d1,GTModem.writeIndex(a1)	// update writeIndex
@clockInDone
		
		// restore interrupts
			move.w	(sp)+,sr

		// if no more data, then bail out of while loop
			tst.b	d2
			bne		@whileStart
			move.l	#kNoData,d0

		 // end of while		
@whileEnd

		// save off the modem error
			cmp.l	#kNoData,d0
			beq.s	@returnErr
			move.l	d0,GTModem.modemErr(a1)

@returnErr
			move.w	(sp)+,d3
	
		}
#else
	return noErr;
#endif
}


//
// Is there space in the modem to send a byte?
//
Boolean _GTModem_AbleToSend(GTModem *modem)
{
	return OSTransmitBufferFree() == noErr;
}


/*
*	This is the gametalk send as fast as you can routine. The fred fifo should
*	never be full as we should never be sending that many bytes. Therefore fifo
*	full is a really bad error
*/
Err _GTModem_SendBytes(GTModem *modem, short numBytes, unsigned char *bytes)
{
short	count;
Err		err;
short	overrun;

	err = noErr;
	overrun = false;
	
#ifdef SIMULATOR
	/* just write the puppy as fast as the little fucker can go */
	for ( count = numBytes; count >=0 && err == noErr; --count )
		{
		/* the stimulator uses the PLayer stuff as it needs to block since the card */
		/* has no fifo */
		err = OSWriteSerialByte( *bytes++ );
		}
#else
		asm
			{
			move.l	bytes,a1
			move.w	numBytes,d1
			moveq	#0,d2
			move.l	OFFSET(SegaLowMem,gameVectors)+OFFSET(GameTimeLowMem,registerBase),a0
			
			// wait for the transmit fifo to free up
			// BRAIN DAMAGE - do we want a timeout here - what's a good number?
@nxtByte	move.b	kReadMStatus1+1(a0),d0
			
			// see if the modem has been overrun
			btst	#kRMoverrunBit,d0
			beq.s	@chksend
			st		d2
			
@chksend	btst	#kRMtxfullBit,d0
			bne.s	@nxtByte			
		
			// now that the buffer is free, write the damn byte
			move.b	(a1)+,kTxBuff+1(a0)
			dbra	d1,@nxtByte
@done		move.w	d2,overrun
			}
		
		/* if the modem was overrun and we currently have no error in modemErr, then */
		/* set overrun */
		if ( overrun && modem->modemErr == noErr )
			{
			modem->modemErr = kOverrunError;
			err = kOverrunError;
			}
#endif
	
	return err;
}


Err	_GTModem_CheckLine ( GTModem * modem )
{
Err		err;

	err = OSCheckLine();
		
	return err;
}

