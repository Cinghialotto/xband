;
;	File:		FredEqu.h
;
;	Contains:	xxx put contents here xxx
;
;	Written by:	Shannon Holland
;
;	Copyright:	� 1994 by Catapult Entertainment, Inc., all rights reserved.
;
;	Change History (most recent first):
;
;		 <2>	10/19/94	SAH		Some new bits.
;
;	To Do:
;

; FredEqu.h

; By Steve Roskowski
; 	Copyright Catapult Entertainment, Inc. 1994
; 	All Rights Reserved

; Rev History
; 
; 6/15/94	SGP		Reformatted


kDefaultInternal	equ		($1de000*2)
kDefaultControl		equ		($1dff00*2)
kSoftOffset			equ		($c0*2)


kKillHere			equ 	$1dff00*2 ; same as killheresoft...trans register
kRegHere			equ 	$1dff01*2 ;
kEnblL				equ 	$1de06c*2 ; 
kEnblH				equ 	$1de06d*2 ;
kSafeRamBaseL		equ 	$1de060*2 ;
kSafeRamBaseH		equ 	$1de061*2 ;
kSafeRamBndL		equ 	$1de064*2 ;
kSafeRamBndH		equ 	$1de065*2 ;
kAddrStatusL		equ 	$1de07c*2 ;
kAddrStatusH		equ 	$1de07d*2 ;
kVTableL			equ 	$1de068*2 ;
kVTableH			equ 	$1de069*2 ;
kRangeL				equ 	$1de040*2 ;
kRangeM				equ 	$1de041*2 ;
kRangeH				equ 	$1de042*2 ;
kTrBL				equ 	$1de050*2 ;
kTrBH				equ 	$1de051*2 ;
kTrM				equ 	$1de052*2 ;

kSafeRomBase		equ 	$1de074*2 ;
kSafeRomBnd			equ 	$1de070*2 ;

kKillHereSoft		equ 	$0000c0*2 ;
kCtlRegSoft			equ 	$0000c1*2 ;

kSNESKillHereSoft	equ 	$617000 ;
kSNESCtlRegSoft		equ 	$617001 ;

kLEDEnable			equ 	$1de0b5*2 ;
kLEDData			equ 	$1de0b4*2 ;


;kEnblH:KEnableL Mapping
;kEnblH
kzeroPageEnable		equ		$80		; enable zero page
ktransAddrEnable	equ		$40 	; enable transition address

kVectorAEna			equ		$04
kVector9Ena			equ		$02
kVector8Ena			equ		$01

;kEnblL
kVector7Ena			equ		$80
kVector6Ena			equ		$40
kVector5Ena			equ		$20
kVector4Ena			equ		$10
kVector3Ena			equ		$08
kVector2Ena			equ		$04
kVector1Ena			equ		$02
kVector0Ena			equ		$01

; memory parameters for control register
kEnSNESExcept		equ		$20 ;
kEnFixedInternal	equ 	$10 ;
kEnInternal			equ		$08 ;
kRomHi				equ 	$04 ;
kEnSafeRom			equ 	$02 ;
kEnTwoRam			equ 	$01 ;

; kill register parameters
kHereAssert			equ 	$01 ; Here = cannot see cart
kDecExcept			equ 	$04 ; 
kForce				equ 	$08 ;

; modem (and serial) parameters
kTxBuff				equ 	$1de090*2;
kTxBuffReg			equ		$90*2
kRxBuff				equ 	$1de094*2;
kRxBuffReg			equ 	$94*2;
kReadMStatus1Reg	equ 	$a0*2;
kReadMStatus2Reg	equ 	$98*2;
kReadMStatus1		equ 	$1de0a0*2;
kReadMStatus2		equ 	$1de098*2;
kReadMVSync			equ 	$1de088*2;
kReadSerialVCnt		equ 	$1de09c*2	; Top 8 bits of 20 bit counter tied to 
										; input clock, or it increments 1 each 4096 clks
										; Resets to zero at vblank
										; At 24 MHz, each 170.667 �sec
										; in 1/60 sec, counts up to 97 ($61), so
										; range is 0 to $61 (verified by observation)
kMStatus1			equ 	$1de08c*2;
kMStatus2			equ 	$1de0ac*2;
kBCnt				equ 	$1de0a8*2;
kGuard				equ 	$1de0a4*2;
kVSyncWrite			equ 	$1de0b0*2;

; for rx:
; 1. read status until rxready
; 2. read serialVcnt
; 3. read Rxbuff (reading rxbuff clears the full fifo entry)

; bits for kMStatus1
kMbreak				equ 	$80 ;
kModdparity			equ 	$40 ;
kMenparity			equ 	$20 ;
kMonestop			equ 	$10 ;
kMenstop			equ 	$08 ;
kMbit_8				equ 	$04 ;
kMresetModem		equ 	$02 ;
kMenModem			equ 	$01 ;

kMbreakBit			equ 	$7 ;
kModdparityBit		equ 	$6 ;
kMenparityBit		equ 	$5 ;
kMonestopBit		equ 	$4 ;
kMenstopBit			equ 	$3 ;
kMbit_8Bit			equ 	$2 ;
kMresetModemBit		equ 	$1 ;
kMenModemBit		equ 	$0 ;


; bits for readMStatus1:
smartTxNumRetry		equ		$c0
smartRxNumRetry		equ		$30
overRun				equ		$08
rxBreak				equ		$04
txEmpty				equ		$02
txFull				equ		$01

smartTxNumRetryBit	equ		$5
smartRxNumRetryBit	equ		$4
overRunBit			equ		$3
rxBreakBit			equ		$2
txEmptyBit			equ		$1
txFullBit			equ		$0	; 1 = full, 0 = not full

; bits for readMStatus2:
sFCnt				equ		$18
ltchedParityErr		equ		$04
ltchedFrameErr		equ		$02		
rxReady				equ		$01	; 1 = have rx data, 0 = no data

ltchedParityErrBit	equ		$2
ltchedFrameErrBit	equ		$1		
rxReadyBit			equ		$0

;bits for kMStatus2
kMsync				equ 	$8 ;
kMsmart				equ 	$4 ;
kMensmarttxretry	equ 	$2 ;
kMensmartrxretry	equ 	$1 ;

; smart card parameters
kSCtl				equ 	$1de080*2 ; 
kSStatus			equ 	$1de084*2 ;

; parameters for smart control
kSoutputClk			equ 	$01;
kSenOutputData		equ 	$02;
kSoutputData		equ 	$04;
kSoutputReset		equ 	$08;
kSoutputVcc			equ 	$10;

; parameters for control II
kSoutputVpp			equ	 	$01;

